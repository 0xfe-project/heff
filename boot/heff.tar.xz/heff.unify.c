// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_failed 665164648
#define LBL_hmap 9701563
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_renEv 309756614
#define LBL_renEvTy 1323365525
#define LBL_renFlex 1323386232
#define LBL_renTy 309757082
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_solve 310977625
#define LBL_span 10032145
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_mel__mty__msp[] = {LBL_mel, LBL_mty, LBL_msp};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
static uint32_t shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex[] = {LBL_uty, LBL_uel, LBL_ubare, LBL_solve, LBL_ren, LBL_renEv, LBL_renTy, LBL_renEvTy, LBL_renFlex};
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2econversion_2ecanon(V);
V g_heff_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2econversion_2ecanon_clo;
V g_heff_2econversion_2eeqHead(V, V);
V g_heff_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2econversion_2eeqHead_clo;
V g_heff_2edict_2eindexed(V, V);
V g_heff_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2edict_2eindexed_clo;
V g_heff_2edict_2ezipKV(V, V);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_heff_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTermF_clo;
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(V, V, V, V);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_clo;
V g_heff_2eeval_2eevaluator_get(void);
V g_heff_2eparams_2eemptyShape_get(void);
V g_heff_2eparams_2eeqLevel(V, V);
V g_heff_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eparams_2eeqLevel_clo;
V g_heff_2epsurface_2eelF_24s473646377x555746588(V, V, V, V);
V g_heff_2epsurface_2eelF_24s473646377x555746588_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s473646377x555746588_clo;
V g_heff_2eunify_2eanyL(V, V);
V g_heff_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eunify_2eanyL_clo;
V g_heff_2eunify_2eappendL(V, V);
V g_heff_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eunify_2eappendL_clo;
V g_heff_2eunify_2ecatMaybes(V);
V g_heff_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eunify_2ecatMaybes_clo;
V g_heff_2eunify_2econcatMapL(V, V);
V g_heff_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eunify_2econcatMapL_clo;
V g_heff_2eunify_2edistinct(V);
V g_heff_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eunify_2edistinct_clo;
V g_heff_2eunify_2eeqPatArgs(V, V);
V g_heff_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eunify_2eeqPatArgs_clo;
V g_heff_2eunify_2eforU(V, V, V, V, V);
V g_heff_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eunify_2eforU_clo;
V g_heff_2eunify_2eiterateLift(V, V);
V g_heff_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eunify_2eiterateLift_clo;
V g_heff_2eunify_2elamsU(V, V);
V g_heff_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eunify_2elamsU_clo;
V g_heff_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eunify_2emapWithIndexL_clo;
V g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925(V, V);
V g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925_entry(V self, V *a);
extern Clo g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925_clo;
V g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904(V, V);
V g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904_entry(V self, V *a);
extern Clo g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904_clo;
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529(V, V, V);
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_clo;
V g_heff_2eunify_2emetasK(V);
V g_heff_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasK_clo;
V g_heff_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasSpF_clo;
V g_heff_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasTermF_clo;
V g_heff_2eunify_2emetasTypeF(V, V, V, V, V);
V g_heff_2eunify_2emetasTypeF_entry(V self, V *a);
extern Clo g_heff_2eunify_2emetasTypeF_clo;
V g_heff_2eunify_2emsEv(V);
V g_heff_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eunify_2emsEv_clo;
V g_heff_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eunify_2enewMetaIn_clo;
V g_heff_2eunify_2enth(V, V);
V g_heff_2eunify_2enth_entry(V self, V *a);
extern Clo g_heff_2eunify_2enth_clo;
V g_heff_2eunify_2epatSpine(V, V, V);
V g_heff_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eunify_2epatSpine_clo;
V g_heff_2eunify_2epatStep(V, V, V);
V g_heff_2eunify_2epatStep_entry(V self, V *a);
extern Clo g_heff_2eunify_2epatStep_clo;
V g_heff_2eunify_2epatVarsOf(V);
V g_heff_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eunify_2epatVarsOf_clo;
V g_heff_2eunify_2epoisonEl(V, V, V, V, V);
V g_heff_2eunify_2epoisonEl_entry(V self, V *a);
extern Clo g_heff_2eunify_2epoisonEl_clo;
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400(V, V, V, V);
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_entry(V self, V *a);
extern Clo g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_clo;
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448(V, V, V, V);
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_entry(V self, V *a);
extern Clo g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_clo;
V g_heff_2eunify_2erenameClo_24s402172772x1190044452(V, V, V, V, V);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameClo_24s402172772x1190044452_clo;
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877(V, V, V, V, V);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_clo;
V g_heff_2eunify_2erenameF_24s1030639481x1219654980(V, V, V, V, V, V);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo;
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983(V, V, V, V, V, V, V);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameFlexF_24s593953928x917846983_clo;
V g_heff_2eunify_2erenameHead_24s1197776504x706394141(V, V);
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameHead_24s1197776504x706394141_clo;
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417(V, V, V, V, V, V);
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_clo;
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631(V, V, V, V, V);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameSpine_24s1422019577x129546631_clo;
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(V, V, V, V, V, V);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_entry(V self, V *a);
extern Clo g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo;
V g_heff_2eunify_2esolveF_24s190498893x664563428(V, V, V, V, V, V, V, V);
V g_heff_2eunify_2esolveF_24s190498893x664563428_entry(V self, V *a);
extern Clo g_heff_2eunify_2esolveF_24s190498893x664563428_clo;
V g_heff_2eunify_2esolveRhs_24s86524727x216308409(V, V, V, V, V);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_entry(V self, V *a);
extern Clo g_heff_2eunify_2esolveRhs_24s86524727x216308409_clo;
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806(V, V, V, V, V, V, V, V);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_entry(V self, V *a);
extern Clo g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_clo;
V g_heff_2eunify_2estoreSol_24s913555157x21100521(V, V, V);
V g_heff_2eunify_2estoreSol_24s913555157x21100521_entry(V self, V *a);
extern Clo g_heff_2eunify_2estoreSol_24s913555157x21100521_clo;
V g_heff_2eunify_2estripLams(V, V);
V g_heff_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eunify_2estripLams_clo;
V g_heff_2eunify_2esubstOf(V);
V g_heff_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstOf_clo;
V g_heff_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstTermF_clo;
V g_heff_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstTyFields_clo;
V g_heff_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eunify_2esubstTypeF_clo;
V g_heff_2eunify_2etraceSolve_24s634453577x121216057(V, V);
V g_heff_2eunify_2etraceSolve_24s634453577x121216057_entry(V self, V *a);
extern Clo g_heff_2eunify_2etraceSolve_24s634453577x121216057_clo;
V g_heff_2eunify_2etraverseU_24s427677288x1451739928(V, V);
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_entry(V self, V *a);
extern Clo g_heff_2eunify_2etraverseU_24s427677288x1451739928_clo;
V g_heff_2eunify_2euAlg(V, V);
V g_heff_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eunify_2euAlg_clo;
V g_heff_2eunify_2euBareF_24s1294623001x1737536464(V, V, V, V, V, V);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_entry(V self, V *a);
extern Clo g_heff_2eunify_2euBareF_24s1294623001x1737536464_clo;
V g_heff_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eunify_2euElRigid_clo;
V g_heff_2eunify_2euH_get(void);
V g_heff_2eunify_2euModify(V, V, V, V);
V g_heff_2eunify_2euModify_entry(V self, V *a);
extern Clo g_heff_2eunify_2euModify_clo;
V g_heff_2eunify_2euModify_24s1340946300x2077833874(V, V, V);
V g_heff_2eunify_2euModify_24s1340946300x2077833874_entry(V self, V *a);
extern Clo g_heff_2eunify_2euModify_24s1340946300x2077833874_clo;
V g_heff_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2euTermF_clo;
V g_heff_2eunify_2euTyRigid(V, V, V, V, V, V, V, V);
V g_heff_2eunify_2euTyRigid_entry(V self, V *a);
extern Clo g_heff_2eunify_2euTyRigid_clo;
V g_heff_2eunify_2euTypeF_24s957014611x2143677719(V, V, V, V, V, V);
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_entry(V self, V *a);
extern Clo g_heff_2eunify_2euTypeF_24s957014611x2143677719_clo;
V g_heff_2eunify_2eufEv(V);
V g_heff_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eunify_2eufEv_clo;
V g_heff_2eunify_2euk_24s99985437x1876045342_get(void);
V g_heff_2eunify_2ezipL(V, V);
V g_heff_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezipL_clo;
V g_heff_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezonkTermF_clo;
V g_heff_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezonkTypeF_clo;
V g_heff_2eunify_2ezonker(V);
V g_heff_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eunify_2ezonker_clo;
V g_heff_2evalue_2ebehavior(V);
V g_heff_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2evalue_2ebehavior_clo;
V g_heff_2evalue_2eforceEl(V, V);
V g_heff_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2evalue_2eforceEl_clo;
V g_heff_2evalue_2eforceTy(V, V);
V g_heff_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2evalue_2eforceTy_clo;
V g_heff_2evalue_2eisError(V);
V g_heff_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2evalue_2eisError_clo;
V g_heff_2evalue_2eisFixed(V, V);
V g_heff_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2evalue_2eisFixed_clo;
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694(V, V, V, V);
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s1912479565x1511825694_clo;
V g_heff_2evalue_2ereplay(V, V);
V g_heff_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2evalue_2ereplay_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1377741640x1185496867(V, V);
V g_prelude_2efoldl_24s1377741640x1185496867_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1377741640x1185496867_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s848659184x39013903(V, V);
V g_prelude_2efoldl_24s848659184x39013903_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s848659184x39013903_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1581021428x1223114127(V);
V g_prelude_2emap_24s1581021428x1223114127_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1581021428x1223114127_clo;
V g_prelude_2emap_24s531459667x996402587(V);
V g_prelude_2emap_24s531459667x996402587_entry(V self, V *a);
extern Clo g_prelude_2emap_24s531459667x996402587_clo;
V g_heff_2eunify_2euModify_lam1(V self, V *args);
V g_heff_2eunify_2euModify_lam0(V self, V *args);
V g_heff_2eunify_2euModify_lam4(V self, V *args);
V g_heff_2eunify_2euModify_lam3(V self, V *args);
V g_heff_2eunify_2euModify_lam2(V self, V *args);
Clo g_heff_2eunify_2euModify_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euModify_entry, 4, 0};

V g_heff_2eunify_2euModify(V v_w_240, V v_ms_241, V v_uf_242, V v_f_243) {
top: ;
  V v_p_244 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_243})}));
  V v_c_2410 = heff_clo(g_heff_2eunify_2euModify_lam0, 2, 2, (V[]){heff_dup(v_w_240), v_p_244});
  return heff_clo(g_heff_2eunify_2euModify_lam2, 2, 3, (V[]){v_c_2410, v_ms_241, v_w_240});
}
V g_heff_2eunify_2euModify_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euModify(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2eunify_2euModify_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_245), heff_get(v_hd_245, LBL_ret)});
}
V g_heff_2eunify_2euModify_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euModify_lam1, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_248}));
  V f_ = heff_get(v_hd_245, LBL_bind);
  args[0] = v_t_249;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euModify_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2411), heff_get(v_hd_2411, LBL_ret)});
}
V g_heff_2eunify_2euModify_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_p_2415 = heff_tr(heff_apply(v_ms_241, 1, (V[]){v_t_2414}));
  V v_t_2417 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euModify_lam4, 1, 1, (V[]){heff_dup(v_hd_2411)}), v_p_2415}));
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2418, v_k_2412});
}
V g_heff_2eunify_2euModify_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2eunify_2euModify_lam3, 1, 4, (V[]){v_ms_241, v_w_240, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          v_t_2411 = heff_intEq(heff_dup(v_l_248), heff_dup(v_l_27_249));
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eeqPatArgs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, (g_heff_2eunify_2epatVarsOf(v_rest_242))});
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epatVarsOf(a[0]);
}
V g_heff_2eunify_2edistinct_lam0(V self, V *args);
Clo g_heff_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_244 = (g_prelude_2eany(heff_clo(g_heff_2eunify_2edistinct_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2edistinct(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2edistinct_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_x_241, v_b_243);
}
Clo g_heff_2eunify_2epatStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatStep_entry, 3, 0};

V g_heff_2eunify_2epatStep(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_it1_244 = heff_field(v_v_241, 0);
      V v_it2_245 = heff_field(v_v_241, 1);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_it1_244, 0);
        heff_drop(v_selfKey_240);
        switch (heff_tag_of(v_it2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){heff_dup(v_l_249)}), v_rest_243});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2410});
        }
        case TAG_SpApp: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_245);
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_it1_244, 0);
        switch (heff_tag_of(v_it2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_rest_243);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            heff_take_n(v_selfKey_240, 1ULL, 1);
            V v_t_2420 = heff_strEq(v_sk_2419, heff_dup(v_k_2418));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_True: {
              V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return heff_tag_at(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
            }
            case TAG_False: {
              heff_drop(v_rest_243);
              heff_drop_cell(v_ru_24x3_242_24Just, 1);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
          default: return heff_nomatch(v_selfKey_240);
          }
        }
        case TAG_SpApp: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_245);
        }
      }
      case TAG_HMeta: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it1_244);
      }
    }
    case TAG_VCode: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_v_241);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2epatStep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epatStep(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop(v_selfKey_240);
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2evalue_2eforceEl(v_mc_241, heff_dup(v_v_244)));
    V v_t_246 = (g_heff_2eunify_2epatSpine(heff_dup(v_selfKey_240), v_mc_241, v_s_243));
    return ({ V a_0 = v_selfKey_240; V a_1 = v_t_245; V a_2 = v_t_246; V r_ = (g_heff_2eunify_2epatStep(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_SpProj: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epatSpine(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eunify_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2enth_entry, 2, 0};

V g_heff_2eunify_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2enth_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2enth(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eunify_2emapWithIndexL(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eunify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eunify_2ecatMaybes(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2ecatMaybes(a[0]);
}
Clo g_heff_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eanyL(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eunify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2econcatMapL(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2eforU_lam0(V self, V *args); static Clo g_heff_2eunify_2eforU_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eforU_lam0, 2, 0};
V g_heff_2eunify_2eforU_lam2(V self, V *args);
V g_heff_2eunify_2eforU_lam1(V self, V *args);
Clo g_heff_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eforU_entry, 5, 0};

V g_heff_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    return ((V)&g_heff_2eunify_2eforU_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_apply(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_clo(g_heff_2eunify_2eforU_lam1, 2, 6, (V[]){v_c_249, heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eforU(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eunify_2eforU_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2eforU_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_t_2413 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V r_ = (g_heff_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_2410, v_k_2411});
}
V g_heff_2eunify_2eforU_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_uf_242 = heff_env(self)[3];
  V v_xs_248 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2eunify_2eforU_lam2, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_xs_248, v_f_244, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_depth_242), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_it_246 = (g_heff_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_246)) {
    case TAG_VNeu: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_sp_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 5);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HMeta: {
        V v_m_2414 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248}));
        return heff_tag(TAG_Cons, 2, (V[]){v_m_2414, v_t_2415});
      }
      case TAG_HError: {
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    case TAG_VCode: {
      V v_t_2416 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      return heff_tail(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2416});
    }
    case TAG_VLam: {
      V v_d_2417 = heff_field(v_it_246, 0);
      V v_c_2418 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      V v_x1_2439;
      switch (heff_tag_of(v_c_2418)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_c_2418, 1);
        V v_body_2421 = heff_field(v_c_2418, 2);
        heff_take_n(v_c_2418, 6ULL, 3);
        v_x1_2439 = heff_tr(heff_apply(v_body_2421, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo(g_heff_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2417, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2438 = heff_field(v_c_2418, 0);
        heff_take_n(v_c_2418, 1ULL, 1);
        heff_drop(v_d_2417);
        v_x1_2439 = v_body_2438;
        break;
      }
      default: heff_nomatch(v_c_2418);
      }
      V v_t_2443;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_Nom: {
        V v_x_2440 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2440;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2439, 0ULL, 1);
        v_t_2443 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2442 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2442;
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2443});
    }
    case TAG_VCons: {
      V v_d_2444 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      V v_t_2445 = heff_arrayToList(heff_get(v_d_2444, LBL_values));
      return ({ V a_0 = heff_clo(g_heff_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_r_240, v_depth_242, v_len_243}); V a_1 = v_t_2445; V r_ = (g_heff_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2445); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasTermF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  V v_a_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return v_a_2436;
}
V g_heff_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2417 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_apply(v_d_2417, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2423)));
  V v_a_2436;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2427 = heff_field(v_t_2424, 1);
    heff_take_n(v_t_2424, 2ULL, 4);
    heff_drop(v_t_2423);
    v_a_2436 = v_dom_2427;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2424, 0ULL, 3);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeInt: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeString: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_NoRules: {
    v_a_2436 = v_t_2423;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2436}), NTAG(TAG_Nothing)));
}
V g_heff_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2446 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2450});
}
V g_heff_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_depth_242), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_t_246 = (g_heff_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 16ULL, 5);
      V v_t_2413 = heff_tr(heff_apply(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 5);
      V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_mty), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2426;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2421 = heff_field(v_cod_2416, 1);
        V v_body_2422 = heff_field(v_cod_2416, 2);
        heff_take_n(v_cod_2416, 6ULL, 3);
        v_x1_2426 = heff_tr(heff_apply(v_body_2422, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2421, heff_clo(g_heff_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2425 = heff_field(v_cod_2416, 0);
        heff_take_n(v_cod_2416, 1ULL, 1);
        heff_drop(v_dom_2415);
        v_x1_2426 = v_body_2425;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2430;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_Nom: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2427;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2426, 0ULL, 1);
        v_t_2430 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2429 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2429;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_t_2431 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2430}));
      return (g_heff_2eunify_2eappendL(v_t_2419, v_t_2431));
    }
    case TAG_VRecord: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2437 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tail(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2437});
    }
    case TAG_VFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasTypeF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_2415;
}
V g_heff_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2423);
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_msp), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_msp), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasSpF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); heff_drop(a[4]); return r;
}
V g_heff_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec(3, shape_mel__mty__msp, (V[]){heff_clo(g_heff_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasK(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eunify_2epoisonEl_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonEl_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_lam0, 1, 0};
V g_heff_2eunify_2epoisonEl_lam2(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam1(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam5(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam4(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam3(V self, V *args);
Clo g_heff_2eunify_2epoisonEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_entry, 5, 0};

V g_heff_2eunify_2epoisonEl(V v_w_240, V v_ms_241, V v_uf_242, V v_len_243, V v_v_244) {
top: ;
  V v_p_246 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonEl_lam0_clo)})}));
  V v_c_2412 = heff_clo(g_heff_2eunify_2epoisonEl_lam1, 2, 2, (V[]){heff_dup(v_w_240), v_p_246});
  return heff_clo(g_heff_2eunify_2epoisonEl_lam3, 2, 6, (V[]){v_c_2412, v_len_243, v_v_244, v_w_240, v_ms_241, heff_dup(v_uf_242)});
}
V g_heff_2eunify_2epoisonEl_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epoisonEl(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eunify_2epoisonEl_lam0(V self, V *args) {
  V v_c_245 = args[0];
  return heff_get(v_c_245, LBL_metas);
}
V g_heff_2eunify_2epoisonEl_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_247), heff_get(v_hd_247, LBL_ret)});
}
V g_heff_2eunify_2epoisonEl_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2epoisonEl_lam2, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2410}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2411;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2epoisonEl_lam5(V self, V *args) {
  V v_c_2418 = args[0];
  V v_ms_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2419 = ({ V a_0 = heff_get(heff_dup(v_c_2418), LBL_poisoned); V a_1 = v_ms_2417; V r_ = (g_prelude_2efoldl_24s1377741640x1185496867(a_0, a_1)); heff_drop(v_ms_2417); r_; });
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_2418), LBL_infos), heff_get(heff_dup(v_c_2418), LBL_recovered), v_ps_2419, heff_get(heff_dup(v_c_2418), LBL_metas), heff_get(heff_dup(v_c_2418), LBL_nextMeta), heff_get(heff_dup(v_c_2418), LBL_postponed), heff_get(heff_dup(v_c_2418), LBL_trace), heff_get(v_c_2418, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonEl_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = ({ V a_0 = v_x_2415; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_2415); r_; });
  V v_ms_2417 = heff_tr(heff_apply(heff_get(v_t_2416, LBL_mel), 3, (V[]){MK_INT(20LL), v_len_243, v_v_244}));
  V v_t_2420 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = heff_clo(g_heff_2eunify_2epoisonEl_lam5, 1, 1, (V[]){v_ms_2417}); V r_ = (g_heff_2eunify_2euModify(a_0, a_1, a_2, a_3)); heff_drop(v_uf_242); r_; });
  return heff_tail(v_t_2420, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2eunify_2epoisonEl_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  V v_v_244 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_ms_241 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2eunify_2epoisonEl_lam4, 1, 7, (V[]){v_len_243, v_v_244, v_w_240, v_ms_241, v_uf_242, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_245 = heff_intLt(heff_dup(v_i_244), heff_dup(v_d_242));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_d_242);
      return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    }
    case TAG_False: {
      V v_t_246 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      V v_t_248 = (g_heff_2eunify_2enth(v_idxs_241, v_t_247));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_242);
        return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
      }
      case TAG_Just: {
        V v_j_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        heff_drop(v_i_244);
        return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_249, v_d_242)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_SGlobal: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty_2411}));
    return heff_tag_at(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_t_243, 0);
    V v_a_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_f_2413}));
    V v_t_2416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_a_2414}));
    return heff_tag_at(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_dd_2417 = heff_field(v_t_243, 0);
    V v_it2_2418 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_it2_2418)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_it2_2418, 0);
      V v_b_2420 = heff_field(v_it2_2418, 1);
      heff_take_n(v_it2_2418, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2420}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2419, v_t_2422})});
    }
    case TAG_AbsConst: {
      V v_b_2423 = heff_field(v_it2_2418, 0);
      heff_take_n(v_it2_2418, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2425 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2423}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2425})});
    }
    default: return heff_nomatch(v_it2_2418);
    }
  }
  case TAG_SCons: {
    V v_dct_2426 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2427 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_xs_2428 = heff_get(heff_dup(v_dct_2426), LBL_values);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo(g_heff_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    V v_t_2432 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_dct_2426), LBL_keys), heff_get(v_dct_2426, LBL_byName), v_t_2431});
    return heff_tag_at(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2432});
  }
  case TAG_SProj: {
    V v_e_2433 = heff_field(v_t_243, 0);
    V v_l_2434 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2433}));
    return heff_tag_at(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2435, v_l_2434});
  }
  case TAG_STag: {
    V v_x_2436 = heff_field(v_t_243, 0);
    V v_as_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2437)), heff_clo(g_heff_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_as_2437, v_f_2438}));
    return heff_tag_at(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2436, v_t_2441});
  }
  case TAG_SMatch: {
    V v_e_2442 = heff_field(v_t_243, 0);
    V v_cs_2443 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2442}));
    V v_xs_2445 = heff_get(heff_dup(v_cs_2443), LBL_values);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2445)), heff_clo(g_heff_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2445, v_d_242, v_r_240}));
    V v_t_2453 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_cs_2443), LBL_keys), heff_get(v_cs_2443, LBL_byName), v_t_2452});
    return heff_tag_at(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e_2454 = heff_field(v_t_243, 0);
    V v_l_2455 = heff_field(v_t_243, 1);
    V v_v_2456 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2454}));
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_v_2456}));
    return heff_tag_at(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2461 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2462 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2461}));
    return heff_tag_at(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_dd_2463 = heff_field(v_t_243, 0);
    V v_it2_2464 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_it2_2464)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_it2_2464, 0);
      V v_b_2466 = heff_field(v_it2_2464, 1);
      heff_take_n(v_it2_2464, 3ULL, 2);
      V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2468 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2466}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2467, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2468})});
    }
    case TAG_AbsConst: {
      V v_b_2469 = heff_field(v_it2_2464, 0);
      heff_take_n(v_it2_2464, 1ULL, 1);
      V v_t_2470 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2471 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2469}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2471})});
    }
    default: return heff_nomatch(v_it2_2464);
    }
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_t_243, 0);
    V v_e_2473 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2473}));
    return heff_tag_at(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_t_243, 0);
    V v_ix_2477 = heff_field(v_t_243, 1);
    V v_ty_2478 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2486 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_ix_2477)), heff_clo(g_heff_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2477, heff_dup(v_d_242), heff_dup(v_idxs_241)}));
    V v_t_2487 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty_2478}));
    return heff_tag_at(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_t_2486, v_t_2487});
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstTermF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  V f_ = v_f_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2439 = args[0];
  V v_as_2437 = heff_env(self)[0];
  V v_f_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_as_2437, v_i_2439);
  V f_ = v_f_2438;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2448)));
    V v_t_2451 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_t_2450, v_b_2449}));
    return heff_tag_at(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2479 = args[0];
  V v_ix_2477 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_idxs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_i_2480 = heff_arrayIndex(v_ix_2477, v_i_2479);
  V v_t_2481 = heff_intLt(heff_dup(v_i_2480), heff_dup(v_d_242));
  switch (heff_tag_of(v_t_2481)) {
  case TAG_True: {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    return v_i_2480;
  }
  case TAG_False: {
    V v_t_2482 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
    V v_t_2483 = heff_intSub(heff_intSub(v_t_2482, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2480), heff_dup(v_d_242)));
    V v_t_2484 = ({ V a_0 = v_idxs_241; V a_1 = v_t_2483; V r_ = (g_heff_2eunify_2enth(a_0, a_1)); heff_drop(v_idxs_241); r_; });
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      heff_drop(v_d_242);
      return v_i_2480;
    }
    case TAG_Just: {
      V v_j_2485 = heff_field(v_t_2484, 0);
      heff_take_n(v_t_2484, 1ULL, 1);
      heff_drop(v_i_2480);
      return heff_intAdd(v_j_2485, v_d_242);
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
  default: return heff_nomatch(v_t_2481);
  }
}
Clo g_heff_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    return heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eunify_2esubstTyFields(v_r_240, v_d_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245))});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eunify_2esubstTypeF_lam0(V self, V *args);
V g_heff_2eunify_2esubstTypeF_lam2(V self, V *args);
Clo g_heff_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_it3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_it3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_it3_249, 0);
      V v_b_2413 = heff_field(v_it3_249, 1);
      heff_take_n(v_it3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_it3_249, 0);
      heff_take_n(v_it3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_it3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2422 = heff_arrayToList(heff_get(heff_dup(v_ft_2420), LBL_values));
    V v_t_2423 = (g_heff_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2422));
    V v_t_2424 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_ft_2420), LBL_keys), heff_get(v_ft_2420, LBL_byName), heff_arrayFromList(v_t_2423)});
    return heff_tag_at(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2424, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2426 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_d_242}));
    V v_f_2430 = heff_clo(g_heff_2eunify_2esubstTypeF_lam0, 1, 1, (V[]){v_f_2426});
    V v_xs_2431 = heff_get(heff_dup(v_vs_2425), LBL_values);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2431)), heff_clo(g_heff_2eunify_2esubstTypeF_lam2, 1, 2, (V[]){v_xs_2431, v_f_2430}));
    V v_t_2435 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_vs_2425), LBL_keys), heff_get(v_vs_2425, LBL_byName), v_t_2434});
    return heff_tag_at(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2435});
  }
  case TAG_SIsTy: {
    V v_a_2436 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2437 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_a_2436}));
    return heff_tag_at(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2437});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SFixed: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstTypeF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  V f_ = v_f_2426;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_xs_2427 = args[0];
  V v_f_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo(g_heff_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2427, v_f_2426}));
}
V g_heff_2eunify_2esubstTypeF_lam2(V self, V *args) {
  V v_i_2432 = args[0];
  V v_xs_2431 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_xs_2431, v_i_2432);
  V f_ = v_f_2430;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec(2, shape_el__ty, (V[]){heff_clo(g_heff_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo(g_heff_2eunify_2esubstOf_lam1, 2, 1, (V[]){heff_dup(v_idxs_240)})});
}
V g_heff_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_243; V a_1 = v_idxs_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eunify_2esubstTermF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
Clo g_heff_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return v_t_241;
  }
  case TAG_False: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take_n(v_it2_249, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take_n(v_it2_249, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFixed: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat32: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2estripLams(a[0], a[1]);
}
V g_heff_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_245}));
    return heff_tag_at(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_a_248}));
    return heff_tag_at(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get(v_r_240, LBL_el);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at(v_ru_24t_242_24SLam, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse_n(v_b_2412, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SLam, 2);
      V v_t_2419 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag(TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2422 = heff_get(heff_dup(v_d_2421), LBL_values);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo(g_heff_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2422, v_r_240}));
    V v_t_2426 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_d_2421), LBL_keys), heff_get(v_d_2421, LBL_byName), v_t_2425});
    return heff_tag_at(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e_2427 = heff_field(v_t_242, 0);
    V v_l_2428 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2427}));
    return heff_tag_at(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_x_2430 = heff_field(v_t_242, 0);
    V v_as_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2431)), heff_clo(g_heff_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_as_2431, v_r_240}));
    return heff_tag_at(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2430, v_t_2434});
  }
  case TAG_SMatch: {
    V v_e_2435 = heff_field(v_t_242, 0);
    V v_cs_2436 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_e_2435}));
    V v_xs_2438 = heff_get(heff_dup(v_cs_2436), LBL_values);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo(g_heff_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2438, v_r_240}));
    V v_t_2445 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_cs_2436), LBL_keys), heff_get(v_cs_2436, LBL_byName), v_t_2444});
    return heff_tag_at(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2437, v_t_2445});
  }
  case TAG_SSpecialize: {
    V v_e_2446 = heff_field(v_t_242, 0);
    V v_l_2447 = heff_field(v_t_242, 1);
    V v_v_2448 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_e_2446}));
    V v_t_2450 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_v_2448}));
    return heff_tag_at(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2449, v_l_2447, v_t_2450});
  }
  case TAG_SIs: {
    V v_e_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2451}));
    return heff_tag_at(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2452});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2453 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2454 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2453}));
    return heff_tag_at(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2454});
  }
  case TAG_SFix: {
    V v_d_2455 = heff_field(v_t_242, 0);
    V v_b_2456 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_d_2455}));
    V v_f_2458 = heff_get(v_r_240, LBL_el);
    V v_t_2464;
    switch (heff_tag_of(v_b_2456)) {
    case TAG_MkAbs: {
      V v_x_2459 = heff_field(v_b_2456, 0);
      V v_b_2460 = heff_field(v_b_2456, 1);
      heff_take_n(v_b_2456, 3ULL, 2);
      V v_t_2461 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2460}));
      v_t_2464 = heff_tag_at(v_ru_24t_242_24SFix, TAG_MkAbs, 2, (V[]){v_x_2459, v_t_2461});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2462 = heff_field(v_b_2456, 0);
      V v_ru_24b_2456_24AbsConst = heff_take_reuse_n(v_b_2456, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SFix, 2);
      V v_t_2463 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2462}));
      v_t_2464 = heff_tag_at(v_ru_24b_2456_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2463});
      break;
    }
    default: heff_nomatch(v_b_2456);
    }
    return heff_tag(TAG_SFix, 2, (V[]){v_t_2457, v_t_2464});
  }
  case TAG_SImplicit: {
    V v_x_2465 = heff_field(v_t_242, 0);
    V v_e_2466 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2466}));
    return heff_tag_at(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2465, v_t_2467});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2469 = heff_field(v_t_242, 0);
    V v_idxs_2470 = heff_field(v_t_242, 1);
    V v_ty_2471 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2472 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_2469), v_mc_241));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_Nothing: {
      V v_t_2473 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_2471}));
      return heff_tag_at(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2473});
    }
    case TAG_Just: {
      V v_e_2474 = heff_field(v_t_2472, 0);
      heff_take_n(v_t_2472, 1ULL, 1);
      V v_t_2475 = heff_get(v_e_2474, LBL_solStx);
      switch (heff_tag_of(v_t_2475)) {
      case TAG_Nothing: {
        V v_t_2476 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_2471}));
        return heff_tag_at(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2476});
      }
      case TAG_Just: {
        V v_sol_2477 = heff_field(v_t_2475, 0);
        heff_take_n(v_t_2475, 1ULL, 1);
        heff_drop(v_m_2469);
        heff_drop(v_ty_2471);
        heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
        V v_idxs_2478 = heff_arrayToList(v_idxs_2470);
        V v_t_2479 = (g_heff_2eunify_2esubstOf(v_idxs_2478));
        V v_t_2480 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_idxs_2478; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_idxs_2478); r_; });
        V v_t_2481 = (g_heff_2eunify_2estripLams(v_t_2480, v_sol_2477));
        V v_t_2482 = heff_tr(heff_apply(heff_get(v_t_2479, LBL_el), 2, (V[]){MK_INT(0LL), v_t_2481}));
        return heff_tail(heff_get(v_r_240, LBL_el), 1, (V[]){v_t_2482});
      }
      default: return heff_nomatch(v_t_2475);
      }
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitFixed: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitFloat32: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonkTermF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get(v_r_240, LBL_el);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_as_2431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_as_2431, v_i_2432);
  V f_ = heff_get(v_r_240, LBL_el);
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_xs_2441 = heff_field(v_p_2440, 0);
    V v_b_2442 = heff_field(v_p_2440, 1);
    V v_ru_24p_2440_24MkPair = heff_take_reuse_n(v_p_2440, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_b_2442}));
    return heff_tag_at(v_ru_24p_2440_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_p_2440);
  }
}
V g_heff_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_244}));
    return heff_tag_at(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_dom_247}));
    V v_f_2412 = heff_get(heff_dup(v_r_240), LBL_ty);
    V v_t_2418;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_248, 0);
      V v_b_2414 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_apply(v_f_2412, 1, (V[]){v_b_2414}));
      v_t_2418 = heff_tag_at(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_apply(v_f_2412, 1, (V[]){v_b_2416}));
      v_t_2418 = heff_tag_at(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2421;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_2419}));
      v_t_2421 = heff_tag_at(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_at(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_246, v_t_2411, v_t_2418, v_implicit_249, v_t_2421});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_t_242, 0);
    V v_ft_2423 = heff_field(v_t_242, 1);
    V v_ds_2424 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2425 = heff_get(heff_dup(v_ft_2423), LBL_values);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2425)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2425, heff_dup(v_r_240)}));
    V v_t_2429 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_ft_2423), LBL_keys), heff_get(v_ft_2423, LBL_byName), v_t_2428});
    V v_xs_2430 = heff_get(heff_dup(v_ds_2424), LBL_values);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_r_240}));
    V v_t_2434 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_ds_2424), LBL_keys), heff_get(v_ds_2424, LBL_byName), v_t_2433});
    return heff_tag_at(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2422, v_t_2429, v_t_2434});
  }
  case TAG_SSum: {
    V v_vs_2435 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2436 = heff_get(heff_dup(v_vs_2435), LBL_values);
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2436)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2436, v_r_240}));
    V v_t_2442 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_vs_2435), LBL_keys), heff_get(v_vs_2435, LBL_byName), v_t_2441});
    return heff_tag_at(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2442});
  }
  case TAG_SIsTy: {
    V v_a_2443 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2444 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_a_2443}));
    return heff_tag_at(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2444});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SFixed: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonkTypeF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = heff_get(v_r_240, LBL_ty);
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = heff_get(v_r_240, LBL_el);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  V f_ = heff_get(v_r_240, LBL_ty);
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2438, v_r_240}));
}
V g_heff_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec(2, shape_el__ty, (V[]){heff_clo(g_heff_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonker(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
Clo g_heff_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_i_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_240);
    return v_rr_241;
  }
  case TAG_False: {
    V v_t_243 = heff_intAdd(heff_get(heff_dup(v_rr_241), LBL_dom), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_get(heff_dup(v_rr_241), LBL_cod), MK_INT(1LL));
    V v_t_245 = (g_map_2einsert_24s1689409319x1710080871(heff_get(heff_dup(v_rr_241), LBL_dom), heff_get(heff_dup(v_rr_241), LBL_cod), heff_get(v_rr_241, LBL_ren)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_rec(3, shape_dom__cod__ren, (V[]){v_t_243, v_t_244, v_t_245});
    v_i_240 = t_0;
    v_rr_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eiterateLift(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2elamsU_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_k_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_k_240);
    return v_body_241;
  }
  case TAG_False: {
    V v_t_243 = heff_tag(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_244 = heff_tag(TAG_SLam, 2, (V[]){v_t_243, heff_tag(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_244;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = heff_rec(6, shape_ty__sol__solStx__arity__name__span, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_arity_241, heff_get(heff_dup(v_entry_240), LBL_name), heff_get(v_entry_240, LBL_span)});
  V v_mc_245 = (g_map_2einsert_24s1689409319x1710080871(heff_get(heff_dup(v_c_243), LBL_nextMeta), v_t_244, heff_get(heff_dup(v_c_243), LBL_metas)));
  V v_t_246 = heff_intAdd(heff_get(heff_dup(v_c_243), LBL_nextMeta), MK_INT(1LL));
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_243), LBL_infos), heff_get(heff_dup(v_c_243), LBL_recovered), heff_get(heff_dup(v_c_243), LBL_poisoned), v_mc_245, v_t_246, heff_get(heff_dup(v_c_243), LBL_postponed), heff_get(heff_dup(v_c_243), LBL_trace), heff_get(v_c_243, LBL_selfKey)});
}
V g_heff_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925_entry, 2, 0};

V g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          v_t_249 = heff_intEq(v_a_246, v_a_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925(a[0], a[1]);
}
Clo g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904_entry, 2, 0};

V g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), (g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2euTyRigid_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eunify_2euTyRigid_lam0(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam0, 2, 0};
V g_heff_2eunify_2euTyRigid_lam2(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam1(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam4(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam3(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam6(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam5(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam8(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam7(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam10(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam9(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam12(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam11(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam14(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam13(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam16(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam15(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam18(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam17(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam20(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam19(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam22(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam21(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam24(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam23(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam26(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam25(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam28(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam27(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam30(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam29(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam32(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam31(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam34(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam33(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam36(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam35(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam38(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam37(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam40(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam39(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam42(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam41(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam45(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam46(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam47(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam44(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam43(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam49(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam48(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam51(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam50(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam53(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam52(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam55(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam54(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam57(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam56(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam59(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam58(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam61(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam60(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam63(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam62(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam65(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam64(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam67(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam66(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam69(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam68(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam71(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam70(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam73(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam72(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam75(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam74(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam77(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam76(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam78(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam78, 2, 0};
V g_heff_2eunify_2euTyRigid_lam80(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam79(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam82(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam81(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam84(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam83(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam86(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam85(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam88(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam87(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam90(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam89(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam92(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam91(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam94(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam93(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam96(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam95(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam98(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam97(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam99(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam99_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam99, 2, 0};
V g_heff_2eunify_2euTyRigid_lam101(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam100(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam103(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam102(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam105(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam104(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam107(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam106(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam109(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam108(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam111(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam110(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam113(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam112(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam115(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam114(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam117(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam116(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam119(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam118(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam120(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam120, 2, 0};
V g_heff_2eunify_2euTyRigid_lam122(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam121(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam124(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam123(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam126(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam125(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam128(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam127(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam130(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam129(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam132(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam131(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam134(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam133(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam136(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam135(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam138(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam137(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam140(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam139(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam142(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam141(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam143(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam143_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam143, 2, 0};
V g_heff_2eunify_2euTyRigid_lam145(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam144(V self, V *args);
Clo g_heff_2eunify_2euTyRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_entry, 8, 0};

V g_heff_2eunify_2euTyRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a_246, V v_b_247) {
top: ;
  switch (heff_tag_of(v_a_246)) {
  case TAG_VU: {
    V v_u_248 = heff_dup(heff_field(v_a_246, 0));
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_u_27_249 = heff_dup(heff_field(v_b_247, 0));
      V v_t_2410;
      switch (heff_tag_of(v_u_248)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_249)) {
        case TAG_SmallU: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        case TAG_LargeU: {
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_u_27_249);
        }
        break;
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_249)) {
        case TAG_SmallU: {
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_LargeU: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_u_27_249);
        }
        break;
      }
      default: heff_nomatch(v_u_248);
      }
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_w_240);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop_tag(v_a_246, 1);
        heff_drop_tag(v_b_247, 1);
        return ((V)&g_heff_2eunify_2euTyRigid_lam0_clo);
      }
      case TAG_False: {
        V v_t_2413 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
        V v_p_2414 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2413}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam1, 2, 2, (V[]){v_w_240, v_p_2414});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_248);
      V v_t_2425 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2426 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2425}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam3, 2, 2, (V[]){v_w_240, v_p_2426});
    }
    case TAG_VFunction: {
      heff_drop(v_u_248);
      V v_t_2437 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2438 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2437}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam5, 2, 2, (V[]){v_w_240, v_p_2438});
    }
    case TAG_VRecord: {
      heff_drop(v_u_248);
      V v_t_2448 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2449 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2448}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam7, 2, 2, (V[]){v_w_240, v_p_2449});
    }
    case TAG_VSum: {
      heff_drop(v_u_248);
      V v_t_2456 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2457 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2456}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam9, 2, 2, (V[]){v_w_240, v_p_2457});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_248);
      V v_t_2463 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2464 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2463}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam11, 2, 2, (V[]){v_w_240, v_p_2464});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_248);
      V v_t_2470 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2471 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2470}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam13, 2, 2, (V[]){v_w_240, v_p_2471});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_248);
      V v_t_2477 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2478 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2477}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam15, 2, 2, (V[]){v_w_240, v_p_2478});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_248);
      V v_t_2485 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2486 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2485}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam17, 2, 2, (V[]){v_w_240, v_p_2486});
    }
    case TAG_VFixed: {
      heff_drop(v_u_248);
      V v_t_2493 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2494 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2493}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam19, 2, 2, (V[]){v_w_240, v_p_2494});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VDecode: {
    V v_h_24100 = heff_dup(heff_field(v_a_246, 0));
    V v_sp_24101 = heff_dup(heff_field(v_a_246, 1));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24106 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24107 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24106}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam21, 2, 2, (V[]){v_w_240, v_p_24107});
    }
    case TAG_VDecode: {
      V v_h_27_24113 = heff_field(v_b_247, 0);
      V v_sp_27_24114 = heff_field(v_b_247, 1);
      heff_take_n(v_b_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop_tag(v_a_246, 5);
      return heff_tail(heff_get(v_r_243, LBL_ubare), 6, (V[]){v_g_244, v_cs_245, v_h_24100, v_sp_24101, v_h_27_24113, v_sp_27_24114});
    }
    case TAG_VFunction: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24123 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24124 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24123}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam23, 2, 2, (V[]){v_w_240, v_p_24124});
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24134 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24135 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24134}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam25, 2, 2, (V[]){v_w_240, v_p_24135});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24142 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24143 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24142}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam27, 2, 2, (V[]){v_w_240, v_p_24143});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24149 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24150 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24149}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam29, 2, 2, (V[]){v_w_240, v_p_24150});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24156 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24157 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24156}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam31, 2, 2, (V[]){v_w_240, v_p_24157});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24163 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24164 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24163}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam33, 2, 2, (V[]){v_w_240, v_p_24164});
    }
    case TAG_VPrimArray: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24171 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24172 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24171}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam35, 2, 2, (V[]){v_w_240, v_p_24172});
    }
    case TAG_VFixed: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_24100);
      heff_drop(v_sp_24101);
      V v_t_24179 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24180 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24179}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam37, 2, 2, (V[]){v_w_240, v_p_24180});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VFunction: {
    V v_level_24186 = heff_dup(heff_field(v_a_246, 0));
    V v_dom_24187 = heff_dup(heff_field(v_a_246, 1));
    V v_cod_24188 = heff_dup(heff_field(v_a_246, 2));
    V v_implicit_24189 = heff_dup(heff_field(v_a_246, 3));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24192 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24193 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24192}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam39, 2, 2, (V[]){v_w_240, v_p_24193});
    }
    case TAG_VDecode: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24204 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24205 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24204}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam41, 2, 2, (V[]){v_w_240, v_p_24205});
    }
    case TAG_VFunction: {
      V v_level_27_24211 = heff_dup(heff_field(v_b_247, 0));
      V v_dom_27_24212 = heff_dup(heff_field(v_b_247, 1));
      V v_cod_27_24213 = heff_dup(heff_field(v_b_247, 2));
      V v_implicit_27_24214 = heff_dup(heff_field(v_b_247, 3));
      V v_t_24216 = ({ V a_0 = v_level_24186; V a_1 = v_level_27_24211; V r_ = (g_heff_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_24186); heff_drop(v_level_27_24211); r_; });
      V v_t_24217;
      switch (heff_tag_of(v_t_24216)) {
      case TAG_True: {
        switch (heff_tag_of(v_implicit_24189)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24214)) {
          case TAG_Expl: {
            v_t_24217 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24217 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24217 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24214);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24214)) {
          case TAG_Expl: {
            v_t_24217 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24217 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24217 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24214);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24214)) {
          case TAG_Expl: {
            v_t_24217 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24217 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24217 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24214);
          }
          break;
        }
        default: heff_nomatch(v_implicit_24189);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_implicit_24189);
        heff_drop(v_implicit_27_24214);
        v_t_24217 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24216);
      }
      switch (heff_tag_of(v_t_24217)) {
      case TAG_True: {
        heff_drop(v_w_240);
        heff_drop(v_uf_242);
        heff_drop_tag(v_a_246, 5);
        heff_drop_tag(v_b_247, 5);
        V v_c_24218 = heff_tr(heff_apply(heff_get(heff_dup(v_r_243), LBL_uty), 4, (V[]){heff_dup(v_g_244), heff_dup(v_cs_245), heff_dup(v_dom_24187), v_dom_27_24212}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam43, 2, 7, (V[]){v_c_24218, v_cs_245, v_dom_24187, v_cod_24188, v_cod_27_24213, v_r_243, v_g_244});
      }
      case TAG_False: {
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        heff_drop(v_dom_24187);
        heff_drop(v_cod_24188);
        heff_drop(v_dom_27_24212);
        heff_drop(v_cod_27_24213);
        V v_t_24252 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
        V v_p_24253 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24252}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam48, 2, 2, (V[]){v_w_240, v_p_24253});
      }
      default: return heff_nomatch(v_t_24217);
      }
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24263 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24264 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24263}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam50, 2, 2, (V[]){v_w_240, v_p_24264});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24271 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24272 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24271}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam52, 2, 2, (V[]){v_w_240, v_p_24272});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24278 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24279 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24278}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam54, 2, 2, (V[]){v_w_240, v_p_24279});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24285 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24286 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24285}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam56, 2, 2, (V[]){v_w_240, v_p_24286});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24292 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24293 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24292}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam58, 2, 2, (V[]){v_w_240, v_p_24293});
    }
    case TAG_VPrimArray: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24300 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24301 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24300}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam60, 2, 2, (V[]){v_w_240, v_p_24301});
    }
    case TAG_VFixed: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24186);
      heff_drop(v_dom_24187);
      heff_drop(v_cod_24188);
      heff_drop(v_implicit_24189);
      V v_t_24308 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24309 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24308}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam62, 2, 2, (V[]){v_w_240, v_p_24309});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24319 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
    V v_p_24320 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24319}));
    return heff_clo(g_heff_2eunify_2euTyRigid_lam64, 2, 2, (V[]){v_w_240, v_p_24320});
  }
  case TAG_VSum: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24327 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
    V v_p_24328 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24327}));
    return heff_clo(g_heff_2eunify_2euTyRigid_lam66, 2, 2, (V[]){v_w_240, v_p_24328});
  }
  case TAG_VPrimInt: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24335 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24336 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24335}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam68, 2, 2, (V[]){v_w_240, v_p_24336});
    }
    case TAG_VDecode: {
      V v_t_24347 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24348 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24347}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam70, 2, 2, (V[]){v_w_240, v_p_24348});
    }
    case TAG_VFunction: {
      V v_t_24359 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24360 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24359}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam72, 2, 2, (V[]){v_w_240, v_p_24360});
    }
    case TAG_VRecord: {
      V v_t_24370 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24371 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24370}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam74, 2, 2, (V[]){v_w_240, v_p_24371});
    }
    case TAG_VSum: {
      V v_t_24378 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24379 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24378}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam76, 2, 2, (V[]){v_w_240, v_p_24379});
    }
    case TAG_VPrimInt: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      return ((V)&g_heff_2eunify_2euTyRigid_lam78_clo);
    }
    case TAG_VPrimFloat: {
      V v_t_24387 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24388 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24387}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam79, 2, 2, (V[]){v_w_240, v_p_24388});
    }
    case TAG_VPrimString: {
      V v_t_24394 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24395 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24394}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam81, 2, 2, (V[]){v_w_240, v_p_24395});
    }
    case TAG_VPrimArray: {
      V v_t_24402 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24403 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24402}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam83, 2, 2, (V[]){v_w_240, v_p_24403});
    }
    case TAG_VFixed: {
      V v_t_24410 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24411 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24410}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam85, 2, 2, (V[]){v_w_240, v_p_24411});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24418 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24419 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24418}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam87, 2, 2, (V[]){v_w_240, v_p_24419});
    }
    case TAG_VDecode: {
      V v_t_24430 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24431 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24430}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam89, 2, 2, (V[]){v_w_240, v_p_24431});
    }
    case TAG_VFunction: {
      V v_t_24442 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24443 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24442}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam91, 2, 2, (V[]){v_w_240, v_p_24443});
    }
    case TAG_VRecord: {
      V v_t_24453 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24454 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24453}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam93, 2, 2, (V[]){v_w_240, v_p_24454});
    }
    case TAG_VSum: {
      V v_t_24461 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24462 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24461}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam95, 2, 2, (V[]){v_w_240, v_p_24462});
    }
    case TAG_VPrimInt: {
      V v_t_24468 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24469 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24468}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam97, 2, 2, (V[]){v_w_240, v_p_24469});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      return ((V)&g_heff_2eunify_2euTyRigid_lam99_clo);
    }
    case TAG_VPrimString: {
      V v_t_24477 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24478 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24477}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam100, 2, 2, (V[]){v_w_240, v_p_24478});
    }
    case TAG_VPrimArray: {
      V v_t_24485 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24486 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24485}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam102, 2, 2, (V[]){v_w_240, v_p_24486});
    }
    case TAG_VFixed: {
      V v_t_24493 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24494 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24493}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam104, 2, 2, (V[]){v_w_240, v_p_24494});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24501 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24502 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24501}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam106, 2, 2, (V[]){v_w_240, v_p_24502});
    }
    case TAG_VDecode: {
      V v_t_24513 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24514 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24513}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam108, 2, 2, (V[]){v_w_240, v_p_24514});
    }
    case TAG_VFunction: {
      V v_t_24525 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24526 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24525}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam110, 2, 2, (V[]){v_w_240, v_p_24526});
    }
    case TAG_VRecord: {
      V v_t_24536 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24537 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24536}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam112, 2, 2, (V[]){v_w_240, v_p_24537});
    }
    case TAG_VSum: {
      V v_t_24544 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24545 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24544}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam114, 2, 2, (V[]){v_w_240, v_p_24545});
    }
    case TAG_VPrimInt: {
      V v_t_24551 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24552 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24551}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam116, 2, 2, (V[]){v_w_240, v_p_24552});
    }
    case TAG_VPrimFloat: {
      V v_t_24558 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24559 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24558}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam118, 2, 2, (V[]){v_w_240, v_p_24559});
    }
    case TAG_VPrimString: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      return ((V)&g_heff_2eunify_2euTyRigid_lam120_clo);
    }
    case TAG_VPrimArray: {
      V v_t_24568 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24569 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24568}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam121, 2, 2, (V[]){v_w_240, v_p_24569});
    }
    case TAG_VFixed: {
      V v_t_24576 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24577 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24576}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam123, 2, 2, (V[]){v_w_240, v_p_24577});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimArray: {
    V v_x_24583 = heff_dup(heff_field(v_a_246, 0));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24585 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24586 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24585}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam125, 2, 2, (V[]){v_w_240, v_p_24586});
    }
    case TAG_VDecode: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24597 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24598 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24597}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam127, 2, 2, (V[]){v_w_240, v_p_24598});
    }
    case TAG_VFunction: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24609 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24610 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24609}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam129, 2, 2, (V[]){v_w_240, v_p_24610});
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24620 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24621 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24620}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam131, 2, 2, (V[]){v_w_240, v_p_24621});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24628 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24629 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24628}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam133, 2, 2, (V[]){v_w_240, v_p_24629});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24635 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24636 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24635}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam135, 2, 2, (V[]){v_w_240, v_p_24636});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24642 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24643 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24642}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam137, 2, 2, (V[]){v_w_240, v_p_24643});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24649 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24650 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24649}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam139, 2, 2, (V[]){v_w_240, v_p_24650});
    }
    case TAG_VPrimArray: {
      V v_y_24656 = heff_field(v_b_247, 0);
      heff_take_n(v_b_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop_tag(v_a_246, 1);
      return heff_tail(heff_get(v_r_243, LBL_uty), 4, (V[]){v_g_244, v_cs_245, v_x_24583, v_y_24656});
    }
    case TAG_VFixed: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24583);
      V v_t_24658 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24659 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24658}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam141, 2, 2, (V[]){v_w_240, v_p_24659});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VFixed: {
    V v_w_24665 = heff_dup(heff_field(v_a_246, 0));
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24666 = ({ V a_0 = v_w_24665; V a_1 = v_b_247; V r_ = (g_heff_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24665); r_; });
    switch (heff_tag_of(v_t_24666)) {
    case TAG_True: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop_tag(v_a_246, 1);
      heff_drop(v_b_247);
      return ((V)&g_heff_2eunify_2euTyRigid_lam143_clo);
    }
    case TAG_False: {
      V v_t_24669 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24670 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24669}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam144, 2, 2, (V[]){v_w_240, v_p_24670});
    }
    default: return heff_nomatch(v_t_24666);
    }
  }
  default: return heff_nomatch(v_a_246);
  }
}
V g_heff_2eunify_2euTyRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euTyRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2euTyRigid_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam2(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2415), heff_get(v_hd_2415, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam2, 1, 1, (V[]){heff_dup(v_hd_2415)}), v_p_2414}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam4(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_2427), heff_get(v_hd_2427, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam4, 1, 1, (V[]){heff_dup(v_hd_2427)}), v_p_2426}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2427), LBL_malg), 1, (V[]){v_t_2430}));
  V f_ = heff_get(v_hd_2427, LBL_bind);
  args[0] = v_t_2431;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam6(V self, V *args) {
  V v_c_2441 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_2439), heff_get(v_hd_2439, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam5(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k2_2440 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam6, 1, 1, (V[]){heff_dup(v_hd_2439)}), v_p_2438}));
  V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2439), LBL_malg), 1, (V[]){v_t_2442}));
  V f_ = heff_get(v_hd_2439, LBL_bind);
  args[0] = v_t_2443;
  args[1] = v_k2_2440;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam8(V self, V *args) {
  V v_c_2452 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2452, 2, (V[]){heff_dup(v_hd_2450), heff_get(v_hd_2450, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam7(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k2_2451 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam8, 1, 1, (V[]){heff_dup(v_hd_2450)}), v_p_2449}));
  V v_t_2454 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2450), LBL_malg), 1, (V[]){v_t_2453}));
  V f_ = heff_get(v_hd_2450, LBL_bind);
  args[0] = v_t_2454;
  args[1] = v_k2_2451;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam10(V self, V *args) {
  V v_c_2460 = args[0];
  V v_hd_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2460, 2, (V[]){heff_dup(v_hd_2458), heff_get(v_hd_2458, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam9(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k2_2459 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam10, 1, 1, (V[]){heff_dup(v_hd_2458)}), v_p_2457}));
  V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2458), LBL_malg), 1, (V[]){v_t_2461}));
  V f_ = heff_get(v_hd_2458, LBL_bind);
  args[0] = v_t_2462;
  args[1] = v_k2_2459;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam12(V self, V *args) {
  V v_c_2467 = args[0];
  V v_hd_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2467, 2, (V[]){heff_dup(v_hd_2465), heff_get(v_hd_2465, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam11(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam12, 1, 1, (V[]){heff_dup(v_hd_2465)}), v_p_2464}));
  V v_t_2469 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2465), LBL_malg), 1, (V[]){v_t_2468}));
  V f_ = heff_get(v_hd_2465, LBL_bind);
  args[0] = v_t_2469;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam14(V self, V *args) {
  V v_c_2474 = args[0];
  V v_hd_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2474, 2, (V[]){heff_dup(v_hd_2472), heff_get(v_hd_2472, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam13(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k2_2473 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam14, 1, 1, (V[]){heff_dup(v_hd_2472)}), v_p_2471}));
  V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2472), LBL_malg), 1, (V[]){v_t_2475}));
  V f_ = heff_get(v_hd_2472, LBL_bind);
  args[0] = v_t_2476;
  args[1] = v_k2_2473;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam16(V self, V *args) {
  V v_c_2481 = args[0];
  V v_hd_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2481, 2, (V[]){heff_dup(v_hd_2479), heff_get(v_hd_2479, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam15(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k2_2480 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2482 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam16, 1, 1, (V[]){heff_dup(v_hd_2479)}), v_p_2478}));
  V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2479), LBL_malg), 1, (V[]){v_t_2482}));
  V f_ = heff_get(v_hd_2479, LBL_bind);
  args[0] = v_t_2483;
  args[1] = v_k2_2480;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam18(V self, V *args) {
  V v_c_2489 = args[0];
  V v_hd_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2489, 2, (V[]){heff_dup(v_hd_2487), heff_get(v_hd_2487, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam17(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k2_2488 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2486 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2490 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam18, 1, 1, (V[]){heff_dup(v_hd_2487)}), v_p_2486}));
  V v_t_2491 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2487), LBL_malg), 1, (V[]){v_t_2490}));
  V f_ = heff_get(v_hd_2487, LBL_bind);
  args[0] = v_t_2491;
  args[1] = v_k2_2488;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam20(V self, V *args) {
  V v_c_2497 = args[0];
  V v_hd_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2497, 2, (V[]){heff_dup(v_hd_2495), heff_get(v_hd_2495, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam19(V self, V *args) {
  V v_hd_2495 = args[0];
  V v_k2_2496 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2494 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2498 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam20, 1, 1, (V[]){heff_dup(v_hd_2495)}), v_p_2494}));
  V v_t_2499 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2495), LBL_malg), 1, (V[]){v_t_2498}));
  V f_ = heff_get(v_hd_2495, LBL_bind);
  args[0] = v_t_2499;
  args[1] = v_k2_2496;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam22(V self, V *args) {
  V v_c_24110 = args[0];
  V v_hd_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24110, 2, (V[]){heff_dup(v_hd_24108), heff_get(v_hd_24108, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam21(V self, V *args) {
  V v_hd_24108 = args[0];
  V v_k2_24109 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24107 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24111 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam22, 1, 1, (V[]){heff_dup(v_hd_24108)}), v_p_24107}));
  V v_t_24112 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24108), LBL_malg), 1, (V[]){v_t_24111}));
  V f_ = heff_get(v_hd_24108, LBL_bind);
  args[0] = v_t_24112;
  args[1] = v_k2_24109;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam24(V self, V *args) {
  V v_c_24127 = args[0];
  V v_hd_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24127, 2, (V[]){heff_dup(v_hd_24125), heff_get(v_hd_24125, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam23(V self, V *args) {
  V v_hd_24125 = args[0];
  V v_k2_24126 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam24, 1, 1, (V[]){heff_dup(v_hd_24125)}), v_p_24124}));
  V v_t_24129 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24125), LBL_malg), 1, (V[]){v_t_24128}));
  V f_ = heff_get(v_hd_24125, LBL_bind);
  args[0] = v_t_24129;
  args[1] = v_k2_24126;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam26(V self, V *args) {
  V v_c_24138 = args[0];
  V v_hd_24136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24138, 2, (V[]){heff_dup(v_hd_24136), heff_get(v_hd_24136, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam25(V self, V *args) {
  V v_hd_24136 = args[0];
  V v_k2_24137 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24135 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24139 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam26, 1, 1, (V[]){heff_dup(v_hd_24136)}), v_p_24135}));
  V v_t_24140 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24136), LBL_malg), 1, (V[]){v_t_24139}));
  V f_ = heff_get(v_hd_24136, LBL_bind);
  args[0] = v_t_24140;
  args[1] = v_k2_24137;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam28(V self, V *args) {
  V v_c_24146 = args[0];
  V v_hd_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24146, 2, (V[]){heff_dup(v_hd_24144), heff_get(v_hd_24144, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam27(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k2_24145 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24143 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24147 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam28, 1, 1, (V[]){heff_dup(v_hd_24144)}), v_p_24143}));
  V v_t_24148 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24144), LBL_malg), 1, (V[]){v_t_24147}));
  V f_ = heff_get(v_hd_24144, LBL_bind);
  args[0] = v_t_24148;
  args[1] = v_k2_24145;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam30(V self, V *args) {
  V v_c_24153 = args[0];
  V v_hd_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24153, 2, (V[]){heff_dup(v_hd_24151), heff_get(v_hd_24151, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam29(V self, V *args) {
  V v_hd_24151 = args[0];
  V v_k2_24152 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24150 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24154 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam30, 1, 1, (V[]){heff_dup(v_hd_24151)}), v_p_24150}));
  V v_t_24155 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24151), LBL_malg), 1, (V[]){v_t_24154}));
  V f_ = heff_get(v_hd_24151, LBL_bind);
  args[0] = v_t_24155;
  args[1] = v_k2_24152;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam32(V self, V *args) {
  V v_c_24160 = args[0];
  V v_hd_24158 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24160, 2, (V[]){heff_dup(v_hd_24158), heff_get(v_hd_24158, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam31(V self, V *args) {
  V v_hd_24158 = args[0];
  V v_k2_24159 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24157 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24161 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam32, 1, 1, (V[]){heff_dup(v_hd_24158)}), v_p_24157}));
  V v_t_24162 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24158), LBL_malg), 1, (V[]){v_t_24161}));
  V f_ = heff_get(v_hd_24158, LBL_bind);
  args[0] = v_t_24162;
  args[1] = v_k2_24159;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam34(V self, V *args) {
  V v_c_24167 = args[0];
  V v_hd_24165 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24167, 2, (V[]){heff_dup(v_hd_24165), heff_get(v_hd_24165, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam33(V self, V *args) {
  V v_hd_24165 = args[0];
  V v_k2_24166 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24164 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24168 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam34, 1, 1, (V[]){heff_dup(v_hd_24165)}), v_p_24164}));
  V v_t_24169 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24165), LBL_malg), 1, (V[]){v_t_24168}));
  V f_ = heff_get(v_hd_24165, LBL_bind);
  args[0] = v_t_24169;
  args[1] = v_k2_24166;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam36(V self, V *args) {
  V v_c_24175 = args[0];
  V v_hd_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24175, 2, (V[]){heff_dup(v_hd_24173), heff_get(v_hd_24173, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam35(V self, V *args) {
  V v_hd_24173 = args[0];
  V v_k2_24174 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24172 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24176 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam36, 1, 1, (V[]){heff_dup(v_hd_24173)}), v_p_24172}));
  V v_t_24177 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24173), LBL_malg), 1, (V[]){v_t_24176}));
  V f_ = heff_get(v_hd_24173, LBL_bind);
  args[0] = v_t_24177;
  args[1] = v_k2_24174;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam38(V self, V *args) {
  V v_c_24183 = args[0];
  V v_hd_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24183, 2, (V[]){heff_dup(v_hd_24181), heff_get(v_hd_24181, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam37(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k2_24182 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24180 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam38, 1, 1, (V[]){heff_dup(v_hd_24181)}), v_p_24180}));
  V v_t_24185 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24181), LBL_malg), 1, (V[]){v_t_24184}));
  V f_ = heff_get(v_hd_24181, LBL_bind);
  args[0] = v_t_24185;
  args[1] = v_k2_24182;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam40(V self, V *args) {
  V v_c_24196 = args[0];
  V v_hd_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24196, 2, (V[]){heff_dup(v_hd_24194), heff_get(v_hd_24194, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam39(V self, V *args) {
  V v_hd_24194 = args[0];
  V v_k2_24195 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24193 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24197 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam40, 1, 1, (V[]){heff_dup(v_hd_24194)}), v_p_24193}));
  V v_t_24198 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24194), LBL_malg), 1, (V[]){v_t_24197}));
  V f_ = heff_get(v_hd_24194, LBL_bind);
  args[0] = v_t_24198;
  args[1] = v_k2_24195;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam42(V self, V *args) {
  V v_c_24208 = args[0];
  V v_hd_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24208, 2, (V[]){heff_dup(v_hd_24206), heff_get(v_hd_24206, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam41(V self, V *args) {
  V v_hd_24206 = args[0];
  V v_k2_24207 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24205 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24209 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam42, 1, 1, (V[]){heff_dup(v_hd_24206)}), v_p_24205}));
  V v_t_24210 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24206), LBL_malg), 1, (V[]){v_t_24209}));
  V f_ = heff_get(v_hd_24206, LBL_bind);
  args[0] = v_t_24210;
  args[1] = v_k2_24207;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam45(V self, V *args) {
  V v_u_24223 = args[0];
  V v_dom_24187 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24223);
  return v_dom_24187;
}
V g_heff_2eunify_2euTyRigid_lam46(V self, V *args) {
  V v_w_24235 = args[0];
  V v_v_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24235);
  return v_v_24224;
}
V g_heff_2eunify_2euTyRigid_lam47(V self, V *args) {
  V v_w_24245 = args[0];
  V v_v_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24245);
  return v_v_24224;
}
V g_heff_2eunify_2euTyRigid_lam44(V self, V *args) {
  V v_x_24221 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_dom_24187 = heff_env(self)[1];
  V v_cod_24188 = heff_env(self)[2];
  V v_cod_27_24213 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_hd_24219 = heff_env(self)[6];
  V v_k_24220 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_24221);
  V v_t_24222 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_cs_245), LBL_len)});
  V v_v_24224 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_24222, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2euTyRigid_lam45, 1, 1, (V[]){v_dom_24187}), NTAG(TAG_Nothing)));
  V v_x_24229;
  switch (heff_tag_of(v_cod_24188)) {
  case TAG_MkClo: {
    V v_n_24225 = heff_dup(heff_field(v_cod_24188, 0));
    v_x_24229 = v_n_24225;
    break;
  }
  case TAG_CloConst: {
    v_x_24229 = ((V)&g_heff_2eunify_2euTyRigid_str0);
    break;
  }
  default: heff_nomatch(v_cod_24188);
  }
  V v_t_24230 = heff_intAdd(heff_get(heff_dup(v_cs_245), LBL_len), MK_INT(1LL));
  V v_t_24231 = heff_tag(TAG_Cons, 2, (V[]){v_x_24229, heff_get(v_cs_245, LBL_names)});
  V v_x1_24237;
  switch (heff_tag_of(v_cod_24188)) {
  case TAG_MkClo: {
    V v_vs_24233 = heff_field(v_cod_24188, 1);
    V v_body_24234 = heff_field(v_cod_24188, 2);
    heff_take_n(v_cod_24188, 6ULL, 3);
    v_x1_24237 = heff_tr(heff_apply(v_body_24234, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24233, heff_clo(g_heff_2eunify_2euTyRigid_lam46, 1, 1, (V[]){heff_dup(v_v_24224)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24236 = heff_field(v_cod_24188, 0);
    heff_take_n(v_cod_24188, 1ULL, 1);
    v_x1_24237 = v_body_24236;
    break;
  }
  default: heff_nomatch(v_cod_24188);
  }
  V v_t_24241;
  switch (heff_tag_of(v_x1_24237)) {
  case TAG_Nom: {
    V v_x_24238 = heff_field(v_x1_24237, 0);
    heff_take_n(v_x1_24237, 1ULL, 1);
    v_t_24241 = v_x_24238;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24237, 0ULL, 1);
    v_t_24241 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24240 = heff_field(v_x1_24237, 0);
    heff_take_n(v_x1_24237, 1ULL, 1);
    v_t_24241 = v_x_24240;
    break;
  }
  default: heff_nomatch(v_x1_24237);
  }
  V v_x1_24247;
  switch (heff_tag_of(v_cod_27_24213)) {
  case TAG_MkClo: {
    V v_vs_24243 = heff_field(v_cod_27_24213, 1);
    V v_body_24244 = heff_field(v_cod_27_24213, 2);
    heff_take_n(v_cod_27_24213, 6ULL, 3);
    v_x1_24247 = heff_tr(heff_apply(v_body_24244, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24243, heff_clo(g_heff_2eunify_2euTyRigid_lam47, 1, 1, (V[]){v_v_24224})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24246 = heff_field(v_cod_27_24213, 0);
    heff_take_n(v_cod_27_24213, 1ULL, 1);
    heff_drop(v_v_24224);
    v_x1_24247 = v_body_24246;
    break;
  }
  default: heff_nomatch(v_cod_27_24213);
  }
  V v_t_24251;
  switch (heff_tag_of(v_x1_24247)) {
  case TAG_Nom: {
    V v_x_24248 = heff_field(v_x1_24247, 0);
    heff_take_n(v_x1_24247, 1ULL, 1);
    v_t_24251 = v_x_24248;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24247, 0ULL, 1);
    v_t_24251 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24250 = heff_field(v_x1_24247, 0);
    heff_take_n(v_x1_24247, 1ULL, 1);
    v_t_24251 = v_x_24250;
    break;
  }
  default: heff_nomatch(v_x1_24247);
  }
  return heff_tail(heff_get(v_r_243, LBL_uty), 6, (V[]){v_g_244, heff_rec(2, shape_len__names, (V[]){v_t_24230, v_t_24231}), v_t_24241, v_t_24251, v_hd_24219, v_k_24220});
}
V g_heff_2eunify_2euTyRigid_lam43(V self, V *args) {
  V v_hd_24219 = args[0];
  V v_k_24220 = args[1];
  V v_c_24218 = heff_env(self)[0];
  V v_cs_245 = heff_env(self)[1];
  V v_dom_24187 = heff_env(self)[2];
  V v_cod_24188 = heff_env(self)[3];
  V v_cod_27_24213 = heff_env(self)[4];
  V v_r_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_24218;
  args[0] = heff_dup(v_hd_24219);
  args[1] = heff_clo(g_heff_2eunify_2euTyRigid_lam44, 1, 8, (V[]){v_cs_245, v_dom_24187, v_cod_24188, v_cod_27_24213, v_r_243, v_g_244, v_hd_24219, v_k_24220});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam49(V self, V *args) {
  V v_c_24256 = args[0];
  V v_hd_24254 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24256, 2, (V[]){heff_dup(v_hd_24254), heff_get(v_hd_24254, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam48(V self, V *args) {
  V v_hd_24254 = args[0];
  V v_k2_24255 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24253 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24257 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam49, 1, 1, (V[]){heff_dup(v_hd_24254)}), v_p_24253}));
  V v_t_24258 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24254), LBL_malg), 1, (V[]){v_t_24257}));
  V f_ = heff_get(v_hd_24254, LBL_bind);
  args[0] = v_t_24258;
  args[1] = v_k2_24255;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam51(V self, V *args) {
  V v_c_24267 = args[0];
  V v_hd_24265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24267, 2, (V[]){heff_dup(v_hd_24265), heff_get(v_hd_24265, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam50(V self, V *args) {
  V v_hd_24265 = args[0];
  V v_k2_24266 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24264 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24268 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam51, 1, 1, (V[]){heff_dup(v_hd_24265)}), v_p_24264}));
  V v_t_24269 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24265), LBL_malg), 1, (V[]){v_t_24268}));
  V f_ = heff_get(v_hd_24265, LBL_bind);
  args[0] = v_t_24269;
  args[1] = v_k2_24266;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam53(V self, V *args) {
  V v_c_24275 = args[0];
  V v_hd_24273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24275, 2, (V[]){heff_dup(v_hd_24273), heff_get(v_hd_24273, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam52(V self, V *args) {
  V v_hd_24273 = args[0];
  V v_k2_24274 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24272 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24276 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam53, 1, 1, (V[]){heff_dup(v_hd_24273)}), v_p_24272}));
  V v_t_24277 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24273), LBL_malg), 1, (V[]){v_t_24276}));
  V f_ = heff_get(v_hd_24273, LBL_bind);
  args[0] = v_t_24277;
  args[1] = v_k2_24274;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam55(V self, V *args) {
  V v_c_24282 = args[0];
  V v_hd_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24282, 2, (V[]){heff_dup(v_hd_24280), heff_get(v_hd_24280, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam54(V self, V *args) {
  V v_hd_24280 = args[0];
  V v_k2_24281 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24279 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24283 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam55, 1, 1, (V[]){heff_dup(v_hd_24280)}), v_p_24279}));
  V v_t_24284 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24280), LBL_malg), 1, (V[]){v_t_24283}));
  V f_ = heff_get(v_hd_24280, LBL_bind);
  args[0] = v_t_24284;
  args[1] = v_k2_24281;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam57(V self, V *args) {
  V v_c_24289 = args[0];
  V v_hd_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24289, 2, (V[]){heff_dup(v_hd_24287), heff_get(v_hd_24287, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam56(V self, V *args) {
  V v_hd_24287 = args[0];
  V v_k2_24288 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24286 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24290 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam57, 1, 1, (V[]){heff_dup(v_hd_24287)}), v_p_24286}));
  V v_t_24291 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24287), LBL_malg), 1, (V[]){v_t_24290}));
  V f_ = heff_get(v_hd_24287, LBL_bind);
  args[0] = v_t_24291;
  args[1] = v_k2_24288;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam59(V self, V *args) {
  V v_c_24296 = args[0];
  V v_hd_24294 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24296, 2, (V[]){heff_dup(v_hd_24294), heff_get(v_hd_24294, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam58(V self, V *args) {
  V v_hd_24294 = args[0];
  V v_k2_24295 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24293 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24297 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam59, 1, 1, (V[]){heff_dup(v_hd_24294)}), v_p_24293}));
  V v_t_24298 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24294), LBL_malg), 1, (V[]){v_t_24297}));
  V f_ = heff_get(v_hd_24294, LBL_bind);
  args[0] = v_t_24298;
  args[1] = v_k2_24295;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam61(V self, V *args) {
  V v_c_24304 = args[0];
  V v_hd_24302 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24304, 2, (V[]){heff_dup(v_hd_24302), heff_get(v_hd_24302, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam60(V self, V *args) {
  V v_hd_24302 = args[0];
  V v_k2_24303 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24301 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24305 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam61, 1, 1, (V[]){heff_dup(v_hd_24302)}), v_p_24301}));
  V v_t_24306 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24302), LBL_malg), 1, (V[]){v_t_24305}));
  V f_ = heff_get(v_hd_24302, LBL_bind);
  args[0] = v_t_24306;
  args[1] = v_k2_24303;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam63(V self, V *args) {
  V v_c_24312 = args[0];
  V v_hd_24310 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24312, 2, (V[]){heff_dup(v_hd_24310), heff_get(v_hd_24310, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam62(V self, V *args) {
  V v_hd_24310 = args[0];
  V v_k2_24311 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24309 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24313 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam63, 1, 1, (V[]){heff_dup(v_hd_24310)}), v_p_24309}));
  V v_t_24314 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24310), LBL_malg), 1, (V[]){v_t_24313}));
  V f_ = heff_get(v_hd_24310, LBL_bind);
  args[0] = v_t_24314;
  args[1] = v_k2_24311;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam65(V self, V *args) {
  V v_c_24323 = args[0];
  V v_hd_24321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24323, 2, (V[]){heff_dup(v_hd_24321), heff_get(v_hd_24321, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam64(V self, V *args) {
  V v_hd_24321 = args[0];
  V v_k2_24322 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24320 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24324 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam65, 1, 1, (V[]){heff_dup(v_hd_24321)}), v_p_24320}));
  V v_t_24325 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24321), LBL_malg), 1, (V[]){v_t_24324}));
  V f_ = heff_get(v_hd_24321, LBL_bind);
  args[0] = v_t_24325;
  args[1] = v_k2_24322;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam67(V self, V *args) {
  V v_c_24331 = args[0];
  V v_hd_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24331, 2, (V[]){heff_dup(v_hd_24329), heff_get(v_hd_24329, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam66(V self, V *args) {
  V v_hd_24329 = args[0];
  V v_k2_24330 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24328 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24332 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam67, 1, 1, (V[]){heff_dup(v_hd_24329)}), v_p_24328}));
  V v_t_24333 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24329), LBL_malg), 1, (V[]){v_t_24332}));
  V f_ = heff_get(v_hd_24329, LBL_bind);
  args[0] = v_t_24333;
  args[1] = v_k2_24330;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam69(V self, V *args) {
  V v_c_24339 = args[0];
  V v_hd_24337 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24339, 2, (V[]){heff_dup(v_hd_24337), heff_get(v_hd_24337, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam68(V self, V *args) {
  V v_hd_24337 = args[0];
  V v_k2_24338 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24336 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24340 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam69, 1, 1, (V[]){heff_dup(v_hd_24337)}), v_p_24336}));
  V v_t_24341 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24337), LBL_malg), 1, (V[]){v_t_24340}));
  V f_ = heff_get(v_hd_24337, LBL_bind);
  args[0] = v_t_24341;
  args[1] = v_k2_24338;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam71(V self, V *args) {
  V v_c_24351 = args[0];
  V v_hd_24349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24351, 2, (V[]){heff_dup(v_hd_24349), heff_get(v_hd_24349, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam70(V self, V *args) {
  V v_hd_24349 = args[0];
  V v_k2_24350 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24348 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24352 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam71, 1, 1, (V[]){heff_dup(v_hd_24349)}), v_p_24348}));
  V v_t_24353 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24349), LBL_malg), 1, (V[]){v_t_24352}));
  V f_ = heff_get(v_hd_24349, LBL_bind);
  args[0] = v_t_24353;
  args[1] = v_k2_24350;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam73(V self, V *args) {
  V v_c_24363 = args[0];
  V v_hd_24361 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24363, 2, (V[]){heff_dup(v_hd_24361), heff_get(v_hd_24361, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam72(V self, V *args) {
  V v_hd_24361 = args[0];
  V v_k2_24362 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24360 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24364 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam73, 1, 1, (V[]){heff_dup(v_hd_24361)}), v_p_24360}));
  V v_t_24365 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24361), LBL_malg), 1, (V[]){v_t_24364}));
  V f_ = heff_get(v_hd_24361, LBL_bind);
  args[0] = v_t_24365;
  args[1] = v_k2_24362;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam75(V self, V *args) {
  V v_c_24374 = args[0];
  V v_hd_24372 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24374, 2, (V[]){heff_dup(v_hd_24372), heff_get(v_hd_24372, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam74(V self, V *args) {
  V v_hd_24372 = args[0];
  V v_k2_24373 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24371 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24375 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam75, 1, 1, (V[]){heff_dup(v_hd_24372)}), v_p_24371}));
  V v_t_24376 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24372), LBL_malg), 1, (V[]){v_t_24375}));
  V f_ = heff_get(v_hd_24372, LBL_bind);
  args[0] = v_t_24376;
  args[1] = v_k2_24373;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam77(V self, V *args) {
  V v_c_24382 = args[0];
  V v_hd_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24382, 2, (V[]){heff_dup(v_hd_24380), heff_get(v_hd_24380, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam76(V self, V *args) {
  V v_hd_24380 = args[0];
  V v_k2_24381 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24379 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24383 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam77, 1, 1, (V[]){heff_dup(v_hd_24380)}), v_p_24379}));
  V v_t_24384 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24380), LBL_malg), 1, (V[]){v_t_24383}));
  V f_ = heff_get(v_hd_24380, LBL_bind);
  args[0] = v_t_24384;
  args[1] = v_k2_24381;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam78(V self, V *args) {
  V v_hd_24385 = args[0];
  V v_k_24386 = args[1];
  heff_drop(v_hd_24385);
  V f_ = v_k_24386;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam80(V self, V *args) {
  V v_c_24391 = args[0];
  V v_hd_24389 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24391, 2, (V[]){heff_dup(v_hd_24389), heff_get(v_hd_24389, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam79(V self, V *args) {
  V v_hd_24389 = args[0];
  V v_k2_24390 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24388 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24392 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam80, 1, 1, (V[]){heff_dup(v_hd_24389)}), v_p_24388}));
  V v_t_24393 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24389), LBL_malg), 1, (V[]){v_t_24392}));
  V f_ = heff_get(v_hd_24389, LBL_bind);
  args[0] = v_t_24393;
  args[1] = v_k2_24390;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam82(V self, V *args) {
  V v_c_24398 = args[0];
  V v_hd_24396 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24398, 2, (V[]){heff_dup(v_hd_24396), heff_get(v_hd_24396, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam81(V self, V *args) {
  V v_hd_24396 = args[0];
  V v_k2_24397 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24395 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24399 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam82, 1, 1, (V[]){heff_dup(v_hd_24396)}), v_p_24395}));
  V v_t_24400 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24396), LBL_malg), 1, (V[]){v_t_24399}));
  V f_ = heff_get(v_hd_24396, LBL_bind);
  args[0] = v_t_24400;
  args[1] = v_k2_24397;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam84(V self, V *args) {
  V v_c_24406 = args[0];
  V v_hd_24404 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24406, 2, (V[]){heff_dup(v_hd_24404), heff_get(v_hd_24404, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam83(V self, V *args) {
  V v_hd_24404 = args[0];
  V v_k2_24405 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24403 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24407 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam84, 1, 1, (V[]){heff_dup(v_hd_24404)}), v_p_24403}));
  V v_t_24408 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24404), LBL_malg), 1, (V[]){v_t_24407}));
  V f_ = heff_get(v_hd_24404, LBL_bind);
  args[0] = v_t_24408;
  args[1] = v_k2_24405;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam86(V self, V *args) {
  V v_c_24414 = args[0];
  V v_hd_24412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24414, 2, (V[]){heff_dup(v_hd_24412), heff_get(v_hd_24412, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam85(V self, V *args) {
  V v_hd_24412 = args[0];
  V v_k2_24413 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24415 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam86, 1, 1, (V[]){heff_dup(v_hd_24412)}), v_p_24411}));
  V v_t_24416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24412), LBL_malg), 1, (V[]){v_t_24415}));
  V f_ = heff_get(v_hd_24412, LBL_bind);
  args[0] = v_t_24416;
  args[1] = v_k2_24413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam88(V self, V *args) {
  V v_c_24422 = args[0];
  V v_hd_24420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24422, 2, (V[]){heff_dup(v_hd_24420), heff_get(v_hd_24420, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam87(V self, V *args) {
  V v_hd_24420 = args[0];
  V v_k2_24421 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24423 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam88, 1, 1, (V[]){heff_dup(v_hd_24420)}), v_p_24419}));
  V v_t_24424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24420), LBL_malg), 1, (V[]){v_t_24423}));
  V f_ = heff_get(v_hd_24420, LBL_bind);
  args[0] = v_t_24424;
  args[1] = v_k2_24421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam90(V self, V *args) {
  V v_c_24434 = args[0];
  V v_hd_24432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24434, 2, (V[]){heff_dup(v_hd_24432), heff_get(v_hd_24432, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam89(V self, V *args) {
  V v_hd_24432 = args[0];
  V v_k2_24433 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24435 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam90, 1, 1, (V[]){heff_dup(v_hd_24432)}), v_p_24431}));
  V v_t_24436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24432), LBL_malg), 1, (V[]){v_t_24435}));
  V f_ = heff_get(v_hd_24432, LBL_bind);
  args[0] = v_t_24436;
  args[1] = v_k2_24433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam92(V self, V *args) {
  V v_c_24446 = args[0];
  V v_hd_24444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24446, 2, (V[]){heff_dup(v_hd_24444), heff_get(v_hd_24444, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam91(V self, V *args) {
  V v_hd_24444 = args[0];
  V v_k2_24445 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24447 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam92, 1, 1, (V[]){heff_dup(v_hd_24444)}), v_p_24443}));
  V v_t_24448 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24444), LBL_malg), 1, (V[]){v_t_24447}));
  V f_ = heff_get(v_hd_24444, LBL_bind);
  args[0] = v_t_24448;
  args[1] = v_k2_24445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam94(V self, V *args) {
  V v_c_24457 = args[0];
  V v_hd_24455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24457, 2, (V[]){heff_dup(v_hd_24455), heff_get(v_hd_24455, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam93(V self, V *args) {
  V v_hd_24455 = args[0];
  V v_k2_24456 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24458 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam94, 1, 1, (V[]){heff_dup(v_hd_24455)}), v_p_24454}));
  V v_t_24459 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24455), LBL_malg), 1, (V[]){v_t_24458}));
  V f_ = heff_get(v_hd_24455, LBL_bind);
  args[0] = v_t_24459;
  args[1] = v_k2_24456;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam96(V self, V *args) {
  V v_c_24465 = args[0];
  V v_hd_24463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24465, 2, (V[]){heff_dup(v_hd_24463), heff_get(v_hd_24463, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam95(V self, V *args) {
  V v_hd_24463 = args[0];
  V v_k2_24464 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24466 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam96, 1, 1, (V[]){heff_dup(v_hd_24463)}), v_p_24462}));
  V v_t_24467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24463), LBL_malg), 1, (V[]){v_t_24466}));
  V f_ = heff_get(v_hd_24463, LBL_bind);
  args[0] = v_t_24467;
  args[1] = v_k2_24464;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam98(V self, V *args) {
  V v_c_24472 = args[0];
  V v_hd_24470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24472, 2, (V[]){heff_dup(v_hd_24470), heff_get(v_hd_24470, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam97(V self, V *args) {
  V v_hd_24470 = args[0];
  V v_k2_24471 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24473 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam98, 1, 1, (V[]){heff_dup(v_hd_24470)}), v_p_24469}));
  V v_t_24474 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24470), LBL_malg), 1, (V[]){v_t_24473}));
  V f_ = heff_get(v_hd_24470, LBL_bind);
  args[0] = v_t_24474;
  args[1] = v_k2_24471;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam99(V self, V *args) {
  V v_hd_24475 = args[0];
  V v_k_24476 = args[1];
  heff_drop(v_hd_24475);
  V f_ = v_k_24476;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam101(V self, V *args) {
  V v_c_24481 = args[0];
  V v_hd_24479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24481, 2, (V[]){heff_dup(v_hd_24479), heff_get(v_hd_24479, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam100(V self, V *args) {
  V v_hd_24479 = args[0];
  V v_k2_24480 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24482 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam101, 1, 1, (V[]){heff_dup(v_hd_24479)}), v_p_24478}));
  V v_t_24483 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24479), LBL_malg), 1, (V[]){v_t_24482}));
  V f_ = heff_get(v_hd_24479, LBL_bind);
  args[0] = v_t_24483;
  args[1] = v_k2_24480;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam103(V self, V *args) {
  V v_c_24489 = args[0];
  V v_hd_24487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24489, 2, (V[]){heff_dup(v_hd_24487), heff_get(v_hd_24487, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam102(V self, V *args) {
  V v_hd_24487 = args[0];
  V v_k2_24488 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24486 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24490 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam103, 1, 1, (V[]){heff_dup(v_hd_24487)}), v_p_24486}));
  V v_t_24491 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24487), LBL_malg), 1, (V[]){v_t_24490}));
  V f_ = heff_get(v_hd_24487, LBL_bind);
  args[0] = v_t_24491;
  args[1] = v_k2_24488;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam105(V self, V *args) {
  V v_c_24497 = args[0];
  V v_hd_24495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24497, 2, (V[]){heff_dup(v_hd_24495), heff_get(v_hd_24495, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam104(V self, V *args) {
  V v_hd_24495 = args[0];
  V v_k2_24496 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24494 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24498 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam105, 1, 1, (V[]){heff_dup(v_hd_24495)}), v_p_24494}));
  V v_t_24499 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24495), LBL_malg), 1, (V[]){v_t_24498}));
  V f_ = heff_get(v_hd_24495, LBL_bind);
  args[0] = v_t_24499;
  args[1] = v_k2_24496;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam107(V self, V *args) {
  V v_c_24505 = args[0];
  V v_hd_24503 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24505, 2, (V[]){heff_dup(v_hd_24503), heff_get(v_hd_24503, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam106(V self, V *args) {
  V v_hd_24503 = args[0];
  V v_k2_24504 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24502 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24506 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam107, 1, 1, (V[]){heff_dup(v_hd_24503)}), v_p_24502}));
  V v_t_24507 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24503), LBL_malg), 1, (V[]){v_t_24506}));
  V f_ = heff_get(v_hd_24503, LBL_bind);
  args[0] = v_t_24507;
  args[1] = v_k2_24504;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam109(V self, V *args) {
  V v_c_24517 = args[0];
  V v_hd_24515 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24517, 2, (V[]){heff_dup(v_hd_24515), heff_get(v_hd_24515, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam108(V self, V *args) {
  V v_hd_24515 = args[0];
  V v_k2_24516 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24514 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24518 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam109, 1, 1, (V[]){heff_dup(v_hd_24515)}), v_p_24514}));
  V v_t_24519 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24515), LBL_malg), 1, (V[]){v_t_24518}));
  V f_ = heff_get(v_hd_24515, LBL_bind);
  args[0] = v_t_24519;
  args[1] = v_k2_24516;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam111(V self, V *args) {
  V v_c_24529 = args[0];
  V v_hd_24527 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24529, 2, (V[]){heff_dup(v_hd_24527), heff_get(v_hd_24527, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam110(V self, V *args) {
  V v_hd_24527 = args[0];
  V v_k2_24528 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24526 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24530 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam111, 1, 1, (V[]){heff_dup(v_hd_24527)}), v_p_24526}));
  V v_t_24531 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24527), LBL_malg), 1, (V[]){v_t_24530}));
  V f_ = heff_get(v_hd_24527, LBL_bind);
  args[0] = v_t_24531;
  args[1] = v_k2_24528;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam113(V self, V *args) {
  V v_c_24540 = args[0];
  V v_hd_24538 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24540, 2, (V[]){heff_dup(v_hd_24538), heff_get(v_hd_24538, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam112(V self, V *args) {
  V v_hd_24538 = args[0];
  V v_k2_24539 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24537 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24541 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam113, 1, 1, (V[]){heff_dup(v_hd_24538)}), v_p_24537}));
  V v_t_24542 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24538), LBL_malg), 1, (V[]){v_t_24541}));
  V f_ = heff_get(v_hd_24538, LBL_bind);
  args[0] = v_t_24542;
  args[1] = v_k2_24539;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam115(V self, V *args) {
  V v_c_24548 = args[0];
  V v_hd_24546 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24548, 2, (V[]){heff_dup(v_hd_24546), heff_get(v_hd_24546, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam114(V self, V *args) {
  V v_hd_24546 = args[0];
  V v_k2_24547 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24545 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24549 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam115, 1, 1, (V[]){heff_dup(v_hd_24546)}), v_p_24545}));
  V v_t_24550 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24546), LBL_malg), 1, (V[]){v_t_24549}));
  V f_ = heff_get(v_hd_24546, LBL_bind);
  args[0] = v_t_24550;
  args[1] = v_k2_24547;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam117(V self, V *args) {
  V v_c_24555 = args[0];
  V v_hd_24553 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24555, 2, (V[]){heff_dup(v_hd_24553), heff_get(v_hd_24553, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam116(V self, V *args) {
  V v_hd_24553 = args[0];
  V v_k2_24554 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24552 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24556 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam117, 1, 1, (V[]){heff_dup(v_hd_24553)}), v_p_24552}));
  V v_t_24557 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24553), LBL_malg), 1, (V[]){v_t_24556}));
  V f_ = heff_get(v_hd_24553, LBL_bind);
  args[0] = v_t_24557;
  args[1] = v_k2_24554;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam119(V self, V *args) {
  V v_c_24562 = args[0];
  V v_hd_24560 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24562, 2, (V[]){heff_dup(v_hd_24560), heff_get(v_hd_24560, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam118(V self, V *args) {
  V v_hd_24560 = args[0];
  V v_k2_24561 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24559 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24563 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam119, 1, 1, (V[]){heff_dup(v_hd_24560)}), v_p_24559}));
  V v_t_24564 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24560), LBL_malg), 1, (V[]){v_t_24563}));
  V f_ = heff_get(v_hd_24560, LBL_bind);
  args[0] = v_t_24564;
  args[1] = v_k2_24561;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam120(V self, V *args) {
  V v_hd_24565 = args[0];
  V v_k_24566 = args[1];
  heff_drop(v_hd_24565);
  V f_ = v_k_24566;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam122(V self, V *args) {
  V v_c_24572 = args[0];
  V v_hd_24570 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24572, 2, (V[]){heff_dup(v_hd_24570), heff_get(v_hd_24570, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam121(V self, V *args) {
  V v_hd_24570 = args[0];
  V v_k2_24571 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24569 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24573 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam122, 1, 1, (V[]){heff_dup(v_hd_24570)}), v_p_24569}));
  V v_t_24574 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24570), LBL_malg), 1, (V[]){v_t_24573}));
  V f_ = heff_get(v_hd_24570, LBL_bind);
  args[0] = v_t_24574;
  args[1] = v_k2_24571;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam124(V self, V *args) {
  V v_c_24580 = args[0];
  V v_hd_24578 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24580, 2, (V[]){heff_dup(v_hd_24578), heff_get(v_hd_24578, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam123(V self, V *args) {
  V v_hd_24578 = args[0];
  V v_k2_24579 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24577 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24581 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam124, 1, 1, (V[]){heff_dup(v_hd_24578)}), v_p_24577}));
  V v_t_24582 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24578), LBL_malg), 1, (V[]){v_t_24581}));
  V f_ = heff_get(v_hd_24578, LBL_bind);
  args[0] = v_t_24582;
  args[1] = v_k2_24579;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam126(V self, V *args) {
  V v_c_24589 = args[0];
  V v_hd_24587 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24589, 2, (V[]){heff_dup(v_hd_24587), heff_get(v_hd_24587, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam125(V self, V *args) {
  V v_hd_24587 = args[0];
  V v_k2_24588 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24586 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24590 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam126, 1, 1, (V[]){heff_dup(v_hd_24587)}), v_p_24586}));
  V v_t_24591 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24587), LBL_malg), 1, (V[]){v_t_24590}));
  V f_ = heff_get(v_hd_24587, LBL_bind);
  args[0] = v_t_24591;
  args[1] = v_k2_24588;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam128(V self, V *args) {
  V v_c_24601 = args[0];
  V v_hd_24599 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24601, 2, (V[]){heff_dup(v_hd_24599), heff_get(v_hd_24599, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam127(V self, V *args) {
  V v_hd_24599 = args[0];
  V v_k2_24600 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24598 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24602 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam128, 1, 1, (V[]){heff_dup(v_hd_24599)}), v_p_24598}));
  V v_t_24603 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24599), LBL_malg), 1, (V[]){v_t_24602}));
  V f_ = heff_get(v_hd_24599, LBL_bind);
  args[0] = v_t_24603;
  args[1] = v_k2_24600;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam130(V self, V *args) {
  V v_c_24613 = args[0];
  V v_hd_24611 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24613, 2, (V[]){heff_dup(v_hd_24611), heff_get(v_hd_24611, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam129(V self, V *args) {
  V v_hd_24611 = args[0];
  V v_k2_24612 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24610 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24614 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam130, 1, 1, (V[]){heff_dup(v_hd_24611)}), v_p_24610}));
  V v_t_24615 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24611), LBL_malg), 1, (V[]){v_t_24614}));
  V f_ = heff_get(v_hd_24611, LBL_bind);
  args[0] = v_t_24615;
  args[1] = v_k2_24612;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam132(V self, V *args) {
  V v_c_24624 = args[0];
  V v_hd_24622 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24624, 2, (V[]){heff_dup(v_hd_24622), heff_get(v_hd_24622, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam131(V self, V *args) {
  V v_hd_24622 = args[0];
  V v_k2_24623 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24621 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24625 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam132, 1, 1, (V[]){heff_dup(v_hd_24622)}), v_p_24621}));
  V v_t_24626 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24622), LBL_malg), 1, (V[]){v_t_24625}));
  V f_ = heff_get(v_hd_24622, LBL_bind);
  args[0] = v_t_24626;
  args[1] = v_k2_24623;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam134(V self, V *args) {
  V v_c_24632 = args[0];
  V v_hd_24630 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24632, 2, (V[]){heff_dup(v_hd_24630), heff_get(v_hd_24630, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam133(V self, V *args) {
  V v_hd_24630 = args[0];
  V v_k2_24631 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24629 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24633 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam134, 1, 1, (V[]){heff_dup(v_hd_24630)}), v_p_24629}));
  V v_t_24634 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24630), LBL_malg), 1, (V[]){v_t_24633}));
  V f_ = heff_get(v_hd_24630, LBL_bind);
  args[0] = v_t_24634;
  args[1] = v_k2_24631;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam136(V self, V *args) {
  V v_c_24639 = args[0];
  V v_hd_24637 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24639, 2, (V[]){heff_dup(v_hd_24637), heff_get(v_hd_24637, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam135(V self, V *args) {
  V v_hd_24637 = args[0];
  V v_k2_24638 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24636 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24640 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam136, 1, 1, (V[]){heff_dup(v_hd_24637)}), v_p_24636}));
  V v_t_24641 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24637), LBL_malg), 1, (V[]){v_t_24640}));
  V f_ = heff_get(v_hd_24637, LBL_bind);
  args[0] = v_t_24641;
  args[1] = v_k2_24638;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam138(V self, V *args) {
  V v_c_24646 = args[0];
  V v_hd_24644 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24646, 2, (V[]){heff_dup(v_hd_24644), heff_get(v_hd_24644, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam137(V self, V *args) {
  V v_hd_24644 = args[0];
  V v_k2_24645 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24643 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24647 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam138, 1, 1, (V[]){heff_dup(v_hd_24644)}), v_p_24643}));
  V v_t_24648 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24644), LBL_malg), 1, (V[]){v_t_24647}));
  V f_ = heff_get(v_hd_24644, LBL_bind);
  args[0] = v_t_24648;
  args[1] = v_k2_24645;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam140(V self, V *args) {
  V v_c_24653 = args[0];
  V v_hd_24651 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24653, 2, (V[]){heff_dup(v_hd_24651), heff_get(v_hd_24651, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam139(V self, V *args) {
  V v_hd_24651 = args[0];
  V v_k2_24652 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24650 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24654 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam140, 1, 1, (V[]){heff_dup(v_hd_24651)}), v_p_24650}));
  V v_t_24655 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24651), LBL_malg), 1, (V[]){v_t_24654}));
  V f_ = heff_get(v_hd_24651, LBL_bind);
  args[0] = v_t_24655;
  args[1] = v_k2_24652;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam142(V self, V *args) {
  V v_c_24662 = args[0];
  V v_hd_24660 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24662, 2, (V[]){heff_dup(v_hd_24660), heff_get(v_hd_24660, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam141(V self, V *args) {
  V v_hd_24660 = args[0];
  V v_k2_24661 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24659 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24663 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam142, 1, 1, (V[]){heff_dup(v_hd_24660)}), v_p_24659}));
  V v_t_24664 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24660), LBL_malg), 1, (V[]){v_t_24663}));
  V f_ = heff_get(v_hd_24660, LBL_bind);
  args[0] = v_t_24664;
  args[1] = v_k2_24661;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam143(V self, V *args) {
  V v_hd_24667 = args[0];
  V v_k_24668 = args[1];
  heff_drop(v_hd_24667);
  V f_ = v_k_24668;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam145(V self, V *args) {
  V v_c_24673 = args[0];
  V v_hd_24671 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24673, 2, (V[]){heff_dup(v_hd_24671), heff_get(v_hd_24671, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam144(V self, V *args) {
  V v_hd_24671 = args[0];
  V v_k2_24672 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24670 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24674 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam145, 1, 1, (V[]){heff_dup(v_hd_24671)}), v_p_24670}));
  V v_t_24675 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24671), LBL_malg), 1, (V[]){v_t_24674}));
  V f_ = heff_get(v_hd_24671, LBL_bind);
  args[0] = v_t_24675;
  args[1] = v_k2_24672;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2euElRigid_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eunify_2euElRigid_lam3(V self, V *args);
V g_heff_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eunify_2euElRigid_lam5(V self, V *args);
V g_heff_2eunify_2euElRigid_lam4(V self, V *args);
V g_heff_2eunify_2euElRigid_lam7(V self, V *args);
V g_heff_2eunify_2euElRigid_lam6(V self, V *args);
V g_heff_2eunify_2euElRigid_lam9(V self, V *args);
V g_heff_2eunify_2euElRigid_lam8(V self, V *args);
V g_heff_2eunify_2euElRigid_lam11(V self, V *args);
V g_heff_2eunify_2euElRigid_lam10(V self, V *args);
V g_heff_2eunify_2euElRigid_lam13(V self, V *args);
V g_heff_2eunify_2euElRigid_lam12(V self, V *args);
V g_heff_2eunify_2euElRigid_lam15(V self, V *args);
V g_heff_2eunify_2euElRigid_lam14(V self, V *args);
V g_heff_2eunify_2euElRigid_lam17(V self, V *args);
V g_heff_2eunify_2euElRigid_lam16(V self, V *args);
V g_heff_2eunify_2euElRigid_lam19(V self, V *args);
V g_heff_2eunify_2euElRigid_lam18(V self, V *args);
V g_heff_2eunify_2euElRigid_lam20(V self, V *args);
V g_heff_2eunify_2euElRigid_lam21(V self, V *args);
V g_heff_2eunify_2euElRigid_lam22(V self, V *args);
V g_heff_2eunify_2euElRigid_lam24(V self, V *args);
V g_heff_2eunify_2euElRigid_lam23(V self, V *args);
V g_heff_2eunify_2euElRigid_lam26(V self, V *args);
V g_heff_2eunify_2euElRigid_lam25(V self, V *args);
V g_heff_2eunify_2euElRigid_lam28(V self, V *args);
V g_heff_2eunify_2euElRigid_lam27(V self, V *args);
V g_heff_2eunify_2euElRigid_lam30(V self, V *args);
V g_heff_2eunify_2euElRigid_lam29(V self, V *args);
V g_heff_2eunify_2euElRigid_lam32(V self, V *args);
V g_heff_2eunify_2euElRigid_lam31(V self, V *args);
V g_heff_2eunify_2euElRigid_lam33(V self, V *args);
V g_heff_2eunify_2euElRigid_lam35(V self, V *args);
V g_heff_2eunify_2euElRigid_lam34(V self, V *args);
V g_heff_2eunify_2euElRigid_lam36(V self, V *args); static Clo g_heff_2eunify_2euElRigid_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euElRigid_lam36, 2, 0};
Clo g_heff_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euElRigid_entry, 10, 0};

V g_heff_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_ca_246, V v_cb_247, V v_a_248, V v_b_249) {
top: ;
  switch (heff_tag_of(v_ca_246)) {
  case TAG_VNeu: {
    V v_h_2410 = heff_field(v_ca_246, 0);
    V v_sp_2411 = heff_field(v_ca_246, 1);
    heff_take_n(v_ca_246, 3ULL, 5);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2415 = heff_field(v_cb_247, 0);
      V v_sp_27_2416 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get(v_r_243, LBL_ubare), 6, (V[]){v_g_244, v_cs_245, v_h_2410, v_sp_2411, v_h_27_2415, v_sp_27_2416});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2421 = heff_tag_at(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2422 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2421}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam0, 2, 2, (V[]){v_w_240, v_p_2422});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2430 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2431 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2430}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam2, 2, 2, (V[]){v_w_240, v_p_2431});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2438 = heff_tag_at(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2439 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2438}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam4, 2, 2, (V[]){v_w_240, v_p_2439});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2445 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2446 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2445}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam6, 2, 2, (V[]){v_w_240, v_p_2446});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2452 = heff_field(v_ca_246, 0);
    V v_ru_24ca_246_24VCode = heff_take_reuse_n(v_ca_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2458 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2459 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2458}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam8, 2, 2, (V[]){v_w_240, v_p_2459});
    }
    case TAG_VCode: {
      V v_t_27_2465 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24ca_246_24VCode, 1);
      return heff_tail(heff_get(v_r_243, LBL_uty), 4, (V[]){v_g_244, v_cs_245, v_t_2452, v_t_27_2465});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2468 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2469 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2468}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam10, 2, 2, (V[]){v_w_240, v_p_2469});
    }
    case TAG_VCons: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2476 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2477 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2476}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam12, 2, 2, (V[]){v_w_240, v_p_2477});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2483 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2484 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2483}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam14, 2, 2, (V[]){v_w_240, v_p_2484});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2490 = heff_field(v_ca_246, 0);
    V v_c_2491 = heff_field(v_ca_246, 1);
    V v_ru_24ca_246_24VLam = heff_take_reuse_n(v_ca_246, 3ULL, 2);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_2497 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2498 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2497}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam16, 2, 2, (V[]){v_w_240, v_p_2498});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_24105 = heff_tag_at(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24106 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24105}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam18, 2, 2, (V[]){v_w_240, v_p_24106});
    }
    case TAG_VLam: {
      V v_c_27_24113 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 2ULL, 2);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_24114 = heff_tr(heff_apply(v_d_2490, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_24115 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_24114)));
      V v_a_24127;
      switch (heff_tag_of(v_t_24115)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_24118 = heff_field(v_t_24115, 1);
        heff_take_n(v_t_24115, 2ULL, 4);
        heff_drop(v_t_24114);
        v_a_24127 = v_dom_24118;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_24115, 0ULL, 3);
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeInt: {
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeFloat: {
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeString: {
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24127 = v_t_24114;
        break;
      }
      case TAG_NoRules: {
        v_a_24127 = v_t_24114;
        break;
      }
      default: heff_nomatch(v_t_24115);
      }
      V v_t_24128 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_cs_245), LBL_len)});
      V v_v_24130 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_24128, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2euElRigid_lam20, 1, 1, (V[]){v_a_24127}), NTAG(TAG_Nothing)));
      V v_x_24135;
      switch (heff_tag_of(v_c_2491)) {
      case TAG_MkClo: {
        V v_n_24131 = heff_dup(heff_field(v_c_2491, 0));
        v_x_24135 = v_n_24131;
        break;
      }
      case TAG_CloConst: {
        v_x_24135 = ((V)&g_heff_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2491);
      }
      V v_t_24136 = heff_intAdd(heff_get(heff_dup(v_cs_245), LBL_len), MK_INT(1LL));
      V v_t_24137 = heff_tag_at(v_ru_24ca_246_24VLam, TAG_Cons, 2, (V[]){v_x_24135, heff_get(v_cs_245, LBL_names)});
      V v_x1_24143;
      switch (heff_tag_of(v_c_2491)) {
      case TAG_MkClo: {
        V v_vs_24139 = heff_field(v_c_2491, 1);
        V v_body_24140 = heff_field(v_c_2491, 2);
        heff_take_n(v_c_2491, 6ULL, 3);
        v_x1_24143 = heff_tr(heff_apply(v_body_24140, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24139, heff_clo(g_heff_2eunify_2euElRigid_lam21, 1, 1, (V[]){heff_dup(v_v_24130)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24142 = heff_field(v_c_2491, 0);
        heff_take_n(v_c_2491, 1ULL, 1);
        v_x1_24143 = v_body_24142;
        break;
      }
      default: heff_nomatch(v_c_2491);
      }
      V v_t_24147;
      switch (heff_tag_of(v_x1_24143)) {
      case TAG_Nom: {
        V v_x_24144 = heff_field(v_x1_24143, 0);
        heff_take_n(v_x1_24143, 1ULL, 1);
        v_t_24147 = v_x_24144;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24143, 0ULL, 1);
        v_t_24147 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24146 = heff_field(v_x1_24143, 0);
        heff_take_n(v_x1_24143, 1ULL, 1);
        v_t_24147 = v_x_24146;
        break;
      }
      default: heff_nomatch(v_x1_24143);
      }
      V v_x1_24153;
      switch (heff_tag_of(v_c_27_24113)) {
      case TAG_MkClo: {
        V v_vs_24149 = heff_field(v_c_27_24113, 1);
        V v_body_24150 = heff_field(v_c_27_24113, 2);
        heff_take_n(v_c_27_24113, 6ULL, 3);
        v_x1_24153 = heff_tr(heff_apply(v_body_24150, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24149, heff_clo(g_heff_2eunify_2euElRigid_lam22, 1, 1, (V[]){v_v_24130})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24152 = heff_field(v_c_27_24113, 0);
        heff_take_n(v_c_27_24113, 1ULL, 1);
        heff_drop(v_v_24130);
        v_x1_24153 = v_body_24152;
        break;
      }
      default: heff_nomatch(v_c_27_24113);
      }
      V v_t_24157;
      switch (heff_tag_of(v_x1_24153)) {
      case TAG_Nom: {
        V v_x_24154 = heff_field(v_x1_24153, 0);
        heff_take_n(v_x1_24153, 1ULL, 1);
        v_t_24157 = v_x_24154;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24153, 0ULL, 1);
        v_t_24157 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24156 = heff_field(v_x1_24153, 0);
        heff_take_n(v_x1_24153, 1ULL, 1);
        v_t_24157 = v_x_24156;
        break;
      }
      default: heff_nomatch(v_x1_24153);
      }
      return heff_tail(heff_get(v_r_243, LBL_uel), 4, (V[]){v_g_244, heff_rec(2, shape_len__names, (V[]){v_t_24136, v_t_24137}), v_t_24147, v_t_24157});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_24159 = heff_tag_at(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24160 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24159}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam23, 2, 2, (V[]){v_w_240, v_p_24160});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_24166 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24167 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24166}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam25, 2, 2, (V[]){v_w_240, v_p_24167});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24173 = heff_field(v_ca_246, 0);
    V v_ru_24ca_246_24VCons = heff_take_reuse_n(v_ca_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24173);
      V v_t_24179 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24180 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24179}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam27, 2, 2, (V[]){v_w_240, v_p_24180});
    }
    case TAG_VCode: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24173);
      V v_t_24187 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24188 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24187}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam29, 2, 2, (V[]){v_w_240, v_p_24188});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24173);
      V v_t_24196 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24197 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24196}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam31, 2, 2, (V[]){v_w_240, v_p_24197});
    }
    case TAG_VCons: {
      V v_d_27_24203 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24ca_246_24VCons, 1);
      V v_t_24204 = heff_arrayToList(heff_get(v_d_24173, LBL_values));
      V v_t_24205 = heff_arrayToList(heff_get(v_d_27_24203, LBL_values));
      V v_t_24206 = (g_heff_2eunify_2ezipL(v_t_24204, v_t_24205));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24206; V a_4 = heff_clo(g_heff_2eunify_2euElRigid_lam33, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V r_ = (g_heff_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24206); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24173);
      V v_t_24218 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24219 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24218}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam34, 2, 2, (V[]){v_w_240, v_p_24219});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    heff_drop(v_cs_245);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    return ((V)&g_heff_2eunify_2euElRigid_lam36_clo);
  }
  default: return heff_nomatch(v_ca_246);
  }
}
V g_heff_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euElRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_2423), heff_get(v_hd_2423, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_hd_2423)}), v_p_2422}));
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_c_2434 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_2432), heff_get(v_hd_2432, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam3, 1, 1, (V[]){heff_dup(v_hd_2432)}), v_p_2431}));
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2432), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2432, LBL_bind);
  args[0] = v_t_2436;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam5(V self, V *args) {
  V v_c_2442 = args[0];
  V v_hd_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_2440), heff_get(v_hd_2440, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam5, 1, 1, (V[]){heff_dup(v_hd_2440)}), v_p_2439}));
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2440), LBL_malg), 1, (V[]){v_t_2443}));
  V f_ = heff_get(v_hd_2440, LBL_bind);
  args[0] = v_t_2444;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam7(V self, V *args) {
  V v_c_2449 = args[0];
  V v_hd_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2449, 2, (V[]){heff_dup(v_hd_2447), heff_get(v_hd_2447, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam7, 1, 1, (V[]){heff_dup(v_hd_2447)}), v_p_2446}));
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2450}));
  V f_ = heff_get(v_hd_2447, LBL_bind);
  args[0] = v_t_2451;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam9(V self, V *args) {
  V v_c_2462 = args[0];
  V v_hd_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2462, 2, (V[]){heff_dup(v_hd_2460), heff_get(v_hd_2460, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam8(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k2_2461 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam9, 1, 1, (V[]){heff_dup(v_hd_2460)}), v_p_2459}));
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2460), LBL_malg), 1, (V[]){v_t_2463}));
  V f_ = heff_get(v_hd_2460, LBL_bind);
  args[0] = v_t_2464;
  args[1] = v_k2_2461;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam11(V self, V *args) {
  V v_c_2472 = args[0];
  V v_hd_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2472, 2, (V[]){heff_dup(v_hd_2470), heff_get(v_hd_2470, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam10(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2473 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam11, 1, 1, (V[]){heff_dup(v_hd_2470)}), v_p_2469}));
  V v_t_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2470), LBL_malg), 1, (V[]){v_t_2473}));
  V f_ = heff_get(v_hd_2470, LBL_bind);
  args[0] = v_t_2474;
  args[1] = v_k2_2471;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam13(V self, V *args) {
  V v_c_2480 = args[0];
  V v_hd_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2480, 2, (V[]){heff_dup(v_hd_2478), heff_get(v_hd_2478, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam12(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam13, 1, 1, (V[]){heff_dup(v_hd_2478)}), v_p_2477}));
  V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2478), LBL_malg), 1, (V[]){v_t_2481}));
  V f_ = heff_get(v_hd_2478, LBL_bind);
  args[0] = v_t_2482;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam15(V self, V *args) {
  V v_c_2487 = args[0];
  V v_hd_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2487, 2, (V[]){heff_dup(v_hd_2485), heff_get(v_hd_2485, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam14(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k2_2486 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2484 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2488 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam15, 1, 1, (V[]){heff_dup(v_hd_2485)}), v_p_2484}));
  V v_t_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2485), LBL_malg), 1, (V[]){v_t_2488}));
  V f_ = heff_get(v_hd_2485, LBL_bind);
  args[0] = v_t_2489;
  args[1] = v_k2_2486;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam17(V self, V *args) {
  V v_c_24101 = args[0];
  V v_hd_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_2499), heff_get(v_hd_2499, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam16(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k2_24100 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24102 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam17, 1, 1, (V[]){heff_dup(v_hd_2499)}), v_p_2498}));
  V v_t_24103 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2499), LBL_malg), 1, (V[]){v_t_24102}));
  V f_ = heff_get(v_hd_2499, LBL_bind);
  args[0] = v_t_24103;
  args[1] = v_k2_24100;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam19(V self, V *args) {
  V v_c_24109 = args[0];
  V v_hd_24107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24109, 2, (V[]){heff_dup(v_hd_24107), heff_get(v_hd_24107, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam18(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k2_24108 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24106 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24110 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam19, 1, 1, (V[]){heff_dup(v_hd_24107)}), v_p_24106}));
  V v_t_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24107), LBL_malg), 1, (V[]){v_t_24110}));
  V f_ = heff_get(v_hd_24107, LBL_bind);
  args[0] = v_t_24111;
  args[1] = v_k2_24108;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam20(V self, V *args) {
  V v_u_24129 = args[0];
  V v_a_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24129);
  return v_a_24127;
}
V g_heff_2eunify_2euElRigid_lam21(V self, V *args) {
  V v_w_24141 = args[0];
  V v_v_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24141);
  return v_v_24130;
}
V g_heff_2eunify_2euElRigid_lam22(V self, V *args) {
  V v_w_24151 = args[0];
  V v_v_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24151);
  return v_v_24130;
}
V g_heff_2eunify_2euElRigid_lam24(V self, V *args) {
  V v_c_24163 = args[0];
  V v_hd_24161 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24163, 2, (V[]){heff_dup(v_hd_24161), heff_get(v_hd_24161, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam23(V self, V *args) {
  V v_hd_24161 = args[0];
  V v_k2_24162 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24160 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24164 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam24, 1, 1, (V[]){heff_dup(v_hd_24161)}), v_p_24160}));
  V v_t_24165 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24161), LBL_malg), 1, (V[]){v_t_24164}));
  V f_ = heff_get(v_hd_24161, LBL_bind);
  args[0] = v_t_24165;
  args[1] = v_k2_24162;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam26(V self, V *args) {
  V v_c_24170 = args[0];
  V v_hd_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24170, 2, (V[]){heff_dup(v_hd_24168), heff_get(v_hd_24168, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam25(V self, V *args) {
  V v_hd_24168 = args[0];
  V v_k2_24169 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24167 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24171 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam26, 1, 1, (V[]){heff_dup(v_hd_24168)}), v_p_24167}));
  V v_t_24172 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24168), LBL_malg), 1, (V[]){v_t_24171}));
  V f_ = heff_get(v_hd_24168, LBL_bind);
  args[0] = v_t_24172;
  args[1] = v_k2_24169;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam28(V self, V *args) {
  V v_c_24183 = args[0];
  V v_hd_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24183, 2, (V[]){heff_dup(v_hd_24181), heff_get(v_hd_24181, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam27(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k2_24182 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24180 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam28, 1, 1, (V[]){heff_dup(v_hd_24181)}), v_p_24180}));
  V v_t_24185 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24181), LBL_malg), 1, (V[]){v_t_24184}));
  V f_ = heff_get(v_hd_24181, LBL_bind);
  args[0] = v_t_24185;
  args[1] = v_k2_24182;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam30(V self, V *args) {
  V v_c_24191 = args[0];
  V v_hd_24189 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24191, 2, (V[]){heff_dup(v_hd_24189), heff_get(v_hd_24189, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam29(V self, V *args) {
  V v_hd_24189 = args[0];
  V v_k2_24190 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24188 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24192 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam30, 1, 1, (V[]){heff_dup(v_hd_24189)}), v_p_24188}));
  V v_t_24193 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24189), LBL_malg), 1, (V[]){v_t_24192}));
  V f_ = heff_get(v_hd_24189, LBL_bind);
  args[0] = v_t_24193;
  args[1] = v_k2_24190;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam32(V self, V *args) {
  V v_c_24200 = args[0];
  V v_hd_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24200, 2, (V[]){heff_dup(v_hd_24198), heff_get(v_hd_24198, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam31(V self, V *args) {
  V v_hd_24198 = args[0];
  V v_k2_24199 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24197 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24201 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam32, 1, 1, (V[]){heff_dup(v_hd_24198)}), v_p_24197}));
  V v_t_24202 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24198), LBL_malg), 1, (V[]){v_t_24201}));
  V f_ = heff_get(v_hd_24198, LBL_bind);
  args[0] = v_t_24202;
  args[1] = v_k2_24199;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam33(V self, V *args) {
  V v_p_24207 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  V v_cs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_24207)) {
  case TAG_MkPair: {
    V v_x_24208 = heff_field(v_p_24207, 0);
    V v_y_24209 = heff_field(v_p_24207, 1);
    heff_take_n(v_p_24207, 3ULL, 2);
    V v_t_24213;
    switch (heff_tag_of(v_x_24208)) {
    case TAG_Nom: {
      V v_x_24210 = heff_field(v_x_24208, 0);
      heff_take_n(v_x_24208, 1ULL, 1);
      v_t_24213 = v_x_24210;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24208, 0ULL, 1);
      v_t_24213 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24212 = heff_field(v_x_24208, 0);
      heff_take_n(v_x_24208, 1ULL, 1);
      v_t_24213 = v_x_24212;
      break;
    }
    default: heff_nomatch(v_x_24208);
    }
    V v_t_24217;
    switch (heff_tag_of(v_y_24209)) {
    case TAG_Nom: {
      V v_x_24214 = heff_field(v_y_24209, 0);
      heff_take_n(v_y_24209, 1ULL, 1);
      v_t_24217 = v_x_24214;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24209, 0ULL, 1);
      v_t_24217 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24216 = heff_field(v_y_24209, 0);
      heff_take_n(v_y_24209, 1ULL, 1);
      v_t_24217 = v_x_24216;
      break;
    }
    default: heff_nomatch(v_y_24209);
    }
    return heff_tail(heff_get(v_r_243, LBL_uel), 4, (V[]){v_g_244, v_cs_245, v_t_24213, v_t_24217});
  }
  default: return heff_nomatch(v_p_24207);
  }
}
V g_heff_2eunify_2euElRigid_lam35(V self, V *args) {
  V v_c_24222 = args[0];
  V v_hd_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24222, 2, (V[]){heff_dup(v_hd_24220), heff_get(v_hd_24220, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam34(V self, V *args) {
  V v_hd_24220 = args[0];
  V v_k2_24221 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24219 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24223 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam35, 1, 1, (V[]){heff_dup(v_hd_24220)}), v_p_24219}));
  V v_t_24224 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24220), LBL_malg), 1, (V[]){v_t_24223}));
  V f_ = heff_get(v_hd_24220, LBL_bind);
  args[0] = v_t_24224;
  args[1] = v_k2_24221;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam36(V self, V *args) {
  V v_hd_24225 = args[0];
  V v_k_24226 = args[1];
  heff_drop(v_hd_24225);
  V f_ = v_k_24226;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eunify_2euTermF_lam1(V self, V *args);
V g_heff_2eunify_2euTermF_lam5(V self, V *args);
V g_heff_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eunify_2euTermF_lam9(V self, V *args);
V g_heff_2eunify_2euTermF_lam8(V self, V *args);
V g_heff_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eunify_2euTermF_lam3(V self, V *args);
Clo g_heff_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_p_249 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  V v_c_2415 = heff_clo(g_heff_2eunify_2euTermF_lam1, 2, 2, (V[]){heff_dup(v_w_240), v_p_249});
  return heff_clo(g_heff_2eunify_2euTermF_lam3, 2, 8, (V[]){v_c_2415, v_ms_241, v_b0_247, v_w_240, v_uf_242, v_cs_245, v_r_243, v_g_244});
}
V g_heff_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_a0_246; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTermF_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2410), heff_get(v_hd_2410, LBL_ret)});
}
V g_heff_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam2, 1, 1, (V[]){heff_dup(v_hd_2410)}), v_p_249}));
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2419 = args[0];
  V v_b0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2419, LBL_metas); V a_1 = v_b0_247; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTermF_lam7(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2421), heff_get(v_hd_2421, LBL_ret)});
}
V g_heff_2eunify_2euTermF_lam6(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam7, 1, 1, (V[]){heff_dup(v_hd_2421)}), v_p_2420}));
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2424}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2425;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTermF_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2431);
  V v_t_2432 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = heff_get(v_cs_245, LBL_len); V a_4 = v_x_2427; V r_ = (g_heff_2eunify_2epoisonEl(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_uf_242); r_; });
  return heff_tail(v_t_2432, 2, (V[]){v_hd_2416, v_k_2417});
}
V g_heff_2eunify_2euTermF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_uf_242 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2428 = (g_heff_2evalue_2eisError(v_x_2418));
  V v_t_2429;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_True: {
    v_t_2429 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_2429 = (g_heff_2evalue_2eisError(v_x_2427));
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  switch (heff_tag_of(v_t_2429)) {
  case TAG_True: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_c_2430 = (g_heff_2eunify_2epoisonEl(heff_dup(v_w_240), heff_dup(v_ms_241), v_uf_242, heff_get(heff_dup(v_cs_245), LBL_len), v_x_2418));
    return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam9, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_cs_245, v_x_2427, v_hd_2416, v_k_2417})});
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_2455;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_2443 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_2444 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_2443)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_2443, 0ULL, 1);
            heff_drop(v_sp_2444);
            v_it_2455 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_2443, 0ULL, 1);
            heff_drop(v_sp_2444);
            v_it_2455 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2450 = heff_field(v_it1_2443, 0);
            V v_ru_24it1_2443_24HMeta = heff_take_reuse_n(v_it1_2443, 1ULL, 1);
            v_it_2455 = heff_tag_at(v_ru_24it1_2443_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2450, v_sp_2444})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2444);
            v_it_2455 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_2443);
          }
          break;
        }
        case TAG_VCode: {
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_2455)) {
        case TAG_Nothing: {
          V v_it_2468;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_2456 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_2457 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_2456)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_2456, 0ULL, 1);
              heff_drop(v_sp_2457);
              v_it_2468 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_2456, 0ULL, 1);
              heff_drop(v_sp_2457);
              v_it_2468 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2463 = heff_field(v_it1_2456, 0);
              V v_ru_24it1_2456_24HMeta = heff_take_reuse_n(v_it1_2456, 1ULL, 1);
              v_it_2468 = heff_tag_at(v_ru_24it1_2456_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2463, v_sp_2457})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2457);
              v_it_2468 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_2456);
            }
            break;
          }
          case TAG_VCode: {
            v_it_2468 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_2468 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_2468 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_2468 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_2468)) {
          case TAG_Nothing: {
            V v_t_2481;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_2469 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_2469)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_2469, 0ULL, 1);
                v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_2469, 0ULL, 1);
                v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_2469, 0ULL, 1);
                v_t_2481 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_2469);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2481 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_2494;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_2482 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_2482)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_2482, 0ULL, 1);
                v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_2482, 0ULL, 1);
                v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_2482, 0ULL, 1);
                v_t_2494 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_2482);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2494 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_2495 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_2481; V a_7 = v_t_2494; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_2495, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_2496 = heff_field(v_it_2468, 0);
            heff_take_n(v_it_2468, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_2496)) {
            case TAG_MkPair: {
              V v_m_2497 = heff_field(v_it1_2496, 0);
              V v_sp_2498 = heff_field(v_it1_2496, 1);
              heff_take_n(v_it1_2496, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_2497, v_sp_2498, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_2496);
            }
          }
          default: return heff_nomatch(v_it_2468);
          }
        }
        case TAG_Just: {
          V v_it1_2499 = heff_field(v_it_2455, 0);
          heff_take_n(v_it_2455, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_2499)) {
          case TAG_MkPair: {
            V v_m_24100 = heff_field(v_it1_2499, 0);
            V v_sp_24101 = heff_field(v_it1_2499, 1);
            heff_take_n(v_it1_2499, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24100, v_sp_24101, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_2499);
          }
        }
        default: return heff_nomatch(v_it_2455);
        }
      }
      case TAG_VCode: {
        V v_it_24115;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24103 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24104 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24103)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24103, 0ULL, 1);
            heff_drop(v_sp_24104);
            v_it_24115 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24103, 0ULL, 1);
            heff_drop(v_sp_24104);
            v_it_24115 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24110 = heff_field(v_it1_24103, 0);
            V v_ru_24it1_24103_24HMeta = heff_take_reuse_n(v_it1_24103, 1ULL, 1);
            v_it_24115 = heff_tag_at(v_ru_24it1_24103_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24110, v_sp_24104})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24104);
            v_it_24115 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24103);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24115)) {
        case TAG_Nothing: {
          V v_it_24128;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24116 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24117 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24116)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24116, 0ULL, 1);
              heff_drop(v_sp_24117);
              v_it_24128 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24116, 0ULL, 1);
              heff_drop(v_sp_24117);
              v_it_24128 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24123 = heff_field(v_it1_24116, 0);
              V v_ru_24it1_24116_24HMeta = heff_take_reuse_n(v_it1_24116, 1ULL, 1);
              v_it_24128 = heff_tag_at(v_ru_24it1_24116_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24123, v_sp_24117})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24117);
              v_it_24128 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24116);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24128)) {
          case TAG_Nothing: {
            V v_t_24141;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24129 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24129)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24129, 0ULL, 1);
                v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24129, 0ULL, 1);
                v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24129, 0ULL, 1);
                v_t_24141 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24129);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24154;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24142 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24142)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24142, 0ULL, 1);
                v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24142, 0ULL, 1);
                v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24142, 0ULL, 1);
                v_t_24154 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24142);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24155 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24141; V a_7 = v_t_24154; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24155, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24156 = heff_field(v_it_24128, 0);
            heff_take_n(v_it_24128, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24156)) {
            case TAG_MkPair: {
              V v_m_24157 = heff_field(v_it1_24156, 0);
              V v_sp_24158 = heff_field(v_it1_24156, 1);
              heff_take_n(v_it1_24156, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24157, v_sp_24158, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24156);
            }
          }
          default: return heff_nomatch(v_it_24128);
          }
        }
        case TAG_Just: {
          V v_it1_24159 = heff_field(v_it_24115, 0);
          heff_take_n(v_it_24115, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24159)) {
          case TAG_MkPair: {
            V v_m_24160 = heff_field(v_it1_24159, 0);
            V v_sp_24161 = heff_field(v_it1_24159, 1);
            heff_take_n(v_it1_24159, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24160, v_sp_24161, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24159);
          }
        }
        default: return heff_nomatch(v_it_24115);
        }
      }
      case TAG_VLam: {
        V v_it_24176;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24164 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24165 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24164)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24164, 0ULL, 1);
            heff_drop(v_sp_24165);
            v_it_24176 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24164, 0ULL, 1);
            heff_drop(v_sp_24165);
            v_it_24176 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24171 = heff_field(v_it1_24164, 0);
            V v_ru_24it1_24164_24HMeta = heff_take_reuse_n(v_it1_24164, 1ULL, 1);
            v_it_24176 = heff_tag_at(v_ru_24it1_24164_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24171, v_sp_24165})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24165);
            v_it_24176 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24164);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24176 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24176 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24176 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24176 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24176)) {
        case TAG_Nothing: {
          V v_it_24189;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24177 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24178 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24177)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24177, 0ULL, 1);
              heff_drop(v_sp_24178);
              v_it_24189 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24177, 0ULL, 1);
              heff_drop(v_sp_24178);
              v_it_24189 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24184 = heff_field(v_it1_24177, 0);
              V v_ru_24it1_24177_24HMeta = heff_take_reuse_n(v_it1_24177, 1ULL, 1);
              v_it_24189 = heff_tag_at(v_ru_24it1_24177_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24184, v_sp_24178})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24178);
              v_it_24189 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24177);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24189 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24189 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24189 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24189 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24189)) {
          case TAG_Nothing: {
            V v_t_24202;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24190 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24190)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24190, 0ULL, 1);
                v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24190, 0ULL, 1);
                v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24190, 0ULL, 1);
                v_t_24202 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24190);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24202 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24215;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24203 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24203)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24203, 0ULL, 1);
                v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24203, 0ULL, 1);
                v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24203, 0ULL, 1);
                v_t_24215 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24203);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24215 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24216 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24202; V a_7 = v_t_24215; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24216, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24217 = heff_field(v_it_24189, 0);
            heff_take_n(v_it_24189, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24217)) {
            case TAG_MkPair: {
              V v_m_24218 = heff_field(v_it1_24217, 0);
              V v_sp_24219 = heff_field(v_it1_24217, 1);
              heff_take_n(v_it1_24217, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24218, v_sp_24219, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24217);
            }
          }
          default: return heff_nomatch(v_it_24189);
          }
        }
        case TAG_Just: {
          V v_it1_24220 = heff_field(v_it_24176, 0);
          heff_take_n(v_it_24176, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24220)) {
          case TAG_MkPair: {
            V v_m_24221 = heff_field(v_it1_24220, 0);
            V v_sp_24222 = heff_field(v_it1_24220, 1);
            heff_take_n(v_it1_24220, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24221, v_sp_24222, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24220);
          }
        }
        default: return heff_nomatch(v_it_24176);
        }
      }
      case TAG_VCons: {
        V v_it_24236;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24224 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24225 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24224)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24224, 0ULL, 1);
            heff_drop(v_sp_24225);
            v_it_24236 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24224, 0ULL, 1);
            heff_drop(v_sp_24225);
            v_it_24236 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24231 = heff_field(v_it1_24224, 0);
            V v_ru_24it1_24224_24HMeta = heff_take_reuse_n(v_it1_24224, 1ULL, 1);
            v_it_24236 = heff_tag_at(v_ru_24it1_24224_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24231, v_sp_24225})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24225);
            v_it_24236 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24224);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24236)) {
        case TAG_Nothing: {
          V v_it_24249;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24237 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24238 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24237)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24237, 0ULL, 1);
              heff_drop(v_sp_24238);
              v_it_24249 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24237, 0ULL, 1);
              heff_drop(v_sp_24238);
              v_it_24249 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24244 = heff_field(v_it1_24237, 0);
              V v_ru_24it1_24237_24HMeta = heff_take_reuse_n(v_it1_24237, 1ULL, 1);
              v_it_24249 = heff_tag_at(v_ru_24it1_24237_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24244, v_sp_24238})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24238);
              v_it_24249 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24237);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24249)) {
          case TAG_Nothing: {
            V v_t_24262;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24250 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24250)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24250, 0ULL, 1);
                v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24250, 0ULL, 1);
                v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24250, 0ULL, 1);
                v_t_24262 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24250);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24275;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24263 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24263)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24263, 0ULL, 1);
                v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24263, 0ULL, 1);
                v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24263, 0ULL, 1);
                v_t_24275 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24263);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24276 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24262; V a_7 = v_t_24275; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24276, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24277 = heff_field(v_it_24249, 0);
            heff_take_n(v_it_24249, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24277)) {
            case TAG_MkPair: {
              V v_m_24278 = heff_field(v_it1_24277, 0);
              V v_sp_24279 = heff_field(v_it1_24277, 1);
              heff_take_n(v_it1_24277, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24278, v_sp_24279, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24277);
            }
          }
          default: return heff_nomatch(v_it_24249);
          }
        }
        case TAG_Just: {
          V v_it1_24280 = heff_field(v_it_24236, 0);
          heff_take_n(v_it_24236, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24280)) {
          case TAG_MkPair: {
            V v_m_24281 = heff_field(v_it1_24280, 0);
            V v_sp_24282 = heff_field(v_it1_24280, 1);
            heff_take_n(v_it1_24280, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24281, v_sp_24282, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24280);
          }
        }
        default: return heff_nomatch(v_it_24236);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 5);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24301;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24289 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24290 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24289)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24289, 0ULL, 1);
            heff_drop(v_sp_24290);
            v_it_24301 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24289, 0ULL, 1);
            heff_drop(v_sp_24290);
            v_it_24301 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24296 = heff_field(v_it1_24289, 0);
            V v_ru_24it1_24289_24HMeta = heff_take_reuse_n(v_it1_24289, 1ULL, 1);
            v_it_24301 = heff_tag_at(v_ru_24it1_24289_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24296, v_sp_24290})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24290);
            v_it_24301 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24289);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24301 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24301 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24301 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24301 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24301)) {
        case TAG_Nothing: {
          V v_it_24314;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24302 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24303 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24302)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24302, 0ULL, 1);
              heff_drop(v_sp_24303);
              v_it_24314 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24302, 0ULL, 1);
              heff_drop(v_sp_24303);
              v_it_24314 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24309 = heff_field(v_it1_24302, 0);
              V v_ru_24it1_24302_24HMeta = heff_take_reuse_n(v_it1_24302, 1ULL, 1);
              v_it_24314 = heff_tag_at(v_ru_24it1_24302_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24309, v_sp_24303})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24303);
              v_it_24314 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24302);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24314 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24314 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24314 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24314 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24314)) {
          case TAG_Nothing: {
            V v_t_24327;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24315 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24315)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24315, 0ULL, 1);
                v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24315, 0ULL, 1);
                v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24315, 0ULL, 1);
                v_t_24327 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24315);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24327 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24340;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24328 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24328)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24328, 0ULL, 1);
                v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24328, 0ULL, 1);
                v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24328, 0ULL, 1);
                v_t_24340 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24328);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24340 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24341 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24327; V a_7 = v_t_24340; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24341, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24342 = heff_field(v_it_24314, 0);
            heff_take_n(v_it_24314, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24342)) {
            case TAG_MkPair: {
              V v_m_24343 = heff_field(v_it1_24342, 0);
              V v_sp_24344 = heff_field(v_it1_24342, 1);
              heff_take_n(v_it1_24342, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24343, v_sp_24344, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24342);
            }
          }
          default: return heff_nomatch(v_it_24314);
          }
        }
        case TAG_Just: {
          V v_it1_24345 = heff_field(v_it_24301, 0);
          heff_take_n(v_it_24301, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24345)) {
          case TAG_MkPair: {
            V v_m_24346 = heff_field(v_it1_24345, 0);
            V v_sp_24347 = heff_field(v_it1_24345, 1);
            heff_take_n(v_it1_24345, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24346, v_sp_24347, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24345);
          }
        }
        default: return heff_nomatch(v_it_24301);
        }
      }
      case TAG_VCode: {
        V v_it_24361;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24349 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24350 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24349)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24349, 0ULL, 1);
            heff_drop(v_sp_24350);
            v_it_24361 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24349, 0ULL, 1);
            heff_drop(v_sp_24350);
            v_it_24361 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24356 = heff_field(v_it1_24349, 0);
            V v_ru_24it1_24349_24HMeta = heff_take_reuse_n(v_it1_24349, 1ULL, 1);
            v_it_24361 = heff_tag_at(v_ru_24it1_24349_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24356, v_sp_24350})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24350);
            v_it_24361 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24349);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24361)) {
        case TAG_Nothing: {
          V v_it_24374;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24362 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24363 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24362)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24362, 0ULL, 1);
              heff_drop(v_sp_24363);
              v_it_24374 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24362, 0ULL, 1);
              heff_drop(v_sp_24363);
              v_it_24374 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24369 = heff_field(v_it1_24362, 0);
              V v_ru_24it1_24362_24HMeta = heff_take_reuse_n(v_it1_24362, 1ULL, 1);
              v_it_24374 = heff_tag_at(v_ru_24it1_24362_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24369, v_sp_24363})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24363);
              v_it_24374 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24362);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24374)) {
          case TAG_Nothing: {
            V v_t_24387;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24375 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24375)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24375, 0ULL, 1);
                v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24375, 0ULL, 1);
                v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24375, 0ULL, 1);
                v_t_24387 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24375);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24400;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24388 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24388)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24388, 0ULL, 1);
                v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24388, 0ULL, 1);
                v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24388, 0ULL, 1);
                v_t_24400 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24388);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24401 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24387; V a_7 = v_t_24400; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24401, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24402 = heff_field(v_it_24374, 0);
            heff_take_n(v_it_24374, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24402)) {
            case TAG_MkPair: {
              V v_m_24403 = heff_field(v_it1_24402, 0);
              V v_sp_24404 = heff_field(v_it1_24402, 1);
              heff_take_n(v_it1_24402, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24403, v_sp_24404, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24402);
            }
          }
          default: return heff_nomatch(v_it_24374);
          }
        }
        case TAG_Just: {
          V v_it1_24405 = heff_field(v_it_24361, 0);
          heff_take_n(v_it_24361, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24405)) {
          case TAG_MkPair: {
            V v_m_24406 = heff_field(v_it1_24405, 0);
            V v_sp_24407 = heff_field(v_it1_24405, 1);
            heff_take_n(v_it1_24405, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24406, v_sp_24407, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24405);
          }
        }
        default: return heff_nomatch(v_it_24361);
        }
      }
      case TAG_VLam: {
        V v_it_24422;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24410 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24411 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24410)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24410, 0ULL, 1);
            heff_drop(v_sp_24411);
            v_it_24422 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24410, 0ULL, 1);
            heff_drop(v_sp_24411);
            v_it_24422 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24417 = heff_field(v_it1_24410, 0);
            V v_ru_24it1_24410_24HMeta = heff_take_reuse_n(v_it1_24410, 1ULL, 1);
            v_it_24422 = heff_tag_at(v_ru_24it1_24410_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24417, v_sp_24411})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24411);
            v_it_24422 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24410);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24422 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24422 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24422 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24422 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24422)) {
        case TAG_Nothing: {
          V v_it_24435;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24423 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24424 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24423)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24423, 0ULL, 1);
              heff_drop(v_sp_24424);
              v_it_24435 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24423, 0ULL, 1);
              heff_drop(v_sp_24424);
              v_it_24435 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24430 = heff_field(v_it1_24423, 0);
              V v_ru_24it1_24423_24HMeta = heff_take_reuse_n(v_it1_24423, 1ULL, 1);
              v_it_24435 = heff_tag_at(v_ru_24it1_24423_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24430, v_sp_24424})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24424);
              v_it_24435 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24423);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24435 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24435 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24435 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24435 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24435)) {
          case TAG_Nothing: {
            V v_t_24448;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24436 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24436)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24436, 0ULL, 1);
                v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24436, 0ULL, 1);
                v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24436, 0ULL, 1);
                v_t_24448 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24436);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24448 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24461;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24449 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24449)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24449, 0ULL, 1);
                v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24449, 0ULL, 1);
                v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24449, 0ULL, 1);
                v_t_24461 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24449);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24461 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24462 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24448; V a_7 = v_t_24461; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24462, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24463 = heff_field(v_it_24435, 0);
            heff_take_n(v_it_24435, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24463)) {
            case TAG_MkPair: {
              V v_m_24464 = heff_field(v_it1_24463, 0);
              V v_sp_24465 = heff_field(v_it1_24463, 1);
              heff_take_n(v_it1_24463, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24464, v_sp_24465, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24463);
            }
          }
          default: return heff_nomatch(v_it_24435);
          }
        }
        case TAG_Just: {
          V v_it1_24466 = heff_field(v_it_24422, 0);
          heff_take_n(v_it_24422, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24466)) {
          case TAG_MkPair: {
            V v_m_24467 = heff_field(v_it1_24466, 0);
            V v_sp_24468 = heff_field(v_it1_24466, 1);
            heff_take_n(v_it1_24466, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24467, v_sp_24468, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24466);
          }
        }
        default: return heff_nomatch(v_it_24422);
        }
      }
      case TAG_VCons: {
        V v_it_24482;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24470 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24471 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24470)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24470, 0ULL, 1);
            heff_drop(v_sp_24471);
            v_it_24482 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24470, 0ULL, 1);
            heff_drop(v_sp_24471);
            v_it_24482 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24477 = heff_field(v_it1_24470, 0);
            V v_ru_24it1_24470_24HMeta = heff_take_reuse_n(v_it1_24470, 1ULL, 1);
            v_it_24482 = heff_tag_at(v_ru_24it1_24470_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24477, v_sp_24471})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24471);
            v_it_24482 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24470);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24482)) {
        case TAG_Nothing: {
          V v_it_24495;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24483 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24484 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24483)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24483, 0ULL, 1);
              heff_drop(v_sp_24484);
              v_it_24495 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24483, 0ULL, 1);
              heff_drop(v_sp_24484);
              v_it_24495 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24490 = heff_field(v_it1_24483, 0);
              V v_ru_24it1_24483_24HMeta = heff_take_reuse_n(v_it1_24483, 1ULL, 1);
              v_it_24495 = heff_tag_at(v_ru_24it1_24483_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24490, v_sp_24484})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24484);
              v_it_24495 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24483);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24495)) {
          case TAG_Nothing: {
            V v_t_24508;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24496 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24496)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24496, 0ULL, 1);
                v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24496, 0ULL, 1);
                v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24496, 0ULL, 1);
                v_t_24508 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24496);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24521;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24509 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24509)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24509, 0ULL, 1);
                v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24509, 0ULL, 1);
                v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24509, 0ULL, 1);
                v_t_24521 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24509);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24522 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24508; V a_7 = v_t_24521; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24522, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24523 = heff_field(v_it_24495, 0);
            heff_take_n(v_it_24495, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24523)) {
            case TAG_MkPair: {
              V v_m_24524 = heff_field(v_it1_24523, 0);
              V v_sp_24525 = heff_field(v_it1_24523, 1);
              heff_take_n(v_it1_24523, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24524, v_sp_24525, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24523);
            }
          }
          default: return heff_nomatch(v_it_24495);
          }
        }
        case TAG_Just: {
          V v_it1_24526 = heff_field(v_it_24482, 0);
          heff_take_n(v_it_24482, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24526)) {
          case TAG_MkPair: {
            V v_m_24527 = heff_field(v_it1_24526, 0);
            V v_sp_24528 = heff_field(v_it1_24526, 1);
            heff_take_n(v_it1_24526, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24527, v_sp_24528, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24526);
          }
        }
        default: return heff_nomatch(v_it_24482);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 1);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24548;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24536 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24537 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24536)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24536, 0ULL, 1);
            heff_drop(v_sp_24537);
            v_it_24548 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24536, 0ULL, 1);
            heff_drop(v_sp_24537);
            v_it_24548 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24543 = heff_field(v_it1_24536, 0);
            V v_ru_24it1_24536_24HMeta = heff_take_reuse_n(v_it1_24536, 1ULL, 1);
            v_it_24548 = heff_tag_at(v_ru_24it1_24536_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24543, v_sp_24537})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24537);
            v_it_24548 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24536);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24548 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24548 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24548 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24548 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24548)) {
        case TAG_Nothing: {
          V v_it_24561;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24549 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24550 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24549)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24549, 0ULL, 1);
              heff_drop(v_sp_24550);
              v_it_24561 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24549, 0ULL, 1);
              heff_drop(v_sp_24550);
              v_it_24561 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24556 = heff_field(v_it1_24549, 0);
              V v_ru_24it1_24549_24HMeta = heff_take_reuse_n(v_it1_24549, 1ULL, 1);
              v_it_24561 = heff_tag_at(v_ru_24it1_24549_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24556, v_sp_24550})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24550);
              v_it_24561 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24549);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24561 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24561 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24561 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24561 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24561)) {
          case TAG_Nothing: {
            V v_t_24574;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24562 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24562)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24562, 0ULL, 1);
                v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24562, 0ULL, 1);
                v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24562, 0ULL, 1);
                v_t_24574 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24562);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24574 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24587;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24575 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24575)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24575, 0ULL, 1);
                v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24575, 0ULL, 1);
                v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24575, 0ULL, 1);
                v_t_24587 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24575);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24587 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24588 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24574; V a_7 = v_t_24587; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24588, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24589 = heff_field(v_it_24561, 0);
            heff_take_n(v_it_24561, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24589)) {
            case TAG_MkPair: {
              V v_m_24590 = heff_field(v_it1_24589, 0);
              V v_sp_24591 = heff_field(v_it1_24589, 1);
              heff_take_n(v_it1_24589, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24590, v_sp_24591, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24589);
            }
          }
          default: return heff_nomatch(v_it_24561);
          }
        }
        case TAG_Just: {
          V v_it1_24592 = heff_field(v_it_24548, 0);
          heff_take_n(v_it_24548, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24592)) {
          case TAG_MkPair: {
            V v_m_24593 = heff_field(v_it1_24592, 0);
            V v_sp_24594 = heff_field(v_it1_24592, 1);
            heff_take_n(v_it1_24592, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24593, v_sp_24594, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24592);
          }
        }
        default: return heff_nomatch(v_it_24548);
        }
      }
      case TAG_VCode: {
        V v_it_24608;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24596 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24597 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24596)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24596, 0ULL, 1);
            heff_drop(v_sp_24597);
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24596, 0ULL, 1);
            heff_drop(v_sp_24597);
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24603 = heff_field(v_it1_24596, 0);
            V v_ru_24it1_24596_24HMeta = heff_take_reuse_n(v_it1_24596, 1ULL, 1);
            v_it_24608 = heff_tag_at(v_ru_24it1_24596_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24603, v_sp_24597})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24597);
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24596);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24608)) {
        case TAG_Nothing: {
          V v_it_24621;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24609 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24610 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24609)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24609, 0ULL, 1);
              heff_drop(v_sp_24610);
              v_it_24621 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24609, 0ULL, 1);
              heff_drop(v_sp_24610);
              v_it_24621 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24616 = heff_field(v_it1_24609, 0);
              V v_ru_24it1_24609_24HMeta = heff_take_reuse_n(v_it1_24609, 1ULL, 1);
              v_it_24621 = heff_tag_at(v_ru_24it1_24609_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24616, v_sp_24610})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24610);
              v_it_24621 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24609);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24621)) {
          case TAG_Nothing: {
            V v_t_24634;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24622 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24622)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24622, 0ULL, 1);
                v_t_24634 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24622);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24647;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24635 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24635)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24635, 0ULL, 1);
                v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24635, 0ULL, 1);
                v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24635, 0ULL, 1);
                v_t_24647 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24635);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24648 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24634; V a_7 = v_t_24647; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24648, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24649 = heff_field(v_it_24621, 0);
            heff_take_n(v_it_24621, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24649)) {
            case TAG_MkPair: {
              V v_m_24650 = heff_field(v_it1_24649, 0);
              V v_sp_24651 = heff_field(v_it1_24649, 1);
              heff_take_n(v_it1_24649, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24650, v_sp_24651, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24649);
            }
          }
          default: return heff_nomatch(v_it_24621);
          }
        }
        case TAG_Just: {
          V v_it1_24652 = heff_field(v_it_24608, 0);
          heff_take_n(v_it_24608, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24652)) {
          case TAG_MkPair: {
            V v_m_24653 = heff_field(v_it1_24652, 0);
            V v_sp_24654 = heff_field(v_it1_24652, 1);
            heff_take_n(v_it1_24652, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24653, v_sp_24654, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24652);
          }
        }
        default: return heff_nomatch(v_it_24608);
        }
      }
      case TAG_VLam: {
        V v_it_24669;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24657 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24658 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24657)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24657, 0ULL, 1);
            heff_drop(v_sp_24658);
            v_it_24669 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24657, 0ULL, 1);
            heff_drop(v_sp_24658);
            v_it_24669 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24664 = heff_field(v_it1_24657, 0);
            V v_ru_24it1_24657_24HMeta = heff_take_reuse_n(v_it1_24657, 1ULL, 1);
            v_it_24669 = heff_tag_at(v_ru_24it1_24657_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24664, v_sp_24658})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24658);
            v_it_24669 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24657);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24669 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24669 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24669 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24669 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24669)) {
        case TAG_Nothing: {
          V v_it_24682;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24670 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24671 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24670)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24670, 0ULL, 1);
              heff_drop(v_sp_24671);
              v_it_24682 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24670, 0ULL, 1);
              heff_drop(v_sp_24671);
              v_it_24682 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24677 = heff_field(v_it1_24670, 0);
              V v_ru_24it1_24670_24HMeta = heff_take_reuse_n(v_it1_24670, 1ULL, 1);
              v_it_24682 = heff_tag_at(v_ru_24it1_24670_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24677, v_sp_24671})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24671);
              v_it_24682 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24670);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24682 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24682 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24682 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24682 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24682)) {
          case TAG_Nothing: {
            V v_t_24695;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24683 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24683)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24683, 0ULL, 1);
                v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24683, 0ULL, 1);
                v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24683, 0ULL, 1);
                v_t_24695 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24683);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24695 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24708;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24696 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24696)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24696, 0ULL, 1);
                v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24696, 0ULL, 1);
                v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24696, 0ULL, 1);
                v_t_24708 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24696);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24708 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24709 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24695; V a_7 = v_t_24708; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24709, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24710 = heff_field(v_it_24682, 0);
            heff_take_n(v_it_24682, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24710)) {
            case TAG_MkPair: {
              V v_m_24711 = heff_field(v_it1_24710, 0);
              V v_sp_24712 = heff_field(v_it1_24710, 1);
              heff_take_n(v_it1_24710, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24711, v_sp_24712, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24710);
            }
          }
          default: return heff_nomatch(v_it_24682);
          }
        }
        case TAG_Just: {
          V v_it1_24713 = heff_field(v_it_24669, 0);
          heff_take_n(v_it_24669, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24713)) {
          case TAG_MkPair: {
            V v_m_24714 = heff_field(v_it1_24713, 0);
            V v_sp_24715 = heff_field(v_it1_24713, 1);
            heff_take_n(v_it1_24713, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24714, v_sp_24715, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24713);
          }
        }
        default: return heff_nomatch(v_it_24669);
        }
      }
      case TAG_VCons: {
        V v_it_24729;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24717 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24718 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24717)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24717, 0ULL, 1);
            heff_drop(v_sp_24718);
            v_it_24729 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24717, 0ULL, 1);
            heff_drop(v_sp_24718);
            v_it_24729 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24724 = heff_field(v_it1_24717, 0);
            V v_ru_24it1_24717_24HMeta = heff_take_reuse_n(v_it1_24717, 1ULL, 1);
            v_it_24729 = heff_tag_at(v_ru_24it1_24717_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24724, v_sp_24718})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24718);
            v_it_24729 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24717);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24729)) {
        case TAG_Nothing: {
          V v_it_24742;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24730 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24731 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24730)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24730, 0ULL, 1);
              heff_drop(v_sp_24731);
              v_it_24742 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24730, 0ULL, 1);
              heff_drop(v_sp_24731);
              v_it_24742 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24737 = heff_field(v_it1_24730, 0);
              V v_ru_24it1_24730_24HMeta = heff_take_reuse_n(v_it1_24730, 1ULL, 1);
              v_it_24742 = heff_tag_at(v_ru_24it1_24730_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24737, v_sp_24731})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24731);
              v_it_24742 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24730);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24742)) {
          case TAG_Nothing: {
            V v_t_24755;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24743 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24743)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24743, 0ULL, 1);
                v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24743, 0ULL, 1);
                v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24743, 0ULL, 1);
                v_t_24755 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24743);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24768;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24756 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24756)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24756, 0ULL, 1);
                v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24756, 0ULL, 1);
                v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24756, 0ULL, 1);
                v_t_24768 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24756);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24769 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24755; V a_7 = v_t_24768; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24769, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24770 = heff_field(v_it_24742, 0);
            heff_take_n(v_it_24742, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24770)) {
            case TAG_MkPair: {
              V v_m_24771 = heff_field(v_it1_24770, 0);
              V v_sp_24772 = heff_field(v_it1_24770, 1);
              heff_take_n(v_it1_24770, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24771, v_sp_24772, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24770);
            }
          }
          default: return heff_nomatch(v_it_24742);
          }
        }
        case TAG_Just: {
          V v_it1_24773 = heff_field(v_it_24729, 0);
          heff_take_n(v_it_24729, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24773)) {
          case TAG_MkPair: {
            V v_m_24774 = heff_field(v_it1_24773, 0);
            V v_sp_24775 = heff_field(v_it1_24773, 1);
            heff_take_n(v_it1_24773, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24774, v_sp_24775, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24773);
          }
        }
        default: return heff_nomatch(v_it_24729);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 2);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24794;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24782 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24783 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24782)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24782, 0ULL, 1);
            heff_drop(v_sp_24783);
            v_it_24794 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24782, 0ULL, 1);
            heff_drop(v_sp_24783);
            v_it_24794 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24789 = heff_field(v_it1_24782, 0);
            V v_ru_24it1_24782_24HMeta = heff_take_reuse_n(v_it1_24782, 1ULL, 1);
            v_it_24794 = heff_tag_at(v_ru_24it1_24782_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24789, v_sp_24783})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24783);
            v_it_24794 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24782);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24794 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24794 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24794 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24794 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24794)) {
        case TAG_Nothing: {
          V v_it_24807;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24795 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24796 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24795)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24795, 0ULL, 1);
              heff_drop(v_sp_24796);
              v_it_24807 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24795, 0ULL, 1);
              heff_drop(v_sp_24796);
              v_it_24807 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24802 = heff_field(v_it1_24795, 0);
              V v_ru_24it1_24795_24HMeta = heff_take_reuse_n(v_it1_24795, 1ULL, 1);
              v_it_24807 = heff_tag_at(v_ru_24it1_24795_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24802, v_sp_24796})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24796);
              v_it_24807 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24795);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24807 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24807 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24807 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24807 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24807)) {
          case TAG_Nothing: {
            V v_t_24820;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24808 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24808)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24808, 0ULL, 1);
                v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24808, 0ULL, 1);
                v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24808, 0ULL, 1);
                v_t_24820 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24808);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24820 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24833;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24821 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24821)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24821, 0ULL, 1);
                v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24821, 0ULL, 1);
                v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24821, 0ULL, 1);
                v_t_24833 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24821);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24833 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24834 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24820; V a_7 = v_t_24833; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24834, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24835 = heff_field(v_it_24807, 0);
            heff_take_n(v_it_24807, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24835)) {
            case TAG_MkPair: {
              V v_m_24836 = heff_field(v_it1_24835, 0);
              V v_sp_24837 = heff_field(v_it1_24835, 1);
              heff_take_n(v_it1_24835, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24836, v_sp_24837, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24835);
            }
          }
          default: return heff_nomatch(v_it_24807);
          }
        }
        case TAG_Just: {
          V v_it1_24838 = heff_field(v_it_24794, 0);
          heff_take_n(v_it_24794, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24838)) {
          case TAG_MkPair: {
            V v_m_24839 = heff_field(v_it1_24838, 0);
            V v_sp_24840 = heff_field(v_it1_24838, 1);
            heff_take_n(v_it1_24838, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24839, v_sp_24840, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24838);
          }
        }
        default: return heff_nomatch(v_it_24794);
        }
      }
      case TAG_VCode: {
        V v_it_24854;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24842 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24843 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24842)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24842, 0ULL, 1);
            heff_drop(v_sp_24843);
            v_it_24854 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24842, 0ULL, 1);
            heff_drop(v_sp_24843);
            v_it_24854 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24849 = heff_field(v_it1_24842, 0);
            V v_ru_24it1_24842_24HMeta = heff_take_reuse_n(v_it1_24842, 1ULL, 1);
            v_it_24854 = heff_tag_at(v_ru_24it1_24842_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24849, v_sp_24843})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24843);
            v_it_24854 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24842);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24854)) {
        case TAG_Nothing: {
          V v_it_24867;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24855 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24856 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24855)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24855, 0ULL, 1);
              heff_drop(v_sp_24856);
              v_it_24867 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24855, 0ULL, 1);
              heff_drop(v_sp_24856);
              v_it_24867 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24862 = heff_field(v_it1_24855, 0);
              V v_ru_24it1_24855_24HMeta = heff_take_reuse_n(v_it1_24855, 1ULL, 1);
              v_it_24867 = heff_tag_at(v_ru_24it1_24855_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24862, v_sp_24856})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24856);
              v_it_24867 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24855);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24867)) {
          case TAG_Nothing: {
            V v_t_24880;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24868 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24868)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24868, 0ULL, 1);
                v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24868, 0ULL, 1);
                v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24868, 0ULL, 1);
                v_t_24880 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24868);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24893;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24881 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24881)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24881, 0ULL, 1);
                v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24881, 0ULL, 1);
                v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24881, 0ULL, 1);
                v_t_24893 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24881);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24894 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24880; V a_7 = v_t_24893; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24894, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24895 = heff_field(v_it_24867, 0);
            heff_take_n(v_it_24867, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24895)) {
            case TAG_MkPair: {
              V v_m_24896 = heff_field(v_it1_24895, 0);
              V v_sp_24897 = heff_field(v_it1_24895, 1);
              heff_take_n(v_it1_24895, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24896, v_sp_24897, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24895);
            }
          }
          default: return heff_nomatch(v_it_24867);
          }
        }
        case TAG_Just: {
          V v_it1_24898 = heff_field(v_it_24854, 0);
          heff_take_n(v_it_24854, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24898)) {
          case TAG_MkPair: {
            V v_m_24899 = heff_field(v_it1_24898, 0);
            V v_sp_24900 = heff_field(v_it1_24898, 1);
            heff_take_n(v_it1_24898, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24899, v_sp_24900, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24898);
          }
        }
        default: return heff_nomatch(v_it_24854);
        }
      }
      case TAG_VLam: {
        V v_it_24915;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24903 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24904 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24903)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24903, 0ULL, 1);
            heff_drop(v_sp_24904);
            v_it_24915 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24903, 0ULL, 1);
            heff_drop(v_sp_24904);
            v_it_24915 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24910 = heff_field(v_it1_24903, 0);
            V v_ru_24it1_24903_24HMeta = heff_take_reuse_n(v_it1_24903, 1ULL, 1);
            v_it_24915 = heff_tag_at(v_ru_24it1_24903_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24910, v_sp_24904})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24904);
            v_it_24915 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24903);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24915 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24915 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24915 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24915 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24915)) {
        case TAG_Nothing: {
          V v_it_24928;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24916 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24917 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24916)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24916, 0ULL, 1);
              heff_drop(v_sp_24917);
              v_it_24928 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24916, 0ULL, 1);
              heff_drop(v_sp_24917);
              v_it_24928 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24923 = heff_field(v_it1_24916, 0);
              V v_ru_24it1_24916_24HMeta = heff_take_reuse_n(v_it1_24916, 1ULL, 1);
              v_it_24928 = heff_tag_at(v_ru_24it1_24916_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24923, v_sp_24917})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24917);
              v_it_24928 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24916);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24928 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24928 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24928 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24928 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24928)) {
          case TAG_Nothing: {
            V v_t_24941;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24929 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24929)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24929, 0ULL, 1);
                v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24929, 0ULL, 1);
                v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24929, 0ULL, 1);
                v_t_24941 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24929);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24941 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24954;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24942 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24942)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24942, 0ULL, 1);
                v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24942, 0ULL, 1);
                v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24942, 0ULL, 1);
                v_t_24954 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24942);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24954 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24955 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24941; V a_7 = v_t_24954; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24955, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24956 = heff_field(v_it_24928, 0);
            heff_take_n(v_it_24928, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24956)) {
            case TAG_MkPair: {
              V v_m_24957 = heff_field(v_it1_24956, 0);
              V v_sp_24958 = heff_field(v_it1_24956, 1);
              heff_take_n(v_it1_24956, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24957, v_sp_24958, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24956);
            }
          }
          default: return heff_nomatch(v_it_24928);
          }
        }
        case TAG_Just: {
          V v_it1_24959 = heff_field(v_it_24915, 0);
          heff_take_n(v_it_24915, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24959)) {
          case TAG_MkPair: {
            V v_m_24960 = heff_field(v_it1_24959, 0);
            V v_sp_24961 = heff_field(v_it1_24959, 1);
            heff_take_n(v_it1_24959, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24960, v_sp_24961, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24959);
          }
        }
        default: return heff_nomatch(v_it_24915);
        }
      }
      case TAG_VCons: {
        V v_it_24975;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24963 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24964 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24963)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24963, 0ULL, 1);
            heff_drop(v_sp_24964);
            v_it_24975 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24963, 0ULL, 1);
            heff_drop(v_sp_24964);
            v_it_24975 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24970 = heff_field(v_it1_24963, 0);
            V v_ru_24it1_24963_24HMeta = heff_take_reuse_n(v_it1_24963, 1ULL, 1);
            v_it_24975 = heff_tag_at(v_ru_24it1_24963_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24970, v_sp_24964})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24964);
            v_it_24975 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24963);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24975)) {
        case TAG_Nothing: {
          V v_it_24988;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24976 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24977 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24976)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24976, 0ULL, 1);
              heff_drop(v_sp_24977);
              v_it_24988 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24976, 0ULL, 1);
              heff_drop(v_sp_24977);
              v_it_24988 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24983 = heff_field(v_it1_24976, 0);
              V v_ru_24it1_24976_24HMeta = heff_take_reuse_n(v_it1_24976, 1ULL, 1);
              v_it_24988 = heff_tag_at(v_ru_24it1_24976_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24983, v_sp_24977})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24977);
              v_it_24988 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24976);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24988)) {
          case TAG_Nothing: {
            V v_t_241001;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24989 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24989)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24989, 0ULL, 1);
                v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24989, 0ULL, 1);
                v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24989, 0ULL, 1);
                v_t_241001 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24989);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_241014;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_241002 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_241002)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_241002, 0ULL, 1);
                v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_241002, 0ULL, 1);
                v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_241002, 0ULL, 1);
                v_t_241014 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_241002);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_241015 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_241001; V a_7 = v_t_241014; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_241015, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_241016 = heff_field(v_it_24988, 0);
            heff_take_n(v_it_24988, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_241016)) {
            case TAG_MkPair: {
              V v_m_241017 = heff_field(v_it1_241016, 0);
              V v_sp_241018 = heff_field(v_it1_241016, 1);
              heff_take_n(v_it1_241016, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241017, v_sp_241018, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_241016);
            }
          }
          default: return heff_nomatch(v_it_24988);
          }
        }
        case TAG_Just: {
          V v_it1_241019 = heff_field(v_it_24975, 0);
          heff_take_n(v_it_24975, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_241019)) {
          case TAG_MkPair: {
            V v_m_241020 = heff_field(v_it1_241019, 0);
            V v_sp_241021 = heff_field(v_it1_241019, 1);
            heff_take_n(v_it1_241019, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241020, v_sp_241021, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_241019);
          }
        }
        default: return heff_nomatch(v_it_24975);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 1);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2427);
      heff_drop(v_w_240);
      heff_drop(v_ms_241);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop(v_hd_2416);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      V f_ = v_k_2417;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2418);
    }
  }
  default: return heff_nomatch(v_t_2429);
  }
}
V g_heff_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_b0_247 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_cs_245 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_p_2420 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam5, 1, 1, (V[]){v_b0_247})})}));
  V v_c_2426 = heff_clo(g_heff_2eunify_2euTermF_lam6, 2, 2, (V[]){heff_dup(v_w_240), v_p_2420});
  return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam8, 1, 9, (V[]){v_x_2418, v_w_240, v_ms_241, v_uf_242, v_cs_245, v_hd_2416, v_k_2417, v_r_243, v_g_244})});
}
V g_heff_2eunify_2euTermF_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_b0_247 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_cs_245 = heff_env(self)[5];
  V v_r_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2eunify_2euTermF_lam4, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2416, v_uf_242, v_cs_245, v_k_2417, v_r_243, v_g_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eufEv(a[0]);
}
Clo g_heff_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_apply(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euH_lam0, 2, 0};
V g_heff_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eunify_2euH_val;
static int g_heff_2eunify_2euH_st;
static V g_heff_2eunify_2euH_init(void) {
  return heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eunify_2euH_lam0_clo), ((V)&g_heff_2eunify_2euH_lam1_clo), ((V)&g_heff_2eunify_2euAlg_clo)});
}
V g_heff_2eunify_2euH_get(void) {
  if (g_heff_2eunify_2euH_st == 2) return g_heff_2eunify_2euH_val;
  if (g_heff_2eunify_2euH_st == 1) heff_fail("defined by itself");
  g_heff_2eunify_2euH_st = 1;
  g_heff_2eunify_2euH_val = heff_tr(g_heff_2eunify_2euH_init());
  g_heff_2eunify_2euH_st = 2;
  return g_heff_2eunify_2euH_val;
}
V g_heff_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eunify_2euModify_24s1340946300x2077833874_lam0(V self, V *args);
Clo g_heff_2eunify_2euModify_24s1340946300x2077833874_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euModify_24s1340946300x2077833874_entry, 3, 0};

V g_heff_2eunify_2euModify_24s1340946300x2077833874(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_240})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2eunify_2euModify_24s1340946300x2077833874_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eunify_2euModify_24s1340946300x2077833874_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euModify_24s1340946300x2077833874(a[0], a[1], a[2]);
}
V g_heff_2eunify_2euModify_24s1340946300x2077833874_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_Put, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_247, v_k_242});
}
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam0, 1, 0};
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam2(V self, V *args);
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam1(V self, V *args);
Clo g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_entry, 4, 0};

V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448(V v_len_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam1, 1, 4, (V[]){v_len_240, v_t_241, v_hd_242, v_k_243})});
}
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epoisonTy_24s1250827093x1392482448(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_ms_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2411 = ({ V a_0 = heff_get(heff_dup(v_c_2410), LBL_poisoned); V a_1 = v_ms_249; V r_ = (g_prelude_2efoldl_24s1377741640x1185496867(a_0, a_1)); heff_drop(v_ms_249); r_; });
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_2410), LBL_infos), heff_get(heff_dup(v_c_2410), LBL_recovered), v_ps_2411, heff_get(heff_dup(v_c_2410), LBL_metas), heff_get(heff_dup(v_c_2410), LBL_nextMeta), heff_get(heff_dup(v_c_2410), LBL_postponed), heff_get(heff_dup(v_c_2410), LBL_trace), heff_get(v_c_2410, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_247); r_; });
  V v_ms_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_mty), 3, (V[]){MK_INT(20LL), v_len_240, v_t_241}));
  return (g_heff_2eunify_2euModify_24s1340946300x2077833874(heff_clo(g_heff_2eunify_2epoisonTy_24s1250827093x1392482448_lam2, 1, 1, (V[]){v_ms_249}), v_hd_242, v_k_243));
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam0(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam0, 2, 0};
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam1(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam1, 2, 0};
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam2(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam3(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam4(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam5(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam6(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam8(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam7(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam9(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam10(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam11(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam12(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam14(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam13(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam15(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam16(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam17(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam18(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam21(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam21, 2, 0};
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam22(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam23(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam20(V self, V *args);
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam19(V self, V *args);
Clo g_heff_2eunify_2euBareF_24s1294623001x1737536464_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s1294623001x1737536464_entry, 6, 0};

V g_heff_2eunify_2euBareF_24s1294623001x1737536464(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    return ((V)&g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam0_clo);
  }
  case TAG_False: {
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2econversion_2eeqHead(v_h_242, v_h_27_244));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          return ((V)&g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam1_clo);
        }
        case TAG_False: {
          return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
        default: return heff_nomatch(v_t_2421);
        }
      }
      case TAG_SpApp: {
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2447 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2448 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2453 = heff_field(v_sp_27_245, 0);
        V v_v_27_2454 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2455 = (g_heff_2eunify_2euBareF_24s1294623001x1737536464(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2447, v_h_27_244, v_sq_27_2453));
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam7, 2, 5, (V[]){v_c_2455, v_g_240, v_cs_241, v_v_2448, v_v_27_2454});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2473 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2474 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_2485 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2486 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2487 = (g_heff_2eunify_2euBareF_24s1294623001x1737536464(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2473, heff_dup(v_h_27_244), v_sq_27_2485));
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam13, 2, 8, (V[]){v_c_2487, v_x_2474, v_x_27_2486, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24101 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24102 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24103 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24120 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24121 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24122 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24123 = (g_heff_2eunify_2euBareF_24s1294623001x1737536464(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24101, heff_dup(v_h_27_244), v_sq_27_24120));
        return heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam19, 2, 11, (V[]){v_c_24123, v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24103, v_v_27_24122});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euBareF_24s1294623001x1737536464(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get(v_hd_2424, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get(v_hd_2430, LBL_bind);
  args[0] = v_t_2433;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2436), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_get(v_hd_2436, LBL_bind);
  args[0] = v_t_2439;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2443), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_get(v_hd_2443, LBL_bind);
  args[0] = v_t_2446;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2451 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2449), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2451})}));
  V f_ = heff_get(v_hd_2449, LBL_bind);
  args[0] = v_t_2452;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2448 = heff_env(self)[2];
  V v_v_27_2454 = heff_env(self)[3];
  V v_hd_2456 = heff_env(self)[4];
  V v_k_2457 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s99985437x1876045342_get()), v_g_240, v_cs_241, v_v_2448, v_v_27_2454));
  return heff_tail(v_t_2459, 2, (V[]){v_hd_2456, v_k_2457});
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2448 = heff_env(self)[3];
  V v_v_27_2454 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2448, v_v_27_2454, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2462), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2464})}));
  V f_ = heff_get(v_hd_2462, LBL_bind);
  args[0] = v_t_2465;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2471 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2469), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2471})}));
  V f_ = heff_get(v_hd_2469, LBL_bind);
  args[0] = v_t_2472;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam11(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2477 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2475), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_get(v_hd_2475, LBL_bind);
  args[0] = v_t_2478;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2483 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2481), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_get(v_hd_2481, LBL_bind);
  args[0] = v_t_2484;
  args[1] = v_k2_2482;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_x_27_2486 = heff_env(self)[1];
  V v_k_2489 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2488 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2490);
  V v_t_2491 = heff_strEq(v_x_2474, v_x_27_2486);
  switch (heff_tag_of(v_t_2491)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop(v_hd_2488);
    V f_ = v_k_2489;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2492 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2488), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2492})}));
    return heff_tail(heff_get(v_hd_2488, LBL_bind), 2, (V[]){v_t_2493, v_k_2489});
  }
  default: return heff_nomatch(v_t_2491);
  }
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_x_27_2486 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam14, 1, 9, (V[]){v_x_2474, v_x_27_2486, v_k_2489, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam15(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2497), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2499})}));
  V f_ = heff_get(v_hd_2497, LBL_bind);
  args[0] = v_t_24100;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam16(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k2_24105 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24106 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24104), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24106})}));
  V f_ = heff_get(v_hd_24104, LBL_bind);
  args[0] = v_t_24107;
  args[1] = v_k2_24105;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24112 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24110), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_get(v_hd_24110, LBL_bind);
  args[0] = v_t_24113;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24118 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24116), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24118})}));
  V f_ = heff_get(v_hd_24116, LBL_bind);
  args[0] = v_t_24119;
  args[1] = v_k2_24117;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam21(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24132 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24133 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24130), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24132})}));
  V f_ = heff_get(v_hd_24130, LBL_bind);
  args[0] = v_t_24133;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam23(V self, V *args) {
  V v_x_24135 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24103 = heff_env(self)[2];
  V v_v_27_24122 = heff_env(self)[3];
  V v_hd_24124 = heff_env(self)[4];
  V v_k_24125 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24135);
  V v_t_24136 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s99985437x1876045342_get()), v_g_240, v_cs_241, v_v_24103, v_v_27_24122));
  return heff_tail(v_t_24136, 2, (V[]){v_hd_24124, v_k_24125});
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam20(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_x_27_24121 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_24124 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  V v_k_24125 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_24126);
  V v_t_24127 = heff_strEq(v_x_24102, v_x_27_24121);
  V v_c_24134;
  switch (heff_tag_of(v_t_24127)) {
  case TAG_True: {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_c_24134 = ((V)&g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam21_clo);
    break;
  }
  case TAG_False: {
    v_c_24134 = heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
    break;
  }
  default: heff_nomatch(v_t_24127);
  }
  return heff_tail(v_c_24134, 2, (V[]){heff_dup(v_hd_24124), heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24103, v_v_27_24122, v_hd_24124, v_k_24125})});
}
V g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_x_27_24121 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo(g_heff_2eunify_2euBareF_24s1294623001x1737536464_lam20, 1, 12, (V[]){v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24124, v_g_240, v_v_24103, v_v_27_24122, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam0, 2, 0};
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam1(V self, V *args);
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam2(V self, V *args);
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam3(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam3, 2, 0};
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam4(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam4, 2, 0};
Clo g_heff_2eunify_2erenameHead_24s1197776504x706394141_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s1197776504x706394141_entry, 2, 0};

V g_heff_2eunify_2erenameHead_24s1197776504x706394141(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_243 = ({ V a_0 = v_l_242; V b_1 = heff_get(heff_dup(v_r_240), LBL_ren); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      return ((V)&g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam0_clo);
    }
    case TAG_Just: {
      V v_l_27_249 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      return heff_clo(g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam1, 2, 2, (V[]){v_r_240, v_l_27_249});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_HGlobal: {
    V v_x_2414 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_r_240);
    return heff_clo(g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam2, 2, 1, (V[]){v_x_2414});
  }
  case TAG_HMeta: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_r_240);
    return ((V)&g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam3_clo);
  }
  case TAG_HError: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam4_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameHead_24s1197776504x706394141(a[0], a[1]);
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_t_246 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  V f_ = heff_get(v_hd_244, LBL_bind);
  args[0] = v_t_248;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_l_27_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_intSub(heff_get(v_r_240, LBL_cod), v_l_27_249);
  V v_t_2413 = heff_tag(TAG_SLocal, 1, (V[]){heff_intSub(v_t_2412, MK_INT(1LL))});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag(TAG_SGlobal, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_t_2420 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2421}));
  V f_ = heff_get(v_hd_2418, LBL_bind);
  args[0] = v_t_2422;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameHead_24s1197776504x706394141_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_t_2425 = heff_tag(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2425})}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam0(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam3(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam2(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam1(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam5(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam4(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam8(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam7(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam6(V self, V *args);
Clo g_heff_2eunify_2erenameSpine_24s1422019577x129546631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameSpine_24s1422019577x129546631_entry, 5, 0};

V g_heff_2eunify_2erenameSpine_24s1422019577x129546631(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameSpine_24s1422019577x129546631(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo(g_heff_2eunify_2erenameSpine_24s1422019577x129546631_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam0(V self, V *args); static Clo g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam0, 1, 0};
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam1(V self, V *args);
Clo g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_entry, 3, 0};

V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam0_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam1, 1, 3, (V[]){v_m_240, v_hd_241, v_k_242})});
}
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emetaEntry_24s1601622766x1299645529(a[0], a[1], a[2]);
}
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam0(V self, V *args) {
  V v_c_243 = args[0];
  return heff_get(v_c_243, LBL_metas);
}
V g_heff_2eunify_2emetaEntry_24s1601622766x1299645529_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = ({ V a_0 = v_m_240; V a_1 = v_x_246; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2410, v_k_242});
  }
  case TAG_Just: {
    V v_e_2411 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_e_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam0(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam1(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam3(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam2(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam5(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam4(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam7(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam6(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam9(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam8(V self, V *args);
Clo g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_entry, 5, 0};

V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_cod), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_get(heff_dup(v_pr_242), LBL_dom), heff_get(heff_dup(v_pr_242), LBL_cod), heff_get(heff_dup(v_pr_242), LBL_ren)));
    V v_pr_2411 = heff_rec(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_pr_242, LBL_dom)});
    V v_v_2414 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2412, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nom: {
      V v_a_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2417}));
      break;
    }
    case TAG_Describe: {
      V v_a_2418 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2418}));
      break;
    }
    case TAG_Become: {
      V v_a_2419 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419});
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_a_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2428}));
      break;
    }
    case TAG_Describe: {
      V v_a_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2429}));
      break;
    }
    case TAG_Become: {
      V v_a_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameCloTy_24s379732076x1925143877(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag(TAG_SIsTy, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(v_g_240, v_m_241, v_pr_2411, v_a_2419, v_hd_2420, heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag(TAG_SIsTy, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(v_g_240, v_m_241, v_pr_242, v_a_2430, v_hd_2431, heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo(g_heff_2eunify_2erenameCloTy_24s379732076x1925143877_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam0, 2, 0};
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam3(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam4(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam5(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam2(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_entry, 6, 0};

V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      V v_c_2414 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411)}));
      return heff_clo(g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam1, 2, 8, (V[]){v_c_2414, v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_ty_2411;
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam4(V self, V *args) {
  V v_u_2421 = args[0];
  V v_v_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  return v_v_2420;
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2416;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_2417, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2415 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2418 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), heff_dup(v_i_243));
  V v_v_2420 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){v_t_2418}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2422 = (g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo(g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam4, 1, 1, (V[]){v_v_2420})}), v_rest_249));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2415, heff_clo(g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam5, 1, 2, (V[]){v_k_2416, v_x_2417})});
}
V g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_i_243 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_m_241 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam0(V self, V *args); static Clo g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam0, 2, 0};
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam3(V self, V *args);
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam2(V self, V *args);
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam1(V self, V *args);
Clo g_heff_2eunify_2etraverseU_24s427677288x1451739928_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraverseU_24s427677288x1451739928_entry, 2, 0};

V g_heff_2eunify_2etraverseU_24s427677288x1451739928(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2etraverseU_24s427677288x1451739928(a[0], a[1]);
}
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eunify_2etraverseU_24s427677288x1451739928(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2eunify_2etraverseU_24s427677288x1451739928_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam0(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam3(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam2(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam5(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam4(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam6(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam8(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam7(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam10(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam9(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam11(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam13(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam15(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam14(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam12(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam16(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam17(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_entry, 6, 0};

V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_t0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  return heff_tail(v_c_2419, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam3, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  return heff_tail(v_c_2424, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam5, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2434 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2433));
  return heff_tail(v_c_2434, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam8, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2436 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_implicit_2439 = heff_env(self)[3];
  V v_dflt_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SFunction, 5, (V[]){v_level_2436, v_x_2441, v_x_2443, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2437 = heff_env(self)[3];
  V v_cod_2438 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2436 = heff_env(self)[7];
  V v_implicit_2439 = heff_env(self)[8];
  V v_dflt_2440 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2442 = (g_heff_2eunify_2erenameCloTy_24s379732076x1925143877(v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438));
  return heff_tail(v_c_2442, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam10, 1, 5, (V[]){v_k_245, v_level_2436, v_x_2441, v_implicit_2439, v_dflt_2440})});
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam11(V self, V *args) {
  V v_x_2450 = args[0];
  V v_fieldTypes_2446 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2444 = heff_env(self)[2];
  V v_defaults_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fieldTypes_2446), LBL_keys), heff_get(v_fieldTypes_2446, LBL_byName), heff_arrayFromList(v_x_2450)});
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SRecord, 3, (V[]){v_level_2444, v_t_2451, v_defaults_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam13(V self, V *args) {
  V v_a_2459 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tr(heff_apply(v_a_2459, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_t_2460});
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam15(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2457 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = heff_tag(TAG_MkPair, 2, (V[]){v_k_2457, heff_arrayFromList(v_x_2464)});
  V f_ = v_k_2463;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam14(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = v_hd_2462;
  args[1] = heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam15, 1, 2, (V[]){v_k_2457, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam12(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_args_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    V v_c_2461 = (g_heff_2eunify_2etraverseU_24s427677288x1451739928(heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2458)));
    return heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam14, 2, 2, (V[]){v_c_2461, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam16(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = (g_prelude_2emap_24s1581021428x1223114127(heff_dup(v_x_2467)));
  V v_t_2469 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2467));
  V v_t_2470 = (g_prelude_2emap_24s531459667x996402587(v_x_2467));
  V v_t_2471 = heff_rec(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2468), v_t_2469, heff_arrayFromList(v_t_2470)});
  V v_x_2472 = heff_tag(TAG_SSum, 1, (V[]){v_t_2471});
  V f_ = v_k_245;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam17(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SPrimArray, 1, (V[]){v_x_2474});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eunify_2erenameHead_24s1197776504x706394141(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eunify_2erenameHead_24s1197776504x706394141(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      V v_t_2427 = heff_intEq(heff_dup(v_m_27_2426), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_2427)) {
      case TAG_True: {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        V v_t_2428 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2429}));
        return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2430, v_k_245});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2426; V a_4 = v_sp_2412; V a_5 = v_hd_244; V a_6 = heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam6, 1, 1, (V[]){v_k_245}); V r_ = (g_heff_2eunify_2erenameFlexF_24s593953928x917846983(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2412); r_; });
      }
      default: return heff_nomatch(v_t_2427);
      }
    }
    case TAG_HError: {
      V v_c_2432 = (g_heff_2eunify_2erenameHead_24s1197776504x706394141(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2436 = heff_field(v_x_249, 0);
    V v_dom_2437 = heff_field(v_x_249, 1);
    V v_cod_2438 = heff_field(v_x_249, 2);
    V v_implicit_2439 = heff_field(v_x_249, 3);
    V v_dflt_2440 = heff_field(v_x_249, 4);
    heff_take_n(v_x_249, 31ULL, 5);
    return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2437), heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438, v_hd_244, v_k_245, v_level_2436, v_implicit_2439, v_dflt_2440})));
  }
  case TAG_VRecord: {
    V v_level_2444 = heff_field(v_x_249, 0);
    V v_capture_2445 = heff_field(v_x_249, 1);
    V v_fieldTypes_2446 = heff_field(v_x_249, 2);
    V v_defaults_2447 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2448 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2446), LBL_values));
    V v_c_2449 = (g_heff_2eunify_2erenameRecordFields_24s1076898909x472582417(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2445, v_t_2448));
    return heff_tail(v_c_2449, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam11, 1, 4, (V[]){v_fieldTypes_2446, v_k_245, v_level_2444, v_defaults_2447})});
  }
  case TAG_VSum: {
    V v_vs_2452 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2453 = heff_arrayToList(heff_get(heff_dup(v_vs_2452), LBL_keys));
    V v_t_2454 = heff_arrayToList(heff_get(v_vs_2452, LBL_values));
    V v_t_2455 = (g_heff_2edict_2ezipKV(v_t_2453, v_t_2454));
    V v_c_2466 = (g_heff_2eunify_2etraverseU_24s427677288x1451739928(heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    return heff_tail(v_c_2466, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam16, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2473 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(v_g_240, v_m_241, v_pr_242, v_a_2473, v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2475 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_SFixed, 1, (V[]){v_w_2475});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eunify_2estoreSol_24s913555157x21100521_lam0(V self, V *args);
Clo g_heff_2eunify_2estoreSol_24s913555157x21100521_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2estoreSol_24s913555157x21100521_entry, 3, 0};

V g_heff_2eunify_2estoreSol_24s913555157x21100521(V v_m_240, V v_sol_241, V v_stx_242) {
top: ;
  return heff_tail(((V)&g_heff_2eunify_2euModify_24s1340946300x2077833874_clo), 1, (V[]){heff_clo(g_heff_2eunify_2estoreSol_24s913555157x21100521_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})});
}
V g_heff_2eunify_2estoreSol_24s913555157x21100521_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2estoreSol_24s913555157x21100521(a[0], a[1], a[2]);
}
V g_heff_2eunify_2estoreSol_24s913555157x21100521_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V a_0 = heff_dup(v_m_240); V b_1 = heff_get(heff_dup(v_c_243), LBL_metas); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_sol_241);
    heff_drop(v_stx_242);
    return v_c_243;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_rec(6, shape_ty__sol__solStx__arity__name__span, (V[]){heff_get(heff_dup(v_e_245), LBL_ty), heff_tag(TAG_Just, 1, (V[]){v_sol_241}), heff_tag(TAG_Just, 1, (V[]){v_stx_242}), heff_get(heff_dup(v_e_245), LBL_arity), heff_get(heff_dup(v_e_245), LBL_name), heff_get(v_e_245, LBL_span)});
    V v_mc_247 = (g_map_2einsert_24s1689409319x1710080871(v_m_240, v_t_246, heff_get(heff_dup(v_c_243), LBL_metas)));
    return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_243), LBL_infos), heff_get(heff_dup(v_c_243), LBL_recovered), heff_get(heff_dup(v_c_243), LBL_poisoned), v_mc_247, heff_get(heff_dup(v_c_243), LBL_nextMeta), heff_get(heff_dup(v_c_243), LBL_postponed), heff_get(heff_dup(v_c_243), LBL_trace), heff_get(v_c_243, LBL_selfKey)});
  }
  default: return heff_nomatch(v_t_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eunify_2etraceSolve_24s634453577x121216057_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 111, 108, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2etraceSolve_24s634453577x121216057_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eunify_2etraceSolve_24s634453577x121216057_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eunify_2etraceSolve_24s634453577x121216057_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 58, 61, 32}};
V g_heff_2eunify_2etraceSolve_24s634453577x121216057_lam1(V self, V *args);
V g_heff_2eunify_2etraceSolve_24s634453577x121216057_lam0(V self, V *args);
Clo g_heff_2eunify_2etraceSolve_24s634453577x121216057_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraceSolve_24s634453577x121216057_entry, 2, 0};

V g_heff_2eunify_2etraceSolve_24s634453577x121216057(V v_m_240, V v_stx_241) {
top: ;
  return heff_tail(((V)&g_heff_2eunify_2euModify_24s1340946300x2077833874_clo), 1, (V[]){heff_clo(g_heff_2eunify_2etraceSolve_24s634453577x121216057_lam0, 1, 2, (V[]){v_m_240, v_stx_241})});
}
V g_heff_2eunify_2etraceSolve_24s634453577x121216057_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2etraceSolve_24s634453577x121216057(a[0], a[1]);
}
V g_heff_2eunify_2etraceSolve_24s634453577x121216057_lam1(V self, V *args) {
  V v_u_245 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  V v_m_240 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_245);
  V v_t_246 = ({ V b_0 = heff_get(v_c_242, LBL_metas); V r_ = (g_heff_2eunify_2ezonker(b_0)); heff_drop(b_0); r_; });
  V v_e_247 = heff_tr(heff_apply(heff_get(v_t_246, LBL_el), 1, (V[]){v_stx_241}));
  V v_t_248 = (g_heff_2epsurface_2eelF_24s473646377x555746588(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_247));
  return heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s634453577x121216057_str1), heff_strAppend(heff_intShow(v_m_240), heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s634453577x121216057_str2), heff_strAppend(heff_get(v_e_244, LBL_name), heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s634453577x121216057_str3), v_t_248)))));
}
V g_heff_2eunify_2etraceSolve_24s634453577x121216057_lam0(V self, V *args) {
  V v_c_242 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = ({ V a_0 = heff_dup(v_m_240); V b_1 = heff_get(heff_dup(v_c_242), LBL_metas); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_stx_241);
    return v_c_242;
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_249 = heff_rec(3, shape_span__kind__text, (V[]){heff_get(heff_dup(v_e_244), LBL_span), ((V)&g_heff_2eunify_2etraceSolve_24s634453577x121216057_str0), heff_clo(g_heff_2eunify_2etraceSolve_24s634453577x121216057_lam1, 1, 4, (V[]){heff_dup(v_c_242), v_stx_241, v_m_240, v_e_244})});
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_get(heff_dup(v_c_242), LBL_trace)});
    return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_242), LBL_infos), heff_get(heff_dup(v_c_242), LBL_recovered), heff_get(heff_dup(v_c_242), LBL_poisoned), heff_get(heff_dup(v_c_242), LBL_metas), heff_get(heff_dup(v_c_242), LBL_nextMeta), heff_get(heff_dup(v_c_242), LBL_postponed), v_t_2410, heff_get(v_c_242, LBL_selfKey)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam2(V self, V *args); static Clo g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam2, 1, 0};
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam4(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam3(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam1(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam6(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam8(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam7(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam5(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam0(V self, V *args);
Clo g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_entry, 8, 0};

V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec(3, shape_dom__cod__ren, (V[]){heff_get(heff_dup(v_entry_243), LBL_arity), MK_INT(0LL), heff_dup(g_map_2eempty_get())});
  return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_get(heff_dup(v_entry_243), LBL_ty), heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esolveWithPruned_24s187873466x184247806(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam2(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get(v_c_2418, LBL_nextMeta);
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V f_ = v_k_2417;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_entry_243 = heff_env(self)[0];
  V v_arity_2410 = heff_env(self)[1];
  V v_ty_2415 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_243, v_arity_2410, v_ty_2415}));
  V v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euModify_24s1340946300x2077833874_clo), 1, (V[]){v_t_2422}));
  return heff_tail(v_c_2423, 2, (V[]){v_hd_2416, heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam4, 1, 2, (V[]){v_k_2417, v_x_2421})});
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_entry_243 = heff_env(self)[0];
  V v_arity_2410 = heff_env(self)[1];
  V v_ty_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam2_clo)})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2419}));
  V f_ = heff_get(heff_dup(v_hd_2416), LBL_bind);
  args[0] = v_t_2420;
  args[1] = heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam3, 1, 5, (V[]){v_entry_243, v_arity_2410, v_ty_2415, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam6(V self, V *args) {
  V v_i_2427 = args[0];
  V v_n_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_244, v_i_2427), MK_INT(1LL));
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  V f_ = v_k_247;
  args[0] = v_v_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2437);
  V v_c_2438 = heff_tr(g_heff_2eunify_2etraceSolve_24s634453577x121216057(v_storeM_242, v_t_2430));
  return heff_tail(v_c_2438, 2, (V[]){v_hd_246, heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam8, 1, 2, (V[]){v_k_247, v_v_2435})});
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam6, 1, 1, (V[]){heff_dup(v_n_244)}), v_kept_245));
  V v_t_2429 = heff_tag(TAG_SMetaApp, 3, (V[]){v_x_2426, heff_arrayFromList(v_t_2428), v_x_249});
  V v_t_2430 = (g_heff_2eunify_2elamsU(v_n_244, v_t_2429));
  V v_x1_2431 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2430), NTAG(TAG_LNil)));
  V v_v_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_v_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    v_v_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_v_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_c_2436 = heff_tr(g_heff_2eunify_2estoreSol_24s913555157x21100521(heff_dup(v_storeM_242), heff_dup(v_v_2435), heff_dup(v_t_2430)));
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam7, 1, 5, (V[]){v_storeM_242, v_t_2430, v_hd_246, v_k_247, v_v_2435})});
}
V g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_arity_2410 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  V v_x1_2411 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  V v_ty_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_ty_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_ty_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_ty_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_c_2425 = heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam1, 2, 3, (V[]){v_entry_243, v_arity_2410, v_ty_2415});
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_lam5, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})});
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam0, 1, 0};
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam2(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam2, 1, 0};
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam4(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam6(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam7(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam5(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam11(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam11, 2, 0};
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam12(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam13(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam13, 2, 0};
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam10(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam14(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam9(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam8(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam3(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameFlexF_24s593953928x917846983_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s593953928x917846983_entry, 7, 0};

V g_heff_2eunify_2erenameFlexF_24s593953928x917846983(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam0_clo)})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam1, 1, 7, (V[]){v_hd_245, heff_dup(v_sp_244), v_k_246, v_pr_242, v_m_27_243, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2erenameFlexF_24s593953928x917846983(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[4]); return r;
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get(v_c_247, LBL_metas);
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get(v_c_2411, LBL_selfKey);
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_PVar: {
    V v_l_2425 = heff_field(v_a_2424, 0);
    heff_take_n(v_a_2424, 1ULL, 1);
    V v_x3_2426 = ({ V a_0 = v_l_2425; V b_1 = heff_get(v_pr_242, LBL_ren); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2426)) {
    case TAG_Nothing: {
      v_x1_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2426, 0ULL, 1);
      v_x1_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2426);
    }
    break;
  }
  case TAG_PSelf: {
    heff_drop(v_pr_242);
    v_x1_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam6(V self, V *args) {
  V v_i_2432 = args[0];
  V v_a_2433 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2433)) {
  case TAG_PVar: {
    V v_l_2434 = heff_field(v_a_2433, 0);
    V v_ru_24a_2433_24PVar = heff_take_reuse_n(v_a_2433, 1ULL, 1);
    V v_x3_2435 = ({ V a_0 = v_l_2434; V b_1 = heff_get(v_pr_242, LBL_ren); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2435)) {
    case TAG_Nothing: {
      heff_drop(v_i_2432);
      heff_drop_cell(v_ru_24a_2433_24PVar, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2435, 0ULL, 1);
      return heff_tag_at(v_ru_24a_2433_24PVar, TAG_Just, 1, (V[]){v_i_2432});
    }
    default: return heff_nomatch(v_x3_2435);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2432);
    heff_drop(v_pr_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2433);
  }
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2441 = ({ V a_0 = v_x_2440; V a_1 = v_sp_244; V r_ = (g_heff_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_240, v_m_241, v_pr_242, v_v_2441, v_hd_245, v_k_246));
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_args_2423 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2431 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_args_2423));
  V v_t_2437 = (g_heff_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2423));
  V v_t_2438 = (g_heff_2eunify_2ecatMaybes(v_t_2437));
  V v_c_2439 = heff_tr(heff_apply(((V)&g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_clo), 6, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2430, v_t_2431, v_t_2438}));
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})});
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam11(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_t_2449 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2450}));
  V f_ = heff_get(v_hd_2447, LBL_bind);
  args[0] = v_t_2451;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam12(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2453);
  V v_t_2455 = heff_intSub(heff_get(v_pr_242, LBL_cod), v_l_27_2452);
  V f_ = v_k_2454;
  args[0] = heff_intSub(v_t_2455, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam13(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_t_2458 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2459}));
  V f_ = heff_get(v_hd_2456, LBL_bind);
  args[0] = v_t_2460;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam10(V self, V *args) {
  V v_a_2444 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2444)) {
  case TAG_PVar: {
    V v_l_2445 = heff_field(v_a_2444, 0);
    heff_take_n(v_a_2444, 1ULL, 1);
    V v_t_2446 = ({ V a_0 = v_l_2445; V b_1 = heff_get(heff_dup(v_pr_242), LBL_ren); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Nothing: {
      heff_drop(v_pr_242);
      return ((V)&g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam11_clo);
    }
    case TAG_Just: {
      V v_l_27_2452 = heff_field(v_t_2446, 0);
      heff_take_n(v_t_2446, 1ULL, 1);
      return heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam12, 2, 2, (V[]){v_pr_242, v_l_27_2452});
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_pr_242);
    return ((V)&g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam13_clo);
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam14(V self, V *args) {
  V v_x_2462 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2463 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2462), v_x_2443});
  V f_ = v_k_246;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2423 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2461 = (g_heff_2eunify_2etraverseU_24s427677288x1451739928(heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam10, 1, 1, (V[]){v_pr_242}), v_args_2423));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_245, heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam14, 1, 3, (V[]){v_m_27_243, v_x_2443, v_k_246})});
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2423 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get(v_x_2442, LBL_ty), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam9, 1, 5, (V[]){v_pr_242, v_args_2423, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_m_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = v_sp_244; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_t_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2416 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Just = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2416)));
    V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2417); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_tag_at(v_ru_24t_2415_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_items_2416))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2416);
      heff_drop_cell(v_ru_24t_2415_24Just, 1);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    heff_drop(v_sp_244);
    heff_drop(v_pr_242);
    heff_drop(v_m_27_243);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V v_t_2420 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2422, v_k_246});
  }
  case TAG_Just: {
    V v_args_2423 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    V v_t_2429 = (g_heff_2eunify_2eanyL(heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2423));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      return (g_heff_2eunify_2emetaEntry_24s1601622766x1299645529(heff_dup(v_m_27_243), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam5, 1, 8, (V[]){v_args_2423, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_sp_244, v_k_246})));
    }
    case TAG_False: {
      heff_drop(v_sp_244);
      return (g_heff_2eunify_2emetaEntry_24s1601622766x1299645529(heff_dup(v_m_27_243), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam8, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_hd_245, v_args_2423, v_m_27_243, v_k_246})));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  V v_m_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2eunify_2erenameFlexF_24s593953928x917846983_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_hd_245, v_k_246, v_pr_242, v_m_27_243, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam0(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam1(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam3(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam2(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam5(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam4(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam7(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam6(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam9(V self, V *args);
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam8(V self, V *args);
Clo g_heff_2eunify_2erenameClo_24s402172772x1190044452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameClo_24s402172772x1190044452_entry, 5, 0};

V g_heff_2eunify_2erenameClo_24s402172772x1190044452(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_cod), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_get(heff_dup(v_pr_242), LBL_dom), heff_get(heff_dup(v_pr_242), LBL_cod), heff_get(heff_dup(v_pr_242), LBL_ren)));
    V v_pr_2411 = heff_rec(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_pr_242, LBL_dom)});
    V v_v_2414 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2412, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_v_2416)) {
    case TAG_Nom: {
      V v_v_2417 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2417}));
      break;
    }
    case TAG_Describe: {
      V v_v_2418 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2418}));
      break;
    }
    case TAG_Become: {
      V v_v_2419 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419});
      break;
    }
    default: heff_nomatch(v_v_2416);
    }
    return heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_v_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2428}));
      break;
    }
    case TAG_Describe: {
      V v_v_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2429}));
      break;
    }
    case TAG_Become: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameClo_24s402172772x1190044452(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag(TAG_SIs, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_240, v_m_241, v_pr_2411, v_v_2419, v_hd_2420, heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag(TAG_SIs, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_240, v_m_241, v_pr_242, v_v_2430, v_hd_2431, heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo(g_heff_2eunify_2erenameClo_24s402172772x1190044452_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam0(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam2(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam3(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam4(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam5(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam7(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam6(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam10(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam9(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam12(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam11(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam8(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam13(V self, V *args);
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameF_24s1030639481x1219654980_entry, 6, 0};

V g_heff_2eunify_2erenameF_24s1030639481x1219654980(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameF_24s1030639481x1219654980(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_v0_243; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  return heff_tail(v_t_2418, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  return heff_tail(v_t_2422, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = (g_heff_2eunify_2erenameSpine_24s1422019577x129546631(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2429));
  return heff_tail(v_t_2430, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SCode, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SLam, 2, (V[]){v_x_2437, v_x_2453});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_fty_2433 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2434 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2438 = heff_tr(heff_apply(v_fty_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2439 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2438)));
  V v_t_2451;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2442 = heff_field(v_t_2439, 1);
    heff_take_n(v_t_2439, 2ULL, 4);
    heff_drop(v_t_2438);
    v_t_2451 = v_dom_2442;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2439, 0ULL, 3);
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeInt: {
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeString: {
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2451 = v_t_2438;
    break;
  }
  case TAG_NoRules: {
    v_t_2451 = v_t_2438;
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  V v_c_2452 = (g_heff_2eunify_2erenameClo_24s402172772x1190044452(v_g_240, v_m_241, v_pr_242, v_t_2451, v_body_2434));
  return heff_tail(v_c_2452, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam7, 1, 2, (V[]){v_k_245, v_x_2437})});
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam10(V self, V *args) {
  V v_x_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2465;
  args[0] = heff_tag(TAG_SIs, 1, (V[]){v_x_2466});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam9(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2463 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_240, v_m_241, v_pr_242, v_v_2463, v_hd_2464, heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam10, 1, 1, (V[]){v_k_2465})));
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam12(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_2469 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2469;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_k_2459, v_x_2470});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam11(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_c_2467 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2467;
  args[0] = v_hd_2468;
  args[1] = heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam12, 1, 2, (V[]){v_k_2469, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam8(V self, V *args) {
  V v_p_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2458)) {
  case TAG_MkPair: {
    V v_k_2459 = heff_field(v_p_2458, 0);
    V v_x_2460 = heff_field(v_p_2458, 1);
    heff_take_n(v_p_2458, 3ULL, 2);
    V v_c_2467;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_Nom: {
      V v_v_2461 = heff_field(v_x_2460, 0);
      heff_take_n(v_x_2460, 1ULL, 1);
      v_c_2467 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2461}));
      break;
    }
    case TAG_Describe: {
      V v_v_2462 = heff_field(v_x_2460, 0);
      heff_take_n(v_x_2460, 1ULL, 1);
      v_c_2467 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2462}));
      break;
    }
    case TAG_Become: {
      V v_v_2463 = heff_field(v_x_2460, 0);
      heff_take_n(v_x_2460, 1ULL, 1);
      v_c_2467 = heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam9, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2463});
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    return heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam11, 2, 2, (V[]){v_c_2467, v_k_2459});
  }
  default: return heff_nomatch(v_p_2458);
  }
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam13(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2473 = (g_prelude_2emap_24s1581021428x1223114127(heff_dup(v_x_2472)));
  V v_t_2474 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2472));
  V v_t_2475 = (g_prelude_2emap_24s531459667x996402587(v_x_2472));
  V v_t_2476 = heff_rec(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2473), v_t_2474, heff_arrayFromList(v_t_2475)});
  V v_x_2477 = heff_tag(TAG_SCons, 1, (V[]){v_t_2476});
  V f_ = v_k_245;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eunify_2erenameHead_24s1197776504x706394141(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eunify_2erenameHead_24s1197776504x706394141(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      V v_t_2424 = heff_intEq(heff_dup(v_m_27_2423), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        V v_t_2425 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2426 = heff_tag_at(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2426}));
        return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2427, v_k_245});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2423; V a_4 = v_sp_2411; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2eunify_2erenameFlexF_24s593953928x917846983(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2411); r_; });
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    case TAG_HError: {
      V v_c_2428 = (g_heff_2eunify_2erenameHead_24s1197776504x706394141(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(v_g_240, v_m_241, v_pr_242, v_t_2431, v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2433 = heff_field(v_x_249, 0);
    V v_body_2434 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_apply(heff_dup(v_fty_2433), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_c_2436 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2435}));
    return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam6, 1, 7, (V[]){v_fty_2433, v_g_240, v_m_241, v_pr_242, v_body_2434, v_hd_244, v_k_245})});
  }
  case TAG_VCons: {
    V v_d_2454 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2455 = heff_arrayToList(heff_get(heff_dup(v_d_2454), LBL_keys));
    V v_t_2456 = heff_arrayToList(heff_get(v_d_2454, LBL_values));
    V v_t_2457 = (g_heff_2edict_2ezipKV(v_t_2455, v_t_2456));
    V v_c_2471 = (g_heff_2eunify_2etraverseU_24s427677288x1451739928(heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2457));
    return heff_tail(v_c_2471, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s1030639481x1219654980_lam13, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam0, 1, 0};
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam2(V self, V *args);
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam1(V self, V *args);
Clo g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_entry, 4, 0};

V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400(V v_len_240, V v_v_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam1, 1, 4, (V[]){v_len_240, v_v_241, v_hd_242, v_k_243})});
}
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epoisonEl_24s1216569143x1261067400(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_ms_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2411 = ({ V a_0 = heff_get(heff_dup(v_c_2410), LBL_poisoned); V a_1 = v_ms_249; V r_ = (g_prelude_2efoldl_24s1377741640x1185496867(a_0, a_1)); heff_drop(v_ms_249); r_; });
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_2410), LBL_infos), heff_get(heff_dup(v_c_2410), LBL_recovered), v_ps_2411, heff_get(heff_dup(v_c_2410), LBL_metas), heff_get(heff_dup(v_c_2410), LBL_nextMeta), heff_get(heff_dup(v_c_2410), LBL_postponed), heff_get(heff_dup(v_c_2410), LBL_trace), heff_get(v_c_2410, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_247); r_; });
  V v_ms_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_mel), 3, (V[]){MK_INT(20LL), v_len_240, v_v_241}));
  return (g_heff_2eunify_2euModify_24s1340946300x2077833874(heff_clo(g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_lam2, 1, 1, (V[]){v_ms_249}), v_hd_242, v_k_243));
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam1(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam0(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam4(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam5(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam6(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam7(V self, V *args); static Clo g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam7, 2, 0};
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam3(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam2(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam11(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam13(V self, V *args); static Clo g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam13, 2, 0};
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam14(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam12(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam10(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam9(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam8(V self, V *args);
Clo g_heff_2eunify_2esolveRhs_24s86524727x216308409_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s86524727x216308409_entry, 5, 0};

V g_heff_2eunify_2esolveRhs_24s86524727x216308409(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244) {
top: ;
  V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_246 = (g_heff_2eunify_2emapWithIndexL_24s1417191219x117474904(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s848659184x39013903(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_pr_248 = heff_rec(3, shape_dom__cod__ren, (V[]){heff_get(v_cs_241, LBL_len), v_t_245, v_t_247});
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_242), v_pr_248, v_rhs_244}));
  V v_m_2413 = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam0, 2, 1, (V[]){v_c_249});
  V v_c_2446 = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam2, 2, 1, (V[]){v_m_2413});
  return heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam8, 2, 4, (V[]){v_c_2446, v_args_243, v_g_240, v_m_242});
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esolveRhs_24s86524727x216308409(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2411;
  args[0] = heff_tag(TAG_Just, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam1, 1, 1, (V[]){v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_s_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2423}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2424;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_s_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2430}));
  V f_ = heff_get(v_hd_2428, LBL_bind);
  args[0] = v_t_2431;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_s_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2439}));
  V f_ = heff_get(v_hd_2437, LBL_bind);
  args[0] = v_t_2440;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2443;
  switch (heff_tag_of(v_s_2417)) {
  case TAG_UnequalTys: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam4, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_UnequalEls: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam5, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_UnequalNeus: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam6, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_MentionsError: {
    v_c_2443 = ((V)&g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam7_clo);
    break;
  }
  default: heff_nomatch(v_s_2417);
  }
  return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_2414), heff_get(v_hd_2414, LBL_ret)});
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_m_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_apply(v_m_2413, 2, (V[]){heff_dup(v_hd_2414), heff_get(heff_dup(v_hd_2414), LBL_ret)}));
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Catch, 2, (V[]){v_t_2416, heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam3, 1, 1, (V[]){heff_dup(v_hd_2414)})})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(v_hd_2414, LBL_bind);
  args[0] = v_t_2445;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam11(V self, V *args) {
  V v_c_2460 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2461 = ({ V a_0 = v_m_242; V b_1 = heff_get(v_c_2460, LBL_poisoned); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2461)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2461, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2461);
  }
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam13(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  heff_drop(v_hd_2466);
  V f_ = v_k_2467;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam14(V self, V *args) {
  V v_x_2469 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2452 = heff_env(self)[1];
  V v_hd_2447 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_tr(g_heff_2eunify_2etraceSolve_24s634453577x121216057(v_m_242, v_t_2452));
  return heff_tail(v_t_2470, 2, (V[]){v_hd_2447, v_k_2448});
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam12(V self, V *args) {
  V v_x_2465 = args[0];
  V v_v_2457 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2452 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2468;
  switch (heff_tag_of(v_x_2465)) {
  case TAG_True: {
    v_c_2468 = heff_tr(heff_apply(((V)&g_heff_2eunify_2epoisonEl_24s1216569143x1261067400_clo), 2, (V[]){MK_INT(0LL), v_v_2457}));
    break;
  }
  case TAG_False: {
    heff_drop(v_v_2457);
    v_c_2468 = ((V)&g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam13_clo);
    break;
  }
  default: heff_nomatch(v_x_2465);
  }
  return heff_tail(v_c_2468, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam14, 1, 4, (V[]){v_m_242, v_t_2452, v_hd_2447, v_k_2448})});
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_v_2457 = heff_env(self)[2];
  V v_t_2452 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2459);
  V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam11, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2463}));
  return heff_tail(heff_get(heff_dup(v_hd_2447), LBL_bind), 2, (V[]){v_t_2464, heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam12, 1, 5, (V[]){v_v_2457, v_hd_2447, v_m_242, v_t_2452, v_k_2448})});
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop(v_hd_2447);
    V f_ = v_k_2448;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2450 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    V v_t_2451 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2452 = (g_heff_2eunify_2elamsU(v_t_2451, v_body_2450));
    V v_x1_2453 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2452), NTAG(TAG_LNil)));
    V v_v_2457;
    switch (heff_tag_of(v_x1_2453)) {
    case TAG_Nom: {
      V v_x_2454 = heff_field(v_x1_2453, 0);
      heff_take_n(v_x1_2453, 1ULL, 1);
      v_v_2457 = v_x_2454;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2453, 0ULL, 1);
      v_v_2457 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2456 = heff_field(v_x1_2453, 0);
      heff_take_n(v_x1_2453, 1ULL, 1);
      v_v_2457 = v_x_2456;
      break;
    }
    default: heff_nomatch(v_x1_2453);
    }
    V v_c_2458 = heff_tr(g_heff_2eunify_2estoreSol_24s913555157x21100521(heff_dup(v_m_242), heff_dup(v_v_2457), heff_dup(v_t_2452)));
    return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam10, 1, 5, (V[]){v_m_242, v_hd_2447, v_v_2457, v_t_2452, v_k_2448})});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam8(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo(g_heff_2eunify_2esolveRhs_24s86524727x216308409_lam9, 1, 5, (V[]){v_k_2448, v_args_243, v_g_240, v_m_242, v_hd_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam0(V self, V *args); static Clo g_heff_2eunify_2esolveF_24s190498893x664563428_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s190498893x664563428_lam0, 1, 0};
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam2(V self, V *args); static Clo g_heff_2eunify_2esolveF_24s190498893x664563428_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s190498893x664563428_lam2, 1, 0};
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam4(V self, V *args);
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam5(V self, V *args);
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam7(V self, V *args);
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam6(V self, V *args);
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam8(V self, V *args);
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam3(V self, V *args);
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam1(V self, V *args);
Clo g_heff_2eunify_2esolveF_24s190498893x664563428_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s190498893x664563428_entry, 8, 0};

V g_heff_2eunify_2esolveF_24s190498893x664563428(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveF_24s190498893x664563428_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam1, 1, 8, (V[]){v_hd_246, heff_dup(v_sp_243), v_cs_241, v_self_245, v_rhs_244, v_k_247, v_g_240, v_m_242})});
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esolveF_24s190498893x664563428(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[3]); return r;
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get(v_c_248, LBL_metas);
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get(v_c_2412, LBL_selfKey);
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam4(V self, V *args) {
  V v_c_2421 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_self_245 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_rec(4, shape_shape__left__right__failed, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_get(heff_dup(v_c_2421), LBL_postponed)});
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_2421), LBL_infos), heff_get(heff_dup(v_c_2421), LBL_recovered), heff_get(heff_dup(v_c_2421), LBL_poisoned), heff_get(heff_dup(v_c_2421), LBL_metas), heff_get(heff_dup(v_c_2421), LBL_nextMeta), v_t_2423, heff_get(heff_dup(v_c_2421), LBL_trace), heff_get(v_c_2421, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam5(V self, V *args) {
  V v_c_2448 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_self_245 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449 = heff_rec(4, shape_shape__left__right__failed, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){v_t_2449, heff_get(heff_dup(v_c_2448), LBL_postponed)});
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_2448), LBL_infos), heff_get(heff_dup(v_c_2448), LBL_recovered), heff_get(heff_dup(v_c_2448), LBL_poisoned), heff_get(heff_dup(v_c_2448), LBL_metas), heff_get(heff_dup(v_c_2448), LBL_nextMeta), v_t_2450, heff_get(heff_dup(v_c_2448), LBL_trace), heff_get(v_c_2448, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2462);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_args_2424 = heff_env(self)[0];
  V v_args_27_2451 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2457 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_args_2424));
  V v_t_2458 = (g_heff_2eunify_2ezipL(v_args_2424, v_args_27_2451));
  V v_t_2459 = (g_heff_2eunify_2emapWithIndexL_24s1102832539x1140239925(MK_INT(0LL), v_t_2458));
  V v_t_2460 = (g_heff_2eunify_2ecatMaybes(v_t_2459));
  V v_c_2461 = heff_tr(heff_apply(((V)&g_heff_2eunify_2esolveWithPruned_24s187873466x184247806_clo), 6, (V[]){v_g_240, heff_dup(v_m_242), v_m_242, v_x_2456, v_t_2457, v_t_2460}));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_246, heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam7, 1, 1, (V[]){v_k_247})});
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam8(V self, V *args) {
  V v_c_2463 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_self_245 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2464 = heff_rec(4, shape_shape__left__right__failed, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2465 = heff_tag(TAG_Cons, 2, (V[]){v_t_2464, heff_get(heff_dup(v_c_2463), LBL_postponed)});
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){heff_get(heff_dup(v_c_2463), LBL_infos), heff_get(heff_dup(v_c_2463), LBL_recovered), heff_get(heff_dup(v_c_2463), LBL_poisoned), heff_get(heff_dup(v_c_2463), LBL_metas), heff_get(heff_dup(v_c_2463), LBL_nextMeta), v_t_2465, heff_get(heff_dup(v_c_2463), LBL_trace), heff_get(v_c_2463, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_g_240 = heff_env(self)[7];
  V v_m_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = ({ V a_0 = heff_dup(v_x_2415); V a_1 = v_x_2411; V a_2 = v_sp_243; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_sp_243); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2417 = heff_field(v_t_2416, 0);
    V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 1ULL, 1);
    V v_t_2418 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2417)));
    V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2418); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      v_t_2420 = heff_tag_at(v_ru_24t_2416_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_items_2417))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2417);
      heff_drop_cell(v_ru_24t_2416_24Just, 1);
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    heff_drop(v_x_2415);
    heff_drop(v_x_2411);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    return (g_heff_2eunify_2euModify_24s1340946300x2077833874(heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam4, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_args_2424 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    V v_it_2437;
    switch (heff_tag_of(v_rhs_244)) {
    case TAG_VNeu: {
      V v_it1_2425 = heff_dup(heff_field(v_rhs_244, 0));
      V v_sp_2426 = heff_dup(heff_field(v_rhs_244, 1));
      switch (heff_tag_of(v_it1_2425)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2425, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2425, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2432 = heff_field(v_it1_2425, 0);
        heff_take_n(v_it1_2425, 1ULL, 1);
        v_it_2437 = heff_tag_at(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2432, v_sp_2426})});
        break;
      }
      case TAG_HError: {
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2425);
      }
      break;
    }
    case TAG_VCode: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VLam: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VCons: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VOpaque: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_rhs_244);
    }
    switch (heff_tag_of(v_it_2437)) {
    case TAG_Nothing: {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_self_245);
      V v_t_2438 = (g_heff_2eunify_2esolveRhs_24s86524727x216308409(v_g_240, v_cs_241, v_m_242, v_args_2424, v_rhs_244));
      return heff_tail(v_t_2438, 2, (V[]){v_hd_246, v_k_247});
    }
    case TAG_Just: {
      V v_it1_2439 = heff_field(v_it_2437, 0);
      V v_ru_24it_2437_24Just = heff_take_reuse_n(v_it_2437, 1ULL, 1);
      switch (heff_tag_of(v_it1_2439)) {
      case TAG_MkPair: {
        V v_m_27_2440 = heff_field(v_it1_2439, 0);
        V v_sp_27_2441 = heff_field(v_it1_2439, 1);
        heff_take_n(v_it1_2439, 3ULL, 2);
        V v_t_2442 = heff_intEq(v_m_27_2440, heff_dup(v_m_242));
        switch (heff_tag_of(v_t_2442)) {
        case TAG_True: {
          V v_t_2443 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_27_2441; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2411); heff_drop(v_sp_27_2441); r_; });
          V v_t_2447;
          switch (heff_tag_of(v_t_2443)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24it_2437_24Just, 1);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_items_2444 = heff_field(v_t_2443, 0);
            heff_take_n(v_t_2443, 1ULL, 1);
            V v_t_2445 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2444)));
            V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2445); r_; });
            switch (heff_tag_of(v_t_2446)) {
            case TAG_True: {
              v_t_2447 = heff_tag_at(v_ru_24it_2437_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_items_2444))});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2437_24Just, 1);
              heff_drop(v_items_2444);
              v_t_2447 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2446);
            }
            break;
          }
          default: heff_nomatch(v_t_2443);
          }
          switch (heff_tag_of(v_t_2447)) {
          case TAG_Nothing: {
            heff_drop(v_g_240);
            heff_drop(v_m_242);
            heff_drop(v_args_2424);
            return (g_heff_2eunify_2euModify_24s1340946300x2077833874(heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam5, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
          }
          case TAG_Just: {
            V v_args_27_2451 = heff_field(v_t_2447, 0);
            heff_take_n(v_t_2447, 1ULL, 1);
            V v_t_2452 = (g_heff_2eunify_2eeqPatArgs(v_args_27_2451, v_args_2424));
            switch (heff_tag_of(v_t_2452)) {
            case TAG_True: {
              heff_drop(v_cs_241);
              heff_drop(v_self_245);
              heff_drop(v_rhs_244);
              heff_drop(v_hd_246);
              heff_drop(v_g_240);
              heff_drop(v_m_242);
              heff_drop(v_args_2424);
              heff_drop(v_args_27_2451);
              V f_ = v_k_247;
              args[0] = NTAG(TAG_MkUnit);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_False: {
              V v_t_2453 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_args_27_2451));
              V v_t_2454 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_args_2424));
              V v_t_2455 = heff_intEq(v_t_2453, v_t_2454);
              switch (heff_tag_of(v_t_2455)) {
              case TAG_True: {
                heff_drop(v_cs_241);
                heff_drop(v_self_245);
                heff_drop(v_rhs_244);
                return (g_heff_2eunify_2emetaEntry_24s1601622766x1299645529(heff_dup(v_m_242), heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam6, 1, 6, (V[]){v_args_2424, v_args_27_2451, v_g_240, v_m_242, v_hd_246, v_k_247})));
              }
              case TAG_False: {
                heff_drop(v_g_240);
                heff_drop(v_m_242);
                heff_drop(v_args_2424);
                heff_drop(v_args_27_2451);
                return (g_heff_2eunify_2euModify_24s1340946300x2077833874(heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam8, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
              }
              default: return heff_nomatch(v_t_2455);
              }
            }
            default: return heff_nomatch(v_t_2452);
            }
          }
          default: return heff_nomatch(v_t_2447);
          }
        }
        case TAG_False: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          heff_drop_cell(v_ru_24it_2437_24Just, 1);
          heff_drop(v_sp_27_2441);
          V v_t_2466 = (g_heff_2eunify_2esolveRhs_24s86524727x216308409(v_g_240, v_cs_241, v_m_242, v_args_2424, v_rhs_244));
          return heff_tail(v_t_2466, 2, (V[]){v_hd_246, v_k_247});
        }
        default: return heff_nomatch(v_t_2442);
        }
      }
      default: return heff_nomatch(v_it1_2439);
      }
    }
    default: return heff_nomatch(v_it_2437);
    }
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2eunify_2esolveF_24s190498893x664563428_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_m_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveF_24s190498893x664563428_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2eunify_2esolveF_24s190498893x664563428_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247, v_g_240, v_m_242})});
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam0(V self, V *args); static Clo g_heff_2eunify_2euk_24s99985437x1876045342_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euk_24s99985437x1876045342_lam0, 4, 0};
V g_heff_2eunify_2euk_24s99985437x1876045342_lam3(V self, V *args);
V g_heff_2eunify_2euk_24s99985437x1876045342_lam2(V self, V *args);
V g_heff_2eunify_2euk_24s99985437x1876045342_lam1(V self, V *args); static Clo g_heff_2eunify_2euk_24s99985437x1876045342_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euk_24s99985437x1876045342_lam1, 4, 0};
V g_heff_2eunify_2euk_24s99985437x1876045342_lam6(V self, V *args);
V g_heff_2eunify_2euk_24s99985437x1876045342_lam5(V self, V *args);
V g_heff_2eunify_2euk_24s99985437x1876045342_lam4(V self, V *args); static Clo g_heff_2eunify_2euk_24s99985437x1876045342_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euk_24s99985437x1876045342_lam4, 4, 0};

static V g_heff_2eunify_2euk_24s99985437x1876045342_val;
static int g_heff_2eunify_2euk_24s99985437x1876045342_st;
static V g_heff_2eunify_2euk_24s99985437x1876045342_init(void) {
  return heff_rec(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eunify_2euTypeF_24s957014611x2143677719_clo), ((V)&g_heff_2eunify_2euk_24s99985437x1876045342_lam0_clo), ((V)&g_heff_2eunify_2euBareF_24s1294623001x1737536464_clo), ((V)&g_heff_2eunify_2esolveF_24s190498893x664563428_clo), ((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo), ((V)&g_heff_2eunify_2euk_24s99985437x1876045342_lam1_clo), ((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo), ((V)&g_heff_2eunify_2euk_24s99985437x1876045342_lam4_clo), ((V)&g_heff_2eunify_2erenameFlexF_24s593953928x917846983_clo)});
}
V g_heff_2eunify_2euk_24s99985437x1876045342_get(void) {
  if (g_heff_2eunify_2euk_24s99985437x1876045342_st == 2) return g_heff_2eunify_2euk_24s99985437x1876045342_val;
  if (g_heff_2eunify_2euk_24s99985437x1876045342_st == 1) heff_fail("defined by itself");
  g_heff_2eunify_2euk_24s99985437x1876045342_st = 1;
  g_heff_2eunify_2euk_24s99985437x1876045342_val = heff_tr(g_heff_2eunify_2euk_24s99985437x1876045342_init());
  g_heff_2eunify_2euk_24s99985437x1876045342_st = 2;
  return g_heff_2eunify_2euk_24s99985437x1876045342_val;
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s99985437x1876045342_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameF_24s1030639481x1219654980(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo(g_heff_2eunify_2euk_24s99985437x1876045342_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eunify_2erenameF_24s1030639481x1219654980_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo(g_heff_2eunify_2euk_24s99985437x1876045342_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eunify_2erenameTypeF_24s10960290x2138199522(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo(g_heff_2eunify_2euk_24s99985437x1876045342_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eunify_2euk_24s99985437x1876045342_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eunify_2erenameTypeF_24s10960290x2138199522_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo(g_heff_2eunify_2euk_24s99985437x1876045342_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam0(V self, V *args);
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam2(V self, V *args);
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam4(V self, V *args);
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam3(V self, V *args);
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam1(V self, V *args);
Clo g_heff_2eunify_2euTypeF_24s957014611x2143677719_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTypeF_24s957014611x2143677719_entry, 6, 0};

V g_heff_2eunify_2euTypeF_24s957014611x2143677719(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euTypeF_24s957014611x2143677719(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_a0_242; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2410, LBL_metas); V a_1 = v_b0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam4(V self, V *args) {
  V v_x_2458 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2458);
  return (g_heff_2eunify_2epoisonTy_24s1250827093x1392482448(heff_get(v_cs_241, LBL_len), v_x_2413, v_hd_244, v_k_245));
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2457;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_True: {
    v_t_2457 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2437 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2437)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2457 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2437);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  switch (heff_tag_of(v_t_2457)) {
  case TAG_True: {
    heff_drop(v_g_240);
    return (g_heff_2eunify_2epoisonTy_24s1250827093x1392482448(heff_get(heff_dup(v_cs_241), LBL_len), v_x_249, heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam4, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245})));
  }
  case TAG_False: {
    V v_it_2480;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2460 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2461 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_it1_2460)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2460, 0ULL, 1);
        heff_drop(v_sp_2461);
        v_it_2480 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2460, 0ULL, 1);
        heff_drop(v_sp_2461);
        v_it_2480 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2467 = heff_field(v_it1_2460, 0);
        V v_ru_24it1_2460_24HMeta = heff_take_reuse_n(v_it1_2460, 1ULL, 1);
        v_it_2480 = heff_tag_at(v_ru_24it1_2460_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2467, v_sp_2461})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2461);
        v_it_2480 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2460);
      }
      break;
    }
    case TAG_VFunction: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_it_2480 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_it_2480)) {
    case TAG_Nothing: {
      V v_it_24102;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_it1_2482 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2483 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_it1_2482)) {
        case TAG_HLocal: {
          heff_take_n(v_it1_2482, 0ULL, 1);
          heff_drop(v_sp_2483);
          v_it_24102 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_it1_2482, 0ULL, 1);
          heff_drop(v_sp_2483);
          v_it_24102 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_2489 = heff_field(v_it1_2482, 0);
          V v_ru_24it1_2482_24HMeta = heff_take_reuse_n(v_it1_2482, 1ULL, 1);
          v_it_24102 = heff_tag_at(v_ru_24it1_2482_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2489, v_sp_2483})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2483);
          v_it_24102 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_it1_2482);
        }
        break;
      }
      case TAG_VFunction: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_it_24102 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_it_24102)) {
      case TAG_Nothing: {
        V v_t_24103 = ({ V a_0 = heff_dup(g_co_2eplus_24s645371449x668519272_get()); V b_1 = ((V)&g_heff_2eunify_2emsEv_clo); V a_2 = ((V)&g_heff_2eunify_2eufEv_clo); V a_3 = heff_dup(g_heff_2eunify_2euk_24s99985437x1876045342_get()); V a_4 = v_g_240; V a_5 = v_cs_241; V a_6 = v_x_249; V a_7 = v_x_2413; V r_ = heff_tr(g_heff_2eunify_2euTyRigid(a_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(b_1); r_; });
        return heff_tail(v_t_24103, 2, (V[]){v_hd_244, v_k_245});
      }
      case TAG_Just: {
        V v_it1_24104 = heff_field(v_it_24102, 0);
        V v_ru_24it_24102_24Just = heff_take_reuse_n(v_it_24102, 1ULL, 1);
        switch (heff_tag_of(v_it1_24104)) {
        case TAG_MkPair: {
          V v_m_24105 = heff_field(v_it1_24104, 0);
          V v_sp_24106 = heff_field(v_it1_24104, 1);
          heff_take_n(v_it1_24104, 3ULL, 2);
          V v_rhs_24125;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24112 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24it_24102_24Just, 1);
            v_rhs_24125 = heff_tr(heff_apply(v_el_24112, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24125 = heff_tag_at(v_ru_24it_24102_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24144;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24131 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24144 = heff_tr(heff_apply(v_el_24131, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24144 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24105; V a_3 = v_sp_24106; V a_4 = v_rhs_24125; V a_5 = v_self_24144; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eunify_2esolveF_24s190498893x664563428(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24106); r_; });
        }
        default: return heff_nomatch(v_it1_24104);
        }
      }
      default: return heff_nomatch(v_it_24102);
      }
    }
    case TAG_Just: {
      V v_it1_24145 = heff_field(v_it_2480, 0);
      V v_ru_24it_2480_24Just = heff_take_reuse_n(v_it_2480, 1ULL, 1);
      switch (heff_tag_of(v_it1_24145)) {
      case TAG_MkPair: {
        V v_m_24146 = heff_field(v_it1_24145, 0);
        V v_sp_24147 = heff_field(v_it1_24145, 1);
        heff_take_n(v_it1_24145, 3ULL, 2);
        V v_rhs_24166;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24153 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24it_2480_24Just, 1);
          v_rhs_24166 = heff_tr(heff_apply(v_el_24153, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24166 = heff_tag_at(v_ru_24it_2480_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24185;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24172 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24185 = heff_tr(heff_apply(v_el_24172, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24185 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24146; V a_3 = v_sp_24147; V a_4 = v_rhs_24166; V a_5 = v_self_24185; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eunify_2esolveF_24s190498893x664563428(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24147); r_; });
      }
      default: return heff_nomatch(v_it1_24145);
      }
    }
    default: return heff_nomatch(v_it_2480);
    }
  }
  default: return heff_nomatch(v_t_2457);
  }
}
V g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2eunify_2euTypeF_24s957014611x2143677719_lam3, 1, 5, (V[]){v_x_249, v_cs_241, v_hd_244, v_k_245, v_g_240})});
}