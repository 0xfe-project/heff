// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eunify_2euModify_lam1(V self, V *args);
V g_heff_2eunify_2euModify_lam0(V self, V *args);
V g_heff_2eunify_2euModify_lam4(V self, V *args);
V g_heff_2eunify_2euModify_lam3(V self, V *args);
V g_heff_2eunify_2euModify_lam2(V self, V *args);
Clo g_heff_2eunify_2euModify_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euModify_entry, 4, 0};

V g_heff_2eunify_2euModify(V v_w_240, V v_ms_241, V v_uf_242, V v_f_243) {
top: ;
  V v_p_244 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_243})}));
  V v_c_2410 = heff_clo(g_heff_2eunify_2euModify_lam0, 2, 2, (V[]){heff_dup(v_w_240), v_p_244});
  return heff_clo(g_heff_2eunify_2euModify_lam2, 2, 3, (V[]){v_c_2410, v_ms_241, v_w_240});
}
V g_heff_2eunify_2euModify_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euModify(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2eunify_2euModify_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_245), heff_get(v_hd_245, LBL_ret)});
}
V g_heff_2eunify_2euModify_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_248 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euModify_lam1, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_249, v_k2_246});
}
V g_heff_2eunify_2euModify_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_2411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2411), heff_get(v_hd_2411, LBL_ret)});
}
V g_heff_2eunify_2euModify_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ms_241 = heff_dup(heff_env(self)[0]);
  V v_w_240 = heff_dup(heff_env(self)[1]);
  V v_hd_2411 = heff_dup(heff_env(self)[2]);
  V v_k_2412 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2414 = heff_tag(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_p_2415 = heff_tr(heff_apply(v_ms_241, 1, (V[]){v_t_2414}));
  V v_t_2417 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euModify_lam4, 1, 1, (V[]){heff_dup(v_hd_2411)}), v_p_2415}));
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2418, v_k_2412});
}
V g_heff_2eunify_2euModify_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_dup(heff_env(self)[0]);
  V v_ms_241 = heff_dup(heff_env(self)[1]);
  V v_w_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2eunify_2euModify_lam3, 1, 4, (V[]){v_ms_241, v_w_240, v_hd_2411, v_k_2412})});
}
Clo g_heff_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          v_t_2411 = heff_intEq(heff_dup(v_l_248), heff_dup(v_l_27_249));
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_t_2411);
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_t_2411);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eeqPatArgs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take(v_x11_241, 1ULL);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, (g_heff_2eunify_2epatVarsOf(v_rest_242))});
    }
    case TAG_PSelf: {
      heff_drop(v_x11_241);
      heff_drop(v_ru_24x1_240_24Cons);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epatVarsOf(a[0]);
}
V g_heff_2eunify_2edistinct_lam0(V self, V *args);
Clo g_heff_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_244 = (g_prelude_2eany(heff_clo(g_heff_2eunify_2edistinct_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      heff_drop(v_x1_244);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_x1_244);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2edistinct(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2edistinct_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_intEq(v_x_241, v_b_243);
}
Clo g_heff_2eunify_2epatStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatStep_entry, 3, 0};

V g_heff_2eunify_2epatStep(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_selfKey_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse(v_x3_242, 1ULL);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_it1_244 = heff_field(v_v_241, 0);
      V v_it2_245 = heff_field(v_v_241, 1);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_it1_244, 0);
        heff_drop(v_selfKey_240);
        switch (heff_tag_of(v_it2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){heff_dup(v_l_249)}), v_rest_243});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2410});
        }
        case TAG_SpApp: {
          heff_drop(v_rest_243);
          heff_drop(v_ru_24x3_242_24Just);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_rest_243);
          heff_drop(v_ru_24x3_242_24Just);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_rest_243);
          heff_drop(v_ru_24x3_242_24Just);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_245);
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_it1_244, 0);
        switch (heff_tag_of(v_it2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_selfKey_240);
            heff_drop(v_rest_243);
            heff_drop(v_ru_24x3_242_24Just);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            heff_take(v_selfKey_240, 1ULL);
            V v_t_2420 = heff_strEq(v_sk_2419, heff_dup(v_k_2418));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_True: {
              heff_drop(v_t_2420);
              V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return heff_tag_at(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
            }
            case TAG_False: {
              heff_drop(v_rest_243);
              heff_drop(v_ru_24x3_242_24Just);
              heff_drop(v_t_2420);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
          default: return heff_nomatch(v_selfKey_240);
          }
        }
        case TAG_SpApp: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop(v_ru_24x3_242_24Just);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop(v_ru_24x3_242_24Just);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop(v_ru_24x3_242_24Just);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_245);
        }
      }
      case TAG_HMeta: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop(v_ru_24x3_242_24Just);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop(v_ru_24x3_242_24Just);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it1_244);
      }
    }
    case TAG_VCode: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop(v_ru_24x3_242_24Just);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop(v_ru_24x3_242_24Just);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop(v_ru_24x3_242_24Just);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop(v_ru_24x3_242_24Just);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_v_241);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2epatStep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epatStep(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop(v_selfKey_240);
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2evalue_2eforceEl(v_mc_241, heff_dup(v_v_244)));
    V v_t_246 = (g_heff_2eunify_2epatSpine(heff_dup(v_selfKey_240), v_mc_241, v_s_243));
    return ({ V a_0 = v_selfKey_240; V a_1 = v_t_245; V a_2 = v_t_246; V r_ = (g_heff_2eunify_2epatStep(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_SpProj: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epatSpine(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eunify_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2enth_entry, 2, 0};

V g_heff_2eunify_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      heff_drop(v_t_244);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        heff_drop(v_t_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        heff_drop(v_t_245);
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2enth_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2enth(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eunify_2emapWithIndexL(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x2_241);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop(v_ru_24x1_240_24Cons);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take(v_x2_241, 3ULL);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eunify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x11_241);
      heff_drop(v_ru_24x1_240_24Cons);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take(v_x11_241, 1ULL);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eunify_2ecatMaybes(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2ecatMaybes(a[0]);
}
Clo g_heff_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eanyL(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eunify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eunify_2econcatMapL(v_f_240, v_xs_243));
    return (g_heff_2eunify_2eappendL(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2econcatMapL(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2eforU_lam0(V self, V *args); static Clo g_heff_2eunify_2eforU_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eforU_lam0, 2, 0};
V g_heff_2eunify_2eforU_lam2(V self, V *args);
V g_heff_2eunify_2eforU_lam1(V self, V *args);
Clo g_heff_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eforU_entry, 5, 0};

V g_heff_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    return ((V)&g_heff_2eunify_2eforU_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_apply(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_clo(g_heff_2eunify_2eforU_lam1, 2, 6, (V[]){v_c_249, heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eforU(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eunify_2eforU_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(self);
  heff_drop(v_hd_245);
  return heff_tail(v_k_246, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2eforU_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_ms_241 = heff_dup(heff_env(self)[1]);
  V v_uf_242 = heff_dup(heff_env(self)[2]);
  V v_xs_248 = heff_dup(heff_env(self)[3]);
  V v_f_244 = heff_dup(heff_env(self)[4]);
  V v_hd_2410 = heff_dup(heff_env(self)[5]);
  V v_k_2411 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  heff_drop(v_x_2412);
  V v_t_2413 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V r_ = (g_heff_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_2410, v_k_2411});
}
V g_heff_2eunify_2eforU_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_dup(heff_env(self)[0]);
  V v_w_240 = heff_dup(heff_env(self)[1]);
  V v_ms_241 = heff_dup(heff_env(self)[2]);
  V v_uf_242 = heff_dup(heff_env(self)[3]);
  V v_xs_248 = heff_dup(heff_env(self)[4]);
  V v_f_244 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_2410), heff_clo(g_heff_2eunify_2eforU_lam2, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_xs_248, v_f_244, v_hd_2410, v_k_2411})});
}
V g_heff_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_depth_242), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    heff_drop(v_t_245);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_it_246 = (g_heff_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_246)) {
    case TAG_VNeu: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_sp_248 = heff_field(v_it_246, 1);
      heff_take(v_it_246, 3ULL);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_HLocal: {
        heff_take(v_it1_247, 0ULL);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HGlobal: {
        heff_take(v_it1_247, 0ULL);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HMeta: {
        V v_m_2414 = heff_field(v_it1_247, 0);
        heff_take(v_it1_247, 1ULL);
        V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248}));
        return heff_tag(TAG_Cons, 2, (V[]){v_m_2414, v_t_2415});
      }
      case TAG_HError: {
        heff_drop(v_it1_247);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    case TAG_VCode: {
      V v_t_2416 = heff_field(v_it_246, 0);
      heff_take(v_it_246, 1ULL);
      return heff_tail(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2416});
    }
    case TAG_VLam: {
      V v_d_2417 = heff_field(v_it_246, 0);
      V v_c_2418 = heff_field(v_it_246, 1);
      heff_take(v_it_246, 3ULL);
      V v_x1_2438;
      switch (heff_tag_of(v_c_2418)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_c_2418, 1);
        V v_body_2421 = heff_field(v_c_2418, 2);
        heff_take(v_c_2418, 6ULL);
        v_x1_2438 = heff_tr(heff_apply(v_body_2421, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo(g_heff_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2417, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2437 = heff_field(v_c_2418, 0);
        heff_take(v_c_2418, 1ULL);
        heff_drop(v_d_2417);
        v_x1_2438 = v_body_2437;
        break;
      }
      default: heff_nomatch(v_c_2418);
      }
      V v_t_2442;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_Nom: {
        V v_x_2439 = heff_field(v_x1_2438, 0);
        heff_take(v_x1_2438, 1ULL);
        v_t_2442 = v_x_2439;
        break;
      }
      case TAG_Describe: {
        heff_take(v_x1_2438, 0ULL);
        v_t_2442 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2441 = heff_field(v_x1_2438, 0);
        heff_take(v_x1_2438, 1ULL);
        v_t_2442 = v_x_2441;
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2442});
    }
    case TAG_VCons: {
      V v_d_2443 = heff_field(v_it_246, 0);
      heff_take(v_it_246, 1ULL);
      V v_t_2444 = heff_arrayToList(heff_get(v_d_2443, LBL_values));
      return ({ V a_0 = heff_clo(g_heff_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_r_240, v_depth_242, v_len_243}); V a_1 = v_t_2444; V r_ = (g_heff_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2444); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      heff_drop(v_it_246);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasTermF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2436 = args[0];
  V v_a_2435 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2436);
  return v_a_2435;
}
V g_heff_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2417 = heff_dup(heff_env(self)[0]);
  V v_len_243 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_apply(v_d_2417, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2423)));
  V v_a_2435;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take(v_t_2424, 0ULL);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2427 = heff_field(v_t_2424, 1);
    heff_take(v_t_2424, 2ULL);
    heff_drop(v_t_2423);
    v_a_2435 = v_dom_2427;
    break;
  }
  case TAG_LikeRecord: {
    heff_take(v_t_2424, 0ULL);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeSum: {
    heff_take(v_t_2424, 0ULL);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_t_2424);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_t_2424);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_t_2424);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeArray: {
    heff_take(v_t_2424, 0ULL);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_NoRules: {
    heff_drop(v_t_2424);
    v_a_2435 = v_t_2423;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  return (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2435}), NTAG(TAG_Nothing)));
}
V g_heff_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2445 = args[0];
  V v_r_240 = heff_dup(heff_env(self)[0]);
  V v_depth_242 = heff_dup(heff_env(self)[1]);
  V v_len_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2449;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Nom: {
    V v_x_2446 = heff_field(v_x_2445, 0);
    heff_take(v_x_2445, 1ULL);
    v_t_2449 = v_x_2446;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x_2445, 0ULL);
    v_t_2449 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2448 = heff_field(v_x_2445, 0);
    heff_take(v_x_2445, 1ULL);
    v_t_2449 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2449});
}
V g_heff_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_depth_242), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    heff_drop(v_t_245);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take(v_t_246, 0ULL);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take(v_t_246, 16ULL);
      V v_t_2413 = heff_tr(heff_apply(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take(v_t_246, 6ULL);
      V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_mty), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2425;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_cod_2416, 1);
        V v_body_2421 = heff_field(v_cod_2416, 2);
        heff_take(v_cod_2416, 6ULL);
        v_x1_2425 = heff_tr(heff_apply(v_body_2421, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo(g_heff_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2424 = heff_field(v_cod_2416, 0);
        heff_take(v_cod_2416, 1ULL);
        heff_drop(v_dom_2415);
        v_x1_2425 = v_body_2424;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2429;
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nom: {
        V v_x_2426 = heff_field(v_x1_2425, 0);
        heff_take(v_x1_2425, 1ULL);
        v_t_2429 = v_x_2426;
        break;
      }
      case TAG_Describe: {
        heff_take(v_x1_2425, 0ULL);
        v_t_2429 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2428 = heff_field(v_x1_2425, 0);
        heff_take(v_x1_2425, 1ULL);
        v_t_2429 = v_x_2428;
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
      V v_t_2430 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2429}));
      return (g_heff_2eunify_2eappendL(v_t_2418, v_t_2430));
    }
    case TAG_VRecord: {
      heff_take(v_t_246, 0ULL);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take(v_t_246, 0ULL);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      heff_drop(v_t_246);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      heff_drop(v_t_246);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      heff_drop(v_t_246);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2435 = heff_field(v_t_246, 0);
      heff_take(v_t_246, 1ULL);
      return heff_tail(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2435});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasTypeF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2423 = args[0];
  V v_dom_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2423);
  return v_dom_2415;
}
V g_heff_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_len_243 = heff_dup(heff_env(self)[0]);
  V v_dom_2415 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_u_2422);
  return (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_msp), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_msp), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasSpF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); heff_drop(a[4]); return r;
}
V g_heff_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec(3, shape_179_187_186, (V[]){heff_clo(g_heff_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasK(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2412 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eunify_2epoisonEl_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonEl_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_lam0, 1, 0};
V g_heff_2eunify_2epoisonEl_lam2(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam1(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam5(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam4(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam3(V self, V *args);
Clo g_heff_2eunify_2epoisonEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_entry, 5, 0};

V g_heff_2eunify_2epoisonEl(V v_w_240, V v_ms_241, V v_uf_242, V v_len_243, V v_v_244) {
top: ;
  V v_p_246 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonEl_lam0_clo)})}));
  V v_c_2412 = heff_clo(g_heff_2eunify_2epoisonEl_lam1, 2, 2, (V[]){heff_dup(v_w_240), v_p_246});
  return heff_clo(g_heff_2eunify_2epoisonEl_lam3, 2, 6, (V[]){v_c_2412, v_len_243, v_v_244, v_w_240, v_ms_241, heff_dup(v_uf_242)});
}
V g_heff_2eunify_2epoisonEl_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epoisonEl(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eunify_2epoisonEl_lam0(V self, V *args) {
  V v_c_245 = args[0];
  heff_drop(self);
  return heff_get(v_c_245, LBL_metas);
}
V g_heff_2eunify_2epoisonEl_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_247), heff_get(v_hd_247, LBL_ret)});
}
V g_heff_2eunify_2epoisonEl_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_246 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2410 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2epoisonEl_lam2, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2411, v_k2_248});
}
V g_heff_2eunify_2epoisonEl_lam5(V self, V *args) {
  V v_c_2418 = args[0];
  V v_ms_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_ps_2419 = ({ V a_0 = heff_get(heff_dup(v_c_2418), LBL_poisoned); V a_1 = v_ms_2417; V r_ = (g_prelude_2efoldl_24s315(a_0, a_1)); heff_drop(v_ms_2417); r_; });
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_2418), LBL_infos), heff_get(heff_dup(v_c_2418), LBL_recovered), v_ps_2419, heff_get(heff_dup(v_c_2418), LBL_metas), heff_get(heff_dup(v_c_2418), LBL_nextMeta), heff_get(heff_dup(v_c_2418), LBL_postponed), heff_get(heff_dup(v_c_2418), LBL_trace), heff_get(v_c_2418, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonEl_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_len_243 = heff_dup(heff_env(self)[0]);
  V v_v_244 = heff_dup(heff_env(self)[1]);
  V v_w_240 = heff_dup(heff_env(self)[2]);
  V v_ms_241 = heff_dup(heff_env(self)[3]);
  V v_uf_242 = heff_dup(heff_env(self)[4]);
  V v_hd_2413 = heff_dup(heff_env(self)[5]);
  V v_k_2414 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_2416 = ({ V a_0 = v_x_2415; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_2415); r_; });
  V v_ms_2417 = heff_tr(heff_apply(heff_get(v_t_2416, LBL_mel), 3, (V[]){MK_INT(20LL), v_len_243, v_v_244}));
  V v_t_2420 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = heff_clo(g_heff_2eunify_2epoisonEl_lam5, 1, 1, (V[]){v_ms_2417}); V r_ = (g_heff_2eunify_2euModify(a_0, a_1, a_2, a_3)); heff_drop(v_uf_242); r_; });
  return heff_tail(v_t_2420, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2eunify_2epoisonEl_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_dup(heff_env(self)[0]);
  V v_len_243 = heff_dup(heff_env(self)[1]);
  V v_v_244 = heff_dup(heff_env(self)[2]);
  V v_w_240 = heff_dup(heff_env(self)[3]);
  V v_ms_241 = heff_dup(heff_env(self)[4]);
  V v_uf_242 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2eunify_2epoisonEl_lam4, 1, 7, (V[]){v_len_243, v_v_244, v_w_240, v_ms_241, v_uf_242, v_hd_2413, v_k_2414})});
}
V g_heff_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse(v_t_243, 1ULL);
    heff_drop(v_r_240);
    V v_t_245 = heff_intLt(heff_dup(v_i_244), heff_dup(v_d_242));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_d_242);
      heff_drop(v_t_245);
      return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_246 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      V v_t_248 = (g_heff_2eunify_2enth(v_idxs_241, v_t_247));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_242);
        heff_drop(v_t_248);
        return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
      }
      case TAG_Just: {
        V v_j_249 = heff_field(v_t_248, 0);
        heff_take(v_t_248, 1ULL);
        heff_drop(v_i_244);
        return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_249, v_d_242)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_SGlobal: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse(v_t_243, 1ULL);
    V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty_2411}));
    return heff_tag_at(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_t_243, 0);
    V v_a_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse(v_t_243, 3ULL);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_f_2413}));
    V v_t_2416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_a_2414}));
    return heff_tag_at(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_dd_2417 = heff_field(v_t_243, 0);
    V v_it2_2418 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse(v_t_243, 3ULL);
    switch (heff_tag_of(v_it2_2418)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_it2_2418, 0);
      V v_b_2420 = heff_field(v_it2_2418, 1);
      heff_take(v_it2_2418, 3ULL);
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2420}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2419, v_t_2422})});
    }
    case TAG_AbsConst: {
      V v_b_2423 = heff_field(v_it2_2418, 0);
      heff_take(v_it2_2418, 1ULL);
      V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2425 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2423}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2425})});
    }
    default: return heff_nomatch(v_it2_2418);
    }
  }
  case TAG_SCons: {
    V v_dct_2426 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse(v_t_243, 1ULL);
    V v_f_2427 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_xs_2428 = heff_get(heff_dup(v_dct_2426), LBL_values);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo(g_heff_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    V v_t_2432 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_dct_2426), LBL_keys), heff_get(v_dct_2426, LBL_byName), v_t_2431});
    return heff_tag_at(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2432});
  }
  case TAG_SProj: {
    V v_e_2433 = heff_field(v_t_243, 0);
    V v_l_2434 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse(v_t_243, 3ULL);
    V v_t_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2433}));
    return heff_tag_at(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2435, v_l_2434});
  }
  case TAG_STag: {
    V v_x_2436 = heff_field(v_t_243, 0);
    V v_as_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse(v_t_243, 3ULL);
    V v_f_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2437)), heff_clo(g_heff_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_as_2437, v_f_2438}));
    return heff_tag_at(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2436, v_t_2441});
  }
  case TAG_SMatch: {
    V v_e_2442 = heff_field(v_t_243, 0);
    V v_cs_2443 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse(v_t_243, 3ULL);
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2442}));
    V v_xs_2445 = heff_get(heff_dup(v_cs_2443), LBL_values);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2445)), heff_clo(g_heff_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2445, v_d_242, v_r_240}));
    V v_t_2453 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_cs_2443), LBL_keys), heff_get(v_cs_2443, LBL_byName), v_t_2452});
    return heff_tag_at(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e_2454 = heff_field(v_t_243, 0);
    V v_l_2455 = heff_field(v_t_243, 1);
    V v_v_2456 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse(v_t_243, 7ULL);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2454}));
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_v_2456}));
    return heff_tag_at(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse(v_t_243, 1ULL);
    V v_t_2460 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2461 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse(v_t_243, 1ULL);
    V v_t_2462 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2461}));
    return heff_tag_at(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_dd_2463 = heff_field(v_t_243, 0);
    V v_it2_2464 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse(v_t_243, 3ULL);
    switch (heff_tag_of(v_it2_2464)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_it2_2464, 0);
      V v_b_2466 = heff_field(v_it2_2464, 1);
      heff_take(v_it2_2464, 3ULL);
      V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2468 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2466}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2467, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2468})});
    }
    case TAG_AbsConst: {
      V v_b_2469 = heff_field(v_it2_2464, 0);
      heff_take(v_it2_2464, 1ULL);
      V v_t_2470 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2471 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2469}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2471})});
    }
    default: return heff_nomatch(v_it2_2464);
    }
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_t_243, 0);
    V v_e_2473 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse(v_t_243, 3ULL);
    V v_t_2474 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2473}));
    return heff_tag_at(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_t_243, 0);
    V v_ix_2477 = heff_field(v_t_243, 1);
    V v_ty_2478 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse(v_t_243, 7ULL);
    V v_t_2486 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_ix_2477)), heff_clo(g_heff_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2477, heff_dup(v_d_242), heff_dup(v_idxs_241)}));
    V v_t_2487 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty_2478}));
    return heff_tag_at(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_t_2486, v_t_2487});
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstTermF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_dup(heff_env(self)[0]);
  V v_f_2427 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  return heff_tail(v_f_2427, 1, (V[]){v_t_2430});
}
V g_heff_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2439 = args[0];
  V v_as_2437 = heff_dup(heff_env(self)[0]);
  V v_f_2438 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2440 = heff_arrayIndex(v_as_2437, v_i_2439);
  return heff_tail(v_f_2438, 1, (V[]){v_t_2440});
}
V g_heff_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_dup(heff_env(self)[0]);
  V v_d_242 = heff_dup(heff_env(self)[1]);
  V v_r_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse(v_p_2447, 3ULL);
    V v_t_2450 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2448)));
    V v_t_2451 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_t_2450, v_b_2449}));
    return heff_tag_at(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2479 = args[0];
  V v_ix_2477 = heff_dup(heff_env(self)[0]);
  V v_d_242 = heff_dup(heff_env(self)[1]);
  V v_idxs_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_i_2480 = heff_arrayIndex(v_ix_2477, v_i_2479);
  V v_t_2481 = heff_intLt(heff_dup(v_i_2480), heff_dup(v_d_242));
  switch (heff_tag_of(v_t_2481)) {
  case TAG_True: {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    heff_drop(v_t_2481);
    return v_i_2480;
  }
  case TAG_False: {
    heff_drop(v_t_2481);
    V v_t_2482 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_idxs_241));
    V v_t_2483 = heff_intSub(heff_intSub(v_t_2482, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2480), heff_dup(v_d_242)));
    V v_t_2484 = ({ V a_0 = v_idxs_241; V a_1 = v_t_2483; V r_ = (g_heff_2eunify_2enth(a_0, a_1)); heff_drop(v_idxs_241); r_; });
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      heff_drop(v_d_242);
      heff_drop(v_t_2484);
      return v_i_2480;
    }
    case TAG_Just: {
      V v_j_2485 = heff_field(v_t_2484, 0);
      heff_take(v_t_2484, 1ULL);
      heff_drop(v_i_2480);
      return heff_intAdd(v_j_2485, v_d_242);
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
  default: return heff_nomatch(v_t_2481);
  }
}
Clo g_heff_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    heff_drop(v_x4_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse(v_x4_243, 3ULL);
    V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    return heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eunify_2esubstTyFields(v_r_240, v_d_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245))});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eunify_2esubstTypeF_lam0(V self, V *args);
V g_heff_2eunify_2esubstTypeF_lam2(V self, V *args);
Clo g_heff_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse(v_t_243, 1ULL);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_it3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_ru_24t_243_24SFunction = heff_take_reuse(v_t_243, 15ULL);
    switch (heff_tag_of(v_it3_249)) {
    case TAG_MkAbs: {
      V v_x_2411 = heff_field(v_it3_249, 0);
      V v_b_2412 = heff_field(v_it3_249, 1);
      heff_take(v_it3_249, 3ULL);
      V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2414 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2412}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 4, (V[]){v_level_247, v_t_2413, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2411, v_t_2414}), v_implicit_2410});
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_it3_249, 0);
      heff_take(v_it3_249, 1ULL);
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_b_2415}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 4, (V[]){v_level_247, v_t_2416, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2417}), v_implicit_2410});
    }
    default: return heff_nomatch(v_it3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_t_243, 0);
    V v_ft_2419 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SRecord = heff_take_reuse(v_t_243, 3ULL);
    V v_t_2420 = heff_arrayToList(heff_get(heff_dup(v_ft_2419), LBL_values));
    V v_t_2421 = (g_heff_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2420));
    V v_t_2422 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_ft_2419), LBL_keys), heff_get(v_ft_2419, LBL_byName), heff_arrayFromList(v_t_2421)});
    return heff_tag_at(v_ru_24t_243_24SRecord, TAG_SRecord, 2, (V[]){v_level_2418, v_t_2422});
  }
  case TAG_SSum: {
    V v_vs_2423 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse(v_t_243, 1ULL);
    V v_f_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_d_242}));
    V v_f_2428 = heff_clo(g_heff_2eunify_2esubstTypeF_lam0, 1, 1, (V[]){v_f_2424});
    V v_xs_2429 = heff_get(heff_dup(v_vs_2423), LBL_values);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2429)), heff_clo(g_heff_2eunify_2esubstTypeF_lam2, 1, 2, (V[]){v_xs_2429, v_f_2428}));
    V v_t_2433 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_vs_2423), LBL_keys), heff_get(v_vs_2423, LBL_byName), v_t_2432});
    return heff_tag_at(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2433});
  }
  case TAG_SIsTy: {
    V v_a_2434 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse(v_t_243, 1ULL);
    V v_t_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_a_2434}));
    return heff_tag_at(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2435});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstTypeF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_dup(heff_env(self)[0]);
  V v_f_2424 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  return heff_tail(v_f_2424, 1, (V[]){v_t_2427});
}
V g_heff_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_xs_2425 = args[0];
  V v_f_2424 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2425)), heff_clo(g_heff_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2425, v_f_2424}));
}
V g_heff_2eunify_2esubstTypeF_lam2(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_dup(heff_env(self)[0]);
  V v_f_2428 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  return heff_tail(v_f_2428, 1, (V[]){v_t_2431});
}
V g_heff_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec(2, shape_75_336, (V[]){heff_clo(g_heff_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo(g_heff_2eunify_2esubstOf_lam1, 2, 1, (V[]){heff_dup(v_idxs_240)})});
}
V g_heff_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_243 = (g_heff_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_243; V a_1 = v_idxs_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eunify_2esubstTermF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246 = (g_heff_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
Clo g_heff_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_n_240);
    heff_drop(v_t_242);
    return v_t_241;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take(v_t_241, 2ULL);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take(v_it2_249, 2ULL);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take(v_it2_249, 1ULL);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2estripLams(a[0], a[1]);
}
V g_heff_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse(v_t_242, 1ULL);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_245}));
    return heff_tag_at(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse(v_t_242, 3ULL);
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_a_248}));
    return heff_tag_at(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse(v_t_242, 3ULL);
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get(v_r_240, LBL_el);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      heff_take(v_b_2412, 3ULL);
      V v_t_2417 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at(v_ru_24t_242_24SLam, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse(v_b_2412, 1ULL);
      heff_drop(v_ru_24t_242_24SLam);
      V v_t_2419 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag(TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse(v_t_242, 1ULL);
    V v_xs_2422 = heff_get(heff_dup(v_d_2421), LBL_values);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo(g_heff_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2422, v_r_240}));
    V v_t_2426 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_d_2421), LBL_keys), heff_get(v_d_2421, LBL_byName), v_t_2425});
    return heff_tag_at(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e_2427 = heff_field(v_t_242, 0);
    V v_l_2428 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse(v_t_242, 3ULL);
    V v_t_2429 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2427}));
    return heff_tag_at(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_x_2430 = heff_field(v_t_242, 0);
    V v_as_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse(v_t_242, 3ULL);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2431)), heff_clo(g_heff_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_as_2431, v_r_240}));
    return heff_tag_at(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2430, v_t_2434});
  }
  case TAG_SMatch: {
    V v_e_2435 = heff_field(v_t_242, 0);
    V v_cs_2436 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse(v_t_242, 3ULL);
    V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_e_2435}));
    V v_xs_2438 = heff_get(heff_dup(v_cs_2436), LBL_values);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo(g_heff_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2438, v_r_240}));
    V v_t_2445 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_cs_2436), LBL_keys), heff_get(v_cs_2436, LBL_byName), v_t_2444});
    return heff_tag_at(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2437, v_t_2445});
  }
  case TAG_SSpecialize: {
    V v_e_2446 = heff_field(v_t_242, 0);
    V v_l_2447 = heff_field(v_t_242, 1);
    V v_v_2448 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse(v_t_242, 7ULL);
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_e_2446}));
    V v_t_2450 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_v_2448}));
    return heff_tag_at(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2449, v_l_2447, v_t_2450});
  }
  case TAG_SIs: {
    V v_e_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse(v_t_242, 1ULL);
    V v_t_2452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2451}));
    return heff_tag_at(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2452});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2453 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse(v_t_242, 1ULL);
    V v_t_2454 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2453}));
    return heff_tag_at(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2454});
  }
  case TAG_SFix: {
    V v_d_2455 = heff_field(v_t_242, 0);
    V v_b_2456 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse(v_t_242, 3ULL);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_d_2455}));
    V v_f_2458 = heff_get(v_r_240, LBL_el);
    V v_t_2464;
    switch (heff_tag_of(v_b_2456)) {
    case TAG_MkAbs: {
      V v_x_2459 = heff_field(v_b_2456, 0);
      V v_b_2460 = heff_field(v_b_2456, 1);
      heff_take(v_b_2456, 3ULL);
      V v_t_2461 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2460}));
      v_t_2464 = heff_tag_at(v_ru_24t_242_24SFix, TAG_MkAbs, 2, (V[]){v_x_2459, v_t_2461});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2462 = heff_field(v_b_2456, 0);
      V v_ru_24b_2456_24AbsConst = heff_take_reuse(v_b_2456, 1ULL);
      heff_drop(v_ru_24t_242_24SFix);
      V v_t_2463 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2462}));
      v_t_2464 = heff_tag_at(v_ru_24b_2456_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2463});
      break;
    }
    default: heff_nomatch(v_b_2456);
    }
    return heff_tag(TAG_SFix, 2, (V[]){v_t_2457, v_t_2464});
  }
  case TAG_SImplicit: {
    V v_x_2465 = heff_field(v_t_242, 0);
    V v_e_2466 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse(v_t_242, 3ULL);
    V v_t_2467 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2466}));
    return heff_tag_at(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2465, v_t_2467});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2469 = heff_field(v_t_242, 0);
    V v_idxs_2470 = heff_field(v_t_242, 1);
    V v_ty_2471 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse(v_t_242, 7ULL);
    V v_t_2472 = (g_map_2elookup_24s12(heff_dup(v_m_2469), v_mc_241));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_Nothing: {
      heff_drop(v_t_2472);
      V v_t_2473 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_2471}));
      return heff_tag_at(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2473});
    }
    case TAG_Just: {
      V v_e_2474 = heff_field(v_t_2472, 0);
      heff_take(v_t_2472, 1ULL);
      V v_t_2475 = heff_get(v_e_2474, LBL_solStx);
      switch (heff_tag_of(v_t_2475)) {
      case TAG_Nothing: {
        heff_drop(v_t_2475);
        V v_t_2476 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_2471}));
        return heff_tag_at(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2476});
      }
      case TAG_Just: {
        V v_sol_2477 = heff_field(v_t_2475, 0);
        heff_take(v_t_2475, 1ULL);
        heff_drop(v_m_2469);
        heff_drop(v_ty_2471);
        heff_drop(v_ru_24t_242_24SMetaApp);
        V v_idxs_2478 = heff_arrayToList(v_idxs_2470);
        V v_t_2479 = (g_heff_2eunify_2esubstOf(v_idxs_2478));
        V v_t_2480 = ({ V a_0 = MK_INT(0LL); V a_1 = v_idxs_2478; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_idxs_2478); r_; });
        V v_t_2481 = (g_heff_2eunify_2estripLams(v_t_2480, v_sol_2477));
        V v_t_2482 = heff_tr(heff_apply(heff_get(v_t_2479, LBL_el), 2, (V[]){MK_INT(0LL), v_t_2481}));
        return heff_tail(heff_get(v_r_240, LBL_el), 1, (V[]){v_t_2482});
      }
      default: return heff_nomatch(v_t_2475);
      }
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonkTermF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  return heff_tail(heff_get(v_r_240, LBL_el), 1, (V[]){v_t_2424});
}
V g_heff_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_as_2431 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2433 = heff_arrayIndex(v_as_2431, v_i_2432);
  return heff_tail(heff_get(v_r_240, LBL_el), 1, (V[]){v_t_2433});
}
V g_heff_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_p_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_xs_2441 = heff_field(v_p_2440, 0);
    V v_b_2442 = heff_field(v_p_2440, 1);
    V v_ru_24p_2440_24MkPair = heff_take_reuse(v_p_2440, 3ULL);
    V v_t_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_b_2442}));
    return heff_tag_at(v_ru_24p_2440_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_p_2440);
  }
}
V g_heff_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam2(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam1(V self, V *args);
Clo g_heff_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse(v_t_242, 1ULL);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_244}));
    return heff_tag_at(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_ru_24t_242_24SFunction = heff_take_reuse(v_t_242, 15ULL);
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_dom_247}));
    V v_f_2411 = heff_get(v_r_240, LBL_ty);
    V v_t_2417;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_cod_248, 0);
      V v_b_2413 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse(v_cod_248, 3ULL);
      V v_t_2414 = heff_tr(heff_apply(v_f_2411, 1, (V[]){v_b_2413}));
      v_t_2417 = heff_tag_at(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2414});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse(v_cod_248, 1ULL);
      V v_t_2416 = heff_tr(heff_apply(v_f_2411, 1, (V[]){v_b_2415}));
      v_t_2417 = heff_tag_at(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    return heff_tag_at(v_ru_24t_242_24SFunction, TAG_SFunction, 4, (V[]){v_level_246, v_t_2410, v_t_2417, v_implicit_249});
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_t_242, 0);
    V v_ft_2419 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SRecord = heff_take_reuse(v_t_242, 3ULL);
    V v_xs_2420 = heff_get(heff_dup(v_ft_2419), LBL_values);
    V v_t_2423 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2420)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2420, v_r_240}));
    V v_t_2424 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_ft_2419), LBL_keys), heff_get(v_ft_2419, LBL_byName), v_t_2423});
    return heff_tag_at(v_ru_24t_242_24SRecord, TAG_SRecord, 2, (V[]){v_level_2418, v_t_2424});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse(v_t_242, 1ULL);
    V v_xs_2426 = heff_get(heff_dup(v_vs_2425), LBL_values);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2426)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2426, v_r_240}));
    V v_t_2432 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_vs_2425), LBL_keys), heff_get(v_vs_2425, LBL_byName), v_t_2431});
    return heff_tag_at(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2432});
  }
  case TAG_SIsTy: {
    V v_a_2433 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse(v_t_242, 1ULL);
    V v_t_2434 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_a_2433}));
    return heff_tag_at(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2434});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonkTypeF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2421 = args[0];
  V v_xs_2420 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2422 = heff_arrayIndex(v_xs_2420, v_i_2421);
  return heff_tail(heff_get(v_r_240, LBL_ty), 1, (V[]){v_t_2422});
}
V g_heff_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  return heff_tail(heff_get(v_r_240, LBL_ty), 1, (V[]){v_t_2430});
}
V g_heff_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2427 = args[0];
  V v_xs_2426 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_xs_2428 = heff_arrayIndex(v_xs_2426, v_i_2427);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2428, v_r_240}));
}
V g_heff_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec(2, shape_75_336, (V[]){heff_clo(g_heff_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonker(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_242 = (g_heff_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = (g_heff_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
Clo g_heff_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_i_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_240);
    heff_drop(v_t_242);
    return v_rr_241;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intAdd(heff_get(heff_dup(v_rr_241), LBL_dom), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_get(heff_dup(v_rr_241), LBL_cod), MK_INT(1LL));
    V v_t_245 = (g_map_2einsert_24s214(heff_get(heff_dup(v_rr_241), LBL_dom), heff_get(heff_dup(v_rr_241), LBL_cod), heff_get(v_rr_241, LBL_ren)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_rec(3, shape_65_43_256, (V[]){v_t_243, v_t_244, v_t_245});
    v_i_240 = t_0;
    v_rr_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eiterateLift(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2elamsU_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_k_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_k_240);
    heff_drop(v_t_242);
    return v_body_241;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_tag(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_244 = heff_tag(TAG_SLam, 2, (V[]){v_t_243, heff_tag(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_244;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = heff_rec(6, shape_336_293_294_13_190_299, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_arity_241, heff_get(heff_dup(v_entry_240), LBL_name), heff_get(v_entry_240, LBL_span)});
  V v_mc_245 = (g_map_2einsert_24s214(heff_get(heff_dup(v_c_243), LBL_nextMeta), v_t_244, heff_get(heff_dup(v_c_243), LBL_metas)));
  V v_t_246 = heff_intAdd(heff_get(heff_dup(v_c_243), LBL_nextMeta), MK_INT(1LL));
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_243), LBL_infos), heff_get(heff_dup(v_c_243), LBL_recovered), heff_get(heff_dup(v_c_243), LBL_poisoned), v_mc_245, v_t_246, heff_get(heff_dup(v_c_243), LBL_postponed), heff_get(heff_dup(v_c_243), LBL_trace), heff_get(v_c_243, LBL_selfKey)});
}
V g_heff_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eunify_2emapWithIndexL_24s412_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_24s412_entry, 2, 0};

V g_heff_2eunify_2emapWithIndexL_24s412(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse(v_x3_241, 3ULL);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a1_244 = heff_field(v_x_242, 0);
      V v_a2_245 = heff_field(v_x_242, 1);
      heff_take(v_x_242, 3ULL);
      V v_t_249;
      switch (heff_tag_of(v_a1_244)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_a1_244, 0);
        heff_take(v_a1_244, 1ULL);
        switch (heff_tag_of(v_a2_245)) {
        case TAG_PVar: {
          V v_l_27_247 = heff_field(v_a2_245, 0);
          heff_take(v_a2_245, 1ULL);
          v_t_249 = heff_intEq(v_l_246, v_l_27_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a2_245);
          heff_drop(v_l_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a2_245);
        }
        break;
      }
      case TAG_PSelf: {
        heff_drop(v_a1_244);
        switch (heff_tag_of(v_a2_245)) {
        case TAG_PVar: {
          heff_take(v_a2_245, 0ULL);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a2_245);
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a2_245);
        }
        break;
      }
      default: heff_nomatch(v_a1_244);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_t_249);
        v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
        break;
      }
      case TAG_False: {
        heff_drop(v_t_249);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eunify_2emapWithIndexL_24s412(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eunify_2emapWithIndexL_24s412_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL_24s412(a[0], a[1]);
}
Clo g_heff_2eunify_2emapWithIndexL_24s415_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_24s415_entry, 2, 0};

V g_heff_2eunify_2emapWithIndexL_24s415(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse(v_x3_241, 3ULL);
    return heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), (g_heff_2eunify_2emapWithIndexL_24s415(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eunify_2emapWithIndexL_24s415_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL_24s415(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2euTyRigid_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eunify_2euTyRigid_lam0(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam0, 2, 0};
V g_heff_2eunify_2euTyRigid_lam2(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam1(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam4(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam3(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam6(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam5(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam8(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam7(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam10(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam9(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam12(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam11(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam14(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam13(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam16(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam15(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam18(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam17(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam20(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam19(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam22(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam21(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam24(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam23(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam26(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam25(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam28(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam27(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam30(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam29(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam32(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam31(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam34(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam33(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam36(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam35(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam38(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam37(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam41(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam42(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam43(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam40(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam39(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam45(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam44(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam47(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam46(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam49(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam48(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam51(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam50(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam53(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam52(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam55(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam54(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam57(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam56(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam59(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam58(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam61(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam60(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam63(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam62(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam65(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam64(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam67(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam66(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam69(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam68(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam71(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam70(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam72(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam72, 2, 0};
V g_heff_2eunify_2euTyRigid_lam74(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam73(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam76(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam75(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam78(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam77(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam80(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam79(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam82(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam81(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam84(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam83(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam86(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam85(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam88(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam87(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam90(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam89(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam91(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam91, 2, 0};
V g_heff_2eunify_2euTyRigid_lam93(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam92(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam95(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam94(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam97(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam96(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam99(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam98(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam101(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam100(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam103(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam102(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam105(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam104(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam107(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam106(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam109(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam108(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam110(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam110, 2, 0};
V g_heff_2eunify_2euTyRigid_lam112(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam111(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam114(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam113(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam116(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam115(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam118(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam117(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam120(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam119(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam122(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam121(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam124(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam123(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam126(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam125(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam128(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam127(V self, V *args);
Clo g_heff_2eunify_2euTyRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_entry, 8, 0};

V g_heff_2eunify_2euTyRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a_246, V v_b_247) {
top: ;
  switch (heff_tag_of(v_a_246)) {
  case TAG_VU: {
    V v_u_248 = heff_dup(heff_field(v_a_246, 0));
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_u_27_249 = heff_dup(heff_field(v_b_247, 0));
      V v_t_2410;
      switch (heff_tag_of(v_u_248)) {
      case TAG_SmallU: {
        heff_drop(v_u_248);
        switch (heff_tag_of(v_u_27_249)) {
        case TAG_SmallU: {
          heff_drop(v_u_27_249);
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        case TAG_LargeU: {
          heff_drop(v_u_27_249);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_u_27_249);
        }
        break;
      }
      case TAG_LargeU: {
        heff_drop(v_u_248);
        switch (heff_tag_of(v_u_27_249)) {
        case TAG_SmallU: {
          heff_drop(v_u_27_249);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_LargeU: {
          heff_drop(v_u_27_249);
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_u_27_249);
        }
        break;
      }
      default: heff_nomatch(v_u_248);
      }
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_w_240);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_a_246);
        heff_drop(v_b_247);
        heff_drop(v_t_2410);
        return ((V)&g_heff_2eunify_2euTyRigid_lam0_clo);
      }
      case TAG_False: {
        heff_drop(v_t_2410);
        V v_t_2413 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
        V v_p_2414 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2413}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam1, 2, 2, (V[]){v_w_240, v_p_2414});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_248);
      V v_t_2425 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2426 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2425}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam3, 2, 2, (V[]){v_w_240, v_p_2426});
    }
    case TAG_VFunction: {
      heff_drop(v_u_248);
      V v_t_2436 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2437 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2436}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam5, 2, 2, (V[]){v_w_240, v_p_2437});
    }
    case TAG_VRecord: {
      heff_drop(v_u_248);
      V v_t_2446 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2447 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2446}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam7, 2, 2, (V[]){v_w_240, v_p_2447});
    }
    case TAG_VSum: {
      heff_drop(v_u_248);
      V v_t_2454 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2455 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2454}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam9, 2, 2, (V[]){v_w_240, v_p_2455});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_248);
      V v_t_2461 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2462 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2461}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam11, 2, 2, (V[]){v_w_240, v_p_2462});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_248);
      V v_t_2468 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2469 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2468}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam13, 2, 2, (V[]){v_w_240, v_p_2469});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_248);
      V v_t_2475 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2476 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2475}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam15, 2, 2, (V[]){v_w_240, v_p_2476});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_248);
      V v_t_2483 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2484 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2483}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam17, 2, 2, (V[]){v_w_240, v_p_2484});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VDecode: {
    V v_h_2490 = heff_dup(heff_field(v_a_246, 0));
    V v_sp_2491 = heff_dup(heff_field(v_a_246, 1));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_2496 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2497 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2496}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam19, 2, 2, (V[]){v_w_240, v_p_2497});
    }
    case TAG_VDecode: {
      V v_h_27_24103 = heff_field(v_b_247, 0);
      V v_sp_27_24104 = heff_field(v_b_247, 1);
      heff_take(v_b_247, 3ULL);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_246);
      return heff_tail(heff_get(v_r_243, LBL_ubare), 6, (V[]){v_g_244, v_cs_245, v_h_2490, v_sp_2491, v_h_27_24103, v_sp_27_24104});
    }
    case TAG_VFunction: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24112 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24113 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24112}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam21, 2, 2, (V[]){v_w_240, v_p_24113});
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24122 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24123 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24122}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam23, 2, 2, (V[]){v_w_240, v_p_24123});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24130 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24131 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24130}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam25, 2, 2, (V[]){v_w_240, v_p_24131});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24137 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24138 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24137}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam27, 2, 2, (V[]){v_w_240, v_p_24138});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24144 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24145 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24144}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam29, 2, 2, (V[]){v_w_240, v_p_24145});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24151 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24152 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24151}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam31, 2, 2, (V[]){v_w_240, v_p_24152});
    }
    case TAG_VPrimArray: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2490);
      heff_drop(v_sp_2491);
      V v_t_24159 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24160 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24159}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam33, 2, 2, (V[]){v_w_240, v_p_24160});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VFunction: {
    V v_level_24166 = heff_dup(heff_field(v_a_246, 0));
    V v_dom_24167 = heff_dup(heff_field(v_a_246, 1));
    V v_cod_24168 = heff_dup(heff_field(v_a_246, 2));
    V v_implicit_24169 = heff_dup(heff_field(v_a_246, 3));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24171 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24172 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24171}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam35, 2, 2, (V[]){v_w_240, v_p_24172});
    }
    case TAG_VDecode: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24183 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24184 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24183}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam37, 2, 2, (V[]){v_w_240, v_p_24184});
    }
    case TAG_VFunction: {
      V v_level_27_24190 = heff_dup(heff_field(v_b_247, 0));
      V v_dom_27_24191 = heff_dup(heff_field(v_b_247, 1));
      V v_cod_27_24192 = heff_dup(heff_field(v_b_247, 2));
      V v_implicit_27_24193 = heff_dup(heff_field(v_b_247, 3));
      V v_t_24194 = ({ V a_0 = v_level_24166; V a_1 = v_level_27_24190; V r_ = (g_heff_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_24166); heff_drop(v_level_27_24190); r_; });
      V v_t_24195;
      switch (heff_tag_of(v_t_24194)) {
      case TAG_True: {
        heff_drop(v_t_24194);
        switch (heff_tag_of(v_implicit_24169)) {
        case TAG_Expl: {
          heff_drop(v_implicit_24169);
          switch (heff_tag_of(v_implicit_27_24193)) {
          case TAG_Expl: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24193);
          }
          break;
        }
        case TAG_Impl: {
          heff_drop(v_implicit_24169);
          switch (heff_tag_of(v_implicit_27_24193)) {
          case TAG_Expl: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24193);
          }
          break;
        }
        case TAG_Inst: {
          heff_drop(v_implicit_24169);
          switch (heff_tag_of(v_implicit_27_24193)) {
          case TAG_Expl: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            heff_drop(v_implicit_27_24193);
            v_t_24195 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24193);
          }
          break;
        }
        default: heff_nomatch(v_implicit_24169);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_implicit_24169);
        heff_drop(v_implicit_27_24193);
        heff_drop(v_t_24194);
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24194);
      }
      switch (heff_tag_of(v_t_24195)) {
      case TAG_True: {
        heff_drop(v_w_240);
        heff_drop(v_uf_242);
        heff_drop(v_a_246);
        heff_drop(v_b_247);
        heff_drop(v_t_24195);
        V v_c_24196 = heff_tr(heff_apply(heff_get(heff_dup(v_r_243), LBL_uty), 4, (V[]){heff_dup(v_g_244), heff_dup(v_cs_245), heff_dup(v_dom_24167), v_dom_27_24191}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam39, 2, 7, (V[]){v_c_24196, v_cs_245, v_dom_24167, v_cod_24168, v_cod_27_24192, v_r_243, v_g_244});
      }
      case TAG_False: {
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        heff_drop(v_dom_24167);
        heff_drop(v_cod_24168);
        heff_drop(v_dom_27_24191);
        heff_drop(v_cod_27_24192);
        heff_drop(v_t_24195);
        V v_t_24230 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
        V v_p_24231 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24230}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam44, 2, 2, (V[]){v_w_240, v_p_24231});
      }
      default: return heff_nomatch(v_t_24195);
      }
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24240 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24241 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24240}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam46, 2, 2, (V[]){v_w_240, v_p_24241});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24248 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24249 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24248}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam48, 2, 2, (V[]){v_w_240, v_p_24249});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24255 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24256 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24255}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam50, 2, 2, (V[]){v_w_240, v_p_24256});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24262 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24263 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24262}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam52, 2, 2, (V[]){v_w_240, v_p_24263});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24269 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24270 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24269}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam54, 2, 2, (V[]){v_w_240, v_p_24270});
    }
    case TAG_VPrimArray: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24166);
      heff_drop(v_dom_24167);
      heff_drop(v_cod_24168);
      heff_drop(v_implicit_24169);
      V v_t_24277 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24278 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24277}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam56, 2, 2, (V[]){v_w_240, v_p_24278});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24287 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
    V v_p_24288 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24287}));
    return heff_clo(g_heff_2eunify_2euTyRigid_lam58, 2, 2, (V[]){v_w_240, v_p_24288});
  }
  case TAG_VSum: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24295 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
    V v_p_24296 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24295}));
    return heff_clo(g_heff_2eunify_2euTyRigid_lam60, 2, 2, (V[]){v_w_240, v_p_24296});
  }
  case TAG_VPrimInt: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24303 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24304 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24303}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam62, 2, 2, (V[]){v_w_240, v_p_24304});
    }
    case TAG_VDecode: {
      V v_t_24315 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24316 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24315}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam64, 2, 2, (V[]){v_w_240, v_p_24316});
    }
    case TAG_VFunction: {
      V v_t_24326 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24327 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24326}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam66, 2, 2, (V[]){v_w_240, v_p_24327});
    }
    case TAG_VRecord: {
      V v_t_24336 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24337 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24336}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam68, 2, 2, (V[]){v_w_240, v_p_24337});
    }
    case TAG_VSum: {
      V v_t_24344 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24345 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24344}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam70, 2, 2, (V[]){v_w_240, v_p_24345});
    }
    case TAG_VPrimInt: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop(v_a_246);
      heff_drop(v_b_247);
      return ((V)&g_heff_2eunify_2euTyRigid_lam72_clo);
    }
    case TAG_VPrimFloat: {
      V v_t_24353 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24354 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24353}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam73, 2, 2, (V[]){v_w_240, v_p_24354});
    }
    case TAG_VPrimString: {
      V v_t_24360 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24361 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24360}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam75, 2, 2, (V[]){v_w_240, v_p_24361});
    }
    case TAG_VPrimArray: {
      V v_t_24368 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24369 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24368}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam77, 2, 2, (V[]){v_w_240, v_p_24369});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24376 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24377 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24376}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam79, 2, 2, (V[]){v_w_240, v_p_24377});
    }
    case TAG_VDecode: {
      V v_t_24388 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24389 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24388}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam81, 2, 2, (V[]){v_w_240, v_p_24389});
    }
    case TAG_VFunction: {
      V v_t_24399 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24400 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24399}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam83, 2, 2, (V[]){v_w_240, v_p_24400});
    }
    case TAG_VRecord: {
      V v_t_24409 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24410 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24409}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam85, 2, 2, (V[]){v_w_240, v_p_24410});
    }
    case TAG_VSum: {
      V v_t_24417 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24418 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24417}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam87, 2, 2, (V[]){v_w_240, v_p_24418});
    }
    case TAG_VPrimInt: {
      V v_t_24424 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24425 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24424}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam89, 2, 2, (V[]){v_w_240, v_p_24425});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop(v_a_246);
      heff_drop(v_b_247);
      return ((V)&g_heff_2eunify_2euTyRigid_lam91_clo);
    }
    case TAG_VPrimString: {
      V v_t_24433 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24434 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24433}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam92, 2, 2, (V[]){v_w_240, v_p_24434});
    }
    case TAG_VPrimArray: {
      V v_t_24441 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24442 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24441}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam94, 2, 2, (V[]){v_w_240, v_p_24442});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24449 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24450 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24449}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam96, 2, 2, (V[]){v_w_240, v_p_24450});
    }
    case TAG_VDecode: {
      V v_t_24461 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24462 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24461}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam98, 2, 2, (V[]){v_w_240, v_p_24462});
    }
    case TAG_VFunction: {
      V v_t_24472 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24473 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24472}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam100, 2, 2, (V[]){v_w_240, v_p_24473});
    }
    case TAG_VRecord: {
      V v_t_24482 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24483 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24482}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam102, 2, 2, (V[]){v_w_240, v_p_24483});
    }
    case TAG_VSum: {
      V v_t_24490 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24491 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24490}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam104, 2, 2, (V[]){v_w_240, v_p_24491});
    }
    case TAG_VPrimInt: {
      V v_t_24497 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24498 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24497}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam106, 2, 2, (V[]){v_w_240, v_p_24498});
    }
    case TAG_VPrimFloat: {
      V v_t_24504 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24505 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24504}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam108, 2, 2, (V[]){v_w_240, v_p_24505});
    }
    case TAG_VPrimString: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop(v_a_246);
      heff_drop(v_b_247);
      return ((V)&g_heff_2eunify_2euTyRigid_lam110_clo);
    }
    case TAG_VPrimArray: {
      V v_t_24514 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24515 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24514}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam111, 2, 2, (V[]){v_w_240, v_p_24515});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimArray: {
    V v_x_24521 = heff_dup(heff_field(v_a_246, 0));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24523 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24524 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24523}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam113, 2, 2, (V[]){v_w_240, v_p_24524});
    }
    case TAG_VDecode: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24535 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24536 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24535}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam115, 2, 2, (V[]){v_w_240, v_p_24536});
    }
    case TAG_VFunction: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24546 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24547 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24546}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam117, 2, 2, (V[]){v_w_240, v_p_24547});
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24556 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24557 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24556}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam119, 2, 2, (V[]){v_w_240, v_p_24557});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24564 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24565 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24564}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam121, 2, 2, (V[]){v_w_240, v_p_24565});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24571 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24572 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24571}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam123, 2, 2, (V[]){v_w_240, v_p_24572});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24578 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24579 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24578}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam125, 2, 2, (V[]){v_w_240, v_p_24579});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24521);
      V v_t_24585 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24586 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24585}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam127, 2, 2, (V[]){v_w_240, v_p_24586});
    }
    case TAG_VPrimArray: {
      V v_y_24592 = heff_field(v_b_247, 0);
      heff_take(v_b_247, 1ULL);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_246);
      return heff_tail(heff_get(v_r_243, LBL_uty), 4, (V[]){v_g_244, v_cs_245, v_x_24521, v_y_24592});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  default: return heff_nomatch(v_a_246);
  }
}
V g_heff_2eunify_2euTyRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euTyRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2euTyRigid_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2411);
  return heff_tail(v_k_2412, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euTyRigid_lam2(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2415), heff_get(v_hd_2415, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2414 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2418 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam2, 1, 1, (V[]){heff_dup(v_hd_2415)}), v_p_2414}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_hd_2415, LBL_bind), 2, (V[]){v_t_2419, v_k2_2416});
}
V g_heff_2eunify_2euTyRigid_lam4(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_2427 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_2427), heff_get(v_hd_2427, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2426 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2430 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam4, 1, 1, (V[]){heff_dup(v_hd_2427)}), v_p_2426}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2427), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(v_hd_2427, LBL_bind), 2, (V[]){v_t_2431, v_k2_2428});
}
V g_heff_2eunify_2euTyRigid_lam6(V self, V *args) {
  V v_c_2440 = args[0];
  V v_hd_2438 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2440, 2, (V[]){heff_dup(v_hd_2438), heff_get(v_hd_2438, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam5(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2437 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2441 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam6, 1, 1, (V[]){heff_dup(v_hd_2438)}), v_p_2437}));
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2441}));
  return heff_tail(heff_get(v_hd_2438, LBL_bind), 2, (V[]){v_t_2442, v_k2_2439});
}
V g_heff_2eunify_2euTyRigid_lam8(V self, V *args) {
  V v_c_2450 = args[0];
  V v_hd_2448 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2450, 2, (V[]){heff_dup(v_hd_2448), heff_get(v_hd_2448, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam7(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k2_2449 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2447 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2451 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam8, 1, 1, (V[]){heff_dup(v_hd_2448)}), v_p_2447}));
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2448), LBL_malg), 1, (V[]){v_t_2451}));
  return heff_tail(heff_get(v_hd_2448, LBL_bind), 2, (V[]){v_t_2452, v_k2_2449});
}
V g_heff_2eunify_2euTyRigid_lam10(V self, V *args) {
  V v_c_2458 = args[0];
  V v_hd_2456 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2456), heff_get(v_hd_2456, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam9(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2455 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2459 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam10, 1, 1, (V[]){heff_dup(v_hd_2456)}), v_p_2455}));
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2459}));
  return heff_tail(heff_get(v_hd_2456, LBL_bind), 2, (V[]){v_t_2460, v_k2_2457});
}
V g_heff_2eunify_2euTyRigid_lam12(V self, V *args) {
  V v_c_2465 = args[0];
  V v_hd_2463 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2465, 2, (V[]){heff_dup(v_hd_2463), heff_get(v_hd_2463, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam11(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k2_2464 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2462 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2466 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam12, 1, 1, (V[]){heff_dup(v_hd_2463)}), v_p_2462}));
  V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2463), LBL_malg), 1, (V[]){v_t_2466}));
  return heff_tail(heff_get(v_hd_2463, LBL_bind), 2, (V[]){v_t_2467, v_k2_2464});
}
V g_heff_2eunify_2euTyRigid_lam14(V self, V *args) {
  V v_c_2472 = args[0];
  V v_hd_2470 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2472, 2, (V[]){heff_dup(v_hd_2470), heff_get(v_hd_2470, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam13(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2469 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2473 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam14, 1, 1, (V[]){heff_dup(v_hd_2470)}), v_p_2469}));
  V v_t_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2470), LBL_malg), 1, (V[]){v_t_2473}));
  return heff_tail(heff_get(v_hd_2470, LBL_bind), 2, (V[]){v_t_2474, v_k2_2471});
}
V g_heff_2eunify_2euTyRigid_lam16(V self, V *args) {
  V v_c_2479 = args[0];
  V v_hd_2477 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2479, 2, (V[]){heff_dup(v_hd_2477), heff_get(v_hd_2477, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam15(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k2_2478 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2476 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2480 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam16, 1, 1, (V[]){heff_dup(v_hd_2477)}), v_p_2476}));
  V v_t_2481 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2477), LBL_malg), 1, (V[]){v_t_2480}));
  return heff_tail(heff_get(v_hd_2477, LBL_bind), 2, (V[]){v_t_2481, v_k2_2478});
}
V g_heff_2eunify_2euTyRigid_lam18(V self, V *args) {
  V v_c_2487 = args[0];
  V v_hd_2485 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2487, 2, (V[]){heff_dup(v_hd_2485), heff_get(v_hd_2485, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam17(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k2_2486 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2484 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2488 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam18, 1, 1, (V[]){heff_dup(v_hd_2485)}), v_p_2484}));
  V v_t_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2485), LBL_malg), 1, (V[]){v_t_2488}));
  return heff_tail(heff_get(v_hd_2485, LBL_bind), 2, (V[]){v_t_2489, v_k2_2486});
}
V g_heff_2eunify_2euTyRigid_lam20(V self, V *args) {
  V v_c_24100 = args[0];
  V v_hd_2498 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24100, 2, (V[]){heff_dup(v_hd_2498), heff_get(v_hd_2498, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam19(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k2_2499 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2497 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24101 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam20, 1, 1, (V[]){heff_dup(v_hd_2498)}), v_p_2497}));
  V v_t_24102 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2498), LBL_malg), 1, (V[]){v_t_24101}));
  return heff_tail(heff_get(v_hd_2498, LBL_bind), 2, (V[]){v_t_24102, v_k2_2499});
}
V g_heff_2eunify_2euTyRigid_lam22(V self, V *args) {
  V v_c_24116 = args[0];
  V v_hd_24114 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24116, 2, (V[]){heff_dup(v_hd_24114), heff_get(v_hd_24114, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam21(V self, V *args) {
  V v_hd_24114 = args[0];
  V v_k2_24115 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24113 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24117 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam22, 1, 1, (V[]){heff_dup(v_hd_24114)}), v_p_24113}));
  V v_t_24118 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24114), LBL_malg), 1, (V[]){v_t_24117}));
  return heff_tail(heff_get(v_hd_24114, LBL_bind), 2, (V[]){v_t_24118, v_k2_24115});
}
V g_heff_2eunify_2euTyRigid_lam24(V self, V *args) {
  V v_c_24126 = args[0];
  V v_hd_24124 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24126, 2, (V[]){heff_dup(v_hd_24124), heff_get(v_hd_24124, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam23(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k2_24125 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24123 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24127 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam24, 1, 1, (V[]){heff_dup(v_hd_24124)}), v_p_24123}));
  V v_t_24128 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24124), LBL_malg), 1, (V[]){v_t_24127}));
  return heff_tail(heff_get(v_hd_24124, LBL_bind), 2, (V[]){v_t_24128, v_k2_24125});
}
V g_heff_2eunify_2euTyRigid_lam26(V self, V *args) {
  V v_c_24134 = args[0];
  V v_hd_24132 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24134, 2, (V[]){heff_dup(v_hd_24132), heff_get(v_hd_24132, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam25(V self, V *args) {
  V v_hd_24132 = args[0];
  V v_k2_24133 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24131 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24135 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam26, 1, 1, (V[]){heff_dup(v_hd_24132)}), v_p_24131}));
  V v_t_24136 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24132), LBL_malg), 1, (V[]){v_t_24135}));
  return heff_tail(heff_get(v_hd_24132, LBL_bind), 2, (V[]){v_t_24136, v_k2_24133});
}
V g_heff_2eunify_2euTyRigid_lam28(V self, V *args) {
  V v_c_24141 = args[0];
  V v_hd_24139 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24141, 2, (V[]){heff_dup(v_hd_24139), heff_get(v_hd_24139, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam27(V self, V *args) {
  V v_hd_24139 = args[0];
  V v_k2_24140 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24138 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24142 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam28, 1, 1, (V[]){heff_dup(v_hd_24139)}), v_p_24138}));
  V v_t_24143 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24139), LBL_malg), 1, (V[]){v_t_24142}));
  return heff_tail(heff_get(v_hd_24139, LBL_bind), 2, (V[]){v_t_24143, v_k2_24140});
}
V g_heff_2eunify_2euTyRigid_lam30(V self, V *args) {
  V v_c_24148 = args[0];
  V v_hd_24146 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24148, 2, (V[]){heff_dup(v_hd_24146), heff_get(v_hd_24146, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam29(V self, V *args) {
  V v_hd_24146 = args[0];
  V v_k2_24147 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24145 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24149 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam30, 1, 1, (V[]){heff_dup(v_hd_24146)}), v_p_24145}));
  V v_t_24150 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24146), LBL_malg), 1, (V[]){v_t_24149}));
  return heff_tail(heff_get(v_hd_24146, LBL_bind), 2, (V[]){v_t_24150, v_k2_24147});
}
V g_heff_2eunify_2euTyRigid_lam32(V self, V *args) {
  V v_c_24155 = args[0];
  V v_hd_24153 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24155, 2, (V[]){heff_dup(v_hd_24153), heff_get(v_hd_24153, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam31(V self, V *args) {
  V v_hd_24153 = args[0];
  V v_k2_24154 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24152 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24156 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam32, 1, 1, (V[]){heff_dup(v_hd_24153)}), v_p_24152}));
  V v_t_24157 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24153), LBL_malg), 1, (V[]){v_t_24156}));
  return heff_tail(heff_get(v_hd_24153, LBL_bind), 2, (V[]){v_t_24157, v_k2_24154});
}
V g_heff_2eunify_2euTyRigid_lam34(V self, V *args) {
  V v_c_24163 = args[0];
  V v_hd_24161 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24163, 2, (V[]){heff_dup(v_hd_24161), heff_get(v_hd_24161, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam33(V self, V *args) {
  V v_hd_24161 = args[0];
  V v_k2_24162 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24160 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24164 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam34, 1, 1, (V[]){heff_dup(v_hd_24161)}), v_p_24160}));
  V v_t_24165 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24161), LBL_malg), 1, (V[]){v_t_24164}));
  return heff_tail(heff_get(v_hd_24161, LBL_bind), 2, (V[]){v_t_24165, v_k2_24162});
}
V g_heff_2eunify_2euTyRigid_lam36(V self, V *args) {
  V v_c_24175 = args[0];
  V v_hd_24173 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24175, 2, (V[]){heff_dup(v_hd_24173), heff_get(v_hd_24173, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam35(V self, V *args) {
  V v_hd_24173 = args[0];
  V v_k2_24174 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24172 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24176 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam36, 1, 1, (V[]){heff_dup(v_hd_24173)}), v_p_24172}));
  V v_t_24177 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24173), LBL_malg), 1, (V[]){v_t_24176}));
  return heff_tail(heff_get(v_hd_24173, LBL_bind), 2, (V[]){v_t_24177, v_k2_24174});
}
V g_heff_2eunify_2euTyRigid_lam38(V self, V *args) {
  V v_c_24187 = args[0];
  V v_hd_24185 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24187, 2, (V[]){heff_dup(v_hd_24185), heff_get(v_hd_24185, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam37(V self, V *args) {
  V v_hd_24185 = args[0];
  V v_k2_24186 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24184 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24188 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam38, 1, 1, (V[]){heff_dup(v_hd_24185)}), v_p_24184}));
  V v_t_24189 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24185), LBL_malg), 1, (V[]){v_t_24188}));
  return heff_tail(heff_get(v_hd_24185, LBL_bind), 2, (V[]){v_t_24189, v_k2_24186});
}
V g_heff_2eunify_2euTyRigid_lam41(V self, V *args) {
  V v_u_24201 = args[0];
  V v_dom_24167 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_24201);
  return v_dom_24167;
}
V g_heff_2eunify_2euTyRigid_lam42(V self, V *args) {
  V v_w_24213 = args[0];
  V v_v_24202 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_w_24213);
  return v_v_24202;
}
V g_heff_2eunify_2euTyRigid_lam43(V self, V *args) {
  V v_w_24223 = args[0];
  V v_v_24202 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_w_24223);
  return v_v_24202;
}
V g_heff_2eunify_2euTyRigid_lam40(V self, V *args) {
  V v_x_24199 = args[0];
  V v_cs_245 = heff_dup(heff_env(self)[0]);
  V v_dom_24167 = heff_dup(heff_env(self)[1]);
  V v_cod_24168 = heff_dup(heff_env(self)[2]);
  V v_cod_27_24192 = heff_dup(heff_env(self)[3]);
  V v_r_243 = heff_dup(heff_env(self)[4]);
  V v_g_244 = heff_dup(heff_env(self)[5]);
  V v_hd_24197 = heff_dup(heff_env(self)[6]);
  V v_k_24198 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  heff_drop(v_x_24199);
  V v_t_24200 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_cs_245), LBL_len)});
  V v_v_24202 = (g_heff_2evalue_2emkNeu_24s10(v_t_24200, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2euTyRigid_lam41, 1, 1, (V[]){v_dom_24167}), NTAG(TAG_Nothing)));
  V v_x_24207;
  switch (heff_tag_of(v_cod_24168)) {
  case TAG_MkClo: {
    V v_n_24203 = heff_dup(heff_field(v_cod_24168, 0));
    v_x_24207 = v_n_24203;
    break;
  }
  case TAG_CloConst: {
    v_x_24207 = ((V)&g_heff_2eunify_2euTyRigid_str0);
    break;
  }
  default: heff_nomatch(v_cod_24168);
  }
  V v_t_24208 = heff_intAdd(heff_get(heff_dup(v_cs_245), LBL_len), MK_INT(1LL));
  V v_t_24209 = heff_tag(TAG_Cons, 2, (V[]){v_x_24207, heff_get(v_cs_245, LBL_names)});
  V v_x1_24215;
  switch (heff_tag_of(v_cod_24168)) {
  case TAG_MkClo: {
    V v_vs_24211 = heff_field(v_cod_24168, 1);
    V v_body_24212 = heff_field(v_cod_24168, 2);
    heff_take(v_cod_24168, 6ULL);
    v_x1_24215 = heff_tr(heff_apply(v_body_24212, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24211, heff_clo(g_heff_2eunify_2euTyRigid_lam42, 1, 1, (V[]){heff_dup(v_v_24202)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24214 = heff_field(v_cod_24168, 0);
    heff_take(v_cod_24168, 1ULL);
    v_x1_24215 = v_body_24214;
    break;
  }
  default: heff_nomatch(v_cod_24168);
  }
  V v_t_24219;
  switch (heff_tag_of(v_x1_24215)) {
  case TAG_Nom: {
    V v_x_24216 = heff_field(v_x1_24215, 0);
    heff_take(v_x1_24215, 1ULL);
    v_t_24219 = v_x_24216;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_24215, 0ULL);
    v_t_24219 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24218 = heff_field(v_x1_24215, 0);
    heff_take(v_x1_24215, 1ULL);
    v_t_24219 = v_x_24218;
    break;
  }
  default: heff_nomatch(v_x1_24215);
  }
  V v_x1_24225;
  switch (heff_tag_of(v_cod_27_24192)) {
  case TAG_MkClo: {
    V v_vs_24221 = heff_field(v_cod_27_24192, 1);
    V v_body_24222 = heff_field(v_cod_27_24192, 2);
    heff_take(v_cod_27_24192, 6ULL);
    v_x1_24225 = heff_tr(heff_apply(v_body_24222, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24221, heff_clo(g_heff_2eunify_2euTyRigid_lam43, 1, 1, (V[]){v_v_24202})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24224 = heff_field(v_cod_27_24192, 0);
    heff_take(v_cod_27_24192, 1ULL);
    heff_drop(v_v_24202);
    v_x1_24225 = v_body_24224;
    break;
  }
  default: heff_nomatch(v_cod_27_24192);
  }
  V v_t_24229;
  switch (heff_tag_of(v_x1_24225)) {
  case TAG_Nom: {
    V v_x_24226 = heff_field(v_x1_24225, 0);
    heff_take(v_x1_24225, 1ULL);
    v_t_24229 = v_x_24226;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_24225, 0ULL);
    v_t_24229 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24228 = heff_field(v_x1_24225, 0);
    heff_take(v_x1_24225, 1ULL);
    v_t_24229 = v_x_24228;
    break;
  }
  default: heff_nomatch(v_x1_24225);
  }
  return heff_tail(heff_get(v_r_243, LBL_uty), 6, (V[]){v_g_244, heff_rec(2, shape_160_192, (V[]){v_t_24208, v_t_24209}), v_t_24219, v_t_24229, v_hd_24197, v_k_24198});
}
V g_heff_2eunify_2euTyRigid_lam39(V self, V *args) {
  V v_hd_24197 = args[0];
  V v_k_24198 = args[1];
  V v_c_24196 = heff_dup(heff_env(self)[0]);
  V v_cs_245 = heff_dup(heff_env(self)[1]);
  V v_dom_24167 = heff_dup(heff_env(self)[2]);
  V v_cod_24168 = heff_dup(heff_env(self)[3]);
  V v_cod_27_24192 = heff_dup(heff_env(self)[4]);
  V v_r_243 = heff_dup(heff_env(self)[5]);
  V v_g_244 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  return heff_tail(v_c_24196, 2, (V[]){heff_dup(v_hd_24197), heff_clo(g_heff_2eunify_2euTyRigid_lam40, 1, 8, (V[]){v_cs_245, v_dom_24167, v_cod_24168, v_cod_27_24192, v_r_243, v_g_244, v_hd_24197, v_k_24198})});
}
V g_heff_2eunify_2euTyRigid_lam45(V self, V *args) {
  V v_c_24234 = args[0];
  V v_hd_24232 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24234, 2, (V[]){heff_dup(v_hd_24232), heff_get(v_hd_24232, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam44(V self, V *args) {
  V v_hd_24232 = args[0];
  V v_k2_24233 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24231 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24235 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam45, 1, 1, (V[]){heff_dup(v_hd_24232)}), v_p_24231}));
  V v_t_24236 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24232), LBL_malg), 1, (V[]){v_t_24235}));
  return heff_tail(heff_get(v_hd_24232, LBL_bind), 2, (V[]){v_t_24236, v_k2_24233});
}
V g_heff_2eunify_2euTyRigid_lam47(V self, V *args) {
  V v_c_24244 = args[0];
  V v_hd_24242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24244, 2, (V[]){heff_dup(v_hd_24242), heff_get(v_hd_24242, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam46(V self, V *args) {
  V v_hd_24242 = args[0];
  V v_k2_24243 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24245 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam47, 1, 1, (V[]){heff_dup(v_hd_24242)}), v_p_24241}));
  V v_t_24246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24242), LBL_malg), 1, (V[]){v_t_24245}));
  return heff_tail(heff_get(v_hd_24242, LBL_bind), 2, (V[]){v_t_24246, v_k2_24243});
}
V g_heff_2eunify_2euTyRigid_lam49(V self, V *args) {
  V v_c_24252 = args[0];
  V v_hd_24250 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24252, 2, (V[]){heff_dup(v_hd_24250), heff_get(v_hd_24250, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam48(V self, V *args) {
  V v_hd_24250 = args[0];
  V v_k2_24251 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24253 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam49, 1, 1, (V[]){heff_dup(v_hd_24250)}), v_p_24249}));
  V v_t_24254 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24250), LBL_malg), 1, (V[]){v_t_24253}));
  return heff_tail(heff_get(v_hd_24250, LBL_bind), 2, (V[]){v_t_24254, v_k2_24251});
}
V g_heff_2eunify_2euTyRigid_lam51(V self, V *args) {
  V v_c_24259 = args[0];
  V v_hd_24257 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24259, 2, (V[]){heff_dup(v_hd_24257), heff_get(v_hd_24257, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam50(V self, V *args) {
  V v_hd_24257 = args[0];
  V v_k2_24258 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24256 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24260 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam51, 1, 1, (V[]){heff_dup(v_hd_24257)}), v_p_24256}));
  V v_t_24261 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24257), LBL_malg), 1, (V[]){v_t_24260}));
  return heff_tail(heff_get(v_hd_24257, LBL_bind), 2, (V[]){v_t_24261, v_k2_24258});
}
V g_heff_2eunify_2euTyRigid_lam53(V self, V *args) {
  V v_c_24266 = args[0];
  V v_hd_24264 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24266, 2, (V[]){heff_dup(v_hd_24264), heff_get(v_hd_24264, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam52(V self, V *args) {
  V v_hd_24264 = args[0];
  V v_k2_24265 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24263 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24267 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam53, 1, 1, (V[]){heff_dup(v_hd_24264)}), v_p_24263}));
  V v_t_24268 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24264), LBL_malg), 1, (V[]){v_t_24267}));
  return heff_tail(heff_get(v_hd_24264, LBL_bind), 2, (V[]){v_t_24268, v_k2_24265});
}
V g_heff_2eunify_2euTyRigid_lam55(V self, V *args) {
  V v_c_24273 = args[0];
  V v_hd_24271 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24273, 2, (V[]){heff_dup(v_hd_24271), heff_get(v_hd_24271, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam54(V self, V *args) {
  V v_hd_24271 = args[0];
  V v_k2_24272 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24270 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24274 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam55, 1, 1, (V[]){heff_dup(v_hd_24271)}), v_p_24270}));
  V v_t_24275 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24271), LBL_malg), 1, (V[]){v_t_24274}));
  return heff_tail(heff_get(v_hd_24271, LBL_bind), 2, (V[]){v_t_24275, v_k2_24272});
}
V g_heff_2eunify_2euTyRigid_lam57(V self, V *args) {
  V v_c_24281 = args[0];
  V v_hd_24279 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24281, 2, (V[]){heff_dup(v_hd_24279), heff_get(v_hd_24279, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam56(V self, V *args) {
  V v_hd_24279 = args[0];
  V v_k2_24280 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24278 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24282 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam57, 1, 1, (V[]){heff_dup(v_hd_24279)}), v_p_24278}));
  V v_t_24283 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24279), LBL_malg), 1, (V[]){v_t_24282}));
  return heff_tail(heff_get(v_hd_24279, LBL_bind), 2, (V[]){v_t_24283, v_k2_24280});
}
V g_heff_2eunify_2euTyRigid_lam59(V self, V *args) {
  V v_c_24291 = args[0];
  V v_hd_24289 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24291, 2, (V[]){heff_dup(v_hd_24289), heff_get(v_hd_24289, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam58(V self, V *args) {
  V v_hd_24289 = args[0];
  V v_k2_24290 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24288 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24292 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam59, 1, 1, (V[]){heff_dup(v_hd_24289)}), v_p_24288}));
  V v_t_24293 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24289), LBL_malg), 1, (V[]){v_t_24292}));
  return heff_tail(heff_get(v_hd_24289, LBL_bind), 2, (V[]){v_t_24293, v_k2_24290});
}
V g_heff_2eunify_2euTyRigid_lam61(V self, V *args) {
  V v_c_24299 = args[0];
  V v_hd_24297 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24299, 2, (V[]){heff_dup(v_hd_24297), heff_get(v_hd_24297, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam60(V self, V *args) {
  V v_hd_24297 = args[0];
  V v_k2_24298 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24296 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24300 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam61, 1, 1, (V[]){heff_dup(v_hd_24297)}), v_p_24296}));
  V v_t_24301 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24297), LBL_malg), 1, (V[]){v_t_24300}));
  return heff_tail(heff_get(v_hd_24297, LBL_bind), 2, (V[]){v_t_24301, v_k2_24298});
}
V g_heff_2eunify_2euTyRigid_lam63(V self, V *args) {
  V v_c_24307 = args[0];
  V v_hd_24305 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24307, 2, (V[]){heff_dup(v_hd_24305), heff_get(v_hd_24305, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam62(V self, V *args) {
  V v_hd_24305 = args[0];
  V v_k2_24306 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24304 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24308 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam63, 1, 1, (V[]){heff_dup(v_hd_24305)}), v_p_24304}));
  V v_t_24309 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24305), LBL_malg), 1, (V[]){v_t_24308}));
  return heff_tail(heff_get(v_hd_24305, LBL_bind), 2, (V[]){v_t_24309, v_k2_24306});
}
V g_heff_2eunify_2euTyRigid_lam65(V self, V *args) {
  V v_c_24319 = args[0];
  V v_hd_24317 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24319, 2, (V[]){heff_dup(v_hd_24317), heff_get(v_hd_24317, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam64(V self, V *args) {
  V v_hd_24317 = args[0];
  V v_k2_24318 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24316 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24320 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam65, 1, 1, (V[]){heff_dup(v_hd_24317)}), v_p_24316}));
  V v_t_24321 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24317), LBL_malg), 1, (V[]){v_t_24320}));
  return heff_tail(heff_get(v_hd_24317, LBL_bind), 2, (V[]){v_t_24321, v_k2_24318});
}
V g_heff_2eunify_2euTyRigid_lam67(V self, V *args) {
  V v_c_24330 = args[0];
  V v_hd_24328 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24330, 2, (V[]){heff_dup(v_hd_24328), heff_get(v_hd_24328, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam66(V self, V *args) {
  V v_hd_24328 = args[0];
  V v_k2_24329 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24327 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24331 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam67, 1, 1, (V[]){heff_dup(v_hd_24328)}), v_p_24327}));
  V v_t_24332 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24328), LBL_malg), 1, (V[]){v_t_24331}));
  return heff_tail(heff_get(v_hd_24328, LBL_bind), 2, (V[]){v_t_24332, v_k2_24329});
}
V g_heff_2eunify_2euTyRigid_lam69(V self, V *args) {
  V v_c_24340 = args[0];
  V v_hd_24338 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24340, 2, (V[]){heff_dup(v_hd_24338), heff_get(v_hd_24338, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam68(V self, V *args) {
  V v_hd_24338 = args[0];
  V v_k2_24339 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24337 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24341 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam69, 1, 1, (V[]){heff_dup(v_hd_24338)}), v_p_24337}));
  V v_t_24342 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24338), LBL_malg), 1, (V[]){v_t_24341}));
  return heff_tail(heff_get(v_hd_24338, LBL_bind), 2, (V[]){v_t_24342, v_k2_24339});
}
V g_heff_2eunify_2euTyRigid_lam71(V self, V *args) {
  V v_c_24348 = args[0];
  V v_hd_24346 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24348, 2, (V[]){heff_dup(v_hd_24346), heff_get(v_hd_24346, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam70(V self, V *args) {
  V v_hd_24346 = args[0];
  V v_k2_24347 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24345 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24349 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam71, 1, 1, (V[]){heff_dup(v_hd_24346)}), v_p_24345}));
  V v_t_24350 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24346), LBL_malg), 1, (V[]){v_t_24349}));
  return heff_tail(heff_get(v_hd_24346, LBL_bind), 2, (V[]){v_t_24350, v_k2_24347});
}
V g_heff_2eunify_2euTyRigid_lam72(V self, V *args) {
  V v_hd_24351 = args[0];
  V v_k_24352 = args[1];
  heff_drop(self);
  heff_drop(v_hd_24351);
  return heff_tail(v_k_24352, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euTyRigid_lam74(V self, V *args) {
  V v_c_24357 = args[0];
  V v_hd_24355 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24357, 2, (V[]){heff_dup(v_hd_24355), heff_get(v_hd_24355, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam73(V self, V *args) {
  V v_hd_24355 = args[0];
  V v_k2_24356 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24354 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24358 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam74, 1, 1, (V[]){heff_dup(v_hd_24355)}), v_p_24354}));
  V v_t_24359 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24355), LBL_malg), 1, (V[]){v_t_24358}));
  return heff_tail(heff_get(v_hd_24355, LBL_bind), 2, (V[]){v_t_24359, v_k2_24356});
}
V g_heff_2eunify_2euTyRigid_lam76(V self, V *args) {
  V v_c_24364 = args[0];
  V v_hd_24362 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24364, 2, (V[]){heff_dup(v_hd_24362), heff_get(v_hd_24362, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam75(V self, V *args) {
  V v_hd_24362 = args[0];
  V v_k2_24363 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24361 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24365 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam76, 1, 1, (V[]){heff_dup(v_hd_24362)}), v_p_24361}));
  V v_t_24366 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24362), LBL_malg), 1, (V[]){v_t_24365}));
  return heff_tail(heff_get(v_hd_24362, LBL_bind), 2, (V[]){v_t_24366, v_k2_24363});
}
V g_heff_2eunify_2euTyRigid_lam78(V self, V *args) {
  V v_c_24372 = args[0];
  V v_hd_24370 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24372, 2, (V[]){heff_dup(v_hd_24370), heff_get(v_hd_24370, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam77(V self, V *args) {
  V v_hd_24370 = args[0];
  V v_k2_24371 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24369 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24373 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam78, 1, 1, (V[]){heff_dup(v_hd_24370)}), v_p_24369}));
  V v_t_24374 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24370), LBL_malg), 1, (V[]){v_t_24373}));
  return heff_tail(heff_get(v_hd_24370, LBL_bind), 2, (V[]){v_t_24374, v_k2_24371});
}
V g_heff_2eunify_2euTyRigid_lam80(V self, V *args) {
  V v_c_24380 = args[0];
  V v_hd_24378 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24380, 2, (V[]){heff_dup(v_hd_24378), heff_get(v_hd_24378, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam79(V self, V *args) {
  V v_hd_24378 = args[0];
  V v_k2_24379 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24377 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24381 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam80, 1, 1, (V[]){heff_dup(v_hd_24378)}), v_p_24377}));
  V v_t_24382 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24378), LBL_malg), 1, (V[]){v_t_24381}));
  return heff_tail(heff_get(v_hd_24378, LBL_bind), 2, (V[]){v_t_24382, v_k2_24379});
}
V g_heff_2eunify_2euTyRigid_lam82(V self, V *args) {
  V v_c_24392 = args[0];
  V v_hd_24390 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24392, 2, (V[]){heff_dup(v_hd_24390), heff_get(v_hd_24390, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam81(V self, V *args) {
  V v_hd_24390 = args[0];
  V v_k2_24391 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24389 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24393 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam82, 1, 1, (V[]){heff_dup(v_hd_24390)}), v_p_24389}));
  V v_t_24394 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24390), LBL_malg), 1, (V[]){v_t_24393}));
  return heff_tail(heff_get(v_hd_24390, LBL_bind), 2, (V[]){v_t_24394, v_k2_24391});
}
V g_heff_2eunify_2euTyRigid_lam84(V self, V *args) {
  V v_c_24403 = args[0];
  V v_hd_24401 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24403, 2, (V[]){heff_dup(v_hd_24401), heff_get(v_hd_24401, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam83(V self, V *args) {
  V v_hd_24401 = args[0];
  V v_k2_24402 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24400 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24404 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam84, 1, 1, (V[]){heff_dup(v_hd_24401)}), v_p_24400}));
  V v_t_24405 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24401), LBL_malg), 1, (V[]){v_t_24404}));
  return heff_tail(heff_get(v_hd_24401, LBL_bind), 2, (V[]){v_t_24405, v_k2_24402});
}
V g_heff_2eunify_2euTyRigid_lam86(V self, V *args) {
  V v_c_24413 = args[0];
  V v_hd_24411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24413, 2, (V[]){heff_dup(v_hd_24411), heff_get(v_hd_24411, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam85(V self, V *args) {
  V v_hd_24411 = args[0];
  V v_k2_24412 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24410 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24414 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam86, 1, 1, (V[]){heff_dup(v_hd_24411)}), v_p_24410}));
  V v_t_24415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24411), LBL_malg), 1, (V[]){v_t_24414}));
  return heff_tail(heff_get(v_hd_24411, LBL_bind), 2, (V[]){v_t_24415, v_k2_24412});
}
V g_heff_2eunify_2euTyRigid_lam88(V self, V *args) {
  V v_c_24421 = args[0];
  V v_hd_24419 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24421, 2, (V[]){heff_dup(v_hd_24419), heff_get(v_hd_24419, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam87(V self, V *args) {
  V v_hd_24419 = args[0];
  V v_k2_24420 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24418 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24422 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam88, 1, 1, (V[]){heff_dup(v_hd_24419)}), v_p_24418}));
  V v_t_24423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24419), LBL_malg), 1, (V[]){v_t_24422}));
  return heff_tail(heff_get(v_hd_24419, LBL_bind), 2, (V[]){v_t_24423, v_k2_24420});
}
V g_heff_2eunify_2euTyRigid_lam90(V self, V *args) {
  V v_c_24428 = args[0];
  V v_hd_24426 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24428, 2, (V[]){heff_dup(v_hd_24426), heff_get(v_hd_24426, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam89(V self, V *args) {
  V v_hd_24426 = args[0];
  V v_k2_24427 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24425 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24429 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam90, 1, 1, (V[]){heff_dup(v_hd_24426)}), v_p_24425}));
  V v_t_24430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24426), LBL_malg), 1, (V[]){v_t_24429}));
  return heff_tail(heff_get(v_hd_24426, LBL_bind), 2, (V[]){v_t_24430, v_k2_24427});
}
V g_heff_2eunify_2euTyRigid_lam91(V self, V *args) {
  V v_hd_24431 = args[0];
  V v_k_24432 = args[1];
  heff_drop(self);
  heff_drop(v_hd_24431);
  return heff_tail(v_k_24432, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euTyRigid_lam93(V self, V *args) {
  V v_c_24437 = args[0];
  V v_hd_24435 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24437, 2, (V[]){heff_dup(v_hd_24435), heff_get(v_hd_24435, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam92(V self, V *args) {
  V v_hd_24435 = args[0];
  V v_k2_24436 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24434 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24438 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam93, 1, 1, (V[]){heff_dup(v_hd_24435)}), v_p_24434}));
  V v_t_24439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24435), LBL_malg), 1, (V[]){v_t_24438}));
  return heff_tail(heff_get(v_hd_24435, LBL_bind), 2, (V[]){v_t_24439, v_k2_24436});
}
V g_heff_2eunify_2euTyRigid_lam95(V self, V *args) {
  V v_c_24445 = args[0];
  V v_hd_24443 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24445, 2, (V[]){heff_dup(v_hd_24443), heff_get(v_hd_24443, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam94(V self, V *args) {
  V v_hd_24443 = args[0];
  V v_k2_24444 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24442 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24446 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam95, 1, 1, (V[]){heff_dup(v_hd_24443)}), v_p_24442}));
  V v_t_24447 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24443), LBL_malg), 1, (V[]){v_t_24446}));
  return heff_tail(heff_get(v_hd_24443, LBL_bind), 2, (V[]){v_t_24447, v_k2_24444});
}
V g_heff_2eunify_2euTyRigid_lam97(V self, V *args) {
  V v_c_24453 = args[0];
  V v_hd_24451 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24453, 2, (V[]){heff_dup(v_hd_24451), heff_get(v_hd_24451, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam96(V self, V *args) {
  V v_hd_24451 = args[0];
  V v_k2_24452 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24450 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24454 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam97, 1, 1, (V[]){heff_dup(v_hd_24451)}), v_p_24450}));
  V v_t_24455 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24451), LBL_malg), 1, (V[]){v_t_24454}));
  return heff_tail(heff_get(v_hd_24451, LBL_bind), 2, (V[]){v_t_24455, v_k2_24452});
}
V g_heff_2eunify_2euTyRigid_lam99(V self, V *args) {
  V v_c_24465 = args[0];
  V v_hd_24463 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24465, 2, (V[]){heff_dup(v_hd_24463), heff_get(v_hd_24463, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam98(V self, V *args) {
  V v_hd_24463 = args[0];
  V v_k2_24464 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24462 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24466 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam99, 1, 1, (V[]){heff_dup(v_hd_24463)}), v_p_24462}));
  V v_t_24467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24463), LBL_malg), 1, (V[]){v_t_24466}));
  return heff_tail(heff_get(v_hd_24463, LBL_bind), 2, (V[]){v_t_24467, v_k2_24464});
}
V g_heff_2eunify_2euTyRigid_lam101(V self, V *args) {
  V v_c_24476 = args[0];
  V v_hd_24474 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24476, 2, (V[]){heff_dup(v_hd_24474), heff_get(v_hd_24474, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam100(V self, V *args) {
  V v_hd_24474 = args[0];
  V v_k2_24475 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24473 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24477 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam101, 1, 1, (V[]){heff_dup(v_hd_24474)}), v_p_24473}));
  V v_t_24478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24474), LBL_malg), 1, (V[]){v_t_24477}));
  return heff_tail(heff_get(v_hd_24474, LBL_bind), 2, (V[]){v_t_24478, v_k2_24475});
}
V g_heff_2eunify_2euTyRigid_lam103(V self, V *args) {
  V v_c_24486 = args[0];
  V v_hd_24484 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24486, 2, (V[]){heff_dup(v_hd_24484), heff_get(v_hd_24484, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam102(V self, V *args) {
  V v_hd_24484 = args[0];
  V v_k2_24485 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24483 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24487 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam103, 1, 1, (V[]){heff_dup(v_hd_24484)}), v_p_24483}));
  V v_t_24488 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24484), LBL_malg), 1, (V[]){v_t_24487}));
  return heff_tail(heff_get(v_hd_24484, LBL_bind), 2, (V[]){v_t_24488, v_k2_24485});
}
V g_heff_2eunify_2euTyRigid_lam105(V self, V *args) {
  V v_c_24494 = args[0];
  V v_hd_24492 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24494, 2, (V[]){heff_dup(v_hd_24492), heff_get(v_hd_24492, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam104(V self, V *args) {
  V v_hd_24492 = args[0];
  V v_k2_24493 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24491 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24495 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam105, 1, 1, (V[]){heff_dup(v_hd_24492)}), v_p_24491}));
  V v_t_24496 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24492), LBL_malg), 1, (V[]){v_t_24495}));
  return heff_tail(heff_get(v_hd_24492, LBL_bind), 2, (V[]){v_t_24496, v_k2_24493});
}
V g_heff_2eunify_2euTyRigid_lam107(V self, V *args) {
  V v_c_24501 = args[0];
  V v_hd_24499 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24501, 2, (V[]){heff_dup(v_hd_24499), heff_get(v_hd_24499, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam106(V self, V *args) {
  V v_hd_24499 = args[0];
  V v_k2_24500 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24498 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24502 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam107, 1, 1, (V[]){heff_dup(v_hd_24499)}), v_p_24498}));
  V v_t_24503 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24499), LBL_malg), 1, (V[]){v_t_24502}));
  return heff_tail(heff_get(v_hd_24499, LBL_bind), 2, (V[]){v_t_24503, v_k2_24500});
}
V g_heff_2eunify_2euTyRigid_lam109(V self, V *args) {
  V v_c_24508 = args[0];
  V v_hd_24506 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24508, 2, (V[]){heff_dup(v_hd_24506), heff_get(v_hd_24506, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam108(V self, V *args) {
  V v_hd_24506 = args[0];
  V v_k2_24507 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24505 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24509 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam109, 1, 1, (V[]){heff_dup(v_hd_24506)}), v_p_24505}));
  V v_t_24510 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24506), LBL_malg), 1, (V[]){v_t_24509}));
  return heff_tail(heff_get(v_hd_24506, LBL_bind), 2, (V[]){v_t_24510, v_k2_24507});
}
V g_heff_2eunify_2euTyRigid_lam110(V self, V *args) {
  V v_hd_24511 = args[0];
  V v_k_24512 = args[1];
  heff_drop(self);
  heff_drop(v_hd_24511);
  return heff_tail(v_k_24512, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euTyRigid_lam112(V self, V *args) {
  V v_c_24518 = args[0];
  V v_hd_24516 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24518, 2, (V[]){heff_dup(v_hd_24516), heff_get(v_hd_24516, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam111(V self, V *args) {
  V v_hd_24516 = args[0];
  V v_k2_24517 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24515 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24519 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam112, 1, 1, (V[]){heff_dup(v_hd_24516)}), v_p_24515}));
  V v_t_24520 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24516), LBL_malg), 1, (V[]){v_t_24519}));
  return heff_tail(heff_get(v_hd_24516, LBL_bind), 2, (V[]){v_t_24520, v_k2_24517});
}
V g_heff_2eunify_2euTyRigid_lam114(V self, V *args) {
  V v_c_24527 = args[0];
  V v_hd_24525 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24527, 2, (V[]){heff_dup(v_hd_24525), heff_get(v_hd_24525, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam113(V self, V *args) {
  V v_hd_24525 = args[0];
  V v_k2_24526 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24524 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24528 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam114, 1, 1, (V[]){heff_dup(v_hd_24525)}), v_p_24524}));
  V v_t_24529 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24525), LBL_malg), 1, (V[]){v_t_24528}));
  return heff_tail(heff_get(v_hd_24525, LBL_bind), 2, (V[]){v_t_24529, v_k2_24526});
}
V g_heff_2eunify_2euTyRigid_lam116(V self, V *args) {
  V v_c_24539 = args[0];
  V v_hd_24537 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24539, 2, (V[]){heff_dup(v_hd_24537), heff_get(v_hd_24537, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam115(V self, V *args) {
  V v_hd_24537 = args[0];
  V v_k2_24538 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24536 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24540 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam116, 1, 1, (V[]){heff_dup(v_hd_24537)}), v_p_24536}));
  V v_t_24541 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24537), LBL_malg), 1, (V[]){v_t_24540}));
  return heff_tail(heff_get(v_hd_24537, LBL_bind), 2, (V[]){v_t_24541, v_k2_24538});
}
V g_heff_2eunify_2euTyRigid_lam118(V self, V *args) {
  V v_c_24550 = args[0];
  V v_hd_24548 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24550, 2, (V[]){heff_dup(v_hd_24548), heff_get(v_hd_24548, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam117(V self, V *args) {
  V v_hd_24548 = args[0];
  V v_k2_24549 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24547 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24551 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam118, 1, 1, (V[]){heff_dup(v_hd_24548)}), v_p_24547}));
  V v_t_24552 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24548), LBL_malg), 1, (V[]){v_t_24551}));
  return heff_tail(heff_get(v_hd_24548, LBL_bind), 2, (V[]){v_t_24552, v_k2_24549});
}
V g_heff_2eunify_2euTyRigid_lam120(V self, V *args) {
  V v_c_24560 = args[0];
  V v_hd_24558 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24560, 2, (V[]){heff_dup(v_hd_24558), heff_get(v_hd_24558, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam119(V self, V *args) {
  V v_hd_24558 = args[0];
  V v_k2_24559 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24557 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24561 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam120, 1, 1, (V[]){heff_dup(v_hd_24558)}), v_p_24557}));
  V v_t_24562 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24558), LBL_malg), 1, (V[]){v_t_24561}));
  return heff_tail(heff_get(v_hd_24558, LBL_bind), 2, (V[]){v_t_24562, v_k2_24559});
}
V g_heff_2eunify_2euTyRigid_lam122(V self, V *args) {
  V v_c_24568 = args[0];
  V v_hd_24566 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24568, 2, (V[]){heff_dup(v_hd_24566), heff_get(v_hd_24566, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam121(V self, V *args) {
  V v_hd_24566 = args[0];
  V v_k2_24567 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24565 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24569 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam122, 1, 1, (V[]){heff_dup(v_hd_24566)}), v_p_24565}));
  V v_t_24570 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24566), LBL_malg), 1, (V[]){v_t_24569}));
  return heff_tail(heff_get(v_hd_24566, LBL_bind), 2, (V[]){v_t_24570, v_k2_24567});
}
V g_heff_2eunify_2euTyRigid_lam124(V self, V *args) {
  V v_c_24575 = args[0];
  V v_hd_24573 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24575, 2, (V[]){heff_dup(v_hd_24573), heff_get(v_hd_24573, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam123(V self, V *args) {
  V v_hd_24573 = args[0];
  V v_k2_24574 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24572 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24576 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam124, 1, 1, (V[]){heff_dup(v_hd_24573)}), v_p_24572}));
  V v_t_24577 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24573), LBL_malg), 1, (V[]){v_t_24576}));
  return heff_tail(heff_get(v_hd_24573, LBL_bind), 2, (V[]){v_t_24577, v_k2_24574});
}
V g_heff_2eunify_2euTyRigid_lam126(V self, V *args) {
  V v_c_24582 = args[0];
  V v_hd_24580 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24582, 2, (V[]){heff_dup(v_hd_24580), heff_get(v_hd_24580, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam125(V self, V *args) {
  V v_hd_24580 = args[0];
  V v_k2_24581 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24579 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24583 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam126, 1, 1, (V[]){heff_dup(v_hd_24580)}), v_p_24579}));
  V v_t_24584 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24580), LBL_malg), 1, (V[]){v_t_24583}));
  return heff_tail(heff_get(v_hd_24580, LBL_bind), 2, (V[]){v_t_24584, v_k2_24581});
}
V g_heff_2eunify_2euTyRigid_lam128(V self, V *args) {
  V v_c_24589 = args[0];
  V v_hd_24587 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24589, 2, (V[]){heff_dup(v_hd_24587), heff_get(v_hd_24587, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam127(V self, V *args) {
  V v_hd_24587 = args[0];
  V v_k2_24588 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24586 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24590 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam128, 1, 1, (V[]){heff_dup(v_hd_24587)}), v_p_24586}));
  V v_t_24591 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24587), LBL_malg), 1, (V[]){v_t_24590}));
  return heff_tail(heff_get(v_hd_24587, LBL_bind), 2, (V[]){v_t_24591, v_k2_24588});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2euElRigid_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eunify_2euElRigid_lam3(V self, V *args);
V g_heff_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eunify_2euElRigid_lam5(V self, V *args);
V g_heff_2eunify_2euElRigid_lam4(V self, V *args);
V g_heff_2eunify_2euElRigid_lam7(V self, V *args);
V g_heff_2eunify_2euElRigid_lam6(V self, V *args);
V g_heff_2eunify_2euElRigid_lam9(V self, V *args);
V g_heff_2eunify_2euElRigid_lam8(V self, V *args);
V g_heff_2eunify_2euElRigid_lam11(V self, V *args);
V g_heff_2eunify_2euElRigid_lam10(V self, V *args);
V g_heff_2eunify_2euElRigid_lam13(V self, V *args);
V g_heff_2eunify_2euElRigid_lam12(V self, V *args);
V g_heff_2eunify_2euElRigid_lam15(V self, V *args);
V g_heff_2eunify_2euElRigid_lam14(V self, V *args);
V g_heff_2eunify_2euElRigid_lam17(V self, V *args);
V g_heff_2eunify_2euElRigid_lam16(V self, V *args);
V g_heff_2eunify_2euElRigid_lam19(V self, V *args);
V g_heff_2eunify_2euElRigid_lam18(V self, V *args);
V g_heff_2eunify_2euElRigid_lam20(V self, V *args);
V g_heff_2eunify_2euElRigid_lam21(V self, V *args);
V g_heff_2eunify_2euElRigid_lam22(V self, V *args);
V g_heff_2eunify_2euElRigid_lam24(V self, V *args);
V g_heff_2eunify_2euElRigid_lam23(V self, V *args);
V g_heff_2eunify_2euElRigid_lam26(V self, V *args);
V g_heff_2eunify_2euElRigid_lam25(V self, V *args);
V g_heff_2eunify_2euElRigid_lam28(V self, V *args);
V g_heff_2eunify_2euElRigid_lam27(V self, V *args);
V g_heff_2eunify_2euElRigid_lam30(V self, V *args);
V g_heff_2eunify_2euElRigid_lam29(V self, V *args);
V g_heff_2eunify_2euElRigid_lam32(V self, V *args);
V g_heff_2eunify_2euElRigid_lam31(V self, V *args);
V g_heff_2eunify_2euElRigid_lam33(V self, V *args);
V g_heff_2eunify_2euElRigid_lam35(V self, V *args);
V g_heff_2eunify_2euElRigid_lam34(V self, V *args);
V g_heff_2eunify_2euElRigid_lam36(V self, V *args); static Clo g_heff_2eunify_2euElRigid_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euElRigid_lam36, 2, 0};
Clo g_heff_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euElRigid_entry, 10, 0};

V g_heff_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_ca_246, V v_cb_247, V v_a_248, V v_b_249) {
top: ;
  switch (heff_tag_of(v_ca_246)) {
  case TAG_VNeu: {
    V v_h_2410 = heff_field(v_ca_246, 0);
    V v_sp_2411 = heff_field(v_ca_246, 1);
    heff_take(v_ca_246, 3ULL);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2415 = heff_field(v_cb_247, 0);
      V v_sp_27_2416 = heff_field(v_cb_247, 1);
      heff_take(v_cb_247, 3ULL);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get(v_r_243, LBL_ubare), 6, (V[]){v_g_244, v_cs_245, v_h_2410, v_sp_2411, v_h_27_2415, v_sp_27_2416});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2421 = heff_tag_at(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2422 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2421}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam0, 2, 2, (V[]){v_w_240, v_p_2422});
    }
    case TAG_VLam: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2430 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2431 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2430}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam2, 2, 2, (V[]){v_w_240, v_p_2431});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2438 = heff_tag_at(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2439 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2438}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam4, 2, 2, (V[]){v_w_240, v_p_2439});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_cb_247);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2445 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2446 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2445}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam6, 2, 2, (V[]){v_w_240, v_p_2446});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2452 = heff_field(v_ca_246, 0);
    V v_ru_24ca_246_24VCode = heff_take_reuse(v_ca_246, 1ULL);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2458 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2459 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2458}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam8, 2, 2, (V[]){v_w_240, v_p_2459});
    }
    case TAG_VCode: {
      V v_t_27_2465 = heff_field(v_cb_247, 0);
      heff_take(v_cb_247, 1ULL);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop(v_ru_24ca_246_24VCode);
      return heff_tail(heff_get(v_r_243, LBL_uty), 4, (V[]){v_g_244, v_cs_245, v_t_2452, v_t_27_2465});
    }
    case TAG_VLam: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2468 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2469 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2468}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam10, 2, 2, (V[]){v_w_240, v_p_2469});
    }
    case TAG_VCons: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2476 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2477 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2476}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam12, 2, 2, (V[]){v_w_240, v_p_2477});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_cb_247);
      heff_drop(v_t_2452);
      V v_t_2483 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2484 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2483}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam14, 2, 2, (V[]){v_w_240, v_p_2484});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2490 = heff_field(v_ca_246, 0);
    V v_c_2491 = heff_field(v_ca_246, 1);
    V v_ru_24ca_246_24VLam = heff_take_reuse(v_ca_246, 3ULL);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop(v_ru_24ca_246_24VLam);
      V v_t_2497 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2498 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2497}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam16, 2, 2, (V[]){v_w_240, v_p_2498});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop(v_ru_24ca_246_24VLam);
      V v_t_24105 = heff_tag_at(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24106 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24105}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam18, 2, 2, (V[]){v_w_240, v_p_24106});
    }
    case TAG_VLam: {
      V v_c_27_24113 = heff_field(v_cb_247, 1);
      heff_take(v_cb_247, 2ULL);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_24114 = heff_tr(heff_apply(v_d_2490, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_24115 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_24114)));
      V v_a_24126;
      switch (heff_tag_of(v_t_24115)) {
      case TAG_LikeU: {
        heff_take(v_t_24115, 0ULL);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_24118 = heff_field(v_t_24115, 1);
        heff_take(v_t_24115, 2ULL);
        heff_drop(v_t_24114);
        v_a_24126 = v_dom_24118;
        break;
      }
      case TAG_LikeRecord: {
        heff_take(v_t_24115, 0ULL);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeSum: {
        heff_take(v_t_24115, 0ULL);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeInt: {
        heff_drop(v_t_24115);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeFloat: {
        heff_drop(v_t_24115);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeString: {
        heff_drop(v_t_24115);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeArray: {
        heff_take(v_t_24115, 0ULL);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_NoRules: {
        heff_drop(v_t_24115);
        v_a_24126 = v_t_24114;
        break;
      }
      default: heff_nomatch(v_t_24115);
      }
      V v_t_24127 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_cs_245), LBL_len)});
      V v_v_24129 = (g_heff_2evalue_2emkNeu_24s10(v_t_24127, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2euElRigid_lam20, 1, 1, (V[]){v_a_24126}), NTAG(TAG_Nothing)));
      V v_x_24134;
      switch (heff_tag_of(v_c_2491)) {
      case TAG_MkClo: {
        V v_n_24130 = heff_dup(heff_field(v_c_2491, 0));
        v_x_24134 = v_n_24130;
        break;
      }
      case TAG_CloConst: {
        v_x_24134 = ((V)&g_heff_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2491);
      }
      V v_t_24135 = heff_intAdd(heff_get(heff_dup(v_cs_245), LBL_len), MK_INT(1LL));
      V v_t_24136 = heff_tag_at(v_ru_24ca_246_24VLam, TAG_Cons, 2, (V[]){v_x_24134, heff_get(v_cs_245, LBL_names)});
      V v_x1_24142;
      switch (heff_tag_of(v_c_2491)) {
      case TAG_MkClo: {
        V v_vs_24138 = heff_field(v_c_2491, 1);
        V v_body_24139 = heff_field(v_c_2491, 2);
        heff_take(v_c_2491, 6ULL);
        v_x1_24142 = heff_tr(heff_apply(v_body_24139, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24138, heff_clo(g_heff_2eunify_2euElRigid_lam21, 1, 1, (V[]){heff_dup(v_v_24129)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24141 = heff_field(v_c_2491, 0);
        heff_take(v_c_2491, 1ULL);
        v_x1_24142 = v_body_24141;
        break;
      }
      default: heff_nomatch(v_c_2491);
      }
      V v_t_24146;
      switch (heff_tag_of(v_x1_24142)) {
      case TAG_Nom: {
        V v_x_24143 = heff_field(v_x1_24142, 0);
        heff_take(v_x1_24142, 1ULL);
        v_t_24146 = v_x_24143;
        break;
      }
      case TAG_Describe: {
        heff_take(v_x1_24142, 0ULL);
        v_t_24146 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24145 = heff_field(v_x1_24142, 0);
        heff_take(v_x1_24142, 1ULL);
        v_t_24146 = v_x_24145;
        break;
      }
      default: heff_nomatch(v_x1_24142);
      }
      V v_x1_24152;
      switch (heff_tag_of(v_c_27_24113)) {
      case TAG_MkClo: {
        V v_vs_24148 = heff_field(v_c_27_24113, 1);
        V v_body_24149 = heff_field(v_c_27_24113, 2);
        heff_take(v_c_27_24113, 6ULL);
        v_x1_24152 = heff_tr(heff_apply(v_body_24149, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24148, heff_clo(g_heff_2eunify_2euElRigid_lam22, 1, 1, (V[]){v_v_24129})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24151 = heff_field(v_c_27_24113, 0);
        heff_take(v_c_27_24113, 1ULL);
        heff_drop(v_v_24129);
        v_x1_24152 = v_body_24151;
        break;
      }
      default: heff_nomatch(v_c_27_24113);
      }
      V v_t_24156;
      switch (heff_tag_of(v_x1_24152)) {
      case TAG_Nom: {
        V v_x_24153 = heff_field(v_x1_24152, 0);
        heff_take(v_x1_24152, 1ULL);
        v_t_24156 = v_x_24153;
        break;
      }
      case TAG_Describe: {
        heff_take(v_x1_24152, 0ULL);
        v_t_24156 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24155 = heff_field(v_x1_24152, 0);
        heff_take(v_x1_24152, 1ULL);
        v_t_24156 = v_x_24155;
        break;
      }
      default: heff_nomatch(v_x1_24152);
      }
      return heff_tail(heff_get(v_r_243, LBL_uel), 4, (V[]){v_g_244, heff_rec(2, shape_160_192, (V[]){v_t_24135, v_t_24136}), v_t_24146, v_t_24156});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop(v_ru_24ca_246_24VLam);
      V v_t_24158 = heff_tag_at(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24159 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24158}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam23, 2, 2, (V[]){v_w_240, v_p_24159});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_cb_247);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop(v_ru_24ca_246_24VLam);
      V v_t_24165 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24166 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24165}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam25, 2, 2, (V[]){v_w_240, v_p_24166});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24172 = heff_field(v_ca_246, 0);
    V v_ru_24ca_246_24VCons = heff_take_reuse(v_ca_246, 1ULL);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24178 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24179 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24178}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam27, 2, 2, (V[]){v_w_240, v_p_24179});
    }
    case TAG_VCode: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24186 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24187 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24186}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam29, 2, 2, (V[]){v_w_240, v_p_24187});
    }
    case TAG_VLam: {
      heff_take(v_cb_247, 0ULL);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24195 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24196 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24195}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam31, 2, 2, (V[]){v_w_240, v_p_24196});
    }
    case TAG_VCons: {
      V v_d_27_24202 = heff_field(v_cb_247, 0);
      heff_take(v_cb_247, 1ULL);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop(v_ru_24ca_246_24VCons);
      V v_t_24203 = heff_arrayToList(heff_get(v_d_24172, LBL_values));
      V v_t_24204 = heff_arrayToList(heff_get(v_d_27_24202, LBL_values));
      V v_t_24205 = (g_heff_2eunify_2ezipL(v_t_24203, v_t_24204));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24205; V a_4 = heff_clo(g_heff_2eunify_2euElRigid_lam33, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V r_ = (g_heff_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24205); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_cb_247);
      heff_drop(v_d_24172);
      V v_t_24217 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24218 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24217}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam34, 2, 2, (V[]){v_w_240, v_p_24218});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    heff_drop(v_cs_245);
    heff_drop(v_ca_246);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    return ((V)&g_heff_2eunify_2euElRigid_lam36_clo);
  }
  default: return heff_nomatch(v_ca_246);
  }
}
V g_heff_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euElRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_2423 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_2423), heff_get(v_hd_2423, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2422 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2426 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_hd_2423)}), v_p_2422}));
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_2423, LBL_bind), 2, (V[]){v_t_2427, v_k2_2424});
}
V g_heff_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_c_2434 = args[0];
  V v_hd_2432 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_2432), heff_get(v_hd_2432, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2431 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2435 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam3, 1, 1, (V[]){heff_dup(v_hd_2432)}), v_p_2431}));
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2432), LBL_malg), 1, (V[]){v_t_2435}));
  return heff_tail(heff_get(v_hd_2432, LBL_bind), 2, (V[]){v_t_2436, v_k2_2433});
}
V g_heff_2eunify_2euElRigid_lam5(V self, V *args) {
  V v_c_2442 = args[0];
  V v_hd_2440 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_2440), heff_get(v_hd_2440, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2439 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2443 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam5, 1, 1, (V[]){heff_dup(v_hd_2440)}), v_p_2439}));
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2440), LBL_malg), 1, (V[]){v_t_2443}));
  return heff_tail(heff_get(v_hd_2440, LBL_bind), 2, (V[]){v_t_2444, v_k2_2441});
}
V g_heff_2eunify_2euElRigid_lam7(V self, V *args) {
  V v_c_2449 = args[0];
  V v_hd_2447 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2449, 2, (V[]){heff_dup(v_hd_2447), heff_get(v_hd_2447, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2446 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2450 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam7, 1, 1, (V[]){heff_dup(v_hd_2447)}), v_p_2446}));
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2450}));
  return heff_tail(heff_get(v_hd_2447, LBL_bind), 2, (V[]){v_t_2451, v_k2_2448});
}
V g_heff_2eunify_2euElRigid_lam9(V self, V *args) {
  V v_c_2462 = args[0];
  V v_hd_2460 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2462, 2, (V[]){heff_dup(v_hd_2460), heff_get(v_hd_2460, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam8(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k2_2461 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2459 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2463 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam9, 1, 1, (V[]){heff_dup(v_hd_2460)}), v_p_2459}));
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2460), LBL_malg), 1, (V[]){v_t_2463}));
  return heff_tail(heff_get(v_hd_2460, LBL_bind), 2, (V[]){v_t_2464, v_k2_2461});
}
V g_heff_2eunify_2euElRigid_lam11(V self, V *args) {
  V v_c_2472 = args[0];
  V v_hd_2470 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2472, 2, (V[]){heff_dup(v_hd_2470), heff_get(v_hd_2470, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam10(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2469 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2473 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam11, 1, 1, (V[]){heff_dup(v_hd_2470)}), v_p_2469}));
  V v_t_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2470), LBL_malg), 1, (V[]){v_t_2473}));
  return heff_tail(heff_get(v_hd_2470, LBL_bind), 2, (V[]){v_t_2474, v_k2_2471});
}
V g_heff_2eunify_2euElRigid_lam13(V self, V *args) {
  V v_c_2480 = args[0];
  V v_hd_2478 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2480, 2, (V[]){heff_dup(v_hd_2478), heff_get(v_hd_2478, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam12(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2477 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2481 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam13, 1, 1, (V[]){heff_dup(v_hd_2478)}), v_p_2477}));
  V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2478), LBL_malg), 1, (V[]){v_t_2481}));
  return heff_tail(heff_get(v_hd_2478, LBL_bind), 2, (V[]){v_t_2482, v_k2_2479});
}
V g_heff_2eunify_2euElRigid_lam15(V self, V *args) {
  V v_c_2487 = args[0];
  V v_hd_2485 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2487, 2, (V[]){heff_dup(v_hd_2485), heff_get(v_hd_2485, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam14(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k2_2486 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2484 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2488 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam15, 1, 1, (V[]){heff_dup(v_hd_2485)}), v_p_2484}));
  V v_t_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2485), LBL_malg), 1, (V[]){v_t_2488}));
  return heff_tail(heff_get(v_hd_2485, LBL_bind), 2, (V[]){v_t_2489, v_k2_2486});
}
V g_heff_2eunify_2euElRigid_lam17(V self, V *args) {
  V v_c_24101 = args[0];
  V v_hd_2499 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_2499), heff_get(v_hd_2499, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam16(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k2_24100 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2498 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24102 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam17, 1, 1, (V[]){heff_dup(v_hd_2499)}), v_p_2498}));
  V v_t_24103 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2499), LBL_malg), 1, (V[]){v_t_24102}));
  return heff_tail(heff_get(v_hd_2499, LBL_bind), 2, (V[]){v_t_24103, v_k2_24100});
}
V g_heff_2eunify_2euElRigid_lam19(V self, V *args) {
  V v_c_24109 = args[0];
  V v_hd_24107 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24109, 2, (V[]){heff_dup(v_hd_24107), heff_get(v_hd_24107, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam18(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k2_24108 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24106 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24110 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam19, 1, 1, (V[]){heff_dup(v_hd_24107)}), v_p_24106}));
  V v_t_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24107), LBL_malg), 1, (V[]){v_t_24110}));
  return heff_tail(heff_get(v_hd_24107, LBL_bind), 2, (V[]){v_t_24111, v_k2_24108});
}
V g_heff_2eunify_2euElRigid_lam20(V self, V *args) {
  V v_u_24128 = args[0];
  V v_a_24126 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_24128);
  return v_a_24126;
}
V g_heff_2eunify_2euElRigid_lam21(V self, V *args) {
  V v_w_24140 = args[0];
  V v_v_24129 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_w_24140);
  return v_v_24129;
}
V g_heff_2eunify_2euElRigid_lam22(V self, V *args) {
  V v_w_24150 = args[0];
  V v_v_24129 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_w_24150);
  return v_v_24129;
}
V g_heff_2eunify_2euElRigid_lam24(V self, V *args) {
  V v_c_24162 = args[0];
  V v_hd_24160 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24162, 2, (V[]){heff_dup(v_hd_24160), heff_get(v_hd_24160, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam23(V self, V *args) {
  V v_hd_24160 = args[0];
  V v_k2_24161 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24159 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24163 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam24, 1, 1, (V[]){heff_dup(v_hd_24160)}), v_p_24159}));
  V v_t_24164 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24160), LBL_malg), 1, (V[]){v_t_24163}));
  return heff_tail(heff_get(v_hd_24160, LBL_bind), 2, (V[]){v_t_24164, v_k2_24161});
}
V g_heff_2eunify_2euElRigid_lam26(V self, V *args) {
  V v_c_24169 = args[0];
  V v_hd_24167 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24169, 2, (V[]){heff_dup(v_hd_24167), heff_get(v_hd_24167, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam25(V self, V *args) {
  V v_hd_24167 = args[0];
  V v_k2_24168 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24166 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24170 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam26, 1, 1, (V[]){heff_dup(v_hd_24167)}), v_p_24166}));
  V v_t_24171 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24167), LBL_malg), 1, (V[]){v_t_24170}));
  return heff_tail(heff_get(v_hd_24167, LBL_bind), 2, (V[]){v_t_24171, v_k2_24168});
}
V g_heff_2eunify_2euElRigid_lam28(V self, V *args) {
  V v_c_24182 = args[0];
  V v_hd_24180 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24182, 2, (V[]){heff_dup(v_hd_24180), heff_get(v_hd_24180, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam27(V self, V *args) {
  V v_hd_24180 = args[0];
  V v_k2_24181 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24179 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24183 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam28, 1, 1, (V[]){heff_dup(v_hd_24180)}), v_p_24179}));
  V v_t_24184 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24180), LBL_malg), 1, (V[]){v_t_24183}));
  return heff_tail(heff_get(v_hd_24180, LBL_bind), 2, (V[]){v_t_24184, v_k2_24181});
}
V g_heff_2eunify_2euElRigid_lam30(V self, V *args) {
  V v_c_24190 = args[0];
  V v_hd_24188 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24190, 2, (V[]){heff_dup(v_hd_24188), heff_get(v_hd_24188, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam29(V self, V *args) {
  V v_hd_24188 = args[0];
  V v_k2_24189 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24187 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24191 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam30, 1, 1, (V[]){heff_dup(v_hd_24188)}), v_p_24187}));
  V v_t_24192 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24188), LBL_malg), 1, (V[]){v_t_24191}));
  return heff_tail(heff_get(v_hd_24188, LBL_bind), 2, (V[]){v_t_24192, v_k2_24189});
}
V g_heff_2eunify_2euElRigid_lam32(V self, V *args) {
  V v_c_24199 = args[0];
  V v_hd_24197 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24199, 2, (V[]){heff_dup(v_hd_24197), heff_get(v_hd_24197, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam31(V self, V *args) {
  V v_hd_24197 = args[0];
  V v_k2_24198 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24196 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24200 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam32, 1, 1, (V[]){heff_dup(v_hd_24197)}), v_p_24196}));
  V v_t_24201 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24197), LBL_malg), 1, (V[]){v_t_24200}));
  return heff_tail(heff_get(v_hd_24197, LBL_bind), 2, (V[]){v_t_24201, v_k2_24198});
}
V g_heff_2eunify_2euElRigid_lam33(V self, V *args) {
  V v_p_24206 = args[0];
  V v_r_243 = heff_dup(heff_env(self)[0]);
  V v_g_244 = heff_dup(heff_env(self)[1]);
  V v_cs_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_p_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_p_24206, 0);
    V v_y_24208 = heff_field(v_p_24206, 1);
    heff_take(v_p_24206, 3ULL);
    V v_t_24212;
    switch (heff_tag_of(v_x_24207)) {
    case TAG_Nom: {
      V v_x_24209 = heff_field(v_x_24207, 0);
      heff_take(v_x_24207, 1ULL);
      v_t_24212 = v_x_24209;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x_24207, 0ULL);
      v_t_24212 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24211 = heff_field(v_x_24207, 0);
      heff_take(v_x_24207, 1ULL);
      v_t_24212 = v_x_24211;
      break;
    }
    default: heff_nomatch(v_x_24207);
    }
    V v_t_24216;
    switch (heff_tag_of(v_y_24208)) {
    case TAG_Nom: {
      V v_x_24213 = heff_field(v_y_24208, 0);
      heff_take(v_y_24208, 1ULL);
      v_t_24216 = v_x_24213;
      break;
    }
    case TAG_Describe: {
      heff_take(v_y_24208, 0ULL);
      v_t_24216 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24215 = heff_field(v_y_24208, 0);
      heff_take(v_y_24208, 1ULL);
      v_t_24216 = v_x_24215;
      break;
    }
    default: heff_nomatch(v_y_24208);
    }
    return heff_tail(heff_get(v_r_243, LBL_uel), 4, (V[]){v_g_244, v_cs_245, v_t_24212, v_t_24216});
  }
  default: return heff_nomatch(v_p_24206);
  }
}
V g_heff_2eunify_2euElRigid_lam35(V self, V *args) {
  V v_c_24221 = args[0];
  V v_hd_24219 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_24221, 2, (V[]){heff_dup(v_hd_24219), heff_get(v_hd_24219, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam34(V self, V *args) {
  V v_hd_24219 = args[0];
  V v_k2_24220 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_24218 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24222 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam35, 1, 1, (V[]){heff_dup(v_hd_24219)}), v_p_24218}));
  V v_t_24223 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24219), LBL_malg), 1, (V[]){v_t_24222}));
  return heff_tail(heff_get(v_hd_24219, LBL_bind), 2, (V[]){v_t_24223, v_k2_24220});
}
V g_heff_2eunify_2euElRigid_lam36(V self, V *args) {
  V v_hd_24224 = args[0];
  V v_k_24225 = args[1];
  heff_drop(self);
  heff_drop(v_hd_24224);
  return heff_tail(v_k_24225, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eunify_2euTermF_lam1(V self, V *args);
V g_heff_2eunify_2euTermF_lam5(V self, V *args);
V g_heff_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eunify_2euTermF_lam9(V self, V *args);
V g_heff_2eunify_2euTermF_lam8(V self, V *args);
V g_heff_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eunify_2euTermF_lam3(V self, V *args);
Clo g_heff_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_p_249 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  V v_c_2415 = heff_clo(g_heff_2eunify_2euTermF_lam1, 2, 2, (V[]){heff_dup(v_w_240), v_p_249});
  return heff_clo(g_heff_2eunify_2euTermF_lam3, 2, 8, (V[]){v_c_2415, v_ms_241, v_b0_247, v_w_240, v_uf_242, v_cs_245, v_r_243, v_g_244});
}
V g_heff_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_a0_246; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTermF_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_hd_2410 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2410), heff_get(v_hd_2410, LBL_ret)});
}
V g_heff_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2413 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam2, 1, 1, (V[]){heff_dup(v_hd_2410)}), v_p_249}));
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_2410, LBL_bind), 2, (V[]){v_t_2414, v_k2_2411});
}
V g_heff_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2419 = args[0];
  V v_b0_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V b_0 = heff_get(v_c_2419, LBL_metas); V a_1 = v_b0_247; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTermF_lam7(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_2421 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2421), heff_get(v_hd_2421, LBL_ret)});
}
V g_heff_2eunify_2euTermF_lam6(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_p_2420 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2424 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam7, 1, 1, (V[]){heff_dup(v_hd_2421)}), v_p_2420}));
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get(v_hd_2421, LBL_bind), 2, (V[]){v_t_2425, v_k2_2422});
}
V g_heff_2eunify_2euTermF_lam9(V self, V *args) {
  V v_x_2491 = args[0];
  V v_w_240 = heff_dup(heff_env(self)[0]);
  V v_ms_241 = heff_dup(heff_env(self)[1]);
  V v_uf_242 = heff_dup(heff_env(self)[2]);
  V v_cs_245 = heff_dup(heff_env(self)[3]);
  V v_x_2427 = heff_dup(heff_env(self)[4]);
  V v_hd_2416 = heff_dup(heff_env(self)[5]);
  V v_k_2417 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  heff_drop(v_x_2491);
  V v_t_2492 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = heff_get(v_cs_245, LBL_len); V a_4 = v_x_2427; V r_ = (g_heff_2eunify_2epoisonEl(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_uf_242); r_; });
  return heff_tail(v_t_2492, 2, (V[]){v_hd_2416, v_k_2417});
}
V g_heff_2eunify_2euTermF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2418 = heff_dup(heff_env(self)[0]);
  V v_w_240 = heff_dup(heff_env(self)[1]);
  V v_ms_241 = heff_dup(heff_env(self)[2]);
  V v_uf_242 = heff_dup(heff_env(self)[3]);
  V v_cs_245 = heff_dup(heff_env(self)[4]);
  V v_hd_2416 = heff_dup(heff_env(self)[5]);
  V v_k_2417 = heff_dup(heff_env(self)[6]);
  V v_r_243 = heff_dup(heff_env(self)[7]);
  V v_g_244 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  V v_t_2458;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_VNeu: {
    V v_h_2428 = heff_dup(heff_field(v_x_2418, 0));
    switch (heff_tag_of(v_h_2428)) {
    case TAG_HLocal: {
      heff_take(v_h_2428, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take(v_h_2428, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take(v_h_2428, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      heff_drop(v_h_2428);
      v_t_2458 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2428);
    }
    break;
  }
  case TAG_VCode: {
    V v_it1_2436 = heff_dup(heff_field(v_x_2418, 0));
    switch (heff_tag_of(v_it1_2436)) {
    case TAG_VU: {
      heff_take(v_it1_2436, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2438 = heff_field(v_it1_2436, 0);
      heff_take(v_it1_2436, 1ULL);
      switch (heff_tag_of(v_h_2438)) {
      case TAG_HLocal: {
        heff_take(v_h_2438, 0ULL);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take(v_h_2438, 0ULL);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take(v_h_2438, 0ULL);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        heff_drop(v_h_2438);
        v_t_2458 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2438);
      }
      break;
    }
    case TAG_VFunction: {
      heff_take(v_it1_2436, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      heff_take(v_it1_2436, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      heff_take(v_it1_2436, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      heff_drop(v_it1_2436);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      heff_drop(v_it1_2436);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      heff_drop(v_it1_2436);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      heff_take(v_it1_2436, 0ULL);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2436);
    }
    break;
  }
  case TAG_VLam: {
    v_t_2458 = NTAG(TAG_False);
    break;
  }
  case TAG_VCons: {
    v_t_2458 = NTAG(TAG_False);
    break;
  }
  case TAG_VOpaque: {
    v_t_2458 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2489;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_True: {
    heff_drop(v_t_2458);
    v_t_2489 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2458);
    switch (heff_tag_of(v_x_2427)) {
    case TAG_VNeu: {
      V v_h_2459 = heff_dup(heff_field(v_x_2427, 0));
      switch (heff_tag_of(v_h_2459)) {
      case TAG_HLocal: {
        heff_take(v_h_2459, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take(v_h_2459, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take(v_h_2459, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        heff_drop(v_h_2459);
        v_t_2489 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2459);
      }
      break;
    }
    case TAG_VCode: {
      V v_it1_2467 = heff_dup(heff_field(v_x_2427, 0));
      switch (heff_tag_of(v_it1_2467)) {
      case TAG_VU: {
        heff_take(v_it1_2467, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_h_2469 = heff_field(v_it1_2467, 0);
        heff_take(v_it1_2467, 1ULL);
        switch (heff_tag_of(v_h_2469)) {
        case TAG_HLocal: {
          heff_take(v_h_2469, 0ULL);
          v_t_2489 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take(v_h_2469, 0ULL);
          v_t_2489 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take(v_h_2469, 0ULL);
          v_t_2489 = NTAG(TAG_False);
          break;
        }
        case TAG_HError: {
          heff_drop(v_h_2469);
          v_t_2489 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_h_2469);
        }
        break;
      }
      case TAG_VFunction: {
        heff_take(v_it1_2467, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        heff_take(v_it1_2467, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        heff_take(v_it1_2467, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        heff_drop(v_it1_2467);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        heff_drop(v_it1_2467);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        heff_drop(v_it1_2467);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        heff_take(v_it1_2467, 0ULL);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2467);
      }
      break;
    }
    case TAG_VLam: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_VCons: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_VOpaque: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  switch (heff_tag_of(v_t_2489)) {
  case TAG_True: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    heff_drop(v_t_2489);
    V v_c_2490 = (g_heff_2eunify_2epoisonEl(heff_dup(v_w_240), heff_dup(v_ms_241), v_uf_242, heff_get(heff_dup(v_cs_245), LBL_len), v_x_2418));
    return heff_tail(v_c_2490, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam9, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_cs_245, v_x_2427, v_hd_2416, v_k_2417})});
  }
  case TAG_False: {
    heff_drop(v_t_2489);
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24115;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24103 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24104 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24103)) {
          case TAG_HLocal: {
            heff_take(v_it1_24103, 0ULL);
            heff_drop(v_sp_24104);
            v_it_24115 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24103, 0ULL);
            heff_drop(v_sp_24104);
            v_it_24115 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24110 = heff_field(v_it1_24103, 0);
            V v_ru_24it1_24103_24HMeta = heff_take_reuse(v_it1_24103, 1ULL);
            v_it_24115 = heff_tag_at(v_ru_24it1_24103_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24110, v_sp_24104})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24103);
            heff_drop(v_sp_24104);
            v_it_24115 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24103);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24115 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24115)) {
        case TAG_Nothing: {
          heff_drop(v_it_24115);
          V v_it_24128;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24116 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24117 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24116)) {
            case TAG_HLocal: {
              heff_take(v_it1_24116, 0ULL);
              heff_drop(v_sp_24117);
              v_it_24128 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24116, 0ULL);
              heff_drop(v_sp_24117);
              v_it_24128 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24123 = heff_field(v_it1_24116, 0);
              V v_ru_24it1_24116_24HMeta = heff_take_reuse(v_it1_24116, 1ULL);
              v_it_24128 = heff_tag_at(v_ru_24it1_24116_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24123, v_sp_24117})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24116);
              heff_drop(v_sp_24117);
              v_it_24128 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24116);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24128 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24128)) {
          case TAG_Nothing: {
            heff_drop(v_it_24128);
            V v_t_24141;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24129 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24129)) {
              case TAG_HLocal: {
                heff_take(v_it1_24129, 0ULL);
                v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24129, 0ULL);
                v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24129, 0ULL);
                v_t_24141 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24129);
                v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24129);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24141 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24154;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24142 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24142)) {
              case TAG_HLocal: {
                heff_take(v_it1_24142, 0ULL);
                v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24142, 0ULL);
                v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24142, 0ULL);
                v_t_24154 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24142);
                v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24142);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24154 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24155 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24141; V a_7 = v_t_24154; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24155, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24156 = heff_field(v_it_24128, 0);
            heff_take(v_it_24128, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24156)) {
            case TAG_MkPair: {
              V v_m_24157 = heff_field(v_it1_24156, 0);
              V v_sp_24158 = heff_field(v_it1_24156, 1);
              heff_take(v_it1_24156, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24157, v_sp_24158, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24156);
            }
          }
          default: return heff_nomatch(v_it_24128);
          }
        }
        case TAG_Just: {
          V v_it1_24159 = heff_field(v_it_24115, 0);
          heff_take(v_it_24115, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24159)) {
          case TAG_MkPair: {
            V v_m_24160 = heff_field(v_it1_24159, 0);
            V v_sp_24161 = heff_field(v_it1_24159, 1);
            heff_take(v_it1_24159, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24160, v_sp_24161, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24159);
          }
        }
        default: return heff_nomatch(v_it_24115);
        }
      }
      case TAG_VCode: {
        V v_it_24175;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24163 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24164 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24163)) {
          case TAG_HLocal: {
            heff_take(v_it1_24163, 0ULL);
            heff_drop(v_sp_24164);
            v_it_24175 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24163, 0ULL);
            heff_drop(v_sp_24164);
            v_it_24175 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24170 = heff_field(v_it1_24163, 0);
            V v_ru_24it1_24163_24HMeta = heff_take_reuse(v_it1_24163, 1ULL);
            v_it_24175 = heff_tag_at(v_ru_24it1_24163_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24170, v_sp_24164})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24163);
            heff_drop(v_sp_24164);
            v_it_24175 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24163);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24175 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24175 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24175 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24175 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24175)) {
        case TAG_Nothing: {
          heff_drop(v_it_24175);
          V v_it_24188;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24176 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24177 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24176)) {
            case TAG_HLocal: {
              heff_take(v_it1_24176, 0ULL);
              heff_drop(v_sp_24177);
              v_it_24188 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24176, 0ULL);
              heff_drop(v_sp_24177);
              v_it_24188 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24183 = heff_field(v_it1_24176, 0);
              V v_ru_24it1_24176_24HMeta = heff_take_reuse(v_it1_24176, 1ULL);
              v_it_24188 = heff_tag_at(v_ru_24it1_24176_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24183, v_sp_24177})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24176);
              heff_drop(v_sp_24177);
              v_it_24188 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24176);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24188 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24188 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24188 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24188 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24188)) {
          case TAG_Nothing: {
            heff_drop(v_it_24188);
            V v_t_24201;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24189 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24189)) {
              case TAG_HLocal: {
                heff_take(v_it1_24189, 0ULL);
                v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24189, 0ULL);
                v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24189, 0ULL);
                v_t_24201 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24189);
                v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24189);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24201 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24214;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24202 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24202)) {
              case TAG_HLocal: {
                heff_take(v_it1_24202, 0ULL);
                v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24202, 0ULL);
                v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24202, 0ULL);
                v_t_24214 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24202);
                v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24202);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24214 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24215 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24201; V a_7 = v_t_24214; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24215, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24216 = heff_field(v_it_24188, 0);
            heff_take(v_it_24188, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24216)) {
            case TAG_MkPair: {
              V v_m_24217 = heff_field(v_it1_24216, 0);
              V v_sp_24218 = heff_field(v_it1_24216, 1);
              heff_take(v_it1_24216, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24217, v_sp_24218, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24216);
            }
          }
          default: return heff_nomatch(v_it_24188);
          }
        }
        case TAG_Just: {
          V v_it1_24219 = heff_field(v_it_24175, 0);
          heff_take(v_it_24175, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24219)) {
          case TAG_MkPair: {
            V v_m_24220 = heff_field(v_it1_24219, 0);
            V v_sp_24221 = heff_field(v_it1_24219, 1);
            heff_take(v_it1_24219, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24220, v_sp_24221, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24219);
          }
        }
        default: return heff_nomatch(v_it_24175);
        }
      }
      case TAG_VLam: {
        V v_it_24236;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24224 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24225 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24224)) {
          case TAG_HLocal: {
            heff_take(v_it1_24224, 0ULL);
            heff_drop(v_sp_24225);
            v_it_24236 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24224, 0ULL);
            heff_drop(v_sp_24225);
            v_it_24236 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24231 = heff_field(v_it1_24224, 0);
            V v_ru_24it1_24224_24HMeta = heff_take_reuse(v_it1_24224, 1ULL);
            v_it_24236 = heff_tag_at(v_ru_24it1_24224_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24231, v_sp_24225})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24224);
            heff_drop(v_sp_24225);
            v_it_24236 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24224);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24236 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24236)) {
        case TAG_Nothing: {
          heff_drop(v_it_24236);
          V v_it_24249;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24237 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24238 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24237)) {
            case TAG_HLocal: {
              heff_take(v_it1_24237, 0ULL);
              heff_drop(v_sp_24238);
              v_it_24249 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24237, 0ULL);
              heff_drop(v_sp_24238);
              v_it_24249 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24244 = heff_field(v_it1_24237, 0);
              V v_ru_24it1_24237_24HMeta = heff_take_reuse(v_it1_24237, 1ULL);
              v_it_24249 = heff_tag_at(v_ru_24it1_24237_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24244, v_sp_24238})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24237);
              heff_drop(v_sp_24238);
              v_it_24249 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24237);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24249 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24249)) {
          case TAG_Nothing: {
            heff_drop(v_it_24249);
            V v_t_24262;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24250 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24250)) {
              case TAG_HLocal: {
                heff_take(v_it1_24250, 0ULL);
                v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24250, 0ULL);
                v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24250, 0ULL);
                v_t_24262 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24250);
                v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24250);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24262 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24275;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24263 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24263)) {
              case TAG_HLocal: {
                heff_take(v_it1_24263, 0ULL);
                v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24263, 0ULL);
                v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24263, 0ULL);
                v_t_24275 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24263);
                v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24263);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24275 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24276 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24262; V a_7 = v_t_24275; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24276, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24277 = heff_field(v_it_24249, 0);
            heff_take(v_it_24249, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24277)) {
            case TAG_MkPair: {
              V v_m_24278 = heff_field(v_it1_24277, 0);
              V v_sp_24279 = heff_field(v_it1_24277, 1);
              heff_take(v_it1_24277, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24278, v_sp_24279, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24277);
            }
          }
          default: return heff_nomatch(v_it_24249);
          }
        }
        case TAG_Just: {
          V v_it1_24280 = heff_field(v_it_24236, 0);
          heff_take(v_it_24236, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24280)) {
          case TAG_MkPair: {
            V v_m_24281 = heff_field(v_it1_24280, 0);
            V v_sp_24282 = heff_field(v_it1_24280, 1);
            heff_take(v_it1_24280, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24281, v_sp_24282, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24280);
          }
        }
        default: return heff_nomatch(v_it_24236);
        }
      }
      case TAG_VCons: {
        V v_it_24296;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24284 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24285 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24284)) {
          case TAG_HLocal: {
            heff_take(v_it1_24284, 0ULL);
            heff_drop(v_sp_24285);
            v_it_24296 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24284, 0ULL);
            heff_drop(v_sp_24285);
            v_it_24296 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24291 = heff_field(v_it1_24284, 0);
            V v_ru_24it1_24284_24HMeta = heff_take_reuse(v_it1_24284, 1ULL);
            v_it_24296 = heff_tag_at(v_ru_24it1_24284_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24291, v_sp_24285})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24284);
            heff_drop(v_sp_24285);
            v_it_24296 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24284);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24296 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24296 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24296 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24296 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24296)) {
        case TAG_Nothing: {
          heff_drop(v_it_24296);
          V v_it_24309;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24297 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24298 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24297)) {
            case TAG_HLocal: {
              heff_take(v_it1_24297, 0ULL);
              heff_drop(v_sp_24298);
              v_it_24309 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24297, 0ULL);
              heff_drop(v_sp_24298);
              v_it_24309 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24304 = heff_field(v_it1_24297, 0);
              V v_ru_24it1_24297_24HMeta = heff_take_reuse(v_it1_24297, 1ULL);
              v_it_24309 = heff_tag_at(v_ru_24it1_24297_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24304, v_sp_24298})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24297);
              heff_drop(v_sp_24298);
              v_it_24309 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24297);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24309 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24309 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24309 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24309 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24309)) {
          case TAG_Nothing: {
            heff_drop(v_it_24309);
            V v_t_24322;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24310 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24310)) {
              case TAG_HLocal: {
                heff_take(v_it1_24310, 0ULL);
                v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24310, 0ULL);
                v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24310, 0ULL);
                v_t_24322 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24310);
                v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24310);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24322 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24335;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24323 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24323)) {
              case TAG_HLocal: {
                heff_take(v_it1_24323, 0ULL);
                v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24323, 0ULL);
                v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24323, 0ULL);
                v_t_24335 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24323);
                v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24323);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24335 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24336 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24322; V a_7 = v_t_24335; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24336, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24337 = heff_field(v_it_24309, 0);
            heff_take(v_it_24309, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24337)) {
            case TAG_MkPair: {
              V v_m_24338 = heff_field(v_it1_24337, 0);
              V v_sp_24339 = heff_field(v_it1_24337, 1);
              heff_take(v_it1_24337, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24338, v_sp_24339, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24337);
            }
          }
          default: return heff_nomatch(v_it_24309);
          }
        }
        case TAG_Just: {
          V v_it1_24340 = heff_field(v_it_24296, 0);
          heff_take(v_it_24296, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24340)) {
          case TAG_MkPair: {
            V v_m_24341 = heff_field(v_it1_24340, 0);
            V v_sp_24342 = heff_field(v_it1_24340, 1);
            heff_take(v_it1_24340, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24341, v_sp_24342, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24340);
          }
        }
        default: return heff_nomatch(v_it_24296);
        }
      }
      case TAG_VOpaque: {
        heff_drop(v_x_2427);
        heff_drop(v_x_2418);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        return heff_tail(v_k_2417, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24361;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24349 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24350 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24349)) {
          case TAG_HLocal: {
            heff_take(v_it1_24349, 0ULL);
            heff_drop(v_sp_24350);
            v_it_24361 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24349, 0ULL);
            heff_drop(v_sp_24350);
            v_it_24361 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24356 = heff_field(v_it1_24349, 0);
            V v_ru_24it1_24349_24HMeta = heff_take_reuse(v_it1_24349, 1ULL);
            v_it_24361 = heff_tag_at(v_ru_24it1_24349_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24356, v_sp_24350})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24349);
            heff_drop(v_sp_24350);
            v_it_24361 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24349);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24361 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24361)) {
        case TAG_Nothing: {
          heff_drop(v_it_24361);
          V v_it_24374;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24362 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24363 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24362)) {
            case TAG_HLocal: {
              heff_take(v_it1_24362, 0ULL);
              heff_drop(v_sp_24363);
              v_it_24374 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24362, 0ULL);
              heff_drop(v_sp_24363);
              v_it_24374 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24369 = heff_field(v_it1_24362, 0);
              V v_ru_24it1_24362_24HMeta = heff_take_reuse(v_it1_24362, 1ULL);
              v_it_24374 = heff_tag_at(v_ru_24it1_24362_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24369, v_sp_24363})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24362);
              heff_drop(v_sp_24363);
              v_it_24374 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24362);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24374 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24374)) {
          case TAG_Nothing: {
            heff_drop(v_it_24374);
            V v_t_24387;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24375 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24375)) {
              case TAG_HLocal: {
                heff_take(v_it1_24375, 0ULL);
                v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24375, 0ULL);
                v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24375, 0ULL);
                v_t_24387 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24375);
                v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24375);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24387 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24400;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24388 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24388)) {
              case TAG_HLocal: {
                heff_take(v_it1_24388, 0ULL);
                v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24388, 0ULL);
                v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24388, 0ULL);
                v_t_24400 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24388);
                v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24388);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24400 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24401 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24387; V a_7 = v_t_24400; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24401, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24402 = heff_field(v_it_24374, 0);
            heff_take(v_it_24374, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24402)) {
            case TAG_MkPair: {
              V v_m_24403 = heff_field(v_it1_24402, 0);
              V v_sp_24404 = heff_field(v_it1_24402, 1);
              heff_take(v_it1_24402, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24403, v_sp_24404, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24402);
            }
          }
          default: return heff_nomatch(v_it_24374);
          }
        }
        case TAG_Just: {
          V v_it1_24405 = heff_field(v_it_24361, 0);
          heff_take(v_it_24361, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24405)) {
          case TAG_MkPair: {
            V v_m_24406 = heff_field(v_it1_24405, 0);
            V v_sp_24407 = heff_field(v_it1_24405, 1);
            heff_take(v_it1_24405, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24406, v_sp_24407, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24405);
          }
        }
        default: return heff_nomatch(v_it_24361);
        }
      }
      case TAG_VCode: {
        V v_it_24421;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24409 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24410 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24409)) {
          case TAG_HLocal: {
            heff_take(v_it1_24409, 0ULL);
            heff_drop(v_sp_24410);
            v_it_24421 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24409, 0ULL);
            heff_drop(v_sp_24410);
            v_it_24421 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24416 = heff_field(v_it1_24409, 0);
            V v_ru_24it1_24409_24HMeta = heff_take_reuse(v_it1_24409, 1ULL);
            v_it_24421 = heff_tag_at(v_ru_24it1_24409_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24416, v_sp_24410})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24409);
            heff_drop(v_sp_24410);
            v_it_24421 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24409);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24421 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24421)) {
        case TAG_Nothing: {
          heff_drop(v_it_24421);
          V v_it_24434;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24422 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24423 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24422)) {
            case TAG_HLocal: {
              heff_take(v_it1_24422, 0ULL);
              heff_drop(v_sp_24423);
              v_it_24434 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24422, 0ULL);
              heff_drop(v_sp_24423);
              v_it_24434 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24429 = heff_field(v_it1_24422, 0);
              V v_ru_24it1_24422_24HMeta = heff_take_reuse(v_it1_24422, 1ULL);
              v_it_24434 = heff_tag_at(v_ru_24it1_24422_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24429, v_sp_24423})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24422);
              heff_drop(v_sp_24423);
              v_it_24434 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24422);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24434 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24434 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24434 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24434 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24434)) {
          case TAG_Nothing: {
            heff_drop(v_it_24434);
            V v_t_24447;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24435 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24435)) {
              case TAG_HLocal: {
                heff_take(v_it1_24435, 0ULL);
                v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24435, 0ULL);
                v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24435, 0ULL);
                v_t_24447 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24435);
                v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24435);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24447 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24460;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24448 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24448)) {
              case TAG_HLocal: {
                heff_take(v_it1_24448, 0ULL);
                v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24448, 0ULL);
                v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24448, 0ULL);
                v_t_24460 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24448);
                v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24448);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24460 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24461 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24447; V a_7 = v_t_24460; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24461, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24462 = heff_field(v_it_24434, 0);
            heff_take(v_it_24434, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24462)) {
            case TAG_MkPair: {
              V v_m_24463 = heff_field(v_it1_24462, 0);
              V v_sp_24464 = heff_field(v_it1_24462, 1);
              heff_take(v_it1_24462, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24463, v_sp_24464, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24462);
            }
          }
          default: return heff_nomatch(v_it_24434);
          }
        }
        case TAG_Just: {
          V v_it1_24465 = heff_field(v_it_24421, 0);
          heff_take(v_it_24421, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24465)) {
          case TAG_MkPair: {
            V v_m_24466 = heff_field(v_it1_24465, 0);
            V v_sp_24467 = heff_field(v_it1_24465, 1);
            heff_take(v_it1_24465, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24466, v_sp_24467, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24465);
          }
        }
        default: return heff_nomatch(v_it_24421);
        }
      }
      case TAG_VLam: {
        V v_it_24482;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24470 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24471 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24470)) {
          case TAG_HLocal: {
            heff_take(v_it1_24470, 0ULL);
            heff_drop(v_sp_24471);
            v_it_24482 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24470, 0ULL);
            heff_drop(v_sp_24471);
            v_it_24482 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24477 = heff_field(v_it1_24470, 0);
            V v_ru_24it1_24470_24HMeta = heff_take_reuse(v_it1_24470, 1ULL);
            v_it_24482 = heff_tag_at(v_ru_24it1_24470_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24477, v_sp_24471})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24470);
            heff_drop(v_sp_24471);
            v_it_24482 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24470);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24482 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24482)) {
        case TAG_Nothing: {
          heff_drop(v_it_24482);
          V v_it_24495;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24483 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24484 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24483)) {
            case TAG_HLocal: {
              heff_take(v_it1_24483, 0ULL);
              heff_drop(v_sp_24484);
              v_it_24495 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24483, 0ULL);
              heff_drop(v_sp_24484);
              v_it_24495 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24490 = heff_field(v_it1_24483, 0);
              V v_ru_24it1_24483_24HMeta = heff_take_reuse(v_it1_24483, 1ULL);
              v_it_24495 = heff_tag_at(v_ru_24it1_24483_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24490, v_sp_24484})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24483);
              heff_drop(v_sp_24484);
              v_it_24495 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24483);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24495 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24495)) {
          case TAG_Nothing: {
            heff_drop(v_it_24495);
            V v_t_24508;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24496 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24496)) {
              case TAG_HLocal: {
                heff_take(v_it1_24496, 0ULL);
                v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24496, 0ULL);
                v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24496, 0ULL);
                v_t_24508 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24496);
                v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24496);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24508 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24521;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24509 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24509)) {
              case TAG_HLocal: {
                heff_take(v_it1_24509, 0ULL);
                v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24509, 0ULL);
                v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24509, 0ULL);
                v_t_24521 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24509);
                v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24509);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24521 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24522 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24508; V a_7 = v_t_24521; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24522, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24523 = heff_field(v_it_24495, 0);
            heff_take(v_it_24495, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24523)) {
            case TAG_MkPair: {
              V v_m_24524 = heff_field(v_it1_24523, 0);
              V v_sp_24525 = heff_field(v_it1_24523, 1);
              heff_take(v_it1_24523, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24524, v_sp_24525, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24523);
            }
          }
          default: return heff_nomatch(v_it_24495);
          }
        }
        case TAG_Just: {
          V v_it1_24526 = heff_field(v_it_24482, 0);
          heff_take(v_it_24482, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24526)) {
          case TAG_MkPair: {
            V v_m_24527 = heff_field(v_it1_24526, 0);
            V v_sp_24528 = heff_field(v_it1_24526, 1);
            heff_take(v_it1_24526, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24527, v_sp_24528, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24526);
          }
        }
        default: return heff_nomatch(v_it_24482);
        }
      }
      case TAG_VCons: {
        V v_it_24542;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24530 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24531 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24530)) {
          case TAG_HLocal: {
            heff_take(v_it1_24530, 0ULL);
            heff_drop(v_sp_24531);
            v_it_24542 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24530, 0ULL);
            heff_drop(v_sp_24531);
            v_it_24542 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24537 = heff_field(v_it1_24530, 0);
            V v_ru_24it1_24530_24HMeta = heff_take_reuse(v_it1_24530, 1ULL);
            v_it_24542 = heff_tag_at(v_ru_24it1_24530_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24537, v_sp_24531})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24530);
            heff_drop(v_sp_24531);
            v_it_24542 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24530);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24542 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24542 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24542 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24542 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24542)) {
        case TAG_Nothing: {
          heff_drop(v_it_24542);
          V v_it_24555;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24543 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24544 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24543)) {
            case TAG_HLocal: {
              heff_take(v_it1_24543, 0ULL);
              heff_drop(v_sp_24544);
              v_it_24555 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24543, 0ULL);
              heff_drop(v_sp_24544);
              v_it_24555 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24550 = heff_field(v_it1_24543, 0);
              V v_ru_24it1_24543_24HMeta = heff_take_reuse(v_it1_24543, 1ULL);
              v_it_24555 = heff_tag_at(v_ru_24it1_24543_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24550, v_sp_24544})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24543);
              heff_drop(v_sp_24544);
              v_it_24555 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24543);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24555 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24555 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24555 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24555 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24555)) {
          case TAG_Nothing: {
            heff_drop(v_it_24555);
            V v_t_24568;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24556 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24556)) {
              case TAG_HLocal: {
                heff_take(v_it1_24556, 0ULL);
                v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24556, 0ULL);
                v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24556, 0ULL);
                v_t_24568 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24556);
                v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24556);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24568 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24581;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24569 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24569)) {
              case TAG_HLocal: {
                heff_take(v_it1_24569, 0ULL);
                v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24569, 0ULL);
                v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24569, 0ULL);
                v_t_24581 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24569);
                v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24569);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24581 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24582 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24568; V a_7 = v_t_24581; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24582, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24583 = heff_field(v_it_24555, 0);
            heff_take(v_it_24555, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24583)) {
            case TAG_MkPair: {
              V v_m_24584 = heff_field(v_it1_24583, 0);
              V v_sp_24585 = heff_field(v_it1_24583, 1);
              heff_take(v_it1_24583, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24584, v_sp_24585, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24583);
            }
          }
          default: return heff_nomatch(v_it_24555);
          }
        }
        case TAG_Just: {
          V v_it1_24586 = heff_field(v_it_24542, 0);
          heff_take(v_it_24542, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24586)) {
          case TAG_MkPair: {
            V v_m_24587 = heff_field(v_it1_24586, 0);
            V v_sp_24588 = heff_field(v_it1_24586, 1);
            heff_take(v_it1_24586, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24587, v_sp_24588, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24586);
          }
        }
        default: return heff_nomatch(v_it_24542);
        }
      }
      case TAG_VOpaque: {
        heff_drop(v_x_2427);
        heff_drop(v_x_2418);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        return heff_tail(v_k_2417, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24608;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24596 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24597 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24596)) {
          case TAG_HLocal: {
            heff_take(v_it1_24596, 0ULL);
            heff_drop(v_sp_24597);
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24596, 0ULL);
            heff_drop(v_sp_24597);
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24603 = heff_field(v_it1_24596, 0);
            V v_ru_24it1_24596_24HMeta = heff_take_reuse(v_it1_24596, 1ULL);
            v_it_24608 = heff_tag_at(v_ru_24it1_24596_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24603, v_sp_24597})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24596);
            heff_drop(v_sp_24597);
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24596);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24608 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24608)) {
        case TAG_Nothing: {
          heff_drop(v_it_24608);
          V v_it_24621;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24609 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24610 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24609)) {
            case TAG_HLocal: {
              heff_take(v_it1_24609, 0ULL);
              heff_drop(v_sp_24610);
              v_it_24621 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24609, 0ULL);
              heff_drop(v_sp_24610);
              v_it_24621 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24616 = heff_field(v_it1_24609, 0);
              V v_ru_24it1_24609_24HMeta = heff_take_reuse(v_it1_24609, 1ULL);
              v_it_24621 = heff_tag_at(v_ru_24it1_24609_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24616, v_sp_24610})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24609);
              heff_drop(v_sp_24610);
              v_it_24621 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24609);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24621 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24621)) {
          case TAG_Nothing: {
            heff_drop(v_it_24621);
            V v_t_24634;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24622 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24622)) {
              case TAG_HLocal: {
                heff_take(v_it1_24622, 0ULL);
                v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24622, 0ULL);
                v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24622, 0ULL);
                v_t_24634 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24622);
                v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24622);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24634 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24647;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24635 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24635)) {
              case TAG_HLocal: {
                heff_take(v_it1_24635, 0ULL);
                v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24635, 0ULL);
                v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24635, 0ULL);
                v_t_24647 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24635);
                v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24635);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24647 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24648 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24634; V a_7 = v_t_24647; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24648, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24649 = heff_field(v_it_24621, 0);
            heff_take(v_it_24621, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24649)) {
            case TAG_MkPair: {
              V v_m_24650 = heff_field(v_it1_24649, 0);
              V v_sp_24651 = heff_field(v_it1_24649, 1);
              heff_take(v_it1_24649, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24650, v_sp_24651, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24649);
            }
          }
          default: return heff_nomatch(v_it_24621);
          }
        }
        case TAG_Just: {
          V v_it1_24652 = heff_field(v_it_24608, 0);
          heff_take(v_it_24608, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24652)) {
          case TAG_MkPair: {
            V v_m_24653 = heff_field(v_it1_24652, 0);
            V v_sp_24654 = heff_field(v_it1_24652, 1);
            heff_take(v_it1_24652, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24653, v_sp_24654, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24652);
          }
        }
        default: return heff_nomatch(v_it_24608);
        }
      }
      case TAG_VCode: {
        V v_it_24668;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24656 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24657 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24656)) {
          case TAG_HLocal: {
            heff_take(v_it1_24656, 0ULL);
            heff_drop(v_sp_24657);
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24656, 0ULL);
            heff_drop(v_sp_24657);
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24663 = heff_field(v_it1_24656, 0);
            V v_ru_24it1_24656_24HMeta = heff_take_reuse(v_it1_24656, 1ULL);
            v_it_24668 = heff_tag_at(v_ru_24it1_24656_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24663, v_sp_24657})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24656);
            heff_drop(v_sp_24657);
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24656);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24668 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24668 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24668 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24668 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24668)) {
        case TAG_Nothing: {
          heff_drop(v_it_24668);
          V v_it_24681;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24669 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24670 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24669)) {
            case TAG_HLocal: {
              heff_take(v_it1_24669, 0ULL);
              heff_drop(v_sp_24670);
              v_it_24681 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24669, 0ULL);
              heff_drop(v_sp_24670);
              v_it_24681 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24676 = heff_field(v_it1_24669, 0);
              V v_ru_24it1_24669_24HMeta = heff_take_reuse(v_it1_24669, 1ULL);
              v_it_24681 = heff_tag_at(v_ru_24it1_24669_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24676, v_sp_24670})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24669);
              heff_drop(v_sp_24670);
              v_it_24681 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24669);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24681 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24681 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24681 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24681 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24681)) {
          case TAG_Nothing: {
            heff_drop(v_it_24681);
            V v_t_24694;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24682 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24682)) {
              case TAG_HLocal: {
                heff_take(v_it1_24682, 0ULL);
                v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24682, 0ULL);
                v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24682, 0ULL);
                v_t_24694 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24682);
                v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24682);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24694 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24707;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24695 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24695)) {
              case TAG_HLocal: {
                heff_take(v_it1_24695, 0ULL);
                v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24695, 0ULL);
                v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24695, 0ULL);
                v_t_24707 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24695);
                v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24695);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24707 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24708 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24694; V a_7 = v_t_24707; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24708, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24709 = heff_field(v_it_24681, 0);
            heff_take(v_it_24681, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24709)) {
            case TAG_MkPair: {
              V v_m_24710 = heff_field(v_it1_24709, 0);
              V v_sp_24711 = heff_field(v_it1_24709, 1);
              heff_take(v_it1_24709, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24710, v_sp_24711, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24709);
            }
          }
          default: return heff_nomatch(v_it_24681);
          }
        }
        case TAG_Just: {
          V v_it1_24712 = heff_field(v_it_24668, 0);
          heff_take(v_it_24668, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24712)) {
          case TAG_MkPair: {
            V v_m_24713 = heff_field(v_it1_24712, 0);
            V v_sp_24714 = heff_field(v_it1_24712, 1);
            heff_take(v_it1_24712, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24713, v_sp_24714, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24712);
          }
        }
        default: return heff_nomatch(v_it_24668);
        }
      }
      case TAG_VLam: {
        V v_it_24729;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24717 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24718 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24717)) {
          case TAG_HLocal: {
            heff_take(v_it1_24717, 0ULL);
            heff_drop(v_sp_24718);
            v_it_24729 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24717, 0ULL);
            heff_drop(v_sp_24718);
            v_it_24729 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24724 = heff_field(v_it1_24717, 0);
            V v_ru_24it1_24717_24HMeta = heff_take_reuse(v_it1_24717, 1ULL);
            v_it_24729 = heff_tag_at(v_ru_24it1_24717_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24724, v_sp_24718})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24717);
            heff_drop(v_sp_24718);
            v_it_24729 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24717);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24729 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24729)) {
        case TAG_Nothing: {
          heff_drop(v_it_24729);
          V v_it_24742;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24730 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24731 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24730)) {
            case TAG_HLocal: {
              heff_take(v_it1_24730, 0ULL);
              heff_drop(v_sp_24731);
              v_it_24742 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24730, 0ULL);
              heff_drop(v_sp_24731);
              v_it_24742 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24737 = heff_field(v_it1_24730, 0);
              V v_ru_24it1_24730_24HMeta = heff_take_reuse(v_it1_24730, 1ULL);
              v_it_24742 = heff_tag_at(v_ru_24it1_24730_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24737, v_sp_24731})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24730);
              heff_drop(v_sp_24731);
              v_it_24742 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24730);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24742 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24742)) {
          case TAG_Nothing: {
            heff_drop(v_it_24742);
            V v_t_24755;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24743 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24743)) {
              case TAG_HLocal: {
                heff_take(v_it1_24743, 0ULL);
                v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24743, 0ULL);
                v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24743, 0ULL);
                v_t_24755 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24743);
                v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24743);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24755 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24768;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24756 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24756)) {
              case TAG_HLocal: {
                heff_take(v_it1_24756, 0ULL);
                v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24756, 0ULL);
                v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24756, 0ULL);
                v_t_24768 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24756);
                v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24756);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24768 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24769 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24755; V a_7 = v_t_24768; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24769, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24770 = heff_field(v_it_24742, 0);
            heff_take(v_it_24742, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24770)) {
            case TAG_MkPair: {
              V v_m_24771 = heff_field(v_it1_24770, 0);
              V v_sp_24772 = heff_field(v_it1_24770, 1);
              heff_take(v_it1_24770, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24771, v_sp_24772, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24770);
            }
          }
          default: return heff_nomatch(v_it_24742);
          }
        }
        case TAG_Just: {
          V v_it1_24773 = heff_field(v_it_24729, 0);
          heff_take(v_it_24729, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24773)) {
          case TAG_MkPair: {
            V v_m_24774 = heff_field(v_it1_24773, 0);
            V v_sp_24775 = heff_field(v_it1_24773, 1);
            heff_take(v_it1_24773, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24774, v_sp_24775, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24773);
          }
        }
        default: return heff_nomatch(v_it_24729);
        }
      }
      case TAG_VCons: {
        V v_it_24789;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24777 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24778 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24777)) {
          case TAG_HLocal: {
            heff_take(v_it1_24777, 0ULL);
            heff_drop(v_sp_24778);
            v_it_24789 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24777, 0ULL);
            heff_drop(v_sp_24778);
            v_it_24789 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24784 = heff_field(v_it1_24777, 0);
            V v_ru_24it1_24777_24HMeta = heff_take_reuse(v_it1_24777, 1ULL);
            v_it_24789 = heff_tag_at(v_ru_24it1_24777_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24784, v_sp_24778})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24777);
            heff_drop(v_sp_24778);
            v_it_24789 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24777);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24789 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24789 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24789 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24789 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24789)) {
        case TAG_Nothing: {
          heff_drop(v_it_24789);
          V v_it_24802;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24790 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24791 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24790)) {
            case TAG_HLocal: {
              heff_take(v_it1_24790, 0ULL);
              heff_drop(v_sp_24791);
              v_it_24802 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24790, 0ULL);
              heff_drop(v_sp_24791);
              v_it_24802 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24797 = heff_field(v_it1_24790, 0);
              V v_ru_24it1_24790_24HMeta = heff_take_reuse(v_it1_24790, 1ULL);
              v_it_24802 = heff_tag_at(v_ru_24it1_24790_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24797, v_sp_24791})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24790);
              heff_drop(v_sp_24791);
              v_it_24802 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24790);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24802 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24802 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24802 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24802 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24802)) {
          case TAG_Nothing: {
            heff_drop(v_it_24802);
            V v_t_24815;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24803 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24803)) {
              case TAG_HLocal: {
                heff_take(v_it1_24803, 0ULL);
                v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24803, 0ULL);
                v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24803, 0ULL);
                v_t_24815 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24803);
                v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24803);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24815 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24828;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24816 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24816)) {
              case TAG_HLocal: {
                heff_take(v_it1_24816, 0ULL);
                v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24816, 0ULL);
                v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24816, 0ULL);
                v_t_24828 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24816);
                v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24816);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24828 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24829 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24815; V a_7 = v_t_24828; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24829, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24830 = heff_field(v_it_24802, 0);
            heff_take(v_it_24802, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24830)) {
            case TAG_MkPair: {
              V v_m_24831 = heff_field(v_it1_24830, 0);
              V v_sp_24832 = heff_field(v_it1_24830, 1);
              heff_take(v_it1_24830, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24831, v_sp_24832, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24830);
            }
          }
          default: return heff_nomatch(v_it_24802);
          }
        }
        case TAG_Just: {
          V v_it1_24833 = heff_field(v_it_24789, 0);
          heff_take(v_it_24789, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24833)) {
          case TAG_MkPair: {
            V v_m_24834 = heff_field(v_it1_24833, 0);
            V v_sp_24835 = heff_field(v_it1_24833, 1);
            heff_take(v_it1_24833, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24834, v_sp_24835, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24833);
          }
        }
        default: return heff_nomatch(v_it_24789);
        }
      }
      case TAG_VOpaque: {
        heff_drop(v_x_2427);
        heff_drop(v_x_2418);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        return heff_tail(v_k_2417, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24854;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24842 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24843 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24842)) {
          case TAG_HLocal: {
            heff_take(v_it1_24842, 0ULL);
            heff_drop(v_sp_24843);
            v_it_24854 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24842, 0ULL);
            heff_drop(v_sp_24843);
            v_it_24854 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24849 = heff_field(v_it1_24842, 0);
            V v_ru_24it1_24842_24HMeta = heff_take_reuse(v_it1_24842, 1ULL);
            v_it_24854 = heff_tag_at(v_ru_24it1_24842_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24849, v_sp_24843})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24842);
            heff_drop(v_sp_24843);
            v_it_24854 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24842);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24854 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24854)) {
        case TAG_Nothing: {
          heff_drop(v_it_24854);
          V v_it_24867;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24855 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24856 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24855)) {
            case TAG_HLocal: {
              heff_take(v_it1_24855, 0ULL);
              heff_drop(v_sp_24856);
              v_it_24867 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24855, 0ULL);
              heff_drop(v_sp_24856);
              v_it_24867 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24862 = heff_field(v_it1_24855, 0);
              V v_ru_24it1_24855_24HMeta = heff_take_reuse(v_it1_24855, 1ULL);
              v_it_24867 = heff_tag_at(v_ru_24it1_24855_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24862, v_sp_24856})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24855);
              heff_drop(v_sp_24856);
              v_it_24867 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24855);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24867 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24867)) {
          case TAG_Nothing: {
            heff_drop(v_it_24867);
            V v_t_24880;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24868 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24868)) {
              case TAG_HLocal: {
                heff_take(v_it1_24868, 0ULL);
                v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24868, 0ULL);
                v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24868, 0ULL);
                v_t_24880 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24868);
                v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24868);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24880 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24893;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24881 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24881)) {
              case TAG_HLocal: {
                heff_take(v_it1_24881, 0ULL);
                v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24881, 0ULL);
                v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24881, 0ULL);
                v_t_24893 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24881);
                v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24881);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24893 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24894 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24880; V a_7 = v_t_24893; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24894, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24895 = heff_field(v_it_24867, 0);
            heff_take(v_it_24867, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24895)) {
            case TAG_MkPair: {
              V v_m_24896 = heff_field(v_it1_24895, 0);
              V v_sp_24897 = heff_field(v_it1_24895, 1);
              heff_take(v_it1_24895, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24896, v_sp_24897, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24895);
            }
          }
          default: return heff_nomatch(v_it_24867);
          }
        }
        case TAG_Just: {
          V v_it1_24898 = heff_field(v_it_24854, 0);
          heff_take(v_it_24854, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24898)) {
          case TAG_MkPair: {
            V v_m_24899 = heff_field(v_it1_24898, 0);
            V v_sp_24900 = heff_field(v_it1_24898, 1);
            heff_take(v_it1_24898, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24899, v_sp_24900, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24898);
          }
        }
        default: return heff_nomatch(v_it_24854);
        }
      }
      case TAG_VCode: {
        V v_it_24914;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24902 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24903 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24902)) {
          case TAG_HLocal: {
            heff_take(v_it1_24902, 0ULL);
            heff_drop(v_sp_24903);
            v_it_24914 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24902, 0ULL);
            heff_drop(v_sp_24903);
            v_it_24914 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24909 = heff_field(v_it1_24902, 0);
            V v_ru_24it1_24902_24HMeta = heff_take_reuse(v_it1_24902, 1ULL);
            v_it_24914 = heff_tag_at(v_ru_24it1_24902_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24909, v_sp_24903})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24902);
            heff_drop(v_sp_24903);
            v_it_24914 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24902);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24914 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24914 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24914 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24914 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24914)) {
        case TAG_Nothing: {
          heff_drop(v_it_24914);
          V v_it_24927;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24915 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24916 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24915)) {
            case TAG_HLocal: {
              heff_take(v_it1_24915, 0ULL);
              heff_drop(v_sp_24916);
              v_it_24927 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24915, 0ULL);
              heff_drop(v_sp_24916);
              v_it_24927 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24922 = heff_field(v_it1_24915, 0);
              V v_ru_24it1_24915_24HMeta = heff_take_reuse(v_it1_24915, 1ULL);
              v_it_24927 = heff_tag_at(v_ru_24it1_24915_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24922, v_sp_24916})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24915);
              heff_drop(v_sp_24916);
              v_it_24927 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24915);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24927 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24927 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24927 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24927 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24927)) {
          case TAG_Nothing: {
            heff_drop(v_it_24927);
            V v_t_24940;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24928 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24928)) {
              case TAG_HLocal: {
                heff_take(v_it1_24928, 0ULL);
                v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24928, 0ULL);
                v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24928, 0ULL);
                v_t_24940 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24928);
                v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24928);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24940 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24953;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24941 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24941)) {
              case TAG_HLocal: {
                heff_take(v_it1_24941, 0ULL);
                v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24941, 0ULL);
                v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24941, 0ULL);
                v_t_24953 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24941);
                v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24941);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24953 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24954 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24940; V a_7 = v_t_24953; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24954, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24955 = heff_field(v_it_24927, 0);
            heff_take(v_it_24927, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24955)) {
            case TAG_MkPair: {
              V v_m_24956 = heff_field(v_it1_24955, 0);
              V v_sp_24957 = heff_field(v_it1_24955, 1);
              heff_take(v_it1_24955, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24956, v_sp_24957, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24955);
            }
          }
          default: return heff_nomatch(v_it_24927);
          }
        }
        case TAG_Just: {
          V v_it1_24958 = heff_field(v_it_24914, 0);
          heff_take(v_it_24914, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24958)) {
          case TAG_MkPair: {
            V v_m_24959 = heff_field(v_it1_24958, 0);
            V v_sp_24960 = heff_field(v_it1_24958, 1);
            heff_take(v_it1_24958, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24959, v_sp_24960, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24958);
          }
        }
        default: return heff_nomatch(v_it_24914);
        }
      }
      case TAG_VLam: {
        V v_it_24975;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24963 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24964 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24963)) {
          case TAG_HLocal: {
            heff_take(v_it1_24963, 0ULL);
            heff_drop(v_sp_24964);
            v_it_24975 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_24963, 0ULL);
            heff_drop(v_sp_24964);
            v_it_24975 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24970 = heff_field(v_it1_24963, 0);
            V v_ru_24it1_24963_24HMeta = heff_take_reuse(v_it1_24963, 1ULL);
            v_it_24975 = heff_tag_at(v_ru_24it1_24963_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24970, v_sp_24964})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_24963);
            heff_drop(v_sp_24964);
            v_it_24975 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24963);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24975 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24975)) {
        case TAG_Nothing: {
          heff_drop(v_it_24975);
          V v_it_24988;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24976 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24977 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24976)) {
            case TAG_HLocal: {
              heff_take(v_it1_24976, 0ULL);
              heff_drop(v_sp_24977);
              v_it_24988 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_24976, 0ULL);
              heff_drop(v_sp_24977);
              v_it_24988 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24983 = heff_field(v_it1_24976, 0);
              V v_ru_24it1_24976_24HMeta = heff_take_reuse(v_it1_24976, 1ULL);
              v_it_24988 = heff_tag_at(v_ru_24it1_24976_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24983, v_sp_24977})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_24976);
              heff_drop(v_sp_24977);
              v_it_24988 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24976);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24988 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24988)) {
          case TAG_Nothing: {
            heff_drop(v_it_24988);
            V v_t_241001;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24989 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24989)) {
              case TAG_HLocal: {
                heff_take(v_it1_24989, 0ULL);
                v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_24989, 0ULL);
                v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_24989, 0ULL);
                v_t_241001 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_24989);
                v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24989);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241001 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_241014;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_241002 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_241002)) {
              case TAG_HLocal: {
                heff_take(v_it1_241002, 0ULL);
                v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_241002, 0ULL);
                v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_241002, 0ULL);
                v_t_241014 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_241002);
                v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_241002);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241014 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_241015 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_241001; V a_7 = v_t_241014; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_241015, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_241016 = heff_field(v_it_24988, 0);
            heff_take(v_it_24988, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_241016)) {
            case TAG_MkPair: {
              V v_m_241017 = heff_field(v_it1_241016, 0);
              V v_sp_241018 = heff_field(v_it1_241016, 1);
              heff_take(v_it1_241016, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241017, v_sp_241018, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_241016);
            }
          }
          default: return heff_nomatch(v_it_24988);
          }
        }
        case TAG_Just: {
          V v_it1_241019 = heff_field(v_it_24975, 0);
          heff_take(v_it_24975, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_241019)) {
          case TAG_MkPair: {
            V v_m_241020 = heff_field(v_it1_241019, 0);
            V v_sp_241021 = heff_field(v_it1_241019, 1);
            heff_take(v_it1_241019, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241020, v_sp_241021, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_241019);
          }
        }
        default: return heff_nomatch(v_it_24975);
        }
      }
      case TAG_VCons: {
        V v_it_241035;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_241023 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_241024 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_241023)) {
          case TAG_HLocal: {
            heff_take(v_it1_241023, 0ULL);
            heff_drop(v_sp_241024);
            v_it_241035 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take(v_it1_241023, 0ULL);
            heff_drop(v_sp_241024);
            v_it_241035 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_241030 = heff_field(v_it1_241023, 0);
            V v_ru_24it1_241023_24HMeta = heff_take_reuse(v_it1_241023, 1ULL);
            v_it_241035 = heff_tag_at(v_ru_24it1_241023_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_241030, v_sp_241024})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_it1_241023);
            heff_drop(v_sp_241024);
            v_it_241035 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_241023);
          }
          break;
        }
        case TAG_VCode: {
          v_it_241035 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_241035 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_241035 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_241035 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_241035)) {
        case TAG_Nothing: {
          heff_drop(v_it_241035);
          V v_it_241048;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_241036 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_241037 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_241036)) {
            case TAG_HLocal: {
              heff_take(v_it1_241036, 0ULL);
              heff_drop(v_sp_241037);
              v_it_241048 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take(v_it1_241036, 0ULL);
              heff_drop(v_sp_241037);
              v_it_241048 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_241043 = heff_field(v_it1_241036, 0);
              V v_ru_24it1_241036_24HMeta = heff_take_reuse(v_it1_241036, 1ULL);
              v_it_241048 = heff_tag_at(v_ru_24it1_241036_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_241043, v_sp_241037})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_it1_241036);
              heff_drop(v_sp_241037);
              v_it_241048 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_241036);
            }
            break;
          }
          case TAG_VCode: {
            v_it_241048 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_241048 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_241048 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_241048 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_241048)) {
          case TAG_Nothing: {
            heff_drop(v_it_241048);
            V v_t_241061;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_241049 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_241049)) {
              case TAG_HLocal: {
                heff_take(v_it1_241049, 0ULL);
                v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_241049, 0ULL);
                v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_241049, 0ULL);
                v_t_241061 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_241049);
                v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_241049);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241061 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_241074;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_241062 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_241062)) {
              case TAG_HLocal: {
                heff_take(v_it1_241062, 0ULL);
                v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take(v_it1_241062, 0ULL);
                v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take(v_it1_241062, 0ULL);
                v_t_241074 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                heff_drop(v_it1_241062);
                v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_241062);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241074 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_241075 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_241061; V a_7 = v_t_241074; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_241075, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_241076 = heff_field(v_it_241048, 0);
            heff_take(v_it_241048, 1ULL);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_241076)) {
            case TAG_MkPair: {
              V v_m_241077 = heff_field(v_it1_241076, 0);
              V v_sp_241078 = heff_field(v_it1_241076, 1);
              heff_take(v_it1_241076, 3ULL);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241077, v_sp_241078, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_241076);
            }
          }
          default: return heff_nomatch(v_it_241048);
          }
        }
        case TAG_Just: {
          V v_it1_241079 = heff_field(v_it_241035, 0);
          heff_take(v_it_241035, 1ULL);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_241079)) {
          case TAG_MkPair: {
            V v_m_241080 = heff_field(v_it1_241079, 0);
            V v_sp_241081 = heff_field(v_it1_241079, 1);
            heff_take(v_it1_241079, 3ULL);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241080, v_sp_241081, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_241079);
          }
        }
        default: return heff_nomatch(v_it_241035);
        }
      }
      case TAG_VOpaque: {
        heff_drop(v_x_2427);
        heff_drop(v_x_2418);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        return heff_tail(v_k_2417, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2427);
      heff_drop(v_x_2418);
      heff_drop(v_w_240);
      heff_drop(v_ms_241);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop(v_hd_2416);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      return heff_tail(v_k_2417, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_x_2418);
    }
  }
  default: return heff_nomatch(v_t_2489);
  }
}
V g_heff_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ms_241 = heff_dup(heff_env(self)[0]);
  V v_b0_247 = heff_dup(heff_env(self)[1]);
  V v_w_240 = heff_dup(heff_env(self)[2]);
  V v_hd_2416 = heff_dup(heff_env(self)[3]);
  V v_uf_242 = heff_dup(heff_env(self)[4]);
  V v_cs_245 = heff_dup(heff_env(self)[5]);
  V v_k_2417 = heff_dup(heff_env(self)[6]);
  V v_r_243 = heff_dup(heff_env(self)[7]);
  V v_g_244 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  V v_p_2420 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam5, 1, 1, (V[]){v_b0_247})})}));
  V v_c_2426 = heff_clo(g_heff_2eunify_2euTermF_lam6, 2, 2, (V[]){heff_dup(v_w_240), v_p_2420});
  return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam8, 1, 9, (V[]){v_x_2418, v_w_240, v_ms_241, v_uf_242, v_cs_245, v_hd_2416, v_k_2417, v_r_243, v_g_244})});
}
V g_heff_2eunify_2euTermF_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_dup(heff_env(self)[0]);
  V v_ms_241 = heff_dup(heff_env(self)[1]);
  V v_b0_247 = heff_dup(heff_env(self)[2]);
  V v_w_240 = heff_dup(heff_env(self)[3]);
  V v_uf_242 = heff_dup(heff_env(self)[4]);
  V v_cs_245 = heff_dup(heff_env(self)[5]);
  V v_r_243 = heff_dup(heff_env(self)[6]);
  V v_g_244 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam4, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2416, v_uf_242, v_cs_245, v_k_2417, v_r_243, v_g_244})});
}
Clo g_heff_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eufEv(a[0]);
}
Clo g_heff_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse(v_x1_240, 1ULL);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take(v_t_242, 1ULL);
      V v_t_244 = heff_tr(heff_apply(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse(v_t_242, 3ULL);
      heff_drop(v_p_241);
      return heff_tag_at(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse(v_x1_240, 1ULL);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take(v_q_247, 1ULL);
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse(v_q_247, 3ULL);
      V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take(v_x2_2411, 3ULL);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take(v_x21_2412, 1ULL);
          heff_drop(v_ru_24x1_240_24InR);
          heff_drop(v_ru_24q_247_24Catch);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take(v_x21_2412, 1ULL);
          heff_drop(v_h_2410);
          return heff_tag_at(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euH_lam0, 2, 0};
V g_heff_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eunify_2euH_val;
static int g_heff_2eunify_2euH_st;
static V g_heff_2eunify_2euH_init(void) {
  return heff_rec(3, shape_267_20_177, (V[]){((V)&g_heff_2eunify_2euH_lam0_clo), ((V)&g_heff_2eunify_2euH_lam1_clo), ((V)&g_heff_2eunify_2euAlg_clo)});
}
V g_heff_2eunify_2euH_get(void) {
  if (g_heff_2eunify_2euH_st == 2) return g_heff_2eunify_2euH_val;
  if (g_heff_2eunify_2euH_st == 1) heff_fail("defined by itself");
  g_heff_2eunify_2euH_st = 1;
  g_heff_2eunify_2euH_val = heff_tr(g_heff_2eunify_2euH_init());
  g_heff_2eunify_2euH_st = 2;
  return g_heff_2eunify_2euH_val;
}
V g_heff_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  heff_drop(self);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  heff_drop(self);
  V v_x1_245 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse(v_x1_245, 3ULL);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take(v_x11_246, 1ULL);
      heff_drop(v_k_243);
      return heff_tag_at(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take(v_x11_246, 1ULL);
      heff_drop(v_ru_24x1_245_24MkPair);
      return heff_tail(v_k_243, 2, (V[]){v_x_249, v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eunify_2euModify_24s419_lam0(V self, V *args);
Clo g_heff_2eunify_2euModify_24s419_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euModify_24s419_entry, 3, 0};

V g_heff_2eunify_2euModify_24s419(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_240})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2eunify_2euModify_24s419_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eunify_2euModify_24s419_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euModify_24s419(a[0], a[1], a[2]);
}
V g_heff_2eunify_2euModify_24s419_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_tag(TAG_Put, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_247, v_k_242});
}
V g_heff_2eunify_2epoisonTy_24s418_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonTy_24s418_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonTy_24s418_lam0, 1, 0};
V g_heff_2eunify_2epoisonTy_24s418_lam2(V self, V *args);
V g_heff_2eunify_2epoisonTy_24s418_lam1(V self, V *args);
Clo g_heff_2eunify_2epoisonTy_24s418_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonTy_24s418_entry, 4, 0};

V g_heff_2eunify_2epoisonTy_24s418(V v_len_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonTy_24s418_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2eunify_2epoisonTy_24s418_lam1, 1, 4, (V[]){v_len_240, v_t_241, v_hd_242, v_k_243})});
}
V g_heff_2eunify_2epoisonTy_24s418_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epoisonTy_24s418(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2epoisonTy_24s418_lam0(V self, V *args) {
  V v_c_244 = args[0];
  heff_drop(self);
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2eunify_2epoisonTy_24s418_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_ms_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_ps_2411 = ({ V a_0 = heff_get(heff_dup(v_c_2410), LBL_poisoned); V a_1 = v_ms_249; V r_ = (g_prelude_2efoldl_24s315(a_0, a_1)); heff_drop(v_ms_249); r_; });
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_2410), LBL_infos), heff_get(heff_dup(v_c_2410), LBL_recovered), v_ps_2411, heff_get(heff_dup(v_c_2410), LBL_metas), heff_get(heff_dup(v_c_2410), LBL_nextMeta), heff_get(heff_dup(v_c_2410), LBL_postponed), heff_get(heff_dup(v_c_2410), LBL_trace), heff_get(v_c_2410, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonTy_24s418_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_len_240 = heff_dup(heff_env(self)[0]);
  V v_t_241 = heff_dup(heff_env(self)[1]);
  V v_hd_242 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_247); r_; });
  V v_ms_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_mty), 3, (V[]){MK_INT(20LL), v_len_240, v_t_241}));
  return (g_heff_2eunify_2euModify_24s419(heff_clo(g_heff_2eunify_2epoisonTy_24s418_lam2, 1, 1, (V[]){v_ms_249}), v_hd_242, v_k_243));
}
V g_heff_2eunify_2estoreSol_24s422_lam0(V self, V *args);
Clo g_heff_2eunify_2estoreSol_24s422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2estoreSol_24s422_entry, 3, 0};

V g_heff_2eunify_2estoreSol_24s422(V v_m_240, V v_sol_241, V v_stx_242) {
top: ;
  return heff_tail(((V)&g_heff_2eunify_2euModify_24s419_clo), 1, (V[]){heff_clo(g_heff_2eunify_2estoreSol_24s422_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})});
}
V g_heff_2eunify_2estoreSol_24s422_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2estoreSol_24s422(a[0], a[1], a[2]);
}
V g_heff_2eunify_2estoreSol_24s422_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  V v_sol_241 = heff_dup(heff_env(self)[1]);
  V v_stx_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_244 = ({ V a_0 = heff_dup(v_m_240); V b_1 = heff_get(heff_dup(v_c_243), LBL_metas); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_sol_241);
    heff_drop(v_stx_242);
    heff_drop(v_t_244);
    return v_c_243;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    V v_t_246 = heff_rec(6, shape_336_293_294_13_190_299, (V[]){heff_get(heff_dup(v_e_245), LBL_ty), heff_tag(TAG_Just, 1, (V[]){v_sol_241}), heff_tag(TAG_Just, 1, (V[]){v_stx_242}), heff_get(heff_dup(v_e_245), LBL_arity), heff_get(heff_dup(v_e_245), LBL_name), heff_get(v_e_245, LBL_span)});
    V v_mc_247 = (g_map_2einsert_24s214(v_m_240, v_t_246, heff_get(heff_dup(v_c_243), LBL_metas)));
    return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_243), LBL_infos), heff_get(heff_dup(v_c_243), LBL_recovered), heff_get(heff_dup(v_c_243), LBL_poisoned), v_mc_247, heff_get(heff_dup(v_c_243), LBL_nextMeta), heff_get(heff_dup(v_c_243), LBL_postponed), heff_get(heff_dup(v_c_243), LBL_trace), heff_get(v_c_243, LBL_selfKey)});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eunify_2epoisonEl_24s423_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonEl_24s423_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_24s423_lam0, 1, 0};
V g_heff_2eunify_2epoisonEl_24s423_lam2(V self, V *args);
V g_heff_2eunify_2epoisonEl_24s423_lam1(V self, V *args);
Clo g_heff_2eunify_2epoisonEl_24s423_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_24s423_entry, 4, 0};

V g_heff_2eunify_2epoisonEl_24s423(V v_len_240, V v_v_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonEl_24s423_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2eunify_2epoisonEl_24s423_lam1, 1, 4, (V[]){v_len_240, v_v_241, v_hd_242, v_k_243})});
}
V g_heff_2eunify_2epoisonEl_24s423_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epoisonEl_24s423(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2epoisonEl_24s423_lam0(V self, V *args) {
  V v_c_244 = args[0];
  heff_drop(self);
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2eunify_2epoisonEl_24s423_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_ms_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_ps_2411 = ({ V a_0 = heff_get(heff_dup(v_c_2410), LBL_poisoned); V a_1 = v_ms_249; V r_ = (g_prelude_2efoldl_24s315(a_0, a_1)); heff_drop(v_ms_249); r_; });
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_2410), LBL_infos), heff_get(heff_dup(v_c_2410), LBL_recovered), v_ps_2411, heff_get(heff_dup(v_c_2410), LBL_metas), heff_get(heff_dup(v_c_2410), LBL_nextMeta), heff_get(heff_dup(v_c_2410), LBL_postponed), heff_get(heff_dup(v_c_2410), LBL_trace), heff_get(v_c_2410, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonEl_24s423_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_len_240 = heff_dup(heff_env(self)[0]);
  V v_v_241 = heff_dup(heff_env(self)[1]);
  V v_hd_242 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_247); r_; });
  V v_ms_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_mel), 3, (V[]){MK_INT(20LL), v_len_240, v_v_241}));
  return (g_heff_2eunify_2euModify_24s419(heff_clo(g_heff_2eunify_2epoisonEl_24s423_lam2, 1, 1, (V[]){v_ms_249}), v_hd_242, v_k_243));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eunify_2etraceSolve_24s424_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 111, 108, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2etraceSolve_24s424_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eunify_2etraceSolve_24s424_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eunify_2etraceSolve_24s424_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 58, 61, 32}};
V g_heff_2eunify_2etraceSolve_24s424_lam1(V self, V *args);
V g_heff_2eunify_2etraceSolve_24s424_lam0(V self, V *args);
Clo g_heff_2eunify_2etraceSolve_24s424_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraceSolve_24s424_entry, 2, 0};

V g_heff_2eunify_2etraceSolve_24s424(V v_m_240, V v_stx_241) {
top: ;
  return heff_tail(((V)&g_heff_2eunify_2euModify_24s419_clo), 1, (V[]){heff_clo(g_heff_2eunify_2etraceSolve_24s424_lam0, 1, 2, (V[]){v_m_240, v_stx_241})});
}
V g_heff_2eunify_2etraceSolve_24s424_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2etraceSolve_24s424(a[0], a[1]);
}
V g_heff_2eunify_2etraceSolve_24s424_lam1(V self, V *args) {
  V v_u_245 = args[0];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_stx_241 = heff_dup(heff_env(self)[1]);
  V v_m_240 = heff_dup(heff_env(self)[2]);
  V v_e_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_u_245);
  V v_t_246 = ({ V b_0 = heff_get(v_c_242, LBL_metas); V r_ = (g_heff_2eunify_2ezonker(b_0)); heff_drop(b_0); r_; });
  V v_e_247 = heff_tr(heff_apply(heff_get(v_t_246, LBL_el), 1, (V[]){v_stx_241}));
  V v_t_248 = (g_heff_2epsurface_2eelF_24s90_24s316(MK_INT(0LL), NTAG(TAG_Nil), v_e_247));
  return heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s424_str1), heff_strAppend(heff_intShow(v_m_240), heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s424_str2), heff_strAppend(heff_get(v_e_244, LBL_name), heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s424_str3), v_t_248)))));
}
V g_heff_2eunify_2etraceSolve_24s424_lam0(V self, V *args) {
  V v_c_242 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  V v_stx_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_243 = ({ V a_0 = heff_dup(v_m_240); V b_1 = heff_get(heff_dup(v_c_242), LBL_metas); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_stx_241);
    heff_drop(v_t_243);
    return v_c_242;
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_t_249 = heff_rec(3, shape_299_147_321, (V[]){heff_get(heff_dup(v_e_244), LBL_span), ((V)&g_heff_2eunify_2etraceSolve_24s424_str0), heff_clo(g_heff_2eunify_2etraceSolve_24s424_lam1, 1, 4, (V[]){heff_dup(v_c_242), v_stx_241, v_m_240, v_e_244})});
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_get(heff_dup(v_c_242), LBL_trace)});
    return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_242), LBL_infos), heff_get(heff_dup(v_c_242), LBL_recovered), heff_get(heff_dup(v_c_242), LBL_poisoned), heff_get(heff_dup(v_c_242), LBL_metas), heff_get(heff_dup(v_c_242), LBL_nextMeta), heff_get(heff_dup(v_c_242), LBL_postponed), v_t_2410, heff_get(v_c_242, LBL_selfKey)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2erenameHead_24s426_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s426_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s426_lam0, 2, 0};
V g_heff_2eunify_2erenameHead_24s426_lam1(V self, V *args);
V g_heff_2eunify_2erenameHead_24s426_lam2(V self, V *args);
V g_heff_2eunify_2erenameHead_24s426_lam3(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s426_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s426_lam3, 2, 0};
V g_heff_2eunify_2erenameHead_24s426_lam4(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s426_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s426_lam4, 2, 0};
Clo g_heff_2eunify_2erenameHead_24s426_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s426_entry, 2, 0};

V g_heff_2eunify_2erenameHead_24s426(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_242 = heff_field(v_x2_241, 0);
    heff_take(v_x2_241, 1ULL);
    V v_t_243 = ({ V a_0 = v_l_242; V b_1 = heff_get(heff_dup(v_r_240), LBL_ren); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      heff_drop(v_t_243);
      return ((V)&g_heff_2eunify_2erenameHead_24s426_lam0_clo);
    }
    case TAG_Just: {
      V v_l_27_249 = heff_field(v_t_243, 0);
      heff_take(v_t_243, 1ULL);
      return heff_clo(g_heff_2eunify_2erenameHead_24s426_lam1, 2, 2, (V[]){v_r_240, v_l_27_249});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_HGlobal: {
    V v_x_2414 = heff_field(v_x2_241, 0);
    heff_take(v_x2_241, 1ULL);
    heff_drop(v_r_240);
    return heff_clo(g_heff_2eunify_2erenameHead_24s426_lam2, 2, 1, (V[]){v_x_2414});
  }
  case TAG_HMeta: {
    heff_take(v_x2_241, 0ULL);
    heff_drop(v_r_240);
    return ((V)&g_heff_2eunify_2erenameHead_24s426_lam3_clo);
  }
  case TAG_HError: {
    heff_drop(v_r_240);
    heff_drop(v_x2_241);
    return ((V)&g_heff_2eunify_2erenameHead_24s426_lam4_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2erenameHead_24s426_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameHead_24s426(a[0], a[1]);
}
V g_heff_2eunify_2erenameHead_24s426_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  heff_drop(self);
  V v_t_246 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_248, v_k2_245});
}
V g_heff_2eunify_2erenameHead_24s426_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_r_240 = heff_dup(heff_env(self)[0]);
  V v_l_27_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_intSub(heff_get(v_r_240, LBL_cod), v_l_27_249);
  V v_t_2413 = heff_tag(TAG_SLocal, 1, (V[]){heff_intSub(v_t_2412, MK_INT(1LL))});
  return heff_tail(v_k_2411, 1, (V[]){v_t_2413});
}
V g_heff_2eunify_2erenameHead_24s426_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2415);
  return heff_tail(v_k_2416, 1, (V[]){heff_tag(TAG_SGlobal, 1, (V[]){v_x_2414})});
}
V g_heff_2eunify_2erenameHead_24s426_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  heff_drop(self);
  V v_t_2420 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get(v_hd_2418, LBL_bind), 2, (V[]){v_t_2422, v_k2_2419});
}
V g_heff_2eunify_2erenameHead_24s426_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  heff_drop(self);
  V v_t_2425 = heff_tag(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2425})}));
  return heff_tail(heff_get(v_hd_2423, LBL_bind), 2, (V[]){v_t_2426, v_k2_2424});
}
V g_heff_2eunify_2erenameSpine_24s427_lam0(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam3(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam2(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam1(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam5(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam4(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam8(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam7(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s427_lam6(V self, V *args);
Clo g_heff_2eunify_2erenameSpine_24s427_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameSpine_24s427_entry, 5, 0};

V g_heff_2eunify_2erenameSpine_24s427(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    heff_drop(v_x5_243);
    return heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take(v_x5_243, 3ULL);
    V v_c_249 = (g_heff_2eunify_2erenameSpine_24s427(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2415 = heff_field(v_x5_243, 0);
    V v_l_2416 = heff_field(v_x5_243, 1);
    heff_take(v_x5_243, 3ULL);
    V v_c_2417 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_s_2415, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam4, 2, 2, (V[]){v_c_2417, v_l_2416});
  }
  case TAG_SpSpec: {
    V v_s_2421 = heff_field(v_x5_243, 0);
    V v_l_2422 = heff_field(v_x5_243, 1);
    V v_a_2423 = heff_field(v_x5_243, 2);
    heff_take(v_x5_243, 7ULL);
    V v_c_2424 = (g_heff_2eunify_2erenameSpine_24s427(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2421, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam6, 2, 6, (V[]){v_c_2424, v_g_240, v_m_241, v_pr_242, v_a_2423, v_l_2422});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameSpine_24s427_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameSpine_24s427(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameSpine_24s427_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_245);
  return heff_tail(v_k_246, 1, (V[]){v_h_244});
}
V g_heff_2eunify_2erenameSpine_24s427_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_2411 = heff_dup(heff_env(self)[0]);
  V v_x_2412 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_2411, 1, (V[]){heff_tag(TAG_SApp, 2, (V[]){v_x_2412, v_x_2414})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_a_248 = heff_dup(heff_env(self)[3]);
  V v_hd_2410 = heff_dup(heff_env(self)[4]);
  V v_k_2411 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s425_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248}));
  return heff_tail(v_c_2413, 2, (V[]){v_hd_2410, heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_m_241 = heff_dup(heff_env(self)[2]);
  V v_pr_242 = heff_dup(heff_env(self)[3]);
  V v_a_248 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_2410), heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_dup(heff_env(self)[0]);
  V v_l_2416 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_2419, 1, (V[]){heff_tag(TAG_SProj, 2, (V[]){v_x_2420, v_l_2416})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_dup(heff_env(self)[0]);
  V v_l_2416 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2418, heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam5, 1, 2, (V[]){v_k_2419, v_l_2416})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2426 = heff_dup(heff_env(self)[0]);
  V v_x_2427 = heff_dup(heff_env(self)[1]);
  V v_l_2422 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_k_2426, 1, (V[]){heff_tag(TAG_SSpecialize, 3, (V[]){v_x_2427, v_l_2422, v_x_2429})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_a_2423 = heff_dup(heff_env(self)[3]);
  V v_hd_2425 = heff_dup(heff_env(self)[4]);
  V v_k_2426 = heff_dup(heff_env(self)[5]);
  V v_l_2422 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_c_2428 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s425_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2423}));
  return heff_tail(v_c_2428, 2, (V[]){v_hd_2425, heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam8, 1, 3, (V[]){v_k_2426, v_x_2427, v_l_2422})});
}
V g_heff_2eunify_2erenameSpine_24s427_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_m_241 = heff_dup(heff_env(self)[2]);
  V v_pr_242 = heff_dup(heff_env(self)[3]);
  V v_a_2423 = heff_dup(heff_env(self)[4]);
  V v_l_2422 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_2425), heff_clo(g_heff_2eunify_2erenameSpine_24s427_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2423, v_hd_2425, v_k_2426, v_l_2422})});
}
V g_heff_2eunify_2erenameEvF_24s429_lam1(V self, V *args);
V g_heff_2eunify_2erenameEvF_24s429_lam0(V self, V *args);
Clo g_heff_2eunify_2erenameEvF_24s429_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameEvF_24s429_entry, 4, 0};

V g_heff_2eunify_2erenameEvF_24s429(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nom: {
    V v_v_244 = heff_field(v_x5_243, 0);
    heff_take(v_x5_243, 1ULL);
    return heff_tail(((V)&g_heff_2eunify_2erenameF_24s425_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_244});
  }
  case TAG_Describe: {
    V v_v_245 = heff_field(v_x5_243, 0);
    heff_take(v_x5_243, 1ULL);
    return heff_tail(((V)&g_heff_2eunify_2erenameF_24s425_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_245});
  }
  case TAG_Become: {
    V v_v_246 = heff_field(v_x5_243, 0);
    heff_take(v_x5_243, 1ULL);
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s425_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_246}));
    return heff_clo(g_heff_2eunify_2erenameEvF_24s429_lam0, 2, 1, (V[]){v_c_247});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameEvF_24s429_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameEvF_24s429(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2erenameEvF_24s429_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_249, 1, (V[]){heff_tag(TAG_SIs, 1, (V[]){v_x_2410})});
}
V g_heff_2eunify_2erenameEvF_24s429_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){v_hd_248, heff_clo(g_heff_2eunify_2erenameEvF_24s429_lam1, 1, 1, (V[]){v_k_249})});
}
V g_heff_2eunify_2erenameClo_24s428_lam0(V self, V *args);
V g_heff_2eunify_2erenameClo_24s428_lam1(V self, V *args);
V g_heff_2eunify_2erenameClo_24s428_lam3(V self, V *args);
V g_heff_2eunify_2erenameClo_24s428_lam2(V self, V *args);
V g_heff_2eunify_2erenameClo_24s428_lam5(V self, V *args);
V g_heff_2eunify_2erenameClo_24s428_lam4(V self, V *args);
Clo g_heff_2eunify_2erenameClo_24s428_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameClo_24s428_entry, 5, 0};

V g_heff_2eunify_2erenameClo_24s428(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take(v_x6_244, 7ULL);
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_cod), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s214(heff_get(heff_dup(v_pr_242), LBL_dom), heff_get(heff_dup(v_pr_242), LBL_cod), heff_get(heff_dup(v_pr_242), LBL_ren)));
    V v_pr_2411 = heff_rec(3, shape_65_43_256, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_pr_242, LBL_dom)});
    V v_v_2414 = (g_heff_2evalue_2emkNeu_24s10(v_t_2412, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameClo_24s428_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo(g_heff_2eunify_2erenameClo_24s428_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2417 = heff_tr(g_heff_2eunify_2erenameEvF_24s429(v_g_240, v_m_241, v_pr_2411, v_v_2416));
    return heff_clo(g_heff_2eunify_2erenameClo_24s428_lam2, 2, 2, (V[]){v_c_2417, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2421 = heff_field(v_x6_244, 0);
    heff_take(v_x6_244, 1ULL);
    heff_drop(v_dom_243);
    V v_c_2422 = heff_tr(g_heff_2eunify_2erenameEvF_24s429(v_g_240, v_m_241, v_pr_242, v_t_2421));
    return heff_clo(g_heff_2eunify_2erenameClo_24s428_lam4, 2, 1, (V[]){v_c_2422});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eunify_2erenameClo_24s428_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameClo_24s428(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameClo_24s428_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eunify_2erenameClo_24s428_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eunify_2erenameClo_24s428_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_dup(heff_env(self)[0]);
  V v_x_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_2419, 1, (V[]){heff_tag(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2420})});
}
V g_heff_2eunify_2erenameClo_24s428_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_dup(heff_env(self)[0]);
  V v_x_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2418, heff_clo(g_heff_2eunify_2erenameClo_24s428_lam3, 1, 2, (V[]){v_k_2419, v_x_245})});
}
V g_heff_2eunify_2erenameClo_24s428_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_2424, 1, (V[]){heff_tag(TAG_AbsConst, 1, (V[]){v_x_2425})});
}
V g_heff_2eunify_2erenameClo_24s428_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2423, heff_clo(g_heff_2eunify_2erenameClo_24s428_lam5, 1, 1, (V[]){v_k_2424})});
}
V g_heff_2eunify_2etraverseU_24s430_lam0(V self, V *args); static Clo g_heff_2eunify_2etraverseU_24s430_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraverseU_24s430_lam0, 2, 0};
V g_heff_2eunify_2etraverseU_24s430_lam3(V self, V *args);
V g_heff_2eunify_2etraverseU_24s430_lam2(V self, V *args);
V g_heff_2eunify_2etraverseU_24s430_lam1(V self, V *args);
Clo g_heff_2eunify_2etraverseU_24s430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraverseU_24s430_entry, 2, 0};

V g_heff_2eunify_2etraverseU_24s430(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x2_241);
    return ((V)&g_heff_2eunify_2etraverseU_24s430_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2eunify_2etraverseU_24s430_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2etraverseU_24s430_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2etraverseU_24s430(a[0], a[1]);
}
V g_heff_2eunify_2etraverseU_24s430_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2eunify_2etraverseU_24s430_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  V v_x_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_248, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411})});
}
V g_heff_2eunify_2etraverseU_24s430_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_dup(heff_env(self)[0]);
  V v_xs_245 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_k_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_2410 = (g_heff_2eunify_2etraverseU_24s430(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2eunify_2etraverseU_24s430_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eunify_2etraverseU_24s430_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_f_240 = heff_dup(heff_env(self)[1]);
  V v_xs_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2eunify_2etraverseU_24s430_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248})});
}
V g_heff_2eunify_2emetaEntry_24s432_lam0(V self, V *args); static Clo g_heff_2eunify_2emetaEntry_24s432_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetaEntry_24s432_lam0, 1, 0};
V g_heff_2eunify_2emetaEntry_24s432_lam1(V self, V *args);
Clo g_heff_2eunify_2emetaEntry_24s432_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetaEntry_24s432_entry, 3, 0};

V g_heff_2eunify_2emetaEntry_24s432(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2emetaEntry_24s432_lam0_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2eunify_2emetaEntry_24s432_lam1, 1, 3, (V[]){v_m_240, v_hd_241, v_k_242})});
}
V g_heff_2eunify_2emetaEntry_24s432_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emetaEntry_24s432(a[0], a[1], a[2]);
}
V g_heff_2eunify_2emetaEntry_24s432_lam0(V self, V *args) {
  V v_c_243 = args[0];
  heff_drop(self);
  return heff_get(v_c_243, LBL_metas);
}
V g_heff_2eunify_2emetaEntry_24s432_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = ({ V a_0 = v_m_240; V a_1 = v_x_246; V r_ = (g_map_2elookup_24s12(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_t_247);
    V v_t_248 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2410, v_k_242});
  }
  case TAG_Just: {
    V v_e_2411 = heff_field(v_t_247, 0);
    heff_take(v_t_247, 1ULL);
    heff_drop(v_hd_241);
    return heff_tail(v_k_242, 1, (V[]){v_e_2411});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eunify_2erenameEvTypeF_24s436_lam1(V self, V *args);
V g_heff_2eunify_2erenameEvTypeF_24s436_lam0(V self, V *args);
Clo g_heff_2eunify_2erenameEvTypeF_24s436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameEvTypeF_24s436_entry, 4, 0};

V g_heff_2eunify_2erenameEvTypeF_24s436(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nom: {
    V v_a_244 = heff_field(v_x5_243, 0);
    heff_take(v_x5_243, 1ULL);
    return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_244});
  }
  case TAG_Describe: {
    V v_a_245 = heff_field(v_x5_243, 0);
    heff_take(v_x5_243, 1ULL);
    return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_245});
  }
  case TAG_Become: {
    V v_a_246 = heff_field(v_x5_243, 0);
    heff_take(v_x5_243, 1ULL);
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_246}));
    return heff_clo(g_heff_2eunify_2erenameEvTypeF_24s436_lam0, 2, 1, (V[]){v_c_247});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameEvTypeF_24s436_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameEvTypeF_24s436(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2erenameEvTypeF_24s436_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_249, 1, (V[]){heff_tag(TAG_SIsTy, 1, (V[]){v_x_2410})});
}
V g_heff_2eunify_2erenameEvTypeF_24s436_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){v_hd_248, heff_clo(g_heff_2eunify_2erenameEvTypeF_24s436_lam1, 1, 1, (V[]){v_k_249})});
}
V g_heff_2eunify_2erenameCloTy_24s435_lam0(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s435_lam1(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s435_lam3(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s435_lam2(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s435_lam5(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s435_lam4(V self, V *args);
Clo g_heff_2eunify_2erenameCloTy_24s435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameCloTy_24s435_entry, 5, 0};

V g_heff_2eunify_2erenameCloTy_24s435(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take(v_x6_244, 7ULL);
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_cod), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s214(heff_get(heff_dup(v_pr_242), LBL_dom), heff_get(heff_dup(v_pr_242), LBL_cod), heff_get(heff_dup(v_pr_242), LBL_ren)));
    V v_pr_2411 = heff_rec(3, shape_65_43_256, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_pr_242, LBL_dom)});
    V v_v_2414 = (g_heff_2evalue_2emkNeu_24s10(v_t_2412, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameCloTy_24s435_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo(g_heff_2eunify_2erenameCloTy_24s435_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2417 = heff_tr(g_heff_2eunify_2erenameEvTypeF_24s436(v_g_240, v_m_241, v_pr_2411, v_t_2416));
    return heff_clo(g_heff_2eunify_2erenameCloTy_24s435_lam2, 2, 2, (V[]){v_c_2417, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2421 = heff_field(v_x6_244, 0);
    heff_take(v_x6_244, 1ULL);
    heff_drop(v_dom_243);
    V v_c_2422 = heff_tr(g_heff_2eunify_2erenameEvTypeF_24s436(v_g_240, v_m_241, v_pr_242, v_t_2421));
    return heff_clo(g_heff_2eunify_2erenameCloTy_24s435_lam4, 2, 1, (V[]){v_c_2422});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eunify_2erenameCloTy_24s435_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameCloTy_24s435(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameCloTy_24s435_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eunify_2erenameCloTy_24s435_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eunify_2erenameCloTy_24s435_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_dup(heff_env(self)[0]);
  V v_x_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_2419, 1, (V[]){heff_tag(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2420})});
}
V g_heff_2eunify_2erenameCloTy_24s435_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_dup(heff_env(self)[0]);
  V v_x_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2418, heff_clo(g_heff_2eunify_2erenameCloTy_24s435_lam3, 1, 2, (V[]){v_k_2419, v_x_245})});
}
V g_heff_2eunify_2erenameCloTy_24s435_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_2424, 1, (V[]){heff_tag(TAG_AbsConst, 1, (V[]){v_x_2425})});
}
V g_heff_2eunify_2erenameCloTy_24s435_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2423, heff_clo(g_heff_2eunify_2erenameCloTy_24s435_lam5, 1, 1, (V[]){v_k_2424})});
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameRecordFields_24s437_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameRecordFields_24s437_lam0, 2, 0};
V g_heff_2eunify_2erenameRecordFields_24s437_lam3(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s437_lam4(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s437_lam5(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s437_lam2(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s437_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameRecordFields_24s437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameRecordFields_24s437_entry, 6, 0};

V g_heff_2eunify_2erenameRecordFields_24s437(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    heff_drop(v_x7_245);
    return ((V)&g_heff_2eunify_2erenameRecordFields_24s437_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take(v_x7_245, 3ULL);
    V v_t_2410 = heff_tr(heff_apply(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take(v_t_2410, 1ULL);
      V v_pr_2413 = (g_heff_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      V v_c_2414 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411)}));
      return heff_clo(g_heff_2eunify_2erenameRecordFields_24s437_lam1, 2, 8, (V[]){v_c_2414, v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eunify_2erenameRecordFields_24s437_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameRecordFields_24s437(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(self);
  heff_drop(v_hd_246);
  return heff_tail(v_k_247, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_ty_2411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2419);
  return v_ty_2411;
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam4(V self, V *args) {
  V v_u_2421 = args[0];
  V v_v_2420 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_2421);
  return v_v_2420;
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2416 = heff_dup(heff_env(self)[0]);
  V v_x_2417 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_2416, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2417, v_x_2423})});
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  V v_i_243 = heff_dup(heff_env(self)[1]);
  V v_ty_2411 = heff_dup(heff_env(self)[2]);
  V v_g_240 = heff_dup(heff_env(self)[3]);
  V v_m_241 = heff_dup(heff_env(self)[4]);
  V v_ls_244 = heff_dup(heff_env(self)[5]);
  V v_rest_249 = heff_dup(heff_env(self)[6]);
  V v_hd_2415 = heff_dup(heff_env(self)[7]);
  V v_k_2416 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  V v_t_2418 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), heff_dup(v_i_243));
  V v_v_2420 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_t_2418}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameRecordFields_24s437_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2422 = (g_heff_2eunify_2erenameRecordFields_24s437(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo(g_heff_2eunify_2erenameRecordFields_24s437_lam4, 1, 1, (V[]){v_v_2420})}), v_rest_249));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2415, heff_clo(g_heff_2eunify_2erenameRecordFields_24s437_lam5, 1, 2, (V[]){v_k_2416, v_x_2417})});
}
V g_heff_2eunify_2erenameRecordFields_24s437_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_dup(heff_env(self)[0]);
  V v_pr_242 = heff_dup(heff_env(self)[1]);
  V v_i_243 = heff_dup(heff_env(self)[2]);
  V v_ty_2411 = heff_dup(heff_env(self)[3]);
  V v_g_240 = heff_dup(heff_env(self)[4]);
  V v_m_241 = heff_dup(heff_env(self)[5]);
  V v_ls_244 = heff_dup(heff_env(self)[6]);
  V v_rest_249 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_2415), heff_clo(g_heff_2eunify_2erenameRecordFields_24s437_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2415, v_k_2416})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam0(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam3(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam2(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam5(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam4(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam6(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam8(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam7(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam10(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam9(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam11(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam13(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam15(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam14(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam12(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam16(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam17(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s434_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameTypeF_24s434_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameTypeF_24s434_entry, 6, 0};

V g_heff_2eunify_2erenameTypeF_24s434(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameTypeF_24s434_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameTypeF_24s434(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameTypeF_24s434_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_t0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2erenameTypeF_24s434_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SDecode, 1, (V[]){v_x_2420})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_sp_2412 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_c_2419 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  return heff_tail(v_c_2419, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam3, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SDecode, 1, (V[]){v_x_2425})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_sp_2412 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_c_2424 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  return heff_tail(v_c_2424, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam5, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SDecode, 1, (V[]){v_x_2432})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SDecode, 1, (V[]){v_x_2436})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_sp_2412 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_c_2435 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2434));
  return heff_tail(v_c_2435, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam8, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_level_2437 = heff_dup(heff_env(self)[1]);
  V v_x_2442 = heff_dup(heff_env(self)[2]);
  V v_implicit_2440 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SFunction, 4, (V[]){v_level_2437, v_x_2442, v_x_2444, v_implicit_2440})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_dom_2438 = heff_dup(heff_env(self)[3]);
  V v_cod_2439 = heff_dup(heff_env(self)[4]);
  V v_hd_244 = heff_dup(heff_env(self)[5]);
  V v_k_245 = heff_dup(heff_env(self)[6]);
  V v_level_2437 = heff_dup(heff_env(self)[7]);
  V v_implicit_2440 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  V v_c_2443 = (g_heff_2eunify_2erenameCloTy_24s435(v_g_240, v_m_241, v_pr_242, v_dom_2438, v_cod_2439));
  return heff_tail(v_c_2443, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam10, 1, 4, (V[]){v_k_245, v_level_2437, v_x_2442, v_implicit_2440})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam11(V self, V *args) {
  V v_x_2450 = args[0];
  V v_fieldTypes_2447 = heff_dup(heff_env(self)[0]);
  V v_k_245 = heff_dup(heff_env(self)[1]);
  V v_level_2445 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2451 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_fieldTypes_2447), LBL_keys), heff_get(v_fieldTypes_2447, LBL_byName), heff_arrayFromList(v_x_2450)});
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SRecord, 2, (V[]){v_level_2445, v_t_2451})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam13(V self, V *args) {
  V v_a_2459 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2460 = heff_tr(heff_apply(v_a_2459, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_t_2460});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam15(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2457 = heff_dup(heff_env(self)[0]);
  V v_k_2463 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2465 = heff_tag(TAG_MkPair, 2, (V[]){v_k_2457, heff_arrayFromList(v_x_2464)});
  return heff_tail(v_k_2463, 1, (V[]){v_t_2465});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam14(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_dup(heff_env(self)[0]);
  V v_k_2457 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2461, 2, (V[]){v_hd_2462, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam15, 1, 2, (V[]){v_k_2457, v_k_2463})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam12(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_args_2458 = heff_field(v_p_2456, 1);
    heff_take(v_p_2456, 3ULL);
    V v_c_2461 = (g_heff_2eunify_2etraverseU_24s430(heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2458)));
    return heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam14, 2, 2, (V[]){v_c_2461, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eunify_2erenameTypeF_24s434_lam16(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2468 = (g_prelude_2emap_24s5(heff_dup(v_x_2467)));
  V v_t_2469 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2467));
  V v_t_2470 = (g_prelude_2emap_24s6(v_x_2467));
  V v_t_2471 = heff_rec(3, shape_146_32_353, (V[]){heff_arrayFromList(v_t_2468), v_t_2469, heff_arrayFromList(v_t_2470)});
  V v_x_2472 = heff_tag(TAG_SSum, 1, (V[]){v_t_2471});
  return heff_tail(v_k_245, 1, (V[]){v_x_2472});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam17(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SPrimArray, 1, (V[]){v_x_2475})});
}
V g_heff_2eunify_2erenameTypeF_24s434_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_pr_242 = heff_dup(heff_env(self)[1]);
  V v_hd_244 = heff_dup(heff_env(self)[2]);
  V v_g_240 = heff_dup(heff_env(self)[3]);
  V v_m_241 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SU, 1, (V[]){v_u_2410})});
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take(v_x_249, 3ULL);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eunify_2erenameHead_24s426(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eunify_2erenameHead_24s426(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse(v_it1_2411, 1ULL);
      V v_t_2427 = heff_intEq(heff_dup(v_m_27_2426), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_2427)) {
      case TAG_True: {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        heff_drop(v_t_2427);
        V v_t_2428 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2429}));
        return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2430, v_k_245});
      }
      case TAG_False: {
        heff_drop(v_ru_24it1_2411_24HMeta);
        heff_drop(v_t_2427);
        V v_c_2431 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameFlexF_24s431_clo), 5, (V[]){v_g_240, v_m_241, v_pr_242, v_m_27_2426, v_sp_2412}));
        return heff_tail(v_c_2431, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam6, 1, 1, (V[]){v_k_245})});
      }
      default: return heff_nomatch(v_t_2427);
      }
    }
    case TAG_HError: {
      V v_c_2433 = (g_heff_2eunify_2erenameHead_24s426(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2437 = heff_field(v_x_249, 0);
    V v_dom_2438 = heff_field(v_x_249, 1);
    V v_cod_2439 = heff_field(v_x_249, 2);
    V v_implicit_2440 = heff_field(v_x_249, 3);
    heff_take(v_x_249, 15ULL);
    V v_c_2441 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2438)}));
    return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam9, 1, 9, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2438, v_cod_2439, v_hd_244, v_k_245, v_level_2437, v_implicit_2440})});
  }
  case TAG_VRecord: {
    V v_level_2445 = heff_field(v_x_249, 0);
    V v_capture_2446 = heff_field(v_x_249, 1);
    V v_fieldTypes_2447 = heff_field(v_x_249, 2);
    heff_take(v_x_249, 7ULL);
    V v_t_2448 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2447), LBL_values));
    V v_c_2449 = (g_heff_2eunify_2erenameRecordFields_24s437(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2446, v_t_2448));
    return heff_tail(v_c_2449, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam11, 1, 3, (V[]){v_fieldTypes_2447, v_k_245, v_level_2445})});
  }
  case TAG_VSum: {
    V v_vs_2452 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    V v_t_2453 = heff_arrayToList(heff_get(heff_dup(v_vs_2452), LBL_keys));
    V v_t_2454 = heff_arrayToList(heff_get(v_vs_2452, LBL_values));
    V v_t_2455 = (g_heff_2edict_2ezipKV(v_t_2453, v_t_2454));
    V v_c_2466 = (g_heff_2eunify_2etraverseU_24s430(heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    return heff_tail(v_c_2466, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam16, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VPrimInt: {
    heff_drop(v_x_249);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    return heff_tail(v_k_245, 1, (V[]){NTAG(TAG_SPrimInt)});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_x_249);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    return heff_tail(v_k_245, 1, (V[]){NTAG(TAG_SPrimFloat)});
  }
  case TAG_VPrimString: {
    heff_drop(v_x_249);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    return heff_tail(v_k_245, 1, (V[]){NTAG(TAG_SPrimString)});
  }
  case TAG_VPrimArray: {
    V v_a_2473 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    V v_c_2474 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2473}));
    return heff_tail(v_c_2474, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s434_lam17, 1, 1, (V[]){v_k_245})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam2(V self, V *args); static Clo g_heff_2eunify_2esolveWithPruned_24s433_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveWithPruned_24s433_lam2, 1, 0};
V g_heff_2eunify_2esolveWithPruned_24s433_lam4(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam3(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam1(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam6(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam8(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam7(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam5(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s433_lam0(V self, V *args);
Clo g_heff_2eunify_2esolveWithPruned_24s433_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveWithPruned_24s433_entry, 8, 0};

V g_heff_2eunify_2esolveWithPruned_24s433(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec(3, shape_65_43_256, (V[]){heff_get(heff_dup(v_entry_243), LBL_arity), MK_INT(0LL), heff_dup(g_map_2eempty_get())});
  return (g_heff_2eunify_2erenameTypeF_24s434(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_get(heff_dup(v_entry_243), LBL_ty), heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eunify_2esolveWithPruned_24s433_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esolveWithPruned_24s433(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam2(V self, V *args) {
  V v_c_2418 = args[0];
  heff_drop(self);
  return heff_get(v_c_2418, LBL_nextMeta);
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2417 = heff_dup(heff_env(self)[0]);
  V v_x_2421 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2424);
  return heff_tail(v_k_2417, 1, (V[]){v_x_2421});
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_entry_243 = heff_dup(heff_env(self)[0]);
  V v_arity_2410 = heff_dup(heff_env(self)[1]);
  V v_ty_2415 = heff_dup(heff_env(self)[2]);
  V v_hd_2416 = heff_dup(heff_env(self)[3]);
  V v_k_2417 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_243, v_arity_2410, v_ty_2415}));
  V v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euModify_24s419_clo), 1, (V[]){v_t_2422}));
  return heff_tail(v_c_2423, 2, (V[]){v_hd_2416, heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam4, 1, 2, (V[]){v_k_2417, v_x_2421})});
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_entry_243 = heff_dup(heff_env(self)[0]);
  V v_arity_2410 = heff_dup(heff_env(self)[1]);
  V v_ty_2415 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveWithPruned_24s433_lam2_clo)})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(heff_dup(v_hd_2416), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam3, 1, 5, (V[]){v_entry_243, v_arity_2410, v_ty_2415, v_hd_2416, v_k_2417})});
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam6(V self, V *args) {
  V v_i_2427 = args[0];
  V v_n_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_intSub(heff_intSub(v_n_244, v_i_2427), MK_INT(1LL));
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_247 = heff_dup(heff_env(self)[0]);
  V v_v_2435 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2439);
  return heff_tail(v_k_247, 1, (V[]){v_v_2435});
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_storeM_242 = heff_dup(heff_env(self)[0]);
  V v_t_2430 = heff_dup(heff_env(self)[1]);
  V v_hd_246 = heff_dup(heff_env(self)[2]);
  V v_k_247 = heff_dup(heff_env(self)[3]);
  V v_v_2435 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2437);
  V v_c_2438 = heff_tr(g_heff_2eunify_2etraceSolve_24s424(v_storeM_242, v_t_2430));
  return heff_tail(v_c_2438, 2, (V[]){v_hd_246, heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam8, 1, 2, (V[]){v_k_247, v_v_2435})});
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_n_244 = heff_dup(heff_env(self)[0]);
  V v_kept_245 = heff_dup(heff_env(self)[1]);
  V v_x_249 = heff_dup(heff_env(self)[2]);
  V v_g_240 = heff_dup(heff_env(self)[3]);
  V v_storeM_242 = heff_dup(heff_env(self)[4]);
  V v_hd_246 = heff_dup(heff_env(self)[5]);
  V v_k_247 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam6, 1, 1, (V[]){heff_dup(v_n_244)}), v_kept_245));
  V v_t_2429 = heff_tag(TAG_SMetaApp, 3, (V[]){v_x_2426, heff_arrayFromList(v_t_2428), v_x_249});
  V v_t_2430 = (g_heff_2eunify_2elamsU(v_n_244, v_t_2429));
  V v_x1_2431 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), heff_dup(v_t_2430), NTAG(TAG_LNil)));
  V v_v_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take(v_x1_2431, 1ULL);
    v_v_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2431, 0ULL);
    v_v_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take(v_x1_2431, 1ULL);
    v_v_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_c_2436 = heff_tr(g_heff_2eunify_2estoreSol_24s422(heff_dup(v_storeM_242), heff_dup(v_v_2435), heff_dup(v_t_2430)));
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam7, 1, 5, (V[]){v_storeM_242, v_t_2430, v_hd_246, v_k_247, v_v_2435})});
}
V g_heff_2eunify_2esolveWithPruned_24s433_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_entry_243 = heff_dup(heff_env(self)[2]);
  V v_hd_246 = heff_dup(heff_env(self)[3]);
  V v_n_244 = heff_dup(heff_env(self)[4]);
  V v_storeM_242 = heff_dup(heff_env(self)[5]);
  V v_k_247 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_arity_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_kept_245));
  V v_x1_2411 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  V v_ty_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take(v_x1_2411, 1ULL);
    v_ty_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2411, 0ULL);
    v_ty_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take(v_x1_2411, 1ULL);
    v_ty_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_c_2425 = heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam1, 2, 3, (V[]){v_entry_243, v_arity_2410, v_ty_2415});
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s433_lam5, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s431_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s431_lam0, 1, 0};
V g_heff_2eunify_2erenameFlexF_24s431_lam2(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s431_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s431_lam2, 1, 0};
V g_heff_2eunify_2erenameFlexF_24s431_lam4(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam6(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam7(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam5(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam11(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s431_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s431_lam11, 2, 0};
V g_heff_2eunify_2erenameFlexF_24s431_lam12(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam13(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s431_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s431_lam13, 2, 0};
V g_heff_2eunify_2erenameFlexF_24s431_lam10(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam14(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam9(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam8(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam3(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s431_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameFlexF_24s431_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s431_entry, 7, 0};

V g_heff_2eunify_2erenameFlexF_24s431(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2erenameFlexF_24s431_lam0_clo)})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam1, 1, 7, (V[]){v_hd_245, heff_dup(v_sp_244), v_k_246, v_pr_242, v_m_27_243, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameFlexF_24s431_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2erenameFlexF_24s431(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[4]); return r;
}
V g_heff_2eunify_2erenameFlexF_24s431_lam0(V self, V *args) {
  V v_c_247 = args[0];
  heff_drop(self);
  return heff_get(v_c_247, LBL_metas);
}
V g_heff_2eunify_2erenameFlexF_24s431_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  heff_drop(self);
  return heff_get(v_c_2411, LBL_selfKey);
}
V g_heff_2eunify_2erenameFlexF_24s431_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_2428;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_PVar: {
    V v_l_2425 = heff_field(v_a_2424, 0);
    heff_take(v_a_2424, 1ULL);
    V v_x3_2426 = ({ V a_0 = v_l_2425; V b_1 = heff_get(v_pr_242, LBL_ren); V r_ = (g_map_2elookup_24s413(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2426)) {
    case TAG_Nothing: {
      heff_drop(v_x3_2426);
      v_x1_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take(v_x3_2426, 0ULL);
      v_x1_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2426);
    }
    break;
  }
  case TAG_PSelf: {
    heff_drop(v_a_2424);
    heff_drop(v_pr_242);
    v_x1_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_True: {
    heff_drop(v_x1_2428);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_2428);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eunify_2erenameFlexF_24s431_lam6(V self, V *args) {
  V v_i_2432 = args[0];
  V v_a_2433 = args[1];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  switch (heff_tag_of(v_a_2433)) {
  case TAG_PVar: {
    V v_l_2434 = heff_field(v_a_2433, 0);
    V v_ru_24a_2433_24PVar = heff_take_reuse(v_a_2433, 1ULL);
    V v_x3_2435 = ({ V a_0 = v_l_2434; V b_1 = heff_get(v_pr_242, LBL_ren); V r_ = (g_map_2elookup_24s413(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2435)) {
    case TAG_Nothing: {
      heff_drop(v_i_2432);
      heff_drop(v_ru_24a_2433_24PVar);
      heff_drop(v_x3_2435);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      heff_take(v_x3_2435, 0ULL);
      return heff_tag_at(v_ru_24a_2433_24PVar, TAG_Just, 1, (V[]){v_i_2432});
    }
    default: return heff_nomatch(v_x3_2435);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2432);
    heff_drop(v_a_2433);
    heff_drop(v_pr_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2433);
  }
}
V g_heff_2eunify_2erenameFlexF_24s431_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sp_244 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_m_241 = heff_dup(heff_env(self)[2]);
  V v_pr_242 = heff_dup(heff_env(self)[3]);
  V v_hd_245 = heff_dup(heff_env(self)[4]);
  V v_k_246 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_v_2441 = ({ V a_0 = v_x_2440; V a_1 = v_sp_244; V r_ = (g_heff_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eunify_2erenameF_24s425(v_g_240, v_m_241, v_pr_242, v_v_2441, v_hd_245, v_k_246));
}
V g_heff_2eunify_2erenameFlexF_24s431_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_args_2423 = heff_dup(heff_env(self)[0]);
  V v_pr_242 = heff_dup(heff_env(self)[1]);
  V v_g_240 = heff_dup(heff_env(self)[2]);
  V v_m_241 = heff_dup(heff_env(self)[3]);
  V v_m_27_243 = heff_dup(heff_env(self)[4]);
  V v_hd_245 = heff_dup(heff_env(self)[5]);
  V v_sp_244 = heff_dup(heff_env(self)[6]);
  V v_k_246 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_t_2431 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2423));
  V v_t_2437 = (g_heff_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2423));
  V v_t_2438 = (g_heff_2eunify_2ecatMaybes(v_t_2437));
  V v_c_2439 = heff_tr(heff_apply(((V)&g_heff_2eunify_2esolveWithPruned_24s433_clo), 6, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2430, v_t_2431, v_t_2438}));
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam11(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  heff_drop(self);
  V v_t_2449 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2450}));
  return heff_tail(heff_get(v_hd_2447, LBL_bind), 2, (V[]){v_t_2451, v_k2_2448});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam12(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  V v_l_27_2452 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_hd_2453);
  V v_t_2455 = heff_intSub(heff_get(v_pr_242, LBL_cod), v_l_27_2452);
  return heff_tail(v_k_2454, 1, (V[]){heff_intSub(v_t_2455, MK_INT(1LL))});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam13(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  heff_drop(self);
  V v_t_2458 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2459}));
  return heff_tail(heff_get(v_hd_2456, LBL_bind), 2, (V[]){v_t_2460, v_k2_2457});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam10(V self, V *args) {
  V v_a_2444 = args[0];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  switch (heff_tag_of(v_a_2444)) {
  case TAG_PVar: {
    V v_l_2445 = heff_field(v_a_2444, 0);
    heff_take(v_a_2444, 1ULL);
    V v_t_2446 = ({ V a_0 = v_l_2445; V b_1 = heff_get(heff_dup(v_pr_242), LBL_ren); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Nothing: {
      heff_drop(v_pr_242);
      heff_drop(v_t_2446);
      return ((V)&g_heff_2eunify_2erenameFlexF_24s431_lam11_clo);
    }
    case TAG_Just: {
      V v_l_27_2452 = heff_field(v_t_2446, 0);
      heff_take(v_t_2446, 1ULL);
      return heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam12, 2, 2, (V[]){v_pr_242, v_l_27_2452});
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_a_2444);
    heff_drop(v_pr_242);
    return ((V)&g_heff_2eunify_2erenameFlexF_24s431_lam13_clo);
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2eunify_2erenameFlexF_24s431_lam14(V self, V *args) {
  V v_x_2462 = args[0];
  V v_m_27_243 = heff_dup(heff_env(self)[0]);
  V v_x_2443 = heff_dup(heff_env(self)[1]);
  V v_k_246 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2463 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2462), v_x_2443});
  return heff_tail(v_k_246, 1, (V[]){v_t_2463});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  V v_args_2423 = heff_dup(heff_env(self)[1]);
  V v_hd_245 = heff_dup(heff_env(self)[2]);
  V v_m_27_243 = heff_dup(heff_env(self)[3]);
  V v_k_246 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2461 = (g_heff_2eunify_2etraverseU_24s430(heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam10, 1, 1, (V[]){v_pr_242}), v_args_2423));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_245, heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam14, 1, 3, (V[]){v_m_27_243, v_x_2443, v_k_246})});
}
V g_heff_2eunify_2erenameFlexF_24s431_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_hd_245 = heff_dup(heff_env(self)[3]);
  V v_args_2423 = heff_dup(heff_env(self)[4]);
  V v_m_27_243 = heff_dup(heff_env(self)[5]);
  V v_k_246 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  return (g_heff_2eunify_2erenameTypeF_24s434(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get(v_x_2442, LBL_ty), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam9, 1, 5, (V[]){v_pr_242, v_args_2423, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eunify_2erenameFlexF_24s431_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_dup(heff_env(self)[0]);
  V v_sp_244 = heff_dup(heff_env(self)[1]);
  V v_hd_245 = heff_dup(heff_env(self)[2]);
  V v_k_246 = heff_dup(heff_env(self)[3]);
  V v_pr_242 = heff_dup(heff_env(self)[4]);
  V v_m_27_243 = heff_dup(heff_env(self)[5]);
  V v_g_240 = heff_dup(heff_env(self)[6]);
  V v_m_241 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = v_sp_244; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    heff_drop(v_t_2415);
    v_t_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2416 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Just = heff_take_reuse(v_t_2415, 1ULL);
    V v_t_2417 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2416)));
    V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2417); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop(v_t_2418);
      v_t_2419 = heff_tag_at(v_ru_24t_2415_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_items_2416))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2416);
      heff_drop(v_ru_24t_2415_24Just);
      heff_drop(v_t_2418);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    heff_drop(v_sp_244);
    heff_drop(v_pr_242);
    heff_drop(v_m_27_243);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_t_2419);
    V v_t_2420 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2422, v_k_246});
  }
  case TAG_Just: {
    V v_args_2423 = heff_field(v_t_2419, 0);
    heff_take(v_t_2419, 1ULL);
    V v_t_2429 = (g_heff_2eunify_2eanyL(heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2423));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_t_2429);
      return (g_heff_2eunify_2emetaEntry_24s432(heff_dup(v_m_27_243), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam5, 1, 8, (V[]){v_args_2423, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_sp_244, v_k_246})));
    }
    case TAG_False: {
      heff_drop(v_sp_244);
      heff_drop(v_t_2429);
      return (g_heff_2eunify_2emetaEntry_24s432(heff_dup(v_m_27_243), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam8, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_hd_245, v_args_2423, v_m_27_243, v_k_246})));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eunify_2erenameFlexF_24s431_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_dup(heff_env(self)[0]);
  V v_sp_244 = heff_dup(heff_env(self)[1]);
  V v_k_246 = heff_dup(heff_env(self)[2]);
  V v_pr_242 = heff_dup(heff_env(self)[3]);
  V v_m_27_243 = heff_dup(heff_env(self)[4]);
  V v_g_240 = heff_dup(heff_env(self)[5]);
  V v_m_241 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2erenameFlexF_24s431_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2eunify_2erenameFlexF_24s431_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_hd_245, v_k_246, v_pr_242, v_m_27_243, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameF_24s425_lam0(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam2(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam3(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam4(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam5(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam7(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam6(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam10(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam9(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam8(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam11(V self, V *args);
V g_heff_2eunify_2erenameF_24s425_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameF_24s425_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameF_24s425_entry, 6, 0};

V g_heff_2eunify_2erenameF_24s425(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2erenameF_24s425_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2erenameF_24s425_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eunify_2erenameF_24s425_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameF_24s425(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameF_24s425_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_v0_243; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2erenameF_24s425_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_sp_2411 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2418 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  return heff_tail(v_t_2418, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s425_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_sp_2411 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2422 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  return heff_tail(v_t_2422, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s425_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  V v_sp_2411 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2430 = (g_heff_2eunify_2erenameSpine_24s427(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2429));
  return heff_tail(v_t_2430, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s425_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SCode, 1, (V[]){v_x_2432})});
}
V g_heff_2eunify_2erenameF_24s425_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_x_2437 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_245, 1, (V[]){heff_tag(TAG_SLam, 2, (V[]){v_x_2437, v_x_2452})});
}
V g_heff_2eunify_2erenameF_24s425_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_fty_2433 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_m_241 = heff_dup(heff_env(self)[2]);
  V v_pr_242 = heff_dup(heff_env(self)[3]);
  V v_body_2434 = heff_dup(heff_env(self)[4]);
  V v_hd_244 = heff_dup(heff_env(self)[5]);
  V v_k_245 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_2438 = heff_tr(heff_apply(v_fty_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2439 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2438)));
  V v_t_2450;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_LikeU: {
    heff_take(v_t_2439, 0ULL);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2442 = heff_field(v_t_2439, 1);
    heff_take(v_t_2439, 2ULL);
    heff_drop(v_t_2438);
    v_t_2450 = v_dom_2442;
    break;
  }
  case TAG_LikeRecord: {
    heff_take(v_t_2439, 0ULL);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeSum: {
    heff_take(v_t_2439, 0ULL);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_t_2439);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_t_2439);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_t_2439);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeArray: {
    heff_take(v_t_2439, 0ULL);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_NoRules: {
    heff_drop(v_t_2439);
    v_t_2450 = v_t_2438;
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  V v_c_2451 = (g_heff_2eunify_2erenameClo_24s428(v_g_240, v_m_241, v_pr_242, v_t_2450, v_body_2434));
  return heff_tail(v_c_2451, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s425_lam7, 1, 2, (V[]){v_k_245, v_x_2437})});
}
V g_heff_2eunify_2erenameF_24s425_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2462 = heff_dup(heff_env(self)[0]);
  V v_k_2458 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_2462, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_2458, v_x_2463})});
}
V g_heff_2eunify_2erenameF_24s425_lam9(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_c_2460 = heff_dup(heff_env(self)[0]);
  V v_k_2458 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2460, 2, (V[]){v_hd_2461, heff_clo(g_heff_2eunify_2erenameF_24s425_lam10, 1, 2, (V[]){v_k_2462, v_k_2458})});
}
V g_heff_2eunify_2erenameF_24s425_lam8(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_pr_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_x_2459 = heff_field(v_p_2457, 1);
    heff_take(v_p_2457, 3ULL);
    V v_c_2460 = heff_tr(g_heff_2eunify_2erenameEvF_24s429(v_g_240, v_m_241, v_pr_242, v_x_2459));
    return heff_clo(g_heff_2eunify_2erenameF_24s425_lam9, 2, 2, (V[]){v_c_2460, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eunify_2erenameF_24s425_lam11(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2466 = (g_prelude_2emap_24s5(heff_dup(v_x_2465)));
  V v_t_2467 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2465));
  V v_t_2468 = (g_prelude_2emap_24s6(v_x_2465));
  V v_t_2469 = heff_rec(3, shape_146_32_353, (V[]){heff_arrayFromList(v_t_2466), v_t_2467, heff_arrayFromList(v_t_2468)});
  V v_x_2470 = heff_tag(TAG_SCons, 1, (V[]){v_t_2469});
  return heff_tail(v_k_245, 1, (V[]){v_x_2470});
}
V g_heff_2eunify_2erenameF_24s425_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_g_240 = heff_dup(heff_env(self)[2]);
  V v_m_241 = heff_dup(heff_env(self)[3]);
  V v_k_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take(v_x_249, 3ULL);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eunify_2erenameHead_24s426(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s425_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eunify_2erenameHead_24s426(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s425_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse(v_it1_2410, 1ULL);
      V v_t_2424 = heff_intEq(heff_dup(v_m_27_2423), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        heff_drop(v_t_2424);
        V v_t_2425 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2426 = heff_tag_at(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2426}));
        return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2427, v_k_245});
      }
      case TAG_False: {
        heff_drop(v_ru_24it1_2410_24HMeta);
        heff_drop(v_t_2424);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2423; V a_4 = v_sp_2411; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2eunify_2erenameFlexF_24s431(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2411); r_; });
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    case TAG_HError: {
      V v_c_2428 = (g_heff_2eunify_2erenameHead_24s426(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s425_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    return (g_heff_2eunify_2erenameTypeF_24s434(v_g_240, v_m_241, v_pr_242, v_t_2431, v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s425_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2433 = heff_field(v_x_249, 0);
    V v_body_2434 = heff_field(v_x_249, 1);
    heff_take(v_x_249, 3ULL);
    V v_t_2435 = heff_tr(heff_apply(heff_dup(v_fty_2433), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_c_2436 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2435}));
    return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s425_lam6, 1, 7, (V[]){v_fty_2433, v_g_240, v_m_241, v_pr_242, v_body_2434, v_hd_244, v_k_245})});
  }
  case TAG_VCons: {
    V v_d_2453 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    V v_t_2454 = heff_arrayToList(heff_get(heff_dup(v_d_2453), LBL_keys));
    V v_t_2455 = heff_arrayToList(heff_get(v_d_2453, LBL_values));
    V v_t_2456 = (g_heff_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2464 = (g_heff_2eunify_2etraverseU_24s430(heff_clo(g_heff_2eunify_2erenameF_24s425_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    return heff_tail(v_c_2464, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s425_lam11, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VOpaque: {
    heff_drop(v_x_249);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    return heff_tail(v_k_245, 1, (V[]){NTAG(TAG_SOpaque)});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eunify_2esolveRhs_24s421_lam1(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam0(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam4(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam5(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam6(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam7(V self, V *args); static Clo g_heff_2eunify_2esolveRhs_24s421_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s421_lam7, 2, 0};
V g_heff_2eunify_2esolveRhs_24s421_lam3(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam2(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam11(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam13(V self, V *args); static Clo g_heff_2eunify_2esolveRhs_24s421_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s421_lam13, 2, 0};
V g_heff_2eunify_2esolveRhs_24s421_lam14(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam12(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam10(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam9(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s421_lam8(V self, V *args);
Clo g_heff_2eunify_2esolveRhs_24s421_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s421_entry, 5, 0};

V g_heff_2eunify_2esolveRhs_24s421(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244) {
top: ;
  V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_243));
  V v_t_246 = (g_heff_2eunify_2emapWithIndexL_24s415(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s414(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_pr_248 = heff_rec(3, shape_65_43_256, (V[]){heff_get(v_cs_241, LBL_len), v_t_245, v_t_247});
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s425_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_242), v_pr_248, v_rhs_244}));
  V v_m_2413 = heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam0, 2, 1, (V[]){v_c_249});
  V v_c_2446 = heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam2, 2, 1, (V[]){v_m_2413});
  return heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam8, 2, 4, (V[]){v_c_2446, v_args_243, v_g_240, v_m_242});
}
V g_heff_2eunify_2esolveRhs_24s421_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esolveRhs_24s421(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2esolveRhs_24s421_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_k_2411, 1, (V[]){heff_tag(TAG_Just, 1, (V[]){v_x_2412})});
}
V g_heff_2eunify_2esolveRhs_24s421_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_249, 2, (V[]){v_hd_2410, heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam1, 1, 1, (V[]){v_k_2411})});
}
V g_heff_2eunify_2esolveRhs_24s421_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_s_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2423}));
  return heff_tail(heff_get(v_hd_2421, LBL_bind), 2, (V[]){v_t_2424, v_k2_2422});
}
V g_heff_2eunify_2esolveRhs_24s421_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_s_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(v_hd_2428, LBL_bind), 2, (V[]){v_t_2431, v_k2_2429});
}
V g_heff_2eunify_2esolveRhs_24s421_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_s_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2439 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2439}));
  return heff_tail(heff_get(v_hd_2437, LBL_bind), 2, (V[]){v_t_2440, v_k2_2438});
}
V g_heff_2eunify_2esolveRhs_24s421_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2441);
  return heff_tail(v_k_2442, 1, (V[]){NTAG(TAG_Nothing)});
}
V g_heff_2eunify_2esolveRhs_24s421_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_hd_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_c_2443;
  switch (heff_tag_of(v_s_2417)) {
  case TAG_UnequalTys: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam4, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_UnequalEls: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam5, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_UnequalNeus: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam6, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_MentionsError: {
    heff_drop(v_s_2417);
    v_c_2443 = ((V)&g_heff_2eunify_2esolveRhs_24s421_lam7_clo);
    break;
  }
  default: heff_nomatch(v_s_2417);
  }
  return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_2414), heff_get(v_hd_2414, LBL_ret)});
}
V g_heff_2eunify_2esolveRhs_24s421_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_m_2413 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2416 = heff_tr(heff_apply(v_m_2413, 2, (V[]){heff_dup(v_hd_2414), heff_get(heff_dup(v_hd_2414), LBL_ret)}));
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Catch, 2, (V[]){v_t_2416, heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam3, 1, 1, (V[]){heff_dup(v_hd_2414)})})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2444}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2445, v_k2_2415});
}
V g_heff_2eunify_2esolveRhs_24s421_lam11(V self, V *args) {
  V v_c_2460 = args[0];
  V v_m_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x3_2461 = ({ V a_0 = v_m_242; V b_1 = heff_get(v_c_2460, LBL_poisoned); V r_ = (g_map_2elookup_24s413(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2461)) {
  case TAG_Nothing: {
    heff_drop(v_x3_2461);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take(v_x3_2461, 0ULL);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2461);
  }
}
V g_heff_2eunify_2esolveRhs_24s421_lam13(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2466);
  return heff_tail(v_k_2467, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2esolveRhs_24s421_lam14(V self, V *args) {
  V v_x_2469 = args[0];
  V v_m_242 = heff_dup(heff_env(self)[0]);
  V v_t_2452 = heff_dup(heff_env(self)[1]);
  V v_hd_2447 = heff_dup(heff_env(self)[2]);
  V v_k_2448 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_tr(g_heff_2eunify_2etraceSolve_24s424(v_m_242, v_t_2452));
  return heff_tail(v_t_2470, 2, (V[]){v_hd_2447, v_k_2448});
}
V g_heff_2eunify_2esolveRhs_24s421_lam12(V self, V *args) {
  V v_x_2465 = args[0];
  V v_v_2457 = heff_dup(heff_env(self)[0]);
  V v_hd_2447 = heff_dup(heff_env(self)[1]);
  V v_m_242 = heff_dup(heff_env(self)[2]);
  V v_t_2452 = heff_dup(heff_env(self)[3]);
  V v_k_2448 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2468;
  switch (heff_tag_of(v_x_2465)) {
  case TAG_True: {
    heff_drop(v_x_2465);
    v_c_2468 = heff_tr(heff_apply(((V)&g_heff_2eunify_2epoisonEl_24s423_clo), 2, (V[]){MK_INT(0LL), v_v_2457}));
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2465);
    heff_drop(v_v_2457);
    v_c_2468 = ((V)&g_heff_2eunify_2esolveRhs_24s421_lam13_clo);
    break;
  }
  default: heff_nomatch(v_x_2465);
  }
  return heff_tail(v_c_2468, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam14, 1, 4, (V[]){v_m_242, v_t_2452, v_hd_2447, v_k_2448})});
}
V g_heff_2eunify_2esolveRhs_24s421_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_m_242 = heff_dup(heff_env(self)[0]);
  V v_hd_2447 = heff_dup(heff_env(self)[1]);
  V v_v_2457 = heff_dup(heff_env(self)[2]);
  V v_t_2452 = heff_dup(heff_env(self)[3]);
  V v_k_2448 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2459);
  V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam11, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2463}));
  return heff_tail(heff_get(heff_dup(v_hd_2447), LBL_bind), 2, (V[]){v_t_2464, heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam12, 1, 5, (V[]){v_v_2457, v_hd_2447, v_m_242, v_t_2452, v_k_2448})});
}
V g_heff_2eunify_2esolveRhs_24s421_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2448 = heff_dup(heff_env(self)[0]);
  V v_args_243 = heff_dup(heff_env(self)[1]);
  V v_g_240 = heff_dup(heff_env(self)[2]);
  V v_m_242 = heff_dup(heff_env(self)[3]);
  V v_hd_2447 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    heff_drop(v_x_2449);
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop(v_hd_2447);
    return heff_tail(v_k_2448, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_body_2450 = heff_field(v_x_2449, 0);
    heff_take(v_x_2449, 1ULL);
    V v_t_2451 = ({ V a_0 = MK_INT(0LL); V a_1 = v_args_243; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_args_243); r_; });
    V v_t_2452 = (g_heff_2eunify_2elamsU(v_t_2451, v_body_2450));
    V v_x1_2453 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), heff_dup(v_t_2452), NTAG(TAG_LNil)));
    V v_v_2457;
    switch (heff_tag_of(v_x1_2453)) {
    case TAG_Nom: {
      V v_x_2454 = heff_field(v_x1_2453, 0);
      heff_take(v_x1_2453, 1ULL);
      v_v_2457 = v_x_2454;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2453, 0ULL);
      v_v_2457 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2456 = heff_field(v_x1_2453, 0);
      heff_take(v_x1_2453, 1ULL);
      v_v_2457 = v_x_2456;
      break;
    }
    default: heff_nomatch(v_x1_2453);
    }
    V v_c_2458 = heff_tr(g_heff_2eunify_2estoreSol_24s422(heff_dup(v_m_242), heff_dup(v_v_2457), heff_dup(v_t_2452)));
    return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam10, 1, 5, (V[]){v_m_242, v_hd_2447, v_v_2457, v_t_2452, v_k_2448})});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2eunify_2esolveRhs_24s421_lam8(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_dup(heff_env(self)[0]);
  V v_args_243 = heff_dup(heff_env(self)[1]);
  V v_g_240 = heff_dup(heff_env(self)[2]);
  V v_m_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2446, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s421_lam9, 1, 5, (V[]){v_k_2448, v_args_243, v_g_240, v_m_242, v_hd_2447})});
}
V g_heff_2eunify_2esolveF_24s420_lam0(V self, V *args); static Clo g_heff_2eunify_2esolveF_24s420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s420_lam0, 1, 0};
V g_heff_2eunify_2esolveF_24s420_lam2(V self, V *args); static Clo g_heff_2eunify_2esolveF_24s420_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s420_lam2, 1, 0};
V g_heff_2eunify_2esolveF_24s420_lam4(V self, V *args);
V g_heff_2eunify_2esolveF_24s420_lam5(V self, V *args);
V g_heff_2eunify_2esolveF_24s420_lam7(V self, V *args);
V g_heff_2eunify_2esolveF_24s420_lam6(V self, V *args);
V g_heff_2eunify_2esolveF_24s420_lam8(V self, V *args);
V g_heff_2eunify_2esolveF_24s420_lam3(V self, V *args);
V g_heff_2eunify_2esolveF_24s420_lam1(V self, V *args);
Clo g_heff_2eunify_2esolveF_24s420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s420_entry, 8, 0};

V g_heff_2eunify_2esolveF_24s420(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveF_24s420_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2eunify_2esolveF_24s420_lam1, 1, 8, (V[]){v_hd_246, heff_dup(v_sp_243), v_cs_241, v_self_245, v_rhs_244, v_k_247, v_g_240, v_m_242})});
}
V g_heff_2eunify_2esolveF_24s420_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esolveF_24s420(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[3]); return r;
}
V g_heff_2eunify_2esolveF_24s420_lam0(V self, V *args) {
  V v_c_248 = args[0];
  heff_drop(self);
  return heff_get(v_c_248, LBL_metas);
}
V g_heff_2eunify_2esolveF_24s420_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  heff_drop(self);
  return heff_get(v_c_2412, LBL_selfKey);
}
V g_heff_2eunify_2esolveF_24s420_lam4(V self, V *args) {
  V v_c_2421 = args[0];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_self_245 = heff_dup(heff_env(self)[1]);
  V v_rhs_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2422 = heff_rec(4, shape_286_159_271_91, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_get(heff_dup(v_c_2421), LBL_postponed)});
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_2421), LBL_infos), heff_get(heff_dup(v_c_2421), LBL_recovered), heff_get(heff_dup(v_c_2421), LBL_poisoned), heff_get(heff_dup(v_c_2421), LBL_metas), heff_get(heff_dup(v_c_2421), LBL_nextMeta), v_t_2423, heff_get(heff_dup(v_c_2421), LBL_trace), heff_get(v_c_2421, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s420_lam5(V self, V *args) {
  V v_c_2448 = args[0];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_self_245 = heff_dup(heff_env(self)[1]);
  V v_rhs_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2449 = heff_rec(4, shape_286_159_271_91, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){v_t_2449, heff_get(heff_dup(v_c_2448), LBL_postponed)});
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_2448), LBL_infos), heff_get(heff_dup(v_c_2448), LBL_recovered), heff_get(heff_dup(v_c_2448), LBL_poisoned), heff_get(heff_dup(v_c_2448), LBL_metas), heff_get(heff_dup(v_c_2448), LBL_nextMeta), v_t_2450, heff_get(heff_dup(v_c_2448), LBL_trace), heff_get(v_c_2448, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s420_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2462);
  return heff_tail(v_k_247, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2esolveF_24s420_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_args_2424 = heff_dup(heff_env(self)[0]);
  V v_args_27_2451 = heff_dup(heff_env(self)[1]);
  V v_g_240 = heff_dup(heff_env(self)[2]);
  V v_m_242 = heff_dup(heff_env(self)[3]);
  V v_hd_246 = heff_dup(heff_env(self)[4]);
  V v_k_247 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2457 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2424));
  V v_t_2458 = (g_heff_2eunify_2ezipL(v_args_2424, v_args_27_2451));
  V v_t_2459 = (g_heff_2eunify_2emapWithIndexL_24s412(MK_INT(0LL), v_t_2458));
  V v_t_2460 = (g_heff_2eunify_2ecatMaybes(v_t_2459));
  V v_c_2461 = heff_tr(heff_apply(((V)&g_heff_2eunify_2esolveWithPruned_24s433_clo), 6, (V[]){v_g_240, heff_dup(v_m_242), v_m_242, v_x_2456, v_t_2457, v_t_2460}));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_246, heff_clo(g_heff_2eunify_2esolveF_24s420_lam7, 1, 1, (V[]){v_k_247})});
}
V g_heff_2eunify_2esolveF_24s420_lam8(V self, V *args) {
  V v_c_2463 = args[0];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_self_245 = heff_dup(heff_env(self)[1]);
  V v_rhs_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2464 = heff_rec(4, shape_286_159_271_91, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2465 = heff_tag(TAG_Cons, 2, (V[]){v_t_2464, heff_get(heff_dup(v_c_2463), LBL_postponed)});
  return heff_rec(8, shape_133_255_236_182_193_239_331_283, (V[]){heff_get(heff_dup(v_c_2463), LBL_infos), heff_get(heff_dup(v_c_2463), LBL_recovered), heff_get(heff_dup(v_c_2463), LBL_poisoned), heff_get(heff_dup(v_c_2463), LBL_metas), heff_get(heff_dup(v_c_2463), LBL_nextMeta), v_t_2465, heff_get(heff_dup(v_c_2463), LBL_trace), heff_get(v_c_2463, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s420_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_dup(heff_env(self)[0]);
  V v_sp_243 = heff_dup(heff_env(self)[1]);
  V v_cs_241 = heff_dup(heff_env(self)[2]);
  V v_self_245 = heff_dup(heff_env(self)[3]);
  V v_rhs_244 = heff_dup(heff_env(self)[4]);
  V v_hd_246 = heff_dup(heff_env(self)[5]);
  V v_k_247 = heff_dup(heff_env(self)[6]);
  V v_g_240 = heff_dup(heff_env(self)[7]);
  V v_m_242 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  V v_t_2416 = ({ V a_0 = heff_dup(v_x_2415); V a_1 = v_x_2411; V a_2 = v_sp_243; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_sp_243); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nothing: {
    heff_drop(v_t_2416);
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2417 = heff_field(v_t_2416, 0);
    V v_ru_24t_2416_24Just = heff_take_reuse(v_t_2416, 1ULL);
    V v_t_2418 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2417)));
    V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2418); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_t_2419);
      v_t_2420 = heff_tag_at(v_ru_24t_2416_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_items_2417))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2417);
      heff_drop(v_ru_24t_2416_24Just);
      heff_drop(v_t_2419);
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    heff_drop(v_x_2415);
    heff_drop(v_x_2411);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop(v_t_2420);
    return (g_heff_2eunify_2euModify_24s419(heff_clo(g_heff_2eunify_2esolveF_24s420_lam4, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_args_2424 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Just = heff_take_reuse(v_t_2420, 1ULL);
    V v_it_2437;
    switch (heff_tag_of(v_rhs_244)) {
    case TAG_VNeu: {
      V v_it1_2425 = heff_dup(heff_field(v_rhs_244, 0));
      V v_sp_2426 = heff_dup(heff_field(v_rhs_244, 1));
      switch (heff_tag_of(v_it1_2425)) {
      case TAG_HLocal: {
        heff_take(v_it1_2425, 0ULL);
        heff_drop(v_ru_24t_2420_24Just);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take(v_it1_2425, 0ULL);
        heff_drop(v_ru_24t_2420_24Just);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2432 = heff_field(v_it1_2425, 0);
        heff_take(v_it1_2425, 1ULL);
        v_it_2437 = heff_tag_at(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2432, v_sp_2426})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_ru_24t_2420_24Just);
        heff_drop(v_it1_2425);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2425);
      }
      break;
    }
    case TAG_VCode: {
      heff_drop(v_ru_24t_2420_24Just);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VLam: {
      heff_drop(v_ru_24t_2420_24Just);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VCons: {
      heff_drop(v_ru_24t_2420_24Just);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VOpaque: {
      heff_drop(v_ru_24t_2420_24Just);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_rhs_244);
    }
    switch (heff_tag_of(v_it_2437)) {
    case TAG_Nothing: {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_self_245);
      heff_drop(v_it_2437);
      V v_t_2438 = (g_heff_2eunify_2esolveRhs_24s421(v_g_240, v_cs_241, v_m_242, v_args_2424, v_rhs_244));
      return heff_tail(v_t_2438, 2, (V[]){v_hd_246, v_k_247});
    }
    case TAG_Just: {
      V v_it1_2439 = heff_field(v_it_2437, 0);
      V v_ru_24it_2437_24Just = heff_take_reuse(v_it_2437, 1ULL);
      switch (heff_tag_of(v_it1_2439)) {
      case TAG_MkPair: {
        V v_m_27_2440 = heff_field(v_it1_2439, 0);
        V v_sp_27_2441 = heff_field(v_it1_2439, 1);
        heff_take(v_it1_2439, 3ULL);
        V v_t_2442 = heff_intEq(v_m_27_2440, heff_dup(v_m_242));
        switch (heff_tag_of(v_t_2442)) {
        case TAG_True: {
          heff_drop(v_t_2442);
          V v_t_2443 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_27_2441; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2411); heff_drop(v_sp_27_2441); r_; });
          V v_t_2447;
          switch (heff_tag_of(v_t_2443)) {
          case TAG_Nothing: {
            heff_drop(v_ru_24it_2437_24Just);
            heff_drop(v_t_2443);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_items_2444 = heff_field(v_t_2443, 0);
            heff_take(v_t_2443, 1ULL);
            V v_t_2445 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2444)));
            V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2445); r_; });
            switch (heff_tag_of(v_t_2446)) {
            case TAG_True: {
              heff_drop(v_t_2446);
              v_t_2447 = heff_tag_at(v_ru_24it_2437_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_items_2444))});
              break;
            }
            case TAG_False: {
              heff_drop(v_ru_24it_2437_24Just);
              heff_drop(v_items_2444);
              heff_drop(v_t_2446);
              v_t_2447 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2446);
            }
            break;
          }
          default: heff_nomatch(v_t_2443);
          }
          switch (heff_tag_of(v_t_2447)) {
          case TAG_Nothing: {
            heff_drop(v_g_240);
            heff_drop(v_m_242);
            heff_drop(v_args_2424);
            heff_drop(v_t_2447);
            return (g_heff_2eunify_2euModify_24s419(heff_clo(g_heff_2eunify_2esolveF_24s420_lam5, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
          }
          case TAG_Just: {
            V v_args_27_2451 = heff_field(v_t_2447, 0);
            heff_take(v_t_2447, 1ULL);
            V v_t_2452 = (g_heff_2eunify_2eeqPatArgs(v_args_27_2451, v_args_2424));
            switch (heff_tag_of(v_t_2452)) {
            case TAG_True: {
              heff_drop(v_cs_241);
              heff_drop(v_self_245);
              heff_drop(v_rhs_244);
              heff_drop(v_hd_246);
              heff_drop(v_g_240);
              heff_drop(v_m_242);
              heff_drop(v_args_2424);
              heff_drop(v_args_27_2451);
              heff_drop(v_t_2452);
              return heff_tail(v_k_247, 1, (V[]){NTAG(TAG_MkUnit)});
            }
            case TAG_False: {
              heff_drop(v_t_2452);
              V v_t_2453 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_27_2451));
              V v_t_2454 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2424));
              V v_t_2455 = heff_intEq(v_t_2453, v_t_2454);
              switch (heff_tag_of(v_t_2455)) {
              case TAG_True: {
                heff_drop(v_cs_241);
                heff_drop(v_self_245);
                heff_drop(v_rhs_244);
                heff_drop(v_t_2455);
                return (g_heff_2eunify_2emetaEntry_24s432(heff_dup(v_m_242), heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveF_24s420_lam6, 1, 6, (V[]){v_args_2424, v_args_27_2451, v_g_240, v_m_242, v_hd_246, v_k_247})));
              }
              case TAG_False: {
                heff_drop(v_g_240);
                heff_drop(v_m_242);
                heff_drop(v_args_2424);
                heff_drop(v_args_27_2451);
                heff_drop(v_t_2455);
                return (g_heff_2eunify_2euModify_24s419(heff_clo(g_heff_2eunify_2esolveF_24s420_lam8, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
              }
              default: return heff_nomatch(v_t_2455);
              }
            }
            default: return heff_nomatch(v_t_2452);
            }
          }
          default: return heff_nomatch(v_t_2447);
          }
        }
        case TAG_False: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          heff_drop(v_ru_24it_2437_24Just);
          heff_drop(v_sp_27_2441);
          heff_drop(v_t_2442);
          V v_t_2466 = (g_heff_2eunify_2esolveRhs_24s421(v_g_240, v_cs_241, v_m_242, v_args_2424, v_rhs_244));
          return heff_tail(v_t_2466, 2, (V[]){v_hd_246, v_k_247});
        }
        default: return heff_nomatch(v_t_2442);
        }
      }
      default: return heff_nomatch(v_it1_2439);
      }
    }
    default: return heff_nomatch(v_it_2437);
    }
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2eunify_2esolveF_24s420_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_dup(heff_env(self)[0]);
  V v_sp_243 = heff_dup(heff_env(self)[1]);
  V v_cs_241 = heff_dup(heff_env(self)[2]);
  V v_self_245 = heff_dup(heff_env(self)[3]);
  V v_rhs_244 = heff_dup(heff_env(self)[4]);
  V v_k_247 = heff_dup(heff_env(self)[5]);
  V v_g_240 = heff_dup(heff_env(self)[6]);
  V v_m_242 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveF_24s420_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2eunify_2esolveF_24s420_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247, v_g_240, v_m_242})});
}
V g_heff_2eunify_2euTypeF_24s417_lam0(V self, V *args);
V g_heff_2eunify_2euTypeF_24s417_lam2(V self, V *args);
V g_heff_2eunify_2euTypeF_24s417_lam4(V self, V *args);
V g_heff_2eunify_2euTypeF_24s417_lam3(V self, V *args);
V g_heff_2eunify_2euTypeF_24s417_lam1(V self, V *args);
Clo g_heff_2eunify_2euTypeF_24s417_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTypeF_24s417_entry, 6, 0};

V g_heff_2eunify_2euTypeF_24s417(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTypeF_24s417_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2euTypeF_24s417_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eunify_2euTypeF_24s417_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euTypeF_24s417(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2euTypeF_24s417_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_a0_242; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTypeF_24s417_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V b_0 = heff_get(v_c_2410, LBL_metas); V a_1 = v_b0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTypeF_24s417_lam4(V self, V *args) {
  V v_x_2452 = args[0];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_x_2413 = heff_dup(heff_env(self)[1]);
  V v_hd_244 = heff_dup(heff_env(self)[2]);
  V v_k_245 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2452);
  return (g_heff_2eunify_2epoisonTy_24s418(heff_get(v_cs_241, LBL_len), v_x_2413, v_hd_244, v_k_245));
}
V g_heff_2eunify_2euTypeF_24s417_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_cs_241 = heff_dup(heff_env(self)[1]);
  V v_hd_244 = heff_dup(heff_env(self)[2]);
  V v_k_245 = heff_dup(heff_env(self)[3]);
  V v_g_240 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2432;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take(v_h_2415, 0ULL);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take(v_h_2415, 0ULL);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take(v_h_2415, 0ULL);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      heff_drop(v_h_2415);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2451;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_True: {
    heff_drop(v_t_2432);
    v_t_2451 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2432);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2434 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2434)) {
      case TAG_HLocal: {
        heff_take(v_h_2434, 0ULL);
        v_t_2451 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take(v_h_2434, 0ULL);
        v_t_2451 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take(v_h_2434, 0ULL);
        v_t_2451 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        heff_drop(v_h_2434);
        v_t_2451 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2434);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  switch (heff_tag_of(v_t_2451)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_t_2451);
    return (g_heff_2eunify_2epoisonTy_24s418(heff_get(heff_dup(v_cs_241), LBL_len), v_x_249, heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2euTypeF_24s417_lam4, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245})));
  }
  case TAG_False: {
    heff_drop(v_t_2451);
    V v_it_2471;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2454 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2455 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_it1_2454)) {
      case TAG_HLocal: {
        heff_take(v_it1_2454, 0ULL);
        heff_drop(v_sp_2455);
        v_it_2471 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take(v_it1_2454, 0ULL);
        heff_drop(v_sp_2455);
        v_it_2471 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2461 = heff_field(v_it1_2454, 0);
        V v_ru_24it1_2454_24HMeta = heff_take_reuse(v_it1_2454, 1ULL);
        v_it_2471 = heff_tag_at(v_ru_24it1_2454_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2461, v_sp_2455})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_it1_2454);
        heff_drop(v_sp_2455);
        v_it_2471 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2454);
      }
      break;
    }
    case TAG_VFunction: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_it_2471 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_it_2471)) {
    case TAG_Nothing: {
      heff_drop(v_it_2471);
      V v_it_2490;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_it1_2473 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2474 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_it1_2473)) {
        case TAG_HLocal: {
          heff_take(v_it1_2473, 0ULL);
          heff_drop(v_sp_2474);
          v_it_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take(v_it1_2473, 0ULL);
          heff_drop(v_sp_2474);
          v_it_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_2480 = heff_field(v_it1_2473, 0);
          V v_ru_24it1_2473_24HMeta = heff_take_reuse(v_it1_2473, 1ULL);
          v_it_2490 = heff_tag_at(v_ru_24it1_2473_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2480, v_sp_2474})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_it1_2473);
          heff_drop(v_sp_2474);
          v_it_2490 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_it1_2473);
        }
        break;
      }
      case TAG_VFunction: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_it_2490 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_it_2490)) {
      case TAG_Nothing: {
        heff_drop(v_it_2490);
        V v_t_2491 = ({ V a_0 = heff_dup(g_co_2eplus_24s16_get()); V b_1 = ((V)&g_heff_2eunify_2emsEv_clo); V a_2 = ((V)&g_heff_2eunify_2eufEv_clo); V a_3 = heff_dup(g_heff_2eunify_2euk_24s416_get()); V a_4 = v_g_240; V a_5 = v_cs_241; V a_6 = v_x_249; V a_7 = v_x_2413; V r_ = heff_tr(g_heff_2eunify_2euTyRigid(a_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(b_1); r_; });
        return heff_tail(v_t_2491, 2, (V[]){v_hd_244, v_k_245});
      }
      case TAG_Just: {
        V v_it1_2492 = heff_field(v_it_2490, 0);
        V v_ru_24it_2490_24Just = heff_take_reuse(v_it_2490, 1ULL);
        switch (heff_tag_of(v_it1_2492)) {
        case TAG_MkPair: {
          V v_m_2493 = heff_field(v_it1_2492, 0);
          V v_sp_2494 = heff_field(v_it1_2492, 1);
          heff_take(v_it1_2492, 3ULL);
          V v_rhs_24110;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24100 = heff_field(v_x_249, 4);
            heff_take(v_x_249, 16ULL);
            heff_drop(v_ru_24it_2490_24Just);
            v_rhs_24110 = heff_tr(heff_apply(v_el_24100, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24110 = heff_tag_at(v_ru_24it_2490_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24126;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24116 = heff_field(v_x_2413, 4);
            heff_take(v_x_2413, 16ULL);
            v_self_24126 = heff_tr(heff_apply(v_el_24116, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24126 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_2493; V a_3 = v_sp_2494; V a_4 = v_rhs_24110; V a_5 = v_self_24126; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eunify_2esolveF_24s420(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_2494); r_; });
        }
        default: return heff_nomatch(v_it1_2492);
        }
      }
      default: return heff_nomatch(v_it_2490);
      }
    }
    case TAG_Just: {
      V v_it1_24127 = heff_field(v_it_2471, 0);
      V v_ru_24it_2471_24Just = heff_take_reuse(v_it_2471, 1ULL);
      switch (heff_tag_of(v_it1_24127)) {
      case TAG_MkPair: {
        V v_m_24128 = heff_field(v_it1_24127, 0);
        V v_sp_24129 = heff_field(v_it1_24127, 1);
        heff_take(v_it1_24127, 3ULL);
        V v_rhs_24145;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24135 = heff_field(v_x_2413, 4);
          heff_take(v_x_2413, 16ULL);
          heff_drop(v_ru_24it_2471_24Just);
          v_rhs_24145 = heff_tr(heff_apply(v_el_24135, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24145 = heff_tag_at(v_ru_24it_2471_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24161;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24151 = heff_field(v_x_249, 4);
          heff_take(v_x_249, 16ULL);
          v_self_24161 = heff_tr(heff_apply(v_el_24151, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24161 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24128; V a_3 = v_sp_24129; V a_4 = v_rhs_24145; V a_5 = v_self_24161; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eunify_2esolveF_24s420(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24129); r_; });
      }
      default: return heff_nomatch(v_it1_24127);
      }
    }
    default: return heff_nomatch(v_it_2471);
    }
  }
  default: return heff_nomatch(v_t_2451);
  }
}
V g_heff_2eunify_2euTypeF_24s417_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_cs_241 = heff_dup(heff_env(self)[2]);
  V v_k_245 = heff_dup(heff_env(self)[3]);
  V v_g_240 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTypeF_24s417_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2eunify_2euTypeF_24s417_lam3, 1, 5, (V[]){v_x_249, v_cs_241, v_hd_244, v_k_245, v_g_240})});
}
V g_heff_2eunify_2euBareF_24s438_lam0(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s438_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s438_lam0, 2, 0};
V g_heff_2eunify_2euBareF_24s438_lam1(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s438_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s438_lam1, 2, 0};
V g_heff_2eunify_2euBareF_24s438_lam2(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam3(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam4(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam5(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam6(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam8(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam7(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam9(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam10(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam11(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam12(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam14(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam13(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam15(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam16(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam17(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam18(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam21(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s438_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s438_lam21, 2, 0};
V g_heff_2eunify_2euBareF_24s438_lam22(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam23(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam20(V self, V *args);
V g_heff_2eunify_2euBareF_24s438_lam19(V self, V *args);
Clo g_heff_2eunify_2euBareF_24s438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s438_entry, 6, 0};

V g_heff_2eunify_2euBareF_24s438(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eunify_2euBareF_24s438_lam0_clo);
  }
  case TAG_False: {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2econversion_2eeqHead(v_h_242, v_h_27_244));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_sp_243);
          heff_drop(v_h_27_244);
          heff_drop(v_sp_27_245);
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eunify_2euBareF_24s438_lam1_clo);
        }
        case TAG_False: {
          heff_drop(v_t_2421);
          return heff_clo(g_heff_2eunify_2euBareF_24s438_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
        default: return heff_nomatch(v_t_2421);
        }
      }
      case TAG_SpApp: {
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2447 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2448 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2453 = heff_field(v_sp_27_245, 0);
        V v_v_27_2454 = heff_field(v_sp_27_245, 1);
        heff_take(v_sp_27_245, 3ULL);
        heff_drop(v_sp_243);
        V v_c_2455 = (g_heff_2eunify_2euBareF_24s438(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2447, v_h_27_244, v_sq_27_2453));
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam7, 2, 5, (V[]){v_c_2455, v_g_240, v_cs_241, v_v_2448, v_v_27_2454});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2473 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2474 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_2485 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2486 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2487 = (g_heff_2eunify_2euBareF_24s438(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2473, heff_dup(v_h_27_244), v_sq_27_2485));
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam13, 2, 8, (V[]){v_c_2487, v_x_2474, v_x_27_2486, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24101 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24102 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24103 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24120 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24121 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24122 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24123 = (g_heff_2eunify_2euBareF_24s438(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24101, heff_dup(v_h_27_244), v_sq_27_24120));
        return heff_clo(g_heff_2eunify_2euBareF_24s438_lam19, 2, 11, (V[]){v_c_24123, v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24103, v_v_27_24122});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eunify_2euBareF_24s438_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euBareF_24s438(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2euBareF_24s438_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2419);
  return heff_tail(v_k_2420, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euBareF_24s438_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2422);
  return heff_tail(v_k_2423, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euBareF_24s438_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2426 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})}));
  return heff_tail(heff_get(v_hd_2424, LBL_bind), 2, (V[]){v_t_2427, v_k2_2425});
}
V g_heff_2eunify_2euBareF_24s438_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2432 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})}));
  return heff_tail(heff_get(v_hd_2430, LBL_bind), 2, (V[]){v_t_2433, v_k2_2431});
}
V g_heff_2eunify_2euBareF_24s438_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2438 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2436), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})}));
  return heff_tail(heff_get(v_hd_2436, LBL_bind), 2, (V[]){v_t_2439, v_k2_2437});
}
V g_heff_2eunify_2euBareF_24s438_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2445 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2443), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2445})}));
  return heff_tail(heff_get(v_hd_2443, LBL_bind), 2, (V[]){v_t_2446, v_k2_2444});
}
V g_heff_2eunify_2euBareF_24s438_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2451 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2449), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2451})}));
  return heff_tail(heff_get(v_hd_2449, LBL_bind), 2, (V[]){v_t_2452, v_k2_2450});
}
V g_heff_2eunify_2euBareF_24s438_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_cs_241 = heff_dup(heff_env(self)[1]);
  V v_v_2448 = heff_dup(heff_env(self)[2]);
  V v_v_27_2454 = heff_dup(heff_env(self)[3]);
  V v_hd_2456 = heff_dup(heff_env(self)[4]);
  V v_k_2457 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s416_get()), v_g_240, v_cs_241, v_v_2448, v_v_27_2454));
  return heff_tail(v_t_2459, 2, (V[]){v_hd_2456, v_k_2457});
}
V g_heff_2eunify_2euBareF_24s438_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_cs_241 = heff_dup(heff_env(self)[2]);
  V v_v_2448 = heff_dup(heff_env(self)[3]);
  V v_v_27_2454 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return heff_tail(v_c_2455, 2, (V[]){heff_dup(v_hd_2456), heff_clo(g_heff_2eunify_2euBareF_24s438_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2448, v_v_27_2454, v_hd_2456, v_k_2457})});
}
V g_heff_2eunify_2euBareF_24s438_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2464 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2462), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2464})}));
  return heff_tail(heff_get(v_hd_2462, LBL_bind), 2, (V[]){v_t_2465, v_k2_2463});
}
V g_heff_2eunify_2euBareF_24s438_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2471 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2469), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2471})}));
  return heff_tail(heff_get(v_hd_2469, LBL_bind), 2, (V[]){v_t_2472, v_k2_2470});
}
V g_heff_2eunify_2euBareF_24s438_lam11(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2477 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2475), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2477})}));
  return heff_tail(heff_get(v_hd_2475, LBL_bind), 2, (V[]){v_t_2478, v_k2_2476});
}
V g_heff_2eunify_2euBareF_24s438_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2483 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2481), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2483})}));
  return heff_tail(heff_get(v_hd_2481, LBL_bind), 2, (V[]){v_t_2484, v_k2_2482});
}
V g_heff_2eunify_2euBareF_24s438_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2474 = heff_dup(heff_env(self)[0]);
  V v_x_27_2486 = heff_dup(heff_env(self)[1]);
  V v_k_2489 = heff_dup(heff_env(self)[2]);
  V v_cs_241 = heff_dup(heff_env(self)[3]);
  V v_h_242 = heff_dup(heff_env(self)[4]);
  V v_sp_243 = heff_dup(heff_env(self)[5]);
  V v_h_27_244 = heff_dup(heff_env(self)[6]);
  V v_sp_27_245 = heff_dup(heff_env(self)[7]);
  V v_hd_2488 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  heff_drop(v_x_2490);
  V v_t_2491 = heff_strEq(v_x_2474, v_x_27_2486);
  switch (heff_tag_of(v_t_2491)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_hd_2488);
    heff_drop(v_t_2491);
    return heff_tail(v_k_2489, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_False: {
    heff_drop(v_t_2491);
    V v_t_2492 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2488), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2492})}));
    return heff_tail(heff_get(v_hd_2488, LBL_bind), 2, (V[]){v_t_2493, v_k_2489});
  }
  default: return heff_nomatch(v_t_2491);
  }
}
V g_heff_2eunify_2euBareF_24s438_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_dup(heff_env(self)[0]);
  V v_x_2474 = heff_dup(heff_env(self)[1]);
  V v_x_27_2486 = heff_dup(heff_env(self)[2]);
  V v_cs_241 = heff_dup(heff_env(self)[3]);
  V v_h_242 = heff_dup(heff_env(self)[4]);
  V v_sp_243 = heff_dup(heff_env(self)[5]);
  V v_h_27_244 = heff_dup(heff_env(self)[6]);
  V v_sp_27_245 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  return heff_tail(v_c_2487, 2, (V[]){heff_dup(v_hd_2488), heff_clo(g_heff_2eunify_2euBareF_24s438_lam14, 1, 9, (V[]){v_x_2474, v_x_27_2486, v_k_2489, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2488})});
}
V g_heff_2eunify_2euBareF_24s438_lam15(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2499 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2497), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2499})}));
  return heff_tail(heff_get(v_hd_2497, LBL_bind), 2, (V[]){v_t_24100, v_k2_2498});
}
V g_heff_2eunify_2euBareF_24s438_lam16(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k2_24105 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_24106 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24104), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24106})}));
  return heff_tail(heff_get(v_hd_24104, LBL_bind), 2, (V[]){v_t_24107, v_k2_24105});
}
V g_heff_2eunify_2euBareF_24s438_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_24112 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24110), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24112})}));
  return heff_tail(heff_get(v_hd_24110, LBL_bind), 2, (V[]){v_t_24113, v_k2_24111});
}
V g_heff_2eunify_2euBareF_24s438_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_24118 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24116), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24118})}));
  return heff_tail(heff_get(v_hd_24116, LBL_bind), 2, (V[]){v_t_24119, v_k2_24117});
}
V g_heff_2eunify_2euBareF_24s438_lam21(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  heff_drop(self);
  heff_drop(v_hd_24128);
  return heff_tail(v_k_24129, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2eunify_2euBareF_24s438_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_h_242 = heff_dup(heff_env(self)[1]);
  V v_sp_243 = heff_dup(heff_env(self)[2]);
  V v_h_27_244 = heff_dup(heff_env(self)[3]);
  V v_sp_27_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_24132 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24133 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24130), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24132})}));
  return heff_tail(heff_get(v_hd_24130, LBL_bind), 2, (V[]){v_t_24133, v_k2_24131});
}
V g_heff_2eunify_2euBareF_24s438_lam23(V self, V *args) {
  V v_x_24135 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_cs_241 = heff_dup(heff_env(self)[1]);
  V v_v_24103 = heff_dup(heff_env(self)[2]);
  V v_v_27_24122 = heff_dup(heff_env(self)[3]);
  V v_hd_24124 = heff_dup(heff_env(self)[4]);
  V v_k_24125 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_24135);
  V v_t_24136 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s416_get()), v_g_240, v_cs_241, v_v_24103, v_v_27_24122));
  return heff_tail(v_t_24136, 2, (V[]){v_hd_24124, v_k_24125});
}
V g_heff_2eunify_2euBareF_24s438_lam20(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x_24102 = heff_dup(heff_env(self)[0]);
  V v_x_27_24121 = heff_dup(heff_env(self)[1]);
  V v_cs_241 = heff_dup(heff_env(self)[2]);
  V v_h_242 = heff_dup(heff_env(self)[3]);
  V v_sp_243 = heff_dup(heff_env(self)[4]);
  V v_h_27_244 = heff_dup(heff_env(self)[5]);
  V v_sp_27_245 = heff_dup(heff_env(self)[6]);
  V v_hd_24124 = heff_dup(heff_env(self)[7]);
  V v_g_240 = heff_dup(heff_env(self)[8]);
  V v_v_24103 = heff_dup(heff_env(self)[9]);
  V v_v_27_24122 = heff_dup(heff_env(self)[10]);
  V v_k_24125 = heff_dup(heff_env(self)[11]);
  heff_drop(self);
  heff_drop(v_x_24126);
  V v_t_24127 = heff_strEq(v_x_24102, v_x_27_24121);
  V v_c_24134;
  switch (heff_tag_of(v_t_24127)) {
  case TAG_True: {
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_t_24127);
    v_c_24134 = ((V)&g_heff_2eunify_2euBareF_24s438_lam21_clo);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_24127);
    v_c_24134 = heff_clo(g_heff_2eunify_2euBareF_24s438_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
    break;
  }
  default: heff_nomatch(v_t_24127);
  }
  return heff_tail(v_c_24134, 2, (V[]){heff_dup(v_hd_24124), heff_clo(g_heff_2eunify_2euBareF_24s438_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24103, v_v_27_24122, v_hd_24124, v_k_24125})});
}
V g_heff_2eunify_2euBareF_24s438_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_dup(heff_env(self)[0]);
  V v_x_24102 = heff_dup(heff_env(self)[1]);
  V v_x_27_24121 = heff_dup(heff_env(self)[2]);
  V v_cs_241 = heff_dup(heff_env(self)[3]);
  V v_h_242 = heff_dup(heff_env(self)[4]);
  V v_sp_243 = heff_dup(heff_env(self)[5]);
  V v_h_27_244 = heff_dup(heff_env(self)[6]);
  V v_sp_27_245 = heff_dup(heff_env(self)[7]);
  V v_g_240 = heff_dup(heff_env(self)[8]);
  V v_v_24103 = heff_dup(heff_env(self)[9]);
  V v_v_27_24122 = heff_dup(heff_env(self)[10]);
  heff_drop(self);
  return heff_tail(v_c_24123, 2, (V[]){heff_dup(v_hd_24124), heff_clo(g_heff_2eunify_2euBareF_24s438_lam20, 1, 12, (V[]){v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24124, v_g_240, v_v_24103, v_v_27_24122, v_k_24125})});
}
V g_heff_2eunify_2euk_24s416_lam0(V self, V *args); static Clo g_heff_2eunify_2euk_24s416_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euk_24s416_lam0, 4, 0};

static V g_heff_2eunify_2euk_24s416_val;
static int g_heff_2eunify_2euk_24s416_st;
static V g_heff_2eunify_2euk_24s416_init(void) {
  return heff_rec(9, shape_349_342_341_295_256_257_260_258_259, (V[]){((V)&g_heff_2eunify_2euTypeF_24s417_clo), ((V)&g_heff_2eunify_2euk_24s416_lam0_clo), ((V)&g_heff_2eunify_2euBareF_24s438_clo), ((V)&g_heff_2eunify_2esolveF_24s420_clo), ((V)&g_heff_2eunify_2erenameF_24s425_clo), ((V)&g_heff_2eunify_2erenameEvF_24s429_clo), ((V)&g_heff_2eunify_2erenameTypeF_24s434_clo), ((V)&g_heff_2eunify_2erenameEvTypeF_24s436_clo), ((V)&g_heff_2eunify_2erenameFlexF_24s431_clo)});
}
V g_heff_2eunify_2euk_24s416_get(void) {
  if (g_heff_2eunify_2euk_24s416_st == 2) return g_heff_2eunify_2euk_24s416_val;
  if (g_heff_2eunify_2euk_24s416_st == 1) heff_fail("defined by itself");
  g_heff_2eunify_2euk_24s416_st = 1;
  g_heff_2eunify_2euk_24s416_val = heff_tr(g_heff_2eunify_2euk_24s416_init());
  g_heff_2eunify_2euk_24s416_st = 2;
  return g_heff_2eunify_2euk_24s416_val;
}
V g_heff_2eunify_2euk_24s416_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  heff_drop(self);
  return (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s416_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}