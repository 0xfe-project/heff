// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eunify_2euModify_lam1(V self, V *args);
V g_heff_2eunify_2euModify_lam0(V self, V *args);
V g_heff_2eunify_2euModify_lam4(V self, V *args);
V g_heff_2eunify_2euModify_lam3(V self, V *args);
V g_heff_2eunify_2euModify_lam2(V self, V *args);
Clo g_heff_2eunify_2euModify_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euModify_entry, 4, 0};

V g_heff_2eunify_2euModify(V v_w_240, V v_ms_241, V v_uf_242, V v_f_243) {
top: ;
  V v_p_244 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_243})}));
  V v_c_2410 = heff_clo(g_heff_2eunify_2euModify_lam0, 2, 2, (V[]){heff_dup(v_w_240), v_p_244});
  return heff_clo(g_heff_2eunify_2euModify_lam2, 2, 3, (V[]){v_c_2410, v_ms_241, v_w_240});
}
V g_heff_2eunify_2euModify_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euModify(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2eunify_2euModify_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_245), heff_get(v_hd_245, LBL_ret)});
}
V g_heff_2eunify_2euModify_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euModify_lam1, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_248}));
  V f_ = heff_get(v_hd_245, LBL_bind);
  args[0] = v_t_249;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euModify_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2411), heff_get(v_hd_2411, LBL_ret)});
}
V g_heff_2eunify_2euModify_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_p_2415 = heff_tr(heff_apply(v_ms_241, 1, (V[]){v_t_2414}));
  V v_t_2417 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euModify_lam4, 1, 1, (V[]){heff_dup(v_hd_2411)}), v_p_2415}));
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2418, v_k_2412});
}
V g_heff_2eunify_2euModify_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2eunify_2euModify_lam3, 1, 4, (V[]){v_ms_241, v_w_240, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          v_t_2411 = heff_intEq(heff_dup(v_l_248), heff_dup(v_l_27_249));
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eeqPatArgs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, (g_heff_2eunify_2epatVarsOf(v_rest_242))});
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epatVarsOf(a[0]);
}
V g_heff_2eunify_2edistinct_lam0(V self, V *args);
Clo g_heff_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_244 = (g_prelude_2eany(heff_clo(g_heff_2eunify_2edistinct_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2edistinct(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2edistinct_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_x_241, v_b_243);
}
Clo g_heff_2eunify_2epatStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatStep_entry, 3, 0};

V g_heff_2eunify_2epatStep(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_it1_244 = heff_field(v_v_241, 0);
      V v_it2_245 = heff_field(v_v_241, 1);
      switch (heff_tag_of(v_it1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_it1_244, 0);
        heff_drop(v_selfKey_240);
        switch (heff_tag_of(v_it2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){heff_dup(v_l_249)}), v_rest_243});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2410});
        }
        case TAG_SpApp: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_245);
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_it1_244, 0);
        switch (heff_tag_of(v_it2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_rest_243);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            heff_take_n(v_selfKey_240, 1ULL, 1);
            V v_t_2420 = heff_strEq(v_sk_2419, heff_dup(v_k_2418));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_True: {
              V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return heff_tag_at(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
            }
            case TAG_False: {
              heff_drop(v_rest_243);
              heff_drop_cell(v_ru_24x3_242_24Just, 1);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
          default: return heff_nomatch(v_selfKey_240);
          }
        }
        case TAG_SpApp: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_245);
        }
      }
      case TAG_HMeta: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it1_244);
      }
    }
    case TAG_VCode: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_v_241);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2epatStep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epatStep(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop(v_selfKey_240);
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2evalue_2eforceEl(v_mc_241, heff_dup(v_v_244)));
    V v_t_246 = (g_heff_2eunify_2epatSpine(heff_dup(v_selfKey_240), v_mc_241, v_s_243));
    return ({ V a_0 = v_selfKey_240; V a_1 = v_t_245; V a_2 = v_t_246; V r_ = (g_heff_2eunify_2epatStep(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_SpProj: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epatSpine(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eunify_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2enth_entry, 2, 0};

V g_heff_2eunify_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2enth_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2enth(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eunify_2emapWithIndexL(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eunify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eunify_2ecatMaybes(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2ecatMaybes(a[0]);
}
Clo g_heff_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eanyL(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eunify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2econcatMapL(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2eforU_lam0(V self, V *args); static Clo g_heff_2eunify_2eforU_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eforU_lam0, 2, 0};
V g_heff_2eunify_2eforU_lam2(V self, V *args);
V g_heff_2eunify_2eforU_lam1(V self, V *args);
Clo g_heff_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eforU_entry, 5, 0};

V g_heff_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    return ((V)&g_heff_2eunify_2eforU_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_apply(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_clo(g_heff_2eunify_2eforU_lam1, 2, 6, (V[]){v_c_249, heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2eforU(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eunify_2eforU_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2eforU_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_t_2413 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V r_ = (g_heff_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_2410, v_k_2411});
}
V g_heff_2eunify_2eforU_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_uf_242 = heff_env(self)[3];
  V v_xs_248 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2eunify_2eforU_lam2, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_xs_248, v_f_244, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_depth_242), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_it_246 = (g_heff_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_246)) {
    case TAG_VNeu: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_sp_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 5);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HMeta: {
        V v_m_2414 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248}));
        return heff_tag(TAG_Cons, 2, (V[]){v_m_2414, v_t_2415});
      }
      case TAG_HError: {
        return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    case TAG_VCode: {
      V v_t_2416 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      return heff_tail(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2416});
    }
    case TAG_VLam: {
      V v_d_2417 = heff_field(v_it_246, 0);
      V v_c_2418 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      V v_x1_2438;
      switch (heff_tag_of(v_c_2418)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_c_2418, 1);
        V v_body_2421 = heff_field(v_c_2418, 2);
        heff_take_n(v_c_2418, 6ULL, 3);
        v_x1_2438 = heff_tr(heff_apply(v_body_2421, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo(g_heff_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2417, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2437 = heff_field(v_c_2418, 0);
        heff_take_n(v_c_2418, 1ULL, 1);
        heff_drop(v_d_2417);
        v_x1_2438 = v_body_2437;
        break;
      }
      default: heff_nomatch(v_c_2418);
      }
      V v_t_2442;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_Nom: {
        V v_x_2439 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2442 = v_x_2439;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2438, 0ULL, 1);
        v_t_2442 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2441 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2442 = v_x_2441;
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2442});
    }
    case TAG_VCons: {
      V v_d_2443 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      V v_t_2444 = heff_arrayToList(heff_get(v_d_2443, LBL_values));
      return ({ V a_0 = heff_clo(g_heff_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_r_240, v_depth_242, v_len_243}); V a_1 = v_t_2444; V r_ = (g_heff_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2444); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasTermF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2436 = args[0];
  V v_a_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2436);
  return v_a_2435;
}
V g_heff_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2417 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_apply(v_d_2417, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2423)));
  V v_a_2435;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2427 = heff_field(v_t_2424, 1);
    heff_take_n(v_t_2424, 2ULL, 4);
    heff_drop(v_t_2423);
    v_a_2435 = v_dom_2427;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2424, 0ULL, 3);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeInt: {
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeString: {
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2435 = v_t_2423;
    break;
  }
  case TAG_NoRules: {
    v_a_2435 = v_t_2423;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  return (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2435}), NTAG(TAG_Nothing)));
}
V g_heff_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2445 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Nom: {
    V v_x_2446 = heff_field(v_x_2445, 0);
    heff_take_n(v_x_2445, 1ULL, 1);
    v_t_2449 = v_x_2446;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2445, 0ULL, 1);
    v_t_2449 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2448 = heff_field(v_x_2445, 0);
    heff_take_n(v_x_2445, 1ULL, 1);
    v_t_2449 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2449});
}
V g_heff_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_depth_242), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_t_246 = (g_heff_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 16ULL, 5);
      V v_t_2413 = heff_tr(heff_apply(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get(v_r_240, LBL_mel), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 4);
      V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_mty), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2425;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_cod_2416, 1);
        V v_body_2421 = heff_field(v_cod_2416, 2);
        heff_take_n(v_cod_2416, 6ULL, 3);
        v_x1_2425 = heff_tr(heff_apply(v_body_2421, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo(g_heff_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2424 = heff_field(v_cod_2416, 0);
        heff_take_n(v_cod_2416, 1ULL, 1);
        heff_drop(v_dom_2415);
        v_x1_2425 = v_body_2424;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2429;
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nom: {
        V v_x_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        v_t_2429 = v_x_2426;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2425, 0ULL, 1);
        v_t_2429 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2428 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        v_t_2429 = v_x_2428;
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
      V v_t_2430 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2429}));
      return (g_heff_2eunify_2eappendL(v_t_2418, v_t_2430));
    }
    case TAG_VRecord: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop(v_r_240);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2436 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tail(heff_get(v_r_240, LBL_mty), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2436});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasTypeF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2423 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_dom_2415;
}
V g_heff_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  return (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop(v_r_240);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_msp), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get(v_r_240, LBL_msp), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_msp), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_mel), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasSpF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); heff_drop(a[4]); return r;
}
V g_heff_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec(3, shape_187_195_194, (V[]){heff_clo(g_heff_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2emetasK(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eunify_2epoisonEl_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonEl_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_lam0, 1, 0};
V g_heff_2eunify_2epoisonEl_lam2(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam1(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam5(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam4(V self, V *args);
V g_heff_2eunify_2epoisonEl_lam3(V self, V *args);
Clo g_heff_2eunify_2epoisonEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_entry, 5, 0};

V g_heff_2eunify_2epoisonEl(V v_w_240, V v_ms_241, V v_uf_242, V v_len_243, V v_v_244) {
top: ;
  V v_p_246 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonEl_lam0_clo)})}));
  V v_c_2412 = heff_clo(g_heff_2eunify_2epoisonEl_lam1, 2, 2, (V[]){heff_dup(v_w_240), v_p_246});
  return heff_clo(g_heff_2eunify_2epoisonEl_lam3, 2, 6, (V[]){v_c_2412, v_len_243, v_v_244, v_w_240, v_ms_241, heff_dup(v_uf_242)});
}
V g_heff_2eunify_2epoisonEl_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2epoisonEl(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eunify_2epoisonEl_lam0(V self, V *args) {
  V v_c_245 = args[0];
  return heff_get(v_c_245, LBL_metas);
}
V g_heff_2eunify_2epoisonEl_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_247), heff_get(v_hd_247, LBL_ret)});
}
V g_heff_2eunify_2epoisonEl_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2epoisonEl_lam2, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2410}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2411;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2epoisonEl_lam5(V self, V *args) {
  V v_c_2418 = args[0];
  V v_ms_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2419 = ({ V a_0 = heff_get(heff_dup(v_c_2418), LBL_poisoned); V a_1 = v_ms_2417; V r_ = (g_prelude_2efoldl_24s304(a_0, a_1)); heff_drop(v_ms_2417); r_; });
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2418), LBL_infos), heff_get(heff_dup(v_c_2418), LBL_recovered), v_ps_2419, heff_get(heff_dup(v_c_2418), LBL_metas), heff_get(heff_dup(v_c_2418), LBL_nextMeta), heff_get(heff_dup(v_c_2418), LBL_postponed), heff_get(heff_dup(v_c_2418), LBL_trace), heff_get(v_c_2418, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonEl_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = ({ V a_0 = v_x_2415; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_2415); r_; });
  V v_ms_2417 = heff_tr(heff_apply(heff_get(v_t_2416, LBL_mel), 3, (V[]){MK_INT(20LL), v_len_243, v_v_244}));
  V v_t_2420 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = heff_clo(g_heff_2eunify_2epoisonEl_lam5, 1, 1, (V[]){v_ms_2417}); V r_ = (g_heff_2eunify_2euModify(a_0, a_1, a_2, a_3)); heff_drop(v_uf_242); r_; });
  return heff_tail(v_t_2420, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2eunify_2epoisonEl_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  V v_v_244 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_ms_241 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2eunify_2epoisonEl_lam4, 1, 7, (V[]){v_len_243, v_v_244, v_w_240, v_ms_241, v_uf_242, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_245 = heff_intLt(heff_dup(v_i_244), heff_dup(v_d_242));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_d_242);
      return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    }
    case TAG_False: {
      V v_t_246 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      V v_t_248 = (g_heff_2eunify_2enth(v_idxs_241, v_t_247));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_242);
        return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
      }
      case TAG_Just: {
        V v_j_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        heff_drop(v_i_244);
        return heff_tag_at(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_249, v_d_242)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_SGlobal: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty_2411}));
    return heff_tag_at(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_t_243, 0);
    V v_a_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_f_2413}));
    V v_t_2416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_a_2414}));
    return heff_tag_at(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_dd_2417 = heff_field(v_t_243, 0);
    V v_it2_2418 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_it2_2418)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_it2_2418, 0);
      V v_b_2420 = heff_field(v_it2_2418, 1);
      heff_take_n(v_it2_2418, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2420}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2419, v_t_2422})});
    }
    case TAG_AbsConst: {
      V v_b_2423 = heff_field(v_it2_2418, 0);
      heff_take_n(v_it2_2418, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2425 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2423}));
      return heff_tag_at(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2425})});
    }
    default: return heff_nomatch(v_it2_2418);
    }
  }
  case TAG_SCons: {
    V v_dct_2426 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2427 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_xs_2428 = heff_get(heff_dup(v_dct_2426), LBL_values);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo(g_heff_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    V v_t_2432 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_dct_2426), LBL_keys), heff_get(v_dct_2426, LBL_byName), v_t_2431});
    return heff_tag_at(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2432});
  }
  case TAG_SProj: {
    V v_e_2433 = heff_field(v_t_243, 0);
    V v_l_2434 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2433}));
    return heff_tag_at(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2435, v_l_2434});
  }
  case TAG_STag: {
    V v_x_2436 = heff_field(v_t_243, 0);
    V v_as_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_d_242}));
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2437)), heff_clo(g_heff_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_as_2437, v_f_2438}));
    return heff_tag_at(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2436, v_t_2441});
  }
  case TAG_SMatch: {
    V v_e_2442 = heff_field(v_t_243, 0);
    V v_cs_2443 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2442}));
    V v_xs_2445 = heff_get(heff_dup(v_cs_2443), LBL_values);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2445)), heff_clo(g_heff_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2445, v_d_242, v_r_240}));
    V v_t_2453 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_cs_2443), LBL_keys), heff_get(v_cs_2443, LBL_byName), v_t_2452});
    return heff_tag_at(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e_2454 = heff_field(v_t_243, 0);
    V v_l_2455 = heff_field(v_t_243, 1);
    V v_v_2456 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 2, (V[]){heff_dup(v_d_242), v_e_2454}));
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_v_2456}));
    return heff_tag_at(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2461 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2462 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2461}));
    return heff_tag_at(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_dd_2463 = heff_field(v_t_243, 0);
    V v_it2_2464 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_it2_2464)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_it2_2464, 0);
      V v_b_2466 = heff_field(v_it2_2464, 1);
      heff_take_n(v_it2_2464, 3ULL, 2);
      V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2468 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2466}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2467, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2468})});
    }
    case TAG_AbsConst: {
      V v_b_2469 = heff_field(v_it2_2464, 0);
      heff_take_n(v_it2_2464, 1ULL, 1);
      V v_t_2470 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2471 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_b_2469}));
      return heff_tag_at(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2471})});
    }
    default: return heff_nomatch(v_it2_2464);
    }
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_t_243, 0);
    V v_e_2473 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_2473}));
    return heff_tag_at(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_t_243, 0);
    V v_ix_2477 = heff_field(v_t_243, 1);
    V v_ty_2478 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2486 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_ix_2477)), heff_clo(g_heff_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2477, heff_dup(v_d_242), heff_dup(v_idxs_241)}));
    V v_t_2487 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_ty_2478}));
    return heff_tag_at(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_t_2486, v_t_2487});
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstTermF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  V f_ = v_f_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2439 = args[0];
  V v_as_2437 = heff_env(self)[0];
  V v_f_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_as_2437, v_i_2439);
  V f_ = v_f_2438;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2448)));
    V v_t_2451 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_t_2450, v_b_2449}));
    return heff_tag_at(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2479 = args[0];
  V v_ix_2477 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_idxs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_i_2480 = heff_arrayIndex(v_ix_2477, v_i_2479);
  V v_t_2481 = heff_intLt(heff_dup(v_i_2480), heff_dup(v_d_242));
  switch (heff_tag_of(v_t_2481)) {
  case TAG_True: {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    return v_i_2480;
  }
  case TAG_False: {
    V v_t_2482 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_idxs_241));
    V v_t_2483 = heff_intSub(heff_intSub(v_t_2482, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2480), heff_dup(v_d_242)));
    V v_t_2484 = ({ V a_0 = v_idxs_241; V a_1 = v_t_2483; V r_ = (g_heff_2eunify_2enth(a_0, a_1)); heff_drop(v_idxs_241); r_; });
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      heff_drop(v_d_242);
      return v_i_2480;
    }
    case TAG_Just: {
      V v_j_2485 = heff_field(v_t_2484, 0);
      heff_take_n(v_t_2484, 1ULL, 1);
      heff_drop(v_i_2480);
      return heff_intAdd(v_j_2485, v_d_242);
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
  default: return heff_nomatch(v_t_2481);
  }
}
Clo g_heff_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    return heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eunify_2esubstTyFields(v_r_240, v_d_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245))});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eunify_2esubstTypeF_lam0(V self, V *args);
V g_heff_2eunify_2esubstTypeF_lam2(V self, V *args);
Clo g_heff_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_it3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 15ULL, 4);
    switch (heff_tag_of(v_it3_249)) {
    case TAG_MkAbs: {
      V v_x_2411 = heff_field(v_it3_249, 0);
      V v_b_2412 = heff_field(v_it3_249, 1);
      heff_take_n(v_it3_249, 3ULL, 2);
      V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2414 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2412}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 4, (V[]){v_level_247, v_t_2413, heff_tag(TAG_MkAbs, 2, (V[]){v_x_2411, v_t_2414}), v_implicit_2410});
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_it3_249, 0);
      heff_take_n(v_it3_249, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_b_2415}));
      return heff_tag_at(v_ru_24t_243_24SFunction, TAG_SFunction, 4, (V[]){v_level_247, v_t_2416, heff_tag(TAG_AbsConst, 1, (V[]){v_t_2417}), v_implicit_2410});
    }
    default: return heff_nomatch(v_it3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_t_243, 0);
    V v_ft_2419 = heff_field(v_t_243, 1);
    V v_ds_2420 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2421 = heff_arrayToList(heff_get(heff_dup(v_ft_2419), LBL_values));
    V v_t_2422 = (g_heff_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2421));
    V v_t_2423 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_ft_2419), LBL_keys), heff_get(v_ft_2419, LBL_byName), heff_arrayFromList(v_t_2422)});
    return heff_tag_at(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2418, v_t_2423, v_ds_2420});
  }
  case TAG_SSum: {
    V v_vs_2424 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2425 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_d_242}));
    V v_f_2429 = heff_clo(g_heff_2eunify_2esubstTypeF_lam0, 1, 1, (V[]){v_f_2425});
    V v_xs_2430 = heff_get(heff_dup(v_vs_2424), LBL_values);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo(g_heff_2eunify_2esubstTypeF_lam2, 1, 2, (V[]){v_xs_2430, v_f_2429}));
    V v_t_2434 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_vs_2424), LBL_keys), heff_get(v_vs_2424, LBL_byName), v_t_2433});
    return heff_tag_at(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2434});
  }
  case TAG_SIsTy: {
    V v_a_2435 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2436 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 2, (V[]){v_d_242, v_a_2435}));
    return heff_tag_at(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2436});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop(v_r_240);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstTypeF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2427 = args[0];
  V v_xs_2426 = heff_env(self)[0];
  V v_f_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_arrayIndex(v_xs_2426, v_i_2427);
  V f_ = v_f_2425;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_xs_2426 = args[0];
  V v_f_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2426)), heff_clo(g_heff_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2426, v_f_2425}));
}
V g_heff_2eunify_2esubstTypeF_lam2(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = v_f_2429;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec(2, shape_80_351, (V[]){heff_clo(g_heff_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo(g_heff_2eunify_2esubstOf_lam1, 2, 1, (V[]){heff_dup(v_idxs_240)})});
}
V g_heff_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esubstOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_243; V a_1 = v_idxs_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eunify_2esubstTermF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
Clo g_heff_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return v_t_241;
  }
  case TAG_False: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take_n(v_it2_249, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take_n(v_it2_249, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2estripLams(a[0], a[1]);
}
V g_heff_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_245}));
    return heff_tag_at(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_a_248}));
    return heff_tag_at(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get(v_r_240, LBL_el);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at(v_ru_24t_242_24SLam, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse_n(v_b_2412, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SLam, 2);
      V v_t_2419 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag(TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2422 = heff_get(heff_dup(v_d_2421), LBL_values);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo(g_heff_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2422, v_r_240}));
    V v_t_2426 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_d_2421), LBL_keys), heff_get(v_d_2421, LBL_byName), v_t_2425});
    return heff_tag_at(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e_2427 = heff_field(v_t_242, 0);
    V v_l_2428 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2427}));
    return heff_tag_at(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_x_2430 = heff_field(v_t_242, 0);
    V v_as_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2431)), heff_clo(g_heff_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_as_2431, v_r_240}));
    return heff_tag_at(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2430, v_t_2434});
  }
  case TAG_SMatch: {
    V v_e_2435 = heff_field(v_t_242, 0);
    V v_cs_2436 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_e_2435}));
    V v_xs_2438 = heff_get(heff_dup(v_cs_2436), LBL_values);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo(g_heff_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2438, v_r_240}));
    V v_t_2445 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_cs_2436), LBL_keys), heff_get(v_cs_2436, LBL_byName), v_t_2444});
    return heff_tag_at(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2437, v_t_2445});
  }
  case TAG_SSpecialize: {
    V v_e_2446 = heff_field(v_t_242, 0);
    V v_l_2447 = heff_field(v_t_242, 1);
    V v_v_2448 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){v_e_2446}));
    V v_t_2450 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_v_2448}));
    return heff_tag_at(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2449, v_l_2447, v_t_2450});
  }
  case TAG_SIs: {
    V v_e_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2451}));
    return heff_tag_at(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2452});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2453 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2454 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2453}));
    return heff_tag_at(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2454});
  }
  case TAG_SFix: {
    V v_d_2455 = heff_field(v_t_242, 0);
    V v_b_2456 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_d_2455}));
    V v_f_2458 = heff_get(v_r_240, LBL_el);
    V v_t_2464;
    switch (heff_tag_of(v_b_2456)) {
    case TAG_MkAbs: {
      V v_x_2459 = heff_field(v_b_2456, 0);
      V v_b_2460 = heff_field(v_b_2456, 1);
      heff_take_n(v_b_2456, 3ULL, 2);
      V v_t_2461 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2460}));
      v_t_2464 = heff_tag_at(v_ru_24t_242_24SFix, TAG_MkAbs, 2, (V[]){v_x_2459, v_t_2461});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2462 = heff_field(v_b_2456, 0);
      V v_ru_24b_2456_24AbsConst = heff_take_reuse_n(v_b_2456, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SFix, 2);
      V v_t_2463 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2462}));
      v_t_2464 = heff_tag_at(v_ru_24b_2456_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2463});
      break;
    }
    default: heff_nomatch(v_b_2456);
    }
    return heff_tag(TAG_SFix, 2, (V[]){v_t_2457, v_t_2464});
  }
  case TAG_SImplicit: {
    V v_x_2465 = heff_field(v_t_242, 0);
    V v_e_2466 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_2466}));
    return heff_tag_at(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2465, v_t_2467});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2469 = heff_field(v_t_242, 0);
    V v_idxs_2470 = heff_field(v_t_242, 1);
    V v_ty_2471 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2472 = (g_map_2elookup_24s12(heff_dup(v_m_2469), v_mc_241));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_Nothing: {
      V v_t_2473 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_2471}));
      return heff_tag_at(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2473});
    }
    case TAG_Just: {
      V v_e_2474 = heff_field(v_t_2472, 0);
      heff_take_n(v_t_2472, 1ULL, 1);
      V v_t_2475 = heff_get(v_e_2474, LBL_solStx);
      switch (heff_tag_of(v_t_2475)) {
      case TAG_Nothing: {
        V v_t_2476 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_ty_2471}));
        return heff_tag_at(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2476});
      }
      case TAG_Just: {
        V v_sol_2477 = heff_field(v_t_2475, 0);
        heff_take_n(v_t_2475, 1ULL, 1);
        heff_drop(v_m_2469);
        heff_drop(v_ty_2471);
        heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
        V v_idxs_2478 = heff_arrayToList(v_idxs_2470);
        V v_t_2479 = (g_heff_2eunify_2esubstOf(v_idxs_2478));
        V v_t_2480 = ({ V a_0 = MK_INT(0LL); V a_1 = v_idxs_2478; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_idxs_2478); r_; });
        V v_t_2481 = (g_heff_2eunify_2estripLams(v_t_2480, v_sol_2477));
        V v_t_2482 = heff_tr(heff_apply(heff_get(v_t_2479, LBL_el), 2, (V[]){MK_INT(0LL), v_t_2481}));
        return heff_tail(heff_get(v_r_240, LBL_el), 1, (V[]){v_t_2482});
      }
      default: return heff_nomatch(v_t_2475);
      }
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonkTermF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get(v_r_240, LBL_el);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_as_2431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_as_2431, v_i_2432);
  V f_ = heff_get(v_r_240, LBL_el);
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_xs_2441 = heff_field(v_p_2440, 0);
    V v_b_2442 = heff_field(v_p_2440, 1);
    V v_ru_24p_2440_24MkPair = heff_take_reuse_n(v_p_2440, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_b_2442}));
    return heff_tag_at(v_ru_24p_2440_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_p_2440);
  }
}
V g_heff_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){v_e_244}));
    return heff_tag_at(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 15ULL, 4);
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){v_dom_247}));
    V v_f_2411 = heff_get(v_r_240, LBL_ty);
    V v_t_2417;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_cod_248, 0);
      V v_b_2413 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_apply(v_f_2411, 1, (V[]){v_b_2413}));
      v_t_2417 = heff_tag_at(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2414});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2415 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_apply(v_f_2411, 1, (V[]){v_b_2415}));
      v_t_2417 = heff_tag_at(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    return heff_tag_at(v_ru_24t_242_24SFunction, TAG_SFunction, 4, (V[]){v_level_246, v_t_2410, v_t_2417, v_implicit_249});
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_t_242, 0);
    V v_ft_2419 = heff_field(v_t_242, 1);
    V v_ds_2420 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2421 = heff_get(heff_dup(v_ft_2419), LBL_values);
    V v_t_2424 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2421)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2421, heff_dup(v_r_240)}));
    V v_t_2425 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_ft_2419), LBL_keys), heff_get(v_ft_2419, LBL_byName), v_t_2424});
    V v_xs_2426 = heff_get(heff_dup(v_ds_2420), LBL_values);
    V v_t_2429 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2426)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2426, v_r_240}));
    V v_t_2430 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_ds_2420), LBL_keys), heff_get(v_ds_2420, LBL_byName), v_t_2429});
    return heff_tag_at(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2418, v_t_2425, v_t_2430});
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2432 = heff_get(heff_dup(v_vs_2431), LBL_values);
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2432)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2432, v_r_240}));
    V v_t_2438 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_vs_2431), LBL_keys), heff_get(v_vs_2431, LBL_byName), v_t_2437});
    return heff_tag_at(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2438});
  }
  case TAG_SIsTy: {
    V v_a_2439 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){v_a_2439}));
    return heff_tag_at(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2440});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop(v_r_240);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonkTypeF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2422 = args[0];
  V v_xs_2421 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_arrayIndex(v_xs_2421, v_i_2422);
  V f_ = heff_get(v_r_240, LBL_ty);
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2427 = args[0];
  V v_xs_2426 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_arrayIndex(v_xs_2426, v_i_2427);
  V f_ = heff_get(v_r_240, LBL_el);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2435 = args[0];
  V v_xs_2434 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_arrayIndex(v_xs_2434, v_i_2435);
  V f_ = heff_get(v_r_240, LBL_ty);
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2434)), heff_clo(g_heff_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2434, v_r_240}));
}
V g_heff_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec(2, shape_80_351, (V[]){heff_clo(g_heff_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo(g_heff_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2ezonker(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
Clo g_heff_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_i_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_240);
    return v_rr_241;
  }
  case TAG_False: {
    V v_t_243 = heff_intAdd(heff_get(heff_dup(v_rr_241), LBL_dom), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_get(heff_dup(v_rr_241), LBL_cod), MK_INT(1LL));
    V v_t_245 = (g_map_2einsert_24s194(heff_get(heff_dup(v_rr_241), LBL_dom), heff_get(heff_dup(v_rr_241), LBL_cod), heff_get(v_rr_241, LBL_ren)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_rec(3, shape_70_46_267, (V[]){v_t_243, v_t_244, v_t_245});
    v_i_240 = t_0;
    v_rr_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eiterateLift(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2elamsU_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_k_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_k_240);
    return v_body_241;
  }
  case TAG_False: {
    V v_t_243 = heff_tag(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_244 = heff_tag(TAG_SLam, 2, (V[]){v_t_243, heff_tag(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_244;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = heff_rec(6, shape_351_308_309_14_198_314, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_arity_241, heff_get(heff_dup(v_entry_240), LBL_name), heff_get(v_entry_240, LBL_span)});
  V v_mc_245 = (g_map_2einsert_24s194(heff_get(heff_dup(v_c_243), LBL_nextMeta), v_t_244, heff_get(heff_dup(v_c_243), LBL_metas)));
  V v_t_246 = heff_intAdd(heff_get(heff_dup(v_c_243), LBL_nextMeta), MK_INT(1LL));
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_243), LBL_infos), heff_get(heff_dup(v_c_243), LBL_recovered), heff_get(heff_dup(v_c_243), LBL_poisoned), v_mc_245, v_t_246, heff_get(heff_dup(v_c_243), LBL_postponed), heff_get(heff_dup(v_c_243), LBL_trace), heff_get(v_c_243, LBL_selfKey)});
}
V g_heff_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eunify_2emapWithIndexL_24s387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_24s387_entry, 2, 0};

V g_heff_2eunify_2emapWithIndexL_24s387(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a1_244 = heff_field(v_x_242, 0);
      V v_a2_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_a1_244)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_a1_244, 0);
        heff_take_n(v_a1_244, 1ULL, 1);
        switch (heff_tag_of(v_a2_245)) {
        case TAG_PVar: {
          V v_l_27_247 = heff_field(v_a2_245, 0);
          heff_take_n(v_a2_245, 1ULL, 1);
          v_t_249 = heff_intEq(v_l_246, v_l_27_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_l_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a2_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a2_245)) {
        case TAG_PVar: {
          heff_take_n(v_a2_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a2_245);
        }
        break;
      }
      default: heff_nomatch(v_a1_244);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eunify_2emapWithIndexL_24s387(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eunify_2emapWithIndexL_24s387_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL_24s387(a[0], a[1]);
}
Clo g_heff_2eunify_2emapWithIndexL_24s390_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emapWithIndexL_24s390_entry, 2, 0};

V g_heff_2eunify_2emapWithIndexL_24s390(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), (g_heff_2eunify_2emapWithIndexL_24s390(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eunify_2emapWithIndexL_24s390_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emapWithIndexL_24s390(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2euTyRigid_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eunify_2euTyRigid_lam0(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam0, 2, 0};
V g_heff_2eunify_2euTyRigid_lam2(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam1(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam4(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam3(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam6(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam5(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam8(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam7(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam10(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam9(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam12(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam11(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam14(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam13(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam16(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam15(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam18(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam17(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam20(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam19(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam22(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam21(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam24(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam23(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam26(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam25(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam28(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam27(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam30(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam29(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam32(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam31(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam34(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam33(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam36(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam35(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam38(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam37(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam41(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam42(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam43(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam40(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam39(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam45(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam44(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam47(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam46(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam49(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam48(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam51(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam50(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam53(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam52(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam55(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam54(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam57(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam56(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam59(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam58(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam61(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam60(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam63(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam62(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam65(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam64(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam67(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam66(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam69(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam68(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam71(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam70(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam72(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam72, 2, 0};
V g_heff_2eunify_2euTyRigid_lam74(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam73(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam76(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam75(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam78(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam77(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam80(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam79(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam82(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam81(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam84(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam83(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam86(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam85(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam88(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam87(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam90(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam89(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam91(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam91, 2, 0};
V g_heff_2eunify_2euTyRigid_lam93(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam92(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam95(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam94(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam97(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam96(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam99(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam98(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam101(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam100(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam103(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam102(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam105(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam104(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam107(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam106(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam109(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam108(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam110(V self, V *args); static Clo g_heff_2eunify_2euTyRigid_lam110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_lam110, 2, 0};
V g_heff_2eunify_2euTyRigid_lam112(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam111(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam114(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam113(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam116(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam115(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam118(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam117(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam120(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam119(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam122(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam121(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam124(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam123(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam126(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam125(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam128(V self, V *args);
V g_heff_2eunify_2euTyRigid_lam127(V self, V *args);
Clo g_heff_2eunify_2euTyRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTyRigid_entry, 8, 0};

V g_heff_2eunify_2euTyRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a_246, V v_b_247) {
top: ;
  switch (heff_tag_of(v_a_246)) {
  case TAG_VU: {
    V v_u_248 = heff_dup(heff_field(v_a_246, 0));
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_u_27_249 = heff_dup(heff_field(v_b_247, 0));
      V v_t_2410;
      switch (heff_tag_of(v_u_248)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_249)) {
        case TAG_SmallU: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        case TAG_LargeU: {
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_u_27_249);
        }
        break;
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_249)) {
        case TAG_SmallU: {
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_LargeU: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_u_27_249);
        }
        break;
      }
      default: heff_nomatch(v_u_248);
      }
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_w_240);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop_tag(v_a_246, 1);
        heff_drop_tag(v_b_247, 1);
        return ((V)&g_heff_2eunify_2euTyRigid_lam0_clo);
      }
      case TAG_False: {
        V v_t_2413 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
        V v_p_2414 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2413}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam1, 2, 2, (V[]){v_w_240, v_p_2414});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_248);
      V v_t_2425 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2426 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2425}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam3, 2, 2, (V[]){v_w_240, v_p_2426});
    }
    case TAG_VFunction: {
      heff_drop(v_u_248);
      V v_t_2436 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2437 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2436}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam5, 2, 2, (V[]){v_w_240, v_p_2437});
    }
    case TAG_VRecord: {
      heff_drop(v_u_248);
      V v_t_2447 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2448 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2447}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam7, 2, 2, (V[]){v_w_240, v_p_2448});
    }
    case TAG_VSum: {
      heff_drop(v_u_248);
      V v_t_2455 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2456 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2455}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam9, 2, 2, (V[]){v_w_240, v_p_2456});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_248);
      V v_t_2462 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2463 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2462}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam11, 2, 2, (V[]){v_w_240, v_p_2463});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_248);
      V v_t_2469 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2470 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2469}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam13, 2, 2, (V[]){v_w_240, v_p_2470});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_248);
      V v_t_2476 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2477 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2476}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam15, 2, 2, (V[]){v_w_240, v_p_2477});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_248);
      V v_t_2484 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2485 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2484}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam17, 2, 2, (V[]){v_w_240, v_p_2485});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VDecode: {
    V v_h_2491 = heff_dup(heff_field(v_a_246, 0));
    V v_sp_2492 = heff_dup(heff_field(v_a_246, 1));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_2497 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_2498 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2497}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam19, 2, 2, (V[]){v_w_240, v_p_2498});
    }
    case TAG_VDecode: {
      V v_h_27_24104 = heff_field(v_b_247, 0);
      V v_sp_27_24105 = heff_field(v_b_247, 1);
      heff_take_n(v_b_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop_tag(v_a_246, 5);
      return heff_tail(heff_get(v_r_243, LBL_ubare), 6, (V[]){v_g_244, v_cs_245, v_h_2491, v_sp_2492, v_h_27_24104, v_sp_27_24105});
    }
    case TAG_VFunction: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24113 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24114 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24113}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam21, 2, 2, (V[]){v_w_240, v_p_24114});
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24124 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24125 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24124}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam23, 2, 2, (V[]){v_w_240, v_p_24125});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24132 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24133 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24132}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam25, 2, 2, (V[]){v_w_240, v_p_24133});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24139 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24140 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24139}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam27, 2, 2, (V[]){v_w_240, v_p_24140});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24146 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24147 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24146}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam29, 2, 2, (V[]){v_w_240, v_p_24147});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24153 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24154 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24153}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam31, 2, 2, (V[]){v_w_240, v_p_24154});
    }
    case TAG_VPrimArray: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2491);
      heff_drop(v_sp_2492);
      V v_t_24161 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24162 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24161}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam33, 2, 2, (V[]){v_w_240, v_p_24162});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VFunction: {
    V v_level_24168 = heff_dup(heff_field(v_a_246, 0));
    V v_dom_24169 = heff_dup(heff_field(v_a_246, 1));
    V v_cod_24170 = heff_dup(heff_field(v_a_246, 2));
    V v_implicit_24171 = heff_dup(heff_field(v_a_246, 3));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24173 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24174 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24173}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam35, 2, 2, (V[]){v_w_240, v_p_24174});
    }
    case TAG_VDecode: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24185 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24186 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24185}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam37, 2, 2, (V[]){v_w_240, v_p_24186});
    }
    case TAG_VFunction: {
      V v_level_27_24192 = heff_dup(heff_field(v_b_247, 0));
      V v_dom_27_24193 = heff_dup(heff_field(v_b_247, 1));
      V v_cod_27_24194 = heff_dup(heff_field(v_b_247, 2));
      V v_implicit_27_24195 = heff_dup(heff_field(v_b_247, 3));
      V v_t_24196 = ({ V a_0 = v_level_24168; V a_1 = v_level_27_24192; V r_ = (g_heff_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_24168); heff_drop(v_level_27_24192); r_; });
      V v_t_24197;
      switch (heff_tag_of(v_t_24196)) {
      case TAG_True: {
        switch (heff_tag_of(v_implicit_24171)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24195)) {
          case TAG_Expl: {
            v_t_24197 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24197 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24197 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24195);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24195)) {
          case TAG_Expl: {
            v_t_24197 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24197 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24197 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24195);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24195)) {
          case TAG_Expl: {
            v_t_24197 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24197 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24197 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24195);
          }
          break;
        }
        default: heff_nomatch(v_implicit_24171);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_implicit_24171);
        heff_drop(v_implicit_27_24195);
        v_t_24197 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24196);
      }
      switch (heff_tag_of(v_t_24197)) {
      case TAG_True: {
        heff_drop(v_w_240);
        heff_drop(v_uf_242);
        heff_drop_tag(v_a_246, 4);
        heff_drop_tag(v_b_247, 4);
        V v_c_24198 = heff_tr(heff_apply(heff_get(heff_dup(v_r_243), LBL_uty), 4, (V[]){heff_dup(v_g_244), heff_dup(v_cs_245), heff_dup(v_dom_24169), v_dom_27_24193}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam39, 2, 7, (V[]){v_c_24198, v_cs_245, v_dom_24169, v_cod_24170, v_cod_27_24194, v_r_243, v_g_244});
      }
      case TAG_False: {
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        heff_drop(v_dom_24169);
        heff_drop(v_cod_24170);
        heff_drop(v_dom_27_24193);
        heff_drop(v_cod_27_24194);
        V v_t_24232 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
        V v_p_24233 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24232}));
        return heff_clo(g_heff_2eunify_2euTyRigid_lam44, 2, 2, (V[]){v_w_240, v_p_24233});
      }
      default: return heff_nomatch(v_t_24197);
      }
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24243 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24244 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24243}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam46, 2, 2, (V[]){v_w_240, v_p_24244});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24251 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24252 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24251}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam48, 2, 2, (V[]){v_w_240, v_p_24252});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24258 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24259 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24258}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam50, 2, 2, (V[]){v_w_240, v_p_24259});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24265 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24266 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24265}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam52, 2, 2, (V[]){v_w_240, v_p_24266});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24272 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24273 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24272}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam54, 2, 2, (V[]){v_w_240, v_p_24273});
    }
    case TAG_VPrimArray: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_level_24168);
      heff_drop(v_dom_24169);
      heff_drop(v_cod_24170);
      heff_drop(v_implicit_24171);
      V v_t_24280 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24281 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24280}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam56, 2, 2, (V[]){v_w_240, v_p_24281});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24291 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
    V v_p_24292 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24291}));
    return heff_clo(g_heff_2eunify_2euTyRigid_lam58, 2, 2, (V[]){v_w_240, v_p_24292});
  }
  case TAG_VSum: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_t_24299 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
    V v_p_24300 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24299}));
    return heff_clo(g_heff_2eunify_2euTyRigid_lam60, 2, 2, (V[]){v_w_240, v_p_24300});
  }
  case TAG_VPrimInt: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24307 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24308 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24307}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam62, 2, 2, (V[]){v_w_240, v_p_24308});
    }
    case TAG_VDecode: {
      V v_t_24319 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24320 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24319}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam64, 2, 2, (V[]){v_w_240, v_p_24320});
    }
    case TAG_VFunction: {
      V v_t_24330 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24331 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24330}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam66, 2, 2, (V[]){v_w_240, v_p_24331});
    }
    case TAG_VRecord: {
      V v_t_24341 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24342 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24341}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam68, 2, 2, (V[]){v_w_240, v_p_24342});
    }
    case TAG_VSum: {
      V v_t_24349 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24350 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24349}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam70, 2, 2, (V[]){v_w_240, v_p_24350});
    }
    case TAG_VPrimInt: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      return ((V)&g_heff_2eunify_2euTyRigid_lam72_clo);
    }
    case TAG_VPrimFloat: {
      V v_t_24358 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24359 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24358}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam73, 2, 2, (V[]){v_w_240, v_p_24359});
    }
    case TAG_VPrimString: {
      V v_t_24365 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24366 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24365}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam75, 2, 2, (V[]){v_w_240, v_p_24366});
    }
    case TAG_VPrimArray: {
      V v_t_24373 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24374 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24373}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam77, 2, 2, (V[]){v_w_240, v_p_24374});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24381 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24382 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24381}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam79, 2, 2, (V[]){v_w_240, v_p_24382});
    }
    case TAG_VDecode: {
      V v_t_24393 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24394 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24393}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam81, 2, 2, (V[]){v_w_240, v_p_24394});
    }
    case TAG_VFunction: {
      V v_t_24404 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24405 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24404}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam83, 2, 2, (V[]){v_w_240, v_p_24405});
    }
    case TAG_VRecord: {
      V v_t_24415 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24416 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24415}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam85, 2, 2, (V[]){v_w_240, v_p_24416});
    }
    case TAG_VSum: {
      V v_t_24423 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24424 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24423}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam87, 2, 2, (V[]){v_w_240, v_p_24424});
    }
    case TAG_VPrimInt: {
      V v_t_24430 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24431 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24430}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam89, 2, 2, (V[]){v_w_240, v_p_24431});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      return ((V)&g_heff_2eunify_2euTyRigid_lam91_clo);
    }
    case TAG_VPrimString: {
      V v_t_24439 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24440 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24439}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam92, 2, 2, (V[]){v_w_240, v_p_24440});
    }
    case TAG_VPrimArray: {
      V v_t_24447 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24448 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24447}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam94, 2, 2, (V[]){v_w_240, v_p_24448});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      V v_t_24455 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24456 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24455}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam96, 2, 2, (V[]){v_w_240, v_p_24456});
    }
    case TAG_VDecode: {
      V v_t_24467 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24468 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24467}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam98, 2, 2, (V[]){v_w_240, v_p_24468});
    }
    case TAG_VFunction: {
      V v_t_24478 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24479 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24478}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam100, 2, 2, (V[]){v_w_240, v_p_24479});
    }
    case TAG_VRecord: {
      V v_t_24489 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24490 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24489}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam102, 2, 2, (V[]){v_w_240, v_p_24490});
    }
    case TAG_VSum: {
      V v_t_24497 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24498 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24497}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam104, 2, 2, (V[]){v_w_240, v_p_24498});
    }
    case TAG_VPrimInt: {
      V v_t_24504 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24505 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24504}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam106, 2, 2, (V[]){v_w_240, v_p_24505});
    }
    case TAG_VPrimFloat: {
      V v_t_24511 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24512 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24511}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam108, 2, 2, (V[]){v_w_240, v_p_24512});
    }
    case TAG_VPrimString: {
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      return ((V)&g_heff_2eunify_2euTyRigid_lam110_clo);
    }
    case TAG_VPrimArray: {
      V v_t_24521 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24522 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24521}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam111, 2, 2, (V[]){v_w_240, v_p_24522});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  case TAG_VPrimArray: {
    V v_x_24528 = heff_dup(heff_field(v_a_246, 0));
    switch (heff_tag_of(v_b_247)) {
    case TAG_VU: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24530 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24531 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24530}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam113, 2, 2, (V[]){v_w_240, v_p_24531});
    }
    case TAG_VDecode: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24542 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24543 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24542}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam115, 2, 2, (V[]){v_w_240, v_p_24543});
    }
    case TAG_VFunction: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24553 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24554 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24553}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam117, 2, 2, (V[]){v_w_240, v_p_24554});
    }
    case TAG_VRecord: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24564 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24565 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24564}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam119, 2, 2, (V[]){v_w_240, v_p_24565});
    }
    case TAG_VSum: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24572 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24573 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24572}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam121, 2, 2, (V[]){v_w_240, v_p_24573});
    }
    case TAG_VPrimInt: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24579 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24580 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24579}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam123, 2, 2, (V[]){v_w_240, v_p_24580});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24586 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24587 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24586}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam125, 2, 2, (V[]){v_w_240, v_p_24587});
    }
    case TAG_VPrimString: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_x_24528);
      V v_t_24593 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalTys, 3, (V[]){v_cs_245, v_a_246, v_b_247})});
      V v_p_24594 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24593}));
      return heff_clo(g_heff_2eunify_2euTyRigid_lam127, 2, 2, (V[]){v_w_240, v_p_24594});
    }
    case TAG_VPrimArray: {
      V v_y_24600 = heff_field(v_b_247, 0);
      heff_take_n(v_b_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop_tag(v_a_246, 1);
      return heff_tail(heff_get(v_r_243, LBL_uty), 4, (V[]){v_g_244, v_cs_245, v_x_24528, v_y_24600});
    }
    default: return heff_nomatch(v_b_247);
    }
  }
  default: return heff_nomatch(v_a_246);
  }
}
V g_heff_2eunify_2euTyRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euTyRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2euTyRigid_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam2(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2415), heff_get(v_hd_2415, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam2, 1, 1, (V[]){heff_dup(v_hd_2415)}), v_p_2414}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam4(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_2427), heff_get(v_hd_2427, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam4, 1, 1, (V[]){heff_dup(v_hd_2427)}), v_p_2426}));
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2427), LBL_malg), 1, (V[]){v_t_2430}));
  V f_ = heff_get(v_hd_2427, LBL_bind);
  args[0] = v_t_2431;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam6(V self, V *args) {
  V v_c_2440 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2440, 2, (V[]){heff_dup(v_hd_2438), heff_get(v_hd_2438, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam5(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam6, 1, 1, (V[]){heff_dup(v_hd_2438)}), v_p_2437}));
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2441}));
  V f_ = heff_get(v_hd_2438, LBL_bind);
  args[0] = v_t_2442;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam8(V self, V *args) {
  V v_c_2451 = args[0];
  V v_hd_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2451, 2, (V[]){heff_dup(v_hd_2449), heff_get(v_hd_2449, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam7(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam8, 1, 1, (V[]){heff_dup(v_hd_2449)}), v_p_2448}));
  V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2449), LBL_malg), 1, (V[]){v_t_2452}));
  V f_ = heff_get(v_hd_2449, LBL_bind);
  args[0] = v_t_2453;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam10(V self, V *args) {
  V v_c_2459 = args[0];
  V v_hd_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_2457), heff_get(v_hd_2457, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam9(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam10, 1, 1, (V[]){heff_dup(v_hd_2457)}), v_p_2456}));
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2457), LBL_malg), 1, (V[]){v_t_2460}));
  V f_ = heff_get(v_hd_2457, LBL_bind);
  args[0] = v_t_2461;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam12(V self, V *args) {
  V v_c_2466 = args[0];
  V v_hd_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2466, 2, (V[]){heff_dup(v_hd_2464), heff_get(v_hd_2464, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam11(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam12, 1, 1, (V[]){heff_dup(v_hd_2464)}), v_p_2463}));
  V v_t_2468 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2464), LBL_malg), 1, (V[]){v_t_2467}));
  V f_ = heff_get(v_hd_2464, LBL_bind);
  args[0] = v_t_2468;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam14(V self, V *args) {
  V v_c_2473 = args[0];
  V v_hd_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2473, 2, (V[]){heff_dup(v_hd_2471), heff_get(v_hd_2471, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam13(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k2_2472 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2470 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2474 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam14, 1, 1, (V[]){heff_dup(v_hd_2471)}), v_p_2470}));
  V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2471), LBL_malg), 1, (V[]){v_t_2474}));
  V f_ = heff_get(v_hd_2471, LBL_bind);
  args[0] = v_t_2475;
  args[1] = v_k2_2472;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam16(V self, V *args) {
  V v_c_2480 = args[0];
  V v_hd_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2480, 2, (V[]){heff_dup(v_hd_2478), heff_get(v_hd_2478, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam15(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam16, 1, 1, (V[]){heff_dup(v_hd_2478)}), v_p_2477}));
  V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2478), LBL_malg), 1, (V[]){v_t_2481}));
  V f_ = heff_get(v_hd_2478, LBL_bind);
  args[0] = v_t_2482;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam18(V self, V *args) {
  V v_c_2488 = args[0];
  V v_hd_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2488, 2, (V[]){heff_dup(v_hd_2486), heff_get(v_hd_2486, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam17(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k2_2487 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2489 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam18, 1, 1, (V[]){heff_dup(v_hd_2486)}), v_p_2485}));
  V v_t_2490 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2486), LBL_malg), 1, (V[]){v_t_2489}));
  V f_ = heff_get(v_hd_2486, LBL_bind);
  args[0] = v_t_2490;
  args[1] = v_k2_2487;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam20(V self, V *args) {
  V v_c_24101 = args[0];
  V v_hd_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_2499), heff_get(v_hd_2499, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam19(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k2_24100 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24102 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam20, 1, 1, (V[]){heff_dup(v_hd_2499)}), v_p_2498}));
  V v_t_24103 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2499), LBL_malg), 1, (V[]){v_t_24102}));
  V f_ = heff_get(v_hd_2499, LBL_bind);
  args[0] = v_t_24103;
  args[1] = v_k2_24100;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam22(V self, V *args) {
  V v_c_24117 = args[0];
  V v_hd_24115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24117, 2, (V[]){heff_dup(v_hd_24115), heff_get(v_hd_24115, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam21(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k2_24116 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24114 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24118 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam22, 1, 1, (V[]){heff_dup(v_hd_24115)}), v_p_24114}));
  V v_t_24119 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24115), LBL_malg), 1, (V[]){v_t_24118}));
  V f_ = heff_get(v_hd_24115, LBL_bind);
  args[0] = v_t_24119;
  args[1] = v_k2_24116;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam24(V self, V *args) {
  V v_c_24128 = args[0];
  V v_hd_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24128, 2, (V[]){heff_dup(v_hd_24126), heff_get(v_hd_24126, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam23(V self, V *args) {
  V v_hd_24126 = args[0];
  V v_k2_24127 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24125 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24129 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam24, 1, 1, (V[]){heff_dup(v_hd_24126)}), v_p_24125}));
  V v_t_24130 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24126), LBL_malg), 1, (V[]){v_t_24129}));
  V f_ = heff_get(v_hd_24126, LBL_bind);
  args[0] = v_t_24130;
  args[1] = v_k2_24127;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam26(V self, V *args) {
  V v_c_24136 = args[0];
  V v_hd_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24136, 2, (V[]){heff_dup(v_hd_24134), heff_get(v_hd_24134, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam25(V self, V *args) {
  V v_hd_24134 = args[0];
  V v_k2_24135 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24133 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24137 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam26, 1, 1, (V[]){heff_dup(v_hd_24134)}), v_p_24133}));
  V v_t_24138 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24134), LBL_malg), 1, (V[]){v_t_24137}));
  V f_ = heff_get(v_hd_24134, LBL_bind);
  args[0] = v_t_24138;
  args[1] = v_k2_24135;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam28(V self, V *args) {
  V v_c_24143 = args[0];
  V v_hd_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24143, 2, (V[]){heff_dup(v_hd_24141), heff_get(v_hd_24141, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam27(V self, V *args) {
  V v_hd_24141 = args[0];
  V v_k2_24142 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24140 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24144 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam28, 1, 1, (V[]){heff_dup(v_hd_24141)}), v_p_24140}));
  V v_t_24145 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24141), LBL_malg), 1, (V[]){v_t_24144}));
  V f_ = heff_get(v_hd_24141, LBL_bind);
  args[0] = v_t_24145;
  args[1] = v_k2_24142;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam30(V self, V *args) {
  V v_c_24150 = args[0];
  V v_hd_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24150, 2, (V[]){heff_dup(v_hd_24148), heff_get(v_hd_24148, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam29(V self, V *args) {
  V v_hd_24148 = args[0];
  V v_k2_24149 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24147 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24151 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam30, 1, 1, (V[]){heff_dup(v_hd_24148)}), v_p_24147}));
  V v_t_24152 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24148), LBL_malg), 1, (V[]){v_t_24151}));
  V f_ = heff_get(v_hd_24148, LBL_bind);
  args[0] = v_t_24152;
  args[1] = v_k2_24149;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam32(V self, V *args) {
  V v_c_24157 = args[0];
  V v_hd_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24157, 2, (V[]){heff_dup(v_hd_24155), heff_get(v_hd_24155, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam31(V self, V *args) {
  V v_hd_24155 = args[0];
  V v_k2_24156 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24158 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam32, 1, 1, (V[]){heff_dup(v_hd_24155)}), v_p_24154}));
  V v_t_24159 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24155), LBL_malg), 1, (V[]){v_t_24158}));
  V f_ = heff_get(v_hd_24155, LBL_bind);
  args[0] = v_t_24159;
  args[1] = v_k2_24156;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam34(V self, V *args) {
  V v_c_24165 = args[0];
  V v_hd_24163 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24165, 2, (V[]){heff_dup(v_hd_24163), heff_get(v_hd_24163, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam33(V self, V *args) {
  V v_hd_24163 = args[0];
  V v_k2_24164 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24162 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24166 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam34, 1, 1, (V[]){heff_dup(v_hd_24163)}), v_p_24162}));
  V v_t_24167 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24163), LBL_malg), 1, (V[]){v_t_24166}));
  V f_ = heff_get(v_hd_24163, LBL_bind);
  args[0] = v_t_24167;
  args[1] = v_k2_24164;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam36(V self, V *args) {
  V v_c_24177 = args[0];
  V v_hd_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24177, 2, (V[]){heff_dup(v_hd_24175), heff_get(v_hd_24175, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam35(V self, V *args) {
  V v_hd_24175 = args[0];
  V v_k2_24176 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24174 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24178 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam36, 1, 1, (V[]){heff_dup(v_hd_24175)}), v_p_24174}));
  V v_t_24179 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24175), LBL_malg), 1, (V[]){v_t_24178}));
  V f_ = heff_get(v_hd_24175, LBL_bind);
  args[0] = v_t_24179;
  args[1] = v_k2_24176;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam38(V self, V *args) {
  V v_c_24189 = args[0];
  V v_hd_24187 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24189, 2, (V[]){heff_dup(v_hd_24187), heff_get(v_hd_24187, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam37(V self, V *args) {
  V v_hd_24187 = args[0];
  V v_k2_24188 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24186 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24190 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam38, 1, 1, (V[]){heff_dup(v_hd_24187)}), v_p_24186}));
  V v_t_24191 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24187), LBL_malg), 1, (V[]){v_t_24190}));
  V f_ = heff_get(v_hd_24187, LBL_bind);
  args[0] = v_t_24191;
  args[1] = v_k2_24188;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam41(V self, V *args) {
  V v_u_24203 = args[0];
  V v_dom_24169 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24203);
  return v_dom_24169;
}
V g_heff_2eunify_2euTyRigid_lam42(V self, V *args) {
  V v_w_24215 = args[0];
  V v_v_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24215);
  return v_v_24204;
}
V g_heff_2eunify_2euTyRigid_lam43(V self, V *args) {
  V v_w_24225 = args[0];
  V v_v_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24225);
  return v_v_24204;
}
V g_heff_2eunify_2euTyRigid_lam40(V self, V *args) {
  V v_x_24201 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_dom_24169 = heff_env(self)[1];
  V v_cod_24170 = heff_env(self)[2];
  V v_cod_27_24194 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_hd_24199 = heff_env(self)[6];
  V v_k_24200 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_24201);
  V v_t_24202 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_cs_245), LBL_len)});
  V v_v_24204 = (g_heff_2evalue_2emkNeu_24s10(v_t_24202, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2euTyRigid_lam41, 1, 1, (V[]){v_dom_24169}), NTAG(TAG_Nothing)));
  V v_x_24209;
  switch (heff_tag_of(v_cod_24170)) {
  case TAG_MkClo: {
    V v_n_24205 = heff_dup(heff_field(v_cod_24170, 0));
    v_x_24209 = v_n_24205;
    break;
  }
  case TAG_CloConst: {
    v_x_24209 = ((V)&g_heff_2eunify_2euTyRigid_str0);
    break;
  }
  default: heff_nomatch(v_cod_24170);
  }
  V v_t_24210 = heff_intAdd(heff_get(heff_dup(v_cs_245), LBL_len), MK_INT(1LL));
  V v_t_24211 = heff_tag(TAG_Cons, 2, (V[]){v_x_24209, heff_get(v_cs_245, LBL_names)});
  V v_x1_24217;
  switch (heff_tag_of(v_cod_24170)) {
  case TAG_MkClo: {
    V v_vs_24213 = heff_field(v_cod_24170, 1);
    V v_body_24214 = heff_field(v_cod_24170, 2);
    heff_take_n(v_cod_24170, 6ULL, 3);
    v_x1_24217 = heff_tr(heff_apply(v_body_24214, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24213, heff_clo(g_heff_2eunify_2euTyRigid_lam42, 1, 1, (V[]){heff_dup(v_v_24204)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24216 = heff_field(v_cod_24170, 0);
    heff_take_n(v_cod_24170, 1ULL, 1);
    v_x1_24217 = v_body_24216;
    break;
  }
  default: heff_nomatch(v_cod_24170);
  }
  V v_t_24221;
  switch (heff_tag_of(v_x1_24217)) {
  case TAG_Nom: {
    V v_x_24218 = heff_field(v_x1_24217, 0);
    heff_take_n(v_x1_24217, 1ULL, 1);
    v_t_24221 = v_x_24218;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24217, 0ULL, 1);
    v_t_24221 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24220 = heff_field(v_x1_24217, 0);
    heff_take_n(v_x1_24217, 1ULL, 1);
    v_t_24221 = v_x_24220;
    break;
  }
  default: heff_nomatch(v_x1_24217);
  }
  V v_x1_24227;
  switch (heff_tag_of(v_cod_27_24194)) {
  case TAG_MkClo: {
    V v_vs_24223 = heff_field(v_cod_27_24194, 1);
    V v_body_24224 = heff_field(v_cod_27_24194, 2);
    heff_take_n(v_cod_27_24194, 6ULL, 3);
    v_x1_24227 = heff_tr(heff_apply(v_body_24224, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24223, heff_clo(g_heff_2eunify_2euTyRigid_lam43, 1, 1, (V[]){v_v_24204})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24226 = heff_field(v_cod_27_24194, 0);
    heff_take_n(v_cod_27_24194, 1ULL, 1);
    heff_drop(v_v_24204);
    v_x1_24227 = v_body_24226;
    break;
  }
  default: heff_nomatch(v_cod_27_24194);
  }
  V v_t_24231;
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_Nom: {
    V v_x_24228 = heff_field(v_x1_24227, 0);
    heff_take_n(v_x1_24227, 1ULL, 1);
    v_t_24231 = v_x_24228;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24227, 0ULL, 1);
    v_t_24231 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24230 = heff_field(v_x1_24227, 0);
    heff_take_n(v_x1_24227, 1ULL, 1);
    v_t_24231 = v_x_24230;
    break;
  }
  default: heff_nomatch(v_x1_24227);
  }
  return heff_tail(heff_get(v_r_243, LBL_uty), 6, (V[]){v_g_244, heff_rec(2, shape_168_200, (V[]){v_t_24210, v_t_24211}), v_t_24221, v_t_24231, v_hd_24199, v_k_24200});
}
V g_heff_2eunify_2euTyRigid_lam39(V self, V *args) {
  V v_hd_24199 = args[0];
  V v_k_24200 = args[1];
  V v_c_24198 = heff_env(self)[0];
  V v_cs_245 = heff_env(self)[1];
  V v_dom_24169 = heff_env(self)[2];
  V v_cod_24170 = heff_env(self)[3];
  V v_cod_27_24194 = heff_env(self)[4];
  V v_r_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_24198;
  args[0] = heff_dup(v_hd_24199);
  args[1] = heff_clo(g_heff_2eunify_2euTyRigid_lam40, 1, 8, (V[]){v_cs_245, v_dom_24169, v_cod_24170, v_cod_27_24194, v_r_243, v_g_244, v_hd_24199, v_k_24200});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam45(V self, V *args) {
  V v_c_24236 = args[0];
  V v_hd_24234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24236, 2, (V[]){heff_dup(v_hd_24234), heff_get(v_hd_24234, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam44(V self, V *args) {
  V v_hd_24234 = args[0];
  V v_k2_24235 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24233 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24237 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam45, 1, 1, (V[]){heff_dup(v_hd_24234)}), v_p_24233}));
  V v_t_24238 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24234), LBL_malg), 1, (V[]){v_t_24237}));
  V f_ = heff_get(v_hd_24234, LBL_bind);
  args[0] = v_t_24238;
  args[1] = v_k2_24235;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam47(V self, V *args) {
  V v_c_24247 = args[0];
  V v_hd_24245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24247, 2, (V[]){heff_dup(v_hd_24245), heff_get(v_hd_24245, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam46(V self, V *args) {
  V v_hd_24245 = args[0];
  V v_k2_24246 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24248 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam47, 1, 1, (V[]){heff_dup(v_hd_24245)}), v_p_24244}));
  V v_t_24249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24245), LBL_malg), 1, (V[]){v_t_24248}));
  V f_ = heff_get(v_hd_24245, LBL_bind);
  args[0] = v_t_24249;
  args[1] = v_k2_24246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam49(V self, V *args) {
  V v_c_24255 = args[0];
  V v_hd_24253 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24255, 2, (V[]){heff_dup(v_hd_24253), heff_get(v_hd_24253, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam48(V self, V *args) {
  V v_hd_24253 = args[0];
  V v_k2_24254 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24252 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24256 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam49, 1, 1, (V[]){heff_dup(v_hd_24253)}), v_p_24252}));
  V v_t_24257 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24253), LBL_malg), 1, (V[]){v_t_24256}));
  V f_ = heff_get(v_hd_24253, LBL_bind);
  args[0] = v_t_24257;
  args[1] = v_k2_24254;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam51(V self, V *args) {
  V v_c_24262 = args[0];
  V v_hd_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24262, 2, (V[]){heff_dup(v_hd_24260), heff_get(v_hd_24260, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam50(V self, V *args) {
  V v_hd_24260 = args[0];
  V v_k2_24261 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24259 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24263 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam51, 1, 1, (V[]){heff_dup(v_hd_24260)}), v_p_24259}));
  V v_t_24264 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24260), LBL_malg), 1, (V[]){v_t_24263}));
  V f_ = heff_get(v_hd_24260, LBL_bind);
  args[0] = v_t_24264;
  args[1] = v_k2_24261;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam53(V self, V *args) {
  V v_c_24269 = args[0];
  V v_hd_24267 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24269, 2, (V[]){heff_dup(v_hd_24267), heff_get(v_hd_24267, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam52(V self, V *args) {
  V v_hd_24267 = args[0];
  V v_k2_24268 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24266 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24270 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam53, 1, 1, (V[]){heff_dup(v_hd_24267)}), v_p_24266}));
  V v_t_24271 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24267), LBL_malg), 1, (V[]){v_t_24270}));
  V f_ = heff_get(v_hd_24267, LBL_bind);
  args[0] = v_t_24271;
  args[1] = v_k2_24268;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam55(V self, V *args) {
  V v_c_24276 = args[0];
  V v_hd_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24276, 2, (V[]){heff_dup(v_hd_24274), heff_get(v_hd_24274, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam54(V self, V *args) {
  V v_hd_24274 = args[0];
  V v_k2_24275 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24273 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24277 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam55, 1, 1, (V[]){heff_dup(v_hd_24274)}), v_p_24273}));
  V v_t_24278 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24274), LBL_malg), 1, (V[]){v_t_24277}));
  V f_ = heff_get(v_hd_24274, LBL_bind);
  args[0] = v_t_24278;
  args[1] = v_k2_24275;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam57(V self, V *args) {
  V v_c_24284 = args[0];
  V v_hd_24282 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24284, 2, (V[]){heff_dup(v_hd_24282), heff_get(v_hd_24282, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam56(V self, V *args) {
  V v_hd_24282 = args[0];
  V v_k2_24283 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24281 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24285 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam57, 1, 1, (V[]){heff_dup(v_hd_24282)}), v_p_24281}));
  V v_t_24286 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24282), LBL_malg), 1, (V[]){v_t_24285}));
  V f_ = heff_get(v_hd_24282, LBL_bind);
  args[0] = v_t_24286;
  args[1] = v_k2_24283;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam59(V self, V *args) {
  V v_c_24295 = args[0];
  V v_hd_24293 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24295, 2, (V[]){heff_dup(v_hd_24293), heff_get(v_hd_24293, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam58(V self, V *args) {
  V v_hd_24293 = args[0];
  V v_k2_24294 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24292 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24296 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam59, 1, 1, (V[]){heff_dup(v_hd_24293)}), v_p_24292}));
  V v_t_24297 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24293), LBL_malg), 1, (V[]){v_t_24296}));
  V f_ = heff_get(v_hd_24293, LBL_bind);
  args[0] = v_t_24297;
  args[1] = v_k2_24294;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam61(V self, V *args) {
  V v_c_24303 = args[0];
  V v_hd_24301 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24303, 2, (V[]){heff_dup(v_hd_24301), heff_get(v_hd_24301, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam60(V self, V *args) {
  V v_hd_24301 = args[0];
  V v_k2_24302 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24300 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24304 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam61, 1, 1, (V[]){heff_dup(v_hd_24301)}), v_p_24300}));
  V v_t_24305 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24301), LBL_malg), 1, (V[]){v_t_24304}));
  V f_ = heff_get(v_hd_24301, LBL_bind);
  args[0] = v_t_24305;
  args[1] = v_k2_24302;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam63(V self, V *args) {
  V v_c_24311 = args[0];
  V v_hd_24309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24311, 2, (V[]){heff_dup(v_hd_24309), heff_get(v_hd_24309, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam62(V self, V *args) {
  V v_hd_24309 = args[0];
  V v_k2_24310 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24308 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24312 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam63, 1, 1, (V[]){heff_dup(v_hd_24309)}), v_p_24308}));
  V v_t_24313 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24309), LBL_malg), 1, (V[]){v_t_24312}));
  V f_ = heff_get(v_hd_24309, LBL_bind);
  args[0] = v_t_24313;
  args[1] = v_k2_24310;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam65(V self, V *args) {
  V v_c_24323 = args[0];
  V v_hd_24321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24323, 2, (V[]){heff_dup(v_hd_24321), heff_get(v_hd_24321, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam64(V self, V *args) {
  V v_hd_24321 = args[0];
  V v_k2_24322 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24320 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24324 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam65, 1, 1, (V[]){heff_dup(v_hd_24321)}), v_p_24320}));
  V v_t_24325 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24321), LBL_malg), 1, (V[]){v_t_24324}));
  V f_ = heff_get(v_hd_24321, LBL_bind);
  args[0] = v_t_24325;
  args[1] = v_k2_24322;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam67(V self, V *args) {
  V v_c_24334 = args[0];
  V v_hd_24332 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24334, 2, (V[]){heff_dup(v_hd_24332), heff_get(v_hd_24332, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam66(V self, V *args) {
  V v_hd_24332 = args[0];
  V v_k2_24333 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24331 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24335 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam67, 1, 1, (V[]){heff_dup(v_hd_24332)}), v_p_24331}));
  V v_t_24336 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24332), LBL_malg), 1, (V[]){v_t_24335}));
  V f_ = heff_get(v_hd_24332, LBL_bind);
  args[0] = v_t_24336;
  args[1] = v_k2_24333;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam69(V self, V *args) {
  V v_c_24345 = args[0];
  V v_hd_24343 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24345, 2, (V[]){heff_dup(v_hd_24343), heff_get(v_hd_24343, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam68(V self, V *args) {
  V v_hd_24343 = args[0];
  V v_k2_24344 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24342 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24346 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam69, 1, 1, (V[]){heff_dup(v_hd_24343)}), v_p_24342}));
  V v_t_24347 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24343), LBL_malg), 1, (V[]){v_t_24346}));
  V f_ = heff_get(v_hd_24343, LBL_bind);
  args[0] = v_t_24347;
  args[1] = v_k2_24344;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam71(V self, V *args) {
  V v_c_24353 = args[0];
  V v_hd_24351 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24353, 2, (V[]){heff_dup(v_hd_24351), heff_get(v_hd_24351, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam70(V self, V *args) {
  V v_hd_24351 = args[0];
  V v_k2_24352 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24350 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24354 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam71, 1, 1, (V[]){heff_dup(v_hd_24351)}), v_p_24350}));
  V v_t_24355 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24351), LBL_malg), 1, (V[]){v_t_24354}));
  V f_ = heff_get(v_hd_24351, LBL_bind);
  args[0] = v_t_24355;
  args[1] = v_k2_24352;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam72(V self, V *args) {
  V v_hd_24356 = args[0];
  V v_k_24357 = args[1];
  heff_drop(v_hd_24356);
  V f_ = v_k_24357;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam74(V self, V *args) {
  V v_c_24362 = args[0];
  V v_hd_24360 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24362, 2, (V[]){heff_dup(v_hd_24360), heff_get(v_hd_24360, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam73(V self, V *args) {
  V v_hd_24360 = args[0];
  V v_k2_24361 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24359 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24363 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam74, 1, 1, (V[]){heff_dup(v_hd_24360)}), v_p_24359}));
  V v_t_24364 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24360), LBL_malg), 1, (V[]){v_t_24363}));
  V f_ = heff_get(v_hd_24360, LBL_bind);
  args[0] = v_t_24364;
  args[1] = v_k2_24361;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam76(V self, V *args) {
  V v_c_24369 = args[0];
  V v_hd_24367 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24369, 2, (V[]){heff_dup(v_hd_24367), heff_get(v_hd_24367, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam75(V self, V *args) {
  V v_hd_24367 = args[0];
  V v_k2_24368 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24366 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24370 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam76, 1, 1, (V[]){heff_dup(v_hd_24367)}), v_p_24366}));
  V v_t_24371 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24367), LBL_malg), 1, (V[]){v_t_24370}));
  V f_ = heff_get(v_hd_24367, LBL_bind);
  args[0] = v_t_24371;
  args[1] = v_k2_24368;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam78(V self, V *args) {
  V v_c_24377 = args[0];
  V v_hd_24375 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24377, 2, (V[]){heff_dup(v_hd_24375), heff_get(v_hd_24375, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam77(V self, V *args) {
  V v_hd_24375 = args[0];
  V v_k2_24376 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24374 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24378 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam78, 1, 1, (V[]){heff_dup(v_hd_24375)}), v_p_24374}));
  V v_t_24379 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24375), LBL_malg), 1, (V[]){v_t_24378}));
  V f_ = heff_get(v_hd_24375, LBL_bind);
  args[0] = v_t_24379;
  args[1] = v_k2_24376;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam80(V self, V *args) {
  V v_c_24385 = args[0];
  V v_hd_24383 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24385, 2, (V[]){heff_dup(v_hd_24383), heff_get(v_hd_24383, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam79(V self, V *args) {
  V v_hd_24383 = args[0];
  V v_k2_24384 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24382 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24386 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam80, 1, 1, (V[]){heff_dup(v_hd_24383)}), v_p_24382}));
  V v_t_24387 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24383), LBL_malg), 1, (V[]){v_t_24386}));
  V f_ = heff_get(v_hd_24383, LBL_bind);
  args[0] = v_t_24387;
  args[1] = v_k2_24384;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam82(V self, V *args) {
  V v_c_24397 = args[0];
  V v_hd_24395 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24397, 2, (V[]){heff_dup(v_hd_24395), heff_get(v_hd_24395, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam81(V self, V *args) {
  V v_hd_24395 = args[0];
  V v_k2_24396 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24394 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24398 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam82, 1, 1, (V[]){heff_dup(v_hd_24395)}), v_p_24394}));
  V v_t_24399 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24395), LBL_malg), 1, (V[]){v_t_24398}));
  V f_ = heff_get(v_hd_24395, LBL_bind);
  args[0] = v_t_24399;
  args[1] = v_k2_24396;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam84(V self, V *args) {
  V v_c_24408 = args[0];
  V v_hd_24406 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24408, 2, (V[]){heff_dup(v_hd_24406), heff_get(v_hd_24406, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam83(V self, V *args) {
  V v_hd_24406 = args[0];
  V v_k2_24407 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24405 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24409 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam84, 1, 1, (V[]){heff_dup(v_hd_24406)}), v_p_24405}));
  V v_t_24410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24406), LBL_malg), 1, (V[]){v_t_24409}));
  V f_ = heff_get(v_hd_24406, LBL_bind);
  args[0] = v_t_24410;
  args[1] = v_k2_24407;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam86(V self, V *args) {
  V v_c_24419 = args[0];
  V v_hd_24417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24419, 2, (V[]){heff_dup(v_hd_24417), heff_get(v_hd_24417, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam85(V self, V *args) {
  V v_hd_24417 = args[0];
  V v_k2_24418 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24420 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam86, 1, 1, (V[]){heff_dup(v_hd_24417)}), v_p_24416}));
  V v_t_24421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24417), LBL_malg), 1, (V[]){v_t_24420}));
  V f_ = heff_get(v_hd_24417, LBL_bind);
  args[0] = v_t_24421;
  args[1] = v_k2_24418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam88(V self, V *args) {
  V v_c_24427 = args[0];
  V v_hd_24425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24427, 2, (V[]){heff_dup(v_hd_24425), heff_get(v_hd_24425, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam87(V self, V *args) {
  V v_hd_24425 = args[0];
  V v_k2_24426 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24428 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam88, 1, 1, (V[]){heff_dup(v_hd_24425)}), v_p_24424}));
  V v_t_24429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24425), LBL_malg), 1, (V[]){v_t_24428}));
  V f_ = heff_get(v_hd_24425, LBL_bind);
  args[0] = v_t_24429;
  args[1] = v_k2_24426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam90(V self, V *args) {
  V v_c_24434 = args[0];
  V v_hd_24432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24434, 2, (V[]){heff_dup(v_hd_24432), heff_get(v_hd_24432, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam89(V self, V *args) {
  V v_hd_24432 = args[0];
  V v_k2_24433 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24435 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam90, 1, 1, (V[]){heff_dup(v_hd_24432)}), v_p_24431}));
  V v_t_24436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24432), LBL_malg), 1, (V[]){v_t_24435}));
  V f_ = heff_get(v_hd_24432, LBL_bind);
  args[0] = v_t_24436;
  args[1] = v_k2_24433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam91(V self, V *args) {
  V v_hd_24437 = args[0];
  V v_k_24438 = args[1];
  heff_drop(v_hd_24437);
  V f_ = v_k_24438;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam93(V self, V *args) {
  V v_c_24443 = args[0];
  V v_hd_24441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24443, 2, (V[]){heff_dup(v_hd_24441), heff_get(v_hd_24441, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam92(V self, V *args) {
  V v_hd_24441 = args[0];
  V v_k2_24442 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24444 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam93, 1, 1, (V[]){heff_dup(v_hd_24441)}), v_p_24440}));
  V v_t_24445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24441), LBL_malg), 1, (V[]){v_t_24444}));
  V f_ = heff_get(v_hd_24441, LBL_bind);
  args[0] = v_t_24445;
  args[1] = v_k2_24442;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam95(V self, V *args) {
  V v_c_24451 = args[0];
  V v_hd_24449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24451, 2, (V[]){heff_dup(v_hd_24449), heff_get(v_hd_24449, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam94(V self, V *args) {
  V v_hd_24449 = args[0];
  V v_k2_24450 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24452 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam95, 1, 1, (V[]){heff_dup(v_hd_24449)}), v_p_24448}));
  V v_t_24453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24449), LBL_malg), 1, (V[]){v_t_24452}));
  V f_ = heff_get(v_hd_24449, LBL_bind);
  args[0] = v_t_24453;
  args[1] = v_k2_24450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam97(V self, V *args) {
  V v_c_24459 = args[0];
  V v_hd_24457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24459, 2, (V[]){heff_dup(v_hd_24457), heff_get(v_hd_24457, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam96(V self, V *args) {
  V v_hd_24457 = args[0];
  V v_k2_24458 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24460 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam97, 1, 1, (V[]){heff_dup(v_hd_24457)}), v_p_24456}));
  V v_t_24461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24457), LBL_malg), 1, (V[]){v_t_24460}));
  V f_ = heff_get(v_hd_24457, LBL_bind);
  args[0] = v_t_24461;
  args[1] = v_k2_24458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam99(V self, V *args) {
  V v_c_24471 = args[0];
  V v_hd_24469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24471, 2, (V[]){heff_dup(v_hd_24469), heff_get(v_hd_24469, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam98(V self, V *args) {
  V v_hd_24469 = args[0];
  V v_k2_24470 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24468 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24472 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam99, 1, 1, (V[]){heff_dup(v_hd_24469)}), v_p_24468}));
  V v_t_24473 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24469), LBL_malg), 1, (V[]){v_t_24472}));
  V f_ = heff_get(v_hd_24469, LBL_bind);
  args[0] = v_t_24473;
  args[1] = v_k2_24470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam101(V self, V *args) {
  V v_c_24482 = args[0];
  V v_hd_24480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24482, 2, (V[]){heff_dup(v_hd_24480), heff_get(v_hd_24480, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam100(V self, V *args) {
  V v_hd_24480 = args[0];
  V v_k2_24481 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24483 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam101, 1, 1, (V[]){heff_dup(v_hd_24480)}), v_p_24479}));
  V v_t_24484 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24480), LBL_malg), 1, (V[]){v_t_24483}));
  V f_ = heff_get(v_hd_24480, LBL_bind);
  args[0] = v_t_24484;
  args[1] = v_k2_24481;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam103(V self, V *args) {
  V v_c_24493 = args[0];
  V v_hd_24491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24493, 2, (V[]){heff_dup(v_hd_24491), heff_get(v_hd_24491, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam102(V self, V *args) {
  V v_hd_24491 = args[0];
  V v_k2_24492 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24494 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam103, 1, 1, (V[]){heff_dup(v_hd_24491)}), v_p_24490}));
  V v_t_24495 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24491), LBL_malg), 1, (V[]){v_t_24494}));
  V f_ = heff_get(v_hd_24491, LBL_bind);
  args[0] = v_t_24495;
  args[1] = v_k2_24492;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam105(V self, V *args) {
  V v_c_24501 = args[0];
  V v_hd_24499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24501, 2, (V[]){heff_dup(v_hd_24499), heff_get(v_hd_24499, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam104(V self, V *args) {
  V v_hd_24499 = args[0];
  V v_k2_24500 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24502 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam105, 1, 1, (V[]){heff_dup(v_hd_24499)}), v_p_24498}));
  V v_t_24503 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24499), LBL_malg), 1, (V[]){v_t_24502}));
  V f_ = heff_get(v_hd_24499, LBL_bind);
  args[0] = v_t_24503;
  args[1] = v_k2_24500;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam107(V self, V *args) {
  V v_c_24508 = args[0];
  V v_hd_24506 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24508, 2, (V[]){heff_dup(v_hd_24506), heff_get(v_hd_24506, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam106(V self, V *args) {
  V v_hd_24506 = args[0];
  V v_k2_24507 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24505 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24509 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam107, 1, 1, (V[]){heff_dup(v_hd_24506)}), v_p_24505}));
  V v_t_24510 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24506), LBL_malg), 1, (V[]){v_t_24509}));
  V f_ = heff_get(v_hd_24506, LBL_bind);
  args[0] = v_t_24510;
  args[1] = v_k2_24507;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam109(V self, V *args) {
  V v_c_24515 = args[0];
  V v_hd_24513 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24515, 2, (V[]){heff_dup(v_hd_24513), heff_get(v_hd_24513, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam108(V self, V *args) {
  V v_hd_24513 = args[0];
  V v_k2_24514 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24512 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24516 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam109, 1, 1, (V[]){heff_dup(v_hd_24513)}), v_p_24512}));
  V v_t_24517 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24513), LBL_malg), 1, (V[]){v_t_24516}));
  V f_ = heff_get(v_hd_24513, LBL_bind);
  args[0] = v_t_24517;
  args[1] = v_k2_24514;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam110(V self, V *args) {
  V v_hd_24518 = args[0];
  V v_k_24519 = args[1];
  heff_drop(v_hd_24518);
  V f_ = v_k_24519;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTyRigid_lam112(V self, V *args) {
  V v_c_24525 = args[0];
  V v_hd_24523 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24525, 2, (V[]){heff_dup(v_hd_24523), heff_get(v_hd_24523, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam111(V self, V *args) {
  V v_hd_24523 = args[0];
  V v_k2_24524 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24522 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24526 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam112, 1, 1, (V[]){heff_dup(v_hd_24523)}), v_p_24522}));
  V v_t_24527 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24523), LBL_malg), 1, (V[]){v_t_24526}));
  V f_ = heff_get(v_hd_24523, LBL_bind);
  args[0] = v_t_24527;
  args[1] = v_k2_24524;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam114(V self, V *args) {
  V v_c_24534 = args[0];
  V v_hd_24532 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24534, 2, (V[]){heff_dup(v_hd_24532), heff_get(v_hd_24532, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam113(V self, V *args) {
  V v_hd_24532 = args[0];
  V v_k2_24533 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24531 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24535 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam114, 1, 1, (V[]){heff_dup(v_hd_24532)}), v_p_24531}));
  V v_t_24536 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24532), LBL_malg), 1, (V[]){v_t_24535}));
  V f_ = heff_get(v_hd_24532, LBL_bind);
  args[0] = v_t_24536;
  args[1] = v_k2_24533;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam116(V self, V *args) {
  V v_c_24546 = args[0];
  V v_hd_24544 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24546, 2, (V[]){heff_dup(v_hd_24544), heff_get(v_hd_24544, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam115(V self, V *args) {
  V v_hd_24544 = args[0];
  V v_k2_24545 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24543 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24547 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam116, 1, 1, (V[]){heff_dup(v_hd_24544)}), v_p_24543}));
  V v_t_24548 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24544), LBL_malg), 1, (V[]){v_t_24547}));
  V f_ = heff_get(v_hd_24544, LBL_bind);
  args[0] = v_t_24548;
  args[1] = v_k2_24545;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam118(V self, V *args) {
  V v_c_24557 = args[0];
  V v_hd_24555 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24557, 2, (V[]){heff_dup(v_hd_24555), heff_get(v_hd_24555, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam117(V self, V *args) {
  V v_hd_24555 = args[0];
  V v_k2_24556 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24554 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24558 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam118, 1, 1, (V[]){heff_dup(v_hd_24555)}), v_p_24554}));
  V v_t_24559 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24555), LBL_malg), 1, (V[]){v_t_24558}));
  V f_ = heff_get(v_hd_24555, LBL_bind);
  args[0] = v_t_24559;
  args[1] = v_k2_24556;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam120(V self, V *args) {
  V v_c_24568 = args[0];
  V v_hd_24566 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24568, 2, (V[]){heff_dup(v_hd_24566), heff_get(v_hd_24566, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam119(V self, V *args) {
  V v_hd_24566 = args[0];
  V v_k2_24567 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24565 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24569 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam120, 1, 1, (V[]){heff_dup(v_hd_24566)}), v_p_24565}));
  V v_t_24570 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24566), LBL_malg), 1, (V[]){v_t_24569}));
  V f_ = heff_get(v_hd_24566, LBL_bind);
  args[0] = v_t_24570;
  args[1] = v_k2_24567;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam122(V self, V *args) {
  V v_c_24576 = args[0];
  V v_hd_24574 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24576, 2, (V[]){heff_dup(v_hd_24574), heff_get(v_hd_24574, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam121(V self, V *args) {
  V v_hd_24574 = args[0];
  V v_k2_24575 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24573 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24577 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam122, 1, 1, (V[]){heff_dup(v_hd_24574)}), v_p_24573}));
  V v_t_24578 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24574), LBL_malg), 1, (V[]){v_t_24577}));
  V f_ = heff_get(v_hd_24574, LBL_bind);
  args[0] = v_t_24578;
  args[1] = v_k2_24575;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam124(V self, V *args) {
  V v_c_24583 = args[0];
  V v_hd_24581 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24583, 2, (V[]){heff_dup(v_hd_24581), heff_get(v_hd_24581, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam123(V self, V *args) {
  V v_hd_24581 = args[0];
  V v_k2_24582 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24580 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24584 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam124, 1, 1, (V[]){heff_dup(v_hd_24581)}), v_p_24580}));
  V v_t_24585 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24581), LBL_malg), 1, (V[]){v_t_24584}));
  V f_ = heff_get(v_hd_24581, LBL_bind);
  args[0] = v_t_24585;
  args[1] = v_k2_24582;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam126(V self, V *args) {
  V v_c_24590 = args[0];
  V v_hd_24588 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24590, 2, (V[]){heff_dup(v_hd_24588), heff_get(v_hd_24588, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam125(V self, V *args) {
  V v_hd_24588 = args[0];
  V v_k2_24589 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24587 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24591 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam126, 1, 1, (V[]){heff_dup(v_hd_24588)}), v_p_24587}));
  V v_t_24592 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24588), LBL_malg), 1, (V[]){v_t_24591}));
  V f_ = heff_get(v_hd_24588, LBL_bind);
  args[0] = v_t_24592;
  args[1] = v_k2_24589;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTyRigid_lam128(V self, V *args) {
  V v_c_24597 = args[0];
  V v_hd_24595 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24597, 2, (V[]){heff_dup(v_hd_24595), heff_get(v_hd_24595, LBL_ret)});
}
V g_heff_2eunify_2euTyRigid_lam127(V self, V *args) {
  V v_hd_24595 = args[0];
  V v_k2_24596 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24594 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24598 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTyRigid_lam128, 1, 1, (V[]){heff_dup(v_hd_24595)}), v_p_24594}));
  V v_t_24599 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24595), LBL_malg), 1, (V[]){v_t_24598}));
  V f_ = heff_get(v_hd_24595, LBL_bind);
  args[0] = v_t_24599;
  args[1] = v_k2_24596;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2euElRigid_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eunify_2euElRigid_lam3(V self, V *args);
V g_heff_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eunify_2euElRigid_lam5(V self, V *args);
V g_heff_2eunify_2euElRigid_lam4(V self, V *args);
V g_heff_2eunify_2euElRigid_lam7(V self, V *args);
V g_heff_2eunify_2euElRigid_lam6(V self, V *args);
V g_heff_2eunify_2euElRigid_lam9(V self, V *args);
V g_heff_2eunify_2euElRigid_lam8(V self, V *args);
V g_heff_2eunify_2euElRigid_lam11(V self, V *args);
V g_heff_2eunify_2euElRigid_lam10(V self, V *args);
V g_heff_2eunify_2euElRigid_lam13(V self, V *args);
V g_heff_2eunify_2euElRigid_lam12(V self, V *args);
V g_heff_2eunify_2euElRigid_lam15(V self, V *args);
V g_heff_2eunify_2euElRigid_lam14(V self, V *args);
V g_heff_2eunify_2euElRigid_lam17(V self, V *args);
V g_heff_2eunify_2euElRigid_lam16(V self, V *args);
V g_heff_2eunify_2euElRigid_lam19(V self, V *args);
V g_heff_2eunify_2euElRigid_lam18(V self, V *args);
V g_heff_2eunify_2euElRigid_lam20(V self, V *args);
V g_heff_2eunify_2euElRigid_lam21(V self, V *args);
V g_heff_2eunify_2euElRigid_lam22(V self, V *args);
V g_heff_2eunify_2euElRigid_lam24(V self, V *args);
V g_heff_2eunify_2euElRigid_lam23(V self, V *args);
V g_heff_2eunify_2euElRigid_lam26(V self, V *args);
V g_heff_2eunify_2euElRigid_lam25(V self, V *args);
V g_heff_2eunify_2euElRigid_lam28(V self, V *args);
V g_heff_2eunify_2euElRigid_lam27(V self, V *args);
V g_heff_2eunify_2euElRigid_lam30(V self, V *args);
V g_heff_2eunify_2euElRigid_lam29(V self, V *args);
V g_heff_2eunify_2euElRigid_lam32(V self, V *args);
V g_heff_2eunify_2euElRigid_lam31(V self, V *args);
V g_heff_2eunify_2euElRigid_lam33(V self, V *args);
V g_heff_2eunify_2euElRigid_lam35(V self, V *args);
V g_heff_2eunify_2euElRigid_lam34(V self, V *args);
V g_heff_2eunify_2euElRigid_lam36(V self, V *args); static Clo g_heff_2eunify_2euElRigid_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euElRigid_lam36, 2, 0};
Clo g_heff_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euElRigid_entry, 10, 0};

V g_heff_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_ca_246, V v_cb_247, V v_a_248, V v_b_249) {
top: ;
  switch (heff_tag_of(v_ca_246)) {
  case TAG_VNeu: {
    V v_h_2410 = heff_field(v_ca_246, 0);
    V v_sp_2411 = heff_field(v_ca_246, 1);
    heff_take_n(v_ca_246, 3ULL, 5);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2415 = heff_field(v_cb_247, 0);
      V v_sp_27_2416 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get(v_r_243, LBL_ubare), 6, (V[]){v_g_244, v_cs_245, v_h_2410, v_sp_2411, v_h_27_2415, v_sp_27_2416});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2421 = heff_tag_at(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2422 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2421}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam0, 2, 2, (V[]){v_w_240, v_p_2422});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2430 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2431 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2430}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam2, 2, 2, (V[]){v_w_240, v_p_2431});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2438 = heff_tag_at(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2439 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2438}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam4, 2, 2, (V[]){v_w_240, v_p_2439});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2445 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2446 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2445}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam6, 2, 2, (V[]){v_w_240, v_p_2446});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2452 = heff_field(v_ca_246, 0);
    V v_ru_24ca_246_24VCode = heff_take_reuse_n(v_ca_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2458 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2459 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2458}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam8, 2, 2, (V[]){v_w_240, v_p_2459});
    }
    case TAG_VCode: {
      V v_t_27_2465 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24ca_246_24VCode, 1);
      return heff_tail(heff_get(v_r_243, LBL_uty), 4, (V[]){v_g_244, v_cs_245, v_t_2452, v_t_27_2465});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2468 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2469 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2468}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam10, 2, 2, (V[]){v_w_240, v_p_2469});
    }
    case TAG_VCons: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2476 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2477 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2476}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam12, 2, 2, (V[]){v_w_240, v_p_2477});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_t_2452);
      V v_t_2483 = heff_tag_at(v_ru_24ca_246_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2484 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2483}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam14, 2, 2, (V[]){v_w_240, v_p_2484});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2490 = heff_field(v_ca_246, 0);
    V v_c_2491 = heff_field(v_ca_246, 1);
    V v_ru_24ca_246_24VLam = heff_take_reuse_n(v_ca_246, 3ULL, 2);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_2497 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_2498 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2497}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam16, 2, 2, (V[]){v_w_240, v_p_2498});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_24105 = heff_tag_at(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24106 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24105}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam18, 2, 2, (V[]){v_w_240, v_p_24106});
    }
    case TAG_VLam: {
      V v_c_27_24113 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 2ULL, 2);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_24114 = heff_tr(heff_apply(v_d_2490, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_24115 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_24114)));
      V v_a_24126;
      switch (heff_tag_of(v_t_24115)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_24118 = heff_field(v_t_24115, 1);
        heff_take_n(v_t_24115, 2ULL, 4);
        heff_drop(v_t_24114);
        v_a_24126 = v_dom_24118;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_24115, 0ULL, 3);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeInt: {
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeFloat: {
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeString: {
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24115, 0ULL, 1);
        v_a_24126 = v_t_24114;
        break;
      }
      case TAG_NoRules: {
        v_a_24126 = v_t_24114;
        break;
      }
      default: heff_nomatch(v_t_24115);
      }
      V v_t_24127 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_cs_245), LBL_len)});
      V v_v_24129 = (g_heff_2evalue_2emkNeu_24s10(v_t_24127, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2euElRigid_lam20, 1, 1, (V[]){v_a_24126}), NTAG(TAG_Nothing)));
      V v_x_24134;
      switch (heff_tag_of(v_c_2491)) {
      case TAG_MkClo: {
        V v_n_24130 = heff_dup(heff_field(v_c_2491, 0));
        v_x_24134 = v_n_24130;
        break;
      }
      case TAG_CloConst: {
        v_x_24134 = ((V)&g_heff_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2491);
      }
      V v_t_24135 = heff_intAdd(heff_get(heff_dup(v_cs_245), LBL_len), MK_INT(1LL));
      V v_t_24136 = heff_tag_at(v_ru_24ca_246_24VLam, TAG_Cons, 2, (V[]){v_x_24134, heff_get(v_cs_245, LBL_names)});
      V v_x1_24142;
      switch (heff_tag_of(v_c_2491)) {
      case TAG_MkClo: {
        V v_vs_24138 = heff_field(v_c_2491, 1);
        V v_body_24139 = heff_field(v_c_2491, 2);
        heff_take_n(v_c_2491, 6ULL, 3);
        v_x1_24142 = heff_tr(heff_apply(v_body_24139, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24138, heff_clo(g_heff_2eunify_2euElRigid_lam21, 1, 1, (V[]){heff_dup(v_v_24129)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24141 = heff_field(v_c_2491, 0);
        heff_take_n(v_c_2491, 1ULL, 1);
        v_x1_24142 = v_body_24141;
        break;
      }
      default: heff_nomatch(v_c_2491);
      }
      V v_t_24146;
      switch (heff_tag_of(v_x1_24142)) {
      case TAG_Nom: {
        V v_x_24143 = heff_field(v_x1_24142, 0);
        heff_take_n(v_x1_24142, 1ULL, 1);
        v_t_24146 = v_x_24143;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24142, 0ULL, 1);
        v_t_24146 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24145 = heff_field(v_x1_24142, 0);
        heff_take_n(v_x1_24142, 1ULL, 1);
        v_t_24146 = v_x_24145;
        break;
      }
      default: heff_nomatch(v_x1_24142);
      }
      V v_x1_24152;
      switch (heff_tag_of(v_c_27_24113)) {
      case TAG_MkClo: {
        V v_vs_24148 = heff_field(v_c_27_24113, 1);
        V v_body_24149 = heff_field(v_c_27_24113, 2);
        heff_take_n(v_c_27_24113, 6ULL, 3);
        v_x1_24152 = heff_tr(heff_apply(v_body_24149, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_24148, heff_clo(g_heff_2eunify_2euElRigid_lam22, 1, 1, (V[]){v_v_24129})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24151 = heff_field(v_c_27_24113, 0);
        heff_take_n(v_c_27_24113, 1ULL, 1);
        heff_drop(v_v_24129);
        v_x1_24152 = v_body_24151;
        break;
      }
      default: heff_nomatch(v_c_27_24113);
      }
      V v_t_24156;
      switch (heff_tag_of(v_x1_24152)) {
      case TAG_Nom: {
        V v_x_24153 = heff_field(v_x1_24152, 0);
        heff_take_n(v_x1_24152, 1ULL, 1);
        v_t_24156 = v_x_24153;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24152, 0ULL, 1);
        v_t_24156 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24155 = heff_field(v_x1_24152, 0);
        heff_take_n(v_x1_24152, 1ULL, 1);
        v_t_24156 = v_x_24155;
        break;
      }
      default: heff_nomatch(v_x1_24152);
      }
      return heff_tail(heff_get(v_r_243, LBL_uel), 4, (V[]){v_g_244, heff_rec(2, shape_168_200, (V[]){v_t_24135, v_t_24136}), v_t_24146, v_t_24156});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_24158 = heff_tag_at(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24159 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24158}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam23, 2, 2, (V[]){v_w_240, v_p_24159});
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_2490);
      heff_drop(v_c_2491);
      heff_drop_cell(v_ru_24ca_246_24VLam, 2);
      V v_t_24165 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24166 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24165}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam25, 2, 2, (V[]){v_w_240, v_p_24166});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24172 = heff_field(v_ca_246, 0);
    V v_ru_24ca_246_24VCons = heff_take_reuse_n(v_ca_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24178 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24179 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24178}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam27, 2, 2, (V[]){v_w_240, v_p_24179});
    }
    case TAG_VCode: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24186 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24187 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24186}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam29, 2, 2, (V[]){v_w_240, v_p_24187});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24195 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24196 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24195}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam31, 2, 2, (V[]){v_w_240, v_p_24196});
    }
    case TAG_VCons: {
      V v_d_27_24202 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24ca_246_24VCons, 1);
      V v_t_24203 = heff_arrayToList(heff_get(v_d_24172, LBL_values));
      V v_t_24204 = heff_arrayToList(heff_get(v_d_27_24202, LBL_values));
      V v_t_24205 = (g_heff_2eunify_2ezipL(v_t_24203, v_t_24204));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24205; V a_4 = heff_clo(g_heff_2eunify_2euElRigid_lam33, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V r_ = (g_heff_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24205); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_d_24172);
      V v_t_24217 = heff_tag_at(v_ru_24ca_246_24VCons, TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_p_24218 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24217}));
      return heff_clo(g_heff_2eunify_2euElRigid_lam34, 2, 2, (V[]){v_w_240, v_p_24218});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    heff_drop(v_cs_245);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    return ((V)&g_heff_2eunify_2euElRigid_lam36_clo);
  }
  default: return heff_nomatch(v_ca_246);
  }
}
V g_heff_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2euElRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[1]); return r;
}
V g_heff_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_2423), heff_get(v_hd_2423, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_hd_2423)}), v_p_2422}));
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_c_2434 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_2432), heff_get(v_hd_2432, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam3, 1, 1, (V[]){heff_dup(v_hd_2432)}), v_p_2431}));
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2432), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2432, LBL_bind);
  args[0] = v_t_2436;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam5(V self, V *args) {
  V v_c_2442 = args[0];
  V v_hd_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_2440), heff_get(v_hd_2440, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam5, 1, 1, (V[]){heff_dup(v_hd_2440)}), v_p_2439}));
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2440), LBL_malg), 1, (V[]){v_t_2443}));
  V f_ = heff_get(v_hd_2440, LBL_bind);
  args[0] = v_t_2444;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam7(V self, V *args) {
  V v_c_2449 = args[0];
  V v_hd_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2449, 2, (V[]){heff_dup(v_hd_2447), heff_get(v_hd_2447, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam7, 1, 1, (V[]){heff_dup(v_hd_2447)}), v_p_2446}));
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2450}));
  V f_ = heff_get(v_hd_2447, LBL_bind);
  args[0] = v_t_2451;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam9(V self, V *args) {
  V v_c_2462 = args[0];
  V v_hd_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2462, 2, (V[]){heff_dup(v_hd_2460), heff_get(v_hd_2460, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam8(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k2_2461 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam9, 1, 1, (V[]){heff_dup(v_hd_2460)}), v_p_2459}));
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2460), LBL_malg), 1, (V[]){v_t_2463}));
  V f_ = heff_get(v_hd_2460, LBL_bind);
  args[0] = v_t_2464;
  args[1] = v_k2_2461;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam11(V self, V *args) {
  V v_c_2472 = args[0];
  V v_hd_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2472, 2, (V[]){heff_dup(v_hd_2470), heff_get(v_hd_2470, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam10(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2473 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam11, 1, 1, (V[]){heff_dup(v_hd_2470)}), v_p_2469}));
  V v_t_2474 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2470), LBL_malg), 1, (V[]){v_t_2473}));
  V f_ = heff_get(v_hd_2470, LBL_bind);
  args[0] = v_t_2474;
  args[1] = v_k2_2471;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam13(V self, V *args) {
  V v_c_2480 = args[0];
  V v_hd_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2480, 2, (V[]){heff_dup(v_hd_2478), heff_get(v_hd_2478, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam12(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam13, 1, 1, (V[]){heff_dup(v_hd_2478)}), v_p_2477}));
  V v_t_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2478), LBL_malg), 1, (V[]){v_t_2481}));
  V f_ = heff_get(v_hd_2478, LBL_bind);
  args[0] = v_t_2482;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam15(V self, V *args) {
  V v_c_2487 = args[0];
  V v_hd_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2487, 2, (V[]){heff_dup(v_hd_2485), heff_get(v_hd_2485, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam14(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k2_2486 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2484 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2488 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam15, 1, 1, (V[]){heff_dup(v_hd_2485)}), v_p_2484}));
  V v_t_2489 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2485), LBL_malg), 1, (V[]){v_t_2488}));
  V f_ = heff_get(v_hd_2485, LBL_bind);
  args[0] = v_t_2489;
  args[1] = v_k2_2486;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam17(V self, V *args) {
  V v_c_24101 = args[0];
  V v_hd_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_2499), heff_get(v_hd_2499, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam16(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k2_24100 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24102 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam17, 1, 1, (V[]){heff_dup(v_hd_2499)}), v_p_2498}));
  V v_t_24103 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2499), LBL_malg), 1, (V[]){v_t_24102}));
  V f_ = heff_get(v_hd_2499, LBL_bind);
  args[0] = v_t_24103;
  args[1] = v_k2_24100;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam19(V self, V *args) {
  V v_c_24109 = args[0];
  V v_hd_24107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24109, 2, (V[]){heff_dup(v_hd_24107), heff_get(v_hd_24107, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam18(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k2_24108 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24106 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24110 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam19, 1, 1, (V[]){heff_dup(v_hd_24107)}), v_p_24106}));
  V v_t_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24107), LBL_malg), 1, (V[]){v_t_24110}));
  V f_ = heff_get(v_hd_24107, LBL_bind);
  args[0] = v_t_24111;
  args[1] = v_k2_24108;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam20(V self, V *args) {
  V v_u_24128 = args[0];
  V v_a_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24128);
  return v_a_24126;
}
V g_heff_2eunify_2euElRigid_lam21(V self, V *args) {
  V v_w_24140 = args[0];
  V v_v_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24140);
  return v_v_24129;
}
V g_heff_2eunify_2euElRigid_lam22(V self, V *args) {
  V v_w_24150 = args[0];
  V v_v_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24150);
  return v_v_24129;
}
V g_heff_2eunify_2euElRigid_lam24(V self, V *args) {
  V v_c_24162 = args[0];
  V v_hd_24160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24162, 2, (V[]){heff_dup(v_hd_24160), heff_get(v_hd_24160, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam23(V self, V *args) {
  V v_hd_24160 = args[0];
  V v_k2_24161 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24159 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24163 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam24, 1, 1, (V[]){heff_dup(v_hd_24160)}), v_p_24159}));
  V v_t_24164 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24160), LBL_malg), 1, (V[]){v_t_24163}));
  V f_ = heff_get(v_hd_24160, LBL_bind);
  args[0] = v_t_24164;
  args[1] = v_k2_24161;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam26(V self, V *args) {
  V v_c_24169 = args[0];
  V v_hd_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24169, 2, (V[]){heff_dup(v_hd_24167), heff_get(v_hd_24167, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam25(V self, V *args) {
  V v_hd_24167 = args[0];
  V v_k2_24168 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24166 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24170 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam26, 1, 1, (V[]){heff_dup(v_hd_24167)}), v_p_24166}));
  V v_t_24171 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24167), LBL_malg), 1, (V[]){v_t_24170}));
  V f_ = heff_get(v_hd_24167, LBL_bind);
  args[0] = v_t_24171;
  args[1] = v_k2_24168;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam28(V self, V *args) {
  V v_c_24182 = args[0];
  V v_hd_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24182, 2, (V[]){heff_dup(v_hd_24180), heff_get(v_hd_24180, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam27(V self, V *args) {
  V v_hd_24180 = args[0];
  V v_k2_24181 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24179 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24183 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam28, 1, 1, (V[]){heff_dup(v_hd_24180)}), v_p_24179}));
  V v_t_24184 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24180), LBL_malg), 1, (V[]){v_t_24183}));
  V f_ = heff_get(v_hd_24180, LBL_bind);
  args[0] = v_t_24184;
  args[1] = v_k2_24181;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam30(V self, V *args) {
  V v_c_24190 = args[0];
  V v_hd_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24190, 2, (V[]){heff_dup(v_hd_24188), heff_get(v_hd_24188, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam29(V self, V *args) {
  V v_hd_24188 = args[0];
  V v_k2_24189 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24187 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24191 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam30, 1, 1, (V[]){heff_dup(v_hd_24188)}), v_p_24187}));
  V v_t_24192 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24188), LBL_malg), 1, (V[]){v_t_24191}));
  V f_ = heff_get(v_hd_24188, LBL_bind);
  args[0] = v_t_24192;
  args[1] = v_k2_24189;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam32(V self, V *args) {
  V v_c_24199 = args[0];
  V v_hd_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24199, 2, (V[]){heff_dup(v_hd_24197), heff_get(v_hd_24197, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam31(V self, V *args) {
  V v_hd_24197 = args[0];
  V v_k2_24198 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24196 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24200 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam32, 1, 1, (V[]){heff_dup(v_hd_24197)}), v_p_24196}));
  V v_t_24201 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24197), LBL_malg), 1, (V[]){v_t_24200}));
  V f_ = heff_get(v_hd_24197, LBL_bind);
  args[0] = v_t_24201;
  args[1] = v_k2_24198;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam33(V self, V *args) {
  V v_p_24206 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  V v_cs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_p_24206, 0);
    V v_y_24208 = heff_field(v_p_24206, 1);
    heff_take_n(v_p_24206, 3ULL, 2);
    V v_t_24212;
    switch (heff_tag_of(v_x_24207)) {
    case TAG_Nom: {
      V v_x_24209 = heff_field(v_x_24207, 0);
      heff_take_n(v_x_24207, 1ULL, 1);
      v_t_24212 = v_x_24209;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24207, 0ULL, 1);
      v_t_24212 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24211 = heff_field(v_x_24207, 0);
      heff_take_n(v_x_24207, 1ULL, 1);
      v_t_24212 = v_x_24211;
      break;
    }
    default: heff_nomatch(v_x_24207);
    }
    V v_t_24216;
    switch (heff_tag_of(v_y_24208)) {
    case TAG_Nom: {
      V v_x_24213 = heff_field(v_y_24208, 0);
      heff_take_n(v_y_24208, 1ULL, 1);
      v_t_24216 = v_x_24213;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24208, 0ULL, 1);
      v_t_24216 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24215 = heff_field(v_y_24208, 0);
      heff_take_n(v_y_24208, 1ULL, 1);
      v_t_24216 = v_x_24215;
      break;
    }
    default: heff_nomatch(v_y_24208);
    }
    return heff_tail(heff_get(v_r_243, LBL_uel), 4, (V[]){v_g_244, v_cs_245, v_t_24212, v_t_24216});
  }
  default: return heff_nomatch(v_p_24206);
  }
}
V g_heff_2eunify_2euElRigid_lam35(V self, V *args) {
  V v_c_24221 = args[0];
  V v_hd_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_24221, 2, (V[]){heff_dup(v_hd_24219), heff_get(v_hd_24219, LBL_ret)});
}
V g_heff_2eunify_2euElRigid_lam34(V self, V *args) {
  V v_hd_24219 = args[0];
  V v_k2_24220 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_24218 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24222 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euElRigid_lam35, 1, 1, (V[]){heff_dup(v_hd_24219)}), v_p_24218}));
  V v_t_24223 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24219), LBL_malg), 1, (V[]){v_t_24222}));
  V f_ = heff_get(v_hd_24219, LBL_bind);
  args[0] = v_t_24223;
  args[1] = v_k2_24220;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euElRigid_lam36(V self, V *args) {
  V v_hd_24224 = args[0];
  V v_k_24225 = args[1];
  heff_drop(v_hd_24224);
  V f_ = v_k_24225;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eunify_2euTermF_lam1(V self, V *args);
V g_heff_2eunify_2euTermF_lam5(V self, V *args);
V g_heff_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eunify_2euTermF_lam9(V self, V *args);
V g_heff_2eunify_2euTermF_lam8(V self, V *args);
V g_heff_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eunify_2euTermF_lam3(V self, V *args);
Clo g_heff_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_p_249 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  V v_c_2415 = heff_clo(g_heff_2eunify_2euTermF_lam1, 2, 2, (V[]){heff_dup(v_w_240), v_p_249});
  return heff_clo(g_heff_2eunify_2euTermF_lam3, 2, 8, (V[]){v_c_2415, v_ms_241, v_b0_247, v_w_240, v_uf_242, v_cs_245, v_r_243, v_g_244});
}
V g_heff_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_248, LBL_metas); V a_1 = v_a0_246; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTermF_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2410), heff_get(v_hd_2410, LBL_ret)});
}
V g_heff_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam2, 1, 1, (V[]){heff_dup(v_hd_2410)}), v_p_249}));
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2419 = args[0];
  V v_b0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2419, LBL_metas); V a_1 = v_b0_247; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTermF_lam7(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2421), heff_get(v_hd_2421, LBL_ret)});
}
V g_heff_2eunify_2euTermF_lam6(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_p_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_apply(heff_get(v_w_240, LBL_hmap), 2, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam7, 1, 1, (V[]){heff_dup(v_hd_2421)}), v_p_2420}));
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2424}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2425;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euTermF_lam9(V self, V *args) {
  V v_x_2493 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2493);
  V v_t_2494 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = heff_get(v_cs_245, LBL_len); V a_4 = v_x_2427; V r_ = (g_heff_2eunify_2epoisonEl(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_uf_242); r_; });
  return heff_tail(v_t_2494, 2, (V[]){v_hd_2416, v_k_2417});
}
V g_heff_2eunify_2euTermF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_uf_242 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2459;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_VNeu: {
    V v_h_2428 = heff_dup(heff_field(v_x_2418, 0));
    switch (heff_tag_of(v_h_2428)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2428, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2428, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2428, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2459 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2428);
    }
    break;
  }
  case TAG_VCode: {
    V v_it1_2436 = heff_dup(heff_field(v_x_2418, 0));
    switch (heff_tag_of(v_it1_2436)) {
    case TAG_VU: {
      heff_take_n(v_it1_2436, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2438 = heff_field(v_it1_2436, 0);
      heff_take_n(v_it1_2436, 1ULL, 5);
      switch (heff_tag_of(v_h_2438)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2459 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2438);
      }
      break;
    }
    case TAG_VFunction: {
      heff_take_n(v_it1_2436, 0ULL, 4);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      heff_take_n(v_it1_2436, 0ULL, 4);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      heff_take_n(v_it1_2436, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      heff_take_n(v_it1_2436, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it1_2436);
    }
    break;
  }
  case TAG_VLam: {
    v_t_2459 = NTAG(TAG_False);
    break;
  }
  case TAG_VCons: {
    v_t_2459 = NTAG(TAG_False);
    break;
  }
  case TAG_VOpaque: {
    v_t_2459 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2491;
  switch (heff_tag_of(v_t_2459)) {
  case TAG_True: {
    v_t_2491 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2427)) {
    case TAG_VNeu: {
      V v_h_2460 = heff_dup(heff_field(v_x_2427, 0));
      switch (heff_tag_of(v_h_2460)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2460, 0ULL, 1);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2460, 0ULL, 1);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2460, 0ULL, 1);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2491 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2460);
      }
      break;
    }
    case TAG_VCode: {
      V v_it1_2468 = heff_dup(heff_field(v_x_2427, 0));
      switch (heff_tag_of(v_it1_2468)) {
      case TAG_VU: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_h_2470 = heff_field(v_it1_2468, 0);
        heff_take_n(v_it1_2468, 1ULL, 5);
        switch (heff_tag_of(v_h_2470)) {
        case TAG_HLocal: {
          heff_take_n(v_h_2470, 0ULL, 1);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_h_2470, 0ULL, 1);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_h_2470, 0ULL, 1);
          v_t_2491 = NTAG(TAG_False);
          break;
        }
        case TAG_HError: {
          v_t_2491 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_h_2470);
        }
        break;
      }
      case TAG_VFunction: {
        heff_take_n(v_it1_2468, 0ULL, 4);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        heff_take_n(v_it1_2468, 0ULL, 4);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2468);
      }
      break;
    }
    case TAG_VLam: {
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_VCons: {
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_VOpaque: {
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    break;
  }
  default: heff_nomatch(v_t_2459);
  }
  switch (heff_tag_of(v_t_2491)) {
  case TAG_True: {
    heff_drop(v_r_243);
    heff_drop(v_g_244);
    V v_c_2492 = (g_heff_2eunify_2epoisonEl(heff_dup(v_w_240), heff_dup(v_ms_241), v_uf_242, heff_get(heff_dup(v_cs_245), LBL_len), v_x_2418));
    return heff_tail(v_c_2492, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam9, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_cs_245, v_x_2427, v_hd_2416, v_k_2417})});
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24117;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24105 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24106 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24105)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24105, 0ULL, 1);
            heff_drop(v_sp_24106);
            v_it_24117 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24105, 0ULL, 1);
            heff_drop(v_sp_24106);
            v_it_24117 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24112 = heff_field(v_it1_24105, 0);
            V v_ru_24it1_24105_24HMeta = heff_take_reuse_n(v_it1_24105, 1ULL, 1);
            v_it_24117 = heff_tag_at(v_ru_24it1_24105_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24112, v_sp_24106})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24106);
            v_it_24117 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24105);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24117 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24117 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24117 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24117 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24117)) {
        case TAG_Nothing: {
          V v_it_24130;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24118 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24119 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24118)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24118, 0ULL, 1);
              heff_drop(v_sp_24119);
              v_it_24130 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24118, 0ULL, 1);
              heff_drop(v_sp_24119);
              v_it_24130 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24125 = heff_field(v_it1_24118, 0);
              V v_ru_24it1_24118_24HMeta = heff_take_reuse_n(v_it1_24118, 1ULL, 1);
              v_it_24130 = heff_tag_at(v_ru_24it1_24118_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24125, v_sp_24119})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24119);
              v_it_24130 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24118);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24130 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24130 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24130 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24130 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24130)) {
          case TAG_Nothing: {
            V v_t_24143;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24131 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24131)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24131, 0ULL, 1);
                v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24131, 0ULL, 1);
                v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24131, 0ULL, 1);
                v_t_24143 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24131);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24143 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24156;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24144 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24144)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24144, 0ULL, 1);
                v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24144, 0ULL, 1);
                v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24144, 0ULL, 1);
                v_t_24156 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24144);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24156 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24157 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24143; V a_7 = v_t_24156; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24157, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24158 = heff_field(v_it_24130, 0);
            heff_take_n(v_it_24130, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24158)) {
            case TAG_MkPair: {
              V v_m_24159 = heff_field(v_it1_24158, 0);
              V v_sp_24160 = heff_field(v_it1_24158, 1);
              heff_take_n(v_it1_24158, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24159, v_sp_24160, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24158);
            }
          }
          default: return heff_nomatch(v_it_24130);
          }
        }
        case TAG_Just: {
          V v_it1_24161 = heff_field(v_it_24117, 0);
          heff_take_n(v_it_24117, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24161)) {
          case TAG_MkPair: {
            V v_m_24162 = heff_field(v_it1_24161, 0);
            V v_sp_24163 = heff_field(v_it1_24161, 1);
            heff_take_n(v_it1_24161, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24162, v_sp_24163, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24161);
          }
        }
        default: return heff_nomatch(v_it_24117);
        }
      }
      case TAG_VCode: {
        V v_it_24177;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24165 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24166 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24165)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24165, 0ULL, 1);
            heff_drop(v_sp_24166);
            v_it_24177 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24165, 0ULL, 1);
            heff_drop(v_sp_24166);
            v_it_24177 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24172 = heff_field(v_it1_24165, 0);
            V v_ru_24it1_24165_24HMeta = heff_take_reuse_n(v_it1_24165, 1ULL, 1);
            v_it_24177 = heff_tag_at(v_ru_24it1_24165_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24172, v_sp_24166})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24166);
            v_it_24177 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24165);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24177 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24177 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24177 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24177 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24177)) {
        case TAG_Nothing: {
          V v_it_24190;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24178 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24179 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24178)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24178, 0ULL, 1);
              heff_drop(v_sp_24179);
              v_it_24190 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24178, 0ULL, 1);
              heff_drop(v_sp_24179);
              v_it_24190 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24185 = heff_field(v_it1_24178, 0);
              V v_ru_24it1_24178_24HMeta = heff_take_reuse_n(v_it1_24178, 1ULL, 1);
              v_it_24190 = heff_tag_at(v_ru_24it1_24178_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24185, v_sp_24179})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24179);
              v_it_24190 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24178);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24190 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24190 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24190 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24190 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24190)) {
          case TAG_Nothing: {
            V v_t_24203;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24191 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24191)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24191, 0ULL, 1);
                v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24191, 0ULL, 1);
                v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24191, 0ULL, 1);
                v_t_24203 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24191);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24203 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24216;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24204 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24204)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24204, 0ULL, 1);
                v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24204, 0ULL, 1);
                v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24204, 0ULL, 1);
                v_t_24216 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24204);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24216 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24217 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24203; V a_7 = v_t_24216; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24217, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24218 = heff_field(v_it_24190, 0);
            heff_take_n(v_it_24190, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24218)) {
            case TAG_MkPair: {
              V v_m_24219 = heff_field(v_it1_24218, 0);
              V v_sp_24220 = heff_field(v_it1_24218, 1);
              heff_take_n(v_it1_24218, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24219, v_sp_24220, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24218);
            }
          }
          default: return heff_nomatch(v_it_24190);
          }
        }
        case TAG_Just: {
          V v_it1_24221 = heff_field(v_it_24177, 0);
          heff_take_n(v_it_24177, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24221)) {
          case TAG_MkPair: {
            V v_m_24222 = heff_field(v_it1_24221, 0);
            V v_sp_24223 = heff_field(v_it1_24221, 1);
            heff_take_n(v_it1_24221, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24222, v_sp_24223, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24221);
          }
        }
        default: return heff_nomatch(v_it_24177);
        }
      }
      case TAG_VLam: {
        V v_it_24238;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24226 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24227 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24226)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24226, 0ULL, 1);
            heff_drop(v_sp_24227);
            v_it_24238 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24226, 0ULL, 1);
            heff_drop(v_sp_24227);
            v_it_24238 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24233 = heff_field(v_it1_24226, 0);
            V v_ru_24it1_24226_24HMeta = heff_take_reuse_n(v_it1_24226, 1ULL, 1);
            v_it_24238 = heff_tag_at(v_ru_24it1_24226_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24233, v_sp_24227})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24227);
            v_it_24238 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24226);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24238 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24238 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24238 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24238 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24238)) {
        case TAG_Nothing: {
          V v_it_24251;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24239 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24240 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24239)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24239, 0ULL, 1);
              heff_drop(v_sp_24240);
              v_it_24251 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24239, 0ULL, 1);
              heff_drop(v_sp_24240);
              v_it_24251 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24246 = heff_field(v_it1_24239, 0);
              V v_ru_24it1_24239_24HMeta = heff_take_reuse_n(v_it1_24239, 1ULL, 1);
              v_it_24251 = heff_tag_at(v_ru_24it1_24239_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24246, v_sp_24240})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24240);
              v_it_24251 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24239);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24251 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24251 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24251 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24251 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24251)) {
          case TAG_Nothing: {
            V v_t_24264;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24252 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24252)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24252, 0ULL, 1);
                v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24252, 0ULL, 1);
                v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24252, 0ULL, 1);
                v_t_24264 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24252);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24264 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24277;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24265 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24265)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24265, 0ULL, 1);
                v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24265, 0ULL, 1);
                v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24265, 0ULL, 1);
                v_t_24277 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24265);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24277 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24278 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24264; V a_7 = v_t_24277; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24278, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24279 = heff_field(v_it_24251, 0);
            heff_take_n(v_it_24251, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24279)) {
            case TAG_MkPair: {
              V v_m_24280 = heff_field(v_it1_24279, 0);
              V v_sp_24281 = heff_field(v_it1_24279, 1);
              heff_take_n(v_it1_24279, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24280, v_sp_24281, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24279);
            }
          }
          default: return heff_nomatch(v_it_24251);
          }
        }
        case TAG_Just: {
          V v_it1_24282 = heff_field(v_it_24238, 0);
          heff_take_n(v_it_24238, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24282)) {
          case TAG_MkPair: {
            V v_m_24283 = heff_field(v_it1_24282, 0);
            V v_sp_24284 = heff_field(v_it1_24282, 1);
            heff_take_n(v_it1_24282, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24283, v_sp_24284, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24282);
          }
        }
        default: return heff_nomatch(v_it_24238);
        }
      }
      case TAG_VCons: {
        V v_it_24298;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24286 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24287 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24286)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24286, 0ULL, 1);
            heff_drop(v_sp_24287);
            v_it_24298 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24286, 0ULL, 1);
            heff_drop(v_sp_24287);
            v_it_24298 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24293 = heff_field(v_it1_24286, 0);
            V v_ru_24it1_24286_24HMeta = heff_take_reuse_n(v_it1_24286, 1ULL, 1);
            v_it_24298 = heff_tag_at(v_ru_24it1_24286_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24293, v_sp_24287})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24287);
            v_it_24298 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24286);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24298 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24298 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24298 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24298 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24298)) {
        case TAG_Nothing: {
          V v_it_24311;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24299 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24300 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24299)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24299, 0ULL, 1);
              heff_drop(v_sp_24300);
              v_it_24311 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24299, 0ULL, 1);
              heff_drop(v_sp_24300);
              v_it_24311 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24306 = heff_field(v_it1_24299, 0);
              V v_ru_24it1_24299_24HMeta = heff_take_reuse_n(v_it1_24299, 1ULL, 1);
              v_it_24311 = heff_tag_at(v_ru_24it1_24299_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24306, v_sp_24300})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24300);
              v_it_24311 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24299);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24311 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24311 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24311 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24311 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24311)) {
          case TAG_Nothing: {
            V v_t_24324;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24312 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24312)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24312, 0ULL, 1);
                v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24312, 0ULL, 1);
                v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24312, 0ULL, 1);
                v_t_24324 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24312);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24324 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24337;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24325 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24325)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24325, 0ULL, 1);
                v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24325, 0ULL, 1);
                v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24325, 0ULL, 1);
                v_t_24337 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24325);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24337 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24338 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24324; V a_7 = v_t_24337; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24338, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24339 = heff_field(v_it_24311, 0);
            heff_take_n(v_it_24311, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24339)) {
            case TAG_MkPair: {
              V v_m_24340 = heff_field(v_it1_24339, 0);
              V v_sp_24341 = heff_field(v_it1_24339, 1);
              heff_take_n(v_it1_24339, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24340, v_sp_24341, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24339);
            }
          }
          default: return heff_nomatch(v_it_24311);
          }
        }
        case TAG_Just: {
          V v_it1_24342 = heff_field(v_it_24298, 0);
          heff_take_n(v_it_24298, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24342)) {
          case TAG_MkPair: {
            V v_m_24343 = heff_field(v_it1_24342, 0);
            V v_sp_24344 = heff_field(v_it1_24342, 1);
            heff_take_n(v_it1_24342, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24343, v_sp_24344, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24342);
          }
        }
        default: return heff_nomatch(v_it_24298);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 5);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24363;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24351 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24352 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24351)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24351, 0ULL, 1);
            heff_drop(v_sp_24352);
            v_it_24363 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24351, 0ULL, 1);
            heff_drop(v_sp_24352);
            v_it_24363 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24358 = heff_field(v_it1_24351, 0);
            V v_ru_24it1_24351_24HMeta = heff_take_reuse_n(v_it1_24351, 1ULL, 1);
            v_it_24363 = heff_tag_at(v_ru_24it1_24351_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24358, v_sp_24352})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24352);
            v_it_24363 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24351);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24363 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24363 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24363 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24363 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24363)) {
        case TAG_Nothing: {
          V v_it_24376;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24364 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24365 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24364)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24364, 0ULL, 1);
              heff_drop(v_sp_24365);
              v_it_24376 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24364, 0ULL, 1);
              heff_drop(v_sp_24365);
              v_it_24376 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24371 = heff_field(v_it1_24364, 0);
              V v_ru_24it1_24364_24HMeta = heff_take_reuse_n(v_it1_24364, 1ULL, 1);
              v_it_24376 = heff_tag_at(v_ru_24it1_24364_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24371, v_sp_24365})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24365);
              v_it_24376 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24364);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24376 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24376 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24376 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24376 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24376)) {
          case TAG_Nothing: {
            V v_t_24389;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24377 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24377)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24377, 0ULL, 1);
                v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24377, 0ULL, 1);
                v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24377, 0ULL, 1);
                v_t_24389 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24377);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24389 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24402;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24390 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24390)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24390, 0ULL, 1);
                v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24390, 0ULL, 1);
                v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24390, 0ULL, 1);
                v_t_24402 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24390);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24402 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24403 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24389; V a_7 = v_t_24402; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24403, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24404 = heff_field(v_it_24376, 0);
            heff_take_n(v_it_24376, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24404)) {
            case TAG_MkPair: {
              V v_m_24405 = heff_field(v_it1_24404, 0);
              V v_sp_24406 = heff_field(v_it1_24404, 1);
              heff_take_n(v_it1_24404, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24405, v_sp_24406, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24404);
            }
          }
          default: return heff_nomatch(v_it_24376);
          }
        }
        case TAG_Just: {
          V v_it1_24407 = heff_field(v_it_24363, 0);
          heff_take_n(v_it_24363, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24407)) {
          case TAG_MkPair: {
            V v_m_24408 = heff_field(v_it1_24407, 0);
            V v_sp_24409 = heff_field(v_it1_24407, 1);
            heff_take_n(v_it1_24407, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24408, v_sp_24409, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24407);
          }
        }
        default: return heff_nomatch(v_it_24363);
        }
      }
      case TAG_VCode: {
        V v_it_24423;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24411 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24412 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24411)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24411, 0ULL, 1);
            heff_drop(v_sp_24412);
            v_it_24423 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24411, 0ULL, 1);
            heff_drop(v_sp_24412);
            v_it_24423 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24418 = heff_field(v_it1_24411, 0);
            V v_ru_24it1_24411_24HMeta = heff_take_reuse_n(v_it1_24411, 1ULL, 1);
            v_it_24423 = heff_tag_at(v_ru_24it1_24411_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24418, v_sp_24412})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24412);
            v_it_24423 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24411);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24423 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24423)) {
        case TAG_Nothing: {
          V v_it_24436;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24424 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24425 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24424)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24424, 0ULL, 1);
              heff_drop(v_sp_24425);
              v_it_24436 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24424, 0ULL, 1);
              heff_drop(v_sp_24425);
              v_it_24436 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24431 = heff_field(v_it1_24424, 0);
              V v_ru_24it1_24424_24HMeta = heff_take_reuse_n(v_it1_24424, 1ULL, 1);
              v_it_24436 = heff_tag_at(v_ru_24it1_24424_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24431, v_sp_24425})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24425);
              v_it_24436 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24424);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24436 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24436 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24436 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24436 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24436)) {
          case TAG_Nothing: {
            V v_t_24449;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24437 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24437)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24437, 0ULL, 1);
                v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24437, 0ULL, 1);
                v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24437, 0ULL, 1);
                v_t_24449 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24437);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24449 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24462;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24450 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24450)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24450, 0ULL, 1);
                v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24450, 0ULL, 1);
                v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24450, 0ULL, 1);
                v_t_24462 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24450);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24462 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24463 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24449; V a_7 = v_t_24462; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24463, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24464 = heff_field(v_it_24436, 0);
            heff_take_n(v_it_24436, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24464)) {
            case TAG_MkPair: {
              V v_m_24465 = heff_field(v_it1_24464, 0);
              V v_sp_24466 = heff_field(v_it1_24464, 1);
              heff_take_n(v_it1_24464, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24465, v_sp_24466, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24464);
            }
          }
          default: return heff_nomatch(v_it_24436);
          }
        }
        case TAG_Just: {
          V v_it1_24467 = heff_field(v_it_24423, 0);
          heff_take_n(v_it_24423, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24467)) {
          case TAG_MkPair: {
            V v_m_24468 = heff_field(v_it1_24467, 0);
            V v_sp_24469 = heff_field(v_it1_24467, 1);
            heff_take_n(v_it1_24467, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24468, v_sp_24469, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24467);
          }
        }
        default: return heff_nomatch(v_it_24423);
        }
      }
      case TAG_VLam: {
        V v_it_24484;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24472 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24473 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24472)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24472, 0ULL, 1);
            heff_drop(v_sp_24473);
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24472, 0ULL, 1);
            heff_drop(v_sp_24473);
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24479 = heff_field(v_it1_24472, 0);
            V v_ru_24it1_24472_24HMeta = heff_take_reuse_n(v_it1_24472, 1ULL, 1);
            v_it_24484 = heff_tag_at(v_ru_24it1_24472_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24479, v_sp_24473})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24473);
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24472);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24484 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24484 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24484 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24484 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24484)) {
        case TAG_Nothing: {
          V v_it_24497;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24485 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24486 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24485)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24485, 0ULL, 1);
              heff_drop(v_sp_24486);
              v_it_24497 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24485, 0ULL, 1);
              heff_drop(v_sp_24486);
              v_it_24497 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24492 = heff_field(v_it1_24485, 0);
              V v_ru_24it1_24485_24HMeta = heff_take_reuse_n(v_it1_24485, 1ULL, 1);
              v_it_24497 = heff_tag_at(v_ru_24it1_24485_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24492, v_sp_24486})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24486);
              v_it_24497 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24485);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24497 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24497 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24497 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24497 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24497)) {
          case TAG_Nothing: {
            V v_t_24510;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24498 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24498)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24498, 0ULL, 1);
                v_t_24510 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24498);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24510 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24523;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24511 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24511)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24511, 0ULL, 1);
                v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24511, 0ULL, 1);
                v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24511, 0ULL, 1);
                v_t_24523 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24511);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24523 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24524 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24510; V a_7 = v_t_24523; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24524, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24525 = heff_field(v_it_24497, 0);
            heff_take_n(v_it_24497, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24525)) {
            case TAG_MkPair: {
              V v_m_24526 = heff_field(v_it1_24525, 0);
              V v_sp_24527 = heff_field(v_it1_24525, 1);
              heff_take_n(v_it1_24525, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24526, v_sp_24527, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24525);
            }
          }
          default: return heff_nomatch(v_it_24497);
          }
        }
        case TAG_Just: {
          V v_it1_24528 = heff_field(v_it_24484, 0);
          heff_take_n(v_it_24484, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24528)) {
          case TAG_MkPair: {
            V v_m_24529 = heff_field(v_it1_24528, 0);
            V v_sp_24530 = heff_field(v_it1_24528, 1);
            heff_take_n(v_it1_24528, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24529, v_sp_24530, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24528);
          }
        }
        default: return heff_nomatch(v_it_24484);
        }
      }
      case TAG_VCons: {
        V v_it_24544;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24532 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24533 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24532)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24532, 0ULL, 1);
            heff_drop(v_sp_24533);
            v_it_24544 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24532, 0ULL, 1);
            heff_drop(v_sp_24533);
            v_it_24544 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24539 = heff_field(v_it1_24532, 0);
            V v_ru_24it1_24532_24HMeta = heff_take_reuse_n(v_it1_24532, 1ULL, 1);
            v_it_24544 = heff_tag_at(v_ru_24it1_24532_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24539, v_sp_24533})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24533);
            v_it_24544 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24532);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24544 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24544 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24544 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24544 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24544)) {
        case TAG_Nothing: {
          V v_it_24557;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24545 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24546 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24545)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24545, 0ULL, 1);
              heff_drop(v_sp_24546);
              v_it_24557 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24545, 0ULL, 1);
              heff_drop(v_sp_24546);
              v_it_24557 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24552 = heff_field(v_it1_24545, 0);
              V v_ru_24it1_24545_24HMeta = heff_take_reuse_n(v_it1_24545, 1ULL, 1);
              v_it_24557 = heff_tag_at(v_ru_24it1_24545_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24552, v_sp_24546})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24546);
              v_it_24557 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24545);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24557 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24557 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24557 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24557 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24557)) {
          case TAG_Nothing: {
            V v_t_24570;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24558 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24558)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24558, 0ULL, 1);
                v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24558, 0ULL, 1);
                v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24558, 0ULL, 1);
                v_t_24570 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24558);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24570 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24583;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24571 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24571)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24571, 0ULL, 1);
                v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24571, 0ULL, 1);
                v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24571, 0ULL, 1);
                v_t_24583 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24571);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24583 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24584 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24570; V a_7 = v_t_24583; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24584, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24585 = heff_field(v_it_24557, 0);
            heff_take_n(v_it_24557, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24585)) {
            case TAG_MkPair: {
              V v_m_24586 = heff_field(v_it1_24585, 0);
              V v_sp_24587 = heff_field(v_it1_24585, 1);
              heff_take_n(v_it1_24585, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24586, v_sp_24587, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24585);
            }
          }
          default: return heff_nomatch(v_it_24557);
          }
        }
        case TAG_Just: {
          V v_it1_24588 = heff_field(v_it_24544, 0);
          heff_take_n(v_it_24544, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24588)) {
          case TAG_MkPair: {
            V v_m_24589 = heff_field(v_it1_24588, 0);
            V v_sp_24590 = heff_field(v_it1_24588, 1);
            heff_take_n(v_it1_24588, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24589, v_sp_24590, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24588);
          }
        }
        default: return heff_nomatch(v_it_24544);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 1);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24610;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24598 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24599 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24598)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24598, 0ULL, 1);
            heff_drop(v_sp_24599);
            v_it_24610 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24598, 0ULL, 1);
            heff_drop(v_sp_24599);
            v_it_24610 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24605 = heff_field(v_it1_24598, 0);
            V v_ru_24it1_24598_24HMeta = heff_take_reuse_n(v_it1_24598, 1ULL, 1);
            v_it_24610 = heff_tag_at(v_ru_24it1_24598_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24605, v_sp_24599})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24599);
            v_it_24610 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24598);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24610 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24610 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24610 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24610 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24610)) {
        case TAG_Nothing: {
          V v_it_24623;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24611 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24612 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24611)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24611, 0ULL, 1);
              heff_drop(v_sp_24612);
              v_it_24623 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24611, 0ULL, 1);
              heff_drop(v_sp_24612);
              v_it_24623 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24618 = heff_field(v_it1_24611, 0);
              V v_ru_24it1_24611_24HMeta = heff_take_reuse_n(v_it1_24611, 1ULL, 1);
              v_it_24623 = heff_tag_at(v_ru_24it1_24611_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24618, v_sp_24612})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24612);
              v_it_24623 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24611);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24623 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24623 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24623 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24623 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24623)) {
          case TAG_Nothing: {
            V v_t_24636;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24624 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24624)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24624, 0ULL, 1);
                v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24624, 0ULL, 1);
                v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24624, 0ULL, 1);
                v_t_24636 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24624);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24636 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24649;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24637 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24637)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24637, 0ULL, 1);
                v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24637, 0ULL, 1);
                v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24637, 0ULL, 1);
                v_t_24649 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24637);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24649 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24650 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24636; V a_7 = v_t_24649; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24650, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24651 = heff_field(v_it_24623, 0);
            heff_take_n(v_it_24623, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24651)) {
            case TAG_MkPair: {
              V v_m_24652 = heff_field(v_it1_24651, 0);
              V v_sp_24653 = heff_field(v_it1_24651, 1);
              heff_take_n(v_it1_24651, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24652, v_sp_24653, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24651);
            }
          }
          default: return heff_nomatch(v_it_24623);
          }
        }
        case TAG_Just: {
          V v_it1_24654 = heff_field(v_it_24610, 0);
          heff_take_n(v_it_24610, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24654)) {
          case TAG_MkPair: {
            V v_m_24655 = heff_field(v_it1_24654, 0);
            V v_sp_24656 = heff_field(v_it1_24654, 1);
            heff_take_n(v_it1_24654, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24655, v_sp_24656, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24654);
          }
        }
        default: return heff_nomatch(v_it_24610);
        }
      }
      case TAG_VCode: {
        V v_it_24670;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24658 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24659 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24658)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24658, 0ULL, 1);
            heff_drop(v_sp_24659);
            v_it_24670 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24658, 0ULL, 1);
            heff_drop(v_sp_24659);
            v_it_24670 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24665 = heff_field(v_it1_24658, 0);
            V v_ru_24it1_24658_24HMeta = heff_take_reuse_n(v_it1_24658, 1ULL, 1);
            v_it_24670 = heff_tag_at(v_ru_24it1_24658_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24665, v_sp_24659})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24659);
            v_it_24670 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24658);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24670 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24670 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24670 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24670 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24670)) {
        case TAG_Nothing: {
          V v_it_24683;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24671 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24672 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24671)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24671, 0ULL, 1);
              heff_drop(v_sp_24672);
              v_it_24683 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24671, 0ULL, 1);
              heff_drop(v_sp_24672);
              v_it_24683 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24678 = heff_field(v_it1_24671, 0);
              V v_ru_24it1_24671_24HMeta = heff_take_reuse_n(v_it1_24671, 1ULL, 1);
              v_it_24683 = heff_tag_at(v_ru_24it1_24671_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24678, v_sp_24672})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24672);
              v_it_24683 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24671);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24683 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24683 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24683 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24683 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24683)) {
          case TAG_Nothing: {
            V v_t_24696;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24684 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24684)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24684, 0ULL, 1);
                v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24684, 0ULL, 1);
                v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24684, 0ULL, 1);
                v_t_24696 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24684);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24696 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24709;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24697 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24697)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24697, 0ULL, 1);
                v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24697, 0ULL, 1);
                v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24697, 0ULL, 1);
                v_t_24709 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24697);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24709 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24710 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24696; V a_7 = v_t_24709; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24710, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24711 = heff_field(v_it_24683, 0);
            heff_take_n(v_it_24683, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24711)) {
            case TAG_MkPair: {
              V v_m_24712 = heff_field(v_it1_24711, 0);
              V v_sp_24713 = heff_field(v_it1_24711, 1);
              heff_take_n(v_it1_24711, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24712, v_sp_24713, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24711);
            }
          }
          default: return heff_nomatch(v_it_24683);
          }
        }
        case TAG_Just: {
          V v_it1_24714 = heff_field(v_it_24670, 0);
          heff_take_n(v_it_24670, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24714)) {
          case TAG_MkPair: {
            V v_m_24715 = heff_field(v_it1_24714, 0);
            V v_sp_24716 = heff_field(v_it1_24714, 1);
            heff_take_n(v_it1_24714, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24715, v_sp_24716, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24714);
          }
        }
        default: return heff_nomatch(v_it_24670);
        }
      }
      case TAG_VLam: {
        V v_it_24731;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24719 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24720 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24719)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24719, 0ULL, 1);
            heff_drop(v_sp_24720);
            v_it_24731 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24719, 0ULL, 1);
            heff_drop(v_sp_24720);
            v_it_24731 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24726 = heff_field(v_it1_24719, 0);
            V v_ru_24it1_24719_24HMeta = heff_take_reuse_n(v_it1_24719, 1ULL, 1);
            v_it_24731 = heff_tag_at(v_ru_24it1_24719_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24726, v_sp_24720})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24720);
            v_it_24731 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24719);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24731 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24731 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24731 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24731 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24731)) {
        case TAG_Nothing: {
          V v_it_24744;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24732 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24733 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24732)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24732, 0ULL, 1);
              heff_drop(v_sp_24733);
              v_it_24744 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24732, 0ULL, 1);
              heff_drop(v_sp_24733);
              v_it_24744 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24739 = heff_field(v_it1_24732, 0);
              V v_ru_24it1_24732_24HMeta = heff_take_reuse_n(v_it1_24732, 1ULL, 1);
              v_it_24744 = heff_tag_at(v_ru_24it1_24732_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24739, v_sp_24733})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24733);
              v_it_24744 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24732);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24744 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24744 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24744 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24744 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24744)) {
          case TAG_Nothing: {
            V v_t_24757;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24745 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24745)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24745, 0ULL, 1);
                v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24745, 0ULL, 1);
                v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24745, 0ULL, 1);
                v_t_24757 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24745);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24757 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24770;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24758 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24758)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24758, 0ULL, 1);
                v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24758, 0ULL, 1);
                v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24758, 0ULL, 1);
                v_t_24770 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24758);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24770 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24771 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24757; V a_7 = v_t_24770; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24771, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24772 = heff_field(v_it_24744, 0);
            heff_take_n(v_it_24744, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24772)) {
            case TAG_MkPair: {
              V v_m_24773 = heff_field(v_it1_24772, 0);
              V v_sp_24774 = heff_field(v_it1_24772, 1);
              heff_take_n(v_it1_24772, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24773, v_sp_24774, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24772);
            }
          }
          default: return heff_nomatch(v_it_24744);
          }
        }
        case TAG_Just: {
          V v_it1_24775 = heff_field(v_it_24731, 0);
          heff_take_n(v_it_24731, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24775)) {
          case TAG_MkPair: {
            V v_m_24776 = heff_field(v_it1_24775, 0);
            V v_sp_24777 = heff_field(v_it1_24775, 1);
            heff_take_n(v_it1_24775, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24776, v_sp_24777, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24775);
          }
        }
        default: return heff_nomatch(v_it_24731);
        }
      }
      case TAG_VCons: {
        V v_it_24791;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24779 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24780 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24779)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24779, 0ULL, 1);
            heff_drop(v_sp_24780);
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24779, 0ULL, 1);
            heff_drop(v_sp_24780);
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24786 = heff_field(v_it1_24779, 0);
            V v_ru_24it1_24779_24HMeta = heff_take_reuse_n(v_it1_24779, 1ULL, 1);
            v_it_24791 = heff_tag_at(v_ru_24it1_24779_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24786, v_sp_24780})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24780);
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24779);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24791 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24791 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24791 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24791 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24791)) {
        case TAG_Nothing: {
          V v_it_24804;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24792 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24793 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24792)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24792, 0ULL, 1);
              heff_drop(v_sp_24793);
              v_it_24804 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24792, 0ULL, 1);
              heff_drop(v_sp_24793);
              v_it_24804 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24799 = heff_field(v_it1_24792, 0);
              V v_ru_24it1_24792_24HMeta = heff_take_reuse_n(v_it1_24792, 1ULL, 1);
              v_it_24804 = heff_tag_at(v_ru_24it1_24792_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24799, v_sp_24793})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24793);
              v_it_24804 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24792);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24804 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24804 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24804 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24804 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24804)) {
          case TAG_Nothing: {
            V v_t_24817;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24805 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24805)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24805, 0ULL, 1);
                v_t_24817 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24805);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24817 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24830;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24818 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24818)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24818, 0ULL, 1);
                v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24818, 0ULL, 1);
                v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24818, 0ULL, 1);
                v_t_24830 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24818);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24830 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24831 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24817; V a_7 = v_t_24830; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24831, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24832 = heff_field(v_it_24804, 0);
            heff_take_n(v_it_24804, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24832)) {
            case TAG_MkPair: {
              V v_m_24833 = heff_field(v_it1_24832, 0);
              V v_sp_24834 = heff_field(v_it1_24832, 1);
              heff_take_n(v_it1_24832, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24833, v_sp_24834, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24832);
            }
          }
          default: return heff_nomatch(v_it_24804);
          }
        }
        case TAG_Just: {
          V v_it1_24835 = heff_field(v_it_24791, 0);
          heff_take_n(v_it_24791, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24835)) {
          case TAG_MkPair: {
            V v_m_24836 = heff_field(v_it1_24835, 0);
            V v_sp_24837 = heff_field(v_it1_24835, 1);
            heff_take_n(v_it1_24835, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24836, v_sp_24837, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24835);
          }
        }
        default: return heff_nomatch(v_it_24791);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 2);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2427)) {
      case TAG_VNeu: {
        V v_it_24856;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24844 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24845 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24844)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24844, 0ULL, 1);
            heff_drop(v_sp_24845);
            v_it_24856 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24844, 0ULL, 1);
            heff_drop(v_sp_24845);
            v_it_24856 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24851 = heff_field(v_it1_24844, 0);
            V v_ru_24it1_24844_24HMeta = heff_take_reuse_n(v_it1_24844, 1ULL, 1);
            v_it_24856 = heff_tag_at(v_ru_24it1_24844_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24851, v_sp_24845})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24845);
            v_it_24856 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24844);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24856 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24856 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24856 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24856 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24856)) {
        case TAG_Nothing: {
          V v_it_24869;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24857 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24858 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24857)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24857, 0ULL, 1);
              heff_drop(v_sp_24858);
              v_it_24869 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24857, 0ULL, 1);
              heff_drop(v_sp_24858);
              v_it_24869 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24864 = heff_field(v_it1_24857, 0);
              V v_ru_24it1_24857_24HMeta = heff_take_reuse_n(v_it1_24857, 1ULL, 1);
              v_it_24869 = heff_tag_at(v_ru_24it1_24857_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24864, v_sp_24858})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24858);
              v_it_24869 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24857);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24869 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24869 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24869 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24869 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24869)) {
          case TAG_Nothing: {
            V v_t_24882;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24870 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24870)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24870, 0ULL, 1);
                v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24870, 0ULL, 1);
                v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24870, 0ULL, 1);
                v_t_24882 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24870);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24882 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24895;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24883 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24883)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24883, 0ULL, 1);
                v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24883, 0ULL, 1);
                v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24883, 0ULL, 1);
                v_t_24895 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24883);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24895 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24896 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24882; V a_7 = v_t_24895; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24896, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24897 = heff_field(v_it_24869, 0);
            heff_take_n(v_it_24869, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24897)) {
            case TAG_MkPair: {
              V v_m_24898 = heff_field(v_it1_24897, 0);
              V v_sp_24899 = heff_field(v_it1_24897, 1);
              heff_take_n(v_it1_24897, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24898, v_sp_24899, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24897);
            }
          }
          default: return heff_nomatch(v_it_24869);
          }
        }
        case TAG_Just: {
          V v_it1_24900 = heff_field(v_it_24856, 0);
          heff_take_n(v_it_24856, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24900)) {
          case TAG_MkPair: {
            V v_m_24901 = heff_field(v_it1_24900, 0);
            V v_sp_24902 = heff_field(v_it1_24900, 1);
            heff_take_n(v_it1_24900, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24901, v_sp_24902, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24900);
          }
        }
        default: return heff_nomatch(v_it_24856);
        }
      }
      case TAG_VCode: {
        V v_it_24916;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24904 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24905 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24904)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24904, 0ULL, 1);
            heff_drop(v_sp_24905);
            v_it_24916 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24904, 0ULL, 1);
            heff_drop(v_sp_24905);
            v_it_24916 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24911 = heff_field(v_it1_24904, 0);
            V v_ru_24it1_24904_24HMeta = heff_take_reuse_n(v_it1_24904, 1ULL, 1);
            v_it_24916 = heff_tag_at(v_ru_24it1_24904_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24911, v_sp_24905})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24905);
            v_it_24916 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24904);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24916 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24916 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24916 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24916 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24916)) {
        case TAG_Nothing: {
          V v_it_24929;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24917 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24918 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24917)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24917, 0ULL, 1);
              heff_drop(v_sp_24918);
              v_it_24929 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24917, 0ULL, 1);
              heff_drop(v_sp_24918);
              v_it_24929 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24924 = heff_field(v_it1_24917, 0);
              V v_ru_24it1_24917_24HMeta = heff_take_reuse_n(v_it1_24917, 1ULL, 1);
              v_it_24929 = heff_tag_at(v_ru_24it1_24917_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24924, v_sp_24918})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24918);
              v_it_24929 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24917);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24929 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24929 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24929 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24929 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24929)) {
          case TAG_Nothing: {
            V v_t_24942;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24930 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24930)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24930, 0ULL, 1);
                v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24930, 0ULL, 1);
                v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24930, 0ULL, 1);
                v_t_24942 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24930);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24942 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_24955;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_24943 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_24943)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24943, 0ULL, 1);
                v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24943, 0ULL, 1);
                v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24943, 0ULL, 1);
                v_t_24955 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_24943);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24955 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_24956 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24942; V a_7 = v_t_24955; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24956, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_24957 = heff_field(v_it_24929, 0);
            heff_take_n(v_it_24929, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24957)) {
            case TAG_MkPair: {
              V v_m_24958 = heff_field(v_it1_24957, 0);
              V v_sp_24959 = heff_field(v_it1_24957, 1);
              heff_take_n(v_it1_24957, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24958, v_sp_24959, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_24957);
            }
          }
          default: return heff_nomatch(v_it_24929);
          }
        }
        case TAG_Just: {
          V v_it1_24960 = heff_field(v_it_24916, 0);
          heff_take_n(v_it_24916, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24960)) {
          case TAG_MkPair: {
            V v_m_24961 = heff_field(v_it1_24960, 0);
            V v_sp_24962 = heff_field(v_it1_24960, 1);
            heff_take_n(v_it1_24960, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_24961, v_sp_24962, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_24960);
          }
        }
        default: return heff_nomatch(v_it_24916);
        }
      }
      case TAG_VLam: {
        V v_it_24977;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_24965 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_24966 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_24965)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_24965, 0ULL, 1);
            heff_drop(v_sp_24966);
            v_it_24977 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_24965, 0ULL, 1);
            heff_drop(v_sp_24966);
            v_it_24977 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24972 = heff_field(v_it1_24965, 0);
            V v_ru_24it1_24965_24HMeta = heff_take_reuse_n(v_it1_24965, 1ULL, 1);
            v_it_24977 = heff_tag_at(v_ru_24it1_24965_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24972, v_sp_24966})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24966);
            v_it_24977 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_24965);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24977 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24977 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24977 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24977 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_24977)) {
        case TAG_Nothing: {
          V v_it_24990;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_24978 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_24979 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_24978)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_24978, 0ULL, 1);
              heff_drop(v_sp_24979);
              v_it_24990 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_24978, 0ULL, 1);
              heff_drop(v_sp_24979);
              v_it_24990 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24985 = heff_field(v_it1_24978, 0);
              V v_ru_24it1_24978_24HMeta = heff_take_reuse_n(v_it1_24978, 1ULL, 1);
              v_it_24990 = heff_tag_at(v_ru_24it1_24978_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_24985, v_sp_24979})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24979);
              v_it_24990 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_24978);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24990 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24990 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24990 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24990 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_24990)) {
          case TAG_Nothing: {
            V v_t_241003;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_24991 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_24991)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_24991, 0ULL, 1);
                v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_24991, 0ULL, 1);
                v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_24991, 0ULL, 1);
                v_t_241003 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_24991);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241003 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_241016;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_241004 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_241004)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_241004, 0ULL, 1);
                v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_241004, 0ULL, 1);
                v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_241004, 0ULL, 1);
                v_t_241016 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_241004);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241016 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_241017 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_241003; V a_7 = v_t_241016; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_241017, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_241018 = heff_field(v_it_24990, 0);
            heff_take_n(v_it_24990, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_241018)) {
            case TAG_MkPair: {
              V v_m_241019 = heff_field(v_it1_241018, 0);
              V v_sp_241020 = heff_field(v_it1_241018, 1);
              heff_take_n(v_it1_241018, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241019, v_sp_241020, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_241018);
            }
          }
          default: return heff_nomatch(v_it_24990);
          }
        }
        case TAG_Just: {
          V v_it1_241021 = heff_field(v_it_24977, 0);
          heff_take_n(v_it_24977, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_241021)) {
          case TAG_MkPair: {
            V v_m_241022 = heff_field(v_it1_241021, 0);
            V v_sp_241023 = heff_field(v_it1_241021, 1);
            heff_take_n(v_it1_241021, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241022, v_sp_241023, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_241021);
          }
        }
        default: return heff_nomatch(v_it_24977);
        }
      }
      case TAG_VCons: {
        V v_it_241037;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_VNeu: {
          V v_it1_241025 = heff_dup(heff_field(v_x_2418, 0));
          V v_sp_241026 = heff_dup(heff_field(v_x_2418, 1));
          switch (heff_tag_of(v_it1_241025)) {
          case TAG_HLocal: {
            heff_take_n(v_it1_241025, 0ULL, 1);
            heff_drop(v_sp_241026);
            v_it_241037 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_it1_241025, 0ULL, 1);
            heff_drop(v_sp_241026);
            v_it_241037 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_241032 = heff_field(v_it1_241025, 0);
            V v_ru_24it1_241025_24HMeta = heff_take_reuse_n(v_it1_241025, 1ULL, 1);
            v_it_241037 = heff_tag_at(v_ru_24it1_241025_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_241032, v_sp_241026})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_241026);
            v_it_241037 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_241025);
          }
          break;
        }
        case TAG_VCode: {
          v_it_241037 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_241037 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_241037 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_241037 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        switch (heff_tag_of(v_it_241037)) {
        case TAG_Nothing: {
          V v_it_241050;
          switch (heff_tag_of(v_x_2427)) {
          case TAG_VNeu: {
            V v_it1_241038 = heff_dup(heff_field(v_x_2427, 0));
            V v_sp_241039 = heff_dup(heff_field(v_x_2427, 1));
            switch (heff_tag_of(v_it1_241038)) {
            case TAG_HLocal: {
              heff_take_n(v_it1_241038, 0ULL, 1);
              heff_drop(v_sp_241039);
              v_it_241050 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_it1_241038, 0ULL, 1);
              heff_drop(v_sp_241039);
              v_it_241050 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_241045 = heff_field(v_it1_241038, 0);
              V v_ru_24it1_241038_24HMeta = heff_take_reuse_n(v_it1_241038, 1ULL, 1);
              v_it_241050 = heff_tag_at(v_ru_24it1_241038_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_241045, v_sp_241039})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_241039);
              v_it_241050 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_it1_241038);
            }
            break;
          }
          case TAG_VCode: {
            v_it_241050 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_241050 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_241050 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_241050 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2427);
          }
          switch (heff_tag_of(v_it_241050)) {
          case TAG_Nothing: {
            V v_t_241063;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_VNeu: {
              V v_it1_241051 = heff_dup(heff_field(v_x_2418, 0));
              switch (heff_tag_of(v_it1_241051)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_241051, 0ULL, 1);
                v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_241051, 0ULL, 1);
                v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_241051, 0ULL, 1);
                v_t_241063 = heff_dup(v_x_2418);
                break;
              }
              case TAG_HError: {
                v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
                break;
              }
              default: heff_nomatch(v_it1_241051);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VLam: {
              v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VCons: {
              v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241063 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2418)));
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_241076;
            switch (heff_tag_of(v_x_2427)) {
            case TAG_VNeu: {
              V v_it1_241064 = heff_dup(heff_field(v_x_2427, 0));
              switch (heff_tag_of(v_it1_241064)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_241064, 0ULL, 1);
                v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_241064, 0ULL, 1);
                v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_241064, 0ULL, 1);
                v_t_241076 = heff_dup(v_x_2427);
                break;
              }
              case TAG_HError: {
                v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
                break;
              }
              default: heff_nomatch(v_it1_241064);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VLam: {
              v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VCons: {
              v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241076 = (g_heff_2econversion_2ecanon(heff_dup(v_x_2427)));
              break;
            }
            default: heff_nomatch(v_x_2427);
            }
            V v_t_241077 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_241063; V a_7 = v_t_241076; V a_8 = v_x_2418; V a_9 = v_x_2427; V r_ = heff_tr(g_heff_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_241077, 2, (V[]){v_hd_2416, v_k_2417});
          }
          case TAG_Just: {
            V v_it1_241078 = heff_field(v_it_241050, 0);
            heff_take_n(v_it_241050, 1ULL, 1);
            heff_drop(v_w_240);
            heff_drop(v_ms_241);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_241078)) {
            case TAG_MkPair: {
              V v_m_241079 = heff_field(v_it1_241078, 0);
              V v_sp_241080 = heff_field(v_it1_241078, 1);
              heff_take_n(v_it1_241078, 3ULL, 2);
              return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241079, v_sp_241080, v_x_2418, v_x_2427, v_hd_2416, v_k_2417});
            }
            default: return heff_nomatch(v_it1_241078);
            }
          }
          default: return heff_nomatch(v_it_241050);
          }
        }
        case TAG_Just: {
          V v_it1_241081 = heff_field(v_it_241037, 0);
          heff_take_n(v_it_241037, 1ULL, 1);
          heff_drop(v_w_240);
          heff_drop(v_ms_241);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_241081)) {
          case TAG_MkPair: {
            V v_m_241082 = heff_field(v_it1_241081, 0);
            V v_sp_241083 = heff_field(v_it1_241081, 1);
            heff_take_n(v_it1_241081, 3ULL, 2);
            return heff_tail(heff_get(v_r_243, LBL_solve), 8, (V[]){v_g_244, v_cs_245, v_m_241082, v_sp_241083, v_x_2427, v_x_2418, v_hd_2416, v_k_2417});
          }
          default: return heff_nomatch(v_it1_241081);
          }
        }
        default: return heff_nomatch(v_it_241037);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2418, 1);
        heff_drop(v_w_240);
        heff_drop(v_ms_241);
        heff_drop(v_uf_242);
        heff_drop(v_cs_245);
        heff_drop(v_hd_2416);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        V f_ = v_k_2417;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2427);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2427);
      heff_drop(v_w_240);
      heff_drop(v_ms_241);
      heff_drop(v_uf_242);
      heff_drop(v_cs_245);
      heff_drop(v_hd_2416);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      V f_ = v_k_2417;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2418);
    }
  }
  default: return heff_nomatch(v_t_2491);
  }
}
V g_heff_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_b0_247 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_cs_245 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_p_2420 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTermF_lam5, 1, 1, (V[]){v_b0_247})})}));
  V v_c_2426 = heff_clo(g_heff_2eunify_2euTermF_lam6, 2, 2, (V[]){heff_dup(v_w_240), v_p_2420});
  return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2eunify_2euTermF_lam8, 1, 9, (V[]){v_x_2418, v_w_240, v_ms_241, v_uf_242, v_cs_245, v_hd_2416, v_k_2417, v_r_243, v_g_244})});
}
V g_heff_2eunify_2euTermF_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_b0_247 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_cs_245 = heff_env(self)[5];
  V v_r_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2eunify_2euTermF_lam4, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2416, v_uf_242, v_cs_245, v_k_2417, v_r_243, v_g_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2eufEv(a[0]);
}
Clo g_heff_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_apply(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euH_lam0, 2, 0};
V g_heff_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eunify_2euH_val;
static int g_heff_2eunify_2euH_st;
static V g_heff_2eunify_2euH_init(void) {
  return heff_rec(3, shape_278_23_185, (V[]){((V)&g_heff_2eunify_2euH_lam0_clo), ((V)&g_heff_2eunify_2euH_lam1_clo), ((V)&g_heff_2eunify_2euAlg_clo)});
}
V g_heff_2eunify_2euH_get(void) {
  if (g_heff_2eunify_2euH_st == 2) return g_heff_2eunify_2euH_val;
  if (g_heff_2eunify_2euH_st == 1) heff_fail("defined by itself");
  g_heff_2eunify_2euH_st = 1;
  g_heff_2eunify_2euH_val = heff_tr(g_heff_2eunify_2euH_init());
  g_heff_2eunify_2euH_st = 2;
  return g_heff_2eunify_2euH_val;
}
V g_heff_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eunify_2euModify_24s394_lam0(V self, V *args);
Clo g_heff_2eunify_2euModify_24s394_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euModify_24s394_entry, 3, 0};

V g_heff_2eunify_2euModify_24s394(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_240})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2eunify_2euModify_24s394_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eunify_2euModify_24s394_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euModify_24s394(a[0], a[1], a[2]);
}
V g_heff_2eunify_2euModify_24s394_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_Put, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_247, v_k_242});
}
V g_heff_2eunify_2epoisonTy_24s393_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonTy_24s393_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonTy_24s393_lam0, 1, 0};
V g_heff_2eunify_2epoisonTy_24s393_lam2(V self, V *args);
V g_heff_2eunify_2epoisonTy_24s393_lam1(V self, V *args);
Clo g_heff_2eunify_2epoisonTy_24s393_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonTy_24s393_entry, 4, 0};

V g_heff_2eunify_2epoisonTy_24s393(V v_len_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonTy_24s393_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2eunify_2epoisonTy_24s393_lam1, 1, 4, (V[]){v_len_240, v_t_241, v_hd_242, v_k_243})});
}
V g_heff_2eunify_2epoisonTy_24s393_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epoisonTy_24s393(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2epoisonTy_24s393_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2eunify_2epoisonTy_24s393_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_ms_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2411 = ({ V a_0 = heff_get(heff_dup(v_c_2410), LBL_poisoned); V a_1 = v_ms_249; V r_ = (g_prelude_2efoldl_24s304(a_0, a_1)); heff_drop(v_ms_249); r_; });
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2410), LBL_infos), heff_get(heff_dup(v_c_2410), LBL_recovered), v_ps_2411, heff_get(heff_dup(v_c_2410), LBL_metas), heff_get(heff_dup(v_c_2410), LBL_nextMeta), heff_get(heff_dup(v_c_2410), LBL_postponed), heff_get(heff_dup(v_c_2410), LBL_trace), heff_get(v_c_2410, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonTy_24s393_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_247); r_; });
  V v_ms_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_mty), 3, (V[]){MK_INT(20LL), v_len_240, v_t_241}));
  return (g_heff_2eunify_2euModify_24s394(heff_clo(g_heff_2eunify_2epoisonTy_24s393_lam2, 1, 1, (V[]){v_ms_249}), v_hd_242, v_k_243));
}
V g_heff_2eunify_2estoreSol_24s397_lam0(V self, V *args);
Clo g_heff_2eunify_2estoreSol_24s397_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2estoreSol_24s397_entry, 3, 0};

V g_heff_2eunify_2estoreSol_24s397(V v_m_240, V v_sol_241, V v_stx_242) {
top: ;
  return heff_tail(((V)&g_heff_2eunify_2euModify_24s394_clo), 1, (V[]){heff_clo(g_heff_2eunify_2estoreSol_24s397_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})});
}
V g_heff_2eunify_2estoreSol_24s397_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2estoreSol_24s397(a[0], a[1], a[2]);
}
V g_heff_2eunify_2estoreSol_24s397_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V a_0 = heff_dup(v_m_240); V b_1 = heff_get(heff_dup(v_c_243), LBL_metas); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_sol_241);
    heff_drop(v_stx_242);
    return v_c_243;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_rec(6, shape_351_308_309_14_198_314, (V[]){heff_get(heff_dup(v_e_245), LBL_ty), heff_tag(TAG_Just, 1, (V[]){v_sol_241}), heff_tag(TAG_Just, 1, (V[]){v_stx_242}), heff_get(heff_dup(v_e_245), LBL_arity), heff_get(heff_dup(v_e_245), LBL_name), heff_get(v_e_245, LBL_span)});
    V v_mc_247 = (g_map_2einsert_24s194(v_m_240, v_t_246, heff_get(heff_dup(v_c_243), LBL_metas)));
    return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_243), LBL_infos), heff_get(heff_dup(v_c_243), LBL_recovered), heff_get(heff_dup(v_c_243), LBL_poisoned), v_mc_247, heff_get(heff_dup(v_c_243), LBL_nextMeta), heff_get(heff_dup(v_c_243), LBL_postponed), heff_get(heff_dup(v_c_243), LBL_trace), heff_get(v_c_243, LBL_selfKey)});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eunify_2epoisonEl_24s398_lam0(V self, V *args); static Clo g_heff_2eunify_2epoisonEl_24s398_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_24s398_lam0, 1, 0};
V g_heff_2eunify_2epoisonEl_24s398_lam2(V self, V *args);
V g_heff_2eunify_2epoisonEl_24s398_lam1(V self, V *args);
Clo g_heff_2eunify_2epoisonEl_24s398_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2epoisonEl_24s398_entry, 4, 0};

V g_heff_2eunify_2epoisonEl_24s398(V v_len_240, V v_v_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2epoisonEl_24s398_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2eunify_2epoisonEl_24s398_lam1, 1, 4, (V[]){v_len_240, v_v_241, v_hd_242, v_k_243})});
}
V g_heff_2eunify_2epoisonEl_24s398_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2epoisonEl_24s398(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2epoisonEl_24s398_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get(v_c_244, LBL_metas);
}
V g_heff_2eunify_2epoisonEl_24s398_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_ms_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2411 = ({ V a_0 = heff_get(heff_dup(v_c_2410), LBL_poisoned); V a_1 = v_ms_249; V r_ = (g_prelude_2efoldl_24s304(a_0, a_1)); heff_drop(v_ms_249); r_; });
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2410), LBL_infos), heff_get(heff_dup(v_c_2410), LBL_recovered), v_ps_2411, heff_get(heff_dup(v_c_2410), LBL_metas), heff_get(heff_dup(v_c_2410), LBL_nextMeta), heff_get(heff_dup(v_c_2410), LBL_postponed), heff_get(heff_dup(v_c_2410), LBL_trace), heff_get(v_c_2410, LBL_selfKey)});
}
V g_heff_2eunify_2epoisonEl_24s398_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = ({ V a_0 = v_x_247; V r_ = (g_heff_2eunify_2emetasK(a_0)); heff_drop(v_x_247); r_; });
  V v_ms_249 = heff_tr(heff_apply(heff_get(v_t_248, LBL_mel), 3, (V[]){MK_INT(20LL), v_len_240, v_v_241}));
  return (g_heff_2eunify_2euModify_24s394(heff_clo(g_heff_2eunify_2epoisonEl_24s398_lam2, 1, 1, (V[]){v_ms_249}), v_hd_242, v_k_243));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eunify_2etraceSolve_24s399_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 111, 108, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eunify_2etraceSolve_24s399_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eunify_2etraceSolve_24s399_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eunify_2etraceSolve_24s399_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 58, 61, 32}};
V g_heff_2eunify_2etraceSolve_24s399_lam1(V self, V *args);
V g_heff_2eunify_2etraceSolve_24s399_lam0(V self, V *args);
Clo g_heff_2eunify_2etraceSolve_24s399_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraceSolve_24s399_entry, 2, 0};

V g_heff_2eunify_2etraceSolve_24s399(V v_m_240, V v_stx_241) {
top: ;
  return heff_tail(((V)&g_heff_2eunify_2euModify_24s394_clo), 1, (V[]){heff_clo(g_heff_2eunify_2etraceSolve_24s399_lam0, 1, 2, (V[]){v_m_240, v_stx_241})});
}
V g_heff_2eunify_2etraceSolve_24s399_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2etraceSolve_24s399(a[0], a[1]);
}
V g_heff_2eunify_2etraceSolve_24s399_lam1(V self, V *args) {
  V v_u_245 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  V v_m_240 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_245);
  V v_t_246 = ({ V b_0 = heff_get(v_c_242, LBL_metas); V r_ = (g_heff_2eunify_2ezonker(b_0)); heff_drop(b_0); r_; });
  V v_e_247 = heff_tr(heff_apply(heff_get(v_t_246, LBL_el), 1, (V[]){v_stx_241}));
  V v_t_248 = (g_heff_2epsurface_2eelF_24s91_24s305(MK_INT(0LL), NTAG(TAG_Nil), v_e_247));
  return heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s399_str1), heff_strAppend(heff_intShow(v_m_240), heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s399_str2), heff_strAppend(heff_get(v_e_244, LBL_name), heff_strAppend(((V)&g_heff_2eunify_2etraceSolve_24s399_str3), v_t_248)))));
}
V g_heff_2eunify_2etraceSolve_24s399_lam0(V self, V *args) {
  V v_c_242 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = ({ V a_0 = heff_dup(v_m_240); V b_1 = heff_get(heff_dup(v_c_242), LBL_metas); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_stx_241);
    return v_c_242;
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_249 = heff_rec(3, shape_314_154_337, (V[]){heff_get(heff_dup(v_e_244), LBL_span), ((V)&g_heff_2eunify_2etraceSolve_24s399_str0), heff_clo(g_heff_2eunify_2etraceSolve_24s399_lam1, 1, 4, (V[]){heff_dup(v_c_242), v_stx_241, v_m_240, v_e_244})});
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_get(heff_dup(v_c_242), LBL_trace)});
    return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_242), LBL_infos), heff_get(heff_dup(v_c_242), LBL_recovered), heff_get(heff_dup(v_c_242), LBL_poisoned), heff_get(heff_dup(v_c_242), LBL_metas), heff_get(heff_dup(v_c_242), LBL_nextMeta), heff_get(heff_dup(v_c_242), LBL_postponed), v_t_2410, heff_get(v_c_242, LBL_selfKey)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eunify_2erenameHead_24s401_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s401_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s401_lam0, 2, 0};
V g_heff_2eunify_2erenameHead_24s401_lam1(V self, V *args);
V g_heff_2eunify_2erenameHead_24s401_lam2(V self, V *args);
V g_heff_2eunify_2erenameHead_24s401_lam3(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s401_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s401_lam3, 2, 0};
V g_heff_2eunify_2erenameHead_24s401_lam4(V self, V *args); static Clo g_heff_2eunify_2erenameHead_24s401_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s401_lam4, 2, 0};
Clo g_heff_2eunify_2erenameHead_24s401_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameHead_24s401_entry, 2, 0};

V g_heff_2eunify_2erenameHead_24s401(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_243 = ({ V a_0 = v_l_242; V b_1 = heff_get(heff_dup(v_r_240), LBL_ren); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      return ((V)&g_heff_2eunify_2erenameHead_24s401_lam0_clo);
    }
    case TAG_Just: {
      V v_l_27_249 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      return heff_clo(g_heff_2eunify_2erenameHead_24s401_lam1, 2, 2, (V[]){v_r_240, v_l_27_249});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_HGlobal: {
    V v_x_2414 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_r_240);
    return heff_clo(g_heff_2eunify_2erenameHead_24s401_lam2, 2, 1, (V[]){v_x_2414});
  }
  case TAG_HMeta: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_r_240);
    return ((V)&g_heff_2eunify_2erenameHead_24s401_lam3_clo);
  }
  case TAG_HError: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eunify_2erenameHead_24s401_lam4_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2erenameHead_24s401_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameHead_24s401(a[0], a[1]);
}
V g_heff_2eunify_2erenameHead_24s401_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_t_246 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  V f_ = heff_get(v_hd_244, LBL_bind);
  args[0] = v_t_248;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameHead_24s401_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_l_27_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_intSub(heff_get(v_r_240, LBL_cod), v_l_27_249);
  V v_t_2413 = heff_tag(TAG_SLocal, 1, (V[]){heff_intSub(v_t_2412, MK_INT(1LL))});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameHead_24s401_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag(TAG_SGlobal, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameHead_24s401_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_t_2420 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2421}));
  V f_ = heff_get(v_hd_2418, LBL_bind);
  args[0] = v_t_2422;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameHead_24s401_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_t_2425 = heff_tag(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2425})}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam0(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam3(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam2(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam1(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam5(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam4(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam8(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam7(V self, V *args);
V g_heff_2eunify_2erenameSpine_24s402_lam6(V self, V *args);
Clo g_heff_2eunify_2erenameSpine_24s402_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameSpine_24s402_entry, 5, 0};

V g_heff_2eunify_2erenameSpine_24s402(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eunify_2erenameSpine_24s402(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2415 = heff_field(v_x5_243, 0);
    V v_l_2416 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2417 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_s_2415, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam4, 2, 2, (V[]){v_c_2417, v_l_2416});
  }
  case TAG_SpSpec: {
    V v_s_2421 = heff_field(v_x5_243, 0);
    V v_l_2422 = heff_field(v_x5_243, 1);
    V v_a_2423 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2424 = (g_heff_2eunify_2erenameSpine_24s402(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2421, v_h_244));
    return heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam6, 2, 6, (V[]){v_c_2424, v_g_240, v_m_241, v_pr_242, v_a_2423, v_l_2422});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameSpine_24s402_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameSpine_24s402(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameSpine_24s402_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag(TAG_SApp, 2, (V[]){v_x_2412, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s400_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248}));
  return heff_tail(v_c_2413, 2, (V[]){v_hd_2410, heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})});
}
V g_heff_2eunify_2erenameSpine_24s402_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_l_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag(TAG_SProj, 2, (V[]){v_x_2420, v_l_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_l_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam5, 1, 2, (V[]){v_k_2419, v_l_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_l_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2426;
  args[0] = heff_tag(TAG_SSpecialize, 3, (V[]){v_x_2427, v_l_2422, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameSpine_24s402_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2423 = heff_env(self)[3];
  V v_hd_2425 = heff_env(self)[4];
  V v_k_2426 = heff_env(self)[5];
  V v_l_2422 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2428 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s400_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2423}));
  return heff_tail(v_c_2428, 2, (V[]){v_hd_2425, heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam8, 1, 3, (V[]){v_k_2426, v_x_2427, v_l_2422})});
}
V g_heff_2eunify_2erenameSpine_24s402_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2423 = heff_env(self)[4];
  V v_l_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo(g_heff_2eunify_2erenameSpine_24s402_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2423, v_hd_2425, v_k_2426, v_l_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameEvF_24s404_lam1(V self, V *args);
V g_heff_2eunify_2erenameEvF_24s404_lam0(V self, V *args);
Clo g_heff_2eunify_2erenameEvF_24s404_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameEvF_24s404_entry, 4, 0};

V g_heff_2eunify_2erenameEvF_24s404(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nom: {
    V v_v_244 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    return heff_tail(((V)&g_heff_2eunify_2erenameF_24s400_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_244});
  }
  case TAG_Describe: {
    V v_v_245 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    return heff_tail(((V)&g_heff_2eunify_2erenameF_24s400_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_245});
  }
  case TAG_Become: {
    V v_v_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s400_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_246}));
    return heff_clo(g_heff_2eunify_2erenameEvF_24s404_lam0, 2, 1, (V[]){v_c_247});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameEvF_24s404_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameEvF_24s404(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2erenameEvF_24s404_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_249;
  args[0] = heff_tag(TAG_SIs, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameEvF_24s404_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo(g_heff_2eunify_2erenameEvF_24s404_lam1, 1, 1, (V[]){v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameClo_24s403_lam0(V self, V *args);
V g_heff_2eunify_2erenameClo_24s403_lam1(V self, V *args);
V g_heff_2eunify_2erenameClo_24s403_lam3(V self, V *args);
V g_heff_2eunify_2erenameClo_24s403_lam2(V self, V *args);
V g_heff_2eunify_2erenameClo_24s403_lam5(V self, V *args);
V g_heff_2eunify_2erenameClo_24s403_lam4(V self, V *args);
Clo g_heff_2eunify_2erenameClo_24s403_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameClo_24s403_entry, 5, 0};

V g_heff_2eunify_2erenameClo_24s403(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_cod), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s194(heff_get(heff_dup(v_pr_242), LBL_dom), heff_get(heff_dup(v_pr_242), LBL_cod), heff_get(heff_dup(v_pr_242), LBL_ren)));
    V v_pr_2411 = heff_rec(3, shape_70_46_267, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_pr_242, LBL_dom)});
    V v_v_2414 = (g_heff_2evalue_2emkNeu_24s10(v_t_2412, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameClo_24s403_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo(g_heff_2eunify_2erenameClo_24s403_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2417 = heff_tr(g_heff_2eunify_2erenameEvF_24s404(v_g_240, v_m_241, v_pr_2411, v_v_2416));
    return heff_clo(g_heff_2eunify_2erenameClo_24s403_lam2, 2, 2, (V[]){v_c_2417, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2421 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2422 = heff_tr(g_heff_2eunify_2erenameEvF_24s404(v_g_240, v_m_241, v_pr_242, v_t_2421));
    return heff_clo(g_heff_2eunify_2erenameClo_24s403_lam4, 2, 1, (V[]){v_c_2422});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eunify_2erenameClo_24s403_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameClo_24s403(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameClo_24s403_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eunify_2erenameClo_24s403_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eunify_2erenameClo_24s403_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameClo_24s403_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo(g_heff_2eunify_2erenameClo_24s403_lam3, 1, 2, (V[]){v_k_2419, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameClo_24s403_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2424;
  args[0] = heff_tag(TAG_AbsConst, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameClo_24s403_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo(g_heff_2eunify_2erenameClo_24s403_lam5, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2etraverseU_24s405_lam0(V self, V *args); static Clo g_heff_2eunify_2etraverseU_24s405_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraverseU_24s405_lam0, 2, 0};
V g_heff_2eunify_2etraverseU_24s405_lam3(V self, V *args);
V g_heff_2eunify_2etraverseU_24s405_lam2(V self, V *args);
V g_heff_2eunify_2etraverseU_24s405_lam1(V self, V *args);
Clo g_heff_2eunify_2etraverseU_24s405_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2etraverseU_24s405_entry, 2, 0};

V g_heff_2eunify_2etraverseU_24s405(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eunify_2etraverseU_24s405_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2eunify_2etraverseU_24s405_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eunify_2etraverseU_24s405_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2etraverseU_24s405(a[0], a[1]);
}
V g_heff_2eunify_2etraverseU_24s405_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2etraverseU_24s405_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2etraverseU_24s405_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eunify_2etraverseU_24s405(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2eunify_2etraverseU_24s405_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eunify_2etraverseU_24s405_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2eunify_2etraverseU_24s405_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2emetaEntry_24s407_lam0(V self, V *args); static Clo g_heff_2eunify_2emetaEntry_24s407_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetaEntry_24s407_lam0, 1, 0};
V g_heff_2eunify_2emetaEntry_24s407_lam1(V self, V *args);
Clo g_heff_2eunify_2emetaEntry_24s407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2emetaEntry_24s407_entry, 3, 0};

V g_heff_2eunify_2emetaEntry_24s407(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2emetaEntry_24s407_lam0_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2eunify_2emetaEntry_24s407_lam1, 1, 3, (V[]){v_m_240, v_hd_241, v_k_242})});
}
V g_heff_2eunify_2emetaEntry_24s407_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2emetaEntry_24s407(a[0], a[1], a[2]);
}
V g_heff_2eunify_2emetaEntry_24s407_lam0(V self, V *args) {
  V v_c_243 = args[0];
  return heff_get(v_c_243, LBL_metas);
}
V g_heff_2eunify_2emetaEntry_24s407_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = ({ V a_0 = v_m_240; V a_1 = v_x_246; V r_ = (g_map_2elookup_24s12(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2410, v_k_242});
  }
  case TAG_Just: {
    V v_e_2411 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_e_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eunify_2erenameEvTypeF_24s411_lam1(V self, V *args);
V g_heff_2eunify_2erenameEvTypeF_24s411_lam0(V self, V *args);
Clo g_heff_2eunify_2erenameEvTypeF_24s411_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameEvTypeF_24s411_entry, 4, 0};

V g_heff_2eunify_2erenameEvTypeF_24s411(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nom: {
    V v_a_244 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_244});
  }
  case TAG_Describe: {
    V v_a_245 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_245});
  }
  case TAG_Become: {
    V v_a_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_246}));
    return heff_clo(g_heff_2eunify_2erenameEvTypeF_24s411_lam0, 2, 1, (V[]){v_c_247});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eunify_2erenameEvTypeF_24s411_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameEvTypeF_24s411(a[0], a[1], a[2], a[3]);
}
V g_heff_2eunify_2erenameEvTypeF_24s411_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_249;
  args[0] = heff_tag(TAG_SIsTy, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameEvTypeF_24s411_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo(g_heff_2eunify_2erenameEvTypeF_24s411_lam1, 1, 1, (V[]){v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameCloTy_24s410_lam0(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s410_lam1(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s410_lam3(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s410_lam2(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s410_lam5(V self, V *args);
V g_heff_2eunify_2erenameCloTy_24s410_lam4(V self, V *args);
Clo g_heff_2eunify_2erenameCloTy_24s410_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameCloTy_24s410_entry, 5, 0};

V g_heff_2eunify_2erenameCloTy_24s410(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_cod), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s194(heff_get(heff_dup(v_pr_242), LBL_dom), heff_get(heff_dup(v_pr_242), LBL_cod), heff_get(heff_dup(v_pr_242), LBL_ren)));
    V v_pr_2411 = heff_rec(3, shape_70_46_267, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_pr_242, LBL_dom)});
    V v_v_2414 = (g_heff_2evalue_2emkNeu_24s10(v_t_2412, NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameCloTy_24s410_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo(g_heff_2eunify_2erenameCloTy_24s410_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2417 = heff_tr(g_heff_2eunify_2erenameEvTypeF_24s411(v_g_240, v_m_241, v_pr_2411, v_t_2416));
    return heff_clo(g_heff_2eunify_2erenameCloTy_24s410_lam2, 2, 2, (V[]){v_c_2417, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2421 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2422 = heff_tr(g_heff_2eunify_2erenameEvTypeF_24s411(v_g_240, v_m_241, v_pr_242, v_t_2421));
    return heff_clo(g_heff_2eunify_2erenameCloTy_24s410_lam4, 2, 1, (V[]){v_c_2422});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eunify_2erenameCloTy_24s410_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameCloTy_24s410(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2erenameCloTy_24s410_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eunify_2erenameCloTy_24s410_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eunify_2erenameCloTy_24s410_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameCloTy_24s410_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo(g_heff_2eunify_2erenameCloTy_24s410_lam3, 1, 2, (V[]){v_k_2419, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameCloTy_24s410_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2424;
  args[0] = heff_tag(TAG_AbsConst, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameCloTy_24s410_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo(g_heff_2eunify_2erenameCloTy_24s410_lam5, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameRecordFields_24s412_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameRecordFields_24s412_lam0, 2, 0};
V g_heff_2eunify_2erenameRecordFields_24s412_lam3(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s412_lam4(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s412_lam5(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s412_lam2(V self, V *args);
V g_heff_2eunify_2erenameRecordFields_24s412_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameRecordFields_24s412_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameRecordFields_24s412_entry, 6, 0};

V g_heff_2eunify_2erenameRecordFields_24s412(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eunify_2erenameRecordFields_24s412_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      V v_c_2414 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411)}));
      return heff_clo(g_heff_2eunify_2erenameRecordFields_24s412_lam1, 2, 8, (V[]){v_c_2414, v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eunify_2erenameRecordFields_24s412_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameRecordFields_24s412(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_ty_2411;
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam4(V self, V *args) {
  V v_u_2421 = args[0];
  V v_v_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  return v_v_2420;
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2416;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_2417, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2415 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2418 = heff_intAdd(heff_get(heff_dup(v_pr_242), LBL_dom), heff_dup(v_i_243));
  V v_v_2420 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_t_2418}), NTAG(TAG_SpId), heff_clo(g_heff_2eunify_2erenameRecordFields_24s412_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2422 = (g_heff_2eunify_2erenameRecordFields_24s412(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo(g_heff_2eunify_2erenameRecordFields_24s412_lam4, 1, 1, (V[]){v_v_2420})}), v_rest_249));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2415, heff_clo(g_heff_2eunify_2erenameRecordFields_24s412_lam5, 1, 2, (V[]){v_k_2416, v_x_2417})});
}
V g_heff_2eunify_2erenameRecordFields_24s412_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_i_243 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_m_241 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2eunify_2erenameRecordFields_24s412_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam0(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam3(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam2(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam5(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam4(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam6(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam8(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam7(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam10(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam9(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam11(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam13(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam15(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam14(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam12(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam16(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam17(V self, V *args);
V g_heff_2eunify_2erenameTypeF_24s409_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameTypeF_24s409_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameTypeF_24s409_entry, 6, 0};

V g_heff_2eunify_2erenameTypeF_24s409(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameTypeF_24s409_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameTypeF_24s409(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_t0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2erenameTypeF_24s409_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  return heff_tail(v_c_2419, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam3, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s409_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  return heff_tail(v_c_2424, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam5, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s409_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SDecode, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2435 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2434));
  return heff_tail(v_c_2435, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam8, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eunify_2erenameTypeF_24s409_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2437 = heff_env(self)[1];
  V v_x_2442 = heff_env(self)[2];
  V v_implicit_2440 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SFunction, 4, (V[]){v_level_2437, v_x_2442, v_x_2444, v_implicit_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2438 = heff_env(self)[3];
  V v_cod_2439 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2437 = heff_env(self)[7];
  V v_implicit_2440 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2443 = (g_heff_2eunify_2erenameCloTy_24s410(v_g_240, v_m_241, v_pr_242, v_dom_2438, v_cod_2439));
  return heff_tail(v_c_2443, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam10, 1, 4, (V[]){v_k_245, v_level_2437, v_x_2442, v_implicit_2440})});
}
V g_heff_2eunify_2erenameTypeF_24s409_lam11(V self, V *args) {
  V v_x_2451 = args[0];
  V v_fieldTypes_2447 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2445 = heff_env(self)[2];
  V v_defaults_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_2447), LBL_keys), heff_get(v_fieldTypes_2447, LBL_byName), heff_arrayFromList(v_x_2451)});
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SRecord, 3, (V[]){v_level_2445, v_t_2452, v_defaults_2448});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam13(V self, V *args) {
  V v_a_2460 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2461 = heff_tr(heff_apply(v_a_2460, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_tail(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_t_2461});
}
V g_heff_2eunify_2erenameTypeF_24s409_lam15(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_k_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466 = heff_tag(TAG_MkPair, 2, (V[]){v_k_2458, heff_arrayFromList(v_x_2465)});
  V f_ = v_k_2464;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam14(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_c_2462 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2462;
  args[0] = v_hd_2463;
  args[1] = heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam15, 1, 2, (V[]){v_k_2458, v_k_2464});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam12(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_args_2459 = heff_field(v_p_2457, 1);
    heff_take_n(v_p_2457, 3ULL, 2);
    V v_c_2462 = (g_heff_2eunify_2etraverseU_24s405(heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2459)));
    return heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam14, 2, 2, (V[]){v_c_2462, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eunify_2erenameTypeF_24s409_lam16(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_prelude_2emap_24s5(heff_dup(v_x_2468)));
  V v_t_2470 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2468));
  V v_t_2471 = (g_prelude_2emap_24s6(v_x_2468));
  V v_t_2472 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2469), v_t_2470, heff_arrayFromList(v_t_2471)});
  V v_x_2473 = heff_tag(TAG_SSum, 1, (V[]){v_t_2472});
  V f_ = v_k_245;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam17(V self, V *args) {
  V v_x_2476 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SPrimArray, 1, (V[]){v_x_2476});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameTypeF_24s409_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eunify_2erenameHead_24s401(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eunify_2erenameHead_24s401(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      V v_t_2427 = heff_intEq(heff_dup(v_m_27_2426), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_2427)) {
      case TAG_True: {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        V v_t_2428 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2429}));
        return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2430, v_k_245});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        V v_c_2431 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameFlexF_24s406_clo), 5, (V[]){v_g_240, v_m_241, v_pr_242, v_m_27_2426, v_sp_2412}));
        return heff_tail(v_c_2431, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam6, 1, 1, (V[]){v_k_245})});
      }
      default: return heff_nomatch(v_t_2427);
      }
    }
    case TAG_HError: {
      V v_c_2433 = (g_heff_2eunify_2erenameHead_24s401(heff_dup(v_pr_242), v_it1_2411));
      return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2437 = heff_field(v_x_249, 0);
    V v_dom_2438 = heff_field(v_x_249, 1);
    V v_cod_2439 = heff_field(v_x_249, 2);
    V v_implicit_2440 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_c_2441 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2438)}));
    return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam9, 1, 9, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2438, v_cod_2439, v_hd_244, v_k_245, v_level_2437, v_implicit_2440})});
  }
  case TAG_VRecord: {
    V v_level_2445 = heff_field(v_x_249, 0);
    V v_capture_2446 = heff_field(v_x_249, 1);
    V v_fieldTypes_2447 = heff_field(v_x_249, 2);
    V v_defaults_2448 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2449 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2447), LBL_values));
    V v_c_2450 = (g_heff_2eunify_2erenameRecordFields_24s412(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2446, v_t_2449));
    return heff_tail(v_c_2450, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam11, 1, 4, (V[]){v_fieldTypes_2447, v_k_245, v_level_2445, v_defaults_2448})});
  }
  case TAG_VSum: {
    V v_vs_2453 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2454 = heff_arrayToList(heff_get(heff_dup(v_vs_2453), LBL_keys));
    V v_t_2455 = heff_arrayToList(heff_get(v_vs_2453, LBL_values));
    V v_t_2456 = (g_heff_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2467 = (g_heff_2eunify_2etraverseU_24s405(heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    return heff_tail(v_c_2467, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam16, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2474 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_c_2475 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2474}));
    return heff_tail(v_c_2475, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameTypeF_24s409_lam17, 1, 1, (V[]){v_k_245})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam2(V self, V *args); static Clo g_heff_2eunify_2esolveWithPruned_24s408_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveWithPruned_24s408_lam2, 1, 0};
V g_heff_2eunify_2esolveWithPruned_24s408_lam4(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam3(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam1(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam6(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam8(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam7(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam5(V self, V *args);
V g_heff_2eunify_2esolveWithPruned_24s408_lam0(V self, V *args);
Clo g_heff_2eunify_2esolveWithPruned_24s408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveWithPruned_24s408_entry, 8, 0};

V g_heff_2eunify_2esolveWithPruned_24s408(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec(3, shape_70_46_267, (V[]){heff_get(heff_dup(v_entry_243), LBL_arity), MK_INT(0LL), heff_dup(g_map_2eempty_get())});
  return (g_heff_2eunify_2erenameTypeF_24s409(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_get(heff_dup(v_entry_243), LBL_ty), heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eunify_2esolveWithPruned_24s408_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esolveWithPruned_24s408(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam2(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get(v_c_2418, LBL_nextMeta);
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V f_ = v_k_2417;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_entry_243 = heff_env(self)[0];
  V v_arity_2410 = heff_env(self)[1];
  V v_ty_2415 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_243, v_arity_2410, v_ty_2415}));
  V v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eunify_2euModify_24s394_clo), 1, (V[]){v_t_2422}));
  return heff_tail(v_c_2423, 2, (V[]){v_hd_2416, heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam4, 1, 2, (V[]){v_k_2417, v_x_2421})});
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_entry_243 = heff_env(self)[0];
  V v_arity_2410 = heff_env(self)[1];
  V v_ty_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveWithPruned_24s408_lam2_clo)})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2419}));
  V f_ = heff_get(heff_dup(v_hd_2416), LBL_bind);
  args[0] = v_t_2420;
  args[1] = heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam3, 1, 5, (V[]){v_entry_243, v_arity_2410, v_ty_2415, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam6(V self, V *args) {
  V v_i_2427 = args[0];
  V v_n_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_244, v_i_2427), MK_INT(1LL));
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  V f_ = v_k_247;
  args[0] = v_v_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2437);
  V v_c_2438 = heff_tr(g_heff_2eunify_2etraceSolve_24s399(v_storeM_242, v_t_2430));
  return heff_tail(v_c_2438, 2, (V[]){v_hd_246, heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam8, 1, 2, (V[]){v_k_247, v_v_2435})});
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam6, 1, 1, (V[]){heff_dup(v_n_244)}), v_kept_245));
  V v_t_2429 = heff_tag(TAG_SMetaApp, 3, (V[]){v_x_2426, heff_arrayFromList(v_t_2428), v_x_249});
  V v_t_2430 = (g_heff_2eunify_2elamsU(v_n_244, v_t_2429));
  V v_x1_2431 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), heff_dup(v_t_2430), NTAG(TAG_LNil)));
  V v_v_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_v_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    v_v_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_v_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_c_2436 = heff_tr(g_heff_2eunify_2estoreSol_24s397(heff_dup(v_storeM_242), heff_dup(v_v_2435), heff_dup(v_t_2430)));
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam7, 1, 5, (V[]){v_storeM_242, v_t_2430, v_hd_246, v_k_247, v_v_2435})});
}
V g_heff_2eunify_2esolveWithPruned_24s408_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_arity_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_kept_245));
  V v_x1_2411 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  V v_ty_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_ty_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_ty_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_ty_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_c_2425 = heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam1, 2, 3, (V[]){v_entry_243, v_arity_2410, v_ty_2415});
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveWithPruned_24s408_lam5, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})});
}
V g_heff_2eunify_2erenameFlexF_24s406_lam0(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s406_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s406_lam0, 1, 0};
V g_heff_2eunify_2erenameFlexF_24s406_lam2(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s406_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s406_lam2, 1, 0};
V g_heff_2eunify_2erenameFlexF_24s406_lam4(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam6(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam7(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam5(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam11(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s406_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s406_lam11, 2, 0};
V g_heff_2eunify_2erenameFlexF_24s406_lam12(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam13(V self, V *args); static Clo g_heff_2eunify_2erenameFlexF_24s406_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s406_lam13, 2, 0};
V g_heff_2eunify_2erenameFlexF_24s406_lam10(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam14(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam9(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam8(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam3(V self, V *args);
V g_heff_2eunify_2erenameFlexF_24s406_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameFlexF_24s406_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameFlexF_24s406_entry, 7, 0};

V g_heff_2eunify_2erenameFlexF_24s406(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2erenameFlexF_24s406_lam0_clo)})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam1, 1, 7, (V[]){v_hd_245, heff_dup(v_sp_244), v_k_246, v_pr_242, v_m_27_243, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameFlexF_24s406_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2erenameFlexF_24s406(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[4]); return r;
}
V g_heff_2eunify_2erenameFlexF_24s406_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get(v_c_247, LBL_metas);
}
V g_heff_2eunify_2erenameFlexF_24s406_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get(v_c_2411, LBL_selfKey);
}
V g_heff_2eunify_2erenameFlexF_24s406_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_PVar: {
    V v_l_2425 = heff_field(v_a_2424, 0);
    heff_take_n(v_a_2424, 1ULL, 1);
    V v_x3_2426 = ({ V a_0 = v_l_2425; V b_1 = heff_get(v_pr_242, LBL_ren); V r_ = (g_map_2elookup_24s388(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2426)) {
    case TAG_Nothing: {
      v_x1_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2426, 0ULL, 1);
      v_x1_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2426);
    }
    break;
  }
  case TAG_PSelf: {
    heff_drop(v_pr_242);
    v_x1_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eunify_2erenameFlexF_24s406_lam6(V self, V *args) {
  V v_i_2432 = args[0];
  V v_a_2433 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2433)) {
  case TAG_PVar: {
    V v_l_2434 = heff_field(v_a_2433, 0);
    V v_ru_24a_2433_24PVar = heff_take_reuse_n(v_a_2433, 1ULL, 1);
    V v_x3_2435 = ({ V a_0 = v_l_2434; V b_1 = heff_get(v_pr_242, LBL_ren); V r_ = (g_map_2elookup_24s388(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2435)) {
    case TAG_Nothing: {
      heff_drop(v_i_2432);
      heff_drop_cell(v_ru_24a_2433_24PVar, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2435, 0ULL, 1);
      return heff_tag_at(v_ru_24a_2433_24PVar, TAG_Just, 1, (V[]){v_i_2432});
    }
    default: return heff_nomatch(v_x3_2435);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2432);
    heff_drop(v_pr_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2433);
  }
}
V g_heff_2eunify_2erenameFlexF_24s406_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2441 = ({ V a_0 = v_x_2440; V a_1 = v_sp_244; V r_ = (g_heff_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eunify_2erenameF_24s400(v_g_240, v_m_241, v_pr_242, v_v_2441, v_hd_245, v_k_246));
}
V g_heff_2eunify_2erenameFlexF_24s406_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_args_2423 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2431 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2423));
  V v_t_2437 = (g_heff_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2423));
  V v_t_2438 = (g_heff_2eunify_2ecatMaybes(v_t_2437));
  V v_c_2439 = heff_tr(heff_apply(((V)&g_heff_2eunify_2esolveWithPruned_24s408_clo), 6, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2430, v_t_2431, v_t_2438}));
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})});
}
V g_heff_2eunify_2erenameFlexF_24s406_lam11(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_t_2449 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2450}));
  V f_ = heff_get(v_hd_2447, LBL_bind);
  args[0] = v_t_2451;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameFlexF_24s406_lam12(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2453);
  V v_t_2455 = heff_intSub(heff_get(v_pr_242, LBL_cod), v_l_27_2452);
  V f_ = v_k_2454;
  args[0] = heff_intSub(v_t_2455, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameFlexF_24s406_lam13(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_t_2458 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2459 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2459}));
  V f_ = heff_get(v_hd_2456, LBL_bind);
  args[0] = v_t_2460;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameFlexF_24s406_lam10(V self, V *args) {
  V v_a_2444 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2444)) {
  case TAG_PVar: {
    V v_l_2445 = heff_field(v_a_2444, 0);
    heff_take_n(v_a_2444, 1ULL, 1);
    V v_t_2446 = ({ V a_0 = v_l_2445; V b_1 = heff_get(heff_dup(v_pr_242), LBL_ren); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Nothing: {
      heff_drop(v_pr_242);
      return ((V)&g_heff_2eunify_2erenameFlexF_24s406_lam11_clo);
    }
    case TAG_Just: {
      V v_l_27_2452 = heff_field(v_t_2446, 0);
      heff_take_n(v_t_2446, 1ULL, 1);
      return heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam12, 2, 2, (V[]){v_pr_242, v_l_27_2452});
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_pr_242);
    return ((V)&g_heff_2eunify_2erenameFlexF_24s406_lam13_clo);
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2eunify_2erenameFlexF_24s406_lam14(V self, V *args) {
  V v_x_2462 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2463 = heff_tag(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2462), v_x_2443});
  V f_ = v_k_246;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameFlexF_24s406_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2423 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2461 = (g_heff_2eunify_2etraverseU_24s405(heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam10, 1, 1, (V[]){v_pr_242}), v_args_2423));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_245, heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam14, 1, 3, (V[]){v_m_27_243, v_x_2443, v_k_246})});
}
V g_heff_2eunify_2erenameFlexF_24s406_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2423 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eunify_2erenameTypeF_24s409(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get(v_x_2442, LBL_ty), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam9, 1, 5, (V[]){v_pr_242, v_args_2423, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eunify_2erenameFlexF_24s406_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_m_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = v_sp_244; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_t_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2416 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Just = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2416)));
    V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2417); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_tag_at(v_ru_24t_2415_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_items_2416))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2416);
      heff_drop_cell(v_ru_24t_2415_24Just, 1);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    heff_drop(v_sp_244);
    heff_drop(v_pr_242);
    heff_drop(v_m_27_243);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V v_t_2420 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2422, v_k_246});
  }
  case TAG_Just: {
    V v_args_2423 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    V v_t_2429 = (g_heff_2eunify_2eanyL(heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2423));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      return (g_heff_2eunify_2emetaEntry_24s407(heff_dup(v_m_27_243), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam5, 1, 8, (V[]){v_args_2423, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_sp_244, v_k_246})));
    }
    case TAG_False: {
      heff_drop(v_sp_244);
      return (g_heff_2eunify_2emetaEntry_24s407(heff_dup(v_m_27_243), heff_dup(v_hd_245), heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam8, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_hd_245, v_args_2423, v_m_27_243, v_k_246})));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eunify_2erenameFlexF_24s406_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  V v_m_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2erenameFlexF_24s406_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_245), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2eunify_2erenameFlexF_24s406_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_hd_245, v_k_246, v_pr_242, v_m_27_243, v_g_240, v_m_241})});
}
V g_heff_2eunify_2erenameF_24s400_lam0(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam2(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam3(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam4(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam5(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam7(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam6(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam10(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam9(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam8(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam11(V self, V *args);
V g_heff_2eunify_2erenameF_24s400_lam1(V self, V *args);
Clo g_heff_2eunify_2erenameF_24s400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2erenameF_24s400_entry, 6, 0};

V g_heff_2eunify_2erenameF_24s400(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2erenameF_24s400_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2erenameF_24s400_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eunify_2erenameF_24s400_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2erenameF_24s400(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2erenameF_24s400_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_v0_243; V r_ = (g_heff_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2erenameF_24s400_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  return heff_tail(v_t_2418, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s400_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  return heff_tail(v_t_2422, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s400_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = (g_heff_2eunify_2erenameSpine_24s402(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2429));
  return heff_tail(v_t_2430, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eunify_2erenameF_24s400_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SCode, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s400_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_SLam, 2, (V[]){v_x_2437, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s400_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_fty_2433 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2434 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2438 = heff_tr(heff_apply(v_fty_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2439 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_2438)));
  V v_t_2450;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2442 = heff_field(v_t_2439, 1);
    heff_take_n(v_t_2439, 2ULL, 4);
    heff_drop(v_t_2438);
    v_t_2450 = v_dom_2442;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2439, 0ULL, 3);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeInt: {
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeString: {
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2439, 0ULL, 1);
    v_t_2450 = v_t_2438;
    break;
  }
  case TAG_NoRules: {
    v_t_2450 = v_t_2438;
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  V v_c_2451 = (g_heff_2eunify_2erenameClo_24s403(v_g_240, v_m_241, v_pr_242, v_t_2450, v_body_2434));
  return heff_tail(v_c_2451, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s400_lam7, 1, 2, (V[]){v_k_245, v_x_2437})});
}
V g_heff_2eunify_2erenameF_24s400_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2462;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_k_2458, v_x_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s400_lam9(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_c_2460 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2460;
  args[0] = v_hd_2461;
  args[1] = heff_clo(g_heff_2eunify_2erenameF_24s400_lam10, 1, 2, (V[]){v_k_2462, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2erenameF_24s400_lam8(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_x_2459 = heff_field(v_p_2457, 1);
    heff_take_n(v_p_2457, 3ULL, 2);
    V v_c_2460 = heff_tr(g_heff_2eunify_2erenameEvF_24s404(v_g_240, v_m_241, v_pr_242, v_x_2459));
    return heff_clo(g_heff_2eunify_2erenameF_24s400_lam9, 2, 2, (V[]){v_c_2460, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eunify_2erenameF_24s400_lam11(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_prelude_2emap_24s5(heff_dup(v_x_2465)));
  V v_t_2467 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_x_2465));
  V v_t_2468 = (g_prelude_2emap_24s6(v_x_2465));
  V v_t_2469 = heff_rec(3, shape_153_35_368, (V[]){heff_arrayFromList(v_t_2466), v_t_2467, heff_arrayFromList(v_t_2468)});
  V v_x_2470 = heff_tag(TAG_SCons, 1, (V[]){v_t_2469});
  V f_ = v_k_245;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2erenameF_24s400_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eunify_2erenameHead_24s401(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s400_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eunify_2erenameHead_24s401(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s400_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      V v_t_2424 = heff_intEq(heff_dup(v_m_27_2423), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        V v_t_2425 = heff_tag(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2426 = heff_tag_at(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2426}));
        return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2427, v_k_245});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2423; V a_4 = v_sp_2411; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2eunify_2erenameFlexF_24s406(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2411); r_; });
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    case TAG_HError: {
      V v_c_2428 = (g_heff_2eunify_2erenameHead_24s401(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s400_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eunify_2erenameTypeF_24s409(v_g_240, v_m_241, v_pr_242, v_t_2431, v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s400_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2433 = heff_field(v_x_249, 0);
    V v_body_2434 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_apply(heff_dup(v_fty_2433), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_c_2436 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2435}));
    return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2erenameF_24s400_lam6, 1, 7, (V[]){v_fty_2433, v_g_240, v_m_241, v_pr_242, v_body_2434, v_hd_244, v_k_245})});
  }
  case TAG_VCons: {
    V v_d_2453 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2454 = heff_arrayToList(heff_get(heff_dup(v_d_2453), LBL_keys));
    V v_t_2455 = heff_arrayToList(heff_get(v_d_2453, LBL_values));
    V v_t_2456 = (g_heff_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2464 = (g_heff_2eunify_2etraverseU_24s405(heff_clo(g_heff_2eunify_2erenameF_24s400_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    return heff_tail(v_c_2464, 2, (V[]){v_hd_244, heff_clo(g_heff_2eunify_2erenameF_24s400_lam11, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eunify_2esolveRhs_24s396_lam1(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam0(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam4(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam5(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam6(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam7(V self, V *args); static Clo g_heff_2eunify_2esolveRhs_24s396_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s396_lam7, 2, 0};
V g_heff_2eunify_2esolveRhs_24s396_lam3(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam2(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam11(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam13(V self, V *args); static Clo g_heff_2eunify_2esolveRhs_24s396_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s396_lam13, 2, 0};
V g_heff_2eunify_2esolveRhs_24s396_lam14(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam12(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam10(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam9(V self, V *args);
V g_heff_2eunify_2esolveRhs_24s396_lam8(V self, V *args);
Clo g_heff_2eunify_2esolveRhs_24s396_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveRhs_24s396_entry, 5, 0};

V g_heff_2eunify_2esolveRhs_24s396(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244) {
top: ;
  V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_243));
  V v_t_246 = (g_heff_2eunify_2emapWithIndexL_24s390(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s389(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_pr_248 = heff_rec(3, shape_70_46_267, (V[]){heff_get(v_cs_241, LBL_len), v_t_245, v_t_247});
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eunify_2erenameF_24s400_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_242), v_pr_248, v_rhs_244}));
  V v_m_2413 = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam0, 2, 1, (V[]){v_c_249});
  V v_c_2446 = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam2, 2, 1, (V[]){v_m_2413});
  return heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam8, 2, 4, (V[]){v_c_2446, v_args_243, v_g_240, v_m_242});
}
V g_heff_2eunify_2esolveRhs_24s396_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2esolveRhs_24s396(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eunify_2esolveRhs_24s396_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2411;
  args[0] = heff_tag(TAG_Just, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam1, 1, 1, (V[]){v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_s_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2423}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2424;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_s_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2430}));
  V f_ = heff_get(v_hd_2428, LBL_bind);
  args[0] = v_t_2431;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_s_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_s_2417})});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2439}));
  V f_ = heff_get(v_hd_2437, LBL_bind);
  args[0] = v_t_2440;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2443;
  switch (heff_tag_of(v_s_2417)) {
  case TAG_UnequalTys: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam4, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_UnequalEls: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam5, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_UnequalNeus: {
    v_c_2443 = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam6, 2, 1, (V[]){v_s_2417});
    break;
  }
  case TAG_MentionsError: {
    v_c_2443 = ((V)&g_heff_2eunify_2esolveRhs_24s396_lam7_clo);
    break;
  }
  default: heff_nomatch(v_s_2417);
  }
  return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_2414), heff_get(v_hd_2414, LBL_ret)});
}
V g_heff_2eunify_2esolveRhs_24s396_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_m_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_apply(v_m_2413, 2, (V[]){heff_dup(v_hd_2414), heff_get(heff_dup(v_hd_2414), LBL_ret)}));
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Catch, 2, (V[]){v_t_2416, heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam3, 1, 1, (V[]){heff_dup(v_hd_2414)})})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(v_hd_2414, LBL_bind);
  args[0] = v_t_2445;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam11(V self, V *args) {
  V v_c_2460 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2461 = ({ V a_0 = v_m_242; V b_1 = heff_get(v_c_2460, LBL_poisoned); V r_ = (g_map_2elookup_24s388(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2461)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2461, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2461);
  }
}
V g_heff_2eunify_2esolveRhs_24s396_lam13(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  heff_drop(v_hd_2466);
  V f_ = v_k_2467;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveRhs_24s396_lam14(V self, V *args) {
  V v_x_2469 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2452 = heff_env(self)[1];
  V v_hd_2447 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_tr(g_heff_2eunify_2etraceSolve_24s399(v_m_242, v_t_2452));
  return heff_tail(v_t_2470, 2, (V[]){v_hd_2447, v_k_2448});
}
V g_heff_2eunify_2esolveRhs_24s396_lam12(V self, V *args) {
  V v_x_2465 = args[0];
  V v_v_2457 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2452 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2468;
  switch (heff_tag_of(v_x_2465)) {
  case TAG_True: {
    v_c_2468 = heff_tr(heff_apply(((V)&g_heff_2eunify_2epoisonEl_24s398_clo), 2, (V[]){MK_INT(0LL), v_v_2457}));
    break;
  }
  case TAG_False: {
    heff_drop(v_v_2457);
    v_c_2468 = ((V)&g_heff_2eunify_2esolveRhs_24s396_lam13_clo);
    break;
  }
  default: heff_nomatch(v_x_2465);
  }
  return heff_tail(v_c_2468, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam14, 1, 4, (V[]){v_m_242, v_t_2452, v_hd_2447, v_k_2448})});
}
V g_heff_2eunify_2esolveRhs_24s396_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_v_2457 = heff_env(self)[2];
  V v_t_2452 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2459);
  V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam11, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2463}));
  return heff_tail(heff_get(heff_dup(v_hd_2447), LBL_bind), 2, (V[]){v_t_2464, heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam12, 1, 5, (V[]){v_v_2457, v_hd_2447, v_m_242, v_t_2452, v_k_2448})});
}
V g_heff_2eunify_2esolveRhs_24s396_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop(v_hd_2447);
    V f_ = v_k_2448;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2450 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    V v_t_2451 = ({ V a_0 = MK_INT(0LL); V a_1 = v_args_243; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_args_243); r_; });
    V v_t_2452 = (g_heff_2eunify_2elamsU(v_t_2451, v_body_2450));
    V v_x1_2453 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), heff_dup(v_t_2452), NTAG(TAG_LNil)));
    V v_v_2457;
    switch (heff_tag_of(v_x1_2453)) {
    case TAG_Nom: {
      V v_x_2454 = heff_field(v_x1_2453, 0);
      heff_take_n(v_x1_2453, 1ULL, 1);
      v_v_2457 = v_x_2454;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2453, 0ULL, 1);
      v_v_2457 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2456 = heff_field(v_x1_2453, 0);
      heff_take_n(v_x1_2453, 1ULL, 1);
      v_v_2457 = v_x_2456;
      break;
    }
    default: heff_nomatch(v_x1_2453);
    }
    V v_c_2458 = heff_tr(g_heff_2eunify_2estoreSol_24s397(heff_dup(v_m_242), heff_dup(v_v_2457), heff_dup(v_t_2452)));
    return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2447), heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam10, 1, 5, (V[]){v_m_242, v_hd_2447, v_v_2457, v_t_2452, v_k_2448})});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2eunify_2esolveRhs_24s396_lam8(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo(g_heff_2eunify_2esolveRhs_24s396_lam9, 1, 5, (V[]){v_k_2448, v_args_243, v_g_240, v_m_242, v_hd_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2esolveF_24s395_lam0(V self, V *args); static Clo g_heff_2eunify_2esolveF_24s395_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s395_lam0, 1, 0};
V g_heff_2eunify_2esolveF_24s395_lam2(V self, V *args); static Clo g_heff_2eunify_2esolveF_24s395_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s395_lam2, 1, 0};
V g_heff_2eunify_2esolveF_24s395_lam4(V self, V *args);
V g_heff_2eunify_2esolveF_24s395_lam5(V self, V *args);
V g_heff_2eunify_2esolveF_24s395_lam7(V self, V *args);
V g_heff_2eunify_2esolveF_24s395_lam6(V self, V *args);
V g_heff_2eunify_2esolveF_24s395_lam8(V self, V *args);
V g_heff_2eunify_2esolveF_24s395_lam3(V self, V *args);
V g_heff_2eunify_2esolveF_24s395_lam1(V self, V *args);
Clo g_heff_2eunify_2esolveF_24s395_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2esolveF_24s395_entry, 8, 0};

V g_heff_2eunify_2esolveF_24s395(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveF_24s395_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2eunify_2esolveF_24s395_lam1, 1, 8, (V[]){v_hd_246, heff_dup(v_sp_243), v_cs_241, v_self_245, v_rhs_244, v_k_247, v_g_240, v_m_242})});
}
V g_heff_2eunify_2esolveF_24s395_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eunify_2esolveF_24s395(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[3]); return r;
}
V g_heff_2eunify_2esolveF_24s395_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get(v_c_248, LBL_metas);
}
V g_heff_2eunify_2esolveF_24s395_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get(v_c_2412, LBL_selfKey);
}
V g_heff_2eunify_2esolveF_24s395_lam4(V self, V *args) {
  V v_c_2421 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_self_245 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_rec(4, shape_299_167_282_96, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_get(heff_dup(v_c_2421), LBL_postponed)});
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2421), LBL_infos), heff_get(heff_dup(v_c_2421), LBL_recovered), heff_get(heff_dup(v_c_2421), LBL_poisoned), heff_get(heff_dup(v_c_2421), LBL_metas), heff_get(heff_dup(v_c_2421), LBL_nextMeta), v_t_2423, heff_get(heff_dup(v_c_2421), LBL_trace), heff_get(v_c_2421, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s395_lam5(V self, V *args) {
  V v_c_2448 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_self_245 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449 = heff_rec(4, shape_299_167_282_96, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){v_t_2449, heff_get(heff_dup(v_c_2448), LBL_postponed)});
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2448), LBL_infos), heff_get(heff_dup(v_c_2448), LBL_recovered), heff_get(heff_dup(v_c_2448), LBL_poisoned), heff_get(heff_dup(v_c_2448), LBL_metas), heff_get(heff_dup(v_c_2448), LBL_nextMeta), v_t_2450, heff_get(heff_dup(v_c_2448), LBL_trace), heff_get(v_c_2448, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s395_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2462);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2esolveF_24s395_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_args_2424 = heff_env(self)[0];
  V v_args_27_2451 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2457 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2424));
  V v_t_2458 = (g_heff_2eunify_2ezipL(v_args_2424, v_args_27_2451));
  V v_t_2459 = (g_heff_2eunify_2emapWithIndexL_24s387(MK_INT(0LL), v_t_2458));
  V v_t_2460 = (g_heff_2eunify_2ecatMaybes(v_t_2459));
  V v_c_2461 = heff_tr(heff_apply(((V)&g_heff_2eunify_2esolveWithPruned_24s408_clo), 6, (V[]){v_g_240, heff_dup(v_m_242), v_m_242, v_x_2456, v_t_2457, v_t_2460}));
  return heff_tail(v_c_2461, 2, (V[]){v_hd_246, heff_clo(g_heff_2eunify_2esolveF_24s395_lam7, 1, 1, (V[]){v_k_247})});
}
V g_heff_2eunify_2esolveF_24s395_lam8(V self, V *args) {
  V v_c_2463 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_self_245 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2464 = heff_rec(4, shape_299_167_282_96, (V[]){v_cs_241, v_self_245, v_rhs_244, NTAG(TAG_False)});
  V v_t_2465 = heff_tag(TAG_Cons, 2, (V[]){v_t_2464, heff_get(heff_dup(v_c_2463), LBL_postponed)});
  return heff_rec(8, shape_139_266_247_190_202_250_346_296, (V[]){heff_get(heff_dup(v_c_2463), LBL_infos), heff_get(heff_dup(v_c_2463), LBL_recovered), heff_get(heff_dup(v_c_2463), LBL_poisoned), heff_get(heff_dup(v_c_2463), LBL_metas), heff_get(heff_dup(v_c_2463), LBL_nextMeta), v_t_2465, heff_get(heff_dup(v_c_2463), LBL_trace), heff_get(v_c_2463, LBL_selfKey)});
}
V g_heff_2eunify_2esolveF_24s395_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_g_240 = heff_env(self)[7];
  V v_m_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = ({ V a_0 = heff_dup(v_x_2415); V a_1 = v_x_2411; V a_2 = v_sp_243; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_sp_243); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2417 = heff_field(v_t_2416, 0);
    V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 1ULL, 1);
    V v_t_2418 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2417)));
    V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2418); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      v_t_2420 = heff_tag_at(v_ru_24t_2416_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_items_2417))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2417);
      heff_drop_cell(v_ru_24t_2416_24Just, 1);
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    heff_drop(v_x_2415);
    heff_drop(v_x_2411);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    return (g_heff_2eunify_2euModify_24s394(heff_clo(g_heff_2eunify_2esolveF_24s395_lam4, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_args_2424 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    V v_it_2437;
    switch (heff_tag_of(v_rhs_244)) {
    case TAG_VNeu: {
      V v_it1_2425 = heff_dup(heff_field(v_rhs_244, 0));
      V v_sp_2426 = heff_dup(heff_field(v_rhs_244, 1));
      switch (heff_tag_of(v_it1_2425)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2425, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2425, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2432 = heff_field(v_it1_2425, 0);
        heff_take_n(v_it1_2425, 1ULL, 1);
        v_it_2437 = heff_tag_at(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2432, v_sp_2426})});
        break;
      }
      case TAG_HError: {
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_sp_2426);
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2425);
      }
      break;
    }
    case TAG_VCode: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VLam: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VCons: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VOpaque: {
      heff_drop_cell(v_ru_24t_2420_24Just, 1);
      v_it_2437 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_rhs_244);
    }
    switch (heff_tag_of(v_it_2437)) {
    case TAG_Nothing: {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_self_245);
      V v_t_2438 = (g_heff_2eunify_2esolveRhs_24s396(v_g_240, v_cs_241, v_m_242, v_args_2424, v_rhs_244));
      return heff_tail(v_t_2438, 2, (V[]){v_hd_246, v_k_247});
    }
    case TAG_Just: {
      V v_it1_2439 = heff_field(v_it_2437, 0);
      V v_ru_24it_2437_24Just = heff_take_reuse_n(v_it_2437, 1ULL, 1);
      switch (heff_tag_of(v_it1_2439)) {
      case TAG_MkPair: {
        V v_m_27_2440 = heff_field(v_it1_2439, 0);
        V v_sp_27_2441 = heff_field(v_it1_2439, 1);
        heff_take_n(v_it1_2439, 3ULL, 2);
        V v_t_2442 = heff_intEq(v_m_27_2440, heff_dup(v_m_242));
        switch (heff_tag_of(v_t_2442)) {
        case TAG_True: {
          V v_t_2443 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_27_2441; V r_ = (g_heff_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2411); heff_drop(v_sp_27_2441); r_; });
          V v_t_2447;
          switch (heff_tag_of(v_t_2443)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24it_2437_24Just, 1);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_items_2444 = heff_field(v_t_2443, 0);
            heff_take_n(v_t_2443, 1ULL, 1);
            V v_t_2445 = (g_heff_2eunify_2epatVarsOf(heff_dup(v_items_2444)));
            V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2eunify_2edistinct(a_0)); heff_drop(v_t_2445); r_; });
            switch (heff_tag_of(v_t_2446)) {
            case TAG_True: {
              v_t_2447 = heff_tag_at(v_ru_24it_2437_24Just, TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_items_2444))});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2437_24Just, 1);
              heff_drop(v_items_2444);
              v_t_2447 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2446);
            }
            break;
          }
          default: heff_nomatch(v_t_2443);
          }
          switch (heff_tag_of(v_t_2447)) {
          case TAG_Nothing: {
            heff_drop(v_g_240);
            heff_drop(v_m_242);
            heff_drop(v_args_2424);
            return (g_heff_2eunify_2euModify_24s394(heff_clo(g_heff_2eunify_2esolveF_24s395_lam5, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
          }
          case TAG_Just: {
            V v_args_27_2451 = heff_field(v_t_2447, 0);
            heff_take_n(v_t_2447, 1ULL, 1);
            V v_t_2452 = (g_heff_2eunify_2eeqPatArgs(v_args_27_2451, v_args_2424));
            switch (heff_tag_of(v_t_2452)) {
            case TAG_True: {
              heff_drop(v_cs_241);
              heff_drop(v_self_245);
              heff_drop(v_rhs_244);
              heff_drop(v_hd_246);
              heff_drop(v_g_240);
              heff_drop(v_m_242);
              heff_drop(v_args_2424);
              heff_drop(v_args_27_2451);
              V f_ = v_k_247;
              args[0] = NTAG(TAG_MkUnit);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_False: {
              V v_t_2453 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_27_2451));
              V v_t_2454 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_args_2424));
              V v_t_2455 = heff_intEq(v_t_2453, v_t_2454);
              switch (heff_tag_of(v_t_2455)) {
              case TAG_True: {
                heff_drop(v_cs_241);
                heff_drop(v_self_245);
                heff_drop(v_rhs_244);
                return (g_heff_2eunify_2emetaEntry_24s407(heff_dup(v_m_242), heff_dup(v_hd_246), heff_clo(g_heff_2eunify_2esolveF_24s395_lam6, 1, 6, (V[]){v_args_2424, v_args_27_2451, v_g_240, v_m_242, v_hd_246, v_k_247})));
              }
              case TAG_False: {
                heff_drop(v_g_240);
                heff_drop(v_m_242);
                heff_drop(v_args_2424);
                heff_drop(v_args_27_2451);
                return (g_heff_2eunify_2euModify_24s394(heff_clo(g_heff_2eunify_2esolveF_24s395_lam8, 1, 3, (V[]){v_cs_241, v_self_245, v_rhs_244}), v_hd_246, v_k_247));
              }
              default: return heff_nomatch(v_t_2455);
              }
            }
            default: return heff_nomatch(v_t_2452);
            }
          }
          default: return heff_nomatch(v_t_2447);
          }
        }
        case TAG_False: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          heff_drop_cell(v_ru_24it_2437_24Just, 1);
          heff_drop(v_sp_27_2441);
          V v_t_2466 = (g_heff_2eunify_2esolveRhs_24s396(v_g_240, v_cs_241, v_m_242, v_args_2424, v_rhs_244));
          return heff_tail(v_t_2466, 2, (V[]){v_hd_246, v_k_247});
        }
        default: return heff_nomatch(v_t_2442);
        }
      }
      default: return heff_nomatch(v_it1_2439);
      }
    }
    default: return heff_nomatch(v_it_2437);
    }
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2eunify_2esolveF_24s395_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_m_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2eunify_2esolveF_24s395_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2eunify_2esolveF_24s395_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247, v_g_240, v_m_242})});
}
V g_heff_2eunify_2euTypeF_24s392_lam0(V self, V *args);
V g_heff_2eunify_2euTypeF_24s392_lam2(V self, V *args);
V g_heff_2eunify_2euTypeF_24s392_lam4(V self, V *args);
V g_heff_2eunify_2euTypeF_24s392_lam3(V self, V *args);
V g_heff_2eunify_2euTypeF_24s392_lam1(V self, V *args);
Clo g_heff_2eunify_2euTypeF_24s392_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euTypeF_24s392_entry, 6, 0};

V g_heff_2eunify_2euTypeF_24s392(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTypeF_24s392_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2eunify_2euTypeF_24s392_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eunify_2euTypeF_24s392_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euTypeF_24s392(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2euTypeF_24s392_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_246, LBL_metas); V a_1 = v_a0_242; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTypeF_24s392_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_c_2410, LBL_metas); V a_1 = v_b0_243; V r_ = (g_heff_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eunify_2euTypeF_24s392_lam4(V self, V *args) {
  V v_x_2454 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2454);
  return (g_heff_2eunify_2epoisonTy_24s393(heff_get(v_cs_241, LBL_len), v_x_2413, v_hd_244, v_k_245));
}
V g_heff_2eunify_2euTypeF_24s392_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2453;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    v_t_2453 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2435 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2435)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2453 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2435);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  switch (heff_tag_of(v_t_2453)) {
  case TAG_True: {
    heff_drop(v_g_240);
    return (g_heff_2eunify_2epoisonTy_24s393(heff_get(heff_dup(v_cs_241), LBL_len), v_x_249, heff_dup(v_hd_244), heff_clo(g_heff_2eunify_2euTypeF_24s392_lam4, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245})));
  }
  case TAG_False: {
    V v_it_2474;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_it1_2456 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2457 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_it1_2456)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        heff_drop(v_sp_2457);
        v_it_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        heff_drop(v_sp_2457);
        v_it_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2463 = heff_field(v_it1_2456, 0);
        V v_ru_24it1_2456_24HMeta = heff_take_reuse_n(v_it1_2456, 1ULL, 1);
        v_it_2474 = heff_tag_at(v_ru_24it1_2456_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2463, v_sp_2457})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2457);
        v_it_2474 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2456);
      }
      break;
    }
    case TAG_VFunction: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_it_2474 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_it_2474)) {
    case TAG_Nothing: {
      V v_it_2494;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_it1_2476 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2477 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_it1_2476)) {
        case TAG_HLocal: {
          heff_take_n(v_it1_2476, 0ULL, 1);
          heff_drop(v_sp_2477);
          v_it_2494 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_it1_2476, 0ULL, 1);
          heff_drop(v_sp_2477);
          v_it_2494 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_2483 = heff_field(v_it1_2476, 0);
          V v_ru_24it1_2476_24HMeta = heff_take_reuse_n(v_it1_2476, 1ULL, 1);
          v_it_2494 = heff_tag_at(v_ru_24it1_2476_24HMeta, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_m_2483, v_sp_2477})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2477);
          v_it_2494 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_it1_2476);
        }
        break;
      }
      case TAG_VFunction: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_it_2494 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_it_2494)) {
      case TAG_Nothing: {
        V v_t_2495 = ({ V a_0 = heff_dup(g_co_2eplus_24s16_get()); V b_1 = ((V)&g_heff_2eunify_2emsEv_clo); V a_2 = ((V)&g_heff_2eunify_2eufEv_clo); V a_3 = heff_dup(g_heff_2eunify_2euk_24s391_get()); V a_4 = v_g_240; V a_5 = v_cs_241; V a_6 = v_x_249; V a_7 = v_x_2413; V r_ = heff_tr(g_heff_2eunify_2euTyRigid(a_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(b_1); r_; });
        return heff_tail(v_t_2495, 2, (V[]){v_hd_244, v_k_245});
      }
      case TAG_Just: {
        V v_it1_2496 = heff_field(v_it_2494, 0);
        V v_ru_24it_2494_24Just = heff_take_reuse_n(v_it_2494, 1ULL, 1);
        switch (heff_tag_of(v_it1_2496)) {
        case TAG_MkPair: {
          V v_m_2497 = heff_field(v_it1_2496, 0);
          V v_sp_2498 = heff_field(v_it1_2496, 1);
          heff_take_n(v_it1_2496, 3ULL, 2);
          V v_rhs_24115;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24104 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24it_2494_24Just, 1);
            v_rhs_24115 = heff_tr(heff_apply(v_el_24104, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24115 = heff_tag_at(v_ru_24it_2494_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24132;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24121 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24132 = heff_tr(heff_apply(v_el_24121, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24132 = heff_tag(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_2497; V a_3 = v_sp_2498; V a_4 = v_rhs_24115; V a_5 = v_self_24132; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eunify_2esolveF_24s395(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_2498); r_; });
        }
        default: return heff_nomatch(v_it1_2496);
        }
      }
      default: return heff_nomatch(v_it_2494);
      }
    }
    case TAG_Just: {
      V v_it1_24133 = heff_field(v_it_2474, 0);
      V v_ru_24it_2474_24Just = heff_take_reuse_n(v_it_2474, 1ULL, 1);
      switch (heff_tag_of(v_it1_24133)) {
      case TAG_MkPair: {
        V v_m_24134 = heff_field(v_it1_24133, 0);
        V v_sp_24135 = heff_field(v_it1_24133, 1);
        heff_take_n(v_it1_24133, 3ULL, 2);
        V v_rhs_24152;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24141 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24it_2474_24Just, 1);
          v_rhs_24152 = heff_tr(heff_apply(v_el_24141, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24152 = heff_tag_at(v_ru_24it_2474_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24169;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24158 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24169 = heff_tr(heff_apply(v_el_24158, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24169 = heff_tag(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24134; V a_3 = v_sp_24135; V a_4 = v_rhs_24152; V a_5 = v_self_24169; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eunify_2esolveF_24s395(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24135); r_; });
      }
      default: return heff_nomatch(v_it1_24133);
      }
    }
    default: return heff_nomatch(v_it_2474);
    }
  }
  default: return heff_nomatch(v_t_2453);
  }
}
V g_heff_2eunify_2euTypeF_24s392_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2eunify_2euTypeF_24s392_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2eunify_2euTypeF_24s392_lam3, 1, 5, (V[]){v_x_249, v_cs_241, v_hd_244, v_k_245, v_g_240})});
}
V g_heff_2eunify_2euBareF_24s413_lam0(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s413_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s413_lam0, 2, 0};
V g_heff_2eunify_2euBareF_24s413_lam1(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s413_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s413_lam1, 2, 0};
V g_heff_2eunify_2euBareF_24s413_lam2(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam3(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam4(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam5(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam6(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam8(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam7(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam9(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam10(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam11(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam12(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam14(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam13(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam15(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam16(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam17(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam18(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam21(V self, V *args); static Clo g_heff_2eunify_2euBareF_24s413_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s413_lam21, 2, 0};
V g_heff_2eunify_2euBareF_24s413_lam22(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam23(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam20(V self, V *args);
V g_heff_2eunify_2euBareF_24s413_lam19(V self, V *args);
Clo g_heff_2eunify_2euBareF_24s413_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euBareF_24s413_entry, 6, 0};

V g_heff_2eunify_2euBareF_24s413(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    return ((V)&g_heff_2eunify_2euBareF_24s413_lam0_clo);
  }
  case TAG_False: {
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2econversion_2eeqHead(v_h_242, v_h_27_244));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          return ((V)&g_heff_2eunify_2euBareF_24s413_lam1_clo);
        }
        case TAG_False: {
          return heff_clo(g_heff_2eunify_2euBareF_24s413_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
        default: return heff_nomatch(v_t_2421);
        }
      }
      case TAG_SpApp: {
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2447 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2448 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2453 = heff_field(v_sp_27_245, 0);
        V v_v_27_2454 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2455 = (g_heff_2eunify_2euBareF_24s413(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2447, v_h_27_244, v_sq_27_2453));
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam7, 2, 5, (V[]){v_c_2455, v_g_240, v_cs_241, v_v_2448, v_v_27_2454});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2473 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2474 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_2485 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2486 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2487 = (g_heff_2eunify_2euBareF_24s413(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2473, heff_dup(v_h_27_244), v_sq_27_2485));
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam13, 2, 8, (V[]){v_c_2487, v_x_2474, v_x_27_2486, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24101 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24102 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24103 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24120 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24121 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24122 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24123 = (g_heff_2eunify_2euBareF_24s413(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24101, heff_dup(v_h_27_244), v_sq_27_24120));
        return heff_clo(g_heff_2eunify_2euBareF_24s413_lam19, 2, 11, (V[]){v_c_24123, v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24103, v_v_27_24122});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eunify_2euBareF_24s413_entry(V self, V *a) {
  (void)self;
  return g_heff_2eunify_2euBareF_24s413(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eunify_2euBareF_24s413_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euBareF_24s413_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euBareF_24s413_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get(v_hd_2424, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get(v_hd_2430, LBL_bind);
  args[0] = v_t_2433;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2436), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_get(v_hd_2436, LBL_bind);
  args[0] = v_t_2439;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2443), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_get(v_hd_2443, LBL_bind);
  args[0] = v_t_2446;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2451 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2449), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2451})}));
  V f_ = heff_get(v_hd_2449, LBL_bind);
  args[0] = v_t_2452;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2448 = heff_env(self)[2];
  V v_v_27_2454 = heff_env(self)[3];
  V v_hd_2456 = heff_env(self)[4];
  V v_k_2457 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), v_g_240, v_cs_241, v_v_2448, v_v_27_2454));
  return heff_tail(v_t_2459, 2, (V[]){v_hd_2456, v_k_2457});
}
V g_heff_2eunify_2euBareF_24s413_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2448 = heff_env(self)[3];
  V v_v_27_2454 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo(g_heff_2eunify_2euBareF_24s413_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2448, v_v_27_2454, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2462), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2464})}));
  V f_ = heff_get(v_hd_2462, LBL_bind);
  args[0] = v_t_2465;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2471 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2469), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2471})}));
  V f_ = heff_get(v_hd_2469, LBL_bind);
  args[0] = v_t_2472;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam11(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2477 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2475), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_get(v_hd_2475, LBL_bind);
  args[0] = v_t_2478;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2483 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2481), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_get(v_hd_2481, LBL_bind);
  args[0] = v_t_2484;
  args[1] = v_k2_2482;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_x_27_2486 = heff_env(self)[1];
  V v_k_2489 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2488 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2490);
  V v_t_2491 = heff_strEq(v_x_2474, v_x_27_2486);
  switch (heff_tag_of(v_t_2491)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop(v_hd_2488);
    V f_ = v_k_2489;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2492 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_2493 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2488), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2492})}));
    return heff_tail(heff_get(v_hd_2488, LBL_bind), 2, (V[]){v_t_2493, v_k_2489});
  }
  default: return heff_nomatch(v_t_2491);
  }
}
V g_heff_2eunify_2euBareF_24s413_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_x_27_2486 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo(g_heff_2eunify_2euBareF_24s413_lam14, 1, 9, (V[]){v_x_2474, v_x_27_2486, v_k_2489, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam15(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2497), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2499})}));
  V f_ = heff_get(v_hd_2497, LBL_bind);
  args[0] = v_t_24100;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam16(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k2_24105 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24106 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24104), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24106})}));
  V f_ = heff_get(v_hd_24104, LBL_bind);
  args[0] = v_t_24107;
  args[1] = v_k2_24105;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24112 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24113 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24110), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_get(v_hd_24110, LBL_bind);
  args[0] = v_t_24113;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24118 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24116), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24118})}));
  V f_ = heff_get(v_hd_24116, LBL_bind);
  args[0] = v_t_24119;
  args[1] = v_k2_24117;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam21(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eunify_2euBareF_24s413_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24132 = heff_tag(TAG_Throw, 1, (V[]){heff_tag(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24133 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_24130), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24132})}));
  V f_ = heff_get(v_hd_24130, LBL_bind);
  args[0] = v_t_24133;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euBareF_24s413_lam23(V self, V *args) {
  V v_x_24135 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24103 = heff_env(self)[2];
  V v_v_27_24122 = heff_env(self)[3];
  V v_hd_24124 = heff_env(self)[4];
  V v_k_24125 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24135);
  V v_t_24136 = (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), v_g_240, v_cs_241, v_v_24103, v_v_27_24122));
  return heff_tail(v_t_24136, 2, (V[]){v_hd_24124, v_k_24125});
}
V g_heff_2eunify_2euBareF_24s413_lam20(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_x_27_24121 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_24124 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  V v_k_24125 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_24126);
  V v_t_24127 = heff_strEq(v_x_24102, v_x_27_24121);
  V v_c_24134;
  switch (heff_tag_of(v_t_24127)) {
  case TAG_True: {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_c_24134 = ((V)&g_heff_2eunify_2euBareF_24s413_lam21_clo);
    break;
  }
  case TAG_False: {
    v_c_24134 = heff_clo(g_heff_2eunify_2euBareF_24s413_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
    break;
  }
  default: heff_nomatch(v_t_24127);
  }
  return heff_tail(v_c_24134, 2, (V[]){heff_dup(v_hd_24124), heff_clo(g_heff_2eunify_2euBareF_24s413_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24103, v_v_27_24122, v_hd_24124, v_k_24125})});
}
V g_heff_2eunify_2euBareF_24s413_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_x_27_24121 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo(g_heff_2eunify_2euBareF_24s413_lam20, 1, 12, (V[]){v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24124, v_g_240, v_v_24103, v_v_27_24122, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eunify_2euk_24s391_lam0(V self, V *args); static Clo g_heff_2eunify_2euk_24s391_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eunify_2euk_24s391_lam0, 4, 0};

static V g_heff_2eunify_2euk_24s391_val;
static int g_heff_2eunify_2euk_24s391_st;
static V g_heff_2eunify_2euk_24s391_init(void) {
  return heff_rec(9, shape_364_357_356_310_267_268_271_269_270, (V[]){((V)&g_heff_2eunify_2euTypeF_24s392_clo), ((V)&g_heff_2eunify_2euk_24s391_lam0_clo), ((V)&g_heff_2eunify_2euBareF_24s413_clo), ((V)&g_heff_2eunify_2esolveF_24s395_clo), ((V)&g_heff_2eunify_2erenameF_24s400_clo), ((V)&g_heff_2eunify_2erenameEvF_24s404_clo), ((V)&g_heff_2eunify_2erenameTypeF_24s409_clo), ((V)&g_heff_2eunify_2erenameEvTypeF_24s411_clo), ((V)&g_heff_2eunify_2erenameFlexF_24s406_clo)});
}
V g_heff_2eunify_2euk_24s391_get(void) {
  if (g_heff_2eunify_2euk_24s391_st == 2) return g_heff_2eunify_2euk_24s391_val;
  if (g_heff_2eunify_2euk_24s391_st == 1) heff_fail("defined by itself");
  g_heff_2eunify_2euk_24s391_st = 1;
  g_heff_2eunify_2euk_24s391_val = heff_tr(g_heff_2eunify_2euk_24s391_init());
  g_heff_2eunify_2euk_24s391_st = 2;
  return g_heff_2eunify_2euk_24s391_val;
}
V g_heff_2eunify_2euk_24s391_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eunify_2euTermF(heff_dup(g_co_2eplus_24s16_get()), ((V)&g_heff_2eunify_2emsEv_clo), ((V)&g_heff_2eunify_2eufEv_clo), heff_dup(g_heff_2eunify_2euk_24s391_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}