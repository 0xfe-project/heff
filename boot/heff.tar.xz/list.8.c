// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CDrop 58400
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IVal 40987
#define TAG_ImplicitParam 51130
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_PatVar 49363
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetMut 50164
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_filter 672649891
#define LBL_flags 298871457
#define LBL_key 315609
#define LBL_looser 850054335
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_param 307795111
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_post 9942375
#define LBL_ships 310766033
#define LBL_shown 310772011
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tok 324554
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_value 313331083
#define LBL_version 583465758
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_value__ty__size__flags__span[] = {LBL_value, LBL_ty, LBL_size, LBL_flags, LBL_span};
V g_heff_2ebuild_2ebackcache_2eaddCopy(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eglueProvider(V);
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efuse_2earmWorks(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmWorks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmWorks_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2esimplify_2eetaMade(V, V);
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaMade_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2eworker_2etailCalls(V);
V g_heff_2ecompile_2eworker_2etailCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2etailCalls_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2esplit_2eexprName(V);
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_clo;
V g_heff_2esyntax_2eformat_2ealtKey(V, V);
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ealtKey_clo;
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(V);
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_clo;
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2epresyntax_2earmStmts(V);
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_list_2eall_24s1297075057x1726753756(V, V);
V g_list_2eall_24s1297075057x1726753756_entry(V self, V *a);
extern Clo g_list_2eall_24s1297075057x1726753756_clo;
V g_list_2eall_24s1543979616x278497281(V, V, V, V, V);
V g_list_2eall_24s1543979616x278497281_entry(V self, V *a);
extern Clo g_list_2eall_24s1543979616x278497281_clo;
V g_list_2eall_24s853093203x77424416(V);
V g_list_2eall_24s853093203x77424416_entry(V self, V *a);
extern Clo g_list_2eall_24s853093203x77424416_clo;
V g_list_2eany_24s100684943x1504448948(V, V);
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a);
extern Clo g_list_2eany_24s100684943x1504448948_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2eany_24s2049730270x433866075(V);
V g_list_2eany_24s2049730270x433866075_entry(V self, V *a);
extern Clo g_list_2eany_24s2049730270x433866075_clo;
V g_list_2efilter_24s1328865458x1020778875(V);
V g_list_2efilter_24s1328865458x1020778875_entry(V self, V *a);
extern Clo g_list_2efilter_24s1328865458x1020778875_clo;
V g_list_2efilter_24s1328865458x1020778875_24dps(V, V);
V g_list_2efilter_24s1328865458x1020778875_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1328865458x1020778875_24dps_clo;
V g_list_2efilter_24s1371839958x1221974112_24dps(V, V, V);
V g_list_2efilter_24s1371839958x1221974112_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1371839958x1221974112_24dps_clo;
V g_list_2efilter_24s1582543556x1700452857(V, V, V);
V g_list_2efilter_24s1582543556x1700452857_entry(V self, V *a);
extern Clo g_list_2efilter_24s1582543556x1700452857_clo;
V g_list_2efilter_24s1596967535x1519602627(V, V);
V g_list_2efilter_24s1596967535x1519602627_entry(V self, V *a);
extern Clo g_list_2efilter_24s1596967535x1519602627_clo;
V g_list_2efilter_24s1596967535x1519602627_24dps(V, V, V);
V g_list_2efilter_24s1596967535x1519602627_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1596967535x1519602627_24dps_clo;
V g_list_2efilter_24s1646962431x688731818(V, V);
V g_list_2efilter_24s1646962431x688731818_entry(V self, V *a);
extern Clo g_list_2efilter_24s1646962431x688731818_clo;
V g_list_2efilter_24s1646962431x688731818_24dps(V, V, V);
V g_list_2efilter_24s1646962431x688731818_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1646962431x688731818_24dps_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efilter_24s1967523567x64647275_24dps(V, V);
V g_list_2efilter_24s1967523567x64647275_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_24dps_clo;
V g_list_2efilter_24s639151216x1214259357_24dps(V, V, V, V);
V g_list_2efilter_24s639151216x1214259357_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_24dps_clo;
HeffT2 g_list_2efind_24s1085725546x1737150855_24cpr(V, V);
HeffT2 g_list_2efind_24s1119339522x336883298_24cpr(V, V);
HeffT2 g_list_2efind_24s1637307977x1351693783_24cpr(V, V, V, V, V, V);
V g_list_2efind_24s1816408632x1283768171(V, V);
V g_list_2efind_24s1816408632x1283768171_entry(V self, V *a);
extern Clo g_list_2efind_24s1816408632x1283768171_clo;
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24f129939610x1317417911(V, V, V, V, V, V);
V g_list_2efoldl_24f129939610x1317417911_entry(V self, V *a);
extern Clo g_list_2efoldl_24f129939610x1317417911_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24f625837968x2121675523(V, V, V);
V g_list_2efoldl_24f625837968x2121675523_entry(V self, V *a);
extern Clo g_list_2efoldl_24f625837968x2121675523_clo;
V g_list_2efoldl_24s1068175575x1869083571(V, V);
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1068175575x1869083571_clo;
V g_list_2efoldl_24s1103469845x1474178821(V, V, V);
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1103469845x1474178821_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370766569x1161039615(V, V);
V g_list_2efoldl_24s1370766569x1161039615_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370766569x1161039615_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1418838819x1907320638(V, V);
V g_list_2efoldl_24s1418838819x1907320638_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1418838819x1907320638_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1719254312x1333482082(V, V, V);
V g_list_2efoldl_24s1719254312x1333482082_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1719254312x1333482082_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s1880194630x798487332(V, V);
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1880194630x798487332_clo;
V g_list_2efoldl_24s1982386833x551161312(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1982386833x551161312_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s513294106x1954328253(V, V, V, V);
V g_list_2efoldl_24s513294106x1954328253_entry(V self, V *a);
extern Clo g_list_2efoldl_24s513294106x1954328253_clo;
V g_list_2efoldl_24s559655048x2117761193(V, V);
V g_list_2efoldl_24s559655048x2117761193_entry(V self, V *a);
extern Clo g_list_2efoldl_24s559655048x2117761193_clo;
V g_list_2efoldl_24s629835174x643023540(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s629835174x643023540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s629835174x643023540_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s797527640x986490519(V, V);
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a);
extern Clo g_list_2efoldl_24s797527640x986490519_clo;
V g_list_2emap_24f130772758x674845987_24f797488600x357897558(V, V, V, V);
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_clo;
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(V, V, V, V, V);
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps_clo;
V g_list_2emap_24f336527456x1519848451(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f336527456x1519848451_entry(V self, V *a);
extern Clo g_list_2emap_24f336527456x1519848451_clo;
V g_list_2emap_24f336527456x1519848451_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f336527456x1519848451_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f336527456x1519848451_24dps_clo;
V g_list_2emap_24f342794667x1308411312_24dps(V, V, V);
V g_list_2emap_24f342794667x1308411312_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f342794667x1308411312_24dps_clo;
V g_list_2emap_24s1006818869x590968200_24dps(V, V);
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_24dps_clo;
V g_list_2emap_24s1047941608x1265580215(V, V, V, V, V, V, V);
V g_list_2emap_24s1047941608x1265580215_entry(V self, V *a);
extern Clo g_list_2emap_24s1047941608x1265580215_clo;
V g_list_2emap_24s1047941608x1265580215_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1047941608x1265580215_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1047941608x1265580215_24dps_clo;
V g_list_2emap_24s1152414072x2935301_24dps(V, V, V);
V g_list_2emap_24s1152414072x2935301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_24dps_clo;
V g_list_2emap_24s1170504272x1852564147_24dps(V, V);
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_24dps_clo;
V g_list_2emap_24s1218298322x1569510752_24dps(V, V, V);
V g_list_2emap_24s1218298322x1569510752_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_24dps_clo;
V g_list_2emap_24s1230649048x711093514_24dps(V, V, V);
V g_list_2emap_24s1230649048x711093514_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_24dps_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s135291903x1031656159_24dps(V, V, V);
V g_list_2emap_24s135291903x1031656159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_24dps_clo;
V g_list_2emap_24s1366476796x894764441_24dps(V, V, V);
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_24dps_clo;
V g_list_2emap_24s1372232877x278600396(V);
V g_list_2emap_24s1372232877x278600396_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_clo;
V g_list_2emap_24s1372232877x278600396_24dps(V, V);
V g_list_2emap_24s1372232877x278600396_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_24dps_clo;
V g_list_2emap_24s143096761x246530315_24dps(V, V);
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_24dps_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s1435185561x202019164_24dps(V, V);
V g_list_2emap_24s1435185561x202019164_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_24dps_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1535007417x1587061701_24dps(V, V);
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_24dps_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s1624059865x1140896478_24dps(V, V);
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_24dps_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1895313378x47656836_24dps(V, V);
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_24dps_clo;
V g_list_2emap_24s1902028738x441242582_24dps(V, V);
V g_list_2emap_24s1902028738x441242582_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s2016443462x370533815(V);
V g_list_2emap_24s2016443462x370533815_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_clo;
V g_list_2emap_24s2016443462x370533815_24dps(V, V);
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_24dps_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s2130193383x1335133353_24dps(V, V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_24dps_clo;
V g_list_2emap_24s228910449x1110031924(V, V);
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_clo;
V g_list_2emap_24s228910449x1110031924_24dps(V, V, V);
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s313852718x340738167(V, V);
V g_list_2emap_24s313852718x340738167_entry(V self, V *a);
extern Clo g_list_2emap_24s313852718x340738167_clo;
V g_list_2emap_24s313852718x340738167_24dps(V, V, V);
V g_list_2emap_24s313852718x340738167_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s313852718x340738167_24dps_clo;
V g_list_2emap_24s32026788x2029987799_24dps(V, V);
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_24dps_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_list_2emap_24s370939663x1496042695_24dps(V, V, V);
V g_list_2emap_24s370939663x1496042695_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_24dps_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s435407392x1528135477_24dps(V, V);
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_24dps_clo;
V g_list_2emap_24s577269653x49010166(V);
V g_list_2emap_24s577269653x49010166_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24s831190316x576961335_24dps(V, V);
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s864521685x1610969087_24dps(V, V);
V g_list_2emap_24s864521685x1610969087_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_24dps_clo;
V g_list_2emap_24s886389550x1086668531(V);
V g_list_2emap_24s886389550x1086668531_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_clo;
V g_list_2emap_24s886389550x1086668531_24dps(V, V);
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_24dps_clo;
V g_list_2emap_24s961097229x1129443801_24dps(V, V);
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_24dps_clo;
V g_list_2emerge_24s1904498032x521599863(V, V);
V g_list_2emerge_24s1904498032x521599863_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_clo;
V g_list_2emerge_24s1904498032x521599863_24dps(V, V, V);
V g_list_2emerge_24s1904498032x521599863_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1904498032x521599863_24dps_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1026658656x682908126_24dps(V, V, V);
V g_list_2ezipWith_24s1026658656x682908126_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s528321443x971020870_24dps(V, V, V);
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
Clo g_list_2eall_24s853093203x77424416_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s853093203x77424416_entry, 1, 0};

V g_list_2eall_24s853093203x77424416(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_r1_243 = heff_field(v_x_241, 0);
      V v_r2_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_r1_243)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_r2_244)) {
        case TAG_Nothing: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_Just: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_r2_244);
        }
      }
      case TAG_Just: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_r1_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s853093203x77424416_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s853093203x77424416(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s1026658656x682908126_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1026658656x682908126_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1026658656x682908126_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eranges_2ejoin(v_x_243, v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1026658656x682908126_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1026658656x682908126_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1719254312x1333482082_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1719254312x1333482082_entry, 3, 0};

V g_list_2efoldl_24s1719254312x1333482082(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2415;
    if (heff_intLe_c_lent(v_lit_240, v_t_247, 2)) {
      V v_a_2411;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_249 = heff_field(v_x_243, 0);
        v_a_2411 = heff_dup(v_a_249);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      switch (heff_tag_of(v_z_241)) {
      case TAG_Nothing: {
        v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2411});
        break;
      }
      case TAG_Just: {
        V v_a_2412 = heff_field(v_z_241, 0);
        V v_ru_24z_241_24Just = heff_take_reuse_n(v_z_241, 1ULL, 1);
        V v_t_2414;
        if (heff_intLt_c_lent(v_a_2412, v_a_2411, 0)) {
          heff_drop(v_a_2411);
          v_t_2414 = v_a_2412;
        } else {
          heff_drop(v_a_2412);
          v_t_2414 = v_a_2411;
        }
        v_t_2415 = heff_tag_at_n(v_ru_24z_241_24Just, TAG_Just, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_z_241);
      }
    } else {
      v_t_2415 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1719254312x1333482082_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1719254312x1333482082(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s629835174x643023540_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s629835174x643023540_entry, 14, 0};

V g_list_2efoldl_24s629835174x643023540(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_z_2412, V v_x3_2413) {
top: ;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return v_z_2412;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x3_2413, 0);
    V v_xs_2415 = heff_field(v_x3_2413, 1);
    V v_a_2418;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_2414, 1);
      v_a_2418 = heff_dup(v_a_2417);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_243), heff_dup(v_lit_244), v_a_2418));
    V v_t_2420 = (g_list_2erange(heff_dup(v_lit_242), heff_intSub(v_t_2419, heff_dup(v_lit_245))));
    V v_t_2421 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2420, v_a_2418));
    V v_t_2422 = (g_list_2efilter_24s1582543556x1700452857(heff_dup(v_lit_240), heff_dup(v_lit_241), v_t_2421));
    V v_a_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
    V v_t_2437;
    switch (heff_tag_of(v_a_2423)) {
    case TAG_Nil: {
      v_t_2437 = v_z_2412;
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_a_2423, 0ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_MkPair: {
        V v_a_2426 = heff_field(v_x_2414, 0);
        v_t_2428 = heff_dup(v_a_2426);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_a_2431;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_MkPair: {
        V v_a_2430 = heff_field(v_x_2414, 1);
        v_a_2431 = heff_dup(v_a_2430);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_249), heff_dup(v_lit_2410), v_a_2431));
      V v_t_2433 = (g_list_2erange(heff_dup(v_lit_248), heff_intSub(v_t_2432, heff_dup(v_lit_2411))));
      V v_t_2434 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2433, v_a_2431));
      V v_t_2435 = (g_list_2efilter_24s1582543556x1700452857(heff_dup(v_lit_246), heff_dup(v_lit_247), v_t_2434));
      V v_t_2436 = (g_list_2emap_24s1937570095x2110149801(v_t_2435));
      v_t_2437 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_2412, v_t_2428, v_t_2436));
      break;
    }
    default: heff_nomatch(v_a_2423);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_lit_2410;
    V t_11 = v_lit_2411;
    V t_12 = v_t_2437;
    V t_13 = v_xs_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_lit_2410 = t_10;
    v_lit_2411 = t_11;
    v_z_2412 = t_12;
    v_x3_2413 = t_13;
    goto top;
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_list_2efoldl_24s629835174x643023540_entry(V self, V *a) {
  (void)self;
  V a13 = a[13]; V r = g_list_2efoldl_24s629835174x643023540(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a13); heff_drop(a13); return r;
}
Clo g_list_2efoldl_24s1068175575x1869083571_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1068175575x1869083571_entry, 2, 0};

V g_list_2efoldl_24s1068175575x1869083571(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_2439;
    switch (heff_tag_of(v_t_244)) {
    case TAG_EVar: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_244, 0ULL, 3);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_244, 0ULL, 4);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_244, 0ULL, 3);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EInt: {
      V v_n_2430 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      v_t_2439 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), v_n_2430));
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_244, 0ULL, 1);
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EAbandon: {
      v_t_2439 = v_z_240;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_2439;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1068175575x1869083571(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1596967535x1519602627_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1596967535x1519602627_entry, 2, 0};

V g_list_2efilter_24s1596967535x1519602627(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_x_242, 1)))) {
        heff_drop_rec(v_x_242, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_247 = (g_list_2efilter_24s1596967535x1519602627_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1596967535x1519602627_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1596967535x1519602627_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1596967535x1519602627(a[0], a[1]);
}
Clo g_list_2emap_24s32026788x2029987799_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s32026788x2029987799_24dps_entry, 2, 0};

V g_list_2emap_24s32026788x2029987799_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_x_242, 0), heff_take_field(v_x_242, 1), NTAG(TAG_Nothing), heff_get_n(v_x_242, 2, 3), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s32026788x2029987799_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2049730270x433866075_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2049730270x433866075_entry, 1, 0};

V g_list_2eany_24s2049730270x433866075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2earmStmts(v_a_246));
        v_t_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_a_245, v_t_247});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_a_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2411));
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      heff_drop(v_xs_242);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      V v_t_2426;
      switch (heff_tag_of(v_a_2413)) {
      case TAG_At: {
        V v_a_2415 = heff_field(v_a_2413, 0);
        heff_take_n(v_a_2413, 1ULL, 2);
        switch (heff_tag_of(v_a_2415)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2415, 0ULL, 3);
          v_t_2426 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2415, 0ULL, 2);
          v_t_2426 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtExpr: {
          V v_a_2422 = heff_field(v_a_2415, 0);
          heff_take_n(v_a_2415, 1ULL, 1);
          v_t_2426 = ({ V a_0 = v_a_2422; V r_ = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(a_0)); heff_drop(v_a_2422); r_; });
          break;
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2415, 0ULL, 3);
          v_t_2426 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_2415);
        }
        break;
      }
      default: heff_nomatch(v_a_2413);
      }
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_xs_242);
        heff_drop(v_t_2426);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2426);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2412);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2049730270x433866075_entry(V self, V *a) {
  (void)self;
  return g_list_2eany_24s2049730270x433866075(a[0]);
}
Clo g_list_2emap_24s961097229x1129443801_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s961097229x1129443801_24dps_entry, 2, 0};

V g_list_2emap_24s961097229x1129443801_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s961097229x1129443801_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1782778565x402128078_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_entry, 1, 0};

V g_list_2emap_24s1782778565x402128078(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        V v_ru_24a_243_24MkEquation = heff_take_reuse_n(v_a_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_245, v_a_246, v_a_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s1782778565x402128078_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_entry, 1, 0};

V g_list_2emap_24s386875578x1005587669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s386875578x1005587669_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669(a[0]);
}
Clo g_list_2emap_24s1624059865x1140896478_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_entry, 1, 0};

V g_list_2emap_24s1624059865x1140896478(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2esurface_2easNameE(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1624059865x1140896478_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478(a[0]);
}
Clo g_list_2emap_24s2130193383x1335133353_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2130193383x1335133353_entry, 4, 0};

V g_list_2emap_24s2130193383x1335133353(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_x_244; V r_ = (g_heff_2esyntax_2esurface_2eassembleDiagOne(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s2130193383x1335133353_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24s2130193383x1335133353(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1006818869x590968200_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006818869x590968200_24dps_entry, 2, 0};

V g_list_2emap_24s1006818869x590968200_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 7), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006818869x590968200_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str0, 7, "Float64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str10, 1, "_");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str11, 1, "\?");
Clo g_list_2emap_24s143096761x246530315_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s143096761x246530315_24dps_entry, 2, 0};

V g_list_2emap_24s143096761x246530315_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s143096761x246530315_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s528321443x971020870_24dps_entry, 3, 0};

V g_list_2ezipWith_24s528321443x971020870_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2esimplify_2eetaMade(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s528321443x971020870_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1328865458x1020778875_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1328865458x1020778875_entry, 1, 0};

V g_list_2efilter_24s1328865458x1020778875(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1328865458x1020778875_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1328865458x1020778875_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1328865458x1020778875(a[0]);
}
Clo g_list_2efoldl_24s1982386833x551161312_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1982386833x551161312_entry, 14, 0};

V g_list_2efoldl_24s1982386833x551161312(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_z_2412, V v_x3_2413) {
top: ;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return v_z_2412;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x3_2413, 0);
    V v_xs_2415 = heff_field(v_x3_2413, 1);
    V v_t_2418;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_2414, 1);
      v_t_2418 = heff_dup(v_a_2417);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2420;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_RepV: {
      v_t_2420 = heff_dup(v_lit_240);
      break;
    }
    case TAG_RepFix: {
      V v_a_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      switch (heff_tag_of(v_a_2419)) {
      case TAG_I8: {
        v_t_2420 = heff_dup(v_lit_241);
        break;
      }
      case TAG_I16: {
        v_t_2420 = heff_dup(v_lit_242);
        break;
      }
      case TAG_I32: {
        v_t_2420 = heff_dup(v_lit_243);
        break;
      }
      case TAG_I64: {
        v_t_2420 = heff_dup(v_lit_244);
        break;
      }
      case TAG_U8: {
        v_t_2420 = heff_dup(v_lit_245);
        break;
      }
      case TAG_U16: {
        v_t_2420 = heff_dup(v_lit_246);
        break;
      }
      case TAG_U32: {
        v_t_2420 = heff_dup(v_lit_247);
        break;
      }
      case TAG_U64: {
        v_t_2420 = heff_dup(v_lit_248);
        break;
      }
      case TAG_F32: {
        v_t_2420 = heff_dup(v_lit_249);
        break;
      }
      default: heff_nomatch(v_a_2419);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_2420 = heff_dup(v_lit_2410);
      break;
    }
    case TAG_RepInt: {
      v_t_2420 = heff_dup(v_lit_2411);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2423;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2421 = heff_field(v_x_2414, 0);
      v_t_2423 = heff_dup(v_a_2421);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2424 = (g_heff_2ecompile_2erepr_2efourTo(v_t_2423));
    V v_t_2425 = heff_intAdd(v_z_2412, heff_intMul(v_t_2420, v_t_2424));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_lit_2410;
    V t_11 = v_lit_2411;
    V t_12 = v_t_2425;
    V t_13 = v_xs_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_lit_2410 = t_10;
    v_lit_2411 = t_11;
    v_z_2412 = t_12;
    v_x3_2413 = t_13;
    goto top;
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a) {
  (void)self;
  V a13 = a[13]; V r = g_list_2efoldl_24s1982386833x551161312(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a13); heff_drop(a13); return r;
}
Clo g_list_2efoldl_24s1690891682x1517899652_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1690891682x1517899652_entry, 2, 0};

V g_list_2efoldl_24s1690891682x1517899652(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_t_246, v_t_249}), v_z_240});
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1690891682x1517899652(a[0], a[1]);
}
Clo g_list_2eany_24s100684943x1504448948_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s100684943x1504448948_entry, 2, 0};

V g_list_2eany_24s100684943x1504448948(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s100684943x1504448948(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1370766569x1161039615_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370766569x1161039615_entry, 2, 0};

V g_list_2efoldl_24s1370766569x1161039615(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_242, 0);
        v_t_249 = heff_dup(v_a_247);
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, v_t_249, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_t_246);
      v_t_2410 = v_z_240;
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1370766569x1161039615_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1370766569x1161039615(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1902028738x441242582_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1902028738x441242582_24dps_entry, 2, 0};

V g_list_2emap_24s1902028738x441242582_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = NTAG(TAG_FtOther);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24RepFix = heff_take_reuse_n(v_x_242, 1ULL, 1);
      v_t_245 = heff_tag_at_n(v_ru_24x_242_24RepFix, TAG_FtFixed, 1, (V[]){v_w_244});
      break;
    }
    case TAG_RepF64: {
      v_t_245 = NTAG(TAG_FtFloat);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = NTAG(TAG_FtOther);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1902028738x441242582_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1902028738x441242582_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s559655048x2117761193_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s559655048x2117761193_entry, 2, 0};

V g_list_2efoldl_24s559655048x2117761193(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2edelete_24s339308281x1667047697(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s559655048x2117761193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s559655048x2117761193(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s141450647x925029990_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s141450647x925029990_entry, 1, 0};

V g_list_2eany_24s141450647x925029990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s141450647x925029990_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s141450647x925029990(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1880194630x798487332_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1880194630x798487332_entry, 2, 0};

V g_list_2efoldl_24s1880194630x798487332(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1880194630x798487332(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s797527640x986490519_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s797527640x986490519_entry, 2, 0};

V g_list_2efoldl_24s797527640x986490519(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_a_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1880194630x798487332(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s797527640x986490519(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1543979616x278497281_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1543979616x278497281_entry, 5, 0};

V g_list_2eall_24s1543979616x278497281(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_t_247 = (g_heff_2ecompile_2efuse_2earmWorks(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_lit_243, v_x_245));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_t_247);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2eall_24s1543979616x278497281_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_list_2eall_24s1543979616x278497281(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_list_2emap_24s1796125103x644876049_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_24dps_entry, 2, 0};

V g_list_2emap_24s1796125103x644876049_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1119339522x336883298_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 5);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1418838819x1907320638_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1418838819x1907320638_entry, 2, 0};

V g_list_2efoldl_24s1418838819x1907320638(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2eworker_2etailCalls(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1418838819x1907320638_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1418838819x1907320638(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s184951243x1948563855_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s184951243x1948563855_entry, 1, 0};

V g_list_2eany_24s184951243x1948563855(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = (g_heff_2ecompile_2eemit_2eloops(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s184951243x1948563855(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1366476796x894764441_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1366476796x894764441_24dps_entry, 3, 0};

V g_list_2emap_24s1366476796x894764441_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_243, heff_dup(v_lit_240)), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1366476796x894764441_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s649333309x1802289391_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_entry, 1, 0};

V g_list_2emap_24s649333309x1802289391(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eemit_2ehostLineOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s649333309x1802289391_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391(a[0]);
}
Clo g_list_2emap_24s720989758x1967438448_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_entry, 1, 0};

V g_list_2emap_24s720989758x1967438448(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s720989758x1967438448_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448(a[0]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str1, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str2, 2, ");");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str3, 10, "heff_drop(");
Clo g_list_2emap_24s577269653x49010166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_entry, 1, 0};

V g_list_2emap_24s577269653x49010166(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_x12_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = ({ V a_0 = v_x_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s577269653x49010166_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_243); r_; });
        V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_str1), v_t_245), ((V)&g_list_2emap_24s577269653x49010166_str2));
        v_t_248 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_str3), v_t_246);
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_243); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s577269653x49010166_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166(a[0]);
}
Clo g_list_2efoldl_24s2138447488x1597606028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2138447488x1597606028_entry, 2, 0};

V g_list_2efoldl_24s2138447488x1597606028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2138447488x1597606028(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1218298322x1569510752_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1218298322x1569510752_24dps_entry, 3, 0};

V g_list_2emap_24s1218298322x1569510752_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1218298322x1569510752_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1218298322x1569510752_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1967523567x64647275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1967523567x64647275_entry, 1, 0};

V g_list_2efilter_24s1967523567x64647275(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = v_x_241; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1967523567x64647275_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1967523567x64647275(a[0]);
}
Clo g_list_2efoldl_24s1103469845x1474178821_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1103469845x1474178821_entry, 3, 0};

V g_list_2efoldl_24s1103469845x1474178821(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddCopy(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1103469845x1474178821(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s886389550x1086668531_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s886389550x1086668531_entry, 1, 0};

V g_list_2emap_24s886389550x1086668531(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_v_245 = heff_field(v_x11_243, 0);
        V v_ty_246 = heff_field(v_x11_243, 1);
        V v_size_247 = heff_field(v_x11_243, 2);
        V v_little_248 = heff_field(v_x11_243, 3);
        V v_signed_249 = heff_field(v_x11_243, 4);
        heff_take_n(v_x11_243, 31ULL, 5);
        int64_t v_t_2410;
        if ((heff_dup(v_little_248) == NTAG(TAG_True))) {
          heff_drop(v_little_248);
          v_t_2410 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_248);
          v_t_2410 = ((int64_t)0ULL);
        }
        int64_t v_t_2411;
        if ((heff_dup(v_signed_249) == NTAG(TAG_True))) {
          heff_drop(v_signed_249);
          v_t_2411 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_249);
          v_t_2411 = ((int64_t)0ULL);
        }
        v_t_2412 = heff_rec_n(5, shape_value__ty__size__flags__span, (V[]){v_v_245, v_ty_246, v_size_247, heff_box_word((v_t_2410 + v_t_2411)), v_sp_244});
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s886389550x1086668531_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s886389550x1086668531_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s886389550x1086668531(a[0]);
}
Clo g_list_2emap_24s1230649048x711093514_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230649048x711093514_24dps_entry, 3, 0};

V g_list_2emap_24s1230649048x711093514_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_243}), heff_dup(v_lit_240)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1230649048x711093514_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230649048x711093514_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s1297075057x1726753756_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1297075057x1726753756_entry, 2, 0};

V g_list_2eall_24s1297075057x1726753756(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(heff_rfield(v_x_242, 1), heff_rfield(v_x_242, 2)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_248 = v_field_246;
        if (heff_intEq_c_lent(v_a_248, v_lit_240, 1)) {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_lit_240);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_field_246);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s1297075057x1726753756_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s1297075057x1726753756(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s864521685x1610969087_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_entry, 1, 0};

V g_list_2emap_24s864521685x1610969087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edriver_2ehint(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s864521685x1610969087_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087(a[0]);
}
Clo g_list_2emap_24s864521685x1610969087_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_24dps_entry, 2, 0};

V g_list_2emap_24s864521685x1610969087_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ehint(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1535007417x1587061701_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_entry, 1, 0};

V g_list_2emap_24s1535007417x1587061701(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2419 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x_241_24At, TAG_MkPair, 2, (V[]){v_x_2419, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = (g_list_2emap_24s1535007417x1587061701_24dps(v_xs_242, heff_dup(v_cell_2426)));
    heff_drop(v_u_2427);
    return v_cell_2426;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701(a[0]);
}
Clo g_list_2emap_24s370939663x1496042695_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s370939663x1496042695_entry, 2, 0};

V g_list_2emap_24s370939663x1496042695(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_242)));
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_242, 2, 5));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_244, v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s370939663x1496042695_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s370939663x1496042695(a[0], a[1]);
}
Clo g_list_2efilter_24s1646962431x688731818_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1646962431x688731818_entry, 2, 0};

V g_list_2efilter_24s1646962431x688731818(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1646962431x688731818_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1646962431x688731818_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1646962431x688731818(a[0], a[1]);
}
Clo g_list_2emap_24s1895313378x47656836_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_24dps_entry, 2, 0};

V g_list_2emap_24s1895313378x47656836_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2016443462x370533815_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016443462x370533815_entry, 1, 0};

V g_list_2emap_24s2016443462x370533815(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2016443462x370533815_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2016443462x370533815_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016443462x370533815(a[0]);
}
Clo g_list_2emap_24s1047941608x1265580215_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1047941608x1265580215_entry, 7, 0};

V g_list_2emap_24s1047941608x1265580215(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkFieldPat: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkFieldPat = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2esyntax_2eformat_2epatKey(v_a_2410));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_a_2413 = heff_tag_at_n(v_ru_24x_247_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_249, v_t_2412});
      V v_a_2414 = (g_list_2emap_24s231073986x752637537(heff_dup(v_lit_242), v_a_2413));
      V v_t_2417;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        v_t_2417 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        V v_a_2416 = heff_field(v_a_2414, 1);
        heff_take_n(v_a_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2415; V a_2 = v_a_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2416); r_; });
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      V v_t_2418 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2417, heff_dup(v_lit_245)));
      v_t_2419 = heff_strAppend(heff_dup(v_lit_240), v_t_2418);
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = (g_list_2emap_24s1047941608x1265580215_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2420)));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1047941608x1265580215_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1047941608x1265580215(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1561756891x1126436879_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_entry, 1, 0};

V g_list_2emap_24s1561756891x1126436879(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2eformat_2epatKey(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1561756891x1126436879_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879(a[0]);
}
Clo g_list_2emap_24s135291903x1031656159_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s135291903x1031656159_24dps_entry, 3, 0};

V g_list_2emap_24s135291903x1031656159_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2efieldDeclKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s135291903x1031656159_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s135291903x1031656159_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1152414072x2935301_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1152414072x2935301_24dps_entry, 3, 0};

V g_list_2emap_24s1152414072x2935301_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2ealtKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1152414072x2935301_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1152414072x2935301_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s313852718x340738167_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s313852718x340738167_entry, 2, 0};

V g_list_2emap_24s313852718x340738167(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2estmtKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s313852718x340738167_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s313852718x340738167_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s313852718x340738167(a[0], a[1]);
}
Clo g_list_2emap_24s228910449x1110031924_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s228910449x1110031924_entry, 2, 0};

V g_list_2emap_24s228910449x1110031924(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2eparamKey(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s228910449x1110031924_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s228910449x1110031924(a[0], a[1]);
}
Clo g_list_2efilter_24s639151216x1214259357_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s639151216x1214259357_24dps_entry, 4, 0};

V g_list_2efilter_24s639151216x1214259357_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_245;
        V t_3 = v_cell_248;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_rec(v_x_244, 3);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_245;
        V t_3 = v_d_243;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s639151216x1214259357_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2efilter_24s639151216x1214259357_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s435407392x1528135477_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s435407392x1528135477_24dps_entry, 2, 0};

V g_list_2emap_24s435407392x1528135477_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s435407392x1528135477_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1085725546x1737150855_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    if (heff_intLe_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(v_lit_240))) {
      if (heff_intLe_c(heff_dup(v_lit_240), heff_get_n(v_a_244, 1, 2))) {
        heff_drop(v_lit_240);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
      } else {
        heff_drop_rec(v_x_242, 3);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_rec(v_a_244, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1777318809x1106245647_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1777318809x1106245647_entry, 2, 0};

V g_list_2efoldl_24s1777318809x1106245647(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2413));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1777318809x1106245647(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1904498032x521599863_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1904498032x521599863_entry, 2, 0};

V g_list_2emerge_24s1904498032x521599863(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_y_244, 2)), 0, 2);
      if (heff_intLe_c(v_t_246, v_t_247)) {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1904498032x521599863_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      } else {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2412 = (g_list_2emerge_24s1904498032x521599863_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1904498032x521599863_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1904498032x521599863(a[0], a[1]);
}
Clo g_list_2efilter_24s1371839958x1221974112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1371839958x1221974112_24dps_entry, 3, 0};

V g_list_2efilter_24s1371839958x1221974112_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1371839958x1221974112_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1371839958x1221974112_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1435185561x202019164_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1435185561x202019164_entry, 1, 0};

V g_list_2emap_24s1435185561x202019164(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eglueProvider(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1435185561x202019164_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1435185561x202019164(a[0]);
}
Clo g_list_2efoldl_24s1325969685x576913065_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1325969685x576913065_entry, 2, 0};

V g_list_2efoldl_24s1325969685x576913065(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 1)), 2, 3);
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1325969685x576913065(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s513294106x1954328253_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s513294106x1954328253_entry, 4, 0};

V g_list_2efoldl_24s513294106x1954328253(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_list_2efoldl_24f1046331721x1909432377(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 6)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_246);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s513294106x1954328253_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s513294106x1954328253(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efind_24s1816408632x1283768171_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1816408632x1283768171_entry, 2, 0};

V g_list_2efind_24s1816408632x1283768171(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_lit_240, 0)) - heff_unbox_word(heff_strLength_lent(v_a_246, 0)));
    V v_t_248 = heff_strSlice(heff_dup(v_lit_240), heff_box_word(v_t_247), heff_strLength_lent(v_lit_240, 0));
    if (heff_strEq_c(v_t_248, v_a_246)) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1816408632x1283768171_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2efind_24s1816408632x1283768171(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1170504272x1852564147_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1170504272x1852564147_24dps_entry, 2, 0};

V g_list_2emap_24s1170504272x1852564147_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_246;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_249 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1170504272x1852564147_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1372232877x278600396_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1372232877x278600396_entry, 1, 0};

V g_list_2emap_24s1372232877x278600396(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2elsp_2esplit_2eexprName(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1372232877x278600396_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1372232877x278600396_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1372232877x278600396(a[0]);
}

HeffT2 g_list_2efind_24s1637307977x1351693783_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_242));
    V v_t_249 = heff_strFind(heff_strAppend(heff_dup(v_lit_241), v_t_248), heff_dup(v_lit_243), heff_dup(v_lit_244));
    if (heff_intLe_c_lent(v_lit_240, v_t_249, 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_xs_247);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_246}});
    } else {
      heff_drop_rec(v_x_246, 3);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_245)}});
  }
}
Clo g_list_2emap_24s831190316x576961335_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_entry, 1, 0};

V g_list_2emap_24s831190316x576961335(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s831190316x576961335_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s831190316x576961335(a[0]);
}
Clo g_list_2emap_24s1281445768x1036802655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_24dps_entry, 2, 0};

V g_list_2emap_24s1281445768x1036802655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eflagWord(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1753874608x910016727_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_24dps_entry, 2, 0};

V g_list_2emap_24s1753874608x910016727_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eflagLine(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f625837968x2121675523_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f625837968x2121675523_entry, 3, 0};

V g_list_2efoldl_24f625837968x2121675523(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if ((heff_dup(v_x_243) == NTAG(TAG_True))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f625837968x2121675523_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f625837968x2121675523(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f409057300x985797598_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f409057300x985797598_entry, 2, 0};

V g_list_2efoldl_24f409057300x985797598(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 2, 3);
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f409057300x985797598(a[0], a[1]);
}
Clo g_list_2efoldl_24f1443542135x1147816397_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1443542135x1147816397_entry, 4, 0};

V g_list_2efoldl_24f1443542135x1147816397(V v_z_240, V v_f_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_f_241);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_x_244), heff_dup(v_y_246)}));
      V v_t_249 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_248));
      V t_0 = v_t_249;
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_ys_247;
      v_z_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f1443542135x1147816397(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24f342794667x1308411312_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f342794667x1308411312_24dps_entry, 3, 0};

V g_list_2emap_24f342794667x1308411312_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 3);
    V v_a_246 = heff_dup(heff_rfield(v_lit_240, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_245, 0)), heff_dup(heff_rfield(v_a_246, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_245, 1, 2), heff_get_n(v_a_246, 1, 2))) {
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 1, 2), heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_cell_249;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_rec(v_x_243, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop_rec(v_a_245, 2);
      heff_drop_rec(v_a_246, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f342794667x1308411312_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f342794667x1308411312_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f336527456x1519848451_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f336527456x1519848451_entry, 13, 0};

V g_list_2emap_24f336527456x1519848451(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_x2_2412) {
top: ;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24Cons = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_x_2413, 0)) - heff_unbox_word(heff_strLength_lent(v_lit_247, 0)));
    V v_t_2416 = heff_strSlice(heff_dup(v_x_2413), heff_box_word(v_t_2415), heff_strLength_lent(v_x_2413, 0));
    if (heff_strEq_c_lent(v_t_2416, v_lit_248, 1)) {
      if (heff_strEq_c(heff_strSlice_lent(v_x_2413, v_lit_249, v_lit_2410, 0), heff_dup(v_lit_2411))) {
        heff_drop(v_x_2413);
        heff_drop_cell(v_ru_24x2_2412_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        V t_10 = v_lit_2410;
        V t_11 = v_lit_2411;
        V t_12 = v_xs_2414;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_lit_2411 = t_11;
        v_x2_2412 = t_12;
        goto top;
      } else {
        int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_x_2413, 0)) - heff_peek_word(v_lit_242));
        int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_x_2413, 0)) - heff_peek_word(v_lit_245));
        V v_t_2421 = heff_strAppend(heff_strSlice_lent(v_x_2413, v_lit_244, heff_box_word(v_t_2420), 4), heff_dup(v_lit_246));
        V v_t_2422 = heff_strAppend(heff_strSlice_lent(v_x_2413, v_lit_241, heff_box_word(v_t_2419), 5), heff_strAppend(heff_dup(v_lit_243), v_t_2421));
        V v_cell_2423 = heff_tag_at_n(v_ru_24x2_2412_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2422), heff_hole()});
        V v_u_2424 = (g_list_2emap_24f336527456x1519848451_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_lit_2410, v_lit_2411, v_xs_2414, heff_dup(v_cell_2423)));
        heff_drop(v_u_2424);
        return v_cell_2423;
      }
    } else {
      heff_drop(v_x_2413);
      heff_drop_cell(v_ru_24x2_2412_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_xs_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_x2_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_list_2emap_24f336527456x1519848451_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V a11 = a[11]; V r = g_list_2emap_24f336527456x1519848451(a[0], a1, a[2], a[3], a4, a[5], a[6], a7, a8, a9, a10, a11, a[12]); heff_drop(a1); heff_drop(a4); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); heff_drop(a11); return r;
}
Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f130772758x674845987_24f797488600x357897558_entry, 4, 0};

V g_list_2emap_24f130772758x674845987_24f797488600x357897558(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_take_field(v_x_244, 2);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x_247 = heff_get_n(v_x_244, 0, 4);
      V v_t_248 = heff_strSlice(heff_dup(v_x_247), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
      if (heff_strEq_c_lent(v_t_248, v_lit_242, 1)) {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_247, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2411 = (g_list_2emap_24f130772758x674845987_24f797488600x357897558_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_x_247);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_244, 4);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f130772758x674845987_24f797488600x357897558(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f129939610x1317417911_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f129939610x1317417911_entry, 6, 0};

V g_list_2efoldl_24f129939610x1317417911(V v_lit_240, V v_z_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop_rec(v_lit_243, 6);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lit_243, 2)), 0, 2);
    V v_t_249 = heff_strFind(heff_strOfRunes(v_t_248), heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_244));
    if (heff_intLe_c_lent(v_lit_242, v_t_249, 2)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efoldl_24f129939610x1317417911_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_list_2efoldl_24f129939610x1317417911(a[0], a[1], a[2], a[3], a4, a5); heff_drop(a4); heff_drop(a5); return r;
}