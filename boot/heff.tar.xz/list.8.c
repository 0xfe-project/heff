// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Doc 16324
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_Flat 38290
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IVal 40987
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkFieldPat 14710
#define TAG_MkSegment 38079
#define TAG_Nest 8345
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unreached 46435
#define TAG_Whole 6035
#define TAG_Within 10658
#define LBL_above 293969847
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_e 319
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_fixities 357800079
#define LBL_flags 298871457
#define LBL_fld 311000
#define LBL_goes 9673821
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_leaves 840404935
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_olds 9909235
#define LBL_params 951713969
#define LBL_path 9928940
#define LBL_post 9942375
#define LBL_rest 9992347
#define LBL_severity 75955546
#define LBL_ships 310766033
#define LBL_size 10026184
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_var 326049
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_key__arity__at__rest[] = {LBL_key, LBL_arity, LBL_at, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_value__ty__size__flags__span[] = {LBL_value, LBL_ty, LBL_size, LBL_flags, LBL_span};
static uint32_t shape_var__fld__leaves[] = {LBL_var, LBL_fld, LBL_leaves};
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2eowned_2elentOperand(V, V);
V g_heff_2ecompile_2eowned_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elentOperand_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2elsp_2esplit_2eexprName(V);
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_clo;
V g_heff_2elsp_2esplit_2eexprName_24tok1(V, V);
V g_heff_2elsp_2esplit_2eexprName_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_24tok1_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_list_2eall_24s1543979616x278497281(V, V, V, V, V);
V g_list_2eall_24s1543979616x278497281_entry(V self, V *a);
extern Clo g_list_2eall_24s1543979616x278497281_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2eany_24s1547578820x1498276962(V, V);
V g_list_2eany_24s1547578820x1498276962_entry(V self, V *a);
extern Clo g_list_2eany_24s1547578820x1498276962_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
HeffT2 g_list_2efind_24s1136367117x833793205_24cpr(V, V);
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
HeffT2 g_list_2efind_24s446714453x706785629_24cpr(V, V, V);
V g_list_2efoldl_24f2029054136x351940068(V, V, V, V);
V g_list_2efoldl_24f2029054136x351940068_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2029054136x351940068_clo;
V g_list_2efoldl_24s1068175575x1869083571(V, V);
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1068175575x1869083571_clo;
V g_list_2efoldl_24s1103469845x1474178821(V, V, V);
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1103469845x1474178821_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1468236620x1316701813(V, V);
V g_list_2efoldl_24s1468236620x1316701813_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1468236620x1316701813_clo;
V g_list_2efoldl_24s1497160917x619600869(V, V);
V g_list_2efoldl_24s1497160917x619600869_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1497160917x619600869_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1880194630x798487332(V, V);
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1880194630x798487332_clo;
V g_list_2efoldl_24s1982386833x551161312(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1982386833x551161312_clo;
V g_list_2efoldl_24s2124979901x587925464(V, V);
V g_list_2efoldl_24s2124979901x587925464_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2124979901x587925464_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s53729099x990735293(V, V);
V g_list_2efoldl_24s53729099x990735293_entry(V self, V *a);
extern Clo g_list_2efoldl_24s53729099x990735293_clo;
V g_list_2efoldl_24s634644062x504497039(V, V);
V g_list_2efoldl_24s634644062x504497039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634644062x504497039_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s797527640x986490519(V, V);
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a);
extern Clo g_list_2efoldl_24s797527640x986490519_clo;
V g_list_2ekeepIf_24s1223034477x943356724_24dps(V, V);
V g_list_2ekeepIf_24s1223034477x943356724_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_24dps_clo;
V g_list_2ekeepIf_24s425280038x249084439_24dps(V, V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_24dps_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2ekeepIf_24s689992630x418898235_24dps(V, V, V);
V g_list_2ekeepIf_24s689992630x418898235_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_24dps_clo;
V g_list_2emap_24f1221888634x716224461(V, V);
V g_list_2emap_24f1221888634x716224461_entry(V self, V *a);
extern Clo g_list_2emap_24f1221888634x716224461_clo;
V g_list_2emap_24f1221888634x716224461_24dps(V, V, V);
V g_list_2emap_24f1221888634x716224461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1221888634x716224461_24dps_clo;
V g_list_2emap_24f1730403549x1479772376_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_24dps_clo;
V g_list_2emap_24f1744384903x906515519_24dps(V, V);
V g_list_2emap_24f1744384903x906515519_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_24dps_clo;
V g_list_2emap_24f2041933216x1458595349(V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_clo;
V g_list_2emap_24f2041933216x1458595349_24dps(V, V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_24dps_clo;
V g_list_2emap_24s1152414072x2935301_24dps(V, V, V);
V g_list_2emap_24s1152414072x2935301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_24dps_clo;
V g_list_2emap_24s1170504272x1852564147_24dps(V, V);
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_24dps_clo;
V g_list_2emap_24s135291903x1031656159_24dps(V, V, V);
V g_list_2emap_24s135291903x1031656159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_24dps_clo;
V g_list_2emap_24s1372232877x278600396(V);
V g_list_2emap_24s1372232877x278600396_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_clo;
V g_list_2emap_24s1372232877x278600396_24dps(V, V);
V g_list_2emap_24s1372232877x278600396_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_24dps_clo;
V g_list_2emap_24s1429062098x1340918317(V);
V g_list_2emap_24s1429062098x1340918317_entry(V self, V *a);
extern Clo g_list_2emap_24s1429062098x1340918317_clo;
V g_list_2emap_24s1429062098x1340918317_24dps(V, V);
V g_list_2emap_24s1429062098x1340918317_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1429062098x1340918317_24dps_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1535007417x1587061701_24dps(V, V);
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_24dps_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s1698496827x1884878103_24dps(V, V);
V g_list_2emap_24s1698496827x1884878103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_24dps_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s2130193383x1335133353_24dps(V, V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_24dps_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s23414532x1067218554(V, V, V, V, V, V);
V g_list_2emap_24s23414532x1067218554_entry(V self, V *a);
extern Clo g_list_2emap_24s23414532x1067218554_clo;
V g_list_2emap_24s23414532x1067218554_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s23414532x1067218554_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s23414532x1067218554_24dps_clo;
V g_list_2emap_24s32026788x2029987799_24dps(V, V);
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_24dps_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s435407392x1528135477_24dps(V, V);
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_24dps_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s537124232x94423304_24dps(V, V);
V g_list_2emap_24s537124232x94423304_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s537124232x94423304_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s649333309x1802289391_24dps(V, V);
V g_list_2emap_24s649333309x1802289391_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_24dps_clo;
V g_list_2emap_24s886389550x1086668531(V);
V g_list_2emap_24s886389550x1086668531_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_clo;
V g_list_2emap_24s886389550x1086668531_24dps(V, V);
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_24dps_clo;
V g_list_2ezipWith_24s1026658656x682908126_24dps(V, V, V);
V g_list_2ezipWith_24s1026658656x682908126_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_24dps_clo;
V g_list_2ezipWith_24s1261798533x517442282(V, V);
V g_list_2ezipWith_24s1261798533x517442282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1261798533x517442282_clo;
V g_list_2ezipWith_24s1261798533x517442282_24dps(V, V, V);
V g_list_2ezipWith_24s1261798533x517442282_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1261798533x517442282_24dps_clo;
V g_list_2ezipWith_24s528321443x971020870_24dps(V, V, V);
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_list_2eany_24s1547578820x1498276962_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1547578820x1498276962_entry, 2, 0};

V g_list_2eany_24s1547578820x1498276962(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1547578820x1498276962_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1547578820x1498276962(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1026658656x682908126_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1026658656x682908126_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1026658656x682908126_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eranges_2ejoin(v_x_243, v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1026658656x682908126_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1026658656x682908126_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s425280038x249084439_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s425280038x249084439_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s425280038x249084439_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_Unreached: {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    case TAG_Within: {
      V v_a_249 = heff_field(v_t_248, 0);
      V v_a_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 3ULL, 2);
      switch (heff_tag_of(v_a_249)) {
      case TAG_Nothing: {
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_a_2410);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_245;
        V t_3 = v_d_243;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_a_249, 0);
        heff_take_n(v_a_249, 1ULL, 1);
        switch (heff_tag_of(v_a_2410)) {
        case TAG_Nothing: {
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_242_24Cons, 2);
          heff_drop(v_a_2411);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_245;
          V t_3 = v_d_243;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
        case TAG_Just: {
          V v_a_2412 = heff_field(v_a_2410, 0);
          heff_take_n(v_a_2410, 1ULL, 1);
          if ((heff_intLe_c_lent(v_lit_240, v_a_2411, 0) && heff_intLe_c_lent(v_a_2412, v_lit_241, 0))) {
            heff_drop(v_a_2411);
            heff_drop(v_a_2412);
            V v_cell_2413 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
            V v_u_2414 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2413));
            heff_drop(v_u_2414);
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_xs_245;
            V t_3 = v_cell_2413;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_x2_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_242_24Cons, 2);
            heff_drop(v_a_2411);
            heff_drop(v_a_2412);
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_xs_245;
            V t_3 = v_d_243;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_x2_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_2410);
        }
      }
      default: return heff_nomatch(v_a_249);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s425280038x249084439_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s425280038x249084439_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s1068175575x1869083571_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1068175575x1869083571_entry, 2, 0};

V g_list_2efoldl_24s1068175575x1869083571(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_d_245 = heff_dup(v_x_242);
    V v_body_246 = heff_take_field(v_d_245, 2);
    V v_key_247 = heff_get_n(v_d_245, 0, 3);
    V v_t_2447;
    switch (heff_tag_of(v_body_246)) {
    case TAG_EVar: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_246, 0ULL, 4);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EInt: {
      V v_n_2433 = heff_field(v_body_246, 0);
      heff_take_n(v_body_246, 1ULL, 1);
      v_t_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_key_247, v_n_2433));
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2447 = v_m_244;
      break;
    }
    default: heff_nomatch(v_body_246);
    }
    V t_0 = v_t_2447;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1068175575x1869083571(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s32026788x2029987799_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s32026788x2029987799_24dps_entry, 2, 0};

V g_list_2emap_24s32026788x2029987799_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_start_244 = heff_take_field(v_x_242, 0);
    V v_end_245 = heff_take_field(v_x_242, 1);
    V v_text_246 = heff_get_n(v_x_242, 2, 3);
    V v_t_247 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){v_start_244, v_end_245, NTAG(TAG_Nothing), v_text_246, MK_INT(0LL), MK_INT(0LL)});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s32026788x2029987799_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s386875578x1005587669_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_entry, 1, 0};

V g_list_2emap_24s386875578x1005587669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2451;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_x2_245 = v_a_243;
      V v_t_2450;
      switch (heff_tag_of(v_x2_245)) {
      case TAG_DeclEquations: {
        V v_f_246 = heff_field(v_x2_245, 0);
        V v_sp_247 = heff_field(v_x2_245, 1);
        V v_declared_248 = heff_field(v_x2_245, 2);
        V v_ty_249 = heff_field(v_x2_245, 3);
        V v_eqs_2410 = heff_field(v_x2_245, 4);
        V v_ru_24x2_245_24DeclEquations = heff_take_reuse_n(v_x2_245, 31ULL, 5);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_2413;
        switch (heff_tag_of(v_ty_249)) {
        case TAG_At: {
          V v_n_2411 = heff_field(v_ty_249, 0);
          V v_sp_2412 = heff_field(v_ty_249, 1);
          V v_ru_24ty_249_24At = heff_take_reuse_n(v_ty_249, 3ULL, 2);
          v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24ty_249_24At, v_sp_2412, v_n_2411));
          break;
        }
        default: heff_nomatch(v_ty_249);
        }
        V v_t_2414 = (g_list_2emap_24s1782778565x402128078(v_eqs_2410));
        v_t_2450 = heff_tag_at_n(v_ru_24x2_245_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_246, v_sp_247, v_declared_248, v_t_2413, v_t_2414});
        break;
      }
      case TAG_DeclDefine: {
        V v_x_2415 = heff_field(v_x2_245, 0);
        V v_sp_2416 = heff_field(v_x2_245, 1);
        V v_ps_2417 = heff_field(v_x2_245, 2);
        V v_u_2418 = heff_field(v_x2_245, 3);
        V v_body_2419 = heff_field(v_x2_245, 4);
        V v_ru_24x2_245_24DeclDefine = heff_take_reuse_n(v_x2_245, 31ULL, 5);
        V v_t_2420 = (g_list_2emap_24s474585387x1072098790(v_ps_2417));
        V v_t_2423;
        switch (heff_tag_of(v_u_2418)) {
        case TAG_At: {
          V v_n_2421 = heff_field(v_u_2418, 0);
          V v_sp_2422 = heff_field(v_u_2418, 1);
          V v_ru_24u_2418_24At = heff_take_reuse_n(v_u_2418, 3ULL, 2);
          v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24u_2418_24At, v_sp_2422, v_n_2421));
          break;
        }
        default: heff_nomatch(v_u_2418);
        }
        V v_t_2427;
        switch (heff_tag_of(v_body_2419)) {
        case TAG_At: {
          V v_n_2424 = heff_field(v_body_2419, 0);
          V v_sp_2425 = heff_field(v_body_2419, 1);
          heff_take_n(v_body_2419, 3ULL, 2);
          V v_t_2426 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2424));
          v_t_2427 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2426, v_sp_2425});
          break;
        }
        default: heff_nomatch(v_body_2419);
        }
        v_t_2450 = heff_tag_at_n(v_ru_24x2_245_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2415, v_sp_2416, v_t_2420, v_t_2423, v_t_2427});
        break;
      }
      case TAG_DeclTheory: {
        V v_x_2428 = heff_field(v_x2_245, 0);
        V v_sp_2429 = heff_field(v_x2_245, 1);
        V v_ps_2430 = heff_field(v_x2_245, 2);
        V v_body_2431 = heff_field(v_x2_245, 3);
        V v_ru_24x2_245_24DeclTheory = heff_take_reuse_n(v_x2_245, 15ULL, 4);
        V v_t_2432 = (g_list_2emap_24s474585387x1072098790(v_ps_2430));
        V v_t_2436;
        switch (heff_tag_of(v_body_2431)) {
        case TAG_At: {
          V v_n_2433 = heff_field(v_body_2431, 0);
          V v_sp_2434 = heff_field(v_body_2431, 1);
          heff_take_n(v_body_2431, 3ULL, 2);
          V v_t_2435 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2433));
          v_t_2436 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2435, v_sp_2434});
          break;
        }
        default: heff_nomatch(v_body_2431);
        }
        v_t_2450 = heff_tag_at_n(v_ru_24x2_245_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2428, v_sp_2429, v_t_2432, v_t_2436});
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2437 = heff_field(v_x2_245, 0);
        V v_sp_2438 = heff_field(v_x2_245, 1);
        V v_t_2439 = heff_field(v_x2_245, 2);
        V v_ru_24x2_245_24DeclPrimitive = heff_take_reuse_n(v_x2_245, 7ULL, 3);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_n_2440 = heff_field(v_t_2439, 0);
          V v_sp_2441 = heff_field(v_t_2439, 1);
          V v_ru_24t_2439_24At = heff_take_reuse_n(v_t_2439, 3ULL, 2);
          v_t_2442 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2439_24At, v_sp_2441, v_n_2440));
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2450 = heff_tag_at_n(v_ru_24x2_245_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2437, v_sp_2438, v_t_2442});
        break;
      }
      case TAG_DeclTest: {
        V v_x_2443 = heff_field(v_x2_245, 0);
        V v_sp_2444 = heff_field(v_x2_245, 1);
        V v_ru_24x2_245_24DeclTest = heff_take_reuse_n(v_x2_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2450 = heff_tag_at_n(v_ru_24x2_245_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2443, v_sp_2444});
        break;
      }
      case TAG_DeclWatch: {
        V v_c_2445 = heff_field(v_x2_245, 0);
        V v_ru_24x2_245_24DeclWatch = heff_take_reuse_n(v_x2_245, 1ULL, 1);
        V v_t_2449;
        switch (heff_tag_of(v_c_2445)) {
        case TAG_At: {
          V v_n_2446 = heff_field(v_c_2445, 0);
          V v_sp_2447 = heff_field(v_c_2445, 1);
          heff_take_n(v_c_2445, 3ULL, 2);
          V v_t_2448 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2446));
          v_t_2449 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2448, v_sp_2447});
          break;
        }
        default: heff_nomatch(v_c_2445);
        }
        v_t_2450 = heff_tag_at_n(v_ru_24x2_245_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2449});
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){v_t_2450, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2452 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2451, heff_hole()});
    V v_u_2453 = (g_list_2emap_24s386875578x1005587669_24dps(v_xs_242, heff_dup(v_cell_2452)));
    heff_drop(v_u_2453);
    return v_cell_2452;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669(a[0]);
}
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_str0, 1, "`");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_str1, 30, "` has a type but no definition");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_str2, 1, "`");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_str3, 17, "` needs a type: `");
HEFF_LIT(g_list_2emap_24s2130193383x1335133353_str4, 7, " : ...`");
Clo g_list_2emap_24s2130193383x1335133353_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2130193383x1335133353_entry, 4, 0};

V g_list_2emap_24s2130193383x1335133353(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_broken_246 = heff_dup(v_lit_240);
    V v_sigs_247 = heff_dup(v_lit_241);
    V v_eqns_248 = heff_dup(v_lit_242);
    V v_x4_249 = v_x_244;
    V v_t_2441;
    switch (heff_tag_of(v_x4_249)) {
    case TAG_Sig: {
      V v_f_2411 = heff_field(v_x4_249, 1);
      V v_fsp_2412 = heff_field(v_x4_249, 2);
      heff_take_n(v_x4_249, 6ULL, 5);
      heff_drop(v_sigs_247);
      HeffT2 v_t_2415 = ({ V a_0 = v_eqns_248; V a_1 = v_f_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_eqns_248); r_; });
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          heff_drop(v_broken_246);
          heff_drop(v_f_2411);
          heff_drop(v_fsp_2412);
          V v_x_2418 = v_field_2417;
          heff_drop(v_x_2418);
          v_t_2441 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2417);
          HeffT2 v_t_2419 = ({ V a_0 = v_broken_246; V a_1 = v_f_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_broken_246); r_; });
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              heff_drop(v_f_2411);
              heff_drop(v_fsp_2412);
              V v_x_2422 = v_field_2421;
              heff_drop(v_x_2422);
              v_t_2441 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_field_2421);
              V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2130193383x1335133353_str0), v_f_2411), ((V)&g_list_2emap_24s2130193383x1335133353_str1));
              V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2423, v_fsp_2412, NTAG(TAG_Nothing)});
              v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
            }
          }
        }
      }
      break;
    }
    case TAG_Eqn: {
      V v_f_2425 = heff_field(v_x4_249, 0);
      V v_sp_2427 = heff_field(v_x4_249, 2);
      heff_take_n(v_x4_249, 5ULL, 3);
      heff_drop(v_eqns_248);
      HeffT2 v_t_2428 = ({ V a_0 = v_sigs_247; V a_1 = v_f_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_sigs_247); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          heff_drop(v_broken_246);
          heff_drop(v_f_2425);
          heff_drop(v_sp_2427);
          V v_x_2431 = v_field_2430;
          heff_drop(v_x_2431);
          v_t_2441 = NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_2430);
          HeffT2 v_t_2432 = ({ V a_0 = v_broken_246; V a_1 = v_f_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_broken_246); r_; });
          {
            V v_field_2434 = v_t_2432.f[1];
            int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
            if ((v_tag_2433 == ((int64_t)0ULL))) {
              heff_drop(v_f_2425);
              heff_drop(v_sp_2427);
              V v_x_2435 = v_field_2434;
              heff_drop(v_x_2435);
              v_t_2441 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_field_2434);
              V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2130193383x1335133353_str2), heff_dup(v_f_2425)), ((V)&g_list_2emap_24s2130193383x1335133353_str3));
              V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, v_f_2425), ((V)&g_list_2emap_24s2130193383x1335133353_str4));
              V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2437, v_sp_2427, NTAG(TAG_Nothing)});
              v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2438});
            }
          }
        }
      }
      break;
    }
    case TAG_Whole: {
      heff_take_n(v_x4_249, 0ULL, 1);
      heff_drop(v_broken_246);
      heff_drop(v_sigs_247);
      heff_drop(v_eqns_248);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Doc: {
      heff_take_n(v_x4_249, 0ULL, 1);
      heff_drop(v_broken_246);
      heff_drop(v_sigs_247);
      heff_drop(v_eqns_248);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x4_249);
    }
    V v_cell_2442 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2441, heff_hole()});
    V v_u_2443 = (g_list_2emap_24s2130193383x1335133353_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2442)));
    heff_drop(v_u_2443);
    return v_cell_2442;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2130193383x1335133353(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ezipWith_24s528321443x971020870_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s528321443x971020870_24dps_entry, 3, 0};

V g_list_2ezipWith_24s528321443x971020870_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_a_247 = v_x_243;
      V v_e_248 = v_y_245;
      V v_t_2492;
      switch (heff_tag_of(v_e_248)) {
      case TAG_EVar: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_e_248, 0ULL, 2);
        HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_a_247));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          heff_drop(v_x_2416);
          V v_y_2417 = v_field_2415;
          switch (heff_tag_of(v_y_2417)) {
          case TAG_EVar: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_False);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_y_2417, 0ULL, 3);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_y_2417, 0ULL, 4);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_y_2417, 0ULL, 3);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EAbandon: {
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_y_2417, 0ULL, 3);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_y_2417, 0ULL, 1);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_y_2417, 0ULL, 2);
            v_t_2492 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_y_2417);
          }
        }
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_e_248, 0ULL, 3);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_e_248, 0ULL, 4);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_e_248, 0ULL, 3);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_e_248, 0ULL, 3);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_e_248, 0ULL, 1);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_e_248, 0ULL, 2);
        heff_drop(v_a_247);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_248);
      }
      V v_cell_2493 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2492, heff_hole()});
      V v_u_2494 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2493));
      heff_drop(v_u_2494);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2493;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s528321443x971020870_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s528321443x971020870_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1982386833x551161312_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1982386833x551161312_entry, 14, 0};

V g_list_2efoldl_24s1982386833x551161312(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_z_2412, V v_x3_2413) {
top: ;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return v_z_2412;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x3_2413, 0);
    V v_xs_2415 = heff_field(v_x3_2413, 1);
    V v_t_2418;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_2414, 1);
      v_t_2418 = heff_dup(v_a_2417);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2420;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_RepV: {
      v_t_2420 = heff_dup(v_lit_240);
      break;
    }
    case TAG_RepFix: {
      V v_a_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      switch (heff_tag_of(v_a_2419)) {
      case TAG_I8: {
        v_t_2420 = heff_dup(v_lit_241);
        break;
      }
      case TAG_I16: {
        v_t_2420 = heff_dup(v_lit_242);
        break;
      }
      case TAG_I32: {
        v_t_2420 = heff_dup(v_lit_243);
        break;
      }
      case TAG_I64: {
        v_t_2420 = heff_dup(v_lit_244);
        break;
      }
      case TAG_U8: {
        v_t_2420 = heff_dup(v_lit_245);
        break;
      }
      case TAG_U16: {
        v_t_2420 = heff_dup(v_lit_246);
        break;
      }
      case TAG_U32: {
        v_t_2420 = heff_dup(v_lit_247);
        break;
      }
      case TAG_U64: {
        v_t_2420 = heff_dup(v_lit_248);
        break;
      }
      case TAG_F32: {
        v_t_2420 = heff_dup(v_lit_249);
        break;
      }
      default: heff_nomatch(v_a_2419);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_2420 = heff_dup(v_lit_2410);
      break;
    }
    case TAG_RepInt: {
      v_t_2420 = heff_dup(v_lit_2411);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2423;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2421 = heff_field(v_x_2414, 0);
      v_t_2423 = heff_dup(v_a_2421);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2424 = (g_heff_2ecompile_2erepr_2efourTo(v_t_2423));
    V v_t_2425 = heff_intAdd(v_z_2412, heff_intMul(v_t_2420, v_t_2424));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_lit_2410;
    V t_11 = v_lit_2411;
    V t_12 = v_t_2425;
    V t_13 = v_xs_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_lit_2410 = t_10;
    v_lit_2411 = t_11;
    v_z_2412 = t_12;
    v_x3_2413 = t_13;
    goto top;
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a) {
  (void)self;
  V a13 = a[13]; V r = g_list_2efoldl_24s1982386833x551161312(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a13); heff_drop(a13); return r;
}
Clo g_list_2efoldl_24s1690891682x1517899652_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1690891682x1517899652_entry, 2, 0};

V g_list_2efoldl_24s1690891682x1517899652(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_t_246, v_t_249}), v_z_240});
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1690891682x1517899652(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1223034477x943356724_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1223034477x943356724_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1223034477x943356724_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_246, 0ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_243;
      V t_1 = v_cell_249;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1223034477x943356724_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1223034477x943356724_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s63755471x810534073_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s63755471x810534073_entry, 2, 0};

V g_list_2eany_24s63755471x810534073(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eowned_2elentOperand(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s63755471x810534073_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s63755471x810534073(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2124979901x587925464_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2124979901x587925464_entry, 2, 0};

V g_list_2efoldl_24s2124979901x587925464(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Flat: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Nest: {
      V v_a_248 = heff_field(v_x_242, 3);
      heff_take_n(v_x_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_248));
      v_t_2410 = (g_list_2efoldl_24s1497160917x619600869(NTAG(TAG_Nil), v_t_249));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2124979901x587925464_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2124979901x587925464(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1261798533x517442282_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1261798533x517442282_entry, 2, 0};

V g_list_2ezipWith_24s1261798533x517442282(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_y_244)) {
      case TAG_MkPair: {
        V v_f_246 = heff_field(v_y_244, 0);
        V v_xs_247 = heff_field(v_y_244, 1);
        heff_take_n(v_y_244, 3ULL, 2);
        v_t_248 = heff_rec_n(3, shape_var__fld__leaves, (V[]){v_x_242, v_f_246, v_xs_247});
        break;
      }
      default: heff_nomatch(v_y_244);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s1261798533x517442282_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1261798533x517442282_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1261798533x517442282(a[0], a[1]);
}
Clo g_list_2eany_24s141450647x925029990_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s141450647x925029990_entry, 1, 0};

V g_list_2eany_24s141450647x925029990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s141450647x925029990_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s141450647x925029990(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s797527640x986490519_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s797527640x986490519_entry, 2, 0};

V g_list_2efoldl_24s797527640x986490519(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_a_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1880194630x798487332(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s797527640x986490519(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2eall_24s1543979616x278497281_str0, 0, "");
Clo g_list_2eall_24s1543979616x278497281_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1543979616x278497281_entry, 5, 0};

V g_list_2eall_24s1543979616x278497281(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_sg_247 = heff_dup(v_lit_240);
    V v_c_248 = heff_dup(v_lit_241);
    V v_cs_249 = heff_dup(v_lit_242);
    V v_goes_2410 = heff_take_field(v_cs_249, 3);
    V v_params_2411 = heff_take_field(v_cs_249, 0);
    V v_at_2412 = heff_get_n(v_cs_249, 1, 5);
    V v_m_2413 = heff_dup(v_lit_243);
    V v_x5_2414 = heff_dup(v_x_245);
    V v_t_2427;
    switch (heff_tag_of(v_x5_2414)) {
    case TAG_MkArm: {
      V v_t_2415 = heff_field(v_x5_2414, 0);
      V v_vs_2416 = heff_field(v_x5_2414, 1);
      V v_b_2417 = heff_field(v_x5_2414, 2);
      heff_take_n(v_x5_2414, 7ULL, 3);
      V v_x1_2418 = ({ V a_0 = v_t_2415; V a_1 = v_goes_2410; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2415); heff_drop(v_goes_2410); r_; });
      if (!(heff_dup(v_x1_2418) == NTAG(TAG_True))) {
        heff_drop(v_sg_247);
        heff_drop(v_c_248);
        heff_drop(v_params_2411);
        heff_drop(v_at_2412);
        heff_drop(v_m_2413);
        heff_drop(v_vs_2416);
        heff_drop(v_b_2417);
        heff_drop(v_x1_2418);
        v_t_2427 = NTAG(TAG_True);
      } else {
        heff_drop(v_x1_2418);
        V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2416));
        V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_2411); r_; });
        V v_t_2423;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_Nil: {
          v_t_2423 = ((V)&g_list_2eall_24s1543979616x278497281_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 2);
          v_t_2423 = v_x_2421;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        V v_e_2424 = (g_heff_2ecompile_2efuse_2eselfOut(heff_rec_n(4, shape_key__arity__at__rest, (V[]){v_c_248, v_t_2420, v_at_2412, v_t_2423}), v_b_2417));
        V v_t_2425 = (g_std_2eordmap_2esize(v_m_2413));
        V v_t_2426;
        if (heff_intEq_c(v_t_2425, MK_INT(0LL))) {
          heff_drop(v_m_2413);
          v_t_2426 = v_e_2424;
        } else {
          v_t_2426 = ({ V a_0 = v_m_2413; V a_1 = v_e_2424; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2413); r_; });
        }
        v_t_2427 = (g_heff_2ecompile_2efuse_2eworkPure(v_sg_247, v_t_2426));
      }
      break;
    }
    default: heff_nomatch(v_x5_2414);
    }
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_t_2427);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2eall_24s1543979616x278497281_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2eall_24s1543979616x278497281(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2emap_24s1429062098x1340918317_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1429062098x1340918317_entry, 1, 0};

V g_list_2emap_24s1429062098x1340918317(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_249 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_249}), heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1429062098x1340918317_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1429062098x1340918317_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1429062098x1340918317(a[0]);
}
Clo g_list_2emap_24s537124232x94423304_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s537124232x94423304_24dps_entry, 2, 0};

V g_list_2emap_24s537124232x94423304_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      V v_a_247 = heff_field(v_x_242, 3);
      V v_a_248 = heff_field(v_x_242, 4);
      V v_a_249 = heff_field(v_x_242, 5);
      V v_a_2410 = heff_field(v_x_242, 6);
      V v_a_2411 = heff_field(v_x_242, 7);
      V v_ru_24x_242_24MkCArm = heff_take_reuse_n(v_x_242, 255ULL, 8);
      V v_t_2412 = (g_list_2emap_24s1478286876x830244177(v_a_2410));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24MkCArm, TAG_MkCArm, 8, (V[]){v_a_244, v_a_245, v_a_246, v_a_247, v_a_248, v_a_249, v_t_2412, v_a_2411});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s537124232x94423304_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s537124232x94423304_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s53729099x990735293_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s53729099x990735293_entry, 2, 0};

V g_list_2efoldl_24s53729099x990735293(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_slots_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_def_245 = heff_dup(heff_rfield(v_x_242, 0));
    V v_t_248;
    switch (heff_tag_of(v_slots_244)) {
    case TAG_Nil: {
      heff_drop_rec(v_def_245, 3);
      v_t_248 = v_z_240;
      break;
    }
    case TAG_Cons: {
      v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_get_n(v_def_245, 0, 3), v_slots_244));
      break;
    }
    default: heff_nomatch(v_slots_244);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s53729099x990735293_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s53729099x990735293(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s649333309x1802289391_str0, 22, "export const $host = \"");
HEFF_LIT(g_list_2emap_24s649333309x1802289391_str1, 1, "\"");
Clo g_list_2emap_24s649333309x1802289391_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_entry, 1, 0};

V g_list_2emap_24s649333309x1802289391(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_243 = v_x_241;
    V v_t_248;
    if (heff_strEq_c(heff_strSlice_lent(v_l_243, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_list_2emap_24s649333309x1802289391_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_l_243), MK_INT(22LL), heff_strLength_lent(v_l_243, 0));
      V v_j_245 = heff_strFind(((V)&g_list_2emap_24s649333309x1802289391_str1), v_t_244, MK_INT(0LL));
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        V v_t_246 = heff_strSlice(heff_dup(v_l_243), MK_INT(22LL), heff_strLength(v_l_243));
        v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
      } else {
        V v_t_247 = heff_strSlice(v_l_243, MK_INT(22LL), heff_intAdd(MK_INT(22LL), v_j_245));
        v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
      }
    } else {
      heff_drop(v_l_243);
      v_t_248 = NTAG(TAG_Nothing);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s649333309x1802289391_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391(a[0]);
}
Clo g_list_2efoldl_24s2138447488x1597606028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2138447488x1597606028_entry, 2, 0};

V g_list_2efoldl_24s2138447488x1597606028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2138447488x1597606028(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24s1103469845x1474178821_str0, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s1103469845x1474178821_str1, 2, "$s");
Clo g_list_2efoldl_24s1103469845x1474178821_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1103469845x1474178821_entry, 3, 0};

V g_list_2efoldl_24s1103469845x1474178821(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_fs_245 = heff_dup(v_lit_240);
    V v_mods_246 = heff_take_field(v_fs_245, 0);
    V v_olds_247 = heff_get_n(v_fs_245, 1, 2);
    V v_m_248 = v_z_241;
    V v_c_249 = heff_dup(v_x_243);
    V v_g_2410 = heff_dup(heff_rfield(v_c_249, 0));
    V v_j_2411 = heff_strFind_lent(((V)&g_list_2efoldl_24s1103469845x1474178821_str0), v_g_2410, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
      heff_drop(v_j_2411);
      v_t_2412 = v_g_2410;
    } else {
      v_t_2412 = heff_strSlice(v_g_2410, MK_INT(0LL), v_j_2411);
    }
    V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_246, v_t_2412));
    V v_k_2414 = heff_dup(heff_rfield(v_c_249, 0));
    V v_t_2415 = (g_heff_2ebuild_2ebackcache_2ecopyText(heff_dup(v_c_249)));
    V v_g_2416 = heff_get_n(v_c_249, 0, 7);
    V v_j_2417 = heff_strFind_lent(((V)&g_list_2efoldl_24s1103469845x1474178821_str1), v_g_2416, MK_INT(0LL), 5);
    V v_t_2418;
    if (heff_intLt_c_lent(v_j_2417, MK_INT(0LL), 2)) {
      heff_drop(v_j_2417);
      v_t_2418 = v_g_2416;
    } else {
      v_t_2418 = heff_strSlice(v_g_2416, MK_INT(0LL), v_j_2417);
    }
    V v_t_2419 = ({ V a_0 = v_mods_246; V a_1 = v_t_2418; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_246); r_; });
    V v_es_2420 = ({ V a_0 = v_olds_247; V a_1 = v_m_248; V a_2 = v_t_2419; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(a_0, a_1, a_2)); heff_drop(v_olds_247); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_es_2420, 1), v_k_2414, v_t_2415));
    V v_t_2422 = ({ V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_es_2420, 13ULL, 4, shape_groups__copies__emits__jss, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2423 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, v_t_2413, v_t_2422));
    V t_0 = v_lit_240;
    V t_1 = v_t_2423;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1103469845x1474178821(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s886389550x1086668531_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s886389550x1086668531_entry, 1, 0};

V g_list_2emap_24s886389550x1086668531(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_v_245 = heff_field(v_x11_243, 0);
        V v_ty_246 = heff_field(v_x11_243, 1);
        V v_size_247 = heff_field(v_x11_243, 2);
        V v_little_248 = heff_field(v_x11_243, 3);
        V v_signed_249 = heff_field(v_x11_243, 4);
        heff_take_n(v_x11_243, 31ULL, 5);
        int64_t v_t_2410;
        if ((heff_dup(v_little_248) == NTAG(TAG_True))) {
          heff_drop(v_little_248);
          v_t_2410 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_248);
          v_t_2410 = ((int64_t)0ULL);
        }
        int64_t v_t_2411;
        if ((heff_dup(v_signed_249) == NTAG(TAG_True))) {
          heff_drop(v_signed_249);
          v_t_2411 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_249);
          v_t_2411 = ((int64_t)0ULL);
        }
        v_t_2412 = heff_rec_n(5, shape_value__ty__size__flags__span, (V[]){v_v_245, v_ty_246, v_size_247, heff_box_word((v_t_2410 + v_t_2411)), v_sp_244});
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s886389550x1086668531_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s886389550x1086668531_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s886389550x1086668531(a[0]);
}
Clo g_list_2efoldl_24s634644062x504497039_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s634644062x504497039_entry, 2, 0};

V g_list_2efoldl_24s634644062x504497039(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 11));
    V v_groups_245 = heff_take_field(v_a_244, 0);
    V v_above_246 = heff_get_n(v_a_244, 1, 2);
    V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_z_240, 0), v_groups_245));
    V v_t_248 = (g_heff_2esyntax_2efixity_2enubByG(v_t_247));
    V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_z_240, 1, 2), v_above_246));
    V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByE(v_t_249));
    V t_0 = heff_rec_n(2, shape_groups__above, (V[]){v_t_248, v_t_2410});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s634644062x504497039_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s634644062x504497039(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1535007417x1587061701_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_entry, 1, 0};

V g_list_2emap_24s1535007417x1587061701(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2419 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x_241_24At, TAG_MkPair, 2, (V[]){v_x_2419, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop(v_sp_244);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2425 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = (g_list_2emap_24s1535007417x1587061701_24dps(v_xs_242, heff_dup(v_cell_2426)));
    heff_drop(v_u_2427);
    return v_cell_2426;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701(a[0]);
}
Clo g_list_2efoldl_24s1468236620x1316701813_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1468236620x1316701813_entry, 2, 0};

V g_list_2efoldl_24s1468236620x1316701813(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1468236620x1316701813_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1468236620x1316701813(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s435407392x1528135477_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s435407392x1528135477_24dps_entry, 2, 0};

V g_list_2emap_24s435407392x1528135477_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s435407392x1528135477_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s23414532x1067218554_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s23414532x1067218554_entry, 6, 0};

V g_list_2emap_24s23414532x1067218554(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkFieldPat: {
      V v_a_248 = heff_field(v_x_246, 0);
      V v_a_249 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkFieldPat = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2410 = (g_heff_2esyntax_2eformat_2epatKey(v_a_249));
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      V v_a_2412 = heff_tag_at_n(v_ru_24x_246_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_248, v_t_2411});
      V v_a_2413 = (g_list_2emap_24s231073986x752637537(heff_dup(v_lit_241), v_a_2412));
      V v_t_2416;
      switch (heff_tag_of(v_a_2413)) {
      case TAG_Nil: {
        v_t_2416 = heff_dup(v_lit_242);
        break;
      }
      case TAG_Cons: {
        V v_a_2414 = heff_field(v_a_2413, 0);
        V v_a_2415 = heff_field(v_a_2413, 1);
        heff_take_n(v_a_2413, 3ULL, 2);
        v_t_2416 = ({ V a_0 = heff_dup(v_lit_243); V a_1 = v_a_2414; V a_2 = v_a_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2415); r_; });
        break;
      }
      default: heff_nomatch(v_a_2413);
      }
      v_t_2417 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2416), heff_dup(v_lit_244));
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_cell_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s23414532x1067218554_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s23414532x1067218554_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s23414532x1067218554(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1561756891x1126436879_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_entry, 1, 0};

V g_list_2emap_24s1561756891x1126436879(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2eformat_2epatKey(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1561756891x1126436879_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879(a[0]);
}
Clo g_list_2emap_24s135291903x1031656159_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s135291903x1031656159_24dps_entry, 3, 0};

V g_list_2emap_24s135291903x1031656159_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2efieldDeclKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s135291903x1031656159_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s135291903x1031656159_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1152414072x2935301_24dps_str0, 1, " ");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_24dps_str3, 4, "(alt");
HEFF_LIT(g_list_2emap_24s1152414072x2935301_24dps_str4, 1, ")");
Clo g_list_2emap_24s1152414072x2935301_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1152414072x2935301_24dps_entry, 3, 0};

V g_list_2emap_24s1152414072x2935301_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2419;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 1ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_MkAlt: {
        V v_p_249 = heff_field(v_x21_247, 0);
        V v_e_2410 = heff_field(v_x21_247, 1);
        heff_take_n(v_x21_247, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2eformat_2epatKey(v_p_249));
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2410}));
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_parts_2414 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_t_2411, v_t_2413});
        V v_x2_2415 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1152414072x2935301_24dps_str0), v_parts_2414));
        V v_t_2418;
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_Nil: {
          v_t_2418 = ((V)&g_list_2emap_24s1152414072x2935301_24dps_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x2_2415, 0);
          V v_xs_2417 = heff_field(v_x2_2415, 1);
          heff_take_n(v_x2_2415, 3ULL, 2);
          v_t_2418 = ({ V a_0 = ((V)&g_list_2emap_24s1152414072x2935301_24dps_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2415);
        }
        v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1152414072x2935301_24dps_str3), v_t_2418), ((V)&g_list_2emap_24s1152414072x2935301_24dps_str4));
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2420;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1152414072x2935301_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1152414072x2935301_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1698496827x1884878103_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1698496827x1884878103_24dps_entry, 2, 0};

V g_list_2emap_24s1698496827x1884878103_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 14), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1698496827x1884878103_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1698496827x1884878103_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1325969685x576913065_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1325969685x576913065_entry, 2, 0};

V g_list_2efoldl_24s1325969685x576913065(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 1)), 2, 3);
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1325969685x576913065(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s1136367117x833793205_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_lit_240, 0)) - heff_unbox_word(heff_strLength_lent(v_a_246, 0)));
    V v_t_248 = heff_strSlice(heff_dup(v_lit_240), heff_box_word(v_t_247), heff_strLength_lent(v_lit_240, 0));
    if (heff_strEq_c(v_t_248, v_a_246)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s1170504272x1852564147_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1170504272x1852564147_24dps_entry, 2, 0};

V g_list_2emap_24s1170504272x1852564147_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_246;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_249 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2412 = v_x_249;
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1170504272x1852564147_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1372232877x278600396_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1372232877x278600396_entry, 1, 0};

V g_list_2emap_24s1372232877x278600396(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2elsp_2esplit_2eexprName(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1372232877x278600396_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1372232877x278600396_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1372232877x278600396(a[0]);
}
Clo g_list_2ekeepIf_24s689992630x418898235_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s689992630x418898235_entry, 2, 0};

V g_list_2ekeepIf_24s689992630x418898235(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_lit_240, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (!heff_strEq_c_lent(v_t_246, v_t_249, 0)) {
      heff_drop(v_t_246);
      heff_drop(v_t_249);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = (g_list_2ekeepIf_24s689992630x418898235_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_246);
      heff_drop(v_t_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s689992630x418898235(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s446714453x706785629_24cpr(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 4);
    heff_drop(v_lit_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0))) && (heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2), heff_dup(v_lit_241)) && heff_intLe_c(heff_dup(v_lit_241), heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2))))) {
      heff_drop_rec(v_lit_240, 4);
      heff_drop(v_lit_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_243)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}
Clo g_list_2emap_24f1744384903x906515519_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1744384903x906515519_24dps_entry, 2, 0};

V g_list_2emap_24f1744384903x906515519_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Left: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_name_246 = heff_take_field(v_x_245, 0);
      V v_span_247 = heff_take_field(v_x_245, 1);
      V v_ty_248 = heff_take_field(v_x_245, 2);
      V v_whole_249 = heff_get_n(v_x_245, 4, 5);
      V v_t_2410 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_name_246, v_span_247, v_ty_248, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_whole_249}), heff_hole()});
      V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2411;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1744384903x906515519_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1744384903x906515519_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f2041933216x1458595349_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2041933216x1458595349_entry, 5, 0};

V g_list_2emap_24f2041933216x1458595349(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    HeffT2 v_t_247 = ({ V a_0 = v_x_245; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(a_0)); heff_drop(v_x_245); r_; });
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_t_2410 = heff_tag_n(TAG_Sig, 5, (V[]){heff_dup(v_lit_240), v_field_248, v_field_249, heff_dup(v_lit_241), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_lit_242), heff_dup(v_lit_243)})});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f2041933216x1458595349_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f2041933216x1458595349_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2041933216x1458595349(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f2029054136x351940068_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2029054136x351940068_entry, 4, 0};

V g_list_2efoldl_24f2029054136x351940068(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c_lent(v_lit_242, v_x_244, 0)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f2029054136x351940068_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f2029054136x351940068(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1221888634x716224461_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1221888634x716224461_entry, 2, 0};

V g_list_2emap_24f1221888634x716224461(V v_lit_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_CondTrue: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_CondFalse: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_CondRel: {
    V v_es_243 = heff_field(v_x1_241, 1);
    HEFF_LAST return g_list_2emap_24s215892288x1392224072(v_lit_240, heff_dup(v_es_243));
  }
  case TAG_CondRelU: {
    V v_es_245 = heff_field(v_x1_241, 1);
    HEFF_LAST return g_list_2emap_24s215892288x1392224072(v_lit_240, heff_dup(v_es_245));
  }
  case TAG_CondBool: {
    V v_e_246 = heff_field(v_x1_241, 0);
    V v_t_247 = (g_list_2emap_24s215892288x1392224072(heff_dup(v_lit_240), NTAG(TAG_Nil)));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_lit_240, heff_dup(v_e_246)}), v_t_247});
  }
  case TAG_CondNot: {
    V v_c_248 = heff_field(v_x1_241, 0);
    V t_0 = v_lit_240;
    V t_1 = v_c_248;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_249 = heff_field(v_x1_241, 0);
    V v_b_2410 = heff_field(v_x1_241, 1);
    V v_c_2411 = heff_field(v_x1_241, 2);
    V v_t_2412 = (g_heff_2ecompile_2eowned_2econdKids(v_a_249));
    V v_t_2413 = (g_heff_2ecompile_2eowned_2econdKids(v_b_2410));
    V v_t_2414 = (g_heff_2ecompile_2eowned_2econdKids(v_c_2411));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2414));
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2415));
    HEFF_LAST return g_list_2emap_24s215892288x1392224072(v_lit_240, v_t_2416);
  }
  case TAG_CondLet: {
    V v_e_2418 = heff_field(v_x1_241, 1);
    V v_c_2419 = heff_field(v_x1_241, 2);
    V v_cell_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_e_2418)}), heff_hole()});
    V v_u_2422 = (g_list_2emap_24f1221888634x716224461_24dps(v_lit_240, v_c_2419, heff_dup(v_cell_2421)));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1221888634x716224461_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f1221888634x716224461(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1730403549x1479772376_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1730403549x1479772376_24dps_entry, 13, 0};

V g_list_2emap_24f1730403549x1479772376_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411, V v_d_2412) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_2412, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    V v_xs_2414 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2415 = heff_take_field(v_x_2413, 0);
    V v_key_2416 = heff_get_n(v_x_2413, 1, 2);
    V v_a_2417 = v_name_2415;
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2417, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2417);
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_key_2416, heff_hole()});
      V v_u_2419 = heff_setField(v_d_2412, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_key_2416);
      heff_drop(v_a_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_d_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f1730403549x1479772376_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f1730403549x1479772376_24dps(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11], a[12]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}