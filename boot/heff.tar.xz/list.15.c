// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkDrop 35958
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_el 9998
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_from 9647217
#define LBL_id 10114
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_total 311908190
#define LBL_use 325633
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_witness 1587180415
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_heff_2ebuild_2edriver_2eglueOne(V, V);
V g_heff_2ebuild_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eglueOne_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2efacts_2eflatW(V, V);
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatW_clo;
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(V, V);
V g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2ecompile_2eworker_2ewithSig(V, V, V);
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ewithSig_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eall_24s992198975x2074072147(V, V, V);
V g_list_2eall_24s992198975x2074072147_entry(V self, V *a);
extern Clo g_list_2eall_24s992198975x2074072147_clo;
V g_list_2eany_24s1435885690x1984517496(V, V);
V g_list_2eany_24s1435885690x1984517496_entry(V self, V *a);
extern Clo g_list_2eany_24s1435885690x1984517496_clo;
V g_list_2eany_24s1721003522x874107866(V, V);
V g_list_2eany_24s1721003522x874107866_entry(V self, V *a);
extern Clo g_list_2eany_24s1721003522x874107866_clo;
V g_list_2eany_24s384244645x1082490665(V, V);
V g_list_2eany_24s384244645x1082490665_entry(V self, V *a);
extern Clo g_list_2eany_24s384244645x1082490665_clo;
V g_list_2eany_24s70593242x1575694473(V, V);
V g_list_2eany_24s70593242x1575694473_entry(V self, V *a);
extern Clo g_list_2eany_24s70593242x1575694473_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1109331425x852844386_24dps(V, V, V, V);
V g_list_2efilter_24s1109331425x852844386_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1109331425x852844386_24dps_clo;
V g_list_2efilter_24s1371839958x1221974112(V, V);
V g_list_2efilter_24s1371839958x1221974112_entry(V self, V *a);
extern Clo g_list_2efilter_24s1371839958x1221974112_clo;
V g_list_2efilter_24s1371839958x1221974112_24dps(V, V, V);
V g_list_2efilter_24s1371839958x1221974112_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1371839958x1221974112_24dps_clo;
V g_list_2efilter_24s1596967535x1519602627_24dps(V, V, V);
V g_list_2efilter_24s1596967535x1519602627_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1596967535x1519602627_24dps_clo;
V g_list_2efilter_24s1966236437x1225976932(V, V);
V g_list_2efilter_24s1966236437x1225976932_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_clo;
V g_list_2efilter_24s1966236437x1225976932_24dps(V, V, V);
V g_list_2efilter_24s1966236437x1225976932_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_24dps_clo;
V g_list_2efilter_24s2009824277x1398398543_24dps(V, V, V, V);
V g_list_2efilter_24s2009824277x1398398543_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2009824277x1398398543_24dps_clo;
V g_list_2efilter_24s2018073091x1385246979_24dps(V, V);
V g_list_2efilter_24s2018073091x1385246979_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_24dps_clo;
V g_list_2efilter_24s316268077x2111002396(V, V);
V g_list_2efilter_24s316268077x2111002396_entry(V self, V *a);
extern Clo g_list_2efilter_24s316268077x2111002396_clo;
V g_list_2efilter_24s316268077x2111002396_24dps(V, V, V);
V g_list_2efilter_24s316268077x2111002396_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s316268077x2111002396_24dps_clo;
V g_list_2efilter_24s343483820x881052984(V, V);
V g_list_2efilter_24s343483820x881052984_entry(V self, V *a);
extern Clo g_list_2efilter_24s343483820x881052984_clo;
V g_list_2efilter_24s343483820x881052984_24dps(V, V, V);
V g_list_2efilter_24s343483820x881052984_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s343483820x881052984_24dps_clo;
V g_list_2efind_24s1184231137x30317987(V, V);
V g_list_2efind_24s1184231137x30317987_entry(V self, V *a);
extern Clo g_list_2efind_24s1184231137x30317987_clo;
V g_list_2efind_24s1702742059x483228236(V, V);
V g_list_2efind_24s1702742059x483228236_entry(V self, V *a);
extern Clo g_list_2efind_24s1702742059x483228236_clo;
V g_list_2efind_24s1839921325x671097810(V, V);
V g_list_2efind_24s1839921325x671097810_entry(V self, V *a);
extern Clo g_list_2efind_24s1839921325x671097810_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24f139246788x401086883(V, V);
V g_list_2efoldl_24f139246788x401086883_entry(V self, V *a);
extern Clo g_list_2efoldl_24f139246788x401086883_clo;
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24f316845240x1272469554(V, V, V, V);
V g_list_2efoldl_24f316845240x1272469554_entry(V self, V *a);
extern Clo g_list_2efoldl_24f316845240x1272469554_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2004150897x784001505(V, V);
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2004150897x784001505_clo;
V g_list_2efoldl_24s2063565291x1181877757(V, V, V);
V g_list_2efoldl_24s2063565291x1181877757_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2063565291x1181877757_clo;
V g_list_2efoldl_24s2103009317x1481930218(V, V);
V g_list_2efoldl_24s2103009317x1481930218_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2103009317x1481930218_clo;
V g_list_2efoldl_24s378225814x484524589(V, V);
V g_list_2efoldl_24s378225814x484524589_entry(V self, V *a);
extern Clo g_list_2efoldl_24s378225814x484524589_clo;
V g_list_2efoldl_24s518608766x1858781247(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s518608766x1858781247_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518608766x1858781247_clo;
V g_list_2efoldl_24s560581624x1100110660(V, V, V);
V g_list_2efoldl_24s560581624x1100110660_entry(V self, V *a);
extern Clo g_list_2efoldl_24s560581624x1100110660_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap_24f1162912426x1278991032_24dps(V, V);
V g_list_2emap_24f1162912426x1278991032_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1162912426x1278991032_24dps_clo;
V g_list_2emap_24f1217399696x462307458_24dps(V, V, V, V);
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_24dps_clo;
V g_list_2emap_24f1881659548x1623692567_24dps(V, V, V);
V g_list_2emap_24f1881659548x1623692567_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1881659548x1623692567_24dps_clo;
V g_list_2emap_24f2056124927x822823214(V, V, V);
V g_list_2emap_24f2056124927x822823214_entry(V self, V *a);
extern Clo g_list_2emap_24f2056124927x822823214_clo;
V g_list_2emap_24f2056124927x822823214_24dps(V, V, V, V);
V g_list_2emap_24f2056124927x822823214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2056124927x822823214_24dps_clo;
V g_list_2emap_24f2063070488x1806431062_24dps(V, V, V);
V g_list_2emap_24f2063070488x1806431062_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_24dps_clo;
V g_list_2emap_24f378206553x1816388893_24dps(V, V, V, V, V);
V g_list_2emap_24f378206553x1816388893_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f378206553x1816388893_24dps_clo;
V g_list_2emap_24f505181408x1813697659_24dps(V, V, V);
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_24dps_clo;
V g_list_2emap_24f783067987x1926181389(V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_clo;
V g_list_2emap_24f783067987x1926181389_24dps(V, V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_24dps_clo;
V g_list_2emap_24f88106788x1680212182_24dps(V, V);
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_24dps_clo;
V g_list_2emap_24s1006818869x590968200(V);
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_clo;
V g_list_2emap_24s1006818869x590968200_24dps(V, V);
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_24dps_clo;
V g_list_2emap_24s1068592055x839006909_24dps(V, V, V, V, V);
V g_list_2emap_24s1068592055x839006909_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1068592055x839006909_24dps_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1243189782x897571843_24dps(V, V, V);
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_24dps_clo;
V g_list_2emap_24s1292210741x1158835606(V, V, V);
V g_list_2emap_24s1292210741x1158835606_entry(V self, V *a);
extern Clo g_list_2emap_24s1292210741x1158835606_clo;
V g_list_2emap_24s1292210741x1158835606_24dps(V, V, V, V);
V g_list_2emap_24s1292210741x1158835606_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1292210741x1158835606_24dps_clo;
V g_list_2emap_24s131934541x153143574(V, V, V, V, V, V);
V g_list_2emap_24s131934541x153143574_entry(V self, V *a);
extern Clo g_list_2emap_24s131934541x153143574_clo;
V g_list_2emap_24s131934541x153143574_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s131934541x153143574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s131934541x153143574_24dps_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1386329375x1773300759_24dps(V, V);
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_24dps_clo;
V g_list_2emap_24s1387309293x1990579214(V);
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_clo;
V g_list_2emap_24s1387309293x1990579214_24dps(V, V);
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_24dps_clo;
V g_list_2emap_24s1418045490x2076674085_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_24dps_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1703643582x349630108(V, V);
V g_list_2emap_24s1703643582x349630108_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_clo;
V g_list_2emap_24s1703643582x349630108_24dps(V, V, V);
V g_list_2emap_24s1703643582x349630108_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_24dps_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2emap_24s1791433880x1360378684_24dps(V, V);
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1817753698x509594538(V, V, V);
V g_list_2emap_24s1817753698x509594538_entry(V self, V *a);
extern Clo g_list_2emap_24s1817753698x509594538_clo;
V g_list_2emap_24s1817753698x509594538_24dps(V, V, V, V);
V g_list_2emap_24s1817753698x509594538_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817753698x509594538_24dps_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s1819241345x1511673126_24dps(V, V);
V g_list_2emap_24s1819241345x1511673126_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_24dps_clo;
V g_list_2emap_24s1854779998x1713580578(V);
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_clo;
V g_list_2emap_24s1854779998x1713580578_24dps(V, V);
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_24dps_clo;
V g_list_2emap_24s1917875516x88484758(V);
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_clo;
V g_list_2emap_24s1917875516x88484758_24dps(V, V);
V g_list_2emap_24s1917875516x88484758_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_24dps_clo;
V g_list_2emap_24s2039279853x710813703_24dps(V, V, V);
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_24dps_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s456133444x1904936646_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_24dps_clo;
V g_list_2emap_24s499193121x1224230698(V);
V g_list_2emap_24s499193121x1224230698_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_clo;
V g_list_2emap_24s499193121x1224230698_24dps(V, V);
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_24dps_clo;
V g_list_2emap_24s503834852x510769098_24dps(V, V, V);
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_24dps_clo;
V g_list_2emap_24s567711145x425963688_24dps(V, V, V, V, V);
V g_list_2emap_24s567711145x425963688_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s567711145x425963688_24dps_clo;
V g_list_2emap_24s584558070x895760461(V, V);
V g_list_2emap_24s584558070x895760461_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_clo;
V g_list_2emap_24s584558070x895760461_24dps(V, V, V);
V g_list_2emap_24s584558070x895760461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_24dps_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24s73473062x206541869_24dps(V, V);
V g_list_2emap_24s73473062x206541869_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_24dps_clo;
V g_list_2emap_24s79542405x478516404_24dps(V, V);
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_24dps_clo;
V g_list_2emap_24s88069640x1067514236_24dps(V, V);
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_24dps_clo;
V g_list_2emap_24s903588428x1469638784_24dps(V, V, V);
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_24dps_clo;
V g_list_2emap_24s917234327x1197288555_24dps(V, V);
V g_list_2emap_24s917234327x1197288555_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_24dps_clo;
V g_list_2emap_24s942566919x1152393003_24dps(V, V, V);
V g_list_2emap_24s942566919x1152393003_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_24dps_clo;
V g_list_2emerge_24s1716485482x1012130009(V, V);
V g_list_2emerge_24s1716485482x1012130009_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2erange_24dps(V, V, V);
V g_list_2erange_24dps_entry(V self, V *a);
extern Clo g_list_2erange_24dps_clo;
V g_list_2esortBy_24s1223185427x423554351(V);
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1223185427x423554351_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2etake_24dps(V, V, V);
V g_list_2etake_24dps_entry(V self, V *a);
extern Clo g_list_2etake_24dps_clo;
V g_list_2ezipWith_24s1029292936x211450510_24dps(V, V, V);
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
Clo g_list_2etake_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_entry, 2, 0};

V g_list_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2etake_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_entry(V self, V *a) {
  (void)self;
  return g_list_2etake(a[0], a[1]);
}
Clo g_list_2etake_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_24dps_entry, 3, 0};

V g_list_2etake_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2etake_24dps(a[0], a[1], a[2]);
}
Clo g_list_2elookupBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2elookupBy_entry, 3, 0};

V g_list_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_eq_240);
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_27_245 = heff_field(v_x31_243, 0);
      V v_v_246 = heff_field(v_x31_243, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_k_241), heff_dup(v_k_27_245)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_eq_240);
        heff_drop(v_k_241);
        heff_drop(v_t_247);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_246)});
      } else {
        heff_drop(v_t_247);
        V t_0 = v_eq_240;
        V t_1 = v_k_241;
        V t_2 = v_rest_244;
        v_eq_240 = t_0;
        v_k_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2elookupBy_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2elookupBy(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2erange_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_entry, 2, 0};

V g_list_2erange(V v_a_240, V v_b_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_241), heff_dup(v_a_240))) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), heff_hole()});
    V v_u_244 = (g_list_2erange_24dps(heff_intAdd(v_a_240, MK_INT(1LL)), v_b_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2erange_entry(V self, V *a) {
  (void)self;
  return g_list_2erange(a[0], a[1]);
}
Clo g_list_2efilter_24s1596967535x1519602627_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1596967535x1519602627_24dps_entry, 3, 0};

V g_list_2efilter_24s1596967535x1519602627_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_x_243, 1)))) {
        heff_drop_rec(v_x_243, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_cell_247;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    } else {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1596967535x1519602627_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1596967535x1519602627_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1759289969x319536741_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1759289969x319536741_entry, 2, 0};

V g_list_2efoldl_24s1759289969x319536741(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_247 = (g_heff_2esyntax_2efmt_2eimports_2espacesOf(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength_lent(v_z_240, 0));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1759289969x319536741(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s942566919x1152393003_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s942566919x1152393003_24dps_entry, 3, 0};

V g_list_2emap_24s942566919x1152393003_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2eargOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s942566919x1152393003_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s942566919x1152393003_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1243189782x897571843_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1243189782x897571843_entry, 2, 0};

V g_list_2emap_24s1243189782x897571843(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1243189782x897571843_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1243189782x897571843(a[0], a[1]);
}
Clo g_list_2emap_24s2039279853x710813703_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039279853x710813703_24dps_entry, 3, 0};

V g_list_2emap_24s2039279853x710813703_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldSetOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2039279853x710813703_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2039279853x710813703_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s79542405x478516404_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_24dps_entry, 2, 0};

V g_list_2emap_24s79542405x478516404_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s79542405x478516404_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1006818869x590968200_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006818869x590968200_entry, 1, 0};

V g_list_2emap_24s1006818869x590968200(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 7), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1006818869x590968200_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006818869x590968200(a[0]);
}
Clo g_list_2emap_24s73473062x206541869_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_entry, 1, 0};

V g_list_2emap_24s73473062x206541869(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), heff_hole()});
    V v_u_244 = (g_list_2emap_24s73473062x206541869_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869(a[0]);
}
Clo g_list_2emap_24s2067043448x720245267_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_entry, 1, 0};

V g_list_2emap_24s2067043448x720245267(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2067043448x720245267_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267(a[0]);
}
Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1029292936x211450510_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_243, 0);
        heff_take_n(v_x_243, 1ULL, 2);
        v_t_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_y_245}), heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_2410;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s634927308x1347712163_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s634927308x1347712163_entry, 2, 0};

V g_list_2efoldl_24s634927308x1347712163(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s634927308x1347712163(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2003609603x1707519208_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2003609603x1707519208_entry, 2, 0};

V g_list_2efoldl_24s2003609603x1707519208(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_tr(g_heff_2ecompile_2eimperative_2epartsSt_24s907942474x1810704233(v_x_242, v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2003609603x1707519208(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1721003522x874107866_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1721003522x874107866_entry, 2, 0};

V g_list_2eany_24s1721003522x874107866(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x_242)) {
    case TAG_PartVal: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_t_2428;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SVar: {
        V v_a_245 = heff_field(v_a_244, 0);
        v_t_2428 = heff_strEq_lent(v_lit_240, v_a_245, 0);
        break;
      }
      case TAG_SGlobal: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
        heff_drop(v_lit_240);
        heff_drop(v_t_2428);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2428);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_PartOp: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1721003522x874107866_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1721003522x874107866(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1917875516x88484758_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1917875516x88484758_entry, 1, 0};

V g_list_2emap_24s1917875516x88484758(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_241, NTAG(TAG_RepV)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1917875516x88484758_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1917875516x88484758(a[0]);
}
Clo g_list_2efoldl_24s2004150897x784001505_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2004150897x784001505_entry, 2, 0};

V g_list_2efoldl_24s2004150897x784001505(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2eflatW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2004150897x784001505(a[0], a[1]);
}
Clo g_list_2efoldl_24s2063565291x1181877757_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2063565291x1181877757_entry, 3, 0};

V g_list_2efoldl_24s2063565291x1181877757(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), heff_dup(v_lit_240), v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2063565291x1181877757_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s2063565291x1181877757(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s895450532x1092988905_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s895450532x1092988905_entry, 2, 0};

V g_list_2efoldl_24s895450532x1092988905(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s895450532x1092988905(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1292210741x1158835606_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1292210741x1158835606_entry, 3, 0};

V g_list_2emap_24s1292210741x1158835606(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 6);
    V v_t_246 = heff_tr(heff_call(v_t_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_247 = heff_get_n(heff_get_n(v_x_243, 0, 3), 1, 6);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_247, heff_dup(v_lit_241)));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, v_t_248), heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1292210741x1158835606_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1292210741x1158835606_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1292210741x1158835606(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1729297000x968708966_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_24dps_entry, 2, 0};

V g_list_2emap_24s1729297000x968708966_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_242, 0), heff_get_n(v_x_242, 2, 5)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729297000x968708966_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1966236437x1225976932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1966236437x1225976932_entry, 2, 0};

V g_list_2efilter_24s1966236437x1225976932(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_UpdateTo: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_244;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_2412, v_lit_240, 1)) {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2415 = (g_list_2efilter_24s1966236437x1225976932_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1966236437x1225976932_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1966236437x1225976932(a[0], a[1]);
}
Clo g_list_2emap_24s88069640x1067514236_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s88069640x1067514236_24dps_entry, 2, 0};

V g_list_2emap_24s88069640x1067514236_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_t_249, 1);
      heff_take_n(v_t_249, 2ULL, 2);
      v_t_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s88069640x1067514236_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1435885690x1984517496_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1435885690x1984517496_entry, 2, 0};

V g_list_2eany_24s1435885690x1984517496(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_lit_240, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c(v_t_246, v_t_249)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1435885690x1984517496_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1435885690x1984517496(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2103009317x1481930218_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2103009317x1481930218_entry, 2, 0};

V g_list_2efoldl_24s2103009317x1481930218(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2eworker_2ewithSig(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2103009317x1481930218_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2103009317x1481930218(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s567711145x425963688_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s567711145x425963688_24dps_entry, 5, 0};

V g_list_2emap_24s567711145x425963688_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 3ULL, 2);
      if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_a_247, v_lit_241, v_lit_242, 1))) {
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_a_248});
      } else {
        heff_drop(v_a_248);
        v_t_2410 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s567711145x425963688_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s567711145x425963688_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s732475005x1616712052_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_24dps_entry, 2, 0};

V g_list_2emap_24s732475005x1616712052_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eexportNameOf(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s456133444x1904936646_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456133444x1904936646_24dps_entry, 9, 0};

V g_list_2emap_24s456133444x1904936646_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_249)) {
    case TAG_MkDrop: {
      V v_a_2411 = heff_field(v_x_249, 0);
      V v_a_2412 = heff_field(v_x_249, 1);
      heff_take_n(v_x_249, 3ULL, 2);
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Nothing: {
        V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_a_2411, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)));
        V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2413), heff_dup(v_lit_245));
        v_t_2416 = heff_strAppend(heff_dup(v_lit_240), v_t_2414);
        break;
      }
      case TAG_Just: {
        V v_a_2415 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 1);
        v_t_2416 = ({ V a_0 = v_a_2411; V a_1 = v_a_2415; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2415); r_; });
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2418 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s456133444x1904936646_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456133444x1904936646_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2efoldl_24s125569247x179592613_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s125569247x179592613_entry, 2, 0};

V g_list_2efoldl_24s125569247x179592613(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eprimCloDef(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s125569247x179592613(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str0, 1, "V");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str1, 6, "double");
Clo g_list_2emap_24s1386329375x1773300759_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386329375x1773300759_24dps_entry, 2, 0};

V g_list_2emap_24s1386329375x1773300759_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_245 = ({ V a_0 = v_w_244; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_244); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str1);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386329375x1773300759_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s131934541x153143574_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s131934541x153143574_entry, 6, 0};

V g_list_2emap_24s131934541x153143574(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    V v_t_2411;
    if (heff_strEq_c_lent(v_t_248, v_lit_242, 1)) {
      V v_t_2410 = (g_heff_2ecompile_2eemitc_2eidentAt(v_x_246, heff_dup(v_lit_243), heff_dup(v_lit_244)));
      v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_x_246);
      v_t_2411 = NTAG(TAG_Nothing);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s131934541x153143574_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s131934541x153143574_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s131934541x153143574(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s131934541x153143574_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s131934541x153143574_24dps_entry, 7, 0};

V g_list_2emap_24s131934541x153143574_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_x_247), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    V v_t_2412;
    if (heff_strEq_c_lent(v_t_249, v_lit_242, 1)) {
      V v_t_2411 = (g_heff_2ecompile_2eemitc_2eidentAt(v_x_247, heff_dup(v_lit_243), heff_dup(v_lit_244)));
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
    } else {
      heff_drop(v_x_247);
      v_t_2412 = NTAG(TAG_Nothing);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s131934541x153143574_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s131934541x153143574_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s378225814x484524589_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s378225814x484524589_entry, 2, 0};

V g_list_2efoldl_24s378225814x484524589(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2415, v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s378225814x484524589_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s378225814x484524589(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s503834852x510769098_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503834852x510769098_24dps_entry, 3, 0};

V g_list_2emap_24s503834852x510769098_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_243; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503834852x510769098_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s584558070x895760461_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584558070x895760461_entry, 2, 0};

V g_list_2emap_24s584558070x895760461(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eelab_2eclauses_2erenameEquation(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s584558070x895760461_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s584558070x895760461_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584558070x895760461(a[0], a[1]);
}
Clo g_list_2emap_24s1068592055x839006909_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1068592055x839006909_24dps_entry, 5, 0};

V g_list_2emap_24s1068592055x839006909_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 10);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_lit_240, 9));
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = heff_dup(v_lit_241);
    } else {
      heff_drop(v_t_247);
      v_t_248 = heff_dup(v_lit_242);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_x_245), heff_hole()});
    V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1068592055x839006909_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1068592055x839006909_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str9, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str10, 0, "");
Clo g_list_2emap_24s218655275x981659442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_entry, 1, 0};

V g_list_2emap_24s218655275x981659442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2416 = v_s_2410;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str8);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str9);
      break;
    }
    case TAG_VErased: {
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str10);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s218655275x981659442_24dps(v_xs_242, heff_dup(v_cell_2417)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442(a[0]);
}
Clo g_list_2efind_24s1184231137x30317987_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1184231137x30317987_entry, 2, 0};

V g_list_2efind_24s1184231137x30317987(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1184231137x30317987_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1184231137x30317987(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_24s1702742059x483228236_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1702742059x483228236_entry, 2, 0};

V g_list_2efind_24s1702742059x483228236(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1702742059x483228236_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1702742059x483228236(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1418045490x2076674085_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418045490x2076674085_24dps_entry, 11, 0};

V g_list_2emap_24s1418045490x2076674085_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249, V v_d_2410) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return heff_setField(v_d_2410, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_249, 0);
    V v_xs_2412 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2413 = heff_take_field(v_x_2411, 1);
    V v_t_2414;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_AssocLeft: {
      v_t_2414 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2414 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2414 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_t_2415 = heff_take_field(v_x_2411, 3);
    V v_t_2416;
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      v_t_2416 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_t_2415);
      v_t_2416 = heff_dup(v_lit_245);
    }
    V v_t_2417 = heff_take_field(v_x_2411, 2);
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nil: {
      v_t_2420 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_t_2417, 0);
      V v_a_2419 = heff_field(v_t_2417, 1);
      heff_take_n(v_t_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2418; V a_2 = v_a_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2419); r_; });
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2421 = heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_246), v_t_2420));
    V v_t_2422 = heff_strAppend(heff_intShow(v_t_2414), v_t_2421);
    V v_t_2423 = heff_strAppend(heff_get_n(v_x_2411, 0, 5), heff_strAppend(heff_dup(v_lit_240), v_t_2422));
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_2410, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_xs_2412;
    V t_10 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_x2_249 = t_9;
    v_d_2410 = t_10;
    goto top;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s1418045490x2076674085_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1418045490x2076674085_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2efoldl_24s518608766x1858781247_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s518608766x1858781247_entry, 12, 0};

V g_list_2efoldl_24s518608766x1858781247(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_z_2410, V v_x3_2411) {
top: ;
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return v_z_2410;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x3_2411, 0);
    V v_xs_2413 = heff_field(v_x3_2411, 1);
    V v_ru_24x3_2411_24Cons = heff_take_reuse_n(v_x3_2411, 3ULL, 2);
    V v_a_2414 = heff_take_field(v_x_2412, 0);
    V v_t_2415 = heff_intShow(heff_strLength_lent(v_a_2414, 0));
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_lit_240), v_a_2414));
    V v_t_2417 = heff_take_field(v_x_2412, 1);
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_AssocLeft: {
      v_t_2418 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2418 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2418 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2419 = heff_take_field(v_x_2412, 3);
    V v_t_2420;
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(v_lit_245);
    }
    V v_a_2421 = heff_take_field(v_x_2412, 4);
    V v_t_2422 = heff_intShow(heff_strLength_lent(v_a_2421, 0));
    V v_t_2423 = heff_strAppend(v_t_2422, heff_strAppend(heff_dup(v_lit_246), v_a_2421));
    V v_a_2424 = heff_get_n(v_x_2412, 2, 5);
    V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_247), heff_dup(v_lit_248), v_a_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2424));
    V v_t_2427 = (g_list_2efoldl_24s560581624x1100110660(heff_dup(v_lit_249), NTAG(TAG_Nil), v_t_2426));
    V v_t_2428 = heff_tag_at_n(v_ru_24x3_2411_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2427});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2429});
    V v_t_2431 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2430}), v_z_2410));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_t_2431;
    V t_11 = v_xs_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_z_2410 = t_10;
    v_x3_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_list_2efoldl_24s518608766x1858781247_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s518608766x1858781247(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2eall_24s78096928x1476871221_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s78096928x1476871221_entry, 3, 0};

V g_list_2eall_24s78096928x1476871221(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2eisSameIn(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_245);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s78096928x1476871221(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s903588428x1469638784_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s903588428x1469638784_24dps_entry, 3, 0};

V g_list_2emap_24s903588428x1469638784_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = heff_get_n(v_x_243, 2, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_a_245), heff_strLength_lent(v_a_245, 0)));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice_lent(v_a_245, v_lit_240, v_t_246, 5), heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s903588428x1469638784_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s992198975x2074072147_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s992198975x2074072147_entry, 3, 0};

V g_list_2eall_24s992198975x2074072147(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_243))) {
      if (heff_intLe_c(heff_dup(v_x_243), heff_dup(v_lit_241))) {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s992198975x2074072147_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s992198975x2074072147(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1703643582x349630108_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1703643582x349630108_entry, 2, 0};

V g_list_2emap_24s1703643582x349630108(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = (g_prelude_2eparseInt(v_x_242));
    V v_t_246;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      v_t_246 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1703643582x349630108_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1703643582x349630108_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1703643582x349630108(a[0], a[1]);
}
Clo g_list_2emap_24s1791433880x1360378684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1791433880x1360378684_entry, 1, 0};

V g_list_2emap_24s1791433880x1360378684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1791433880x1360378684_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1791433880x1360378684(a[0]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str0, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str2, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str3, 9, "{ name = ");
Clo g_list_2emap_24s1381986540x1952410492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_entry, 1, 0};

V g_list_2emap_24s1381986540x1952410492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 0)));
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 1)));
    V v_t_245 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_241, 2, 3)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str0), heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1381986540x1952410492_str1)));
    V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str2), heff_strAppend(v_t_244, v_t_246));
    V v_t_248 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str3), heff_strAppend(v_t_243, v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1381986540x1952410492_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492(a[0]);
}
Clo g_list_2emap_24s917234327x1197288555_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s917234327x1197288555_24dps_entry, 2, 0};

V g_list_2emap_24s917234327x1197288555_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s917234327x1197288555_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s917234327x1197288555_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s2018073091x1385246979_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2018073091x1385246979_24dps_entry, 2, 0};

V g_list_2efilter_24s2018073091x1385246979_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2018073091x1385246979_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2018073091x1385246979_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1109331425x852844386_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1109331425x852844386_24dps_entry, 4, 0};

V g_list_2efilter_24s1109331425x852844386_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 1, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 2);
    V v_t_248 = heff_strLength(heff_dup(heff_rfield(v_x_244, 1)));
    if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intAdd(v_t_248, heff_dup(v_lit_240)))) {
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 2);
      if (heff_intLe_c(v_t_2410, heff_dup(v_lit_241))) {
        V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 1, 2);
        if (heff_intLe_c(heff_dup(v_lit_241), v_t_2412)) {
          V v_cell_2414 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
          V v_u_2415 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2414));
          heff_drop(v_u_2415);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_245;
          V t_3 = v_cell_2414;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          v_d_243 = t_3;
          goto top;
        } else {
          heff_drop_rec(v_x_244, 5);
          heff_drop_cell(v_ru_24x2_242_24Cons, 2);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_245;
          V t_3 = v_d_243;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      } else {
        heff_drop_rec(v_x_244, 5);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_245;
        V t_3 = v_d_243;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_244, 5);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s1109331425x852844386_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1109331425x852844386_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2esortBy_24s1223185427x423554351_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1223185427x423554351_entry, 1, 0};

V g_list_2esortBy_24s1223185427x423554351(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1223185427x423554351(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1223185427x423554351(v_t_249));
      return (g_list_2emerge_24s1716485482x1012130009(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1223185427x423554351(a[0]);
}
Clo g_list_2emap_24s1817753698x509594538_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817753698x509594538_entry, 3, 0};

V g_list_2emap_24s1817753698x509594538(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_246 = heff_take_field(v_x_243, 0);
    V v_a_247 = heff_intSub(heff_dup(heff_rfield(v_x_243, 1)), heff_strLength_lent(v_lit_241, 0));
    V v_t_249;
    if (heff_intLe_c(heff_dup(v_a_246), heff_dup(v_a_247))) {
      heff_drop(v_a_246);
      v_t_249 = v_a_247;
    } else {
      heff_drop(v_a_247);
      v_t_249 = v_a_246;
    }
    V v_t_2410 = ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_x_243, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_245, heff_dup(v_lit_241), v_t_2410}), heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1817753698x509594538_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1817753698x509594538_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817753698x509594538(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s316268077x2111002396_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s316268077x2111002396_entry, 2, 0};

V g_list_2efilter_24s316268077x2111002396(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_x_242, 13);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s316268077x2111002396_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s316268077x2111002396_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s316268077x2111002396(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_entry, 1, 0};

V g_list_2emap_24s1819241345x1511673126(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_strSlice_lent(v_x_241, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_list_2emap_24s1819241345x1511673126_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_241), MK_INT(5LL), heff_strLength(v_x_241));
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(v_x_241, ((V)&g_list_2emap_24s1819241345x1511673126_str1))) {
        v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_str2)});
      } else {
        v_t_246 = NTAG(TAG_Nothing);
      }
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1819241345x1511673126_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126(a[0]);
}
Clo g_list_2efilter_24s343483820x881052984_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s343483820x881052984_entry, 2, 0};

V g_list_2efilter_24s343483820x881052984(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    if (heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), v_t_244)) {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
      if (heff_intLe_c(v_t_246, heff_dup(heff_rfield(v_lit_240, 1)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_249 = (g_list_2efilter_24s343483820x881052984_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_rec(v_x_242, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s343483820x881052984_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s343483820x881052984(a[0], a[1]);
}
Clo g_list_2efilter_24s1371839958x1221974112_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1371839958x1221974112_entry, 2, 0};

V g_list_2efilter_24s1371839958x1221974112(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1371839958x1221974112_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1371839958x1221974112_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1371839958x1221974112(a[0], a[1]);
}
Clo g_list_2emap_24s1420651609x666245096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_entry, 1, 0};

V g_list_2emap_24s1420651609x666245096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1420651609x666245096_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096(a[0]);
}
Clo g_list_2emap_24s1387309293x1990579214_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1387309293x1990579214_entry, 1, 0};

V g_list_2emap_24s1387309293x1990579214(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1387309293x1990579214_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1387309293x1990579214(a[0]);
}
Clo g_list_2emap_24s499193121x1224230698_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499193121x1224230698_entry, 1, 0};

V g_list_2emap_24s499193121x1224230698(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_ru_24x11_243_24PatVar = heff_take_reuse_n(v_x11_243, 1ULL, 1);
        v_t_2422 = heff_tag_at_n(v_ru_24x11_243_24PatVar, TAG_Just, 1, (V[]){v_x_245});
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_243, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_243, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_243, 0ULL, 3);
        v_t_2422 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s499193121x1224230698_24dps(v_xs_242, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s499193121x1224230698_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499193121x1224230698(a[0]);
}
Clo g_list_2eany_24s384244645x1082490665_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s384244645x1082490665_entry, 2, 0};

V g_list_2eany_24s384244645x1082490665(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 13);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s384244645x1082490665_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s384244645x1082490665(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1854779998x1713580578_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1854779998x1713580578_entry, 1, 0};

V g_list_2emap_24s1854779998x1713580578(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 8), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1854779998x1713580578_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1854779998x1713580578(a[0]);
}
Clo g_list_2eany_24s70593242x1575694473_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s70593242x1575694473_entry, 2, 0};

V g_list_2eany_24s70593242x1575694473(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 2)), heff_dup(v_lit_240))) {
      V v_t_245 = heff_dup(heff_rfield(v_x_242, 4));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        heff_drop(v_lit_240);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_245);
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s70593242x1575694473_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s70593242x1575694473(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_24s1839921325x671097810_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1839921325x671097810_entry, 2, 0};

V g_list_2efind_24s1839921325x671097810(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1839921325x671097810_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1839921325x671097810(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s2009824277x1398398543_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2009824277x1398398543_24dps_entry, 4, 0};

V g_list_2efilter_24s2009824277x1398398543_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s2009824277x1398398543_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2009824277x1398398543_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1881659548x1623692567_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1881659548x1623692567_24dps_entry, 3, 0};

V g_list_2emap_24f1881659548x1623692567_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 1, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1881659548x1623692567_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1881659548x1623692567_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f88106788x1680212182_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f88106788x1680212182_24dps_entry, 2, 0};

V g_list_2emap_24f88106788x1680212182_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_x_242, 3);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 5), heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f88106788x1680212182_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2efoldl_24f158727028x1528233175_str0, 3, "sym");
Clo g_list_2efoldl_24f158727028x1528233175_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f158727028x1528233175_entry, 3, 0};

V g_list_2efoldl_24f158727028x1528233175(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_242, 0);
    V v_rest_244 = heff_field(v_x1_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_list_2efoldl_24f158727028x1528233175_str0))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_rest_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x1_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      return v_z_241;
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f158727028x1528233175(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f783067987x1926181389_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f783067987x1926181389_entry, 5, 0};

V g_list_2emap_24f783067987x1926181389(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_244), heff_dup(v_a_243))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return NTAG(TAG_Nil);
  } else {
    V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_a_243));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_t_246, heff_dup(v_lit_242)), heff_hole()});
    V v_u_248 = (g_list_2emap_24f783067987x1926181389_24dps(v_lit_240, v_lit_241, v_lit_242, heff_intAdd(v_a_243, MK_INT(1LL)), v_b_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
}
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f783067987x1926181389(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f505181408x1813697659_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f505181408x1813697659_24dps_entry, 3, 0};

V g_list_2emap_24f505181408x1813697659_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_246 = (g_list_2emap_24s1809017761x1063871171(v_xs_244));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_243}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f505181408x1813697659_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1162912426x1278991032_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1162912426x1278991032_24dps_entry, 2, 0};

V g_list_2emap_24f1162912426x1278991032_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_2439;
    switch (heff_tag_of(v_t_244)) {
    case TAG_EVar: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_244, 0ULL, 3);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_244, 0ULL, 4);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_244, 0ULL, 3);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_244, 0ULL, 1);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      V v_t_2440 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_242, 2)), NTAG(TAG_Nil)});
      V v_t_2441 = (g_heff_2ecompile_2eworker_2enumericW(v_t_2440));
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop(v_t_2441);
        V v_cell_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
        V v_u_2443 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2442));
        heff_drop(v_u_2443);
        V t_0 = v_xs_243;
        V t_1 = v_cell_2442;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        heff_drop_rec(v_x_242, 3);
        heff_drop(v_t_2441);
        V t_0 = v_xs_243;
        V t_1 = v_d_241;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2439);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1162912426x1278991032_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1162912426x1278991032_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f1217399696x462307458_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1217399696x462307458_24dps_entry, 4, 0};

V g_list_2emap_24f1217399696x462307458_24dps(V v_lit_240, V v_x1_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_list_2emap_24s231073986x752637537(v_lit_240, v_ys_242));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_241, 0);
    V v_xs_246 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_245), heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_246;
    V t_2 = v_ys_242;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1217399696x462307458_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f316845240x1272469554_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f316845240x1272469554_entry, 4, 0};

V g_list_2efoldl_24f316845240x1272469554(V v_lit_240, V v_z_241, V v_p_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_242), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_p_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_p_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_p_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_p_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f316845240x1272469554_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f316845240x1272469554(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f96178826x1085061806_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f96178826x1085061806_entry, 3, 0};

V g_list_2efoldl_24f96178826x1085061806(V v_z_240, V v_seen_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_seen_241));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), NTAG(TAG_MkUnit), v_seen_241));
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      V t_1 = v_t_246;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_seen_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f96178826x1085061806(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f106956753x832547985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f106956753x832547985_entry, 3, 0};

V g_list_2efoldl_24f106956753x832547985(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f106956753x832547985(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f139246788x401086883_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f139246788x401086883_entry, 2, 0};

V g_list_2efoldl_24f139246788x401086883(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      V t_0 = v_z_240;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_t_245 = (g_heff_2ebuild_2edriver_2eglueOne(v_z_240, heff_dup(v_x_244)));
      V t_0 = v_t_245;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f139246788x401086883_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f139246788x401086883(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f2056124927x822823214_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2056124927x822823214_entry, 3, 0};

V g_list_2emap_24f2056124927x822823214(V v_lit_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_242), heff_dup(v_a_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_244 = (g_std_2epath_2elower_2elow_240(heff_dup(v_lit_240), heff_dup(v_a_241)));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f2056124927x822823214_24dps(v_lit_240, heff_intAdd(v_a_241, MK_INT(1LL)), v_b_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_list_2emap_24f2056124927x822823214_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2056124927x822823214(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f2063070488x1806431062_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2063070488x1806431062_24dps_entry, 3, 0};

V g_list_2emap_24f2063070488x1806431062_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 2, 3), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f2063070488x1806431062_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2063070488x1806431062_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f378206553x1816388893_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f378206553x1816388893_24dps_entry, 5, 0};

V g_list_2emap_24f378206553x1816388893_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_245, 5);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      V v_t_2410;
      if (heff_intEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_240))) {
        V v_t_249 = heff_intAdd(heff_take_field(v_x_245, 3), heff_dup(v_lit_241));
        v_t_2410 = ({ V rv_3 = v_t_249; V rr_ = heff_rec_reuse_nf(v_x_245, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_2410 = v_x_245;
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f378206553x1816388893_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f378206553x1816388893_24dps(a[0], a[1], a[2], a[3], a[4]);
}