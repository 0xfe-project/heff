// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EDo 15964
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_ENest 28629
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_EWith 38507
#define TAG_EquationCovered 28162
#define TAG_F32 16337
#define TAG_Flagged 28540
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_Positional 16703
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Sig 30557
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_el 9998
#define LBL_end 310101
#define LBL_from 9647217
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_key 315609
#define LBL_long 9823043
#define LBL_members 1180739419
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_outer 307469461
#define LBL_param 307795111
#define LBL_params 951713969
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_self 10021907
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_supply 1056026650
#define LBL_used 10094724
#define LBL_witness 1587180415
#define LBL_x 338
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_key__outer__params__body[] = {LBL_key, LBL_outer, LBL_params, LBL_body};
static uint32_t shape_members__supply[] = {LBL_members, LBL_supply};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edriver_2ewithHiddenOne(V, V);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithHiddenOne_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24tok2(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2epatTags(V, V);
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTags_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s107933070x152985962(V, V, V, V, V);
V g_list_2eany_24s107933070x152985962_entry(V self, V *a);
extern Clo g_list_2eany_24s107933070x152985962_clo;
V g_list_2eany_24s767011289x1972536129(V);
V g_list_2eany_24s767011289x1972536129_entry(V self, V *a);
extern Clo g_list_2eany_24s767011289x1972536129_clo;
V g_list_2eascending_24s1547370222x166817322(V, V, V);
V g_list_2eascending_24s1547370222x166817322_entry(V self, V *a);
extern Clo g_list_2eascending_24s1547370222x166817322_clo;
V g_list_2ecollapse_24s929646560x1354573257(V, V);
V g_list_2ecollapse_24s929646560x1354573257_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s929646560x1354573257_clo;
V g_list_2edescending_24s1706700342x2062518382(V, V, V);
V g_list_2edescending_24s1706700342x2062518382_entry(V self, V *a);
extern Clo g_list_2edescending_24s1706700342x2062518382_clo;
HeffT2 g_list_2efind_24s1338461068x888657721_24cpr(V, V);
HeffT2 g_list_2efind_24s1498631415x1735266116_24cpr(V, V);
V g_list_2efoldl_24f1037112923x126964824(V, V, V, V, V);
V g_list_2efoldl_24f1037112923x126964824_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1037112923x126964824_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24f1257949983x1023832813(V, V);
V g_list_2efoldl_24f1257949983x1023832813_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1257949983x1023832813_clo;
V g_list_2efoldl_24f1365277776x1804683130(V, V);
V g_list_2efoldl_24f1365277776x1804683130_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1365277776x1804683130_clo;
V g_list_2efoldl_24f1563799791x267609364(V, V);
V g_list_2efoldl_24f1563799791x267609364_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1563799791x267609364_clo;
V g_list_2efoldl_24f511009896x1182531686(V, V);
V g_list_2efoldl_24f511009896x1182531686_entry(V self, V *a);
extern Clo g_list_2efoldl_24f511009896x1182531686_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1422286737x1936996242(V, V);
V g_list_2efoldl_24s1422286737x1936996242_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1422286737x1936996242_clo;
V g_list_2efoldl_24s1499934538x170225690(V, V);
V g_list_2efoldl_24s1499934538x170225690_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1499934538x170225690_clo;
V g_list_2efoldl_24s1722922134x788519507(V, V);
V g_list_2efoldl_24s1722922134x788519507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722922134x788519507_clo;
V g_list_2efoldl_24s1780676207x938087593(V, V);
V g_list_2efoldl_24s1780676207x938087593_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1780676207x938087593_clo;
V g_list_2efoldl_24s2118756600x1920057229_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s2118756600x1920057229_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_24scalars_clo;
V g_list_2efoldl_24s453100881x1701840665(V, V, V);
V g_list_2efoldl_24s453100881x1701840665_entry(V self, V *a);
extern Clo g_list_2efoldl_24s453100881x1701840665_clo;
V g_list_2efoldl_24s673493459x989016999(V, V, V);
V g_list_2efoldl_24s673493459x989016999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s673493459x989016999_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2ekeepIf_24s1063601026x1972672043_24dps(V, V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_24dps_clo;
V g_list_2ekeepIf_24s1552018029x993523539_24dps(V, V, V);
V g_list_2ekeepIf_24s1552018029x993523539_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_24dps_clo;
V g_list_2ekeepIf_24s708019417x1279437633(V, V);
V g_list_2ekeepIf_24s708019417x1279437633_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_clo;
V g_list_2ekeepIf_24s708019417x1279437633_24dps(V, V, V);
V g_list_2ekeepIf_24s708019417x1279437633_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_24dps_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap_24f1285463828x1893111862(V, V, V);
V g_list_2emap_24f1285463828x1893111862_entry(V self, V *a);
extern Clo g_list_2emap_24f1285463828x1893111862_clo;
V g_list_2emap_24f1285463828x1893111862_24dps(V, V, V, V);
V g_list_2emap_24f1285463828x1893111862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1285463828x1893111862_24dps_clo;
V g_list_2emap_24f1340051005x157438530(V, V, V, V);
V g_list_2emap_24f1340051005x157438530_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_clo;
V g_list_2emap_24f1340051005x157438530_24dps(V, V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24dps_clo;
V g_list_2emap_24f2041933216x1458595349_24dps(V, V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_24dps_clo;
V g_list_2emap_24f505181408x1813697659_24dps(V, V, V);
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_24dps_clo;
V g_list_2emap_24f783067987x1926181389(V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_clo;
V g_list_2emap_24f783067987x1926181389_24dps(V, V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_24dps_clo;
V g_list_2emap_24s1155474388x1593011685(V);
V g_list_2emap_24s1155474388x1593011685_entry(V self, V *a);
extern Clo g_list_2emap_24s1155474388x1593011685_clo;
V g_list_2emap_24s1155474388x1593011685_24dps(V, V);
V g_list_2emap_24s1155474388x1593011685_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1155474388x1593011685_24dps_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1243189782x897571843_24dps(V, V, V);
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_24dps_clo;
V g_list_2emap_24s1263350589x621576050_24dps(V, V);
V g_list_2emap_24s1263350589x621576050_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_24dps_clo;
V g_list_2emap_24s1386329375x1773300759_24dps(V, V);
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_24dps_clo;
V g_list_2emap_24s1387309293x1990579214(V);
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_clo;
V g_list_2emap_24s1387309293x1990579214_24dps(V, V);
V g_list_2emap_24s1387309293x1990579214_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_24dps_clo;
V g_list_2emap_24s1492759219x1917596721(V, V);
V g_list_2emap_24s1492759219x1917596721_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_clo;
V g_list_2emap_24s1492759219x1917596721_24dps(V, V, V);
V g_list_2emap_24s1492759219x1917596721_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_24dps_clo;
V g_list_2emap_24s170737852x2114895588_24dps(V, V, V, V);
V g_list_2emap_24s170737852x2114895588_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s170737852x2114895588_24dps_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1854779998x1713580578(V);
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_clo;
V g_list_2emap_24s1854779998x1713580578_24dps(V, V);
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_24dps_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s2098521682x1221164629_24dps(V, V);
V g_list_2emap_24s2098521682x1221164629_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2098521682x1221164629_24dps_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s319754340x1392149466_24dps(V, V, V, V, V);
V g_list_2emap_24s319754340x1392149466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_24dps_clo;
V g_list_2emap_24s34825065x1144190520_24dps(V, V);
V g_list_2emap_24s34825065x1144190520_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_24dps_clo;
V g_list_2emap_24s503834852x510769098_24dps(V, V, V);
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_24dps_clo;
V g_list_2emap_24s584558070x895760461(V, V);
V g_list_2emap_24s584558070x895760461_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_clo;
V g_list_2emap_24s584558070x895760461_24dps(V, V, V);
V g_list_2emap_24s584558070x895760461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_24dps_clo;
V g_list_2emap_24s70140105x1635164657(V);
V g_list_2emap_24s70140105x1635164657_entry(V self, V *a);
extern Clo g_list_2emap_24s70140105x1635164657_clo;
V g_list_2emap_24s70140105x1635164657_24dps(V, V);
V g_list_2emap_24s70140105x1635164657_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s70140105x1635164657_24dps_clo;
V g_list_2emap_24s942566919x1152393003_24dps(V, V, V);
V g_list_2emap_24s942566919x1152393003_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_24dps_clo;
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s825587185x1704110321_clo;
V g_list_2emergeRuns_24s1839386886x1884977030(V, V);
V g_list_2emergeRuns_24s1839386886x1884977030_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1839386886x1884977030_clo;
V g_list_2epushRun_24s1988589127x1984120882(V, V, V);
V g_list_2epushRun_24s1988589127x1984120882_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1988589127x1984120882_clo;
V g_list_2epushRun_24s2109226209x1912152293(V, V, V);
V g_list_2epushRun_24s2109226209x1912152293_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2109226209x1912152293_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2etake_24dps(V, V, V);
V g_list_2etake_24dps_entry(V self, V *a);
extern Clo g_list_2etake_24dps_clo;
V g_list_2ezipWith_24s1029292936x211450510_24dps(V, V, V);
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s2008157409x530425318(V, V, V);
V g_std_2eordmap_2einsert_24s2008157409x530425318_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s2008157409x530425318_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_list_2etake_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_entry, 2, 0};

V g_list_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2etake_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_entry(V self, V *a) {
  (void)self;
  return g_list_2etake(a[0], a[1]);
}
Clo g_list_2efoldl_24s1780676207x938087593_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1780676207x938087593_entry, 2, 0};

V g_list_2efoldl_24s1780676207x938087593(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2eordmap_2einsert_24s2008157409x530425318(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1780676207x938087593_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1780676207x938087593(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emergeRuns_24s1839386886x1884977030_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s1839386886x1884977030_entry, 2, 0};

V g_list_2emergeRuns_24s1839386886x1884977030(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s929646560x1354573257(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      V v_ru_24x32_243_24Cons = heff_take_reuse_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s1988589127x1984120882(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_2412;
      switch (heff_tag_of(v_xs_245)) {
      case TAG_Nil: {
        V v_t_247 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
        v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_248 = heff_field(v_xs_245, 0);
        V v_ys_249 = heff_field(v_xs_245, 1);
        V v_ru_24xs_245_24Cons = heff_take_reuse_n(v_xs_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
        if (heff_intLe_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(heff_rfield(v_y_248, 0)))) {
          V v_t_2410 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2412 = (g_list_2eascending_24s1547370222x166817322(heff_dup(v_y_248), heff_tag_re_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_248, v_t_2410}), v_ys_249));
        } else {
          V v_t_2411 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2412 = (g_list_2edescending_24s1706700342x2062518382(heff_dup(v_y_248), heff_tag_re_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_248, v_t_2411}), v_ys_249));
        }
        break;
      }
      default: heff_nomatch(v_xs_245);
      }
      V t_0 = v_t_246;
      V t_1 = v_t_2412;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s1839386886x1884977030_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s1839386886x1884977030(a[0], a[1]);
}
Clo g_list_2emap_24s34825065x1144190520_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s34825065x1144190520_24dps_entry, 2, 0};

V g_list_2emap_24s34825065x1144190520_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkSegment: {
        V v_ty_247 = heff_field(v_x11_244, 1);
        V v_size_248 = heff_field(v_x11_244, 2);
        heff_take_n(v_x11_244, 6ULL, 5);
        v_t_2411 = ({ V a_0 = v_ty_247; V a_1 = v_size_248; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_247); heff_drop(v_size_248); r_; });
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2412);
    V t_0 = v_xs_243;
    V t_1 = v_u_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s34825065x1144190520_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s34825065x1144190520_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s767011289x1972536129_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s767011289x1972536129_entry, 1, 0};

V g_list_2eany_24s767011289x1972536129(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x2_243 = heff_dup(v_x_241);
    V v_t_24106;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_StmtBind: {
        V v_e_248 = heff_field(v_x21_244, 2);
        heff_take_n(v_x21_244, 4ULL, 3);
        switch (heff_tag_of(v_e_248)) {
        case TAG_At: {
          V v_e1_249 = heff_dup(heff_field(v_e_248, 0));
          switch (heff_tag_of(v_e1_249)) {
          case TAG_ELam: {
            heff_take_n(v_e1_249, 0ULL, 2);
            switch (heff_tag_of(v_e_248)) {
            case TAG_At: {
              heff_take_n(v_e_248, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_248);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_e1_249, 0ULL, 1);
            switch (heff_tag_of(v_e_248)) {
            case TAG_At: {
              heff_take_n(v_e_248, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_248);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_e1_249, 0ULL, 1);
            switch (heff_tag_of(v_e_248)) {
            case TAG_At: {
              heff_take_n(v_e_248, 0ULL, 2);
              v_t_24106 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_248);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_e1_249, 0ULL, 1);
            switch (heff_tag_of(v_e_248)) {
            case TAG_At: {
              heff_take_n(v_e_248, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_248);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_e1_249, 0ULL, 1);
            switch (heff_tag_of(v_e_248)) {
            case TAG_At: {
              heff_take_n(v_e_248, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_248);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_e1_249, 0ULL, 4);
            switch (heff_tag_of(v_e_248)) {
            case TAG_At: {
              heff_take_n(v_e_248, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_248);
            }
            break;
          }
          default: {
            heff_drop(v_e1_249);
            HeffT2 v_t_2433 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_248));
            {
              V v_field_2434 = v_t_2433.f[0];
              V v_field_2435 = v_t_2433.f[1];
              V v_x_2436 = v_field_2434;
              V v_y_2437 = v_field_2435;
              heff_drop(v_y_2437);
              v_t_24106 = v_x_2436;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_248);
        }
        break;
      }
      case TAG_StmtLet: {
        V v_e_2439 = heff_field(v_x21_244, 1);
        heff_take_n(v_x21_244, 2ULL, 2);
        switch (heff_tag_of(v_e_2439)) {
        case TAG_At: {
          V v_e1_2440 = heff_dup(heff_field(v_e_2439, 0));
          switch (heff_tag_of(v_e1_2440)) {
          case TAG_ELam: {
            heff_take_n(v_e1_2440, 0ULL, 2);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              heff_take_n(v_e_2439, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_e1_2440, 0ULL, 1);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              heff_take_n(v_e_2439, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_e1_2440, 0ULL, 1);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              heff_take_n(v_e_2439, 0ULL, 2);
              v_t_24106 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_e1_2440, 0ULL, 1);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              heff_take_n(v_e_2439, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_e1_2440, 0ULL, 1);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              heff_take_n(v_e_2439, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_e1_2440, 0ULL, 4);
            switch (heff_tag_of(v_e_2439)) {
            case TAG_At: {
              heff_take_n(v_e_2439, 0ULL, 2);
              v_t_24106 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2439);
            }
            break;
          }
          default: {
            heff_drop(v_e1_2440);
            HeffT2 v_t_2464 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_2439));
            {
              V v_field_2465 = v_t_2464.f[0];
              V v_field_2466 = v_t_2464.f[1];
              V v_x_2467 = v_field_2465;
              V v_y_2468 = v_field_2466;
              heff_drop(v_y_2468);
              v_t_24106 = v_x_2467;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2439);
        }
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2469 = heff_field(v_x21_244, 0);
        heff_take_n(v_x21_244, 1ULL, 1);
        V v_t_2470 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2469));
        if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
          heff_drop(v_e_2469);
          heff_drop(v_t_2470);
          v_t_24106 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2470);
          switch (heff_tag_of(v_e_2469)) {
          case TAG_At: {
            V v_e1_2471 = heff_dup(heff_field(v_e_2469, 0));
            switch (heff_tag_of(v_e1_2471)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2471, 0ULL, 2);
              switch (heff_tag_of(v_e_2469)) {
              case TAG_At: {
                heff_take_n(v_e_2469, 0ULL, 2);
                v_t_24106 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2469);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_2471, 0ULL, 1);
              switch (heff_tag_of(v_e_2469)) {
              case TAG_At: {
                heff_take_n(v_e_2469, 0ULL, 2);
                v_t_24106 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2469);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_2471, 0ULL, 1);
              switch (heff_tag_of(v_e_2469)) {
              case TAG_At: {
                heff_take_n(v_e_2469, 0ULL, 2);
                v_t_24106 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2469);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_2471, 0ULL, 1);
              switch (heff_tag_of(v_e_2469)) {
              case TAG_At: {
                heff_take_n(v_e_2469, 0ULL, 2);
                v_t_24106 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2469);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_2471, 0ULL, 1);
              switch (heff_tag_of(v_e_2469)) {
              case TAG_At: {
                heff_take_n(v_e_2469, 0ULL, 2);
                v_t_24106 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2469);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_2471, 0ULL, 4);
              switch (heff_tag_of(v_e_2469)) {
              case TAG_At: {
                heff_take_n(v_e_2469, 0ULL, 2);
                v_t_24106 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2469);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2471);
              HeffT2 v_t_2495 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), v_e_2469));
              {
                V v_field_2496 = v_t_2495.f[0];
                V v_field_2497 = v_t_2495.f[1];
                V v_x_2498 = v_field_2496;
                V v_y_2499 = v_field_2497;
                heff_drop(v_y_2499);
                v_t_24106 = v_x_2498;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2469);
          }
        }
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_x21_244, 0ULL, 3);
        v_t_24106 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x21_244, 0ULL, 3);
        v_t_24106 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
      heff_drop(v_t_24106);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24106);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s767011289x1972536129_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s767011289x1972536129(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s942566919x1152393003_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s942566919x1152393003_24dps_entry, 3, 0};

V g_list_2emap_24s942566919x1152393003_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2eargOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s942566919x1152393003_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s942566919x1152393003_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1243189782x897571843_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1243189782x897571843_entry, 2, 0};

V g_list_2emap_24s1243189782x897571843(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1243189782x897571843_24dps(v_lit_240, v_xs_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1243189782x897571843(a[0], a[1]);
}
Clo g_list_2efoldl_24s1422286737x1936996242_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1422286737x1936996242_entry, 2, 0};

V g_list_2efoldl_24s1422286737x1936996242(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_249 = heff_dup(heff_field(v_a_246, 1));
          v_t_2410 = v_a_249;
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        V v_t_2411 = (g_heff_2esyntax_2esurface_2epatTags(v_a_246, v_z_240));
        v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1422286737x1936996242_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1422286737x1936996242(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1029292936x211450510_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_243, 0);
        heff_take_n(v_x_243, 1ULL, 2);
        v_t_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, v_y_245}), heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_2411;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s1029292936x211450510_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2067043448x720245267_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_entry, 1, 0};

V g_list_2emap_24s2067043448x720245267(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2067043448x720245267_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267(a[0]);
}
Clo g_list_2emap_24s1492759219x1917596721_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1492759219x1917596721_entry, 2, 0};

V g_list_2emap_24s1492759219x1917596721(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_lit_240; V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1492759219x1917596721_24dps(v_lit_240, v_xs_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1492759219x1917596721_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1492759219x1917596721(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1155474388x1593011685_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1155474388x1593011685_entry, 1, 0};

V g_list_2emap_24s1155474388x1593011685(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      V v_ru_24x_241_24MkArm = heff_take_reuse_n(v_x_241, 7ULL, 3);
      V v_t_246 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_a_245));
      v_t_247 = heff_tag_re_n(v_ru_24x_241_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_a_243, v_a_244, v_t_246});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1155474388x1593011685_24dps(v_xs_242, v_cell_248));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1155474388x1593011685_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1155474388x1593011685(a[0]);
}
Clo g_list_2ekeepIf_24s708019417x1279437633_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s708019417x1279437633_entry, 2, 0};

V g_list_2ekeepIf_24s708019417x1279437633(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_lit_240, v_t_246, 2)) {
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s708019417x1279437633_24dps(v_lit_240, v_xs_243, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s708019417x1279437633_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s708019417x1279437633(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1263350589x621576050_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1263350589x621576050_24dps_entry, 2, 0};

V g_list_2emap_24s1263350589x621576050_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_t_246 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24FtFixed = heff_take_reuse_n(v_x_242, 1ULL, 1);
      int64_t v_t_245;
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      if ((v_t_245 == ((int64_t)64ULL))) {
        v_t_246 = heff_tag_at_n(v_ru_24x_242_24FtFixed, TAG_RepFix, 1, (V[]){v_w_244});
      } else {
        heff_drop(v_w_244);
        heff_drop_cell(v_ru_24x_242_24FtFixed, 1);
        v_t_246 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_246 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_t_246 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1263350589x621576050_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1263350589x621576050_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s453100881x1701840665_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s453100881x1701840665_entry, 3, 0};

V g_list_2efoldl_24s453100881x1701840665(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_bodies_245 = heff_dup(v_lit_240);
    V v_acc_246 = v_z_241;
    V v_supply_247 = heff_take_field(v_acc_246, 1);
    V v_members_248 = heff_take_field(v_acc_246, 0);
    V v_k_249 = v_x_243;
    HeffT2 v_t_2410 = ({ V a_0 = v_bodies_245; V a_1 = v_k_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_245); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_b_2414;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2412;
        v_b_2414 = v_x_2413;
      } else {
        heff_drop(v_field_2412);
        v_b_2414 = NTAG(TAG_EAbandon);
      }
      V v_named_2415 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_std_2eordmap_2eempty_get()), v_supply_247, heff_dup(v_b_2414)));
      V v_k_2416 = v_k_249;
      V v_xs_2456;
      switch (heff_tag_of(v_b_2414)) {
      case TAG_EVar: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        V v_xs_2419 = heff_field(v_b_2414, 0);
        heff_take_n(v_b_2414, 1ULL, 2);
        v_xs_2456 = v_xs_2419;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_b_2414, 0ULL, 3);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_b_2414, 0ULL, 4);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_b_2414, 0ULL, 3);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_b_2414, 0ULL, 3);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_b_2414, 0ULL, 1);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_b_2414, 0ULL, 2);
        v_xs_2456 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_b_2414);
      }
      V v_x3_2457 = heff_dup(v_named_2415);
      V v_t_2462;
      switch (heff_tag_of(v_x3_2457)) {
      case TAG_MkPair: {
        V v_x31_2458 = heff_field(v_x3_2457, 0);
        heff_take_n(v_x3_2457, 1ULL, 2);
        switch (heff_tag_of(v_x31_2458)) {
        case TAG_ELam: {
          V v_ys_2460 = heff_field(v_x31_2458, 0);
          V v_b_2461 = heff_field(v_x31_2458, 1);
          heff_take_n(v_x31_2458, 3ULL, 2);
          v_t_2462 = heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_2416, v_xs_2456, v_ys_2460, v_b_2461});
          break;
        }
        default: {
          v_t_2462 = heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_2416, v_xs_2456, NTAG(TAG_Nil), v_x31_2458});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x3_2457);
      }
      V v_t_2465;
      switch (heff_tag_of(v_named_2415)) {
      case TAG_MkPair: {
        V v_n_2464 = heff_field(v_named_2415, 1);
        heff_take_n(v_named_2415, 2ULL, 2);
        v_t_2465 = v_n_2464;
        break;
      }
      default: heff_nomatch(v_named_2415);
      }
      V v_t_2466 = ({ V rv_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, v_members_248}); V rv_1 = v_t_2465; V rr_ = heff_rec_reuse_nf(v_acc_246, 0ULL, 2, shape_members__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      V t_0 = v_lit_240;
      V t_1 = v_t_2466;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s453100881x1701840665_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s453100881x1701840665(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s170737852x2114895588_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s170737852x2114895588_24dps_entry, 4, 0};

V g_list_2emap_24s170737852x2114895588_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 6);
    V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_248 = heff_get_n(heff_get_n(v_x_244, 0, 3), 1, 6);
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_lit_240)), v_t_248);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_lit_241)), heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s170737852x2114895588_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24s170737852x2114895588_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24s1729297000x968708966_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_24dps_entry, 2, 0};

V g_list_2emap_24s1729297000x968708966_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_el_245 = heff_get_n(v_x_242, 2, 5);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_244, v_el_245}), heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1729297000x968708966_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s70140105x1635164657_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s70140105x1635164657_entry, 1, 0};

V g_list_2emap_24s70140105x1635164657(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_249 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_249}), heff_hole()});
    V v_u_2411 = (g_list_2emap_24s70140105x1635164657_24dps(v_xs_242, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s70140105x1635164657_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s70140105x1635164657(a[0]);
}

HeffT2 g_list_2efind_24s1498631415x1735266116_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1499934538x170225690_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1499934538x170225690_entry, 2, 0};

V g_list_2efoldl_24s1499934538x170225690(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1499934538x170225690_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1499934538x170225690(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2118756600x1920057229_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2118756600x1920057229_24scalars_entry, 6, 0};

V g_list_2efoldl_24s2118756600x1920057229_24scalars(V v_gs_240, V v_names_241, V v_used_242, V v_self_243, V v_inl_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nil: {
    return heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, v_names_241, v_used_242, v_self_243, v_inl_244});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_245, 0);
    V v_xs_247 = heff_field(v_x3_245, 1);
    V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_used_242, heff_dup(v_x_246), NTAG(TAG_MkUnit)));
    V t_0 = v_gs_240;
    V t_1 = v_names_241;
    V t_2 = v_t_248;
    V t_3 = v_self_243;
    V t_4 = v_inl_244;
    V t_5 = v_xs_247;
    v_gs_240 = t_0;
    v_names_241 = t_1;
    v_used_242 = t_2;
    v_self_243 = t_3;
    v_inl_244 = t_4;
    v_x3_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_list_2efoldl_24s2118756600x1920057229_24scalars_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_list_2efoldl_24s2118756600x1920057229_24scalars(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_list_2emap_24s319754340x1392149466_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s319754340x1392149466_24dps_entry, 5, 0};

V g_list_2emap_24s319754340x1392149466_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 3ULL, 2);
      if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_a_247, v_lit_241, v_lit_242, 1))) {
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_a_248});
      } else {
        heff_drop(v_a_248);
        v_t_249 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s319754340x1392149466_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2emap_24s319754340x1392149466_24dps(a[0], a1, a2, a[3], a4); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24s503834852x510769098_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503834852x510769098_24dps_entry, 3, 0};

V g_list_2emap_24s503834852x510769098_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_243; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s503834852x510769098_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s503834852x510769098_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1552018029x993523539_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1552018029x993523539_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1552018029x993523539_24dps(V v_box_24lit_240, V v_x2_241, V v_d_242) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((v_lit_240 < heff_unbox_word(heff_strLength_lent(v_x_243, 0)))) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      int64_t t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      int64_t t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1552018029x993523539_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ekeepIf_24s1552018029x993523539_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eany_24s107933070x152985962_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s107933070x152985962_entry, 5, 0};

V g_list_2eany_24s107933070x152985962(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_a_247 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), heff_dup(v_x_245)), heff_dup(v_lit_241));
    V v_t_248 = heff_strSlice_lent(v_lit_242, v_lit_243, heff_strLength_lent(v_a_247, 0), 4);
    if (heff_strEq_c(v_t_248, v_a_247)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2eany_24s107933070x152985962_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2eany_24s107933070x152985962(a[0], a[1], a2, a3, a4); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str0, 1, "V");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str1, 6, "double");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_24dps_str2, 7, "int64_t");
Clo g_list_2emap_24s1386329375x1773300759_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386329375x1773300759_24dps_entry, 2, 0};

V g_list_2emap_24s1386329375x1773300759_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_245 = ({ V a_0 = v_w_244; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_244); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str1);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = ((V)&g_list_2emap_24s1386329375x1773300759_24dps_str2);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1386329375x1773300759_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emap_24s584558070x895760461_lam0(V self, V *args);
Clo g_list_2emap_24s584558070x895760461_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584558070x895760461_entry, 2, 0};

V g_list_2emap_24s584558070x895760461(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x_245 = heff_take_field(v_r_244, 0);
    V v_chk_246 = heff_get_n(v_r_244, 3, 5);
    V v_x2_247 = v_x_242;
    V v_t_2418;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_At: {
      V v_x21_248 = heff_field(v_x2_247, 0);
      V v_sp_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24At = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      switch (heff_tag_of(v_x21_248)) {
      case TAG_MkEquation: {
        V v_f_2410 = heff_field(v_x21_248, 0);
        V v_fsp_2411 = heff_field(v_x21_248, 1);
        V v_ps_2412 = heff_field(v_x21_248, 2);
        V v_rhs_2413 = heff_field(v_x21_248, 3);
        V v_ru_24x21_248_24MkEquation = heff_take_reuse_n(v_x21_248, 15ULL, 4);
        V v_t_2416 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_list_2emap_24s584558070x895760461_lam0, 1, 1, (V[]){v_x_245}), v_ps_2412));
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_chk_246);
          heff_drop(v_t_2416);
          v_t_2418 = heff_tag_re_n(v_ru_24x2_247_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_248_24MkEquation, TAG_MkEquation, 4, 15ULL, (V[]){v_f_2410, v_fsp_2411, v_ps_2412, v_rhs_2413}), v_sp_249});
        } else {
          heff_drop(v_t_2416);
          V v_t_2417 = heff_tr(heff_call(v_chk_246, 1, (V[]){v_rhs_2413}));
          v_t_2418 = heff_tag_re_n(v_ru_24x2_247_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_248_24MkEquation, TAG_MkEquation, 4, 7ULL, (V[]){v_f_2410, v_fsp_2411, v_ps_2412, v_t_2417}), v_sp_249});
        }
        break;
      }
      default: heff_nomatch(v_x21_248);
      }
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s584558070x895760461_24dps(v_lit_240, v_xs_243, v_cell_2419));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s584558070x895760461_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584558070x895760461(a[0], a[1]);
}
V g_list_2emap_24s584558070x895760461_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_xs_2415 = (g_heff_2eelab_2eclauses_2epatBinds(v_p_2414));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_245; V a_1 = v_xs_2415; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_245); heff_drop(v_xs_2415); r_; });
}
Clo g_list_2emap_24s2098521682x1221164629_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2098521682x1221164629_24dps_entry, 2, 0};

V g_list_2emap_24s2098521682x1221164629_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EquationCovered, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2098521682x1221164629_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2098521682x1221164629_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1722922134x788519507_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1722922134x788519507_entry, 2, 0};

V g_list_2efoldl_24s1722922134x788519507(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ewithHiddenOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1722922134x788519507_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1722922134x788519507(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str9, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str10, 0, "");
Clo g_list_2emap_24s218655275x981659442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_entry, 1, 0};

V g_list_2emap_24s218655275x981659442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2416 = v_s_2410;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str8);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str9);
      break;
    }
    case TAG_VErased: {
      v_t_2416 = ((V)&g_list_2emap_24s218655275x981659442_str10);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s218655275x981659442_24dps(v_xs_242, v_cell_2417));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442(a[0]);
}
Clo g_list_2epushRun_24s2109226209x1912152293_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s2109226209x1912152293_entry, 3, 0};

V g_list_2epushRun_24s2109226209x1912152293(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_2411;
        switch (heff_tag_of(v_below_246)) {
        case TAG_Nil: {
          v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_True), v_below_246, v_run_241));
          break;
        }
        case TAG_Cons: {
          V v_a_247 = heff_dup(heff_field(v_below_246, 0));
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nil: {
            heff_drop_rec(v_a_247, 2);
            v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_True), v_below_246, v_run_241));
            break;
          }
          case TAG_Cons: {
            V v_b_249 = heff_dup(heff_field(v_run_241, 0));
            if (heff_intLe_c(heff_get_n(v_a_247, 0, 2), heff_get_n(v_b_249, 0, 2))) {
              v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_True), v_below_246, v_run_241));
            } else {
              v_t_2411 = (g_list_2emerge_2emergeFrom_240_24s825587185x1704110321(NTAG(TAG_False), v_run_241, v_below_246));
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          break;
        }
        default: heff_nomatch(v_below_246);
        }
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_2411;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_2412 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_2412});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s2109226209x1912152293_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s2109226209x1912152293(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s673493459x989016999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s673493459x989016999_entry, 3, 0};

V g_list_2efoldl_24s673493459x989016999(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2equery_2edocMdStep(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s673493459x989016999_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s673493459x989016999(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1063601026x1972672043_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1063601026x1972672043_entry, 2, 0};

V g_list_2ekeepIf_24s1063601026x1972672043(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - heff_unbox_word(heff_strLength_lent(v_lit_240, 0)));
    V v_t_245 = heff_strSlice_lent(v_x_242, heff_box_word(v_t_244), heff_strLength_lent(v_x_242, 0), 6);
    if (heff_strEq_c_lent(v_t_245, v_lit_240, 1)) {
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s1063601026x1972672043_24dps(v_lit_240, v_xs_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1063601026x1972672043(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s1338461068x888657721_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    V v_a_247 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    if ((heff_intEq_c_lent(v_start_245, v_start_248, 0) && heff_intEq_c_lent(v_end_246, v_end_249, 0))) {
      heff_drop_rec(v_lit_240, 5);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s1387309293x1990579214_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1387309293x1990579214_entry, 1, 0};

V g_list_2emap_24s1387309293x1990579214(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1387309293x1990579214_24dps(v_xs_242, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1387309293x1990579214(a[0]);
}
Clo g_list_2emap_24s1854779998x1713580578_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1854779998x1713580578_entry, 1, 0};

V g_list_2emap_24s1854779998x1713580578(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 8), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1854779998x1713580578_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1854779998x1713580578(a[0]);
}
Clo g_list_2emap_24f2041933216x1458595349_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2041933216x1458595349_24dps_entry, 6, 0};

V g_list_2emap_24f2041933216x1458595349_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    HeffT2 v_t_248 = ({ V a_0 = v_x_246; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(a_0)); heff_drop(v_x_246); r_; });
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_t_2411 = heff_tag_n(TAG_Sig, 5, (V[]){heff_dup(v_lit_240), v_field_249, v_field_2410, heff_dup(v_lit_241), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_lit_242), heff_dup(v_lit_243)})});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_247;
      V t_5 = v_u_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f2041933216x1458595349_24dps_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_list_2emap_24f2041933216x1458595349_24dps(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_list_2efoldl_24f1365277776x1804683130_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1365277776x1804683130_entry, 2, 0};

V g_list_2efoldl_24f1365277776x1804683130(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_CondTrue: {
    return v_z_240;
  }
  case TAG_CondFalse: {
    return v_z_240;
  }
  case TAG_CondRel: {
    V v_es_243 = heff_field(v_x1_241, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, heff_dup(v_es_243));
  }
  case TAG_CondRelU: {
    V v_es_245 = heff_field(v_x1_241, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, heff_dup(v_es_245));
  }
  case TAG_CondBool: {
    V v_e_246 = heff_field(v_x1_241, 0);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_246), v_z_240}), NTAG(TAG_Nil));
  }
  case TAG_CondNot: {
    V v_c_247 = heff_field(v_x1_241, 0);
    V t_0 = v_z_240;
    V t_1 = v_c_247;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_248 = heff_field(v_x1_241, 0);
    V v_b_249 = heff_field(v_x1_241, 1);
    V v_c_2410 = heff_field(v_x1_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eowned_2econdKids(v_a_248));
    V v_t_2412 = (g_heff_2ecompile_2eowned_2econdKids(v_b_249));
    V v_t_2413 = (g_heff_2ecompile_2eowned_2econdKids(v_c_2410));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2414));
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(v_z_240, v_t_2415);
  }
  case TAG_CondLet: {
    V v_e_2417 = heff_field(v_x1_241, 1);
    V v_c_2418 = heff_field(v_x1_241, 2);
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2417), v_z_240});
    V t_1 = v_c_2418;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1365277776x1804683130_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1365277776x1804683130(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f511009896x1182531686_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f511009896x1182531686_entry, 2, 0};

V g_list_2efoldl_24f511009896x1182531686(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_x_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f511009896x1182531686_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f511009896x1182531686(a[0], a[1]);
}
Clo g_list_2emap_24f783067987x1926181389_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f783067987x1926181389_entry, 5, 0};

V g_list_2emap_24f783067987x1926181389(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244) {
top: ;
  if (heff_intLt_c_lent(v_b_244, v_a_243, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return NTAG(TAG_Nil);
  } else {
    V v_t_245 = heff_intSub_lent(heff_intSub_lent(v_lit_240, v_lit_241, 0), v_a_243, 1);
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd_lent(v_t_245, v_lit_242, 1), heff_hole()});
    V v_u_247 = (g_list_2emap_24f783067987x1926181389_24dps(v_lit_240, v_lit_241, v_lit_242, heff_box_word((heff_unbox_word(v_a_243) + ((int64_t)1ULL))), v_b_244, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
}
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f783067987x1926181389(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f505181408x1813697659_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f505181408x1813697659_24dps_entry, 3, 0};

V g_list_2emap_24f505181408x1813697659_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      V v_t_245 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24x2_241_24Cons, v_xs_244));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_243}), heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_u_247;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24f505181408x1813697659_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f96178826x1085061806_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f96178826x1085061806_entry, 3, 0};

V g_list_2efoldl_24f96178826x1085061806(V v_z_240, V v_seen_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_z_240;
        V t_1 = v_seen_241;
        V t_2 = v_xs_244;
        v_z_240 = t_0;
        v_seen_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, heff_dup(v_x_243), NTAG(TAG_MkUnit)));
        V t_0 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_z_240});
        V t_1 = v_t_249;
        V t_2 = v_xs_244;
        v_z_240 = t_0;
        v_seen_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f96178826x1085061806(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1257949983x1023832813_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1257949983x1023832813_entry, 2, 0};

V g_list_2efoldl_24f1257949983x1023832813(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V t_0 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, v_z_240});
    V t_1 = v_t_244;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1257949983x1023832813_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1257949983x1023832813(a[0], a[1]);
}
Clo g_list_2efoldl_24f106956753x832547985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f106956753x832547985_entry, 3, 0};

V g_list_2efoldl_24f106956753x832547985(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f106956753x832547985(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1037112923x126964824_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1037112923x126964824_entry, 5, 0};

V g_list_2efoldl_24f1037112923x126964824(V v_lit_240, V v_z_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_242, 4);
    heff_drop_rec(v_lit_243, 2);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_path_247 = heff_dup(heff_rfield(v_x_245, 0));
    V v_span_248 = heff_dup(heff_rfield(v_x_245, 2));
    if ((heff_strEq_c(heff_dup(v_path_247), heff_dup(heff_rfield(v_lit_242, 0))) && heff_intLt_c(heff_dup(heff_rfield(v_span_248, 0)), heff_dup(heff_rfield(v_lit_243, 0))))) {
      heff_drop(v_path_247);
      heff_drop_rec(v_span_248, 2);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    } else {
      heff_drop(v_path_247);
      heff_drop_rec(v_span_248, 2);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1037112923x126964824_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24f1037112923x126964824(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2emap_24f1340051005x157438530_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1340051005x157438530_entry, 4, 0};

V g_list_2emap_24f1340051005x157438530(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strSlice_lent(v_x_244, v_lit_241, heff_strLength_lent(v_lit_242, 0), 4);
    if (heff_strEq_c_lent(v_t_246, v_lit_242, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_244, heff_dup(v_lit_240)), heff_hole()});
      V v_u_248 = (g_list_2emap_24f1340051005x157438530_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1340051005x157438530_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1340051005x157438530(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1563799791x267609364_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1563799791x267609364_entry, 2, 0};

V g_list_2efoldl_24f1563799791x267609364(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 0));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Positional: {
      heff_take_n(v_t_244, 0ULL, 1);
      V t_0 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, v_z_240});
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Flagged: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1563799791x267609364_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1563799791x267609364(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24f1285463828x1893111862_str0, 26, "abcdefghijklmnopqrstuvwxyz");
HEFF_LIT(g_list_2emap_24f1285463828x1893111862_str1, 1, "_");
Clo g_list_2emap_24f1285463828x1893111862_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1285463828x1893111862_entry, 3, 0};

V g_list_2emap_24f1285463828x1893111862(V v_lit_240, V v_i_241, V v_n_242) {
top: ;
  if ((heff_peek_word(v_n_242) <= heff_peek_word(v_i_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nil);
  } else {
    V v_s_243 = heff_dup(v_lit_240);
    V v_i_244 = heff_dup(v_i_241);
    V v_t_248;
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) <= ((int64_t)90ULL)))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) - ((int64_t)65ULL));
      int64_t v_t_246 = (heff_unbox_word(heff_strByteAt(v_s_243, v_i_244)) - ((int64_t)64ULL));
      v_t_248 = heff_strSlice(((V)&g_list_2emap_24f1285463828x1893111862_str0), heff_box_word(v_t_245), heff_box_word(v_t_246));
    } else {
      V v_c_247 = heff_strByteAt_lent(v_s_243, v_i_244, 0);
      if ((((((int64_t)97ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)122ULL))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_247) == ((int64_t)95ULL))))) {
        heff_drop(v_c_247);
        v_t_248 = heff_strSlice(v_s_243, heff_dup(v_i_244), heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))));
      } else {
        heff_drop(v_s_243);
        heff_drop(v_i_244);
        heff_drop(v_c_247);
        v_t_248 = ((V)&g_list_2emap_24f1285463828x1893111862_str1);
      }
    }
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24f1285463828x1893111862_24dps(v_lit_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), v_n_242, v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
}
V g_list_2emap_24f1285463828x1893111862_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1285463828x1893111862(a[0], a[1], a[2]);
}