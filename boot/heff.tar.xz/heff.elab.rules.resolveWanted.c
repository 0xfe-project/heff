// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_Nom 25944
#define TAG_Trace 9637
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_depth 296830685
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_ret 322331
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_text 10052084
#define LBL_val 326043
#define LBL_wantedBy 1134124532
#define LBL_witness 1587180415
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_name__goal[] = {LBL_name, LBL_goal};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
V g_heff_2eelab_2erules_2echeckSettings(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckSettings_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSettings_clo;
V g_heff_2eelab_2erules_2ecommitted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecommitted_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V, V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2emetaOf(V);
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOf_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2especializations(V, V);
V g_heff_2eelab_2evalue_2especializations_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especializations_clo;
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str1, 7, "wanted ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str2, 6, "  [by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str3, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str4, 1, "]");
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam2, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam9, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_entry, 11, 0};

V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_x_245, V v_search_246, V v_final_247, V v_one_248, V v_hd_249, V v_k_2410) {
top: ;
  V v_depth_2411 = heff_take_field(v_search_246, 0);
  V v_wantedBy_2412 = heff_get_n(v_search_246, 1, 2);
  return (g_heff_2eelab_2erules_2ecommitted(heff_dup(v_e_240), heff_dup(v_sp_241), v_hm_242, v_holeVal_243, heff_dup(v_goal_244), heff_dup(v_one_248), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam0, 1, 10, (V[]){v_sp_241, v_e_240, v_one_248, heff_dup(v_x_245), v_goal_244, v_wantedBy_2412, v_depth_2411, v_final_247, v_hd_249, v_k_2410})));
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8], a[9], a[10]); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam2(V self, V *args) {
  V v_c_2421 = args[0];
  return heff_get_n(v_c_2421, 3, 9);
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam4(V self, V *args) {
  V v_u_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_goal_2419 = heff_env(self)[2];
  V v_one_248 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_goal_244 = heff_env(self)[5];
  heff_drop(v_u_2426);
  heff_clo_take(self, 6);
  V v_t_2427 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_2425; V a_2 = v_goal_2419; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2425); r_; });
  V v_t_2428 = heff_get_n(heff_get_n(v_one_248, 0, 3), 0, 6);
  V v_t_2429 = heff_tr(heff_call(v_t_2428, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430 = ({ V a_0 = v_e_240; V a_1 = v_x_245; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_245); r_; });
  V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str1), v_t_2427), ((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str2));
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, v_t_2429), ((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str3));
  return heff_strAppend(heff_strAppend(v_t_2432, v_t_2430), ((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str4));
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam7(V self, V *args) {
  V v_b_2442 = args[0];
  V v_one_248 = heff_env(self)[0];
  V v_hole_2420 = heff_env(self)[1];
  V v_goal_244 = heff_env(self)[2];
  V v_wantedBy_2412 = heff_env(self)[3];
  V v_depth_2411 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_goal_2419 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2443 = heff_get_n(heff_get_n(v_one_248, 0, 3), 0, 6);
  V v_t_2444 = heff_tr(heff_call(v_t_2443, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_hole_2420, 0)));
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_2444, v_goal_244}), v_wantedBy_2412});
  V v_t_2447 = heff_rec_n(2, shape_depth__wantedBy, (V[]){heff_intAdd(v_depth_2411, MK_INT(1LL)), v_t_2446});
  V v_c_2448 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){v_e_240, v_sp_241, v_t_2447, v_t_2445, heff_get_n(v_hole_2420, 1, 2), v_goal_2419, v_b_2442}));
  V f_ = v_c_2448;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_get_n(v_hd_2417, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_one_248 = heff_env(self)[2];
  V v_hole_2420 = heff_env(self)[3];
  V v_goal_244 = heff_env(self)[4];
  V v_wantedBy_2412 = heff_env(self)[5];
  V v_depth_2411 = heff_env(self)[6];
  V v_e_240 = heff_env(self)[7];
  V v_goal_2419 = heff_env(self)[8];
  V v_hd_2417 = heff_env(self)[9];
  if ((heff_dup(v_x_2441) == NTAG(TAG_True))) {
    heff_drop(v_x_2441);
    heff_clo_take(self, 10);
    heff_drop(v_sp_241);
    heff_drop_rec(v_one_248, 3);
    heff_drop_rec(v_hole_2420, 2);
    heff_drop(v_goal_244);
    heff_drop(v_wantedBy_2412);
    heff_drop(v_depth_2411);
    heff_drop(v_e_240);
    heff_drop(v_goal_2419);
    heff_drop_rec(v_hd_2417, 3);
    V f_ = v_k_2418;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2441);
    heff_clo_take(self, 10);
    V v_t_2449 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam7, 1, 9, (V[]){v_one_248, v_hole_2420, v_goal_244, v_wantedBy_2412, v_depth_2411, v_e_240, v_sp_241, v_goal_2419, heff_dup(v_hd_2417)}), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2450}));
    V f_ = heff_get_n(v_hd_2417, 1, 3);
    heff_room[0] = v_t_2451;
    heff_room[1] = v_k_2418;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_one_248 = heff_env(self)[0];
  V v_hole_2420 = heff_env(self)[1];
  V v_goal_244 = heff_env(self)[2];
  V v_wantedBy_2412 = heff_env(self)[3];
  V v_depth_2411 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_goal_2419 = heff_env(self)[7];
  V v_final_247 = heff_env(self)[8];
  V v_hd_2417 = heff_env(self)[9];
  V v_k_2418 = heff_env(self)[10];
  heff_drop(v_x_2435);
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_one_248, 0)), 0, 6);
  V v_t_2437 = heff_tr(heff_call(v_t_2436, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2438 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_hole_2420, 0)));
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_2437, heff_dup(v_goal_244)}), heff_dup(v_wantedBy_2412)});
  V v_t_2440 = heff_rec_n(2, shape_depth__wantedBy, (V[]){heff_intAdd_lent(v_depth_2411, MK_INT(1LL), 2), v_t_2439});
  heff_clo_take(self, 11);
  return (g_heff_2eelab_2erules_2eresolveWanted(heff_dup(v_e_240), heff_dup(v_sp_241), v_t_2440, v_t_2438, heff_dup(heff_rfield(v_hole_2420, 1)), heff_dup(v_goal_2419), v_final_247, heff_dup(v_hd_2417), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam6, 1, 10, (V[]){v_k_2418, v_sp_241, v_one_248, v_hole_2420, v_goal_244, v_wantedBy_2412, v_depth_2411, v_e_240, v_goal_2419, v_hd_2417})));
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_2419 = heff_env(self)[2];
  V v_one_248 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_goal_244 = heff_env(self)[5];
  V v_hd_2417 = heff_env(self)[6];
  V v_hole_2420 = heff_env(self)[7];
  V v_wantedBy_2412 = heff_env(self)[8];
  V v_depth_2411 = heff_env(self)[9];
  V v_final_247 = heff_env(self)[10];
  V v_k_2418 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2433 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_str0), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam4, 1, 6, (V[]){heff_dup(v_e_240), v_x_2425, heff_dup(v_goal_2419), heff_dup(v_one_248), v_x_245, heff_dup(v_goal_244)})}), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
  V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
  heff_room[0] = v_t_2434;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam5, 1, 11, (V[]){v_one_248, v_hole_2420, v_goal_244, v_wantedBy_2412, v_depth_2411, v_e_240, v_sp_241, v_goal_2419, v_final_247, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam1(V self, V *args) {
  V v_sg_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_248 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_goal_244 = heff_env(self)[4];
  V v_wantedBy_2412 = heff_env(self)[5];
  V v_depth_2411 = heff_env(self)[6];
  V v_final_247 = heff_env(self)[7];
  V v_goal_2419 = heff_take_field(v_sg_2416, 1);
  V v_hole_2420 = heff_get_n(v_sg_2416, 0, 2);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam2_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2423}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
  args[0] = v_t_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam3, 1, 12, (V[]){v_sp_241, v_e_240, v_goal_2419, v_one_248, v_x_245, v_goal_244, v_hd_2417, v_hole_2420, v_wantedBy_2412, v_depth_2411, v_final_247, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam9(V self, V *args) {
  V v_c_2453 = args[0];
  return heff_get_n(v_c_2453, 3, 9);
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam11(V self, V *args) {
  V v_x_2484 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_drop(v_x_2484);
  heff_clo_take(self, 1);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_applied_2415 = heff_env(self)[0];
  V v_goal_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_one_248 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2458 = heff_tr(heff_call(heff_get_n(v_applied_2415, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2462;
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_t_2462 = v_x_2459;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    v_t_2462 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_t_2462 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_x1_2458);
  }
  V v_t_2463 = ({ V a_0 = v_x_2457; V a_1 = heff_dup(v_goal_244); V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_x_2457); r_; });
  V v_t_2483;
  switch (heff_tag_of(v_t_2463)) {
  case TAG_VU: {
    heff_take_n(v_t_2463, 0ULL, 1);
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VDecode: {
    V v_sp_2466 = heff_field(v_t_2463, 1);
    heff_take_n(v_t_2463, 2ULL, 5);
    v_t_2483 = ({ V a_0 = v_sp_2466; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2eelab_2evalue_2especializations(a_0, a_1)); heff_drop(v_sp_2466); r_; });
    break;
  }
  case TAG_VFunction: {
    heff_take_n(v_t_2463, 0ULL, 6);
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_t_2463, 0ULL, 4);
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_t_2463, 0ULL, 1);
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimString: {
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_t_2463, 0ULL, 1);
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_t_2463, 0ULL, 1);
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_2463);
  }
  return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = heff_get_n(v_one_248, 0, 3); V a_3 = v_goal_244; V a_4 = v_t_2462; V a_5 = v_t_2483; V a_6 = v_hd_249; V a_7 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam11, 1, 1, (V[]){v_k_2410}); V r_ = (g_heff_2eelab_2erules_2echeckSettings(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2483); r_; });
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam8(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_applied_2415 = heff_env(self)[1];
  V v_goal_244 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_one_248 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_drop(v_x_2452);
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam9_clo)})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2455}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  heff_room[0] = v_t_2456;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam10, 1, 7, (V[]){v_applied_2415, v_goal_244, v_e_240, v_sp_241, v_one_248, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_248 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_goal_244 = heff_env(self)[4];
  V v_wantedBy_2412 = heff_env(self)[5];
  V v_depth_2411 = heff_env(self)[6];
  V v_final_247 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  V v_k_2410 = heff_env(self)[9];
  V v_subgoals_2414 = heff_take_field(v_x_2413, 2);
  V v_applied_2415 = heff_get_n(v_x_2413, 0, 3);
  heff_clo_take(self, 10);
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam1, 3, 8, (V[]){heff_dup(v_sp_241), heff_dup(v_e_240), heff_dup(v_one_248), v_x_245, heff_dup(v_goal_244), v_wantedBy_2412, v_depth_2411, v_final_247}); V a_1 = v_subgoals_2414; V a_2 = heff_dup(v_hd_249); V a_3 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_2etaken_24l0_lam8, 1, 7, (V[]){v_hd_249, v_applied_2415, v_goal_244, v_e_240, v_sp_241, v_one_248, v_k_2410}); V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, a_1, a_2, a_3)); heff_drop(v_subgoals_2414); r_; });
}