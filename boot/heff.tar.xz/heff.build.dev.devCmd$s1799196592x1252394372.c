// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_builds 569118448
#define LBL_dev 308879
#define LBL_stamp 311115741
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted[] = {LBL_builds, LBL_wanted};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087(V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087_clo;
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str1, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str3, 1, "\012");
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(V v_hd_240, V v_k_241, V v_clock_242, V v_wanted_243, V v_ex_244, V v_cu_245, V v_x_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s535099379x685970669(v_t_2413, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam1, 1, 7, (V[]){v_x_246, v_hd_240, v_k_241, v_clock_242, v_wanted_243, v_ex_244, v_cu_245})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_clock_242 = heff_env(self)[0];
  V v_ex_244 = heff_env(self)[1];
  V v_cu_245 = heff_env(self)[2];
  V v_st_2415 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  V v_dev_2438 = heff_take_field(v_x_2437, 0);
  V v_stamp_2439 = heff_take_field(v_x_2437, 2);
  V v_apps_2440 = heff_get_n(v_x_2437, 1, 3);
  heff_clo_take(self, 6);
  return ({ V a_0 = v_clock_242; V a_1 = v_ex_244; V a_2 = v_cu_245; V a_3 = v_st_2415; V a_4 = v_dev_2438; V a_5 = v_stamp_2439; V a_6 = v_apps_2440; V a_7 = v_hd_240; V a_8 = v_k_241; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_stamp_2439); heff_drop(v_k_241); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_clock_242 = heff_env(self)[0];
  V v_st_2415 = heff_env(self)[1];
  V v_wanted_243 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  V v_ex_244 = heff_env(self)[5];
  V v_cu_245 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Nothing: {
    heff_clo_take(self, 8);
    V v_t_2436 = ({ V a_0 = heff_dup(v_clock_242); V a_1 = heff_dup(v_st_2415); V a_2 = heff_rec_n(2, shape_builds__wanted, (V[]){MK_INT(0LL), v_wanted_243}); V a_3 = v_x_2434; V a_4 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1958097834x924889884(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2434); r_; });
    V f_ = v_t_2436;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam5, 1, 6, (V[]){v_clock_242, v_ex_244, v_cu_245, v_st_2415, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_apps_2441 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    heff_clo_take(self, 8);
    return ({ V a_0 = v_clock_242; V a_1 = v_ex_244; V a_2 = v_cu_245; V a_3 = v_st_2415; V a_4 = heff_rec_n(2, shape_builds__wanted, (V[]){MK_INT(1LL), v_wanted_243}); V a_5 = v_x_2434; V a_6 = v_apps_2441; V a_7 = v_hd_240; V a_8 = v_k_241; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1281822031x1208058407(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2434); heff_drop(v_k_241); r_; });
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_clock_242 = heff_env(self)[2];
  V v_wanted_243 = heff_env(self)[3];
  V v_ex_244 = heff_env(self)[4];
  V v_cu_245 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  V v_x_2434;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Nil: {
    v_x_2434 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x_2431, 0);
    V v_xs_2433 = heff_field(v_x_2431, 1);
    heff_take_n(v_x_2431, 3ULL, 2);
    v_x_2434 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str3); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2edev_2erebuilt_24s490076464x1374527087(heff_dup(v_st_2415), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam4, 1, 8, (V[]){v_clock_242, v_st_2415, v_wanted_243, v_x_2434, v_hd_240, v_ex_244, v_cu_245, v_k_241})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_clock_242 = heff_env(self)[3];
  V v_wanted_243 = heff_env(self)[4];
  V v_ex_244 = heff_env(self)[5];
  V v_cu_245 = heff_env(self)[6];
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    V v_ru_24x_246_24Left = heff_take_reuse_n(v_x_246, 0ULL, 1);
    heff_drop(v_clock_242);
    heff_drop(v_wanted_243);
    heff_drop(v_ex_244);
    heff_drop(v_cu_245);
    heff_drop(v_st_2415);
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_str1), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_ru_24x_246_24Right = heff_take_reuse_n(v_x_246, 0ULL, 1);
    return ({ V a_0 = v_ru_24x_246_24Right; V a_1 = heff_dup(v_st_2415); V a_2 = NTAG(TAG_Nil); V b_3 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_4 = heff_dup(v_hd_240); V a_5 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_2ek_24l0_lam3, 1, 7, (V[]){v_st_2415, v_hd_240, v_clock_242, v_wanted_243, v_ex_244, v_cu_245, v_k_241}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_x_246);
  }
}