// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_byMember 2056687451
#define LBL_found 298980252
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_low 316878
#define LBL_members 1180739419
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_onStack 1042445868
#define LBL_outer 307469461
#define LBL_params 951713969
#define LBL_stack 311115426
#define LBL_supply 1056026650
#define LBL_tag 324116
static uint32_t shape_byMember__supply[] = {LBL_byMember, LBL_supply};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__outer__params__body[] = {LBL_key, LBL_outer, LBL_params, LBL_body};
static uint32_t shape_key__tag__members[] = {LBL_key, LBL_tag, LBL_members};
static uint32_t shape_members__supply[] = {LBL_members, LBL_supply};
static uint32_t shape_next__index__low__stack__onStack__found[] = {LBL_next, LBL_index, LBL_low, LBL_stack, LBL_onStack, LBL_found};
V g_heff_2ecompile_2ecycles_2eargsFor(V, V, V, V);
V g_heff_2ecompile_2ecycles_2eargsFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eargsFor_clo;
V g_heff_2ecompile_2ecycles_2ecallsLast(V, V);
V g_heff_2ecompile_2ecycles_2ecallsLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ecallsLast_clo;
V g_heff_2ecompile_2ecycles_2ecycleDef(V);
V g_heff_2ecompile_2ecycles_2ecycleDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ecycleDef_clo;
V g_heff_2ecompile_2ecycles_2ecycleOf(V, V, V, V);
V g_heff_2ecompile_2ecycles_2ecycleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ecycleOf_clo;
V g_heff_2ecompile_2ecycles_2ecycles(V, V);
V g_heff_2ecompile_2ecycles_2ecycles_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ecycles_clo;
HeffT2 g_heff_2ecompile_2ecycles_2ecyclesProgram_24cpr(V, V);
V g_heff_2ecompile_2ecycles_2eenter(V, V);
V g_heff_2ecompile_2ecycles_2eenter_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eenter_clo;
V g_heff_2ecompile_2ecycles_2efreshMember(V, V, V);
V g_heff_2ecompile_2ecycles_2efreshMember_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2efreshMember_clo;
V g_heff_2ecompile_2ecycles_2elastCalls(V, V);
V g_heff_2ecompile_2ecycles_2elastCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2elastCalls_clo;
V g_heff_2ecompile_2ecycles_2eleave(V, V);
V g_heff_2ecompile_2ecycles_2eleave_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eleave_clo;
V g_heff_2ecompile_2ecycles_2elowered(V, V, V);
V g_heff_2ecompile_2ecycles_2elowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2elowered_clo;
HeffT2 g_heff_2ecompile_2ecycles_2emadeOne_24cpr(V, V);
V g_heff_2ecompile_2ecycles_2ememberOf(V, V, V);
V g_heff_2ecompile_2ecycles_2ememberOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ememberOf_clo;
V g_heff_2ecompile_2ecycles_2ememberOut(V, V, V, V);
V g_heff_2ecompile_2ecycles_2ememberOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2ememberOut_clo;
HeffT2 g_heff_2ecompile_2ecycles_2epopTo_24cpr(V, V, V);
V g_heff_2ecompile_2ecycles_2eretail(V, V, V);
V g_heff_2ecompile_2ecycles_2eretail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eretail_clo;
V g_heff_2ecompile_2ecycles_2eretail_24dps(V, V, V, V);
V g_heff_2ecompile_2ecycles_2eretail_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eretail_24dps_clo;
V g_heff_2ecompile_2ecycles_2estartWalk_get(void);
V g_heff_2ecompile_2ecycles_2estrong(V, V, V);
V g_heff_2ecompile_2ecycles_2estrong_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2estrong_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1535080205x545126304(V, V, V, V);
V g_list_2efilter_24s1535080205x545126304_entry(V self, V *a);
extern Clo g_list_2efilter_24s1535080205x545126304_clo;
HeffT2 g_list_2efind_24s52705367x722192183_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1111748987x306062113(V, V, V);
V g_list_2efoldl_24s1111748987x306062113_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1111748987x306062113_clo;
V g_list_2efoldl_24s1144358441x1946627577(V, V);
V g_list_2efoldl_24s1144358441x1946627577_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1144358441x1946627577_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1406601474x338829258(V, V);
V g_list_2efoldl_24s1406601474x338829258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1406601474x338829258_clo;
V g_list_2efoldl_24s1824932427x1510793487(V, V);
V g_list_2efoldl_24s1824932427x1510793487_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1824932427x1510793487_clo;
V g_list_2efoldl_24s1977498258x1405492921(V, V, V, V);
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1977498258x1405492921_clo;
V g_list_2efoldl_24s2023159590x14712440(V, V);
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2023159590x14712440_clo;
V g_list_2efoldl_24s453100881x1701840665(V, V, V);
V g_list_2efoldl_24s453100881x1701840665_entry(V self, V *a);
extern Clo g_list_2efoldl_24s453100881x1701840665_clo;
V g_list_2efoldl_24s559655048x2117761193(V, V);
V g_list_2efoldl_24s559655048x2117761193_entry(V self, V *a);
extern Clo g_list_2efoldl_24s559655048x2117761193_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1460603830x671758883(V, V);
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2ecycles_2elastCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2elastCalls_entry, 2, 0};

V g_heff_2ecompile_2ecycles_2elastCalls(V v_acc_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_acc_240;
    V t_1 = v_b_2410;
    v_acc_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return v_acc_240;
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return v_acc_240;
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = v_acc_240; V a_1 = v_arms_2421; V r_ = (g_list_2efoldl_24s1406601474x338829258(a_0, a_1)); heff_drop(v_arms_2421); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_ECall: {
    V v_g_2425 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 1ULL, 2);
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_Cons, 2, (V[]){v_g_2425, v_acc_240});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return v_acc_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return v_acc_240;
  }
  case TAG_EAbandon: {
    return v_acc_240;
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return v_acc_240;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ecycles_2elastCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2elastCalls(a[0], a[1]);
}
V g_heff_2ecompile_2ecycles_2ecallsLast_lam1(V self, V *args);
V g_heff_2ecompile_2ecycles_2ecallsLast_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2ecallsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2ecallsLast_entry, 2, 0};

V g_heff_2ecompile_2ecycles_2ecallsLast(V v_funs_240, V v_defs_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2ecycles_2ecallsLast_lam0, 2, 1, (V[]){heff_dup(v_funs_240)}), heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
}
V g_heff_2ecompile_2ecycles_2ecallsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecycles_2ecallsLast(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecycles_2ecallsLast_lam1(V self, V *args) {
  V v_g_2447 = args[0];
  V v_funs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2448 = ({ V a_0 = v_funs_240; V a_1 = v_g_2447; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_funs_240); heff_drop(v_g_2447); r_; });
  {
    V v_field_2450 = v_t_2448.f[1];
    int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2449 == ((int64_t)0ULL)) && ({ V v_x_2452 = heff_dup(v_field_2450); int c_ = 1; heff_drop(v_x_2452); c_; })));
    heff_drop(v_field_2450);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecycles_2ecallsLast_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_funs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_funs_240, heff_rfield(v_d_243, 0)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      V v_e_249 = heff_take_field(v_d_243, 2);
      V v_t_2444;
      switch (heff_tag_of(v_e_249)) {
      case TAG_EVar: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EGlobal: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_ELam: {
        V v_b_2413 = heff_field(v_e_249, 1);
        heff_take_n(v_e_249, 2ULL, 2);
        v_t_2444 = v_b_2413;
        break;
      }
      case TAG_EApp: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_ELet: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_ERecord: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EProj: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_ETag: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EMatch: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EPrim: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_ECall: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EInt: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EFloat: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EStr: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EBytes: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EFixed: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EFloat32: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = v_e_249;
        break;
      }
      case TAG_EFix: {
        v_t_2444 = v_e_249;
        break;
      }
      default: heff_nomatch(v_e_249);
      }
      V v_xs_2445 = (g_heff_2ecompile_2ecycles_2elastCalls(NTAG(TAG_Nil), v_t_2444));
      V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2445));
      V v_t_2453 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2ecycles_2ecallsLast_lam1, 1, 1, (V[]){v_funs_240}), v_t_2446));
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_242, heff_get_n(v_d_243, 0, 3), v_t_2453));
    } else {
      heff_drop_rec(v_d_243, 3);
      heff_drop(v_funs_240);
      heff_drop(v_field_246);
      return v_m_242;
    }
  }
}
Clo g_heff_2ecompile_2ecycles_2eenter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2eenter_entry, 2, 0};

V g_heff_2ecompile_2ecycles_2eenter(V v_v_240, V v_w_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_dup(heff_rfield(v_w_241, 0)), MK_INT(1LL));
  V v_t_243 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_w_241, 1), heff_dup(v_v_240), heff_dup(heff_rfield(v_w_241, 0))));
  V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_w_241, 2), heff_dup(v_v_240), heff_take_field(v_w_241, 0)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_240), heff_take_field(v_w_241, 3)});
  V v_t_246 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_w_241, 4), v_v_240, NTAG(TAG_MkUnit)));
  return ({ V rv_0 = v_t_242; V rv_1 = v_t_243; V rv_2 = v_t_244; V rv_3 = v_t_245; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_w_241, 32ULL, 6, shape_next__index__low__stack__onStack__found, 3072u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ecompile_2ecycles_2eenter_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2eenter(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecycles_2elowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2elowered_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2elowered(V v_v_240, V v_n_241, V v_w_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_w_242, 2), v_v_240));
  V v_t_2410;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_b_248;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      v_b_248 = v_x_247;
    } else {
      heff_drop(v_field_245);
      v_b_248 = MK_INT(0LL);
    }
    if (heff_intLt_c_lent(v_n_241, v_b_248, 0)) {
      heff_drop(v_b_248);
      v_t_2410 = v_n_241;
    } else {
      heff_drop(v_n_241);
      v_t_2410 = v_b_248;
    }
  }
  V v_t_2411 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_w_242, 2), v_v_240, v_t_2410));
  return ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_w_242, 59ULL, 6, shape_next__index__low__stack__onStack__found, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2ecycles_2elowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2elowered(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2ecycles_2epopTo_24cpr(V v_v_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{v_acc_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_243, v_v_240, 0)) {
      return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_acc_241}), v_xs_244}});
    } else {
      V t_0 = v_v_240;
      V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_acc_241});
      V t_2 = v_xs_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2ecycles_2eleave_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2eleave_entry, 2, 0};

V g_heff_2ecompile_2ecycles_2eleave(V v_v_240, V v_w_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_w_241, 2), v_v_240));
  V v_t_247;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      v_t_247 = v_x_246;
    } else {
      heff_drop(v_field_244);
      v_t_247 = MK_INT(0LL);
    }
  }
  HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_w_241, 1), v_v_240));
  V v_t_2413;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2410;
      v_t_2413 = v_x_2412;
    } else {
      heff_drop(v_field_2410);
      v_t_2413 = MK_INT(0LL);
    }
  }
  if (heff_intEq_c(v_t_247, v_t_2413)) {
    HeffT2 v_t_2415 = (g_heff_2ecompile_2ecycles_2epopTo_24cpr(v_v_240, NTAG(TAG_Nil), heff_take_field(v_w_241, 3)));
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_comp_2418 = v_field_2416;
      V v_rest_2419 = v_field_2417;
      V v_t_2420 = (g_list_2efoldl_24s559655048x2117761193(heff_take_field(v_w_241, 4), v_comp_2418));
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_comp_2418, heff_take_field(v_w_241, 5)});
      return ({ V rv_3 = v_rest_2419; V rv_4 = v_t_2420; V rv_5 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_w_241, 7ULL, 6, shape_next__index__low__stack__onStack__found, 63u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
  } else {
    return v_w_241;
  }
}
V g_heff_2ecompile_2ecycles_2eleave_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecycles_2eleave(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecycles_2estrong_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2estrong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2estrong_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2estrong(V v_calls_240, V v_w_241, V v_v_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2ecycles_2eenter(heff_dup(v_v_242), v_w_241));
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_calls_240, v_v_242));
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_246);
      v_t_249 = NTAG(TAG_Nil);
    }
  }
  V v_t_2435 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecycles_2estrong_lam0, 2, 2, (V[]){heff_dup(v_v_242), heff_dup(v_calls_240)}); V a_1 = v_t_243; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  return ({ V a_0 = v_v_242; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2ecycles_2eleave(a_0, a_1)); heff_drop(v_v_242); r_; });
}
V g_heff_2ecompile_2ecycles_2estrong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecycles_2estrong(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecycles_2estrong_lam0(V self, V *args) {
  V v_w1_2410 = args[0];
  V v_g_2411 = args[1];
  V v_v_242 = heff_env(self)[0];
  V v_calls_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_w1_2410, 1), v_g_2411));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_calls_240);
      V v_x_2416 = v_field_2414;
      heff_drop(v_x_2416);
      HeffT2 v_t_2417 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_w1_2410, 4), v_g_2411));
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_x_2421 = v_field_2419;
          heff_drop(v_x_2421);
          HeffT2 v_t_2422 = ({ V a_0 = heff_rfield(v_w1_2410, 1); V a_1 = v_g_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_g_2411); r_; });
          V v_t_2427;
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            if ((v_tag_2423 == ((int64_t)0ULL))) {
              V v_x_2426 = v_field_2424;
              v_t_2427 = v_x_2426;
            } else {
              heff_drop(v_field_2424);
              v_t_2427 = MK_INT(0LL);
            }
          }
          return (g_heff_2ecompile_2ecycles_2elowered(v_v_242, v_t_2427, v_w1_2410));
        } else {
          heff_drop(v_g_2411);
          heff_drop(v_v_242);
          heff_drop(v_field_2419);
          return v_w1_2410;
        }
      }
    } else {
      heff_drop(v_field_2414);
      V v_w_2428 = ({ V a_0 = v_calls_240; V a_1 = v_w1_2410; V a_2 = heff_dup(v_g_2411); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_calls_240); r_; });
      HeffT2 v_t_2429 = ({ V a_0 = heff_rfield(v_w_2428, 2); V a_1 = v_g_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_g_2411); r_; });
      V v_t_2434;
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          V v_x_2433 = v_field_2431;
          v_t_2434 = v_x_2433;
        } else {
          heff_drop(v_field_2431);
          v_t_2434 = MK_INT(0LL);
        }
      }
      return (g_heff_2ecompile_2ecycles_2elowered(v_v_242, v_t_2434, v_w_2428));
    }
  }
}

static V g_heff_2ecompile_2ecycles_2estartWalk_val;
static HEFF_ONCE g_heff_2ecompile_2ecycles_2estartWalk_st;
static V g_heff_2ecompile_2ecycles_2estartWalk_init(void) {
  return heff_rec_n(6, shape_next__index__low__stack__onStack__found, (V[]){MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2ecycles_2estartWalk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecycles_2estartWalk_st)) return g_heff_2ecompile_2ecycles_2estartWalk_val;
  return heff_global(&g_heff_2ecompile_2ecycles_2estartWalk_val, &g_heff_2ecompile_2ecycles_2estartWalk_st, g_heff_2ecompile_2ecycles_2estartWalk_init);
}
V g_heff_2ecompile_2ecycles_2ecycles_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2ecycles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2ecycles_entry, 2, 0};

V g_heff_2ecompile_2ecycles_2ecycles(V v_calls_240, V v_defs_241) {
top: ;
  V v_w_2414 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2ecycles_2ecycles_lam0, 2, 1, (V[]){heff_dup(v_calls_240)}), heff_dup(g_heff_2ecompile_2ecycles_2estartWalk_get()), v_defs_241));
  return (g_list_2efilter_24s1535080205x545126304(MK_INT(1LL), MK_INT(0LL), MK_INT(2LL), heff_get_n(v_w_2414, 5, 6)));
}
V g_heff_2ecompile_2ecycles_2ecycles_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecycles_2ecycles(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecycles_2ecycles_lam0(V self, V *args) {
  V v_w_242 = args[0];
  V v_d_243 = args[1];
  V v_calls_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_calls_240, heff_rfield(v_d_243, 0)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_w_242, 1), heff_rfield(v_d_243, 0)));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop_rec(v_d_243, 3);
          heff_drop(v_calls_240);
          V v_x_2413 = v_field_2411;
          heff_drop(v_x_2413);
          return v_w_242;
        } else {
          heff_drop(v_field_2411);
          return ({ V a_0 = v_calls_240; V a_1 = v_w_242; V a_2 = heff_get_n(v_d_243, 0, 3); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_calls_240); r_; });
        }
      }
    } else {
      heff_drop_rec(v_d_243, 3);
      heff_drop(v_calls_240);
      heff_drop(v_field_246);
      return v_w_242;
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2ecycles_2eargsFor_str0, 6, "Enter$");
HEFF_LIT(g_heff_2ecompile_2ecycles_2eargsFor_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecycles_2eargsFor_str2, 0, "");
V g_heff_2ecompile_2ecycles_2eargsFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2eargsFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2eargsFor_entry, 4, 0};

V g_heff_2ecompile_2ecycles_2eargsFor(V v_c_240, V v_at_241, V v_g_242, V v_args_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_ETag, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecycles_2eargsFor_str0), heff_dup(v_g_242)), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_240, 2, 3)));
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecycles_2eargsFor_lam0, 2, 3, (V[]){v_g_242, v_args_243, heff_dup(v_at_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412});
}
V g_heff_2ecompile_2ecycles_2eargsFor_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecycles_2eargsFor(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecycles_2eargsFor_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_g_242 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_at_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), v_g_242)) {
    heff_drop_rec(v_x_247, 4);
    heff_drop(v_at_241);
    v_t_2411 = v_args_243;
  } else {
    heff_drop(v_args_243);
    switch (heff_tag_of(v_at_241)) {
    case TAG_Nothing: {
      v_t_2411 = (g_list_2emap_24s1460603830x671758883(((V)&g_heff_2ecompile_2ecycles_2eargsFor_str1), heff_get_n(v_x_247, 2, 4)));
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_at_241, 0);
      heff_take_n(v_at_241, 1ULL, 1);
      if (heff_strEq_c(v_x_249, heff_dup(heff_rfield(v_x_247, 0)))) {
        v_t_2411 = (g_list_2emap_24s1460603830x671758883(((V)&g_heff_2ecompile_2ecycles_2eargsFor_str2), heff_get_n(v_x_247, 2, 4)));
      } else {
        v_t_2411 = (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_x_247, 2, 4)));
      }
      break;
    }
    default: heff_nomatch(v_at_241);
    }
  }
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_246));
}
V g_heff_2ecompile_2ecycles_2eretail_lam0(V self, V *args);
V g_heff_2ecompile_2ecycles_2eretail_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2eretail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2eretail_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2eretail(V v_c_240, V v_at_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ELam: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EApp: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_cell_2412 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_249, v_a_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2ecycles_2eretail_24dps(v_c_240, v_at_241, v_b_2411, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_ERecord: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EProj: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ETag: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_e_242, 0);
    V v_arms_2424 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecycles_2eretail_lam0, 1, 2, (V[]){v_c_240, v_at_241}), v_arms_2424));
    return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2423, v_t_2439});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ECall: {
    V v_g_2443 = heff_field(v_e_242, 0);
    V v_args_2444 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2449 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2ecycles_2eretail_lam1, 1, 2, (V[]){heff_dup(v_g_2443), heff_dup(v_args_2444)}), heff_rfield(v_c_240, 2)));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_t_2449);
      V v_t_2450 = ({ V a_0 = heff_dup(v_c_240); V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_at_241}); V a_2 = v_g_2443; V a_3 = v_args_2444; V r_ = (g_heff_2ecompile_2ecycles_2eargsFor(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_c_240, 0, 3), v_t_2450});
    } else {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_at_241);
      heff_drop(v_t_2449);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2443, v_args_2444});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFix: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2ecycles_2eretail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2eretail(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecycles_2eretail_lam0(V self, V *args) {
  V v_arm_2425 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_at_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429;
  switch (heff_tag_of(v_arm_2425)) {
  case TAG_MkArm: {
    V v_t_2426 = heff_dup(heff_field(v_arm_2425, 0));
    v_t_2429 = v_t_2426;
    break;
  }
  default: heff_nomatch(v_arm_2425);
  }
  V v_t_2433;
  switch (heff_tag_of(v_arm_2425)) {
  case TAG_MkArm: {
    V v_vs_2431 = heff_dup(heff_field(v_arm_2425, 1));
    v_t_2433 = v_vs_2431;
    break;
  }
  default: heff_nomatch(v_arm_2425);
  }
  V v_t_2437;
  switch (heff_tag_of(v_arm_2425)) {
  case TAG_MkArm: {
    V v_b_2436 = heff_field(v_arm_2425, 2);
    heff_take_n(v_arm_2425, 4ULL, 3);
    v_t_2437 = v_b_2436;
    break;
  }
  default: heff_nomatch(v_arm_2425);
  }
  V v_t_2438 = (g_heff_2ecompile_2ecycles_2eretail(v_c_240, v_at_241, v_t_2437));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2429, v_t_2433, v_t_2438});
}
V g_heff_2ecompile_2ecycles_2eretail_lam1(V self, V *args) {
  V v_m_2445 = args[0];
  V v_g_2443 = heff_env(self)[0];
  V v_args_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_m_2445, 0)), heff_dup(v_g_2443)) && ({ V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_m_2445, 2))); int c_ = ({ V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2444)); int c_ = heff_intEq_c_lent(v_t_2447, v_t_2448, 0); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2447); c_; })));
  heff_drop_rec(v_m_2445, 4);
  heff_drop(v_g_2443);
  heff_drop(v_args_2444);
  return v_ret_24bool;
}
V g_heff_2ecompile_2ecycles_2eretail_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2ecycles_2eretail_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2eretail_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2eretail_24dps_entry, 4, 0};

V g_heff_2ecompile_2ecycles_2eretail_24dps(V v_c_240, V v_at_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_ELam: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EApp: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_ELet: {
    V v_x_2410 = heff_field(v_e_242, 0);
    V v_a_2411 = heff_field(v_e_242, 1);
    V v_b_2412 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_cell_2413 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2410, v_a_2411, heff_hole()});
    V v_u_2414 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_c_240;
    V t_1 = v_at_241;
    V t_2 = v_b_2412;
    V t_3 = v_cell_2413;
    v_c_240 = t_0;
    v_at_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EProj: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_ETag: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_e_242, 0);
    V v_arms_2425 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecycles_2eretail_24dps_lam0, 1, 2, (V[]){v_c_240, v_at_241}), v_arms_2425));
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2424, v_t_2440}));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_ECall: {
    V v_g_2444 = heff_field(v_e_242, 0);
    V v_args_2445 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2450 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2ecycles_2eretail_24dps_lam1, 1, 2, (V[]){heff_dup(v_g_2444), heff_dup(v_args_2445)}), heff_rfield(v_c_240, 2)));
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop(v_t_2450);
      V v_t_2451 = ({ V a_0 = heff_dup(v_c_240); V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_at_241}); V a_2 = v_g_2444; V a_3 = v_args_2445; V r_ = (g_heff_2ecompile_2ecycles_2eargsFor(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      V v_t_2452 = heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_c_240, 0, 3), v_t_2451});
      return heff_setField(v_d_243, MK_INT(2LL), v_t_2452);
    } else {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_at_241);
      heff_drop_cell(v_ru_24e_242_24ECall, 2);
      heff_drop(v_t_2450);
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ECall, 2, (V[]){v_g_2444, v_args_2445}));
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EStr: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_EFix: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2ecycles_2eretail_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2eretail_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecycles_2eretail_24dps_lam0(V self, V *args) {
  V v_arm_2426 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_at_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430;
  switch (heff_tag_of(v_arm_2426)) {
  case TAG_MkArm: {
    V v_t_2427 = heff_dup(heff_field(v_arm_2426, 0));
    v_t_2430 = v_t_2427;
    break;
  }
  default: heff_nomatch(v_arm_2426);
  }
  V v_t_2434;
  switch (heff_tag_of(v_arm_2426)) {
  case TAG_MkArm: {
    V v_vs_2432 = heff_dup(heff_field(v_arm_2426, 1));
    v_t_2434 = v_vs_2432;
    break;
  }
  default: heff_nomatch(v_arm_2426);
  }
  V v_t_2438;
  switch (heff_tag_of(v_arm_2426)) {
  case TAG_MkArm: {
    V v_b_2437 = heff_field(v_arm_2426, 2);
    heff_take_n(v_arm_2426, 4ULL, 3);
    v_t_2438 = v_b_2437;
    break;
  }
  default: heff_nomatch(v_arm_2426);
  }
  V v_t_2439 = (g_heff_2ecompile_2ecycles_2eretail(v_c_240, v_at_241, v_t_2438));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2430, v_t_2434, v_t_2439});
}
V g_heff_2ecompile_2ecycles_2eretail_24dps_lam1(V self, V *args) {
  V v_m_2446 = args[0];
  V v_g_2444 = heff_env(self)[0];
  V v_args_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_m_2446, 0)), heff_dup(v_g_2444)) && ({ V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_m_2446, 2))); int c_ = ({ V v_t_2449 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2445)); int c_ = heff_intEq_c_lent(v_t_2448, v_t_2449, 0); heff_drop(v_t_2449); c_; }); heff_drop(v_t_2448); c_; })));
  heff_drop_rec(v_m_2446, 4);
  heff_drop(v_g_2444);
  heff_drop(v_args_2445);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2ecycles_2ecycleDef_str0, 6, "Enter$");
V g_heff_2ecompile_2ecycles_2ecycleDef_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2ecycleDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2ecycleDef_entry, 1, 0};

V g_heff_2ecompile_2ecycles_2ecycleDef(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 2))));
  V v_t_242 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_241; V r_ = (g_list_2efoldl_24s2023159590x14712440(a_0, a_1)); heff_drop(v_t_241); r_; });
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), v_t_242});
  V v_t_244 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_c_240, 1))});
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecycles_2ecycleDef_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_dup(heff_rfield(v_c_240, 2))));
  V v_body_249 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_244, v_t_248})});
  return heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_c_240, 0)), heff_get_n(v_c_240, 0, 3), v_body_249});
}
V g_heff_2ecompile_2ecycles_2ecycleDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2ecycleDef(a[0]);
}
V g_heff_2ecompile_2ecycles_2ecycleDef_lam0(V self, V *args) {
  V v_m_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2ecycles_2ecycleDef_str0), heff_dup(heff_rfield(v_m_245, 0)));
  V v_t_247 = (g_heff_2ecompile_2ecycles_2eretail(v_c_240, heff_take_field(v_m_245, 0), heff_get_n(v_m_245, 3, 4)));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_246, NTAG(TAG_Nil), v_t_247});
}
Clo g_heff_2ecompile_2ecycles_2efreshMember_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2efreshMember_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2efreshMember(V v_k_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EGlobal: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_ELam: {
      V v_ys_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, heff_dup(v_ys_247), heff_dup(v_b_248)});
    }
    case TAG_EApp: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_ELet: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_ERecord: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EProj: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_ETag: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EMatch: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EPrim: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EPrimCall: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_ECall: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EInt: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EFloat: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EStr: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EBytes: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EFixed: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EFloat32: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EAbandon: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    case TAG_EFix: {
      return heff_rec_n(4, shape_key__outer__params__body, (V[]){v_k_240, v_xs_241, NTAG(TAG_Nil), heff_dup(v_x31_243)});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecycles_2efreshMember_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecycles_2efreshMember(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecycles_2ememberOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2ememberOf_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2ememberOf(V v_bodies_240, V v_acc_241, V v_k_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_bodies_240, v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_b_248;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      v_b_248 = v_x_247;
    } else {
      heff_drop(v_field_245);
      v_b_248 = NTAG(TAG_EAbandon);
    }
    V v_named_249 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_std_2emap_2eempty_get()), heff_take_field(v_acc_241, 1), heff_dup(v_b_248)));
    V v_t_2444;
    switch (heff_tag_of(v_b_248)) {
    case TAG_EVar: {
      heff_take_n(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_b_248, 0);
      heff_take_n(v_b_248, 1ULL, 2);
      v_t_2444 = v_xs_2412;
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_b_248, 0ULL, 3);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_b_248, 0ULL, 4);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_b_248, 0ULL, 3);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_b_248, 0ULL, 1);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_b_248, 0ULL, 2);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_b_248);
    }
    V v_t_2445 = (g_heff_2ecompile_2ecycles_2efreshMember(v_k_242, v_t_2444, v_named_249));
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, heff_get_n(v_acc_241, 0, 2)});
    V v_t_2449;
    switch (heff_tag_of(v_named_249)) {
    case TAG_MkPair: {
      V v_n_2448 = heff_field(v_named_249, 1);
      heff_take_n(v_named_249, 2ULL, 2);
      v_t_2449 = v_n_2448;
      break;
    }
    default: heff_nomatch(v_named_249);
    }
    return heff_rec_n(2, shape_members__supply, (V[]){v_t_2446, v_t_2449});
  }
}
V g_heff_2ecompile_2ecycles_2ememberOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecycles_2ememberOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecycles_2ecycleOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecycles_2ecycleOf_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecycles_2ecycleOf_str2, 6, "$cycle");
HEFF_LIT(g_heff_2ecompile_2ecycles_2ecycleOf_str3, 3, "tag");
V g_heff_2ecompile_2ecycles_2ecycleOf_lam0(V self, V *args);
V g_heff_2ecompile_2ecycles_2ecycleOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2ecycleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2ecycleOf_entry, 4, 0};

V g_heff_2ecompile_2ecycles_2ecycleOf(V v_bodies_240, V v_places_241, V v_cs_242, V v_ks_243) {
top: ;
  V v_m_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2ecycles_2ecycleOf_lam0, 2, 1, (V[]){heff_dup(v_places_241)}), heff_dup(g_std_2emap_2eempty_get()), v_ks_243));
  V v_t_2413 = ({ V a_0 = v_m_2412; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2412); r_; });
  V v_ordered_2414 = (g_list_2emap_24s366344330x1145113647(v_t_2413));
  V v_n_2415 = heff_take_field(v_cs_242, 1);
  V v_t_2416 = heff_rec_n(2, shape_members__supply, (V[]){NTAG(TAG_Nil), heff_intAdd(heff_dup(v_n_2415), MK_INT(1LL))});
  V v_ms_2417 = (g_list_2efoldl_24s453100881x1701840665(v_bodies_240, v_t_2416, v_ordered_2414));
  V v_t_2420;
  switch (heff_tag_of(v_ordered_2414)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ecompile_2ecycles_2ecycleOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_ordered_2414, 0);
    heff_take_n(v_ordered_2414, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_ordered_2414);
  }
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2ecycles_2ecycleOf_str1), heff_intShow(v_n_2415));
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_ms_2417, 0)));
  V v_c_2423 = heff_rec_n(3, shape_key__tag__members, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2ecycles_2ecycleOf_str2)), heff_strAppend(((V)&g_heff_2ecompile_2ecycles_2ecycleOf_str3), v_t_2421), v_t_2422});
  V v_t_2426 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecycles_2ecycleOf_lam1, 2, 1, (V[]){heff_dup(v_c_2423)}); V a_1 = heff_get_n(v_cs_242, 0, 2); V b_2 = heff_get_n(v_c_2423, 2, 3); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_rec_n(2, shape_byMember__supply, (V[]){v_t_2426, heff_get_n(v_ms_2417, 1, 2)});
}
V g_heff_2ecompile_2ecycles_2ecycleOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2ecycles_2ecycleOf(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2ecycles_2ecycleOf_lam0(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_places_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V a_0 = v_places_241; V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_places_241); r_; });
  V v_t_2411;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_248;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_248);
      v_t_2411 = MK_INT(0LL);
    }
  }
  return (g_std_2emap_2einsert_24s170109517x1206653089(v_m_244, v_t_2411, v_k_245));
}
V g_heff_2ecompile_2ecycles_2ecycleOf_lam1(V self, V *args) {
  V v_m_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_2424, heff_get_n(v_k_2425, 0, 4), v_c_2423));
}
Clo g_heff_2ecompile_2ecycles_2ememberOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2ememberOut_entry, 4, 0};

V g_heff_2ecompile_2ecycles_2ememberOut(V v_c_240, V v_acc_241, V v_d_242, V v_first_243) {
top: ;
  HeffT2 v_t_244 = (g_list_2efind_24s52705367x722192183_24cpr(heff_dup(v_d_242), heff_dup(heff_rfield(v_c_240, 2))));
  V v_t_2414;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_m_249;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      v_m_249 = v_x_248;
    } else {
      heff_drop(v_field_246);
      v_m_249 = heff_dup(v_first_243);
    }
    V v_t_2410 = (g_list_2emap_24s1809017761x1063871171(heff_dup(heff_rfield(v_m_249, 1))));
    V v_t_2411 = ({ V a_0 = heff_dup(v_c_240); V b_1 = NTAG(TAG_Nothing); V a_2 = heff_take_field(v_m_249, 0); V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2ecycles_2eargsFor(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
    V v_t_2412 = heff_tag_n(TAG_ECall, 2, (V[]){heff_dup(heff_rfield(v_c_240, 0)), v_t_2411});
    V v_body_2413 = heff_tag_n(TAG_ELam, 2, (V[]){heff_get_n(v_m_249, 1, 4), v_t_2412});
    v_t_2414 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_242, 0)), heff_dup(heff_rfield(v_d_242, 1)), v_body_2413});
  }
  V v_t_2417;
  if (heff_strEq_c(heff_get_n(v_first_243, 0, 4), heff_get_n(v_d_242, 0, 3))) {
    V v_t_2416 = (g_heff_2ecompile_2ecycles_2ecycleDef(v_c_240));
    v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_acc_241});
  } else {
    heff_drop_rec(v_c_240, 3);
    v_t_2417 = v_acc_241;
  }
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
}
V g_heff_2ecompile_2ecycles_2ememberOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2ememberOut(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecycles_2emadeOne_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ecycles_2emadeOne_24cpr(V v_defs_240, V v_cs_241) {
top: ;
  V v_xs_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2ecycles_2emadeOne_24cpr_lam0, 2, 1, (V[]){heff_dup(v_cs_241)}), NTAG(TAG_Nil), v_defs_240));
  V v_f_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
  V v_f_2414 = heff_get_n(v_cs_241, 1, 2);
  return ((HeffT2){{v_f_2413, v_f_2414}});
}
V g_heff_2ecompile_2ecycles_2emadeOne_24cpr_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_d_243 = args[1];
  V v_cs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_cs_241, 0, 2); V a_1 = heff_rfield(v_d_243, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_c_248 = v_field_246;
      V v_t_249 = heff_dup(heff_rfield(v_c_248, 2));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nil: {
        heff_drop_rec(v_c_248, 3);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_d_243, v_acc_242});
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 2);
        return (g_heff_2ecompile_2ecycles_2ememberOut(v_c_248, v_acc_242, v_d_243, v_x_2410));
      }
      default: return heff_nomatch(v_t_249);
      }
    } else {
      heff_drop(v_field_246);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_d_243, v_acc_242});
    }
  }
}

HeffT2 g_heff_2ecompile_2ecycles_2ecyclesProgram_24cpr(V v_n_240, V v_defs_241) {
top: ;
  V v_funs_242 = (g_list_2efoldl_24s1824932427x1510793487(heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
  V v_t_243 = (g_list_2efoldl_24s1144358441x1946627577(heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
  V v_x1_244 = (g_list_2efoldl_24s1111748987x306062113(MK_INT(1LL), heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get())}), heff_dup(v_defs_241)));
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 2ULL, 2);
    v_t_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = ({ V a_0 = v_funs_242; V a_1 = v_defs_241; V r_ = (g_heff_2ecompile_2ecycles_2ecallsLast(a_0, a_1)); heff_drop(v_funs_242); r_; });
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = v_defs_241; V r_ = (g_heff_2ecompile_2ecycles_2ecycles(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_cs_2410 = ({ V a_0 = v_t_243; V a_1 = v_t_247; V a_2 = heff_rec_n(2, shape_byMember__supply, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_n_240)}); V a_3 = v_t_249; V r_ = (g_list_2efoldl_24s1977498258x1405492921(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); heff_drop(v_t_247); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2emap_2esize(heff_rfield(v_cs_2410, 0)));
  if (heff_intEq_c(v_t_2411, MK_INT(0LL))) {
    heff_drop_rec(v_cs_2410, 2);
    return ((HeffT2){{v_defs_241, v_n_240}});
  } else {
    heff_drop(v_n_240);
    return ({ V a_0 = v_defs_241; V a_1 = v_cs_2410; HeffT2 r_ = (g_heff_2ecompile_2ecycles_2emadeOne_24cpr(a_0, a_1)); heff_drop(v_defs_241); r_; });
  }
}