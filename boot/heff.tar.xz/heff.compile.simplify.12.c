// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_applyTo 1586120902
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_off 319465
#define LBL_sp 10436
#define LBL_touched 1244526179
#define LBL_underLam 296337946
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapartMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapartMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartMore_clo;
V g_heff_2ecompile_2esimplify_2eapartOf(V, V);
V g_heff_2ecompile_2esimplify_2eapartOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable(V, V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebuilds(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_clo;
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2ecopyCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eeta(V, V);
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eeta_clo;
V g_heff_2ecompile_2esimplify_2eetaFor(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaFor_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2efirstCalled(V, V);
V g_heff_2ecompile_2esimplify_2efirstCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efirstCalled_clo;
V g_heff_2ecompile_2esimplify_2efreshNames(V, V, V);
V g_heff_2ecompile_2esimplify_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshNames_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2einlineCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ereplayBody_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ereplayed_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especLam_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_24tok2_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2evaluesCalled(V, V, V);
V g_heff_2ecompile_2esimplify_2evaluesCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesCalled_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_list_2eany_24s155774913x881635560(V, V, V);
V g_list_2eany_24s155774913x881635560_entry(V self, V *a);
extern Clo g_list_2eany_24s155774913x881635560_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s418652630x628827683(V);
V g_list_2emap_24s418652630x628827683_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2esimplify_2etakeL_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str1, 6, "MkLazy");

HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_e1_2420 = heff_field(v_e_241, 0);
    V v_e2_2421 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2420)) {
    case TAG_EVar: {
      V v_z_2422 = heff_field(v_e1_2420, 0);
      heff_take_n(v_e1_2420, 1ULL, 1);
      switch (heff_tag_of(v_e2_2421)) {
      case TAG_Nil: {
        heff_drop(v_z_2422);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_e21_2423 = heff_field(v_e2_2421, 0);
        V v_e22_2424 = heff_field(v_e2_2421, 1);
        heff_take_n(v_e2_2421, 3ULL, 2);
        switch (heff_tag_of(v_e21_2423)) {
        case TAG_MkArm: {
          V v_t_2425 = heff_field(v_e21_2423, 0);
          V v_vs_2426 = heff_field(v_e21_2423, 1);
          V v_b_2427 = heff_field(v_e21_2423, 2);
          heff_take_n(v_e21_2423, 7ULL, 3);
          switch (heff_tag_of(v_e22_2424)) {
          case TAG_Nil: {
            V v_t_24100;
            if (heff_strEq_c_lent(v_x_240, v_z_2422, 2)) {
              if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str0), 2)) {
                v_t_24100 = NTAG(TAG_False);
              } else {
                V v_t_24110;
                switch (heff_tag_of(v_vs_2426)) {
                case TAG_Nil: {
                  v_t_24110 = NTAG(TAG_False);
                  break;
                }
                case TAG_Cons: {
                  v_t_24110 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_vs_2426);
                }
                switch (heff_tag_of(v_t_24110)) {
                case TAG_True: {
                  v_t_24100 = heff_bool(((heff_strEq_c_lent(v_t_2425, ((V)&g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str1), 2) ? 0 : ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2425, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2425, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)) && ({ V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2427), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2431 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_2430))); int c_ = ({ V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2427), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2433 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_2432))); int c_ = ({ V v_t_24111 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2431), heff_dup(v_t_2433)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_24111, MK_INT(0LL), 2); heff_drop(v_t_24111); c_; }); heff_drop(v_t_2433); c_; }); heff_drop(v_t_2432); c_; }); heff_drop(v_t_2431); c_; }); heff_drop(v_t_2430); c_; })));
                  break;
                }
                case TAG_False: {
                  v_t_24100 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_t_24110);
                }
              }
            } else {
              v_t_24100 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_t_24100)) {
            case TAG_True: {
              V v_x1_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2426)));
              V v_t_2437;
              switch (heff_tag_of(v_x1_2434)) {
              case TAG_Nil: {
                v_t_2437 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_x_2435 = heff_field(v_x1_2434, 0);
                heff_take_n(v_x1_2434, 1ULL, 2);
                v_t_2437 = ({ V a_0 = v_x_2435; V a_1 = heff_dup(v_b_2427); V r_ = (g_heff_2ecompile_2esimplify_2eapartOf(a_0, a_1)); heff_drop(v_x_2435); r_; });
                break;
              }
              default: heff_nomatch(v_x1_2434);
              }
              V v_f_2438 = ({ V a_0 = v_t_2425; V a_1 = v_vs_2426; V a_2 = v_b_2427; V a_3 = v_t_2437; V r_ = (g_heff_2ecompile_2esimplify_2eapartMore(a_0, a_1, a_2, a_3)); heff_drop(v_t_2437); r_; });
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
            }
            case TAG_False: {
              heff_drop(v_t_2425);
              heff_drop(v_vs_2426);
              heff_drop(v_b_2427);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_t_24100)}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_e22_2424, 0ULL, 2);
            heff_drop(v_z_2422);
            heff_drop(v_t_2425);
            heff_drop(v_vs_2426);
            heff_drop(v_b_2427);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_e22_2424)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e21_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e2_2421)}});
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2420, 0ULL, 3);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2420, 0ULL, 4);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2420, 0ULL, 3);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2420, 0ULL, 3);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_2420)}});
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ebuilds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuilds_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebuilds(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_x312_247 = heff_field(v_x31_243, 1);
      switch (heff_tag_of(v_x312_247)) {
      case TAG_EVar: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_x312_247, 0);
        V v_ts_2418 = heff_field(v_x312_247, 1);
        V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
        if (heff_intEq_c(v_t_2419, v_n_241)) {
          switch (heff_tag_of(v_fs_2417)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_t_2422 = (g_list_2emap_24s549405518x243689326(heff_dup(v_fs_2417)));
            V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2422); r_; });
            if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
              heff_drop(v_t_2423);
              V v_t_2424 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_tag_n(TAG_ERecord, 2, (V[]){heff_dup(v_fs_2417), heff_dup(v_ts_2418)})));
              V v_t_2425 = (g_heff_2ecompile_2eir_2enubI(v_t_2424));
              V v_x1_2426 = ({ V a_0 = v_g_240; V a_1 = v_t_2425; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2425); r_; });
              V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
              heff_drop(v_x1_2426);
              return v_ret_24bool;
            } else {
              heff_drop(v_t_2423);
              return NTAG(TAG_False);
            }
          }
          default: return heff_nomatch(v_fs_2417);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EProj: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x312_247);
      }
    }
    case TAG_EApp: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2ebuilds(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earmsPushable_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2earmsPushable(V v_budget_240, V v_a_241, V v_arms_242) {
top: ;
  V v_x1_243 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_241)));
  V v_t_247;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_ts_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    V v_x_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_244); r_; });
    v_t_247 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_246, 1));
    heff_drop(v_x_246);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_248 = (g_heff_2ecompile_2esimplify_2ewaysOut(v_a_241));
    V v_x1_249 = (g_list_2eany_24s155774913x881635560(v_budget_240, v_t_248, v_arms_242));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
    heff_drop(v_x1_249);
    return v_ret_24bool;
  } else {
    heff_drop(v_budget_240);
    heff_drop(v_a_241);
    heff_drop(v_t_247);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2earmsPushable(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eeta_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_argv_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_ELam: {
        V v_xs_2412 = heff_field(v_e_241, 0);
        V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 1ULL, 2);
        V v_t_2414 = (g_heff_2ecompile_2esimplify_2eparamsAre(v_xs_2412, v_argv_2411));
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          V v_t_2415 = (g_heff_2ecompile_2esimplify_2eetaHead(v_kinds_240, v_xs_2412, v_f_2410));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_argv_2411);
            heff_drop_cell(v_ru_24e2_245_24EApp, 2);
            heff_drop(v_xs_2412);
            heff_drop_cell(v_ru_24e_241_24ELam, 2);
            heff_drop(v_t_2415);
            return v_f_2410;
          } else {
            heff_drop(v_t_2415);
            return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2412, heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_EApp, 2, (V[]){v_f_2410, v_argv_2411})});
          }
        } else {
          heff_drop(v_t_2414);
          return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2412, heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_EApp, 2, (V[]){v_f_2410, v_argv_2411})});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 4);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 3);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EAbandon: {
      return v_e_241;
    }
    case TAG_EBool: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_ESet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      return v_e_241;
    }
    case TAG_EValues: {
      heff_take_n(v_e2_245, 0ULL, 1);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    return v_e_241;
  }
  case TAG_ESet: {
    return v_e_241;
  }
  case TAG_EValues: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eeta(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_argv_243, V v_s_244) {
top: ;
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_s_244, 2), v_g_242));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_b_248 = v_field_247;
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_248, NTAG(TAG_Nil)});
      V v_x_2410 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_249));
      if (heff_intLt_c(MK_INT(50LL), v_x_2410)) {
        heff_drop_rec(v_r_240, 4);
        V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_244});
      } else {
        V v_t_2412 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_244, 2), v_g_242));
        HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2412, v_s_244));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_s_2417 = v_field_2415;
          switch (heff_tag_of(v_x_2416)) {
          case TAG_Nothing: {
            heff_drop_rec(v_r_240, 4);
            V v_x_2418 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_s_2417});
          }
          case TAG_Just: {
            V v_b_2419 = heff_field(v_x_2416, 0);
            heff_take_n(v_x_2416, 1ULL, 1);
            V v_orig_2420 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_argv_243)));
            V v_m_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2419, v_argv_243}));
            return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_2420, v_m_2421, v_s_2417));
          }
          default: return heff_nomatch(v_x_2416);
          }
        }
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2422 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_244, 2), v_g_242));
      HeffT2 v_t_2423 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2422, v_s_244));
      {
        V v_field_2424 = v_t_2423.f[0];
        V v_field_2425 = v_t_2423.f[1];
        V v_x_2426 = v_field_2424;
        V v_s_2427 = v_field_2425;
        switch (heff_tag_of(v_x_2426)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2428 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_s_2427});
        }
        case TAG_Just: {
          V v_b_2429 = heff_field(v_x_2426, 0);
          heff_take_n(v_x_2426, 1ULL, 1);
          V v_orig_2430 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_argv_243)));
          V v_m_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2429, v_argv_243}));
          return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_2430, v_m_2431, v_s_2427));
        }
        default: return heff_nomatch(v_x_2426);
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2einlineCall(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_argv_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopyCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_list_2emap_24s418652630x628827683(heff_dup(v_argv_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      if (((heff_dup(v_t_2411) == NTAG(TAG_True)) && ({ V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248)); int c_ = ({ V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243)); int c_ = heff_intEq_c_lent(v_t_2447, v_t_2448, 0); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2447); c_; }))) {
        heff_drop(v_t_2411);
        return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
      } else {
        heff_drop(v_t_2411);
        return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EBytes: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EFixed: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EFloat32: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EBool: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_ESet: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EValues: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_argv_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2emarkGo(V v_loop_240, V v_all_241, V v_back_242, V v_argv_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_back_242);
    heff_drop(v_argv_243);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_246 = heff_field(v_x5_244, 0);
    V v_rest_247 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2414;
    if ((heff_dup(v_st_246) == NTAG(TAG_True))) {
      heff_drop(v_st_246);
      HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2enthE_24cpr(heff_dup(v_i_245), heff_dup(v_argv_243)));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          V v_t_2412 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_241, heff_dup(v_x_2411)));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_x_2411);
            heff_drop(v_t_2412);
            v_t_2414 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2412);
            if ((heff_dup(v_loop_240) == NTAG(TAG_True))) {
              V v_t_2413 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_2411)));
              if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
                heff_drop(v_x_2411);
                heff_drop(v_t_2413);
                v_t_2414 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2413);
                v_t_2414 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2411}));
              }
            } else {
              v_t_2414 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2411}));
            }
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_st_246);
      v_t_2414 = NTAG(TAG_False);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_heff_2ecompile_2esimplify_2emarkGo_24dps(v_loop_240, v_all_241, v_back_242, v_argv_243, v_rest_247, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo(a0, a1, a[2], a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edepthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edepthOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2edepthOf(V v_ds_240, V v_g_241, V v_args_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2edepthOf_lam0, 2, 1, (V[]){heff_dup(v_ds_240)}); V a_1 = MK_INT(0LL); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_241, v_t_244}); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_intAdd(MK_INT(1LL), v_t_2412);
}
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2edepthOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_n_246 = args[1];
  V v_ds_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_ds_240; V a_1 = v_n_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_ds_240); heff_drop(v_n_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_b_2411;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_b_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_b_2411 = MK_INT(0LL);
    }
    if (heff_intLe_c_lent(v_b_2411, v_d_245, 0)) {
      heff_drop(v_b_2411);
      return v_d_245;
    } else {
      heff_drop(v_d_245);
      return v_b_2411;
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_True), v_p_241}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eargPure_24cpr(v_a_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        V t_0 = v_argv_243;
        V t_1 = v_s_248;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        goto top;
      } else {
        heff_drop(v_argv_243);
        heff_drop(v_x_247);
        return ((HeffT2){{NTAG(TAG_False), v_s_248}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2evaluesCalled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evaluesCalled_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2evaluesCalled(V v_k_240, V v_n_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2evaluesCalled_24cpr(v_k_240, v_n_241, v_e_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2evaluesCalled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2evaluesCalled(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2efirstCalled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efirstCalled_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efirstCalled(V v_k_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    V v_e1_246 = heff_field(v_e_241, 0);
    V v_argv_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EVar: {
      V v_k2_248 = heff_field(v_e1_246, 0);
      heff_take_n(v_e1_246, 1ULL, 1);
      if (heff_strEq_c_lent(v_k_240, v_k2_248, 2)) {
        return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_247); r_; });
      } else {
        heff_drop(v_argv_247);
        return MK_INT(0LL);
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ELam: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_246, 0ULL, 3);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_246, 0ULL, 4);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_246, 0ULL, 3);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      heff_take_n(v_e1_246, 0ULL, 3);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_e1_246);
    }
  }
  case TAG_ELet: {
    V v_b_2449 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_k_240;
    V t_1 = v_b_2449;
    v_k_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_e2_2460 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    switch (heff_tag_of(v_e2_2460)) {
    case TAG_Nil: {
      return MK_INT(0LL);
    }
    case TAG_Cons: {
      V v_a_2461 = heff_field(v_e2_2460, 0);
      heff_take_n(v_e2_2460, 1ULL, 2);
      V v_t_2466;
      switch (heff_tag_of(v_a_2461)) {
      case TAG_MkArm: {
        V v_b_2465 = heff_field(v_a_2461, 2);
        heff_take_n(v_a_2461, 4ULL, 3);
        v_t_2466 = v_b_2465;
        break;
      }
      default: heff_nomatch(v_a_2461);
      }
      V t_0 = v_k_240;
      V t_1 = v_t_2466;
      v_k_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_e2_2460);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    V v_b_2482 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_k_240;
    V t_1 = v_b_2482;
    v_k_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2efirstCalled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2efirstCalled(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2efreshNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshNames_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2efreshNames(V v_base_240, V v_n_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2efreshNames_24cpr(v_base_240, v_n_241, v_p_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2esimplify_2efreshNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshNames(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2ereplayed_24cpr(V v_k_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 7);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_Just: {
    V v_b0_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_dup(heff_rfield(v_k_240, 4)), v_p_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2ereplayBody_24cpr(v_k_240, v_b0_243, v_s_248));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_s_2413 = v_field_2411;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_2412}), v_s_2413}});
        }
      } else {
        heff_drop_rec(v_k_240, 7);
        heff_drop(v_b0_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_247);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_248}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2especLam_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especLam_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especLam_24tok2_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especLam_24tok2(V v_tok_240, V v_r_241, V v_g_242, V v_xs_243, V v_b_244, V v_argv_245, V v_s_246) {
top: ;
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 6, 7);
  if (((heff_dup(v_t_247) == NTAG(TAG_True)) || heff_intLe_c(MK_INT(50000LL), heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 5, 7)))) {
    heff_drop(v_r_241);
    heff_drop(v_xs_243);
    heff_drop(v_b_244);
    heff_drop(v_t_247);
    V v_x_248 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_242}), v_argv_245));
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_x_248, v_s_246});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_247);
    V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eetaFor_clo), 5, (V[]){heff_dup(v_r_241), heff_dup(v_g_242), heff_dup(v_xs_243), heff_dup(v_b_244), heff_dup(v_argv_245)}));
    return (g_heff_2ecompile_2esimplify_2ebind(v_t_249, heff_clo_n(g_heff_2ecompile_2esimplify_2especLam_24tok2_lam0, 2, 5, (V[]){v_argv_245, v_r_241, v_g_242, v_xs_243, v_b_244}), v_s_246));
  }
}
V g_heff_2ecompile_2esimplify_2especLam_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especLam_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2esimplify_2especLam_24tok2_lam0(V self, V *args) {
  V v_bound_2410 = args[0];
  V v_z_2411 = args[1];
  V v_argv_245 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  V v_g_242 = heff_env(self)[2];
  V v_xs_243 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_bound_2410)) {
  case TAG_MkPair: {
    V v_bds_2412 = heff_field(v_bound_2410, 0);
    V v_argv_2413 = heff_field(v_bound_2410, 1);
    V v_ru_24bound_2410_24MkPair = heff_take_reuse_n(v_bound_2410, 3ULL, 2);
    V v_t_2414 = (g_list_2ezipWith_24s528321443x971020870(v_argv_245, heff_dup(v_argv_2413)));
    V v_x2_2415 = heff_tr(g_heff_2ecompile_2esimplify_2especKnown(v_r_241, v_g_242, v_xs_243, v_b_244, v_argv_2413, v_t_2414, v_z_2411));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_s_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      V v_x_2418 = ({ V a_0 = v_bds_2412; V a_1 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2412); r_; });
      return heff_tag_at_n(v_ru_24bound_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_s_2417});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_bound_2410);
  }
}