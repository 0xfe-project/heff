// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define LBL_style 311138763
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_clo;
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str0, 19, " is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str3, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str4, 60, ": a package's src/ holds one directory, named as the package");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str5, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str6, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str7, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str8, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str9, 24, " cannot name a package: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str11, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str12, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str13, 60, ": a package's src/ holds one directory, named as the package");
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(V v_k_240, V v_src_241, V v_ps_242, V v_hd_243, V v_x_244) {
top: ;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_ru_24x_244_24Left = heff_take_reuse_n(v_x_244, 0ULL, 1);
    heff_drop_rec(v_ps_242, 6);
    heff_drop(v_hd_243);
    V v_t_246 = heff_tag_at_n(v_ru_24x_244_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str0))});
    return heff_tail(v_k_240, 1, (V[]){v_t_246});
  }
  case TAG_Right: {
    V v_y_247 = heff_field(v_x_244, 0);
    V v_ru_24x_244_24Right = heff_take_reuse_n(v_x_244, 1ULL, 1);
    switch (heff_tag_of(v_y_247)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_242, 6);
      heff_drop(v_hd_243);
      V v_t_2410;
      switch (heff_tag_of(v_y_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_y_247, 0);
        V v_xs_249 = heff_field(v_y_247, 1);
        heff_take_n(v_y_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_y_247);
      }
      V v_t_2411 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str3)), v_t_2410);
      V v_x_2412 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str4))});
      return heff_tail(v_k_240, 1, (V[]){v_x_2412});
    }
    case TAG_Cons: {
      V v_it12_2414 = heff_dup(heff_field(v_y_247, 1));
      switch (heff_tag_of(v_it12_2414)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_y_247)) {
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_y_247, 0);
          V v_ru_24y_247_24Cons = heff_take_reuse_n(v_y_247, 1ULL, 2);
          V v_st_2417 = heff_dup(heff_rfield(v_ps_242, 5));
          V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_src_241)));
          V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_x_2415)));
          V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
          V v_s_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
          V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2421));
          V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
          V v_a_2425 = heff_tag_at_n(v_ru_24y_247_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam0_clo)});
          V v_t_2426 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
          V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
          V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
          V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
          return (g_co_2eop_24s1896221640x2141527803(v_t_2430, v_hd_243, heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam1, 1, 5, (V[]){v_src_241, v_x_2415, v_k_240, v_path_2422, v_ps_242})));
        }
        default: return heff_nomatch(v_y_247);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2414, 0ULL, 2);
        heff_drop_rec(v_ps_242, 6);
        heff_drop(v_hd_243);
        V v_t_2459;
        switch (heff_tag_of(v_y_247)) {
        case TAG_Nil: {
          v_t_2459 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2457 = heff_field(v_y_247, 0);
          V v_xs_2458 = heff_field(v_y_247, 1);
          heff_take_n(v_y_247, 3ULL, 2);
          v_t_2459 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str11); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
          break;
        }
        default: heff_nomatch(v_y_247);
        }
        V v_t_2460 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str12)), v_t_2459);
        V v_x_2461 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2460, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str13))});
        return heff_tail(v_k_240, 1, (V[]){v_x_2461});
      }
      default: return heff_nomatch(v_it12_2414);
      }
    }
    default: return heff_nomatch(v_y_247);
    }
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam0(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam2(V self, V *args) {
  V v_n_2440 = args[0];
  V v_path_2422 = heff_env(self)[0];
  V v_t_2441 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2440));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2422, v_t_2441));
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_path_2422 = heff_env(self)[3];
  V v_ps_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 0ULL, 1);
    heff_clo_take(self, 5);
    heff_drop(v_path_2422);
    heff_drop_rec(v_ps_242, 6);
    V v_t_2433 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str5)), v_x_2415);
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str6))});
    V f_ = v_k_240;
    args[0] = v_t_2434;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    switch (heff_tag_of(v_y_2435)) {
    case TAG_Left: {
      V v_ru_24y_2435_24Left = heff_take_reuse_n(v_y_2435, 0ULL, 1);
      heff_clo_take(self, 5);
      heff_drop(v_path_2422);
      heff_drop_rec(v_ps_242, 6);
      heff_drop_cell(v_ru_24x_2431_24Right, 1);
      V v_t_2437 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str7)), v_x_2415);
      V v_t_2438 = heff_tag_at_n(v_ru_24y_2435_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str8))});
      V f_ = v_k_240;
      args[0] = v_t_2438;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_y_2435, 0);
      V v_ru_24y_2435_24Right = heff_take_reuse_n(v_y_2435, 1ULL, 1);
      heff_clo_take(self, 5);
      V v_x_2442 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_lam2, 1, 1, (V[]){v_path_2422}), v_x_2439));
      V v_x_2443 = (g_list_2emap_24s219049803x1458391381(v_x_2442));
      heff_drop(v_x_2443);
      V v_st_2444 = heff_get_n(v_ps_242, 5, 6);
      V v_t_2445 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_src_241));
      V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2444), heff_dup(v_x_2415)));
      V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
      V v_dir_2448 = ({ V a_0 = v_st_2444; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2447); r_; });
      HeffT2 v_t_2449 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2415));
      {
        V v_field_2451 = v_t_2449.f[1];
        int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
        V v_t_2454;
        if ((v_tag_2450 == ((int64_t)0ULL))) {
          heff_drop(v_x_2415);
          heff_drop_cell(v_ru_24x_2431_24Right, 1);
          V v_why_2452 = v_field_2451;
          V v_t_2453 = heff_strAppend(heff_strAppend(v_dir_2448, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_str9)), v_why_2452);
          v_t_2454 = heff_tag_at_n(v_ru_24y_2435_24Right, TAG_Left, 1, (V[]){v_t_2453});
        } else {
          heff_drop_cell(v_ru_24y_2435_24Right, 1);
          heff_drop(v_dir_2448);
          heff_drop(v_field_2451);
          v_t_2454 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_Right, 1, (V[]){v_x_2415});
        }
        V f_ = v_k_240;
        args[0] = v_t_2454;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_y_2435);
    }
  }
  default: return heff_nomatch(v_x_2431);
  }
}