// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_BadShape 33347
#define TAG_Extra 49222
#define TAG_Help 25956
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_NoValue 57584
#define TAG_NotIn 31836
#define TAG_SwitchValue 32207
#define TAG_Unknown 64328
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_sh 10428
#define LBL_values 1123329101
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2ekeepIf_24s2034497759x755284100(V, V);
V g_list_2ekeepIf_24s2034497759x755284100_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2034497759x755284100_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
HeffT2 g_std_2ecli_2egroupsGo_24cpr(V, V);
HeffT2 g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr(V, V);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
HeffT2 g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(V, V);
V g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr_lam1(V self, V *args);
V g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr_lam0(V self, V *args);

HeffT2 g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr(V v_sh_240, V v_ws_241) {
top: ;
  V v_t_242 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL)));
  V v_at_243 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){heff_dup(v_sh_240), v_t_242, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  HeffT2 v_t_244 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(v_at_243, v_ws_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop_rec(v_sh_240, 2);
      V v_p_247 = v_field_246;
      heff_drop(v_p_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_sp_248 = v_field_246;
      V v_t_2416 = (g_list_2eall(heff_clo_n(g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr_lam0, 1, 1, (V[]){heff_dup(v_sp_248)}), heff_rfield(v_sh_240, 0)));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        HeffT2 v_t_2417 = (g_std_2ecli_2egroupsGo_24cpr(heff_get_n(v_sh_240, 1, 2), heff_dup(heff_rfield(v_sp_248, 0))));
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_gs1_2420 = v_field_2419;
            switch (heff_tag_of(v_gs1_2420)) {
            case TAG_Unknown: {
              heff_take_n(v_gs1_2420, 0ULL, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_NoValue: {
              heff_take_n(v_gs1_2420, 0ULL, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_SwitchValue: {
              heff_take_n(v_gs1_2420, 0ULL, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_Ambiguous: {
              heff_take_n(v_gs1_2420, 0ULL, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_MissingFlag: {
              heff_take_n(v_gs1_2420, 0ULL, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_NotIn: {
              heff_take_n(v_gs1_2420, 0ULL, 3);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_Missing: {
              heff_take_n(v_gs1_2420, 0ULL, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_Extra: {
              heff_take_n(v_gs1_2420, 0ULL, 1);
              heff_drop_rec(v_sp_248, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Help: {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            case TAG_BadShape: {
              heff_take_n(v_gs1_2420, 0ULL, 1);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
            }
            default: return ((HeffT2){{heff_nomatch(v_gs1_2420)}});
            }
          } else {
            V v_x_2434 = v_field_2419;
            heff_drop(v_x_2434);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_248}});
          }
        }
      } else {
        heff_drop_rec(v_sh_240, 2);
        heff_drop_rec(v_sp_248, 2);
        heff_drop(v_t_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
V g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_f_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V b_1 = heff_get_n(v_f_249, 4, 8); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, b_1)); heff_drop(v_v_2415); heff_drop(b_1); r_; });
}
V g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr_lam0(V self, V *args) {
  V v_f_249 = args[0];
  V v_sp_248 = heff_env(self)[0];
  V v_t_2410 = heff_dup(heff_rfield(v_f_249, 4));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_249, 8);
    heff_drop(self);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_ru_24t_2410_24Cons = heff_take_reuse_n(v_t_2410, 0ULL, 2);
    heff_clo_take(self, 1);
    V v_t_2413 = (g_list_2ekeepIf_24s2034497759x755284100(heff_dup(v_f_249), heff_get_n(v_sp_248, 1, 2)));
    V v_t_2414 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24t_2410_24Cons, v_t_2413));
    return ({ V a_0 = heff_clo_n(g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr_lam1, 1, 1, (V[]){v_f_249}); V a_1 = v_t_2414; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2414); r_; });
  }
  default: return heff_nomatch(v_t_2410);
  }
}