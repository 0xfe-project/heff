// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Collected 38917
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_Pend 2230
#define TAG_Posix 44191
#define TAG_Processors 11008
#define TAG_ReadFile 6783
#define TAG_RealPath 18882
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_loaded 849622832
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcome 1272833429
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_place 308106529
#define LBL_program 2069953735
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_reports 1326460931
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s948886493x1367785519(V, V, V);
V g_co_2eop_24s948886493x1367785519_entry(V self, V *a);
extern Clo g_co_2eop_24s948886493x1367785519_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_clo;
V g_heff_2ebuild_2edriver_2etestsOf(V);
V g_heff_2ebuild_2edriver_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestsOf_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2ebrokenJob(V, V);
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo;
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_clo;
V g_heff_2ebuild_2etesting_2eendedJob_24s1912007361x751786866(V, V, V, V);
V g_heff_2ebuild_2etesting_2eendedJob_24s1912007361x751786866_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eendedJob_24s1912007361x751786866_clo;
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void);
HeffT2 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void);
V g_heff_2ebuild_2etesting_2ejsonFailure(V);
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo;
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2etesting_2epassedOver(V, V);
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2epassedOver_clo;
HeffT2 g_heff_2ebuild_2etesting_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_clo;
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_clo;
V g_heff_2ebuild_2etesting_2erunReady_24s258215756x1850289317(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunReady_24s258215756x1850289317_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunReady_24s258215756x1850289317_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_clo;
V g_heff_2ebuild_2etesting_2etestDir(V, V);
V g_heff_2ebuild_2etesting_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestDir_clo;
V g_heff_2ebuild_2etesting_2etestExpecting_24s1212193572x365187574(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestExpecting_24s1212193572x365187574_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestExpecting_24s1212193572x365187574_clo;
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_clo;
V g_heff_2ebuild_2etesting_2etestOneC_24s908466055x952925079(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneC_24s908466055x952925079_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneC_24s908466055x952925079_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727(V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_clo;
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2emap_24s2029356170x1054793697(V);
V g_list_2emap_24s2029356170x1054793697_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(V);
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1283316583x974970592(V);
V g_std_2eprocess_2ewithProcess_24s1283316583x974970592_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1283316583x974970592_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str3, 0, "");

HeffT2 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V v_n_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_245;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_l_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 2);
      v_t_245 = v_l_243;
      break;
    }
    default: heff_nomatch(v_x2_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str1);
      break;
    }
    case TAG_Cons: {
      V v_l_246 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 2);
      v_t_248 = v_l_246;
      break;
    }
    default: heff_nomatch(v_x3_242);
    }
    V v_f_249 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_248});
    return ((HeffT2){{v_n_240, v_f_249}});
  }
  case TAG_Cons: {
    V v_a_2410 = heff_dup(heff_field(v_x2_241, 0));
    V v_argv_2411 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_a_2410);
      heff_drop(v_argv_2411);
      V v_t_2414;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_l_2412 = heff_field(v_x2_241, 0);
        heff_take_n(v_x2_241, 1ULL, 2);
        v_t_2414 = v_l_2412;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      V v_t_2417;
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_l_2415 = heff_field(v_x3_242, 0);
        heff_take_n(v_x3_242, 1ULL, 2);
        v_t_2417 = v_l_2415;
        break;
      }
      default: heff_nomatch(v_x3_242);
      }
      V v_f_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2417});
      return ((HeffT2){{v_n_240, v_f_2418}});
    }
    case TAG_Cons: {
      V v_b_2419 = heff_field(v_x3_242, 0);
      V v_bs_2420 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_strEq_c_lent(v_a_2410, v_b_2419, 0)) {
        heff_drop(v_a_2410);
        heff_drop(v_b_2419);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_argv_2411;
        V t_2 = v_bs_2420;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_argv_2411);
        heff_drop(v_bs_2420);
        return ((HeffT2){{v_n_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_a_2410, v_b_2419})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eintegrationMainName_str0, 20, "heffTestIntegrations");

static V g_heff_2ebuild_2etesting_2eintegrationMainName_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eintegrationMainName_st;
static V g_heff_2ebuild_2etesting_2eintegrationMainName_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eintegrationMainName_str0);
}
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eintegrationMainName_st)) return g_heff_2ebuild_2etesting_2eintegrationMainName_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eintegrationMainName_val, &g_heff_2ebuild_2etesting_2eintegrationMainName_st, g_heff_2ebuild_2etesting_2eintegrationMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str13, 0, "");
Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ejsonFailure_entry, 1, 0};

V g_heff_2ebuild_2etesting_2ejsonFailure(V v_j_240) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_j_240)) {
  case TAG_JNull: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_246 = heff_dup(heff_field(v_j_240, 0));
    HeffT2 v_t_247 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str0); V a_1 = v_fs_246; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_246); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_249;
        V v_t_2413;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_y_2412 = heff_field(v_p_2410, 1);
          heff_take_n(v_p_2410, 2ULL, 2);
          v_t_2413 = v_y_2412;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        switch (heff_tag_of(v_t_2413)) {
        case TAG_JNull: {
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2417 = heff_field(v_t_2413, 0);
          V v_ru_24t_2413_24JString = heff_take_reuse_n(v_t_2413, 1ULL, 1);
          v_t_2420 = heff_tag_at_n(v_ru_24t_2413_24JString, TAG_Just, 1, (V[]){v_s_2417});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_j_240)) {
    case TAG_JNull: {
      return NTAG(TAG_Nothing);
    }
    case TAG_JBool: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JInt: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JFloat: {
      heff_take_na(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JString: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JArray: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JObject: {
      V v_fs_2426 = heff_field(v_j_240, 0);
      V v_ru_24j_240_24JObject = heff_take_reuse_n(v_j_240, 1ULL, 1);
      HeffT2 v_t_2427 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str1); V a_1 = v_fs_2426; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2426); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_p_2430 = v_field_2429;
          V v_t_2433;
          switch (heff_tag_of(v_p_2430)) {
          case TAG_MkPair: {
            V v_y_2432 = heff_field(v_p_2430, 1);
            heff_take_n(v_p_2430, 2ULL, 2);
            v_t_2433 = v_y_2432;
            break;
          }
          default: heff_nomatch(v_p_2430);
          }
          switch (heff_tag_of(v_t_2433)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2438 = heff_field(v_t_2433, 0);
            heff_take_n(v_t_2433, 1ULL, 1);
            switch (heff_tag_of(v_xs_2438)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24j_240_24JObject, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2439 = heff_field(v_xs_2438, 0);
              V v_it12_2440 = heff_field(v_xs_2438, 1);
              V v_ru_24xs_2438_24Cons = heff_take_reuse_n(v_xs_2438, 3ULL, 2);
              switch (heff_tag_of(v_it12_2440)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24j_240_24JObject, 1);
                heff_drop(v_expected_2439);
                heff_drop_cell(v_ru_24xs_2438_24Cons, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2441 = heff_field(v_it12_2440, 0);
                heff_take_n(v_it12_2440, 1ULL, 2);
                V v_t_2449;
                switch (heff_tag_of(v_expected_2439)) {
                case TAG_JNull: {
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2446 = heff_field(v_expected_2439, 0);
                  heff_take_n(v_expected_2439, 1ULL, 1);
                  v_t_2449 = v_t_2446;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2439);
                }
                V v_t_2456;
                switch (heff_tag_of(v_got_2441)) {
                case TAG_JNull: {
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2453 = heff_field(v_got_2441, 0);
                  heff_take_n(v_got_2441, 1ULL, 1);
                  v_t_2456 = v_t_2453;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str13);
                  break;
                }
                default: heff_nomatch(v_got_2441);
                }
                return heff_tag_at_n(v_ru_24j_240_24JObject, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24xs_2438_24Cons, TAG_FailDiffer, 2, (V[]){v_t_2449, v_t_2456})});
              }
              default: return heff_nomatch(v_it12_2440);
              }
            }
            default: return heff_nomatch(v_xs_2438);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2433);
          }
        } else {
          heff_drop_cell(v_ru_24j_240_24JObject, 1);
          heff_drop(v_field_2429);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_j_240);
    }
  }
  case TAG_Just: {
    V v_why_2458 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    heff_drop(v_j_240);
    return heff_tag_at_n(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2458})});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ejsonFailure(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_247 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str0); V a_1 = v_fs_247; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_JNull: {
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          V v_b_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          v_t_2421 = v_b_2415;
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop(v_field_2410);
        v_t_2421 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2441;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2427 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2428 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str1); V a_1 = v_fs_2427; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2427); r_; });
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_p_2431 = v_field_2430;
        V v_t_2434;
        switch (heff_tag_of(v_p_2431)) {
        case TAG_MkPair: {
          V v_y_2433 = heff_field(v_p_2431, 1);
          heff_take_n(v_p_2431, 2ULL, 2);
          v_t_2434 = v_y_2433;
          break;
        }
        default: heff_nomatch(v_p_2431);
        }
        switch (heff_tag_of(v_t_2434)) {
        case TAG_JNull: {
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2438 = heff_field(v_t_2434, 0);
          V v_ru_24t_2434_24JString = heff_take_reuse_n(v_t_2434, 1ULL, 1);
          v_t_2441 = heff_tag_at_n(v_ru_24t_2434_24JString, TAG_Just, 1, (V[]){v_s_2438});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2434);
        }
      } else {
        heff_drop(v_field_2430);
        v_t_2441 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2461;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JBool: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JInt: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JFloat: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JString: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JArray: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JObject: {
    V v_fs_2447 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2448 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str2); V a_1 = v_fs_2447; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2447); r_; });
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        V v_p_2451 = v_field_2450;
        V v_t_2454;
        switch (heff_tag_of(v_p_2451)) {
        case TAG_MkPair: {
          V v_y_2453 = heff_field(v_p_2451, 1);
          heff_take_n(v_p_2451, 2ULL, 2);
          v_t_2454 = v_y_2453;
          break;
        }
        default: heff_nomatch(v_p_2451);
        }
        switch (heff_tag_of(v_t_2454)) {
        case TAG_JNull: {
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JArray: {
          V v_xs_2459 = heff_field(v_t_2454, 0);
          heff_take_n(v_t_2454, 1ULL, 1);
          v_t_2461 = v_xs_2459;
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2454);
        }
      } else {
        heff_drop(v_field_2450);
        v_t_2461 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2462 = (g_list_2emap_24s1113395621x248103432(v_t_2461));
  V v_t_2476;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2468 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2469 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str3); V a_1 = v_fs_2468; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2468); r_; });
    {
      V v_field_2471 = v_t_2469.f[1];
      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
      if ((v_tag_2470 == ((int64_t)0ULL))) {
        V v_p_2472 = v_field_2471;
        V v_t_2475;
        switch (heff_tag_of(v_p_2472)) {
        case TAG_MkPair: {
          V v_y_2474 = heff_field(v_p_2472, 1);
          heff_take_n(v_p_2472, 2ULL, 2);
          v_t_2475 = v_y_2474;
          break;
        }
        default: heff_nomatch(v_p_2472);
        }
        v_t_2476 = (g_heff_2ebuild_2etesting_2ejsonFailure(v_t_2475));
      } else {
        heff_drop(v_field_2471);
        v_t_2476 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2478 = ({ V a_0 = v_t_2477; V a_1 = v_j_241; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2477, 2); r_; });
  V v_t_2488;
  {
    V v_field_2480 = v_t_2478.f[1];
    int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
    if ((v_tag_2479 == ((int64_t)0ULL))) {
      V v_it1_2481 = v_field_2480;
      switch (heff_tag_of(v_it1_2481)) {
      case TAG_JNull: {
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2486 = heff_field(v_it1_2481, 0);
        heff_take_n(v_it1_2481, 1ULL, 1);
        v_t_2488 = v_xs_2486;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2481);
      }
    } else {
      heff_drop(v_field_2480);
      v_t_2488 = NTAG(TAG_Nil);
    }
  }
  V v_t_2489 = (g_list_2emap_24s2029356170x1054793697(v_t_2488));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2421, v_t_2441, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2462, v_t_2476, MK_INT(0LL), v_t_2489});
}
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eoutcomeOfJson(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2etesting_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eoutcomeVariable_st;
static V g_heff_2ebuild_2etesting_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eoutcomeVariable_st)) return g_heff_2ebuild_2etesting_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eoutcomeVariable_val, &g_heff_2ebuild_2etesting_2eoutcomeVariable_st, g_heff_2ebuild_2etesting_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str1, 3, " / ");
Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry, 5, 0};

V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    V v_s_248 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str0); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str1), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_247, v_t_249, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2411 = ({ V a_0 = v_sel_240; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2etesting_2elevelsSelected(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, NTAG(TAG_Nil)});
      V v_t_2415 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2414));
      V v_t_2416 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2413, heff_dup(heff_rfield(v_j_241, 3)), v_t_2415, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_cell_2417;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_d_244;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2esubtestJobs_24dps(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ebrokenJob_str0, 3, " / ");
Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebrokenJob_entry, 2, 0};

V g_heff_2ebuild_2etesting_2ebrokenJob(V v_j_240, V v_why_241) {
top: ;
  V v_owner_242 = heff_take_field(v_j_240, 0);
  V v_place_243 = heff_take_field(v_j_240, 2);
  V v_top_244 = heff_take_field(v_j_240, 3);
  V v_path_245 = heff_get_n(v_j_240, 4, 6);
  V v_name_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ebrokenJob_str0); V a_1 = v_top_244; V a_2 = v_path_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_path_245); r_; });
  V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_241})});
  V v_t_248 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_246, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247, MK_INT(0LL), NTAG(TAG_Nil)});
  return heff_rec_n(4, shape_owner__place__outcome__next, (V[]){v_owner_242, v_place_243, v_t_248, NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ebrokenJob(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str2, 17, "heff test: --run ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str5, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str6, 0, "");
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam2, 2, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam7(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam7, 1, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_update_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_pattern_241, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
  HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
  V v_c_2430;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_why_2411 = v_field_2410;
      v_c_2430 = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam0, 2, 2, (V[]){heff_dup(v_pattern_241), v_why_2411});
    } else {
      V v_x_2427 = v_field_2410;
      heff_drop(v_x_2427);
      v_c_2430 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam3, 2, 5, (V[]){v_c_2430, heff_dup(v_seed_240), heff_dup(v_pattern_241), heff_dup(v_jobs_242), v_update_243});
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(2LL), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_pattern_241 = heff_env(self)[0];
  V v_why_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str2), v_t_2415), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str3));
  V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, v_why_2411), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str4));
  V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  args[0] = v_t_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam1, 1, 2, (V[]){v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam5(V self, V *args) {
  V v_n_2434 = args[0];
  return v_n_2434;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam7(V self, V *args) {
  V v_v_2444 = args[0];
  return v_v_2444;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam8(V self, V *args) {
  V v_x_2453 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_pattern_241 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2432 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2459;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_2459 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2454 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    HeffT2 v_t_2455 = ({ V a_0 = v_s_2454; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2454); r_; });
    {
      V v_field_2457 = v_t_2455.f[1];
      int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
      if ((v_tag_2456 == ((int64_t)0ULL))) {
        V v_x_2458 = v_field_2457;
        v_t_2459 = v_x_2458;
      } else {
        heff_drop(v_field_2457);
        v_t_2459 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2461;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2461 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2460 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_fallback_2462;
  if (heff_intLt_c(heff_intDiv(heff_dup(v_x_2443), MK_INT(2LL)), MK_INT(1LL))) {
    heff_drop(v_x_2443);
    v_fallback_2462 = MK_INT(1LL);
  } else {
    v_fallback_2462 = heff_intDiv(v_x_2443, MK_INT(2LL));
  }
  V v_fallback_2468;
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Nothing: {
    v_fallback_2468 = v_fallback_2462;
    break;
  }
  case TAG_Just: {
    V v_n_2463 = heff_field(v_x_2453, 0);
    heff_take_n(v_x_2453, 1ULL, 1);
    HeffT2 v_t_2464 = ({ V a_0 = v_n_2463; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2463); r_; });
    {
      V v_field_2466 = v_t_2464.f[1];
      int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
      if ((v_tag_2465 == ((int64_t)0ULL))) {
        V v_k_2467 = v_field_2466;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2467, 1)) {
          heff_drop(v_fallback_2462);
          v_fallback_2468 = v_k_2467;
        } else {
          heff_drop(v_k_2467);
          v_fallback_2468 = v_fallback_2462;
        }
      } else {
        heff_drop(v_field_2466);
        v_fallback_2468 = v_fallback_2462;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2453);
  }
  V v_t_2474;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2474 = v_fallback_2468;
    break;
  }
  case TAG_Just: {
    V v_n_2469 = heff_field(v_jobs_242, 0);
    heff_take_n(v_jobs_242, 1ULL, 1);
    HeffT2 v_t_2470 = ({ V a_0 = v_n_2469; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2469); r_; });
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        V v_k_2473 = v_field_2472;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2473, 1)) {
          heff_drop(v_fallback_2468);
          v_t_2474 = v_k_2473;
        } else {
          heff_drop(v_k_2473);
          v_t_2474 = v_fallback_2468;
        }
      } else {
        heff_drop(v_field_2472);
        v_t_2474 = v_fallback_2468;
      }
    }
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_x_2475 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_t_2459, v_t_2461, v_t_2474, v_update_243});
  V f_ = v_k_2432;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2431 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2432 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_str5), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam7_clo)})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2431, 2), 1, (V[]){v_t_2451}));
  V f_ = heff_get_n(v_hd_2431, 1, 3);
  heff_room[0] = v_t_2452;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam8, 1, 6, (V[]){v_seed_240, v_pattern_241, v_x_2443, v_jobs_242, v_update_243, v_k_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2431 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2432 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2433);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Processors, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam5_clo)})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2431, 2)), 1, (V[]){v_t_2441}));
  V f_ = heff_dup(heff_rfield(v_hd_2431, 1));
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam6, 1, 6, (V[]){v_hd_2431, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s533402362x582155387_lam4, 1, 6, (V[]){v_hd_2431, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_str1, 30, "its program could not be run: ");
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam9(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_entry, 5, 0};

V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046(V v_sel_240, V v_j_241, V v_dir_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_j_241, 1)), 0, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_241, 3)), heff_dup(heff_rfield(v_j_241, 4))});
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_242)));
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_str0))});
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_j_241, 1)), 1, 2);
  V v_t_2410 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_245, v_t_246, v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_249}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_241, 5)), MK_INT(0LL), NTAG(TAG_True)});
  V v_c_2411 = (g_std_2eprocess_2ewithProcess_24s1283316583x974970592(v_t_2410));
  V v_k_2412 = heff_dup(heff_rfield(v_z_243, 0));
  V v_t_2419 = heff_tr(heff_call(v_c_2411, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam0, 1, 5, (V[]){heff_dup(v_sel_240), heff_dup(v_j_241), heff_dup(v_dir_242), heff_dup(v_z_243), v_k_2412})}));
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2419, heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam3, 1, 3, (V[]){v_dir_242, heff_dup(v_z_243), v_j_241})})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
  return heff_tail(heff_dup(heff_rfield(v_z_243, 1)), 2, (V[]){v_t_2446, heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam9, 1, 2, (V[]){v_z_243, v_z_244})});
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2416);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam2, 3, 1, (V[]){v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sel_240 = heff_env(self)[0];
  V v_j_241 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = ({ V a_0 = v_sel_240; V a_1 = v_j_241; V a_2 = v_dir_242; V a_3 = v_x_2413; V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s1912007361x751786866(a_0, a_1, a_2, a_3)); heff_drop(v_sel_240); r_; });
  V f_ = v_c_2414;
  heff_room[0] = v_z_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam1, 1, 1, (V[]){v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam4(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_x_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_err_2432 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    V v_t_2433 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2432})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2433));
  }
  case TAG_Right: {
    V v_x_2434 = heff_field(v_x_2431, 0);
    heff_take_n(v_x_2431, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam6, 2, 1, (V[]){v_x_2434});
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2443 = args[1];
  V v_k_2444 = args[2];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2442);
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_s_2420 = heff_env(self)[0];
  V v_j_241 = heff_env(self)[1];
  V v_k_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_str1), heff_get_n(v_s_2420, 2, 3));
  V v_x_2441 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_241, v_t_2440));
  V f_ = v_k_2438;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam8, 3, 1, (V[]){v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_242));
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
  V v_a_2424 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam4_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_c_2437 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam5_clo)));
  V v_k_2438 = heff_dup(heff_rfield(v_z_243, 0));
  V f_ = v_c_2437;
  heff_room[0] = v_z_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam7, 1, 3, (V[]){v_s_2420, v_j_241, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2447;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_z_243;
  heff_room[2] = v_z_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_str1, 4, "heff");
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_entry, 6, 0};

V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479(V v_opts_240, V v_f_241, V v_x3_242, V v_l_243, V v_z_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x3_242) == NTAG(TAG_True))) {
    if (!heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_str0))) {
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_f_241);
      heff_drop_rec(v_l_243, 5);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())})});
    } else {
      heff_drop_rec(v_opts_240, 4);
      V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_243)));
      return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam0, 1, 4, (V[]){v_l_243, v_f_241, v_z_244, v_z_245})});
    }
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_str1), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam2, 1, 5, (V[]){v_l_243, v_z_244, v_opts_240, v_f_241, v_z_245})));
  }
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = heff_tag_n(TAG_Settled, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_get_n(v_l_243, 1, 5);
  V v_t_2411;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    v_t_2411 = ({ V b_0 = heff_get_n(v_x_247, 0, 2); V r_ = (g_list_2eany_24s1740858080x874135214(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_248, 0ULL, 2);
    heff_drop_rec(v_x_247, 2);
    v_t_2411 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  return ({ V a_0 = v_f_241; V a_1 = v_t_2411; V a_2 = v_z_244; V a_3 = heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam1, 1, 1, (V[]){v_z_245}); V r_ = (g_heff_2ebuild_2etesting_2etestExpecting_24s1212193572x365187574(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_l_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_l_243; V b_3 = heff_get_n(v_x_2415, 0, 2); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2ebuild_2etesting_2etestOneC_24s908466055x952925079(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_c_2414 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_243)));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479_lam3, 1, 5, (V[]){v_opts_240, v_f_241, v_l_243, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str3, 1, "\012");
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_entry, 2, 0};

V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727(V v_opts_240, V v_f_241) {
top: ;
  V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_241)));
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_242); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam0_clo)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_c_2418 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam3, 2, 3, (V[]){v_c_2418, v_f_241, v_opts_240});
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727(a[0], a[1]);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2414));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam2, 2, 1, (V[]){v_x_2415});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_2419 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_j_2425 = heff_strFind(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str0), ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str1), MK_INT(0LL));
  V v_t_2426;
  if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
    heff_drop(v_j_2425);
    v_t_2426 = MK_INT(0LL);
  } else {
    v_t_2426 = v_j_2425;
  }
  V v_t_2427 = heff_bool(heff_strEq_c(heff_strSlice_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str2), MK_INT(0LL), v_t_2426, 3), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_t_2426);
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_t_2427; V a_3 = v_x_2424; V a_4 = v_hd_2419; V a_5 = v_k_2420; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2427); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_y_2428 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_d_2431 = heff_strLength_lent(v_y_2428, 0);
  V v_j_2432 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_str3), v_y_2428, MK_INT(0LL), 5);
  V v_t_2433;
  if (heff_intLt_c_lent(v_j_2432, MK_INT(0LL), 2)) {
    heff_drop(v_j_2432);
    v_t_2433 = v_d_2431;
  } else {
    heff_drop(v_d_2431);
    v_t_2433 = v_j_2432;
  }
  V v_t_2434 = heff_bool(heff_strEq_c(heff_strSlice_lent(v_y_2428, MK_INT(0LL), v_t_2433, 2), heff_dup(g_heff_2ebuild_2etesting_2eexpectErrorsLine_get())));
  heff_drop(v_y_2428);
  heff_drop(v_t_2433);
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_t_2434; V a_3 = v_x_2430; V a_4 = v_hd_2419; V a_5 = v_k_2420; V r_ = (g_heff_2ebuild_2etesting_2etestLoaded_24s673369584x761750479(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2434); r_; });
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    V v_c_2423 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_241)));
    V f_ = v_c_2423;
    heff_room[0] = heff_dup(v_hd_2419);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam5, 1, 4, (V[]){v_opts_240, v_f_241, v_hd_2419, v_k_2420});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    V v_c_2429 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_241)));
    V f_ = v_c_2429;
    heff_room[0] = heff_dup(v_hd_2419);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam6, 1, 5, (V[]){v_y_2428, v_opts_240, v_f_241, v_hd_2419, v_k_2420});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727_lam4, 1, 4, (V[]){v_f_241, v_hd_2419, v_opts_240, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str0, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str1, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str2, 13, "Integrations\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str3, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str4, 17, "integrationMain [");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str6, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str7, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str8, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str9, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str10, 4, "main");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str11, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str12, 4, "main");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str13, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str14, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str15, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str16, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str18, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str19, 1, "1");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str20, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str21, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str22, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str23, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str24, 45, "its file does not import check, which runs it");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str25, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str26, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str27, 34, "its file is not among those loaded");
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam12(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam12, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam14(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam14, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam16(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam15(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam13(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam11(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam21(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam20(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam19(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam18(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam17(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam23(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam22(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam25(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam24(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam27(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam26(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_entry, 6, 0};

V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075(V v_opts_240, V v_at_241, V v_p_242, V v_k_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_242, 5)), 0, 5);
  HeffT2 v_t_247 = ({ V a_0 = heff_dup(v_p_242); V a_1 = v_t_246; HeffT2 r_ = (g_list_2efind_24s595925281x993936542_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_src_2410 = v_field_249;
      V v_p_2411 = heff_dup(v_p_242);
      V v_loaded_2412 = heff_take_field(v_p_2411, 5);
      V v_checked_2413 = heff_get_n(v_p_2411, 6, 7);
      V v_src_2414 = v_src_2410;
      V v_renames_2415 = heff_take_field(v_src_2414, 5);
      V v_implicit_2416 = heff_take_field(v_src_2414, 6);
      V v_source_2417 = heff_get_n(v_src_2414, 4, 8);
      V v_t_2418 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2416, v_source_2417));
      HeffT4 v_t_2419 = ({ V a_0 = v_renames_2415; V a_1 = v_t_2418; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_2415); r_; });
      V v_t_2424;
      {
        V v_field_2420 = v_t_2419.f[0];
        heff_drop(v_t_2419.f[1]);
        heff_drop(v_t_2419.f[2]);
        heff_drop(v_t_2419.f[3]);
        v_t_2424 = v_field_2420;
      }
      HeffT2 v_t_2425 = ({ V a_0 = v_t_2424; HeffT2 r_ = (g_heff_2ebuild_2etesting_2equalifierOf_24cpr(a_0)); heff_drop(v_t_2424); r_; });
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_q_2428 = v_field_2427;
          V v_l_2429 = heff_dup(v_loaded_2412);
          V v_q_2430 = v_q_2428;
          V v_ts_2431 = (g_heff_2ebuild_2edriver_2etestsOf(heff_dup(v_checked_2413)));
          V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str0), heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str1));
          V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, heff_dup(v_q_2430)), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str2));
          V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str3));
          V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, v_q_2430), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str4));
          V v_x2_2436 = (g_list_2emap_24s467798769x1763085075(v_ts_2431));
          V v_t_2439;
          switch (heff_tag_of(v_x2_2436)) {
          case TAG_Nil: {
            v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str5);
            break;
          }
          case TAG_Cons: {
            V v_x_2437 = heff_field(v_x2_2436, 0);
            V v_xs_2438 = heff_field(v_x2_2436, 1);
            heff_take_n(v_x2_2436, 3ULL, 2);
            v_t_2439 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str6); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2436);
          }
          V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2435, v_t_2439), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str7));
          V v_sources_2441 = ({ V b_0 = heff_get_n(v_checked_2413, 0, 14); V a_1 = v_t_2440; V a_2 = heff_get_n(v_loaded_2412, 0, 5); V r_ = (g_list_2emap_24s1681408447x1763680441(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          V v_l_2442 = ({ V rv_0 = v_sources_2441; V rr_ = heff_rec_reuse_nf(v_l_2429, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2443 = heff_strAppend(heff_dup(heff_rfield(v_p_242, 0)), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str8));
          V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2443, MK_INT(2LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam0_clo)})});
          V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
          V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){v_t_2446}));
          return heff_tail(heff_dup(heff_rfield(v_z_244, 1)), 2, (V[]){v_t_2447, heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam1, 1, 7, (V[]){v_z_244, v_l_2442, v_p_242, v_opts_240, v_k_243, v_at_241, v_z_245})});
        } else {
          heff_drop(v_at_241);
          heff_drop_rec(v_loaded_2412, 5);
          heff_drop_rec(v_checked_2413, 14);
          heff_drop(v_field_2427);
          V v_why_24152 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str24);
          V v_more_24153 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str25), v_why_24152, MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
          V v_t_24154 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_24153));
          V v_c_24155 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_24154));
          return heff_tail(v_c_24155, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam24, 1, 5, (V[]){v_opts_240, v_k_243, v_z_244, v_z_245, v_p_242})});
        }
      }
    } else {
      heff_drop(v_at_241);
      heff_drop(v_field_249);
      V v_more_24159 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str26), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str27), MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
      V v_t_24160 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_24159));
      V v_c_24161 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_24160));
      return heff_tail(v_c_24161, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam26, 1, 5, (V[]){v_opts_240, v_k_243, v_z_244, v_z_245, v_p_242})});
    }
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam0(V self, V *args) {
  V v_t_2444 = args[0];
  return v_t_2444;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam2(V self, V *args) {
  V v_t_2449 = args[0];
  return v_t_2449;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam4(V self, V *args) {
  V v_r_2474 = args[0];
  return v_r_2474;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam8(V self, V *args) {
  V v_x_2491 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_hd_2480 = heff_env(self)[1];
  V v_k_2481 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2491});
  heff_room[1] = v_hd_2480;
  heff_room[2] = v_k_2481;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam7(V self, V *args) {
  V v_x_2489 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_hd_2480 = heff_env(self)[2];
  V v_k_2481 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2490 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_2489)));
  if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
    heff_drop(v_x_2489);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_2490);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_hd_2480;
    heff_room[2] = v_k_2481;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2490);
    return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_2489, heff_dup(v_hd_2480), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam8, 1, 3, (V[]){v_k_243, v_hd_2480, v_k_2481})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam6(V self, V *args) {
  V v_x_2485 = args[0];
  V v_why_2479 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_hd_2480 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_k_2481 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2485);
  V v_more_2486 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str15), v_why_2479, MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
  V v_t_2487 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_2486));
  V v_c_2488 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_2487));
  V f_ = v_c_2488;
  heff_room[0] = heff_dup(v_hd_2480);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam7, 1, 5, (V[]){v_opts_240, v_k_243, v_hd_2480, v_k_2481, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam5(V self, V *args) {
  V v_why_2479 = args[0];
  V v_hd_2480 = args[1];
  V v_k_2481 = args[2];
  V v_x_2448 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2482 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2480, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_dup(heff_rfield(v_hd_2480, 1));
  args[0] = v_t_2484;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam6, 1, 6, (V[]){v_why_2479, v_p_242, v_opts_240, v_hd_2480, v_k_243, v_k_2481});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam12(V self, V *args) {
  V v_r_2498 = args[0];
  return v_r_2498;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam14(V self, V *args) {
  V v_r_24106 = args[0];
  return v_r_24106;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam16(V self, V *args) {
  V v_x_24114 = args[0];
  V v_x_2494 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  V v_x_24102 = heff_env(self)[2];
  V v_x_2495 = heff_env(self)[3];
  V v_x_24110 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_p_242 = heff_env(self)[6];
  V v_k_243 = heff_env(self)[7];
  V v_hd_2492 = heff_env(self)[8];
  V v_k_2493 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24114);
  V v_t_24118;
  switch (heff_tag_of(v_x_2494)) {
  case TAG_Left: {
    heff_take_n(v_x_2494, 0ULL, 1);
    v_t_24118 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str17);
    break;
  }
  case TAG_Right: {
    V v_real_24116 = heff_field(v_x_2494, 0);
    heff_take_n(v_x_2494, 1ULL, 1);
    V v_t_24117 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
    v_t_24118 = ({ V a_0 = v_t_24117; V a_1 = v_real_24116; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24117); heff_drop(v_real_24116); r_; });
    break;
  }
  default: heff_nomatch(v_x_2494);
  }
  V v_t_24122;
  switch (heff_tag_of(v_x_24102)) {
  case TAG_Left: {
    heff_take_n(v_x_24102, 0ULL, 1);
    v_t_24122 = v_x_2495;
    break;
  }
  case TAG_Right: {
    V v_real_24120 = heff_field(v_x_24102, 0);
    heff_take_n(v_x_24102, 1ULL, 1);
    heff_drop(v_x_2495);
    V v_t_24121 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
    v_t_24122 = ({ V a_0 = v_t_24121; V a_1 = v_real_24120; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24121); heff_drop(v_real_24120); r_; });
    break;
  }
  default: heff_nomatch(v_x_24102);
  }
  V v_t_24126;
  switch (heff_tag_of(v_x_24110)) {
  case TAG_Left: {
    heff_take_n(v_x_24110, 0ULL, 1);
    v_t_24126 = heff_get_n(heff_get_n(v_l_2442, 2, 5), 0, 6);
    break;
  }
  case TAG_Right: {
    V v_real_24124 = heff_field(v_x_24110, 0);
    heff_take_n(v_x_24110, 1ULL, 1);
    V v_t_24125 = heff_get_n(heff_get_n(v_l_2442, 2, 5), 5, 6);
    v_t_24126 = ({ V a_0 = v_t_24125; V a_1 = v_real_24124; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24125); heff_drop(v_real_24124); r_; });
    break;
  }
  default: heff_nomatch(v_x_24110);
  }
  V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str18), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str19)}), NTAG(TAG_Nil)});
  V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str20), v_t_24126}), v_t_24127});
  V v_t_24129 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str21), v_t_24122}), v_t_24128});
  V v_t_24130 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_241, v_p_242, heff_rec_n(2, shape_program__env, (V[]){v_t_24118, v_t_24129})});
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24130});
  heff_room[1] = v_hd_2492;
  heff_room[2] = v_k_2493;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam15(V self, V *args) {
  V v_x_24110 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_hd_2492 = heff_env(self)[1];
  V v_x_2494 = heff_env(self)[2];
  V v_l_2442 = heff_env(self)[3];
  V v_x_24102 = heff_env(self)[4];
  V v_x_2495 = heff_env(self)[5];
  V v_at_241 = heff_env(self)[6];
  V v_p_242 = heff_env(self)[7];
  V v_k_243 = heff_env(self)[8];
  V v_k_2493 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_24111 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2492, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_dup(heff_rfield(v_hd_2492, 1));
  heff_room[0] = v_t_24113;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam16, 1, 10, (V[]){v_x_2494, v_l_2442, v_x_24102, v_x_2495, v_x_24110, v_at_241, v_p_242, v_k_243, v_hd_2492, v_k_2493});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam13(V self, V *args) {
  V v_x_24102 = args[0];
  V v_l_2442 = heff_env(self)[0];
  V v_hd_2492 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_x_2494 = heff_env(self)[3];
  V v_x_2495 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_p_242 = heff_env(self)[6];
  V v_k_243 = heff_env(self)[7];
  V v_k_2493 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_24103 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 0, 6);
  V v_path_24104 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_t_24103));
  V v_t_24105 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24104; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24104); r_; });
  V v_p_231002_24107 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_24105, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam14_clo)});
  V v_t_24108 = heff_tr(heff_call(((V)&g_co_2eop_24s948886493x1367785519_clo), 1, (V[]){v_p_231002_24107}));
  V v_c_24109 = heff_tr(g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(v_t_24108));
  V f_ = v_c_24109;
  heff_room[0] = heff_dup(v_hd_2492);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam15, 1, 10, (V[]){v_x_2448, v_hd_2492, v_x_2494, v_l_2442, v_x_24102, v_x_2495, v_at_241, v_p_242, v_k_243, v_k_2493});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam11(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_2492 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_x_2494 = heff_env(self)[3];
  V v_at_241 = heff_env(self)[4];
  V v_p_242 = heff_env(self)[5];
  V v_k_243 = heff_env(self)[6];
  V v_k_2493 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2496 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2495)));
  V v_t_2497 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2496; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2496); r_; });
  V v_p_231002_2499 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2497, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam12_clo)});
  V v_t_24100 = heff_tr(heff_call(((V)&g_co_2eop_24s948886493x1367785519_clo), 1, (V[]){v_p_231002_2499}));
  V v_c_24101 = heff_tr(g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(v_t_24100));
  V f_ = v_c_24101;
  heff_room[0] = heff_dup(v_hd_2492);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam13, 1, 9, (V[]){v_l_2442, v_hd_2492, v_x_2448, v_x_2494, v_x_2495, v_at_241, v_p_242, v_k_243, v_k_2493});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam10(V self, V *args) {
  V v_x_2494 = args[0];
  V v_hd_2492 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_at_241 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  V v_k_2493 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_2492), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam11, 1, 8, (V[]){v_hd_2492, v_l_2442, v_x_2448, v_x_2494, v_at_241, v_p_242, v_k_243, v_k_2493})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam9(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_c_2477 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_at_241 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2477;
  args[0] = heff_dup(v_hd_2492);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam10, 1, 7, (V[]){v_hd_2492, v_l_2442, v_x_2448, v_at_241, v_p_242, v_k_243, v_k_2493});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam21(V self, V *args) {
  V v_x_24148 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_hd_24133 = heff_env(self)[1];
  V v_k_24134 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24148});
  heff_room[1] = v_hd_24133;
  heff_room[2] = v_k_24134;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam20(V self, V *args) {
  V v_x_24146 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_hd_24133 = heff_env(self)[2];
  V v_k_24134 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24147 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_24146)));
  if ((heff_dup(v_t_24147) == NTAG(TAG_True))) {
    heff_drop(v_x_24146);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_24147);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_hd_24133;
    heff_room[2] = v_k_24134;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24147);
    return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_24146, heff_dup(v_hd_24133), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam21, 1, 3, (V[]){v_k_243, v_hd_24133, v_k_24134})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam19(V self, V *args) {
  V v_x_24142 = args[0];
  V v_why_24132 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_hd_24133 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_k_24134 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24142);
  V v_more_24143 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str22), v_why_24132, MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
  V v_t_24144 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_24143));
  V v_c_24145 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_24144));
  V f_ = v_c_24145;
  heff_room[0] = heff_dup(v_hd_24133);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam20, 1, 5, (V[]){v_opts_240, v_k_243, v_hd_24133, v_k_24134, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam18(V self, V *args) {
  V v_x_24138 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_hd_24133 = heff_env(self)[1];
  V v_why_24132 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_opts_240 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  V v_k_24134 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24138);
  V v_t_24139 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
  V v_t_24141 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24133, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24140})}));
  V f_ = heff_dup(heff_rfield(v_hd_24133, 1));
  heff_room[0] = v_t_24141;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam19, 1, 6, (V[]){v_why_24132, v_p_242, v_opts_240, v_hd_24133, v_k_243, v_k_24134});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam17(V self, V *args) {
  V v_why_24132 = args[0];
  V v_hd_24133 = args[1];
  V v_k_24134 = args[2];
  V v_x_2453 = heff_env(self)[0];
  V v_x_2448 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24135 = heff_tag_n(TAG_End, 2, (V[]){v_x_2453, NTAG(TAG_MkUnit)});
  V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24133, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24136})}));
  V f_ = heff_dup(heff_rfield(v_hd_24133, 1));
  args[0] = v_t_24137;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam18, 1, 7, (V[]){v_x_2448, v_hd_24133, v_why_24132, v_p_242, v_opts_240, v_k_243, v_k_24134});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam23(V self, V *args) {
  V v_x_24151 = args[0];
  V v_next_24131 = heff_env(self)[0];
  V v_hd_24149 = heff_env(self)[1];
  V v_k_24150 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24151);
  V f_ = v_next_24131;
  heff_room[0] = v_hd_24149;
  heff_room[1] = v_k_24150;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam22(V self, V *args) {
  V v_hd_24149 = args[0];
  V v_k_24150 = args[1];
  V v_x_2453 = heff_env(self)[0];
  V v_next_24131 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2453, heff_dup(v_hd_24149), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam23, 1, 3, (V[]){v_next_24131, v_hd_24149, v_k_24150})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam3(V self, V *args) {
  V v_x_2453 = args[0];
  V v_l_2442 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2454 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2442, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_dir_2455 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2442, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_d_2456 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2442, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_st_2457 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
  V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_2457), v_d_2456));
  V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
  V v_t_2460;
  switch (heff_tag_of(v_t_2459)) {
  case TAG_Posix: {
    v_t_2460 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str10);
    break;
  }
  case TAG_Windows: {
    v_t_2460 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str11);
    break;
  }
  default: heff_nomatch(v_t_2459);
  }
  V v_t_2461 = (g_std_2epath_2eparse(heff_dup(v_st_2457), v_t_2460));
  V v_t_2462 = (g_std_2epath_2ejoin(v_t_2458, v_t_2461));
  V v_out_2463 = ({ V a_0 = v_st_2457; V a_1 = v_t_2462; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2457); heff_drop(v_t_2462); r_; });
  V v_d_2464 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2442, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_st_2465 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
  V v_t_2466 = (g_std_2epath_2eparse(heff_dup(v_st_2465), v_d_2464));
  V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
  V v_t_2468;
  switch (heff_tag_of(v_t_2467)) {
  case TAG_Posix: {
    v_t_2468 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str12);
    break;
  }
  case TAG_Windows: {
    v_t_2468 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str13);
    break;
  }
  default: heff_nomatch(v_t_2467);
  }
  V v_t_2469 = (g_std_2epath_2eparse(heff_dup(v_st_2465), v_t_2468));
  V v_t_2470 = (g_std_2epath_2ejoin(v_t_2466, v_t_2469));
  V v_s_2471 = ({ V a_0 = v_st_2465; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2465); heff_drop(v_t_2470); r_; });
  V v_path_2472 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2471));
  V v_t_2473 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2472; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2472); r_; });
  V v_p_231002_2475 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2473, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam4_clo)});
  V v_t_2476 = heff_tr(heff_call(((V)&g_co_2eop_24s948886493x1367785519_clo), 1, (V[]){v_p_231002_2475}));
  V v_c_2477 = heff_tr(g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(v_t_2476));
  V v_t_2478 = heff_get_n(heff_dup(heff_rfield(v_l_2442, 2)), 5, 6);
  V v_next_24131 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616(((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str14), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam5, 3, 4, (V[]){heff_dup(v_x_2448), heff_dup(v_p_242), heff_dup(v_opts_240), heff_dup(v_k_243)}), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str16), v_t_2478, heff_dup(v_x_2448), v_dir_2455, v_out_2463, heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam9, 2, 6, (V[]){v_c_2477, heff_dup(v_l_2442), heff_dup(v_x_2448), v_at_241, heff_dup(v_p_242), heff_dup(v_k_243)})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532(heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam17, 3, 5, (V[]){heff_dup(v_x_2453), v_x_2448, heff_dup(v_p_242), v_opts_240, v_k_243}), v_l_2442, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())}), heff_strAppend(v_t_2454, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str23)), heff_get_n(v_p_242, 0, 7), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam22, 2, 2, (V[]){v_x_2453, v_next_24131}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam1(V self, V *args) {
  V v_x_2448 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2448), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_str9), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam2_clo)})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){v_t_2451}));
  V f_ = heff_dup(heff_rfield(v_z_244, 1));
  heff_room[0] = v_t_2452;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam3, 1, 8, (V[]){v_l_2442, v_p_242, v_x_2448, v_opts_240, v_k_243, v_at_241, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam25(V self, V *args) {
  V v_x_24158 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24158});
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam24(V self, V *args) {
  V v_x_24156 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24157 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_24156)));
  if ((heff_dup(v_t_24157) == NTAG(TAG_True))) {
    heff_drop(v_x_24156);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_24157);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_z_244;
    heff_room[2] = v_z_245;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24157);
    return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_24156, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam25, 1, 3, (V[]){v_k_243, v_z_244, v_z_245})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam27(V self, V *args) {
  V v_x_24164 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24164});
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam26(V self, V *args) {
  V v_x_24162 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24163 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_24162)));
  if ((heff_dup(v_t_24163) == NTAG(TAG_True))) {
    heff_drop(v_x_24162);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_24163);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_z_244;
    heff_room[2] = v_z_245;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24163);
    return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_24162, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075_lam27, 1, 3, (V[]){v_k_243, v_z_244, v_z_245})));
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_entry, 7, 0};

V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235(V v_tk_240, V v_opts_241, V v_x3_242, V v_acc_243, V v_ready_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_t_247 = heff_tag_n(TAG_End, 2, (V[]){v_tk_240, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
    return heff_tail(heff_dup(heff_rfield(v_p_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam0, 1, 5, (V[]){v_opts_241, v_ready_244, v_acc_243, v_p_245, v_p_246})});
  }
  case TAG_Cons: {
    V v_f_2412 = heff_field(v_x3_242, 0);
    V v_rest_2413 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_tk_240), heff_dup(v_f_2412), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam2_clo)})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_245, 2)), 1, (V[]){v_t_2416}));
    return heff_tail(heff_dup(heff_rfield(v_p_245, 1)), 2, (V[]){v_t_2417, heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam3, 1, 8, (V[]){v_opts_241, v_f_2412, v_p_245, v_ready_244, v_acc_243, v_tk_240, v_rest_2413, v_p_246})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2etesting_2etestSummary_24s1245898028x1457518731(v_opts_241, v_x_2411, v_p_245, v_p_246));
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_ready_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2etesting_2erunReady_24s258215756x1850289317(heff_dup(v_opts_241), v_ready_244, v_acc_243, heff_dup(v_p_245), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam1, 1, 3, (V[]){v_opts_241, v_p_245, v_p_246})));
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_pr_2422 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_tk_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_rest_2413 = heff_env(self)[4];
  V v_ready_244 = heff_env(self)[5];
  V v_hd_2423 = heff_env(self)[6];
  V v_k_2424 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2428);
  switch (heff_tag_of(v_pr_2422)) {
  case TAG_Done: {
    V v_r_2429 = heff_field(v_pr_2422, 0);
    heff_take_n(v_pr_2422, 1ULL, 1);
    V v_t_2430 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_243, v_r_2429));
    return (g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235(v_tk_240, v_opts_241, v_rest_2413, v_t_2430, v_ready_244, v_hd_2423, v_k_2424));
  }
  case TAG_Later: {
    V v_r_2431 = heff_field(v_pr_2422, 0);
    heff_take_n(v_pr_2422, 1ULL, 1);
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2431, NTAG(TAG_Nil)});
    V v_t_2433 = (g_prelude_2e_2b_2b(v_ready_244, v_t_2432));
    return (g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235(v_tk_240, v_opts_241, v_rest_2413, v_acc_243, v_t_2433, v_hd_2423, v_k_2424));
  }
  default: return heff_nomatch(v_pr_2422);
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam5(V self, V *args) {
  V v_pr_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  V v_x_2418 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_tk_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_rest_2413 = heff_env(self)[4];
  V v_ready_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2423, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_dup(heff_rfield(v_hd_2423, 1));
  args[0] = v_t_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam6, 1, 8, (V[]){v_pr_2422, v_acc_243, v_tk_240, v_opts_241, v_rest_2413, v_ready_244, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2434;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2442});
  heff_room[1] = v_p_245;
  heff_room[2] = v_p_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_2434 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_p_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2441 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_241, heff_dup(v_x_2440)));
  if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
    heff_drop(v_x_2440);
    heff_drop_rec(v_p_2436, 7);
    heff_drop(v_t_2441);
    V f_ = v_k_2434;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_p_245;
    heff_room[2] = v_p_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2441);
    return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(heff_dup(heff_rfield(v_p_2436, 0)), heff_dup(heff_rfield(v_p_2436, 1)), heff_get_n(v_p_2436, 2, 7), v_x_2440, heff_dup(v_p_245), heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam8, 1, 3, (V[]){v_k_2434, v_p_245, v_p_246})));
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ready_244 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_tk_240 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_rest_2413 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_at_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ready_244));
  V v_k_2434 = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam5, 3, 6, (V[]){v_x_2418, v_acc_243, v_tk_240, heff_dup(v_opts_241), v_rest_2413, v_ready_244});
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Settled: {
    V v_r_2435 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_at_2421);
    V f_ = v_k_2434;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_r_2435});
    heff_room[1] = v_p_245;
    heff_room[2] = v_p_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Pend: {
    V v_p_2436 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V v_t_2437 = heff_dup(heff_rfield(v_p_2436, 4));
    switch (heff_tag_of(v_t_2437)) {
    case TAG_Nil: {
      heff_drop(v_at_2421);
      V v_t_2438 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_2436, 3)), NTAG(TAG_Nil)));
      V v_c_2439 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(heff_dup(heff_rfield(v_opts_241, 3)), heff_dup(heff_rfield(v_p_2436, 0)), v_t_2438));
      V f_ = v_c_2439;
      heff_room[0] = heff_dup(v_p_245);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam7, 1, 5, (V[]){v_opts_241, v_k_2434, v_p_245, v_p_246, v_p_2436});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2437, 0ULL, 2);
      return (g_heff_2ebuild_2etesting_2ebuildIntegrations_24s493037298x1204220075(v_opts_241, v_at_2421, v_p_2436, v_k_2434, v_p_245, v_p_246));
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_ready_244 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_tk_240 = heff_env(self)[5];
  V v_rest_2413 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2419 = (g_heff_2ebuild_2etesting_2etestOneF_24s19598657x1925856727(heff_dup(v_opts_241), v_f_2412));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_p_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestCmd_24s432417339x1908462235_lam4, 1, 8, (V[]){v_ready_244, v_x_2418, v_acc_243, v_tk_240, v_opts_241, v_rest_2413, v_p_245, v_p_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_str1, 30, "its program could not be run: ");
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam9(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_entry, 6, 0};

V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1(V v_tok_240, V v_sel_241, V v_j_242, V v_dir_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 0, 2);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_242, 3)), heff_dup(heff_rfield(v_j_242, 4))});
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_243)));
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_243), ((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_str0))});
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 1, 2);
  V v_t_2411 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_246, v_t_247, v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_242, 5)), MK_INT(0LL), NTAG(TAG_True)});
  V v_c_2412 = (g_std_2eprocess_2ewithProcess_24s1283316583x974970592(v_t_2411));
  V v_k_2413 = heff_dup(heff_rfield(v_z_244, 0));
  V v_t_2420 = heff_tr(heff_call(v_c_2412, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam0, 1, 5, (V[]){heff_dup(v_sel_241), heff_dup(v_j_242), heff_dup(v_dir_243), heff_dup(v_z_244), v_k_2413})}));
  V v_t_2446 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2420, heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam3, 1, 3, (V[]){v_dir_243, heff_dup(v_z_244), v_j_242})})});
  V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})}));
  return heff_tail(heff_dup(heff_rfield(v_z_244, 1)), 2, (V[]){v_t_2447, heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam9, 1, 2, (V[]){v_z_244, v_z_245})});
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2417);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2413;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam2, 3, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_sel_241 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2415 = ({ V a_0 = v_sel_241; V a_1 = v_j_242; V a_2 = v_dir_243; V a_3 = v_x_2414; V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s1912007361x751786866(a_0, a_1, a_2, a_3)); heff_drop(v_sel_241); r_; });
  V f_ = v_c_2415;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam1, 1, 1, (V[]){v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam4(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_err_2433 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Left = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2432_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2433})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2434));
  }
  case TAG_Right: {
    V v_x_2435 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam6, 2, 1, (V[]){v_x_2435});
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  V v_x_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_s_2421 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_k_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_str1), heff_get_n(v_s_2421, 2, 3));
  V v_x_2442 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_242, v_t_2441));
  V f_ = v_k_2439;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam8, 3, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam3(V self, V *args) {
  V v_s_2421 = args[0];
  V v_dir_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_243));
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
  V v_a_2425 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam4_clo)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_c_2438 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam5_clo)));
  V v_k_2439 = heff_dup(heff_rfield(v_z_244, 0));
  V f_ = v_c_2438;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam7, 1, 3, (V[]){v_s_2421, v_j_242, v_k_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s1810305270x2026404046_24tok1_lam9(V self, V *args) {
  V v_x_2448 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2448;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}