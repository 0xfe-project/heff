// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Holds 53574
#define TAG_Inherited 58190
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_TemporaryDirectory 61563
#define TAG_TimedOut 6056
#define TAG_UseColor 15915
#define TAG_Wait 10206
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_diff 9578700
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_files 298792593
#define LBL_goldens 436112074
#define LBL_got 312070
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_line 9817275
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_other 307428138
#define LBL_outcome 1272833429
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_value 313331083
#define LBL_watch 314261737
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
V g_co_2eop_24s1855546073x1099963660(V, V, V, V);
V g_co_2eop_24s1855546073x1099963660_entry(V self, V *a);
extern Clo g_co_2eop_24s1855546073x1099963660_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ebuild_2etesting_2ebrokenJob(V, V);
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo;
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void);
HeffT3 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_clo;
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454_clo;
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void);
V g_heff_2ebuild_2etesting_2ejsonFailure(V);
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo;
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160(V, V, V, V);
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_clo;
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216(V, V, V);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_clo;
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_clo;
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_clo;
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_clo;
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(V, V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f1564248594x622634626(V, V, V);
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1564248594x622634626_clo;
V g_list_2efoldl_24f319030394x1380151895(V, V, V);
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a);
extern Clo g_list_2efoldl_24f319030394x1380151895_clo;
V g_list_2efoldl_24f496521120x176206934(V, V, V);
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a);
extern Clo g_list_2efoldl_24f496521120x176206934_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2ekeepIf_24s741838803x941779121(V);
V g_list_2ekeepIf_24s741838803x941779121_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_list_2emap_24s2029356170x1054793697(V);
V g_list_2emap_24s2029356170x1054793697_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s580972671x1254803293(V, V, V, V, V, V, V, V);
V g_list_2emap_24s580972671x1254803293_entry(V self, V *a);
extern Clo g_list_2emap_24s580972671x1254803293_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2efromSystem_24s1965754558x142330605(V, V, V);
V g_std_2efilesystem_2efromSystem_24s1965754558x142330605_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s1965754558x142330605_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_clo;
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str3, 0, "");

HeffT3 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V v_n_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_f_245;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      v_f_245 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_l_243 = heff_field(v_x2_241, 0);
      v_f_245 = heff_dup(v_l_243);
      break;
    }
    default: heff_nomatch(v_x2_241);
    }
    V v_f_248;
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      v_f_248 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str1);
      break;
    }
    case TAG_Cons: {
      V v_l_246 = heff_field(v_x3_242, 0);
      v_f_248 = heff_dup(v_l_246);
      break;
    }
    default: heff_nomatch(v_x3_242);
    }
    return ((HeffT3){{v_n_240, v_f_245, v_f_248}});
  }
  case TAG_Cons: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_argv_2410 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V v_f_2413;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        v_f_2413 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_l_2411 = heff_field(v_x2_241, 0);
        v_f_2413 = heff_dup(v_l_2411);
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      V v_f_2416;
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        v_f_2416 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_l_2414 = heff_field(v_x3_242, 0);
        v_f_2416 = heff_dup(v_l_2414);
        break;
      }
      default: heff_nomatch(v_x3_242);
      }
      return ((HeffT3){{v_n_240, v_f_2413, v_f_2416}});
    }
    case TAG_Cons: {
      V v_b_2417 = heff_field(v_x3_242, 0);
      V v_bs_2418 = heff_field(v_x3_242, 1);
      if (heff_strEq_c_lent(v_a_249, v_b_2417, 0)) {
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_argv_2410;
        V t_2 = v_bs_2418;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        return ((HeffT3){{v_n_240, heff_dup(v_a_249), heff_dup(v_b_2417)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eintegrationMainName_str0, 20, "heffTestIntegrations");

static V g_heff_2ebuild_2etesting_2eintegrationMainName_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eintegrationMainName_st;
static V g_heff_2ebuild_2etesting_2eintegrationMainName_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eintegrationMainName_str0);
}
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eintegrationMainName_st)) return g_heff_2ebuild_2etesting_2eintegrationMainName_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eintegrationMainName_val, &g_heff_2ebuild_2etesting_2eintegrationMainName_st, g_heff_2ebuild_2etesting_2eintegrationMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str13, 0, "");
Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ejsonFailure_entry, 1, 0};

V g_heff_2ebuild_2etesting_2ejsonFailure(V v_j_240) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_j_240)) {
  case TAG_JNull: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_246 = heff_dup(heff_field(v_j_240, 0));
    HeffT2 v_t_247 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str0); V a_1 = v_fs_246; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_246); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_249;
        V v_t_2413;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_y_2412 = heff_field(v_p_2410, 1);
          heff_take_n(v_p_2410, 2ULL, 2);
          v_t_2413 = v_y_2412;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        switch (heff_tag_of(v_t_2413)) {
        case TAG_JNull: {
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2417 = heff_field(v_t_2413, 0);
          V v_ru_24t_2413_24JString = heff_take_reuse_n(v_t_2413, 1ULL, 1);
          v_t_2420 = heff_tag_at_n(v_ru_24t_2413_24JString, TAG_Just, 1, (V[]){v_s_2417});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_j_240)) {
    case TAG_JNull: {
      return NTAG(TAG_Nothing);
    }
    case TAG_JBool: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JInt: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JFloat: {
      heff_take_na(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JString: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JArray: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JObject: {
      V v_fs_2426 = heff_field(v_j_240, 0);
      V v_ru_24j_240_24JObject = heff_take_reuse_n(v_j_240, 1ULL, 1);
      HeffT2 v_t_2427 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str1); V a_1 = v_fs_2426; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2426); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_p_2430 = v_field_2429;
          V v_t_2433;
          switch (heff_tag_of(v_p_2430)) {
          case TAG_MkPair: {
            V v_y_2432 = heff_field(v_p_2430, 1);
            heff_take_n(v_p_2430, 2ULL, 2);
            v_t_2433 = v_y_2432;
            break;
          }
          default: heff_nomatch(v_p_2430);
          }
          switch (heff_tag_of(v_t_2433)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2438 = heff_field(v_t_2433, 0);
            heff_take_n(v_t_2433, 1ULL, 1);
            switch (heff_tag_of(v_xs_2438)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24j_240_24JObject, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2439 = heff_field(v_xs_2438, 0);
              V v_it12_2440 = heff_field(v_xs_2438, 1);
              V v_ru_24xs_2438_24Cons = heff_take_reuse_n(v_xs_2438, 3ULL, 2);
              switch (heff_tag_of(v_it12_2440)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24j_240_24JObject, 1);
                heff_drop(v_expected_2439);
                heff_drop_cell(v_ru_24xs_2438_24Cons, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2441 = heff_field(v_it12_2440, 0);
                heff_take_n(v_it12_2440, 1ULL, 2);
                V v_t_2449;
                switch (heff_tag_of(v_expected_2439)) {
                case TAG_JNull: {
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2446 = heff_field(v_expected_2439, 0);
                  heff_take_n(v_expected_2439, 1ULL, 1);
                  v_t_2449 = v_t_2446;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2439);
                }
                V v_t_2456;
                switch (heff_tag_of(v_got_2441)) {
                case TAG_JNull: {
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2453 = heff_field(v_got_2441, 0);
                  heff_take_n(v_got_2441, 1ULL, 1);
                  v_t_2456 = v_t_2453;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str13);
                  break;
                }
                default: heff_nomatch(v_got_2441);
                }
                return heff_tag_at_n(v_ru_24j_240_24JObject, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24xs_2438_24Cons, TAG_FailDiffer, 2, (V[]){v_t_2449, v_t_2456})});
              }
              default: return heff_nomatch(v_it12_2440);
              }
            }
            default: return heff_nomatch(v_xs_2438);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2433);
          }
        } else {
          heff_drop_cell(v_ru_24j_240_24JObject, 1);
          heff_drop(v_field_2429);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_j_240);
    }
  }
  case TAG_Just: {
    V v_why_2458 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    heff_drop(v_j_240);
    return heff_tag_at_n(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2458})});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ejsonFailure(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_247 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str0); V a_1 = v_fs_247; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_JNull: {
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          V v_b_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          v_t_2421 = v_b_2415;
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop(v_field_2410);
        v_t_2421 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2441;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2427 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2428 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str1); V a_1 = v_fs_2427; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2427); r_; });
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_p_2431 = v_field_2430;
        V v_t_2434;
        switch (heff_tag_of(v_p_2431)) {
        case TAG_MkPair: {
          V v_y_2433 = heff_field(v_p_2431, 1);
          heff_take_n(v_p_2431, 2ULL, 2);
          v_t_2434 = v_y_2433;
          break;
        }
        default: heff_nomatch(v_p_2431);
        }
        switch (heff_tag_of(v_t_2434)) {
        case TAG_JNull: {
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2438 = heff_field(v_t_2434, 0);
          V v_ru_24t_2434_24JString = heff_take_reuse_n(v_t_2434, 1ULL, 1);
          v_t_2441 = heff_tag_at_n(v_ru_24t_2434_24JString, TAG_Just, 1, (V[]){v_s_2438});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2434);
        }
      } else {
        heff_drop(v_field_2430);
        v_t_2441 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2461;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JBool: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JInt: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JFloat: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JString: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JArray: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JObject: {
    V v_fs_2447 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2448 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str2); V a_1 = v_fs_2447; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2447); r_; });
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        V v_p_2451 = v_field_2450;
        V v_t_2454;
        switch (heff_tag_of(v_p_2451)) {
        case TAG_MkPair: {
          V v_y_2453 = heff_field(v_p_2451, 1);
          heff_take_n(v_p_2451, 2ULL, 2);
          v_t_2454 = v_y_2453;
          break;
        }
        default: heff_nomatch(v_p_2451);
        }
        switch (heff_tag_of(v_t_2454)) {
        case TAG_JNull: {
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JArray: {
          V v_xs_2459 = heff_field(v_t_2454, 0);
          heff_take_n(v_t_2454, 1ULL, 1);
          v_t_2461 = v_xs_2459;
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2454);
        }
      } else {
        heff_drop(v_field_2450);
        v_t_2461 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2462 = (g_list_2emap_24s1113395621x248103432(v_t_2461));
  V v_t_2476;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2468 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2469 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str3); V a_1 = v_fs_2468; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2468); r_; });
    {
      V v_field_2471 = v_t_2469.f[1];
      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
      if ((v_tag_2470 == ((int64_t)0ULL))) {
        V v_p_2472 = v_field_2471;
        V v_t_2475;
        switch (heff_tag_of(v_p_2472)) {
        case TAG_MkPair: {
          V v_y_2474 = heff_field(v_p_2472, 1);
          heff_take_n(v_p_2472, 2ULL, 2);
          v_t_2475 = v_y_2474;
          break;
        }
        default: heff_nomatch(v_p_2472);
        }
        v_t_2476 = (g_heff_2ebuild_2etesting_2ejsonFailure(v_t_2475));
      } else {
        heff_drop(v_field_2471);
        v_t_2476 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2478 = ({ V a_0 = v_t_2477; V a_1 = v_j_241; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2477, 2); r_; });
  V v_t_2488;
  {
    V v_field_2480 = v_t_2478.f[1];
    int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
    if ((v_tag_2479 == ((int64_t)0ULL))) {
      V v_it1_2481 = v_field_2480;
      switch (heff_tag_of(v_it1_2481)) {
      case TAG_JNull: {
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2486 = heff_field(v_it1_2481, 0);
        heff_take_n(v_it1_2481, 1ULL, 1);
        v_t_2488 = v_xs_2486;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2481);
      }
    } else {
      heff_drop(v_field_2480);
      v_t_2488 = NTAG(TAG_Nil);
    }
  }
  V v_t_2489 = (g_list_2emap_24s2029356170x1054793697(v_t_2488));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2421, v_t_2441, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2462, v_t_2476, MK_INT(0LL), v_t_2489});
}
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eoutcomeOfJson(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2etesting_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eoutcomeVariable_st;
static V g_heff_2ebuild_2etesting_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eoutcomeVariable_st)) return g_heff_2ebuild_2etesting_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eoutcomeVariable_val, &g_heff_2ebuild_2etesting_2eoutcomeVariable_st, g_heff_2ebuild_2etesting_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str1, 3, " / ");
Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry, 5, 0};

V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    V v_s_248 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_249 = ({ V a_0 = v_s_248; V b_1 = ((V)&g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str1), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_248); heff_drop(b_1); r_; });
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_247, v_t_249, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2411 = ({ V a_0 = v_sel_240; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2etesting_2elevelsSelected(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, NTAG(TAG_Nil)});
      V v_t_2415 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2414));
      V v_t_2416 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2413, heff_dup(heff_rfield(v_j_241, 3)), v_t_2415, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_cell_2417;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_d_244;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2esubtestJobs_24dps(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ebrokenJob_str0, 3, " / ");
Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebrokenJob_entry, 2, 0};

V g_heff_2ebuild_2etesting_2ebrokenJob(V v_j_240, V v_why_241) {
top: ;
  V v_owner_242 = heff_take_field(v_j_240, 0);
  V v_place_243 = heff_take_field(v_j_240, 2);
  V v_top_244 = heff_take_field(v_j_240, 3);
  V v_path_245 = heff_get_n(v_j_240, 4, 6);
  V v_name_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ebrokenJob_str0); V a_1 = v_top_244; V a_2 = v_path_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_path_245); r_; });
  V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_241})});
  V v_t_248 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_246, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247, MK_INT(0LL), NTAG(TAG_Nil)});
  return heff_rec_n(4, shape_owner__place__outcome__next, (V[]){v_owner_242, v_place_243, v_t_248, NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ebrokenJob(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str1, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str2, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str3, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str7, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam11(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam12(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451(V v_e_240, V v_argv_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_2414;
  if ((heff_peek_word(v_n_242) == ((int64_t)0ULL))) {
    v_t_2414 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam0_clo);
  } else {
    V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str0), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    v_t_2414 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  }
  return heff_tail(v_t_2414, 2, (V[]){heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam1, 1, 5, (V[]){v_e_240, v_p_243, v_argv_241, v_n_242, v_p_244})});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam4(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam3(V self, V *args) {
  V v_p_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2418)) {
  case TAG_MkWith: {
    V v_x_2419 = heff_field(v_p_2418, 0);
    heff_take_n(v_p_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_p_2418);
  }
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam4_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V f_ = ((V)&g_co_2eop_24s310169282x2049378029_clo);
  heff_room[0] = v_e_240;
  heff_room[1] = v_t_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2449);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_k_2431;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam8, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2430 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2433 = heff_intShow(heff_box_word((heff_peek_word(v_n_242) + ((int64_t)1ULL))));
  V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str1), v_t_2433), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str2));
  V v_t_2435 = heff_get_n(v_x_2432, 0, 3);
  V v_t_2439;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Exited: {
    V v_n_2436 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 1);
    if (heff_intEq_c(v_n_2436, MK_INT(0LL))) {
      v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str3);
    } else {
      v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str4);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str5);
    break;
  }
  case TAG_TimedOut: {
    v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str6);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2439 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str7);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2434, v_t_2439), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str8));
  V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str9)), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam7, 1, 2, (V[]){v_k_2431, v_n_242})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam6, 1, 4, (V[]){v_n_242, v_e_240, v_hd_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam11(V self, V *args) {
  V v_x_2463 = args[0];
  V v_hd_2464 = args[1];
  V v_k_2465 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2463);
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V f_ = v_k_2454;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam11, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam9(V self, V *args) {
  V v_err_2452 = args[0];
  V v_hd_2453 = args[1];
  V v_k_2454 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_err_2452);
  V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_str10), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2461}), v_hd_2453, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam10, 1, 2, (V[]){v_k_2454, v_n_242})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam12(V self, V *args) {
  V v_x_2467 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2467;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_p_243;
  heff_room[2] = v_p_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2416, v_argv_241, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2429 = (g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(heff_dup(v_e_240), v_t_2417, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam3, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam5, 2, 3, (V[]){v_c_2429, heff_dup(v_n_242), heff_dup(v_e_240)}), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam9, 3, 2, (V[]){heff_dup(v_e_240), v_n_242})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam12, 1, 2, (V[]){v_p_243, v_p_244})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_argv_241 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s1332144033x1482876451_lam2, 1, 5, (V[]){v_argv_241, v_e_240, v_n_242, v_p_243, v_p_244})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str0, 10, "heff-test-");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str2, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str5, 21, "no directory for it: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str6, 5, "win32");
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_entry, 5, 0};

V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969(V v_e_240, V v_sel_241, V v_j_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam1, 1, 5, (V[]){v_e_240, v_hd_243, v_j_242, v_k_244, heff_dup(v_sel_241)})));
}
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam2(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_j_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_sel_241 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop(v_x_2413);
    heff_drop(v_e_240);
    heff_drop(v_sel_241);
    heff_drop(v_hd_243);
    V v_path_2426 = heff_take_field(v_err_2425, 3);
    V v_other_2427 = heff_take_field(v_err_2425, 4);
    V v_name_2428 = heff_take_field(v_err_2425, 1);
    V v_message_2429 = heff_get_n(v_err_2425, 2, 5);
    V v_t_2431;
    switch (heff_tag_of(v_other_2427)) {
    case TAG_Nothing: {
      v_t_2431 = ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str1);
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_other_2427, 0);
      heff_take_n(v_other_2427, 1ULL, 1);
      v_t_2431 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str2), v_x_2430);
      break;
    }
    default: heff_nomatch(v_other_2427);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(v_path_2426, v_t_2431), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str3));
    V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_name_2428), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str4));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str5), heff_strAppend(v_t_2433, v_message_2429));
    V v_x_2435 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_242, v_t_2434));
    V f_ = v_k_244;
    args[0] = v_x_2435;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_dir_2436 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    V v_t_2437;
    if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str6))) {
      v_t_2437 = NTAG(TAG_Windows);
    } else {
      v_t_2437 = NTAG(TAG_Posix);
    }
    V v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = v_dir_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2437); heff_drop(v_dir_2436); r_; });
    return ({ V a_0 = v_ru_24x_2424_24Right; V a_1 = v_e_240; V a_2 = v_sel_241; V a_3 = v_j_242; V a_4 = v_t_2438; V a_5 = v_hd_243; V a_6 = v_k_244; V r_ = (g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sel_241); r_; });
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_sel_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TemporaryDirectory, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_str0), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(((V)&g_co_2eop_24s1855546073x1099963660_clo), 2, (V[]){heff_dup(v_e_240), v_t_2421}));
  V v_c_2423 = heff_tr(g_std_2efilesystem_2efromSystem_24s1965754558x142330605(heff_dup(v_e_240), v_e_240, v_t_2422));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2erunJob_24s1455957666x1415425969_lam3, 1, 6, (V[]){v_j_242, v_k_244, v_x_2413, v_e_240, v_sel_241, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str3, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str10, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str11, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str16, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str17, 1, "\"");
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam0, 3, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam2, 3, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam4, 3, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam5(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_entry, 8, 0};

V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993(V v_e_240, V v_update_241, V v_dir_242, V v_path_243, V v_text_244, V v_x5_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_241) == NTAG(TAG_True))) {
      V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_242));
      V v_c_249 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_248; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_248); r_; });
      V v_t_2410 = (g_exception_2eattempted(heff_dup(v_e_240)));
      V v_c_2414 = heff_tr(heff_call(v_c_249, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam0_clo)}));
      return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam1, 1, 5, (V[]){v_path_243, v_e_240, v_text_244, v_z_246, v_z_247})});
    } else {
      heff_drop(v_e_240);
      heff_drop(v_dir_242);
      heff_drop(v_text_244);
      heff_drop(v_z_246);
      V v_t_2427 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str2), v_path_243), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str3)})});
      return heff_tail(v_z_247, 1, (V[]){v_t_2427});
    }
  }
  case TAG_Just: {
    V v_kept_2428 = heff_field(v_x5_245, 0);
    heff_take_n(v_x5_245, 1ULL, 1);
    heff_drop(v_dir_242);
    if (heff_strEq_c_lent(v_kept_2428, v_text_244, 0)) {
      heff_drop(v_e_240);
      heff_drop(v_path_243);
      heff_drop(v_text_244);
      heff_drop(v_z_246);
      heff_drop(v_kept_2428);
      return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_241) == NTAG(TAG_True))) {
        heff_drop(v_kept_2428);
        V v_path_2429 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_243)));
        V v_c_2430 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2429; V a_2 = v_text_244; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2429); r_; });
        V v_t_2431 = (g_exception_2eattempted(v_e_240));
        V v_c_2435 = heff_tr(heff_call(v_c_2430, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam4_clo)}));
        return heff_tail(v_c_2435, 2, (V[]){v_z_246, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam5, 1, 2, (V[]){v_path_243, v_z_247})});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_z_246);
        V v_t_2440 = ({ V a_0 = v_kept_2428; V b_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str7), v_kept_2428, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_kept_2428); heff_drop(b_1); r_; });
        V v_t_2441 = ({ V a_0 = v_text_244; V b_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str8); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str9), v_text_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_text_244); heff_drop(b_1); r_; });
        HeffT3 v_t_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2440; V a_2 = v_t_2441; HeffT3 r_ = (g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2440); heff_drop(v_t_2441); r_; });
        {
          V v_field_2443 = v_t_2442.f[0];
          V v_field_2444 = v_t_2442.f[1];
          V v_field_2445 = v_t_2442.f[2];
          V v_n_2446 = v_field_2443;
          V v_kept_2447 = v_field_2444;
          V v_text_2448 = v_field_2445;
          V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str10), v_path_243), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str11));
          V v_t_2450 = heff_strAppend(v_t_2449, heff_intShow(v_n_2446));
          V v_t_2451 = ({ V a_0 = v_kept_2447; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str12); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2447); r_; });
          V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str13), v_t_2451), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str14));
          V v_t_2453 = ({ V a_0 = v_text_2448; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str15); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2448); r_; });
          V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str16), v_t_2453), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str17));
          V v_x_2455 = heff_tag_n(TAG_Wrong, 2, (V[]){v_t_2450, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2452, v_t_2454})});
          return heff_tail(v_z_247, 1, (V[]){v_x_2455});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    V v_t_2425 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str0), v_path_243), heff_tag_at_n(v_ru_24x_2423_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str1)})});
    V f_ = v_z_247;
    args[0] = v_t_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2423, 0ULL, 1);
    V f_ = v_z_247;
    args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_243});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_text_244 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_243)));
  V v_c_2417 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2416; V a_2 = v_text_244; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2416); r_; });
  V v_t_2418 = (g_exception_2eattempted(v_e_240));
  V v_c_2422 = heff_tr(heff_call(v_c_2417, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam2_clo)}));
  V f_ = v_c_2422;
  heff_room[0] = v_z_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam3, 1, 2, (V[]){v_path_243, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2433 = args[1];
  V v_k_2434 = args[2];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_ru_24x_2436_24Left = heff_take_reuse_n(v_x_2436, 0ULL, 1);
    V v_t_2438 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str4), v_path_243), heff_tag_at_n(v_ru_24x_2436_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s547091699x479789993_str5)})});
    V f_ = v_z_247;
    args[0] = v_t_2438;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2436, 0ULL, 1);
    V f_ = v_z_247;
    args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_243});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry, 4, 0};

V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(V v_e_240, V v_update_241, V v_f_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_f_242);
    return ((V)&g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_t_248 = heff_dup(heff_rfield(v_o_246, 1));
    V v_c_2411;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_c_2411 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1999392614x816744454(heff_dup(v_e_240), v_update_241, heff_dup(v_f_242), heff_dup(v_o_246), heff_get_n(v_o_246, 11, 12)));
    } else {
      heff_drop(v_t_248);
      v_c_2411 = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam1, 2, 1, (V[]){v_o_246});
    }
    return heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam2, 2, 5, (V[]){v_c_2411, v_e_240, heff_dup(v_update_241), v_f_242, v_rest_247});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_o_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = v_o_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_update_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = ({ V a_0 = v_e_240; V a_1 = v_update_241; V a_2 = v_f_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(a_0, a_1, a_2, a_3)); heff_drop(v_update_241); r_; });
  V f_ = v_c_2415;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam4, 1, 2, (V[]){v_k_2413, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_update_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_lam3, 1, 6, (V[]){v_e_240, v_update_241, v_f_242, v_rest_247, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str1, 5, "FAIL ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str4, 2, " (");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str7, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str8, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str9, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str10, 1, "\012");
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_entry, 4, 0};

V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160(V v_e_240, V v_f_241, V v_color_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_f_248 = heff_dup(v_f_241);
    V v_r_249 = heff_dup(v_r_246);
    V v_line_2410 = heff_take_field(v_r_249, 1);
    V v_owner_2411 = heff_take_field(v_r_249, 0);
    V v_watch_2412 = heff_get_n(v_r_249, 2, 3);
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_r_246, 2)), 5, 10);
    V v_t_2415;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      v_t_2415 = ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      v_t_2415 = v_x_2414;
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_t_2416 = heff_get_n(heff_get_n(v_r_246, 2, 3), 4, 10);
    V v_m_2417 = ({ V a_0 = v_color_242; V a_1 = v_t_2415; V a_2 = v_t_2416; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_t_2415); heff_drop(v_t_2416); r_; });
    V v_expected_2418 = heff_take_field(v_m_2417, 0);
    V v_got_2419 = heff_take_field(v_m_2417, 1);
    V v_diff_2420 = heff_get_n(v_m_2417, 2, 3);
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str1), v_f_248), ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str2));
    V v_t_2422 = heff_strAppend(v_t_2421, heff_intShow(v_line_2410));
    V v_t_2424;
    switch (heff_tag_of(v_owner_2411)) {
    case TAG_Nothing: {
      v_t_2424 = ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str3);
      break;
    }
    case TAG_Just: {
      V v_n_2423 = heff_field(v_owner_2411, 0);
      heff_take_n(v_owner_2411, 1ULL, 1);
      v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str4), v_n_2423), ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str5));
      break;
    }
    default: heff_nomatch(v_owner_2411);
    }
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2422, v_t_2424), ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str6));
    V v_t_2426 = heff_strAppend(v_t_2425, heff_get_n(v_watch_2412, 2, 10));
    V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str7)), v_expected_2418);
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str8)), v_got_2419);
    V v_str_2429 = heff_strAppend(heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str9)), v_diff_2420);
    return heff_clo_n(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam1, 2, 5, (V[]){v_str_2429, v_e_240, v_f_241, heff_dup(v_color_242), v_rest_247});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam2(V self, V *args) {
  V v_x_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_color_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2430 = heff_env(self)[4];
  V v_k_2431 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2439);
  V v_t_2440 = ({ V a_0 = v_e_240; V a_1 = v_f_241; V a_2 = v_color_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160(a_0, a_1, a_2, a_3)); heff_drop(v_color_242); r_; });
  V f_ = v_t_2440;
  heff_room[0] = v_hd_2430;
  heff_room[1] = v_k_2431;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam1(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_str_2429 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_color_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2429, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_str10)), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160_lam2, 1, 6, (V[]){v_e_240, v_f_241, v_color_242, v_rest_247, v_hd_2430, v_k_2431})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str4, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str6, 5, " runs");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str7, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str8, 1, "%");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str12, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str13, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str14, 16, "  (failed after ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str15, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str16, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str17, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str19, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str20, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str21, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str22, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str23, 6, " times");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str24, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str25, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str26, 8, "  skip  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str27, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str28, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str30, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str31, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str32, 17, "        diff     ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str33, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str34, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str36, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str37, 1, "\012");
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam3(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam3, 2, 0};
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_entry, 3, 0};

V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216(V v_e_240, V v_color_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_color_241);
    return ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 2));
    V v_str_2437;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_o_248 = heff_dup(v_o_245);
      V v_t_249 = heff_dup(heff_rfield(v_o_248, 1));
      V v_t_2410;
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        v_t_2410 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str0);
      } else {
        heff_drop(v_t_249);
        v_t_2410 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str1);
      }
      V v_t_2411 = heff_strAppend(v_t_2410, heff_dup(heff_rfield(v_o_248, 0)));
      V v_t_2433;
      if (!(heff_dup(heff_rfield(v_o_248, 3)) == NTAG(TAG_True))) {
        heff_drop_rec(v_o_248, 12);
        v_t_2433 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str2);
      } else {
        V v_t_2412 = heff_dup(heff_rfield(v_o_248, 1));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_o_2413 = v_o_248;
          V v_t_2414 = heff_intShow(heff_dup(heff_rfield(v_o_2413, 4)));
          V v_t_2416;
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_2413, 5)))) {
            V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_o_2413, 5)));
            v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str3), v_t_2415), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str4));
          } else {
            v_t_2416 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str5);
          }
          V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str6)), v_t_2416);
          V v_x2_2418 = (g_list_2emap_24s580972671x1254803293(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str7), heff_dup(v_o_2413), MK_INT(0LL), MK_INT(0LL), MK_INT(100LL), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str8), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str9), heff_get_n(v_o_2413, 7, 12)));
          V v_t_2421;
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_Nil: {
            v_t_2421 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            V v_xs_2420 = heff_field(v_x2_2418, 1);
            heff_take_n(v_x2_2418, 3ULL, 2);
            v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str11); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2418);
          }
          V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str12), heff_strAppend(v_t_2417, v_t_2421));
          v_t_2433 = heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str13));
        } else {
          heff_drop(v_t_2412);
          V v_t_2423 = heff_intShow(heff_take_field(v_o_248, 4));
          V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str14), v_t_2423), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str15));
          V v_t_2426;
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_248, 5)))) {
            V v_t_2425 = heff_intShow(heff_dup(heff_rfield(v_o_248, 5)));
            v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str16), v_t_2425), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str17));
          } else {
            v_t_2426 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str18);
          }
          V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2424, v_t_2426), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str19));
          V v_n_2428 = heff_take_field(v_o_248, 6);
          V v_t_2430;
          if (heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2)) {
            heff_drop(v_n_2428);
            v_t_2430 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str20);
          } else {
            if (heff_intEq_c_lent(v_n_2428, MK_INT(1LL), 2)) {
              heff_drop(v_n_2428);
              v_t_2430 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str21);
            } else {
              V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str22), heff_intShow(v_n_2428));
              v_t_2430 = heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str23));
            }
          }
          V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2427, v_t_2430), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str24));
          V v_t_2432 = heff_intShow(heff_get_n(v_o_248, 10, 12));
          v_t_2433 = heff_strAppend(heff_strAppend(v_t_2431, v_t_2432), ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str25));
        }
      }
      v_str_2437 = heff_strAppend(v_t_2411, v_t_2433);
      break;
    }
    case TAG_Just: {
      V v_why_2434 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_2435 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str26), heff_dup(heff_rfield(v_o_245, 0)));
      V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str27)), v_why_2434);
      v_str_2437 = heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str28));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return heff_clo_n(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam1, 2, 5, (V[]){v_str_2437, v_e_240, v_o_245, v_color_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam3(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam4(V self, V *args) {
  V v_x_2478 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_color_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2438 = heff_env(self)[3];
  V v_k_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2478);
  V v_t_2479 = (g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216(v_e_240, v_color_241, v_rest_246));
  V f_ = v_t_2479;
  heff_room[0] = v_hd_2438;
  heff_room[1] = v_k_2439;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam2(V self, V *args) {
  V v_x_2447 = args[0];
  V v_o_245 = heff_env(self)[0];
  V v_color_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2438 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_take_field(v_o_245, 1);
  V v_c_2477;
  if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_245, 12);
    heff_drop(v_t_2448);
    v_c_2477 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam3_clo);
  } else {
    heff_drop(v_t_2448);
    V v_t_2451 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str30), heff_take_field(v_o_245, 8)));
    V v_t_2452 = heff_get_n(v_o_245, 9, 12);
    V v_t_2465;
    switch (heff_tag_of(v_t_2452)) {
    case TAG_Nothing: {
      v_t_2465 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2453 = heff_field(v_t_2452, 0);
      heff_take_n(v_t_2452, 1ULL, 1);
      V v_color_2454 = heff_dup(v_color_241);
      V v_x2_2455 = v_f_2453;
      switch (heff_tag_of(v_x2_2455)) {
      case TAG_FailBecause: {
        V v_why_2456 = heff_field(v_x2_2455, 0);
        heff_take_n(v_x2_2455, 1ULL, 1);
        heff_drop(v_color_2454);
        v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str31), v_why_2456), NTAG(TAG_Nil)});
        break;
      }
      case TAG_FailDiffer: {
        V v_expected_2457 = heff_field(v_x2_2455, 0);
        V v_got_2458 = heff_field(v_x2_2455, 1);
        V v_ru_24x2_2455_24FailDiffer = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
        V v_m_2459 = ({ V a_0 = v_color_2454; V a_1 = v_expected_2457; V a_2 = v_got_2458; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_color_2454); heff_drop(v_expected_2457); heff_drop(v_got_2458); r_; });
        V v_expected_2460 = heff_take_field(v_m_2459, 0);
        V v_got_2461 = heff_take_field(v_m_2459, 1);
        V v_diff_2462 = heff_get_n(v_m_2459, 2, 3);
        V v_t_2463 = heff_tag_at_n(v_ru_24x2_2455_24FailDiffer, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str32), v_diff_2462), NTAG(TAG_Nil)});
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str33), v_got_2461), v_t_2463});
        v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str34), v_expected_2460), v_t_2464});
        break;
      }
      default: heff_nomatch(v_x2_2455);
      }
      break;
    }
    default: heff_nomatch(v_t_2452);
    }
    V v_x2_2466 = (g_prelude_2e_2b_2b(v_t_2451, v_t_2465));
    V v_str_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_str_2469 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_str_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str36); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_t_2470 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2469, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str37)), NTAG(TAG_MkUnit)});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
    v_c_2477 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
  }
  V f_ = v_c_2477;
  heff_room[0] = heff_dup(v_hd_2438);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam4, 1, 5, (V[]){v_e_240, v_color_241, v_rest_246, v_hd_2438, v_k_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam1(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_str_2437 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_o_245 = heff_env(self)[2];
  V v_color_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2437, ((V)&g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_str29)), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(v_hd_2438), heff_clo_n(g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216_lam2, 1, 6, (V[]){v_o_245, v_color_241, v_e_240, v_hd_2438, v_rest_246, v_k_2439})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str4, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str7, 8, ", tests ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str8, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str10, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str11, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str12, 1, "\012");
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry, 7, 0};

V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(V v_e_240, V v_f_241, V v_wrong_242, V v_ts_243, V v_os_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2413, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam1, 1, 7, (V[]){v_ts_243, v_e_240, v_f_241, v_hd_245, v_os_244, v_wrong_242, v_k_246})));
}
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam0(V self, V *args) {
  V v_b_247 = args[0];
  return v_b_247;
}
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam4(V self, V *args) {
  V v_x_2458 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_wrong_242 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_243; V r_ = (g_list_2efoldl_24f319030394x1380151895(a_0, a_1, a_2)); heff_drop(v_ts_243); r_; });
  V v_t_2461 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_244));
  V v_t_2462 = (g_list_2efoldl_24f1564248594x622634626(MK_INT(1LL), MK_INT(0LL), v_os_244));
  V v_t_2463 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_244; V r_ = (g_list_2efoldl_24f496521120x176206934(a_0, a_1, a_2)); heff_drop(v_os_244); r_; });
  V v_x_2464 = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), v_t_2459, v_t_2460, v_wrong_242, v_t_2461, v_t_2462, v_t_2463});
  V f_ = v_k_246;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_wrong_242 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2419);
  V v_x1_2420 = (g_list_2ekeepIf_24s741838803x941779121(heff_dup(v_ts_243)));
  V v_t_2428;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nil: {
    V v_x1_2421 = (g_list_2ekeepIf_24s458067099x815639923(heff_dup(v_os_244)));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_wrong_242)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str0);
        break;
      }
      case TAG_Cons: {
        v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str1);
        break;
      }
      default: heff_nomatch(v_wrong_242);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str2);
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2420, 0ULL, 2);
    v_t_2428 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str3);
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_f_241), ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str4));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2431 = (g_list_2efoldl_24f319030394x1380151895(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2432 = heff_intShow(heff_intSub(v_t_2430, v_t_2431));
  V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2432), ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str5));
  V v_t_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2435 = heff_strAppend(v_t_2433, heff_intShow(v_t_2434));
  V v_os_2436 = heff_dup(v_os_244);
  V v_t_2449;
  switch (heff_tag_of(v_os_2436)) {
  case TAG_Nil: {
    v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str6);
    break;
  }
  case TAG_Cons: {
    V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2440 = (g_list_2efoldl_24f1564248594x622634626(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2441 = (g_list_2efoldl_24f496521120x176206934(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2442 = heff_intSub(heff_intSub(v_t_2439, v_t_2440), v_t_2441);
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str7), heff_intShow(v_t_2442));
    V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_2436));
    V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2443, ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str8)), heff_intShow(v_t_2444));
    V v_n_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_2436; V r_ = (g_list_2efoldl_24f496521120x176206934(a_0, a_1, a_2)); heff_drop_tag(v_os_2436, 2); r_; });
    V v_t_2448;
    if (heff_intEq_c_lent(v_n_2446, MK_INT(0LL), 2)) {
      heff_drop(v_n_2446);
      v_t_2448 = ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str9);
    } else {
      V v_t_2447 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str10), heff_intShow(v_n_2446));
      v_t_2448 = heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str11));
    }
    v_t_2449 = heff_strAppend(v_t_2445, v_t_2448);
    break;
  }
  default: heff_nomatch(v_os_2436);
  }
  V v_str_2450 = heff_strAppend(v_t_2435, v_t_2449);
  V v_t_2451 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_str12)), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_hd_245, heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam4, 1, 4, (V[]){v_ts_243, v_os_244, v_wrong_242, v_k_246})));
}
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_os_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_ts_243 = heff_env(self)[4];
  V v_wrong_242 = heff_env(self)[5];
  V v_f_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2417);
  V v_c_2418 = (g_heff_2ebuild_2etesting_2eprintOutcomes_24s1923257905x1070110216(heff_dup(v_e_240), v_x_2414, heff_dup(v_os_244)));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam3, 1, 7, (V[]){v_ts_243, v_os_244, v_wrong_242, v_f_241, v_e_240, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_os_244 = heff_env(self)[4];
  V v_wrong_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = (g_list_2ekeepIf_24s741838803x941779121(heff_dup(v_ts_243)));
  V v_c_2416 = (g_heff_2ebuild_2etesting_2eprintFails_24s1347526621x97921160(heff_dup(v_e_240), heff_dup(v_f_241), v_x_2414, v_t_2415));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_lam2, 1, 8, (V[]){v_e_240, v_x_2414, v_os_244, v_hd_245, v_ts_243, v_wrong_242, v_f_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str1, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str2, 21, "  errors, as expected");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str4, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str5, 28, "  checks, but expects errors");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str7, 43, ": checks, but its first line expects errors");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str8, 4, "heff");
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam4(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_entry, 7, 0};

V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(V v_e_240, V v_opts_241, V v_f_242, V v_x3_243, V v_l_244, V v_z_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x3_243) == NTAG(TAG_True))) {
    if (!heff_strEq_c(heff_dup(heff_rfield(v_opts_241, 1)), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str0))) {
      heff_drop(v_e_240);
      heff_drop_rec(v_opts_241, 4);
      heff_drop(v_f_242);
      heff_drop_rec(v_l_244, 5);
      heff_drop(v_z_245);
      return heff_tail(v_z_246, 1, (V[]){heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())})});
    } else {
      heff_drop_rec(v_opts_241, 4);
      V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_l_244)));
      return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam0, 1, 5, (V[]){v_l_244, v_e_240, v_f_242, v_z_245, v_z_246})});
    }
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str8), heff_dup(heff_rfield(v_l_244, 1)), MK_INT(0LL), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam4, 1, 6, (V[]){v_e_240, v_l_244, v_z_245, v_opts_241, v_f_242, v_z_246})));
  }
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_Settled, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_p_2418;
  args[0] = heff_dup(g_heff_2ebuild_2etesting_2eexpectedRes_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_f_2414 = heff_env(self)[0];
  V v_p_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_f_2414, ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str7)), NTAG(TAG_Nil)});
  V f_ = v_p_2418;
  args[0] = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2437, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_get_n(v_l_244, 1, 5);
  V v_t_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    v_t_2412 = ({ V b_0 = heff_get_n(v_x_248, 0, 2); V r_ = (g_list_2eany_24s1740858080x874135214(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_249, 0ULL, 2);
    heff_drop_rec(v_x_248, 2);
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_e_2413 = v_e_240;
  V v_f_2414 = v_f_242;
  V v_x2_2415 = v_t_2412;
  V v_p_2416 = v_z_245;
  V v_p_2418 = heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam1, 1, 1, (V[]){v_z_246});
  if ((heff_dup(v_x2_2415) == NTAG(TAG_True))) {
    heff_drop(v_x2_2415);
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str1), v_f_2414), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str2));
    V v_t_2420 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str3)), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s310169282x2049378029(v_e_2413, heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_p_2416, heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam2, 1, 1, (V[]){v_p_2418})));
  } else {
    heff_drop(v_x2_2415);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str4), heff_dup(v_f_2414)), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str5));
    V v_t_2429 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_str6)), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s310169282x2049378029(v_e_2413, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_p_2416, heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam3, 1, 2, (V[]){v_f_2414, v_p_2418})));
  }
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_l_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_e_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_l_244; V b_4 = heff_get_n(v_x_2440, 0, 2); V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2etesting_2etestOneC_24s1601395947x1453484776(a_0, a_1, a_2, a_3, b_4, a_5, a_6)); heff_drop(b_4); r_; });
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_l_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2438);
  V v_c_2439 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_l_244)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1909029181x678604668_lam5, 1, 6, (V[]){v_e_240, v_opts_241, v_f_242, v_l_244, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}