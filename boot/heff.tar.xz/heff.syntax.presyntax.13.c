// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IApp 21275
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_RuneWord 42901
#define TAG_SetPath 11095
#define TAG_StringWord 15530
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TRune 58776
#define TAG_TString 39883
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_e 319
#define LBL_end 310101
#define LBL_part 9928890
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1081934242x609445557_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1806941268x1247563264_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1879669654x137321221_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1935226754x442916785_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s527118018x1185608080_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2elastT(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
V g_heff_2esyntax_2epresyntax_2estmtT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2etryAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_243 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_244 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_243)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_244;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_x_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkPair: {
      V v_st_246 = heff_field(v_x1_245, 0);
      V v_y_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_246, v_xs_244));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_y_2412 = v_field_2410;
        return ((HeffT2){{v_x_2411, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_247, v_y_2412})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_dup(heff_field(v_x3_242, 0));
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EBinary: {
      V v_segs_2411 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EBinary = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2413 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0, 2, 1, (V[]){v_f_240}), v_st_241, v_segs_2411));
        {
          V v_field_2428 = v_t_2427.f[0];
          V v_field_2429 = v_t_2427.f[1];
          V v_x_2430 = v_field_2428;
          V v_y_2431 = v_field_2429;
          V v_t_2432 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EBinary, TAG_EBinary, 1, (V[]){v_y_2431}), v_sp_2413});
          return ((HeffT2){{v_x_2430, v_t_2432}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EApp: {
      V v_h_2435 = heff_field(v_x31_243, 0);
      V v_args_2436 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2438 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2439 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_h_2435}));
        switch (heff_tag_of(v_x1_2439)) {
        case TAG_MkPair: {
          V v_x_2440 = heff_field(v_x1_2439, 0);
          V v_y_2441 = heff_field(v_x1_2439, 1);
          heff_take_n(v_x1_2439, 3ULL, 2);
          HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_x_2440, v_args_2436));
          {
            V v_field_2443 = v_t_2442.f[0];
            V v_field_2444 = v_t_2442.f[1];
            V v_x_2445 = v_field_2443;
            V v_y_2446 = v_field_2444;
            V v_t_2447 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EApp, TAG_EApp, 2, (V[]){v_y_2441, v_y_2446}), v_sp_2438});
            return ((HeffT2){{v_x_2445, v_t_2447}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2439)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ENamed: {
      V v_x_2449 = heff_field(v_x31_243, 0);
      V v_e_2450 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ENamed = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2452 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2453 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2450}));
        switch (heff_tag_of(v_x1_2453)) {
        case TAG_MkPair: {
          V v_x_2454 = heff_field(v_x1_2453, 0);
          V v_y_2455 = heff_field(v_x1_2453, 1);
          heff_take_n(v_x1_2453, 3ULL, 2);
          V v_t_2456 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENamed, TAG_ENamed, 2, (V[]){v_x_2449, v_y_2455}), v_sp_2452});
          return ((HeffT2){{v_x_2454, v_t_2456}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2453)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ELam: {
      V v_b_2459 = heff_field(v_x31_243, 0);
      V v_body_2460 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELam = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2462 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2463 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_body_2460}));
        switch (heff_tag_of(v_x1_2463)) {
        case TAG_MkPair: {
          V v_x_2464 = heff_field(v_x1_2463, 0);
          V v_y_2465 = heff_field(v_x1_2463, 1);
          heff_take_n(v_x1_2463, 3ULL, 2);
          V v_t_2466 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELam, TAG_ELam, 2, (V[]){v_b_2459, v_y_2465}), v_sp_2462});
          return ((HeffT2){{v_x_2464, v_t_2466}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2463)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2467 = heff_field(v_x31_243, 0);
      V v_t_2468 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EAnn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2470 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2471 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2467}));
        switch (heff_tag_of(v_x1_2471)) {
        case TAG_MkPair: {
          V v_x_2472 = heff_field(v_x1_2471, 0);
          V v_y_2473 = heff_field(v_x1_2471, 1);
          heff_take_n(v_x1_2471, 3ULL, 2);
          V v_t_2474 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAnn, TAG_EAnn, 2, (V[]){v_y_2473, v_t_2468}), v_sp_2470});
          return ((HeffT2){{v_x_2472, v_t_2474}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2471)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2475 = heff_field(v_x31_243, 0);
      V v_x_2476 = heff_field(v_x31_243, 1);
      V v_xsp_2477 = heff_field(v_x31_243, 2);
      V v_v_2478 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24ESpec = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2480 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2481 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2475}));
        switch (heff_tag_of(v_x1_2481)) {
        case TAG_MkPair: {
          V v_x_2482 = heff_field(v_x1_2481, 0);
          V v_y_2483 = heff_field(v_x1_2481, 1);
          heff_take_n(v_x1_2481, 3ULL, 2);
          V v_x1_2484 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_2482, v_v_2478}));
          switch (heff_tag_of(v_x1_2484)) {
          case TAG_MkPair: {
            V v_x_2485 = heff_field(v_x1_2484, 0);
            V v_y_2486 = heff_field(v_x1_2484, 1);
            heff_take_n(v_x1_2484, 3ULL, 2);
            V v_t_2487 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ESpec, TAG_ESpec, 4, (V[]){v_y_2483, v_x_2476, v_xsp_2477, v_y_2486}), v_sp_2480});
            return ((HeffT2){{v_x_2485, v_t_2487}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2484)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2481)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EStruct: {
      V v_fs_2490 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EStruct = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2492 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_2493 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_f_240, v_st_241, v_fs_2490));
        {
          V v_field_2494 = v_t_2493.f[0];
          V v_field_2495 = v_t_2493.f[1];
          V v_x_2496 = v_field_2494;
          V v_y_2497 = v_field_2495;
          V v_t_2498 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EStruct, TAG_EStruct, 1, (V[]){v_y_2497}), v_sp_2492});
          return ((HeffT2){{v_x_2496, v_t_2498}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2499 = heff_field(v_x31_243, 0);
      V v_fs_24100 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EUpdate = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24102 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24103 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2499}));
        switch (heff_tag_of(v_x1_24103)) {
        case TAG_MkPair: {
          V v_x_24104 = heff_field(v_x1_24103, 0);
          V v_y_24105 = heff_field(v_x1_24103, 1);
          heff_take_n(v_x1_24103, 3ULL, 2);
          HeffT2 v_t_24116 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1, 2, 1, (V[]){v_f_240}), v_x_24104, v_fs_24100));
          {
            V v_field_24117 = v_t_24116.f[0];
            V v_field_24118 = v_t_24116.f[1];
            V v_x_24119 = v_field_24117;
            V v_y_24120 = v_field_24118;
            V v_t_24121 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EUpdate, TAG_EUpdate, 2, (V[]){v_y_24105, v_y_24120}), v_sp_24102});
            return ((HeffT2){{v_x_24119, v_t_24121}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24103)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24122 = heff_field(v_x31_243, 0);
      V v_alts_24123 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24125 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24126 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_s_24122}));
        switch (heff_tag_of(v_x1_24126)) {
        case TAG_MkPair: {
          V v_x_24127 = heff_field(v_x1_24126, 0);
          V v_y_24128 = heff_field(v_x1_24126, 1);
          heff_take_n(v_x1_24126, 3ULL, 2);
          HeffT2 v_t_24139 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2, 2, 1, (V[]){v_f_240}), v_x_24127, v_alts_24123));
          {
            V v_field_24140 = v_t_24139.f[0];
            V v_field_24141 = v_t_24139.f[1];
            V v_x_24142 = v_field_24140;
            V v_y_24143 = v_field_24141;
            V v_t_24144 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_24128, v_y_24143}), v_sp_24125});
            return ((HeffT2){{v_x_24142, v_t_24144}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24126)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24145 = heff_field(v_x31_243, 0);
      V v_a_24146 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELetIn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24148 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24149 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_rhs_24145}));
        switch (heff_tag_of(v_x1_24149)) {
        case TAG_MkPair: {
          V v_x_24150 = heff_field(v_x1_24149, 0);
          V v_y_24151 = heff_field(v_x1_24149, 1);
          V v_ru_24x1_24149_24MkPair = heff_take_reuse_n(v_x1_24149, 3ULL, 2);
          switch (heff_tag_of(v_a_24146)) {
          case TAG_At: {
            V v_x31_24152 = heff_field(v_a_24146, 0);
            V v_sp_24153 = heff_field(v_a_24146, 1);
            heff_take_n(v_a_24146, 3ULL, 2);
            switch (heff_tag_of(v_x31_24152)) {
            case TAG_MkAlt: {
              V v_p_24154 = heff_field(v_x31_24152, 0);
              V v_e_24155 = heff_field(v_x31_24152, 1);
              heff_take_n(v_x31_24152, 3ULL, 2);
              V v_x1_24156 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24150, v_e_24155}));
              switch (heff_tag_of(v_x1_24156)) {
              case TAG_MkPair: {
                V v_x_24157 = heff_field(v_x1_24156, 0);
                V v_y_24158 = heff_field(v_x1_24156, 1);
                heff_take_n(v_x1_24156, 3ULL, 2);
                V v_t_24159 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24154, v_y_24158}), v_sp_24153});
                V v_t_24160 = heff_tag_at_n(v_ru_24x1_24149_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24151, v_t_24159}), v_sp_24148});
                return ((HeffT2){{v_x_24157, v_t_24160}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x1_24156)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24152)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24146)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24149)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24161 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EDo = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24163 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_t_24164 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24164, v_st_241, v_ss_24161));
        {
          V v_field_24166 = v_t_24165.f[0];
          V v_field_24167 = v_t_24165.f[1];
          V v_x_24168 = v_field_24166;
          V v_y_24169 = v_field_24167;
          V v_t_24170 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EDo, TAG_EDo, 1, (V[]){v_y_24169}), v_sp_24163});
          return ((HeffT2){{v_x_24168, v_t_24170}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EAssign: {
      V v_x_24174 = heff_field(v_x31_243, 0);
      V v_xsp_24175 = heff_field(v_x31_243, 1);
      V v_e_24176 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EAssign = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24178 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24179 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24176}));
        switch (heff_tag_of(v_x1_24179)) {
        case TAG_MkPair: {
          V v_x_24180 = heff_field(v_x1_24179, 0);
          V v_y_24181 = heff_field(v_x1_24179, 1);
          heff_take_n(v_x1_24179, 3ULL, 2);
          V v_t_24182 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAssign, TAG_EAssign, 3, (V[]){v_x_24174, v_xsp_24175, v_y_24181}), v_sp_24178});
          return ((HeffT2){{v_x_24180, v_t_24182}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24179)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24183 = heff_field(v_x31_243, 0);
      V v_body_24184 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EWhile = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24186 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24187 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24183}));
        switch (heff_tag_of(v_x1_24187)) {
        case TAG_MkPair: {
          V v_x_24188 = heff_field(v_x1_24187, 0);
          V v_y_24189 = heff_field(v_x1_24187, 1);
          heff_take_n(v_x1_24187, 3ULL, 2);
          V v_t_24190 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24191 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24190, v_x_24188, v_body_24184));
          {
            V v_field_24192 = v_t_24191.f[0];
            V v_field_24193 = v_t_24191.f[1];
            V v_x_24194 = v_field_24192;
            V v_y_24195 = v_field_24193;
            V v_t_24196 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWhile, TAG_EWhile, 2, (V[]){v_y_24189, v_y_24195}), v_sp_24186});
            return ((HeffT2){{v_x_24194, v_t_24196}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24187)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EFor: {
      V v_p_24197 = heff_field(v_x31_243, 0);
      V v_c_24198 = heff_field(v_x31_243, 1);
      V v_body_24199 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EFor = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24201 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24202 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24198}));
        switch (heff_tag_of(v_x1_24202)) {
        case TAG_MkPair: {
          V v_x_24203 = heff_field(v_x1_24202, 0);
          V v_y_24204 = heff_field(v_x1_24202, 1);
          heff_take_n(v_x1_24202, 3ULL, 2);
          V v_t_24205 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24206 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24205, v_x_24203, v_body_24199));
          {
            V v_field_24207 = v_t_24206.f[0];
            V v_field_24208 = v_t_24206.f[1];
            V v_x_24209 = v_field_24207;
            V v_y_24210 = v_field_24208;
            V v_t_24211 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EFor, TAG_EFor, 3, (V[]){v_p_24197, v_y_24204, v_y_24210}), v_sp_24201});
            return ((HeffT2){{v_x_24209, v_t_24211}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24202)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24212 = heff_field(v_x31_243, 0);
      V v_a_24213 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EIfThen = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24215 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24216 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24212}));
        switch (heff_tag_of(v_x1_24216)) {
        case TAG_MkPair: {
          V v_x_24217 = heff_field(v_x1_24216, 0);
          V v_y_24218 = heff_field(v_x1_24216, 1);
          heff_take_n(v_x1_24216, 3ULL, 2);
          V v_x1_24219 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24217, v_a_24213}));
          switch (heff_tag_of(v_x1_24219)) {
          case TAG_MkPair: {
            V v_x_24220 = heff_field(v_x1_24219, 0);
            V v_y_24221 = heff_field(v_x1_24219, 1);
            heff_take_n(v_x1_24219, 3ULL, 2);
            V v_t_24222 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EIfThen, TAG_EIfThen, 2, (V[]){v_y_24218, v_y_24221}), v_sp_24215});
            return ((HeffT2){{v_x_24220, v_t_24222}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_24219)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24216)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EContinue: {
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EReturn: {
      V v_e_24223 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EReturn = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24225 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24226 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24223}));
        switch (heff_tag_of(v_x1_24226)) {
        case TAG_MkPair: {
          V v_x_24227 = heff_field(v_x1_24226, 0);
          V v_y_24228 = heff_field(v_x1_24226, 1);
          heff_take_n(v_x1_24226, 3ULL, 2);
          V v_t_24229 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EReturn, TAG_EReturn, 1, (V[]){v_y_24228}), v_sp_24225});
          return ((HeffT2){{v_x_24227, v_t_24229}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24226)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ENest: {
      V v_e_24230 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ENest = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24232 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24233 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24230}));
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_MkPair: {
          V v_x_24234 = heff_field(v_x1_24233, 0);
          V v_y_24235 = heff_field(v_x1_24233, 1);
          heff_take_n(v_x1_24233, 3ULL, 2);
          V v_t_24236 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENest, TAG_ENest, 1, (V[]){v_y_24235}), v_sp_24232});
          return ((HeffT2){{v_x_24234, v_t_24236}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24233)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24237 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ELazy = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24239 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24240 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24237}));
        switch (heff_tag_of(v_x1_24240)) {
        case TAG_MkPair: {
          V v_x_24241 = heff_field(v_x1_24240, 0);
          V v_y_24242 = heff_field(v_x1_24240, 1);
          heff_take_n(v_x1_24240, 3ULL, 2);
          V v_t_24243 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELazy, TAG_ELazy, 1, (V[]){v_y_24242}), v_sp_24239});
          return ((HeffT2){{v_x_24241, v_t_24243}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24240)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24244 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETuple = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24246 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_24247 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_241, v_es_24244));
        {
          V v_field_24248 = v_t_24247.f[0];
          V v_field_24249 = v_t_24247.f[1];
          V v_x_24250 = v_field_24248;
          V v_y_24251 = v_field_24249;
          V v_t_24252 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETuple, TAG_ETuple, 1, (V[]){v_y_24251}), v_sp_24246});
          return ((HeffT2){{v_x_24250, v_t_24252}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24253 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETry = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24255 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_24256 = (g_heff_2esyntax_2epresyntax_2etryAcc_24cpr(v_f_240, v_st_241, v_tr_24253));
        {
          V v_field_24257 = v_t_24256.f[0];
          V v_field_24258 = v_t_24256.f[1];
          V v_x_24259 = v_field_24257;
          V v_y_24260 = v_field_24258;
          V v_t_24261 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETry, TAG_ETry, 1, (V[]){v_y_24260}), v_sp_24255});
          return ((HeffT2){{v_x_24259, v_t_24261}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWith: {
      V v_w_24262 = heff_field(v_x31_243, 0);
      V v_x_24263 = heff_field(v_x31_243, 1);
      V v_xsp_24264 = heff_field(v_x31_243, 2);
      V v_body_24265 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24EWith = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24267 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24268 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_w_24262}));
        switch (heff_tag_of(v_x1_24268)) {
        case TAG_MkPair: {
          V v_x_24269 = heff_field(v_x1_24268, 0);
          V v_y_24270 = heff_field(v_x1_24268, 1);
          heff_take_n(v_x1_24268, 3ULL, 2);
          V v_t_24271 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24272 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24271, v_x_24269, v_body_24265));
          {
            V v_field_24273 = v_t_24272.f[0];
            V v_field_24274 = v_t_24272.f[1];
            V v_x_24275 = v_field_24273;
            V v_y_24276 = v_field_24274;
            V v_t_24277 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWith, TAG_EWith, 4, (V[]){v_y_24270, v_x_24263, v_xsp_24264, v_y_24276}), v_sp_24267});
            return ((HeffT2){{v_x_24275, v_t_24277}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24268)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_x3_2415 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2415)) {
  case TAG_At: {
    V v_x31_2416 = heff_field(v_x3_2415, 0);
    V v_sp_2417 = heff_field(v_x3_2415, 1);
    V v_ru_24x3_2415_24At = heff_take_reuse_n(v_x3_2415, 3ULL, 2);
    switch (heff_tag_of(v_x31_2416)) {
    case TAG_MkSegment: {
      V v_v_2418 = heff_field(v_x31_2416, 0);
      V v_ty_2419 = heff_field(v_x31_2416, 1);
      V v_size_2420 = heff_field(v_x31_2416, 2);
      V v_little_2421 = heff_field(v_x31_2416, 3);
      V v_signed_2422 = heff_field(v_x31_2416, 4);
      heff_take_n(v_x31_2416, 31ULL, 5);
      V v_x1_2423 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2414, v_v_2418}));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x1_2423, 0);
        V v_y_2425 = heff_field(v_x1_2423, 1);
        V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
        V v_t_2426 = heff_tag_at_n(v_ru_24x3_2415_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_y_2425, v_ty_2419, v_size_2420, v_little_2421, v_signed_2422}), v_sp_2417});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_t_2426});
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    default: return heff_nomatch(v_x31_2416);
    }
  }
  default: return heff_nomatch(v_x3_2415);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args) {
  V v_st_24106 = args[0];
  V v_x3_24107 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24107)) {
  case TAG_At: {
    V v_x31_24108 = heff_field(v_x3_24107, 0);
    V v_sp_24109 = heff_field(v_x3_24107, 1);
    V v_ru_24x3_24107_24At = heff_take_reuse_n(v_x3_24107, 3ULL, 2);
    switch (heff_tag_of(v_x31_24108)) {
    case TAG_SetPath: {
      V v_path_24110 = heff_field(v_x31_24108, 0);
      V v_e_24111 = heff_field(v_x31_24108, 1);
      V v_ru_24x31_24108_24SetPath = heff_take_reuse_n(v_x31_24108, 3ULL, 2);
      V v_x1_24112 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24106, v_e_24111}));
      switch (heff_tag_of(v_x1_24112)) {
      case TAG_MkPair: {
        V v_x_24113 = heff_field(v_x1_24112, 0);
        V v_y_24114 = heff_field(v_x1_24112, 1);
        heff_take_n(v_x1_24112, 3ULL, 2);
        V v_t_24115 = heff_tag_at_n(v_ru_24x3_24107_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_path_24110, v_y_24114}), v_sp_24109});
        return heff_tag_at_n(v_ru_24x31_24108_24SetPath, TAG_MkPair, 2, (V[]){v_x_24113, v_t_24115});
      }
      default: return heff_nomatch(v_x1_24112);
      }
    }
    default: return heff_nomatch(v_x31_24108);
    }
  }
  default: return heff_nomatch(v_x3_24107);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args) {
  V v_st_24129 = args[0];
  V v_x3_24130 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24130)) {
  case TAG_At: {
    V v_x31_24131 = heff_field(v_x3_24130, 0);
    V v_sp_24132 = heff_field(v_x3_24130, 1);
    V v_ru_24x3_24130_24At = heff_take_reuse_n(v_x3_24130, 3ULL, 2);
    switch (heff_tag_of(v_x31_24131)) {
    case TAG_MkAlt: {
      V v_p_24133 = heff_field(v_x31_24131, 0);
      V v_e_24134 = heff_field(v_x31_24131, 1);
      V v_ru_24x31_24131_24MkAlt = heff_take_reuse_n(v_x31_24131, 3ULL, 2);
      V v_x1_24135 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24129, v_e_24134}));
      switch (heff_tag_of(v_x1_24135)) {
      case TAG_MkPair: {
        V v_x_24136 = heff_field(v_x1_24135, 0);
        V v_y_24137 = heff_field(v_x1_24135, 1);
        heff_take_n(v_x1_24135, 3ULL, 2);
        V v_t_24138 = heff_tag_at_n(v_ru_24x3_24130_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24133, v_y_24137}), v_sp_24132});
        return heff_tag_at_n(v_ru_24x31_24131_24MkAlt, TAG_MkPair, 2, (V[]){v_x_24136, v_t_24138});
      }
      default: return heff_nomatch(v_x1_24135);
      }
    }
    default: return heff_nomatch(v_x31_24131);
    }
  }
  default: return heff_nomatch(v_x3_24130);
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2410 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2412 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eaccList_24s527118018x1185608080_24cpr(v_st_240, v_segs_2410));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_y_2417 = v_field_2415;
          V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2417}), v_sp_2412});
          return ((HeffT2){{v_x_2416, v_t_2418}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2421 = heff_field(v_x31_242, 0);
      V v_args_2422 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2424 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2425;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2425 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_h_2421)));
        }
        HeffT2 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1935226754x442916785_24cpr(v_x_2425, v_args_2422));
        {
          V v_field_2427 = v_t_2426.f[0];
          V v_field_2428 = v_t_2426.f[1];
          V v_x_2429 = v_field_2427;
          V v_y_2430 = v_field_2428;
          V v_t_2431 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2421, v_y_2430}), v_sp_2424});
          return ((HeffT2){{v_x_2429, v_t_2431}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2433 = heff_field(v_x31_242, 0);
      V v_e_2434 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2436 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2437 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2434)));
        }
        V v_t_2438 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2433, v_e_2434}), v_sp_2436});
        return ((HeffT2){{v_x_2437, v_t_2438}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2441 = heff_field(v_x31_242, 0);
      V v_body_2442 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2444 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2445;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2445 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2445 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_body_2442)));
        }
        V v_t_2446 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2441, v_body_2442}), v_sp_2444});
        return ((HeffT2){{v_x_2445, v_t_2446}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2447 = heff_field(v_x31_242, 0);
      V v_t_2448 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2450 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2451;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2451 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2451 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2447)));
        }
        V v_t_2452 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2447, v_t_2448}), v_sp_2450});
        return ((HeffT2){{v_x_2451, v_t_2452}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2453 = heff_field(v_x31_242, 0);
      V v_x_2454 = heff_field(v_x31_242, 1);
      V v_xsp_2455 = heff_field(v_x31_242, 2);
      V v_v_2456 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2458 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_2459 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2453, v_x_2454, v_xsp_2455, v_v_2456}), v_sp_2458});
          return ((HeffT2){{NTAG(TAG_True), v_t_2459}});
        } else {
          heff_drop(v_st_240);
          V v_x_2460 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_a_2453)));
          V v_x_2461;
          if ((heff_dup(v_x_2460) == NTAG(TAG_True))) {
            heff_drop(v_x_2460);
            v_x_2461 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_2460);
            v_x_2461 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_v_2456)));
          }
          V v_t_2462 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_2453, v_x_2454, v_xsp_2455, v_v_2456}), v_sp_2458});
          return ((HeffT2){{v_x_2461, v_t_2462}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2467 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1879669654x137321221_24cpr(v_st_240, v_fs_2465));
        {
          V v_field_2469 = v_t_2468.f[0];
          V v_field_2470 = v_t_2468.f[1];
          V v_x_2471 = v_field_2469;
          V v_y_2472 = v_field_2470;
          V v_t_2473 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2472}), v_sp_2467});
          return ((HeffT2){{v_x_2471, v_t_2473}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2474 = heff_field(v_x31_242, 0);
      V v_fs_2475 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2477 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2478;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2478 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2478 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_a_2474)));
        }
        HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1806941268x1247563264_24cpr(v_x_2478, v_fs_2475));
        {
          V v_field_2480 = v_t_2479.f[0];
          V v_field_2481 = v_t_2479.f[1];
          V v_x_2482 = v_field_2480;
          V v_y_2483 = v_field_2481;
          V v_t_2484 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_2474, v_y_2483}), v_sp_2477});
          return ((HeffT2){{v_x_2482, v_t_2484}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2485 = heff_field(v_x31_242, 0);
      V v_alts_2486 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2488 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2489;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2489 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2489 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_s_2485)));
        }
        HeffT2 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1081934242x609445557_24cpr(v_x_2489, v_alts_2486));
        {
          V v_field_2491 = v_t_2490.f[0];
          V v_field_2492 = v_t_2490.f[1];
          V v_x_2493 = v_field_2491;
          V v_y_2494 = v_field_2492;
          V v_t_2495 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2485, v_y_2494}), v_sp_2488});
          return ((HeffT2){{v_x_2493, v_t_2495}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2496 = heff_field(v_x31_242, 0);
      V v_a_2497 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2499 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2497)) {
          case TAG_At: {
            V v_x31_24100 = heff_field(v_a_2497, 0);
            V v_sp_24101 = heff_field(v_a_2497, 1);
            V v_ru_24a_2497_24At = heff_take_reuse_n(v_a_2497, 3ULL, 2);
            switch (heff_tag_of(v_x31_24100)) {
            case TAG_MkAlt: {
              V v_p_24102 = heff_field(v_x31_24100, 0);
              V v_e_24103 = heff_field(v_x31_24100, 1);
              heff_take_n(v_x31_24100, 3ULL, 2);
              V v_t_24104 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24102, v_e_24103}), v_sp_24101});
              V v_t_24105 = heff_tag_at_n(v_ru_24a_2497_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2496, v_t_24104}), v_sp_2499});
              return ((HeffT2){{NTAG(TAG_True), v_t_24105}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24100)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2497)}});
          }
        } else {
          heff_drop(v_st_240);
          V v_x_24106 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_rhs_2496)));
          switch (heff_tag_of(v_a_2497)) {
          case TAG_At: {
            V v_x31_24107 = heff_field(v_a_2497, 0);
            V v_sp_24108 = heff_field(v_a_2497, 1);
            V v_ru_24a_2497_24At = heff_take_reuse_n(v_a_2497, 3ULL, 2);
            switch (heff_tag_of(v_x31_24107)) {
            case TAG_MkAlt: {
              V v_p_24109 = heff_field(v_x31_24107, 0);
              V v_e_24110 = heff_field(v_x31_24107, 1);
              heff_take_n(v_x31_24107, 3ULL, 2);
              V v_x_24111;
              if ((heff_dup(v_x_24106) == NTAG(TAG_True))) {
                heff_drop(v_x_24106);
                v_x_24111 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24106);
                v_x_24111 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_24110)));
              }
              V v_t_24112 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24109, v_e_24110}), v_sp_24108});
              V v_t_24113 = heff_tag_at_n(v_ru_24a_2497_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_2496, v_t_24112}), v_sp_2499});
              return ((HeffT2){{v_x_24111, v_t_24113}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24107)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2497)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24114 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24116 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24117 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_st_240, v_ss_24114));
        {
          V v_field_24118 = v_t_24117.f[0];
          V v_field_24119 = v_t_24117.f[1];
          V v_x_24120 = v_field_24118;
          V v_y_24121 = v_field_24119;
          V v_t_24122 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24121}), v_sp_24116});
          return ((HeffT2){{v_x_24120, v_t_24122}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24126 = heff_field(v_x31_242, 0);
      V v_xsp_24127 = heff_field(v_x31_242, 1);
      V v_e_24128 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24130 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24131;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24131 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24131 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_24128)));
        }
        V v_t_24132 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24126, v_xsp_24127, v_e_24128}), v_sp_24130});
        return ((HeffT2){{v_x_24131, v_t_24132}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24133 = heff_field(v_x31_242, 0);
      V v_body_24134 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24136 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24137;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24137 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24137 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_c_24133)));
        }
        HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_x_24137, v_body_24134));
        {
          V v_field_24139 = v_t_24138.f[0];
          V v_field_24140 = v_t_24138.f[1];
          V v_x_24141 = v_field_24139;
          V v_y_24142 = v_field_24140;
          V v_t_24143 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24133, v_y_24142}), v_sp_24136});
          return ((HeffT2){{v_x_24141, v_t_24143}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24144 = heff_field(v_x31_242, 0);
      V v_c_24145 = heff_field(v_x31_242, 1);
      V v_body_24146 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24148 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24149;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24149 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24149 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_c_24145)));
        }
        HeffT2 v_t_24150 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_x_24149, v_body_24146));
        {
          V v_field_24151 = v_t_24150.f[0];
          V v_field_24152 = v_t_24150.f[1];
          V v_x_24153 = v_field_24151;
          V v_y_24154 = v_field_24152;
          V v_t_24155 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24144, v_c_24145, v_y_24154}), v_sp_24148});
          return ((HeffT2){{v_x_24153, v_t_24155}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24156 = heff_field(v_x31_242, 0);
      V v_a_24157 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24159 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24160 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24156, v_a_24157}), v_sp_24159});
          return ((HeffT2){{NTAG(TAG_True), v_t_24160}});
        } else {
          heff_drop(v_st_240);
          V v_x_24161 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_c_24156)));
          V v_x_24162;
          if ((heff_dup(v_x_24161) == NTAG(TAG_True))) {
            heff_drop(v_x_24161);
            v_x_24162 = NTAG(TAG_True);
          } else {
            heff_drop(v_x_24161);
            v_x_24162 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_a_24157)));
          }
          V v_t_24163 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24156, v_a_24157}), v_sp_24159});
          return ((HeffT2){{v_x_24162, v_t_24163}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24164 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24166 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24167;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24167 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24167 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_24164)));
        }
        V v_t_24168 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24164}), v_sp_24166});
        return ((HeffT2){{v_x_24167, v_t_24168}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24169 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24171 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24172;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24172 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24172 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_24169)));
        }
        V v_t_24173 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24169}), v_sp_24171});
        return ((HeffT2){{v_x_24172, v_t_24173}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24174 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24176 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24177;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24177 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24177 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_24174)));
        }
        V v_t_24178 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24174}), v_sp_24176});
        return ((HeffT2){{v_x_24177, v_t_24178}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24179 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24181 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24182 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1935226754x442916785_24cpr(v_st_240, v_es_24179));
        {
          V v_field_24183 = v_t_24182.f[0];
          V v_field_24184 = v_t_24182.f[1];
          V v_x_24185 = v_field_24183;
          V v_y_24186 = v_field_24184;
          V v_t_24187 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24186}), v_sp_24181});
          return ((HeffT2){{v_x_24185, v_t_24187}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24188 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24190 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24188)) {
        case TAG_MkTry: {
          V v_err_24191 = heff_field(v_tr_24188, 0);
          V v_body_24192 = heff_field(v_tr_24188, 1);
          V v_c_24193 = heff_field(v_tr_24188, 2);
          V v_ru_24tr_24188_24MkTry = heff_take_reuse_n(v_tr_24188, 7ULL, 3);
          HeffT2 v_t_24194 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_st_240, v_body_24192));
          {
            V v_field_24195 = v_t_24194.f[0];
            V v_field_24196 = v_t_24194.f[1];
            V v_x_24197 = v_field_24195;
            V v_y_24198 = v_field_24196;
            switch (heff_tag_of(v_c_24193)) {
            case TAG_MkCatchArm: {
              V v_b_24199 = heff_field(v_c_24193, 0);
              V v_ss_24200 = heff_field(v_c_24193, 1);
              heff_take_n(v_c_24193, 3ULL, 2);
              HeffT2 v_t_24201 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_x_24197, v_ss_24200));
              {
                V v_field_24202 = v_t_24201.f[0];
                V v_field_24203 = v_t_24201.f[1];
                V v_x_24204 = v_field_24202;
                V v_y_24205 = v_field_24203;
                V v_t_24206 = heff_tag_at_n(v_ru_24tr_24188_24MkTry, TAG_MkTry, 3, (V[]){v_err_24191, v_y_24198, heff_tag_n(TAG_MkCatchArm, 2, (V[]){v_b_24199, v_y_24205})});
                V v_t_24207 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24206}), v_sp_24190});
                return ((HeffT2){{v_x_24204, v_t_24207}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24193)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24188)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24208 = heff_field(v_x31_242, 0);
      V v_x_24209 = heff_field(v_x31_242, 1);
      V v_xsp_24210 = heff_field(v_x31_242, 2);
      V v_body_24211 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24213 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24214;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24214 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_24214 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_w_24208)));
        }
        HeffT2 v_t_24215 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1800031431x2136849781_24cpr(v_x_24214, v_body_24211));
        {
          V v_field_24216 = v_t_24215.f[0];
          V v_field_24217 = v_t_24215.f[1];
          V v_x_24218 = v_field_24216;
          V v_y_24219 = v_field_24217;
          V v_t_24220 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_24208, v_x_24209, v_xsp_24210, v_y_24219}), v_sp_24213});
          return ((HeffT2){{v_x_24218, v_t_24220}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsF_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2estmtsF(V v_t_240, V v_cx_241, V v_x3_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_241), heff_get_n(v_cx_241, 3, 6), v_end_243));
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_end_243)) {
      case TAG_EndValue: {
        return (g_heff_2esyntax_2epresyntax_2elastT(v_t_240, v_cx_241, heff_dup(v_s_244)));
      }
      case TAG_EndJump: {
        return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_244), heff_dup(v_x32_245), v_end_243));
      }
      case TAG_EndGive: {
        return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_244), heff_dup(v_x32_245), v_end_243));
      }
      default: return heff_nomatch(v_end_243);
      }
    }
    case TAG_Cons: {
      return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_244), heff_dup(v_x32_245), v_end_243));
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2estmtsF(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_242}});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_243}});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_244}});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_245}});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_246}});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241})}});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V v_r_240, V v_v_241, V v_sp_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_241}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_IsInferable: {
    V v_i_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsInferable = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    break;
  }
  case TAG_IsCheckable: {
    V v_c_248 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_t_2413 = v_c_248;
    break;
  }
  case TAG_IsType: {
    V v_t_249 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsType = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsType, TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2414));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0)}), heff_dup(v_sp_242)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_242)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_m_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_m_240, 2);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      heff_take_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tr(heff_call(heff_get_n(v_m_240, 1, 2), 2, (V[]){v_s_245, v_sp_246}));
        return heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_Cons, 2, (V[]){v_t_247, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_rest_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2410);
          V v_s_2415 = v_field_2414;
          V v_t_2421;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){v_s_2415, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_s0_2417 = heff_field(v_x11_2416, 0);
              V v_sp0_2418 = heff_field(v_x11_2416, 1);
              heff_take_n(v_x11_2416, 3ULL, 2);
              V v_t_2419 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2420 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2417, v_s_2415), v_t_2419});
              v_t_2421 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2420});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = v_t_2421;
          V t_3 = v_acc_243;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})}));
          V v_t_2427;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2427 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2423 = heff_field(v_run_242, 0);
            heff_take_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2423)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x21_2423, 0);
              V v_sp_2425 = heff_field(v_x21_2423, 1);
              heff_take_n(v_x21_2423, 3ULL, 2);
              V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 1)), 2, (V[]){v_s_2424, v_sp_2425}));
              v_t_2427 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2422, v_t_2427});
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 7ULL, 3);
      V v_t_246 = (g_list_2emap_24s1887874170x1747433177(v_args_245));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, v_t_246}), v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_247));
      V v_t_2420;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2411 = v_field_2410;
          V v_t_2414;
          switch (heff_tag_of(v_c_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_c_2411);
          }
          v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2415 = v_field_2410;
            V v_t_2418;
            switch (heff_tag_of(v_i_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_i_2415);
            }
            v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2415}), v_t_2418});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2419 = v_field_2410;
            v_t_2420 = v_t_2419;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2420}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(a[0]);
}