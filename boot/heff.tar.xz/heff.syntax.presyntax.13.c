// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IApp 21275
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TRune 58776
#define TAG_TString 39883
#define TAG_TType 56738
#define TAG_TypeWord 10401
#define LBL_e 319
#define LBL_end 310101
#define LBL_part 9928890
#define LBL_run 322821
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24dps_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1239681792x678203211_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1350453750x1419818528_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s643934088x525125611_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_243 = heff_from_int_u8(heff_intMod_lent(v_u_241, MK_INT(256LL), 2));
    V v_t_244 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_243)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_244;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_x_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkPair: {
      V v_st_246 = heff_field(v_x1_245, 0);
      V v_y_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 3ULL, 2);
      V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_247, heff_hole()});
      HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24dps_24cpr(v_f_240, v_st_246, v_xs_244, v_cell_248));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v__5f_2413 = v_field_2411;
        heff_drop(v__5f_2413);
        return ((HeffT2){{v_x_2412, v_cell_248}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_dup(heff_field(v_x3_242, 0));
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EBinary: {
      V v_segs_2414 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EBinary = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2416 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_2430 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0, 2, 1, (V[]){v_f_240}), v_st_241, v_segs_2414));
        {
          V v_field_2431 = v_t_2430.f[0];
          V v_field_2432 = v_t_2430.f[1];
          V v_x_2433 = v_field_2431;
          V v_y_2434 = v_field_2432;
          V v_t_2435 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EBinary, TAG_EBinary, 1, (V[]){v_y_2434}), v_sp_2416});
          return ((HeffT2){{v_x_2433, v_t_2435}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EApp: {
      V v_h_2438 = heff_field(v_x31_243, 0);
      V v_args_2439 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2441 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2442 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_h_2438}));
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_MkPair: {
          V v_x_2443 = heff_field(v_x1_2442, 0);
          V v_y_2444 = heff_field(v_x1_2442, 1);
          heff_take_n(v_x1_2442, 3ULL, 2);
          HeffT2 v_t_2445 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_x_2443, v_args_2439));
          {
            V v_field_2446 = v_t_2445.f[0];
            V v_field_2447 = v_t_2445.f[1];
            V v_x_2448 = v_field_2446;
            V v_y_2449 = v_field_2447;
            V v_t_2450 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EApp, TAG_EApp, 2, (V[]){v_y_2444, v_y_2449}), v_sp_2441});
            return ((HeffT2){{v_x_2448, v_t_2450}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2442)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ENamed: {
      V v_x_2452 = heff_field(v_x31_243, 0);
      V v_e_2453 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ENamed = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2455 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2456 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2453}));
        switch (heff_tag_of(v_x1_2456)) {
        case TAG_MkPair: {
          V v_x_2457 = heff_field(v_x1_2456, 0);
          V v_y_2458 = heff_field(v_x1_2456, 1);
          heff_take_n(v_x1_2456, 3ULL, 2);
          V v_t_2459 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24ENamed, TAG_ENamed, 2, 1ULL, (V[]){v_x_2452, v_y_2458}), v_sp_2455});
          return ((HeffT2){{v_x_2457, v_t_2459}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2456)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ELam: {
      V v_b_2462 = heff_field(v_x31_243, 0);
      V v_body_2463 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELam = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2465 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2466 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_body_2463}));
        switch (heff_tag_of(v_x1_2466)) {
        case TAG_MkPair: {
          V v_x_2467 = heff_field(v_x1_2466, 0);
          V v_y_2468 = heff_field(v_x1_2466, 1);
          heff_take_n(v_x1_2466, 3ULL, 2);
          V v_t_2469 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_b_2462, v_y_2468}), v_sp_2465});
          return ((HeffT2){{v_x_2467, v_t_2469}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2466)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2470 = heff_field(v_x31_243, 0);
      V v_t_2471 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EAnn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2473 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2474 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2470}));
        switch (heff_tag_of(v_x1_2474)) {
        case TAG_MkPair: {
          V v_x_2475 = heff_field(v_x1_2474, 0);
          V v_y_2476 = heff_field(v_x1_2474, 1);
          heff_take_n(v_x1_2474, 3ULL, 2);
          V v_t_2477 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24EAnn, TAG_EAnn, 2, 2ULL, (V[]){v_y_2476, v_t_2471}), v_sp_2473});
          return ((HeffT2){{v_x_2475, v_t_2477}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2474)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2478 = heff_field(v_x31_243, 0);
      V v_x_2479 = heff_field(v_x31_243, 1);
      V v_xsp_2480 = heff_field(v_x31_243, 2);
      V v_v_2481 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24ESpec = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2483 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2484 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2478}));
        switch (heff_tag_of(v_x1_2484)) {
        case TAG_MkPair: {
          V v_x_2485 = heff_field(v_x1_2484, 0);
          V v_y_2486 = heff_field(v_x1_2484, 1);
          heff_take_n(v_x1_2484, 3ULL, 2);
          V v_x1_2487 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_2485, v_v_2481}));
          switch (heff_tag_of(v_x1_2487)) {
          case TAG_MkPair: {
            V v_x_2488 = heff_field(v_x1_2487, 0);
            V v_y_2489 = heff_field(v_x1_2487, 1);
            heff_take_n(v_x1_2487, 3ULL, 2);
            V v_t_2490 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24ESpec, TAG_ESpec, 4, 6ULL, (V[]){v_y_2486, v_x_2479, v_xsp_2480, v_y_2489}), v_sp_2483});
            return ((HeffT2){{v_x_2488, v_t_2490}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2487)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2484)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EStruct: {
      V v_fs_2493 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EStruct = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2495 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_2496 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_f_240, v_st_241, v_fs_2493));
        {
          V v_field_2497 = v_t_2496.f[0];
          V v_field_2498 = v_t_2496.f[1];
          V v_x_2499 = v_field_2497;
          V v_y_24100 = v_field_2498;
          V v_t_24101 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EStruct, TAG_EStruct, 1, (V[]){v_y_24100}), v_sp_2495});
          return ((HeffT2){{v_x_2499, v_t_24101}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_24102 = heff_field(v_x31_243, 0);
      V v_fs_24103 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EUpdate = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24105 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24106 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_24102}));
        switch (heff_tag_of(v_x1_24106)) {
        case TAG_MkPair: {
          V v_x_24107 = heff_field(v_x1_24106, 0);
          V v_y_24108 = heff_field(v_x1_24106, 1);
          heff_take_n(v_x1_24106, 3ULL, 2);
          HeffT2 v_t_24119 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1, 2, 1, (V[]){v_f_240}), v_x_24107, v_fs_24103));
          {
            V v_field_24120 = v_t_24119.f[0];
            V v_field_24121 = v_t_24119.f[1];
            V v_x_24122 = v_field_24120;
            V v_y_24123 = v_field_24121;
            V v_t_24124 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EUpdate, TAG_EUpdate, 2, (V[]){v_y_24108, v_y_24123}), v_sp_24105});
            return ((HeffT2){{v_x_24122, v_t_24124}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24106)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24125 = heff_field(v_x31_243, 0);
      V v_alts_24126 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24128 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24129 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_s_24125}));
        switch (heff_tag_of(v_x1_24129)) {
        case TAG_MkPair: {
          V v_x_24130 = heff_field(v_x1_24129, 0);
          V v_y_24131 = heff_field(v_x1_24129, 1);
          heff_take_n(v_x1_24129, 3ULL, 2);
          HeffT2 v_t_24142 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2, 2, 1, (V[]){v_f_240}), v_x_24130, v_alts_24126));
          {
            V v_field_24143 = v_t_24142.f[0];
            V v_field_24144 = v_t_24142.f[1];
            V v_x_24145 = v_field_24143;
            V v_y_24146 = v_field_24144;
            V v_t_24147 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_24131, v_y_24146}), v_sp_24128});
            return ((HeffT2){{v_x_24145, v_t_24147}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24129)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24148 = heff_field(v_x31_243, 0);
      V v_a_24149 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELetIn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24151 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24152 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_rhs_24148}));
        switch (heff_tag_of(v_x1_24152)) {
        case TAG_MkPair: {
          V v_x_24153 = heff_field(v_x1_24152, 0);
          V v_y_24154 = heff_field(v_x1_24152, 1);
          V v_ru_24x1_24152_24MkPair = heff_take_reuse_n(v_x1_24152, 3ULL, 2);
          switch (heff_tag_of(v_a_24149)) {
          case TAG_At: {
            V v_x31_24155 = heff_field(v_a_24149, 0);
            V v_sp_24156 = heff_field(v_a_24149, 1);
            V v_ru_24a_24149_24At = heff_take_reuse_n(v_a_24149, 3ULL, 2);
            switch (heff_tag_of(v_x31_24155)) {
            case TAG_MkAlt: {
              V v_p_24157 = heff_field(v_x31_24155, 0);
              V v_e_24158 = heff_field(v_x31_24155, 1);
              heff_take_n(v_x31_24155, 3ULL, 2);
              V v_x1_24159 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24153, v_e_24158}));
              switch (heff_tag_of(v_x1_24159)) {
              case TAG_MkPair: {
                V v_x_24160 = heff_field(v_x1_24159, 0);
                V v_y_24161 = heff_field(v_x1_24159, 1);
                heff_take_n(v_x1_24159, 3ULL, 2);
                V v_t_24162 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkAlt, 2, (V[]){v_p_24157, v_y_24161}), v_sp_24156});
                V v_t_24163 = heff_tag_at_n(v_ru_24a_24149_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24154, v_t_24162}), v_sp_24151});
                return ((HeffT2){{v_x_24160, v_t_24163}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x1_24159)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24155)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24149)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24152)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24164 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EDo = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24166 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_t_24167 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_24168 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24167, v_st_241, v_ss_24164));
        {
          V v_field_24169 = v_t_24168.f[0];
          V v_field_24170 = v_t_24168.f[1];
          V v_x_24171 = v_field_24169;
          V v_y_24172 = v_field_24170;
          V v_t_24173 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EDo, TAG_EDo, 1, (V[]){v_y_24172}), v_sp_24166});
          return ((HeffT2){{v_x_24171, v_t_24173}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EAssign: {
      V v_x_24177 = heff_field(v_x31_243, 0);
      V v_xsp_24178 = heff_field(v_x31_243, 1);
      V v_e_24179 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EAssign = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24181 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24182 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24179}));
        switch (heff_tag_of(v_x1_24182)) {
        case TAG_MkPair: {
          V v_x_24183 = heff_field(v_x1_24182, 0);
          V v_y_24184 = heff_field(v_x1_24182, 1);
          heff_take_n(v_x1_24182, 3ULL, 2);
          V v_t_24185 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24EAssign, TAG_EAssign, 3, 3ULL, (V[]){v_x_24177, v_xsp_24178, v_y_24184}), v_sp_24181});
          return ((HeffT2){{v_x_24183, v_t_24185}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24182)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24186 = heff_field(v_x31_243, 0);
      V v_body_24187 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EWhile = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24189 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24190 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24186}));
        switch (heff_tag_of(v_x1_24190)) {
        case TAG_MkPair: {
          V v_x_24191 = heff_field(v_x1_24190, 0);
          V v_y_24192 = heff_field(v_x1_24190, 1);
          heff_take_n(v_x1_24190, 3ULL, 2);
          V v_t_24193 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24194 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24193, v_x_24191, v_body_24187));
          {
            V v_field_24195 = v_t_24194.f[0];
            V v_field_24196 = v_t_24194.f[1];
            V v_x_24197 = v_field_24195;
            V v_y_24198 = v_field_24196;
            V v_t_24199 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWhile, TAG_EWhile, 2, (V[]){v_y_24192, v_y_24198}), v_sp_24189});
            return ((HeffT2){{v_x_24197, v_t_24199}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24190)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EFor: {
      V v_p_24200 = heff_field(v_x31_243, 0);
      V v_c_24201 = heff_field(v_x31_243, 1);
      V v_body_24202 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EFor = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24204 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24205 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24201}));
        switch (heff_tag_of(v_x1_24205)) {
        case TAG_MkPair: {
          V v_x_24206 = heff_field(v_x1_24205, 0);
          V v_y_24207 = heff_field(v_x1_24205, 1);
          heff_take_n(v_x1_24205, 3ULL, 2);
          V v_t_24208 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24209 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24208, v_x_24206, v_body_24202));
          {
            V v_field_24210 = v_t_24209.f[0];
            V v_field_24211 = v_t_24209.f[1];
            V v_x_24212 = v_field_24210;
            V v_y_24213 = v_field_24211;
            V v_t_24214 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24EFor, TAG_EFor, 3, 1ULL, (V[]){v_p_24200, v_y_24207, v_y_24213}), v_sp_24204});
            return ((HeffT2){{v_x_24212, v_t_24214}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24205)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24215 = heff_field(v_x31_243, 0);
      V v_a_24216 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EIfThen = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24218 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24219 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24215}));
        switch (heff_tag_of(v_x1_24219)) {
        case TAG_MkPair: {
          V v_x_24220 = heff_field(v_x1_24219, 0);
          V v_y_24221 = heff_field(v_x1_24219, 1);
          heff_take_n(v_x1_24219, 3ULL, 2);
          V v_x1_24222 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24220, v_a_24216}));
          switch (heff_tag_of(v_x1_24222)) {
          case TAG_MkPair: {
            V v_x_24223 = heff_field(v_x1_24222, 0);
            V v_y_24224 = heff_field(v_x1_24222, 1);
            heff_take_n(v_x1_24222, 3ULL, 2);
            V v_t_24225 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EIfThen, TAG_EIfThen, 2, (V[]){v_y_24221, v_y_24224}), v_sp_24218});
            return ((HeffT2){{v_x_24223, v_t_24225}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_24222)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24219)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EContinue: {
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EReturn: {
      V v_e_24226 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EReturn = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24228 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24229 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24226}));
        switch (heff_tag_of(v_x1_24229)) {
        case TAG_MkPair: {
          V v_x_24230 = heff_field(v_x1_24229, 0);
          V v_y_24231 = heff_field(v_x1_24229, 1);
          heff_take_n(v_x1_24229, 3ULL, 2);
          V v_t_24232 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24EReturn, TAG_EReturn, 1, (V[]){v_y_24231}), v_sp_24228});
          return ((HeffT2){{v_x_24230, v_t_24232}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24229)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ENest: {
      V v_e_24233 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ENest = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24235 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24236 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24233}));
        switch (heff_tag_of(v_x1_24236)) {
        case TAG_MkPair: {
          V v_x_24237 = heff_field(v_x1_24236, 0);
          V v_y_24238 = heff_field(v_x1_24236, 1);
          heff_take_n(v_x1_24236, 3ULL, 2);
          V v_t_24239 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENest, TAG_ENest, 1, (V[]){v_y_24238}), v_sp_24235});
          return ((HeffT2){{v_x_24237, v_t_24239}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24236)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24240 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ELazy = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24242 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24243 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24240}));
        switch (heff_tag_of(v_x1_24243)) {
        case TAG_MkPair: {
          V v_x_24244 = heff_field(v_x1_24243, 0);
          V v_y_24245 = heff_field(v_x1_24243, 1);
          heff_take_n(v_x1_24243, 3ULL, 2);
          V v_t_24246 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELazy, TAG_ELazy, 1, (V[]){v_y_24245}), v_sp_24242});
          return ((HeffT2){{v_x_24244, v_t_24246}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24243)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24247 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETuple = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24249 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_24250 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_241, v_es_24247));
        {
          V v_field_24251 = v_t_24250.f[0];
          V v_field_24252 = v_t_24250.f[1];
          V v_x_24253 = v_field_24251;
          V v_y_24254 = v_field_24252;
          V v_t_24255 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETuple, TAG_ETuple, 1, (V[]){v_y_24254}), v_sp_24249});
          return ((HeffT2){{v_x_24253, v_t_24255}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24256 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETry = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24258 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_f_24259 = v_f_240;
        V v_st_24260 = v_st_241;
        V v_x3_24261 = v_tr_24256;
        V v_x1_24280;
        switch (heff_tag_of(v_x3_24261)) {
        case TAG_MkTry: {
          V v_err_24262 = heff_field(v_x3_24261, 0);
          V v_body_24263 = heff_field(v_x3_24261, 1);
          V v_c_24264 = heff_field(v_x3_24261, 2);
          V v_ru_24x3_24261_24MkTry = heff_take_reuse_n(v_x3_24261, 7ULL, 3);
          V v_t_24265 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){heff_dup(v_f_24259)}));
          HeffT2 v_t_24266 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24265, v_st_24260, v_body_24263));
          {
            V v_field_24267 = v_t_24266.f[0];
            V v_field_24268 = v_t_24266.f[1];
            V v_x_24269 = v_field_24267;
            V v_y_24270 = v_field_24268;
            switch (heff_tag_of(v_c_24264)) {
            case TAG_MkCatchArm: {
              V v_b_24271 = heff_field(v_c_24264, 0);
              V v_ss_24272 = heff_field(v_c_24264, 1);
              V v_ru_24c_24264_24MkCatchArm = heff_take_reuse_n(v_c_24264, 3ULL, 2);
              V v_t_24273 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_24259}));
              HeffT2 v_t_24274 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24273, v_x_24269, v_ss_24272));
              {
                V v_field_24275 = v_t_24274.f[0];
                V v_field_24276 = v_t_24274.f[1];
                V v_x_24277 = v_field_24275;
                V v_y_24278 = v_field_24276;
                V v_t_24279 = heff_tag_re_n(v_ru_24x3_24261_24MkTry, TAG_MkTry, 3, 1ULL, (V[]){v_err_24262, v_y_24270, heff_tag_re_n(v_ru_24c_24264_24MkCatchArm, TAG_MkCatchArm, 2, 1ULL, (V[]){v_b_24271, v_y_24278})});
                v_x1_24280 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24277, v_t_24279});
              }
              break;
            }
            default: heff_nomatch(v_c_24264);
            }
          }
          break;
        }
        default: heff_nomatch(v_x3_24261);
        }
        switch (heff_tag_of(v_x1_24280)) {
        case TAG_MkPair: {
          V v_x_24281 = heff_field(v_x1_24280, 0);
          V v_y_24282 = heff_field(v_x1_24280, 1);
          heff_take_n(v_x1_24280, 3ULL, 2);
          V v_t_24283 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETry, TAG_ETry, 1, (V[]){v_y_24282}), v_sp_24258});
          return ((HeffT2){{v_x_24281, v_t_24283}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24280)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWith: {
      V v_w_24284 = heff_field(v_x31_243, 0);
      V v_x_24285 = heff_field(v_x31_243, 1);
      V v_xsp_24286 = heff_field(v_x31_243, 2);
      V v_body_24287 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24EWith = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24289 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24290 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_w_24284}));
        switch (heff_tag_of(v_x1_24290)) {
        case TAG_MkPair: {
          V v_x_24291 = heff_field(v_x1_24290, 0);
          V v_y_24292 = heff_field(v_x1_24290, 1);
          heff_take_n(v_x1_24290, 3ULL, 2);
          V v_t_24293 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24294 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24293, v_x_24291, v_body_24287));
          {
            V v_field_24295 = v_t_24294.f[0];
            V v_field_24296 = v_t_24294.f[1];
            V v_x_24297 = v_field_24295;
            V v_y_24298 = v_field_24296;
            V v_t_24299 = heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_243_24EWith, TAG_EWith, 4, 6ULL, (V[]){v_y_24292, v_x_24285, v_xsp_24286, v_y_24298}), v_sp_24289});
            return ((HeffT2){{v_x_24297, v_t_24299}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24290)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWithBound: {
      V v_bs_24300 = heff_field(v_x31_243, 0);
      V v_w_24301 = heff_field(v_x31_243, 1);
      V v_body_24302 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EWithBound = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24304 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_24316 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam3, 2, 1, (V[]){heff_dup(v_f_240)}), v_st_241, v_bs_24300));
        {
          V v_field_24317 = v_t_24316.f[0];
          V v_field_24318 = v_t_24316.f[1];
          V v_x_24319 = v_field_24317;
          V v_y_24320 = v_field_24318;
          switch (heff_tag_of(v_w_24301)) {
          case TAG_Nothing: {
            heff_drop(v_f_240);
            V v_t_24321 = heff_tag_re_n(v_ru_24x31_243_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24320, NTAG(TAG_Nothing), v_body_24302});
            return ((HeffT2){{v_x_24319, heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_24321, v_sp_24304})}});
          }
          case TAG_Just: {
            V v_e_24322 = heff_field(v_w_24301, 0);
            V v_ru_24w_24301_24Just = heff_take_reuse_n(v_w_24301, 1ULL, 1);
            V v_x1_24323 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24319, v_e_24322}));
            switch (heff_tag_of(v_x1_24323)) {
            case TAG_MkPair: {
              V v_x_24324 = heff_field(v_x1_24323, 0);
              V v_y_24325 = heff_field(v_x1_24323, 1);
              heff_take_n(v_x1_24323, 3ULL, 2);
              V v_t_24326 = heff_tag_re_n(v_ru_24x31_243_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24320, heff_tag_at_n(v_ru_24w_24301_24Just, TAG_Just, 1, (V[]){v_y_24325}), v_body_24302});
              return ((HeffT2){{v_x_24324, heff_tag_re_n(v_ru_24x3_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_24326, v_sp_24304})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x1_24323)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_w_24301)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args) {
  V v_st_2417 = args[0];
  V v_x3_2418 = args[1];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_At: {
    V v_x31_2419 = heff_field(v_x3_2418, 0);
    V v_sp_2420 = heff_field(v_x3_2418, 1);
    V v_ru_24x3_2418_24At = heff_take_reuse_n(v_x3_2418, 3ULL, 2);
    switch (heff_tag_of(v_x31_2419)) {
    case TAG_MkSegment: {
      V v_v_2421 = heff_field(v_x31_2419, 0);
      V v_ty_2422 = heff_field(v_x31_2419, 1);
      V v_size_2423 = heff_field(v_x31_2419, 2);
      V v_little_2424 = heff_field(v_x31_2419, 3);
      V v_signed_2425 = heff_field(v_x31_2419, 4);
      V v_ru_24x31_2419_24MkSegment = heff_take_reuse_n(v_x31_2419, 31ULL, 5);
      heff_clo_take(self, 1);
      V v_x1_2426 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2417, v_v_2421}));
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        V v_y_2428 = heff_field(v_x1_2426, 1);
        V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
        V v_t_2429 = heff_tag_re_n(v_ru_24x3_2418_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_2419_24MkSegment, TAG_MkSegment, 5, 30ULL, (V[]){v_y_2428, v_ty_2422, v_size_2423, v_little_2424, v_signed_2425}), v_sp_2420});
        return heff_tag_re_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_2427, v_t_2429});
      }
      default: return heff_nomatch(v_x1_2426);
      }
    }
    default: return heff_nomatch(v_x31_2419);
    }
  }
  default: return heff_nomatch(v_x3_2418);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args) {
  V v_st_24109 = args[0];
  V v_x3_24110 = args[1];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_24110)) {
  case TAG_At: {
    V v_x31_24111 = heff_field(v_x3_24110, 0);
    V v_sp_24112 = heff_field(v_x3_24110, 1);
    V v_ru_24x3_24110_24At = heff_take_reuse_n(v_x3_24110, 3ULL, 2);
    switch (heff_tag_of(v_x31_24111)) {
    case TAG_SetPath: {
      V v_path_24113 = heff_field(v_x31_24111, 0);
      V v_e_24114 = heff_field(v_x31_24111, 1);
      V v_ru_24x31_24111_24SetPath = heff_take_reuse_n(v_x31_24111, 3ULL, 2);
      heff_clo_take(self, 1);
      V v_x1_24115 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24109, v_e_24114}));
      switch (heff_tag_of(v_x1_24115)) {
      case TAG_MkPair: {
        V v_x_24116 = heff_field(v_x1_24115, 0);
        V v_y_24117 = heff_field(v_x1_24115, 1);
        V v_ru_24x1_24115_24MkPair = heff_take_reuse_n(v_x1_24115, 3ULL, 2);
        V v_t_24118 = heff_tag_re_n(v_ru_24x3_24110_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_24111_24SetPath, TAG_SetPath, 2, 1ULL, (V[]){v_path_24113, v_y_24117}), v_sp_24112});
        return heff_tag_re_n(v_ru_24x1_24115_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_24116, v_t_24118});
      }
      default: return heff_nomatch(v_x1_24115);
      }
    }
    default: return heff_nomatch(v_x31_24111);
    }
  }
  default: return heff_nomatch(v_x3_24110);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args) {
  V v_st_24132 = args[0];
  V v_x3_24133 = args[1];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_24133)) {
  case TAG_At: {
    V v_x31_24134 = heff_field(v_x3_24133, 0);
    V v_sp_24135 = heff_field(v_x3_24133, 1);
    V v_ru_24x3_24133_24At = heff_take_reuse_n(v_x3_24133, 3ULL, 2);
    switch (heff_tag_of(v_x31_24134)) {
    case TAG_MkAlt: {
      V v_p_24136 = heff_field(v_x31_24134, 0);
      V v_e_24137 = heff_field(v_x31_24134, 1);
      V v_ru_24x31_24134_24MkAlt = heff_take_reuse_n(v_x31_24134, 3ULL, 2);
      heff_clo_take(self, 1);
      V v_x1_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24132, v_e_24137}));
      switch (heff_tag_of(v_x1_24138)) {
      case TAG_MkPair: {
        V v_x_24139 = heff_field(v_x1_24138, 0);
        V v_y_24140 = heff_field(v_x1_24138, 1);
        V v_ru_24x1_24138_24MkPair = heff_take_reuse_n(v_x1_24138, 3ULL, 2);
        V v_t_24141 = heff_tag_re_n(v_ru_24x3_24133_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_24134_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_24136, v_y_24140}), v_sp_24135});
        return heff_tag_re_n(v_ru_24x1_24138_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_24139, v_t_24141});
      }
      default: return heff_nomatch(v_x1_24138);
      }
    }
    default: return heff_nomatch(v_x31_24134);
    }
  }
  default: return heff_nomatch(v_x3_24133);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam3(V self, V *args) {
  V v_st_24305 = args[0];
  V v_x3_24306 = args[1];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_24306)) {
  case TAG_At: {
    V v_x31_24307 = heff_field(v_x3_24306, 0);
    V v_sp_24308 = heff_field(v_x3_24306, 1);
    V v_ru_24x3_24306_24At = heff_take_reuse_n(v_x3_24306, 3ULL, 2);
    switch (heff_tag_of(v_x31_24307)) {
    case TAG_MkBinding: {
      V v_x_24309 = heff_field(v_x31_24307, 0);
      V v_xsp_24310 = heff_field(v_x31_24307, 1);
      V v_e_24311 = heff_field(v_x31_24307, 2);
      V v_ru_24x31_24307_24MkBinding = heff_take_reuse_n(v_x31_24307, 7ULL, 3);
      heff_clo_take(self, 1);
      V v_x1_24312 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24305, v_e_24311}));
      switch (heff_tag_of(v_x1_24312)) {
      case TAG_MkPair: {
        V v_x_24313 = heff_field(v_x1_24312, 0);
        V v_y_24314 = heff_field(v_x1_24312, 1);
        V v_ru_24x1_24312_24MkPair = heff_take_reuse_n(v_x1_24312, 3ULL, 2);
        V v_t_24315 = heff_tag_re_n(v_ru_24x3_24306_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_24307_24MkBinding, TAG_MkBinding, 3, 3ULL, (V[]){v_x_24309, v_xsp_24310, v_y_24314}), v_sp_24308});
        return heff_tag_re_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_24313, v_t_24315});
      }
      default: return heff_nomatch(v_x1_24312);
      }
    }
    default: return heff_nomatch(v_x31_24307);
    }
  }
  default: return heff_nomatch(v_x3_24306);
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_SetPath: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24SetPath = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2410)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_2410, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2411, 0ULL, 4);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2435 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_2410)));
              {
                V v_field_2436 = v_t_2435.f[0];
                V v_field_2437 = v_t_2435.f[1];
                V v_a_2438 = v_field_2436;
                V v_a_2439 = v_field_2437;
                heff_drop(v_a_2439);
                v_a_2440 = v_a_2438;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
        }
        V v_t_2441 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24SetPath, TAG_SetPath, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2442 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2441, heff_hole()});
        V v_u_2443 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2442);
        V t_0 = v_a_2440;
        V t_1 = v_xs_246;
        V t_2 = v_u_2443;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_242, 0ULL, 3);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2415 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(v_st_240, v_segs_2413));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_x_2419 = v_field_2417;
          V v_y_2420 = v_field_2418;
          V v_t_2421 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2420}), v_sp_2415});
          return ((HeffT2){{v_x_2419, v_t_2421}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x31_242, 0);
      V v_args_2425 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2427 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2442;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2442 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_h_2424)) {
          case TAG_At: {
            V v_e1_2428 = heff_dup(heff_field(v_h_2424, 0));
            switch (heff_tag_of(v_e1_2428)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2428, 0ULL, 2);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2442 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2442 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2428);
              HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_h_2424)));
              {
                V v_field_2438 = v_t_2437.f[0];
                V v_field_2439 = v_t_2437.f[1];
                V v_x_2440 = v_field_2438;
                V v_y_2441 = v_field_2439;
                heff_drop(v_y_2441);
                v_x_2442 = v_x_2440;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_h_2424);
          }
        }
        HeffT2 v_t_2443 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(v_x_2442, v_args_2425));
        {
          V v_field_2444 = v_t_2443.f[0];
          V v_field_2445 = v_t_2443.f[1];
          V v_x_2446 = v_field_2444;
          V v_y_2447 = v_field_2445;
          V v_t_2448 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, 1ULL, (V[]){v_h_2424, v_y_2447}), v_sp_2427});
          return ((HeffT2){{v_x_2446, v_t_2448}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2450 = heff_field(v_x31_242, 0);
      V v_e_2451 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2453 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2468;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2468 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_2451)) {
          case TAG_At: {
            V v_e1_2454 = heff_dup(heff_field(v_e_2451, 0));
            switch (heff_tag_of(v_e1_2454)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2454, 0ULL, 2);
              switch (heff_tag_of(v_e_2451)) {
              case TAG_At: {
                v_x_2468 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2451);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2454, 0ULL, 1);
              switch (heff_tag_of(v_e_2451)) {
              case TAG_At: {
                v_x_2468 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2451);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2454);
              HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2451)));
              {
                V v_field_2464 = v_t_2463.f[0];
                V v_field_2465 = v_t_2463.f[1];
                V v_x_2466 = v_field_2464;
                V v_y_2467 = v_field_2465;
                heff_drop(v_y_2467);
                v_x_2468 = v_x_2466;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2451);
          }
        }
        V v_t_2469 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, 3ULL, (V[]){v_x_2450, v_e_2451}), v_sp_2453});
        return ((HeffT2){{v_x_2468, v_t_2469}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2472 = heff_field(v_x31_242, 0);
      V v_body_2473 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2475 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2490;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2490 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_body_2473)) {
          case TAG_At: {
            V v_e1_2476 = heff_dup(heff_field(v_body_2473, 0));
            switch (heff_tag_of(v_e1_2476)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2476, 0ULL, 2);
              switch (heff_tag_of(v_body_2473)) {
              case TAG_At: {
                v_x_2490 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_2473);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2476, 0ULL, 1);
              switch (heff_tag_of(v_body_2473)) {
              case TAG_At: {
                v_x_2490 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_body_2473);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2476);
              HeffT2 v_t_2485 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_body_2473)));
              {
                V v_field_2486 = v_t_2485.f[0];
                V v_field_2487 = v_t_2485.f[1];
                V v_x_2488 = v_field_2486;
                V v_y_2489 = v_field_2487;
                heff_drop(v_y_2489);
                v_x_2490 = v_x_2488;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_body_2473);
          }
        }
        V v_t_2491 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, 3ULL, (V[]){v_b_2472, v_body_2473}), v_sp_2475});
        return ((HeffT2){{v_x_2490, v_t_2491}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2492 = heff_field(v_x31_242, 0);
      V v_t_2493 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2495 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24110;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24110 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_2492)) {
          case TAG_At: {
            V v_e1_2496 = heff_dup(heff_field(v_e_2492, 0));
            switch (heff_tag_of(v_e1_2496)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2496, 0ULL, 2);
              switch (heff_tag_of(v_e_2492)) {
              case TAG_At: {
                v_x_24110 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2492);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2496, 0ULL, 1);
              switch (heff_tag_of(v_e_2492)) {
              case TAG_At: {
                v_x_24110 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2492);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2496);
              HeffT2 v_t_24105 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2492)));
              {
                V v_field_24106 = v_t_24105.f[0];
                V v_field_24107 = v_t_24105.f[1];
                V v_x_24108 = v_field_24106;
                V v_y_24109 = v_field_24107;
                heff_drop(v_y_24109);
                v_x_24110 = v_x_24108;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2492);
          }
        }
        V v_t_24111 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, 3ULL, (V[]){v_e_2492, v_t_2493}), v_sp_2495});
        return ((HeffT2){{v_x_24110, v_t_24111}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_24112 = heff_field(v_x31_242, 0);
      V v_x_24113 = heff_field(v_x31_242, 1);
      V v_xsp_24114 = heff_field(v_x31_242, 2);
      V v_v_24115 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24117 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24118 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24112, v_x_24113, v_xsp_24114, v_v_24115}), v_sp_24117});
          return ((HeffT2){{NTAG(TAG_True), v_t_24118}});
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24112)) {
          case TAG_At: {
            V v_e1_24119 = heff_dup(heff_field(v_a_24112, 0));
            switch (heff_tag_of(v_e1_24119)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24119, 0ULL, 2);
              V v_x_24137;
              switch (heff_tag_of(v_v_24115)) {
              case TAG_At: {
                V v_e1_24123 = heff_dup(heff_field(v_v_24115, 0));
                switch (heff_tag_of(v_e1_24123)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24123, 0ULL, 2);
                  switch (heff_tag_of(v_v_24115)) {
                  case TAG_At: {
                    v_x_24137 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24115);
                  }
                  break;
                }
                case TAG_EReturn: {
                  heff_take_n(v_e1_24123, 0ULL, 1);
                  switch (heff_tag_of(v_v_24115)) {
                  case TAG_At: {
                    v_x_24137 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24115);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24123);
                  HeffT2 v_t_24132 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_v_24115)));
                  {
                    V v_field_24133 = v_t_24132.f[0];
                    V v_field_24134 = v_t_24132.f[1];
                    V v_x_24135 = v_field_24133;
                    V v_y_24136 = v_field_24134;
                    heff_drop(v_y_24136);
                    v_x_24137 = v_x_24135;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24115);
              }
              V v_t_24138 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24112, v_x_24113, v_xsp_24114, v_v_24115}), v_sp_24117});
              return ((HeffT2){{v_x_24137, v_t_24138}});
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24119, 0ULL, 1);
              V v_t_24140 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24112, v_x_24113, v_xsp_24114, v_v_24115}), v_sp_24117});
              return ((HeffT2){{NTAG(TAG_True), v_t_24140}});
            }
            default: {
              heff_drop(v_e1_24119);
              HeffT2 v_t_24141 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24112)));
              {
                V v_field_24142 = v_t_24141.f[0];
                V v_field_24143 = v_t_24141.f[1];
                V v_x_24144 = v_field_24142;
                V v_y_24145 = v_field_24143;
                heff_drop(v_y_24145);
                V v_x_24160;
                if ((heff_dup(v_x_24144) == NTAG(TAG_True))) {
                  heff_drop(v_x_24144);
                  v_x_24160 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24144);
                  switch (heff_tag_of(v_v_24115)) {
                  case TAG_At: {
                    V v_e1_24146 = heff_dup(heff_field(v_v_24115, 0));
                    switch (heff_tag_of(v_e1_24146)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24146, 0ULL, 2);
                      switch (heff_tag_of(v_v_24115)) {
                      case TAG_At: {
                        v_x_24160 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24115);
                      }
                      break;
                    }
                    case TAG_EReturn: {
                      heff_take_n(v_e1_24146, 0ULL, 1);
                      switch (heff_tag_of(v_v_24115)) {
                      case TAG_At: {
                        v_x_24160 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_v_24115);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24146);
                      HeffT2 v_t_24155 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_v_24115)));
                      {
                        V v_field_24156 = v_t_24155.f[0];
                        V v_field_24157 = v_t_24155.f[1];
                        V v_x_24158 = v_field_24156;
                        V v_y_24159 = v_field_24157;
                        heff_drop(v_y_24159);
                        v_x_24160 = v_x_24158;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_v_24115);
                  }
                }
                V v_t_24161 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24112, v_x_24113, v_xsp_24114, v_v_24115}), v_sp_24117});
                return ((HeffT2){{v_x_24160, v_t_24161}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24112)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_24164 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24166 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24167 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(v_st_240, v_fs_24164));
        {
          V v_field_24168 = v_t_24167.f[0];
          V v_field_24169 = v_t_24167.f[1];
          V v_x_24170 = v_field_24168;
          V v_y_24171 = v_field_24169;
          V v_t_24172 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_24171}), v_sp_24166});
          return ((HeffT2){{v_x_24170, v_t_24172}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_24173 = heff_field(v_x31_242, 0);
      V v_fs_24174 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24176 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24191;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24191 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24173)) {
          case TAG_At: {
            V v_e1_24177 = heff_dup(heff_field(v_a_24173, 0));
            switch (heff_tag_of(v_e1_24177)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24177, 0ULL, 2);
              switch (heff_tag_of(v_a_24173)) {
              case TAG_At: {
                v_x_24191 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24173);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24177, 0ULL, 1);
              switch (heff_tag_of(v_a_24173)) {
              case TAG_At: {
                v_x_24191 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_24173);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24177);
              HeffT2 v_t_24186 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24173)));
              {
                V v_field_24187 = v_t_24186.f[0];
                V v_field_24188 = v_t_24186.f[1];
                V v_x_24189 = v_field_24187;
                V v_y_24190 = v_field_24188;
                heff_drop(v_y_24190);
                v_x_24191 = v_x_24189;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_24173);
          }
        }
        HeffT2 v_t_24192 = (g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(v_x_24191, v_fs_24174));
        {
          V v_field_24193 = v_t_24192.f[0];
          V v_field_24194 = v_t_24192.f[1];
          V v_x_24195 = v_field_24193;
          V v_y_24196 = v_field_24194;
          V v_t_24197 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, 1ULL, (V[]){v_a_24173, v_y_24196}), v_sp_24176});
          return ((HeffT2){{v_x_24195, v_t_24197}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24198 = heff_field(v_x31_242, 0);
      V v_alts_24199 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24201 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24216;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24216 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_s_24198)) {
          case TAG_At: {
            V v_e1_24202 = heff_dup(heff_field(v_s_24198, 0));
            switch (heff_tag_of(v_e1_24202)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24202, 0ULL, 2);
              switch (heff_tag_of(v_s_24198)) {
              case TAG_At: {
                v_x_24216 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24198);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24202, 0ULL, 1);
              switch (heff_tag_of(v_s_24198)) {
              case TAG_At: {
                v_x_24216 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_s_24198);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24202);
              HeffT2 v_t_24211 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_s_24198)));
              {
                V v_field_24212 = v_t_24211.f[0];
                V v_field_24213 = v_t_24211.f[1];
                V v_x_24214 = v_field_24212;
                V v_y_24215 = v_field_24213;
                heff_drop(v_y_24215);
                v_x_24216 = v_x_24214;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_s_24198);
          }
        }
        HeffT2 v_t_24217 = (g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(v_x_24216, v_alts_24199));
        {
          V v_field_24218 = v_t_24217.f[0];
          V v_field_24219 = v_t_24217.f[1];
          V v_x_24220 = v_field_24218;
          V v_y_24221 = v_field_24219;
          V v_t_24222 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_24198, v_y_24221}), v_sp_24201});
          return ((HeffT2){{v_x_24220, v_t_24222}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24223 = heff_field(v_x31_242, 0);
      V v_a_24224 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24226 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24224)) {
          case TAG_At: {
            V v_x31_24227 = heff_field(v_a_24224, 0);
            V v_sp_24228 = heff_field(v_a_24224, 1);
            V v_ru_24a_24224_24At = heff_take_reuse_n(v_a_24224, 3ULL, 2);
            switch (heff_tag_of(v_x31_24227)) {
            case TAG_MkAlt: {
              V v_p_24229 = heff_field(v_x31_24227, 0);
              V v_e_24230 = heff_field(v_x31_24227, 1);
              V v_ru_24x31_24227_24MkAlt = heff_take_reuse_n(v_x31_24227, 3ULL, 2);
              V v_t_24231 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24227_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24229, v_e_24230}), v_sp_24228});
              V v_t_24232 = heff_tag_at_n(v_ru_24a_24224_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_24223, v_t_24231}), v_sp_24226});
              return ((HeffT2){{NTAG(TAG_True), v_t_24232}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24227)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24224)}});
          }
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_rhs_24223)) {
          case TAG_At: {
            V v_e1_24233 = heff_dup(heff_field(v_rhs_24223, 0));
            switch (heff_tag_of(v_e1_24233)) {
            case TAG_ELam: {
              V v_ru_24e1_24233_24ELam = heff_take_reuse_n(v_e1_24233, 0ULL, 2);
              switch (heff_tag_of(v_a_24224)) {
              case TAG_At: {
                V v_x31_24237 = heff_field(v_a_24224, 0);
                V v_sp_24238 = heff_field(v_a_24224, 1);
                V v_ru_24a_24224_24At = heff_take_reuse_n(v_a_24224, 3ULL, 2);
                switch (heff_tag_of(v_x31_24237)) {
                case TAG_MkAlt: {
                  V v_p_24239 = heff_field(v_x31_24237, 0);
                  V v_e_24240 = heff_field(v_x31_24237, 1);
                  heff_take_n(v_x31_24237, 3ULL, 2);
                  V v_x_24255;
                  switch (heff_tag_of(v_e_24240)) {
                  case TAG_At: {
                    V v_e1_24241 = heff_dup(heff_field(v_e_24240, 0));
                    switch (heff_tag_of(v_e1_24241)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24241, 0ULL, 2);
                      switch (heff_tag_of(v_e_24240)) {
                      case TAG_At: {
                        v_x_24255 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_e_24240);
                      }
                      break;
                    }
                    case TAG_EReturn: {
                      heff_take_n(v_e1_24241, 0ULL, 1);
                      switch (heff_tag_of(v_e_24240)) {
                      case TAG_At: {
                        v_x_24255 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_e_24240);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24241);
                      HeffT2 v_t_24250 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24240)));
                      {
                        V v_field_24251 = v_t_24250.f[0];
                        V v_field_24252 = v_t_24250.f[1];
                        V v_x_24253 = v_field_24251;
                        V v_y_24254 = v_field_24252;
                        heff_drop(v_y_24254);
                        v_x_24255 = v_x_24253;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_e_24240);
                  }
                  V v_t_24256 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_24233_24ELam, TAG_MkAlt, 2, (V[]){v_p_24239, v_e_24240}), v_sp_24238});
                  V v_t_24257 = heff_tag_at_n(v_ru_24a_24224_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_24223, v_t_24256}), v_sp_24226});
                  return ((HeffT2){{v_x_24255, v_t_24257}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_24237)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_24224)}});
              }
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24233, 0ULL, 1);
              switch (heff_tag_of(v_a_24224)) {
              case TAG_At: {
                V v_x31_24259 = heff_field(v_a_24224, 0);
                V v_sp_24260 = heff_field(v_a_24224, 1);
                V v_ru_24a_24224_24At = heff_take_reuse_n(v_a_24224, 3ULL, 2);
                switch (heff_tag_of(v_x31_24259)) {
                case TAG_MkAlt: {
                  V v_p_24261 = heff_field(v_x31_24259, 0);
                  V v_e_24262 = heff_field(v_x31_24259, 1);
                  V v_ru_24x31_24259_24MkAlt = heff_take_reuse_n(v_x31_24259, 3ULL, 2);
                  V v_t_24263 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24259_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24261, v_e_24262}), v_sp_24260});
                  V v_t_24264 = heff_tag_at_n(v_ru_24a_24224_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_24223, v_t_24263}), v_sp_24226});
                  return ((HeffT2){{NTAG(TAG_True), v_t_24264}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_24259)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_24224)}});
              }
            }
            default: {
              heff_drop(v_e1_24233);
              HeffT2 v_t_24265 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_rhs_24223)));
              {
                V v_field_24266 = v_t_24265.f[0];
                V v_field_24267 = v_t_24265.f[1];
                V v_x_24268 = v_field_24266;
                V v_y_24269 = v_field_24267;
                heff_drop(v_y_24269);
                switch (heff_tag_of(v_a_24224)) {
                case TAG_At: {
                  V v_x31_24270 = heff_field(v_a_24224, 0);
                  V v_sp_24271 = heff_field(v_a_24224, 1);
                  V v_ru_24a_24224_24At = heff_take_reuse_n(v_a_24224, 3ULL, 2);
                  switch (heff_tag_of(v_x31_24270)) {
                  case TAG_MkAlt: {
                    V v_p_24272 = heff_field(v_x31_24270, 0);
                    V v_e_24273 = heff_field(v_x31_24270, 1);
                    V v_ru_24x31_24270_24MkAlt = heff_take_reuse_n(v_x31_24270, 3ULL, 2);
                    V v_x_24288;
                    if ((heff_dup(v_x_24268) == NTAG(TAG_True))) {
                      heff_drop(v_x_24268);
                      v_x_24288 = NTAG(TAG_True);
                    } else {
                      heff_drop(v_x_24268);
                      switch (heff_tag_of(v_e_24273)) {
                      case TAG_At: {
                        V v_e1_24274 = heff_dup(heff_field(v_e_24273, 0));
                        switch (heff_tag_of(v_e1_24274)) {
                        case TAG_ELam: {
                          heff_take_n(v_e1_24274, 0ULL, 2);
                          switch (heff_tag_of(v_e_24273)) {
                          case TAG_At: {
                            v_x_24288 = NTAG(TAG_False);
                            break;
                          }
                          default: heff_nomatch(v_e_24273);
                          }
                          break;
                        }
                        case TAG_EReturn: {
                          heff_take_n(v_e1_24274, 0ULL, 1);
                          switch (heff_tag_of(v_e_24273)) {
                          case TAG_At: {
                            v_x_24288 = NTAG(TAG_True);
                            break;
                          }
                          default: heff_nomatch(v_e_24273);
                          }
                          break;
                        }
                        default: {
                          heff_drop(v_e1_24274);
                          HeffT2 v_t_24283 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24273)));
                          {
                            V v_field_24284 = v_t_24283.f[0];
                            V v_field_24285 = v_t_24283.f[1];
                            V v_x_24286 = v_field_24284;
                            V v_y_24287 = v_field_24285;
                            heff_drop(v_y_24287);
                            v_x_24288 = v_x_24286;
                          }
                          break;
                        }
                        }
                        break;
                      }
                      default: heff_nomatch(v_e_24273);
                      }
                    }
                    V v_t_24289 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24270_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24272, v_e_24273}), v_sp_24271});
                    V v_t_24290 = heff_tag_at_n(v_ru_24a_24224_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_24223, v_t_24289}), v_sp_24226});
                    return ((HeffT2){{v_x_24288, v_t_24290}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24270)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_a_24224)}});
                }
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_rhs_24223)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24291 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24293 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24294 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_st_240, v_ss_24291));
        {
          V v_field_24295 = v_t_24294.f[0];
          V v_field_24296 = v_t_24294.f[1];
          V v_x_24297 = v_field_24295;
          V v_y_24298 = v_field_24296;
          V v_t_24299 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24298}), v_sp_24293});
          return ((HeffT2){{v_x_24297, v_t_24299}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24303 = heff_field(v_x31_242, 0);
      V v_xsp_24304 = heff_field(v_x31_242, 1);
      V v_e_24305 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24307 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24322;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24322 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24305)) {
          case TAG_At: {
            V v_e1_24308 = heff_dup(heff_field(v_e_24305, 0));
            switch (heff_tag_of(v_e1_24308)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24308, 0ULL, 2);
              switch (heff_tag_of(v_e_24305)) {
              case TAG_At: {
                v_x_24322 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24305);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24308, 0ULL, 1);
              switch (heff_tag_of(v_e_24305)) {
              case TAG_At: {
                v_x_24322 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24305);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24308);
              HeffT2 v_t_24317 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24305)));
              {
                V v_field_24318 = v_t_24317.f[0];
                V v_field_24319 = v_t_24317.f[1];
                V v_x_24320 = v_field_24318;
                V v_y_24321 = v_field_24319;
                heff_drop(v_y_24321);
                v_x_24322 = v_x_24320;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24305);
          }
        }
        V v_t_24323 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, 7ULL, (V[]){v_x_24303, v_xsp_24304, v_e_24305}), v_sp_24307});
        return ((HeffT2){{v_x_24322, v_t_24323}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24324 = heff_field(v_x31_242, 0);
      V v_body_24325 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24327 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24342;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24342 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24324)) {
          case TAG_At: {
            V v_e1_24328 = heff_dup(heff_field(v_c_24324, 0));
            switch (heff_tag_of(v_e1_24328)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24328, 0ULL, 2);
              switch (heff_tag_of(v_c_24324)) {
              case TAG_At: {
                v_x_24342 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24324);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24328, 0ULL, 1);
              switch (heff_tag_of(v_c_24324)) {
              case TAG_At: {
                v_x_24342 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24324);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24328);
              HeffT2 v_t_24337 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_24324)));
              {
                V v_field_24338 = v_t_24337.f[0];
                V v_field_24339 = v_t_24337.f[1];
                V v_x_24340 = v_field_24338;
                V v_y_24341 = v_field_24339;
                heff_drop(v_y_24341);
                v_x_24342 = v_x_24340;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24324);
          }
        }
        HeffT2 v_t_24343 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24342, v_body_24325));
        {
          V v_field_24344 = v_t_24343.f[0];
          V v_field_24345 = v_t_24343.f[1];
          V v_x_24346 = v_field_24344;
          V v_y_24347 = v_field_24345;
          V v_t_24348 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, 1ULL, (V[]){v_c_24324, v_y_24347}), v_sp_24327});
          return ((HeffT2){{v_x_24346, v_t_24348}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24349 = heff_field(v_x31_242, 0);
      V v_c_24350 = heff_field(v_x31_242, 1);
      V v_body_24351 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24353 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24368;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24368 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24350)) {
          case TAG_At: {
            V v_e1_24354 = heff_dup(heff_field(v_c_24350, 0));
            switch (heff_tag_of(v_e1_24354)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24354, 0ULL, 2);
              switch (heff_tag_of(v_c_24350)) {
              case TAG_At: {
                v_x_24368 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24350);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24354, 0ULL, 1);
              switch (heff_tag_of(v_c_24350)) {
              case TAG_At: {
                v_x_24368 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24350);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24354);
              HeffT2 v_t_24363 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_24350)));
              {
                V v_field_24364 = v_t_24363.f[0];
                V v_field_24365 = v_t_24363.f[1];
                V v_x_24366 = v_field_24364;
                V v_y_24367 = v_field_24365;
                heff_drop(v_y_24367);
                v_x_24368 = v_x_24366;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24350);
          }
        }
        HeffT2 v_t_24369 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24368, v_body_24351));
        {
          V v_field_24370 = v_t_24369.f[0];
          V v_field_24371 = v_t_24369.f[1];
          V v_x_24372 = v_field_24370;
          V v_y_24373 = v_field_24371;
          V v_t_24374 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, 3ULL, (V[]){v_p_24349, v_c_24350, v_y_24373}), v_sp_24353});
          return ((HeffT2){{v_x_24372, v_t_24374}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24375 = heff_field(v_x31_242, 0);
      V v_a_24376 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24378 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24379 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24375, v_a_24376}), v_sp_24378});
          return ((HeffT2){{NTAG(TAG_True), v_t_24379}});
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24375)) {
          case TAG_At: {
            V v_e1_24380 = heff_dup(heff_field(v_c_24375, 0));
            switch (heff_tag_of(v_e1_24380)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24380, 0ULL, 2);
              V v_x_24398;
              switch (heff_tag_of(v_a_24376)) {
              case TAG_At: {
                V v_e1_24384 = heff_dup(heff_field(v_a_24376, 0));
                switch (heff_tag_of(v_e1_24384)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24384, 0ULL, 2);
                  switch (heff_tag_of(v_a_24376)) {
                  case TAG_At: {
                    v_x_24398 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24376);
                  }
                  break;
                }
                case TAG_EReturn: {
                  heff_take_n(v_e1_24384, 0ULL, 1);
                  switch (heff_tag_of(v_a_24376)) {
                  case TAG_At: {
                    v_x_24398 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24376);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24384);
                  HeffT2 v_t_24393 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24376)));
                  {
                    V v_field_24394 = v_t_24393.f[0];
                    V v_field_24395 = v_t_24393.f[1];
                    V v_x_24396 = v_field_24394;
                    V v_y_24397 = v_field_24395;
                    heff_drop(v_y_24397);
                    v_x_24398 = v_x_24396;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24376);
              }
              V v_t_24399 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24375, v_a_24376}), v_sp_24378});
              return ((HeffT2){{v_x_24398, v_t_24399}});
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24380, 0ULL, 1);
              V v_t_24401 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24375, v_a_24376}), v_sp_24378});
              return ((HeffT2){{NTAG(TAG_True), v_t_24401}});
            }
            default: {
              heff_drop(v_e1_24380);
              HeffT2 v_t_24402 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_24375)));
              {
                V v_field_24403 = v_t_24402.f[0];
                V v_field_24404 = v_t_24402.f[1];
                V v_x_24405 = v_field_24403;
                V v_y_24406 = v_field_24404;
                heff_drop(v_y_24406);
                V v_x_24421;
                if ((heff_dup(v_x_24405) == NTAG(TAG_True))) {
                  heff_drop(v_x_24405);
                  v_x_24421 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24405);
                  switch (heff_tag_of(v_a_24376)) {
                  case TAG_At: {
                    V v_e1_24407 = heff_dup(heff_field(v_a_24376, 0));
                    switch (heff_tag_of(v_e1_24407)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24407, 0ULL, 2);
                      switch (heff_tag_of(v_a_24376)) {
                      case TAG_At: {
                        v_x_24421 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24376);
                      }
                      break;
                    }
                    case TAG_EReturn: {
                      heff_take_n(v_e1_24407, 0ULL, 1);
                      switch (heff_tag_of(v_a_24376)) {
                      case TAG_At: {
                        v_x_24421 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_a_24376);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24407);
                      HeffT2 v_t_24416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24376)));
                      {
                        V v_field_24417 = v_t_24416.f[0];
                        V v_field_24418 = v_t_24416.f[1];
                        V v_x_24419 = v_field_24417;
                        V v_y_24420 = v_field_24418;
                        heff_drop(v_y_24420);
                        v_x_24421 = v_x_24419;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_a_24376);
                  }
                }
                V v_t_24422 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24375, v_a_24376}), v_sp_24378});
                return ((HeffT2){{v_x_24421, v_t_24422}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_c_24375)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24423 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24425 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24423)) {
          case TAG_At: {
            V v_e1_24426 = heff_dup(heff_field(v_e_24423, 0));
            switch (heff_tag_of(v_e1_24426)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24426, 0ULL, 2);
              switch (heff_tag_of(v_e_24423)) {
              case TAG_At: {
                v_x_24440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24423);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24426, 0ULL, 1);
              switch (heff_tag_of(v_e_24423)) {
              case TAG_At: {
                v_x_24440 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24423);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24426);
              HeffT2 v_t_24435 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24423)));
              {
                V v_field_24436 = v_t_24435.f[0];
                V v_field_24437 = v_t_24435.f[1];
                V v_x_24438 = v_field_24436;
                V v_y_24439 = v_field_24437;
                heff_drop(v_y_24439);
                v_x_24440 = v_x_24438;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24423);
          }
        }
        V v_t_24441 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, 1ULL, (V[]){v_e_24423}), v_sp_24425});
        return ((HeffT2){{v_x_24440, v_t_24441}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24442 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24444 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24459;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24459 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24442)) {
          case TAG_At: {
            V v_e1_24445 = heff_dup(heff_field(v_e_24442, 0));
            switch (heff_tag_of(v_e1_24445)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24445, 0ULL, 2);
              switch (heff_tag_of(v_e_24442)) {
              case TAG_At: {
                v_x_24459 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24442);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24445, 0ULL, 1);
              switch (heff_tag_of(v_e_24442)) {
              case TAG_At: {
                v_x_24459 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24442);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24445);
              HeffT2 v_t_24454 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24442)));
              {
                V v_field_24455 = v_t_24454.f[0];
                V v_field_24456 = v_t_24454.f[1];
                V v_x_24457 = v_field_24455;
                V v_y_24458 = v_field_24456;
                heff_drop(v_y_24458);
                v_x_24459 = v_x_24457;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24442);
          }
        }
        V v_t_24460 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, 1ULL, (V[]){v_e_24442}), v_sp_24444});
        return ((HeffT2){{v_x_24459, v_t_24460}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24461 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24463 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24478;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24478 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24461)) {
          case TAG_At: {
            V v_e1_24464 = heff_dup(heff_field(v_e_24461, 0));
            switch (heff_tag_of(v_e1_24464)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24464, 0ULL, 2);
              switch (heff_tag_of(v_e_24461)) {
              case TAG_At: {
                v_x_24478 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24461);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24464, 0ULL, 1);
              switch (heff_tag_of(v_e_24461)) {
              case TAG_At: {
                v_x_24478 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24461);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24464);
              HeffT2 v_t_24473 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24461)));
              {
                V v_field_24474 = v_t_24473.f[0];
                V v_field_24475 = v_t_24473.f[1];
                V v_x_24476 = v_field_24474;
                V v_y_24477 = v_field_24475;
                heff_drop(v_y_24477);
                v_x_24478 = v_x_24476;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24461);
          }
        }
        V v_t_24479 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, 1ULL, (V[]){v_e_24461}), v_sp_24463});
        return ((HeffT2){{v_x_24478, v_t_24479}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24480 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24482 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24483 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(v_st_240, v_es_24480));
        {
          V v_field_24484 = v_t_24483.f[0];
          V v_field_24485 = v_t_24483.f[1];
          V v_x_24486 = v_field_24484;
          V v_y_24487 = v_field_24485;
          V v_t_24488 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24487}), v_sp_24482});
          return ((HeffT2){{v_x_24486, v_t_24488}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24489 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24491 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24489)) {
        case TAG_MkTry: {
          V v_err_24492 = heff_field(v_tr_24489, 0);
          V v_body_24493 = heff_field(v_tr_24489, 1);
          V v_c_24494 = heff_field(v_tr_24489, 2);
          V v_ru_24tr_24489_24MkTry = heff_take_reuse_n(v_tr_24489, 7ULL, 3);
          HeffT2 v_t_24495 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_st_240, v_body_24493));
          {
            V v_field_24496 = v_t_24495.f[0];
            V v_field_24497 = v_t_24495.f[1];
            V v_x_24498 = v_field_24496;
            V v_y_24499 = v_field_24497;
            switch (heff_tag_of(v_c_24494)) {
            case TAG_MkCatchArm: {
              V v_b_24500 = heff_field(v_c_24494, 0);
              V v_ss_24501 = heff_field(v_c_24494, 1);
              V v_ru_24c_24494_24MkCatchArm = heff_take_reuse_n(v_c_24494, 3ULL, 2);
              HeffT2 v_t_24502 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24498, v_ss_24501));
              {
                V v_field_24503 = v_t_24502.f[0];
                V v_field_24504 = v_t_24502.f[1];
                V v_x_24505 = v_field_24503;
                V v_y_24506 = v_field_24504;
                V v_t_24507 = heff_tag_re_n(v_ru_24tr_24489_24MkTry, TAG_MkTry, 3, 1ULL, (V[]){v_err_24492, v_y_24499, heff_tag_re_n(v_ru_24c_24494_24MkCatchArm, TAG_MkCatchArm, 2, 1ULL, (V[]){v_b_24500, v_y_24506})});
                V v_t_24508 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24507}), v_sp_24491});
                return ((HeffT2){{v_x_24505, v_t_24508}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24494)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24489)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24509 = heff_field(v_x31_242, 0);
      V v_x_24510 = heff_field(v_x31_242, 1);
      V v_xsp_24511 = heff_field(v_x31_242, 2);
      V v_body_24512 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24514 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24529;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24529 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_w_24509)) {
          case TAG_At: {
            V v_e1_24515 = heff_dup(heff_field(v_w_24509, 0));
            switch (heff_tag_of(v_e1_24515)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24515, 0ULL, 2);
              switch (heff_tag_of(v_w_24509)) {
              case TAG_At: {
                v_x_24529 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_24509);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24515, 0ULL, 1);
              switch (heff_tag_of(v_w_24509)) {
              case TAG_At: {
                v_x_24529 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_w_24509);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24515);
              HeffT2 v_t_24524 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_w_24509)));
              {
                V v_field_24525 = v_t_24524.f[0];
                V v_field_24526 = v_t_24524.f[1];
                V v_x_24527 = v_field_24525;
                V v_y_24528 = v_field_24526;
                heff_drop(v_y_24528);
                v_x_24529 = v_x_24527;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_w_24509);
          }
        }
        HeffT2 v_t_24530 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24529, v_body_24512));
        {
          V v_field_24531 = v_t_24530.f[0];
          V v_field_24532 = v_t_24530.f[1];
          V v_x_24533 = v_field_24531;
          V v_y_24534 = v_field_24532;
          V v_t_24535 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, 7ULL, (V[]){v_w_24509, v_x_24510, v_xsp_24511, v_y_24534}), v_sp_24514});
          return ((HeffT2){{v_x_24533, v_t_24535}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWithBound: {
      V v_bs_24536 = heff_field(v_x31_242, 0);
      V v_w_24537 = heff_field(v_x31_242, 1);
      V v_body_24538 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EWithBound = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24540 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24541 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1350453750x1419818528_24cpr(v_st_240, v_bs_24536));
        {
          V v_field_24542 = v_t_24541.f[0];
          V v_field_24543 = v_t_24541.f[1];
          V v_x_24544 = v_field_24542;
          V v_y_24545 = v_field_24543;
          switch (heff_tag_of(v_w_24537)) {
          case TAG_Nothing: {
            V v_t_24546 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24545, NTAG(TAG_Nothing), v_body_24538});
            return ((HeffT2){{v_x_24544, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24546, v_sp_24540})}});
          }
          case TAG_Just: {
            V v_e_24547 = heff_field(v_w_24537, 0);
            V v_ru_24w_24537_24Just = heff_take_reuse_n(v_w_24537, 1ULL, 1);
            V v_x_24562;
            if ((heff_dup(v_x_24544) == NTAG(TAG_True))) {
              heff_drop(v_x_24544);
              v_x_24562 = NTAG(TAG_True);
            } else {
              heff_drop(v_x_24544);
              switch (heff_tag_of(v_e_24547)) {
              case TAG_At: {
                V v_e1_24548 = heff_dup(heff_field(v_e_24547, 0));
                switch (heff_tag_of(v_e1_24548)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24548, 0ULL, 2);
                  switch (heff_tag_of(v_e_24547)) {
                  case TAG_At: {
                    v_x_24562 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_e_24547);
                  }
                  break;
                }
                case TAG_EReturn: {
                  heff_take_n(v_e1_24548, 0ULL, 1);
                  switch (heff_tag_of(v_e_24547)) {
                  case TAG_At: {
                    v_x_24562 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_e_24547);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24548);
                  HeffT2 v_t_24557 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24547)));
                  {
                    V v_field_24558 = v_t_24557.f[0];
                    V v_field_24559 = v_t_24557.f[1];
                    V v_x_24560 = v_field_24558;
                    V v_y_24561 = v_field_24559;
                    heff_drop(v_y_24561);
                    v_x_24562 = v_x_24560;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_e_24547);
              }
            }
            V v_t_24563 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24545, heff_tag_re_n(v_ru_24w_24537_24Just, TAG_Just, 1, 1ULL, (V[]){v_e_24547}), v_body_24538});
            return ((HeffT2){{v_x_24562, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24563, v_sp_24540})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_w_24537)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V v_lit_240, V v_cx_241, V v_sp_242) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_241, v_sp_242, v_lit_240);
}
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x31_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x31_244, 0);
        V v_xsp_247 = heff_field(v_x31_244, 1);
        V v_e_248 = heff_field(v_x31_244, 2);
        V v_ru_24x31_244_24SetField = heff_take_reuse_n(v_x31_244, 7ULL, 3);
        V v_x_249 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_248), v_st_240));
        V v_t_2410 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_244_24SetField, TAG_SetField, 3, 7ULL, (V[]){v_x_246, v_xsp_247, v_e_248}), v_sp_245});
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24dps_24cpr(v_x_249, v_xs_243, v_cell_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v__5f_2416 = v_field_2414;
          heff_drop(v__5f_2416);
          return ((HeffT2){{v_x_2415, v_cell_2411}});
        }
      }
      case TAG_BadFieldSet: {
        V v_e_2417 = heff_field(v_x31_244, 0);
        V v_ru_24x31_244_24BadFieldSet = heff_take_reuse_n(v_x31_244, 1ULL, 1);
        V v_x_2418 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2417), v_st_240));
        V v_t_2419 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_244_24BadFieldSet, TAG_BadFieldSet, 1, 1ULL, (V[]){v_e_2417}), v_sp_245});
        V v_cell_2420 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
        HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24dps_24cpr(v_x_2418, v_xs_243, v_cell_2420));
        {
          V v_field_2422 = v_t_2421.f[0];
          V v_field_2423 = v_t_2421.f[1];
          V v_x_2424 = v_field_2422;
          V v__5f_2425 = v_field_2423;
          heff_drop(v__5f_2425);
          return ((HeffT2){{v_x_2424, v_cell_2420}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_a_249 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_248), v_st_240));
        V v_t_2410 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 3, 7ULL, (V[]){v_a_246, v_a_247, v_a_248}), v_a_245});
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24dps_24cpr(v_a_249, v_xs_243, v_cell_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v__5f_2416 = v_field_2414;
          heff_drop(v__5f_2416);
          return ((HeffT2){{v_x_2415, v_cell_2411}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s643934088x525125611_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_242, 0ULL, 3);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2415 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24cpr(v_st_240, v_segs_2413));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_x_2419 = v_field_2417;
          V v_y_2420 = v_field_2418;
          V v_t_2421 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2420}), v_sp_2415});
          return ((HeffT2){{v_x_2419, v_t_2421}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x31_242, 0);
      V v_args_2425 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2427 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2428 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_h_2424), v_st_240));
        HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1239681792x678203211_24cpr(v_x_2428, v_args_2425));
        {
          V v_field_2430 = v_t_2429.f[0];
          V v_field_2431 = v_t_2429.f[1];
          V v_x_2432 = v_field_2430;
          V v_y_2433 = v_field_2431;
          V v_t_2434 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, 1ULL, (V[]){v_h_2424, v_y_2433}), v_sp_2427});
          return ((HeffT2){{v_x_2432, v_t_2434}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2436 = heff_field(v_x31_242, 0);
      V v_e_2437 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2439 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2440 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2437), v_st_240));
        V v_t_2441 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, 3ULL, (V[]){v_x_2436, v_e_2437}), v_sp_2439});
        return ((HeffT2){{v_x_2440, v_t_2441}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2444 = heff_field(v_x31_242, 0);
      V v_body_2445 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2447 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2448 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_body_2445), v_st_240));
        V v_t_2449 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, 3ULL, (V[]){v_b_2444, v_body_2445}), v_sp_2447});
        return ((HeffT2){{v_x_2448, v_t_2449}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2450 = heff_field(v_x31_242, 0);
      V v_t_2451 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2453 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2454 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2450), v_st_240));
        V v_t_2455 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, 3ULL, (V[]){v_e_2450, v_t_2451}), v_sp_2453});
        return ((HeffT2){{v_x_2454, v_t_2455}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2456 = heff_field(v_x31_242, 0);
      V v_x_2457 = heff_field(v_x31_242, 1);
      V v_xsp_2458 = heff_field(v_x31_242, 2);
      V v_v_2459 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2461 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2462 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_2456), v_st_240));
        V v_x_2463 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_v_2459), v_x_2462));
        V v_t_2464 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_2456, v_x_2457, v_xsp_2458, v_v_2459}), v_sp_2461});
        return ((HeffT2){{v_x_2463, v_t_2464}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_2467 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2469 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2470 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24cpr(v_st_240, v_fs_2467));
        {
          V v_field_2471 = v_t_2470.f[0];
          V v_field_2472 = v_t_2470.f[1];
          V v_x_2473 = v_field_2471;
          V v_y_2474 = v_field_2472;
          V v_t_2475 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_2474}), v_sp_2469});
          return ((HeffT2){{v_x_2473, v_t_2475}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2476 = heff_field(v_x31_242, 0);
      V v_fs_2477 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2479 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2480 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_2476), v_st_240));
        HeffT2 v_t_2481 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24cpr(v_x_2480, v_fs_2477));
        {
          V v_field_2482 = v_t_2481.f[0];
          V v_field_2483 = v_t_2481.f[1];
          V v_x_2484 = v_field_2482;
          V v_y_2485 = v_field_2483;
          V v_t_2486 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, 1ULL, (V[]){v_a_2476, v_y_2485}), v_sp_2479});
          return ((HeffT2){{v_x_2484, v_t_2486}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_2487 = heff_field(v_x31_242, 0);
      V v_alts_2488 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2490 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2491 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_s_2487), v_st_240));
        HeffT2 v_t_2492 = (g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24cpr(v_x_2491, v_alts_2488));
        {
          V v_field_2493 = v_t_2492.f[0];
          V v_field_2494 = v_t_2492.f[1];
          V v_x_2495 = v_field_2493;
          V v_y_2496 = v_field_2494;
          V v_t_2497 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2487, v_y_2496}), v_sp_2490});
          return ((HeffT2){{v_x_2495, v_t_2497}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_2498 = heff_field(v_x31_242, 0);
      V v_a_2499 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24101 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24102 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_rhs_2498), v_st_240));
        switch (heff_tag_of(v_a_2499)) {
        case TAG_At: {
          V v_x31_24103 = heff_field(v_a_2499, 0);
          V v_sp_24104 = heff_field(v_a_2499, 1);
          V v_ru_24a_2499_24At = heff_take_reuse_n(v_a_2499, 3ULL, 2);
          switch (heff_tag_of(v_x31_24103)) {
          case TAG_MkAlt: {
            V v_p_24105 = heff_field(v_x31_24103, 0);
            V v_e_24106 = heff_field(v_x31_24103, 1);
            V v_ru_24x31_24103_24MkAlt = heff_take_reuse_n(v_x31_24103, 3ULL, 2);
            V v_x_24107 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_24106), v_x_24102));
            V v_t_24108 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24103_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24105, v_e_24106}), v_sp_24104});
            V v_t_24109 = heff_tag_at_n(v_ru_24a_2499_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_2498, v_t_24108}), v_sp_24101});
            return ((HeffT2){{v_x_24107, v_t_24109}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_24103)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_2499)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24110 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24112 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24113 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_st_240, v_ss_24110));
        {
          V v_field_24114 = v_t_24113.f[0];
          V v_field_24115 = v_t_24113.f[1];
          V v_x_24116 = v_field_24114;
          V v_y_24117 = v_field_24115;
          V v_t_24118 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24117}), v_sp_24112});
          return ((HeffT2){{v_x_24116, v_t_24118}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24122 = heff_field(v_x31_242, 0);
      V v_xsp_24123 = heff_field(v_x31_242, 1);
      V v_e_24124 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24126 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24127 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_24124), v_st_240));
        V v_t_24128 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, 7ULL, (V[]){v_x_24122, v_xsp_24123, v_e_24124}), v_sp_24126});
        return ((HeffT2){{v_x_24127, v_t_24128}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24129 = heff_field(v_x31_242, 0);
      V v_body_24130 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24132 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24133 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_c_24129), v_st_240));
        HeffT2 v_t_24134 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_x_24133, v_body_24130));
        {
          V v_field_24135 = v_t_24134.f[0];
          V v_field_24136 = v_t_24134.f[1];
          V v_x_24137 = v_field_24135;
          V v_y_24138 = v_field_24136;
          V v_t_24139 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, 1ULL, (V[]){v_c_24129, v_y_24138}), v_sp_24132});
          return ((HeffT2){{v_x_24137, v_t_24139}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24140 = heff_field(v_x31_242, 0);
      V v_c_24141 = heff_field(v_x31_242, 1);
      V v_body_24142 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24144 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24145 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_c_24141), v_st_240));
        HeffT2 v_t_24146 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_x_24145, v_body_24142));
        {
          V v_field_24147 = v_t_24146.f[0];
          V v_field_24148 = v_t_24146.f[1];
          V v_x_24149 = v_field_24147;
          V v_y_24150 = v_field_24148;
          V v_t_24151 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, 3ULL, (V[]){v_p_24140, v_c_24141, v_y_24150}), v_sp_24144});
          return ((HeffT2){{v_x_24149, v_t_24151}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24152 = heff_field(v_x31_242, 0);
      V v_a_24153 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24155 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24156 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_c_24152), v_st_240));
        V v_x_24157 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_24153), v_x_24156));
        V v_t_24158 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24152, v_a_24153}), v_sp_24155});
        return ((HeffT2){{v_x_24157, v_t_24158}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24159 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24161 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24162 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_24159), v_st_240));
        V v_t_24163 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, 1ULL, (V[]){v_e_24159}), v_sp_24161});
        return ((HeffT2){{v_x_24162, v_t_24163}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24164 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24166 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24167 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_24164), v_st_240));
        V v_t_24168 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, 1ULL, (V[]){v_e_24164}), v_sp_24166});
        return ((HeffT2){{v_x_24167, v_t_24168}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24169 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24171 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24172 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_24169), v_st_240));
        V v_t_24173 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, 1ULL, (V[]){v_e_24169}), v_sp_24171});
        return ((HeffT2){{v_x_24172, v_t_24173}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24174 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24176 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24177 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1239681792x678203211_24cpr(v_st_240, v_es_24174));
        {
          V v_field_24178 = v_t_24177.f[0];
          V v_field_24179 = v_t_24177.f[1];
          V v_x_24180 = v_field_24178;
          V v_y_24181 = v_field_24179;
          V v_t_24182 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24181}), v_sp_24176});
          return ((HeffT2){{v_x_24180, v_t_24182}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24183 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24185 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24183)) {
        case TAG_MkTry: {
          V v_err_24186 = heff_field(v_tr_24183, 0);
          V v_body_24187 = heff_field(v_tr_24183, 1);
          V v_c_24188 = heff_field(v_tr_24183, 2);
          V v_ru_24tr_24183_24MkTry = heff_take_reuse_n(v_tr_24183, 7ULL, 3);
          HeffT2 v_t_24189 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_st_240, v_body_24187));
          {
            V v_field_24190 = v_t_24189.f[0];
            V v_field_24191 = v_t_24189.f[1];
            V v_x_24192 = v_field_24190;
            V v_y_24193 = v_field_24191;
            switch (heff_tag_of(v_c_24188)) {
            case TAG_MkCatchArm: {
              V v_b_24194 = heff_field(v_c_24188, 0);
              V v_ss_24195 = heff_field(v_c_24188, 1);
              V v_ru_24c_24188_24MkCatchArm = heff_take_reuse_n(v_c_24188, 3ULL, 2);
              HeffT2 v_t_24196 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_x_24192, v_ss_24195));
              {
                V v_field_24197 = v_t_24196.f[0];
                V v_field_24198 = v_t_24196.f[1];
                V v_x_24199 = v_field_24197;
                V v_y_24200 = v_field_24198;
                V v_t_24201 = heff_tag_re_n(v_ru_24tr_24183_24MkTry, TAG_MkTry, 3, 1ULL, (V[]){v_err_24186, v_y_24193, heff_tag_re_n(v_ru_24c_24188_24MkCatchArm, TAG_MkCatchArm, 2, 1ULL, (V[]){v_b_24194, v_y_24200})});
                V v_t_24202 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24201}), v_sp_24185});
                return ((HeffT2){{v_x_24199, v_t_24202}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24188)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24183)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24203 = heff_field(v_x31_242, 0);
      V v_x_24204 = heff_field(v_x31_242, 1);
      V v_xsp_24205 = heff_field(v_x31_242, 2);
      V v_body_24206 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24208 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24209 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_w_24203), v_st_240));
        HeffT2 v_t_24210 = (g_heff_2esyntax_2epresyntax_2eaccList_24s564340418x743780676_24cpr(v_x_24209, v_body_24206));
        {
          V v_field_24211 = v_t_24210.f[0];
          V v_field_24212 = v_t_24210.f[1];
          V v_x_24213 = v_field_24211;
          V v_y_24214 = v_field_24212;
          V v_t_24215 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, 7ULL, (V[]){v_w_24203, v_x_24204, v_xsp_24205, v_y_24214}), v_sp_24208});
          return ((HeffT2){{v_x_24213, v_t_24215}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWithBound: {
      V v_bs_24216 = heff_field(v_x31_242, 0);
      V v_w_24217 = heff_field(v_x31_242, 1);
      V v_body_24218 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EWithBound = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24220 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24221 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1978526359x90381742_24cpr(v_st_240, v_bs_24216));
        {
          V v_field_24222 = v_t_24221.f[0];
          V v_field_24223 = v_t_24221.f[1];
          V v_x_24224 = v_field_24222;
          V v_y_24225 = v_field_24223;
          switch (heff_tag_of(v_w_24217)) {
          case TAG_Nothing: {
            V v_t_24226 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24225, NTAG(TAG_Nothing), v_body_24218});
            return ((HeffT2){{v_x_24224, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24226, v_sp_24220})}});
          }
          case TAG_Just: {
            V v_e_24227 = heff_field(v_w_24217, 0);
            V v_ru_24w_24217_24Just = heff_take_reuse_n(v_w_24217, 1ULL, 1);
            V v_x_24228 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_24227), v_x_24224));
            V v_t_24229 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_24225, heff_tag_re_n(v_ru_24w_24217_24Just, TAG_Just, 1, 1ULL, (V[]){v_e_24227}), v_body_24218});
            return ((HeffT2){{v_x_24228, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24229, v_sp_24220})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_w_24217)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0, 22, "`Array` takes one type");

HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_TType), v_sp_241}});
  }
  case TAG_IntWord: {
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_TInt), v_sp_241}});
  }
  case TAG_FloatWord: {
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_TFloat), v_sp_241}});
  }
  case TAG_StringWord: {
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_TString), v_sp_241}});
  }
  case TAG_RuneWord: {
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_TRune), v_sp_241}});
  }
  case TAG_ArrayWord: {
    V v_t_242 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_243 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_241)})});
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_t_243, v_sp_241}});
  }
  case TAG_AbandonWord: {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CAbandon), v_sp_241}});
  }
  case TAG_FixedWord: {
    V v_w_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_244}), v_sp_241}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V v_r_240, V v_v_241, V v_sp_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_241}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_IsInferable: {
    V v_i_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsInferable = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    break;
  }
  case TAG_IsCheckable: {
    V v_c_248 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_t_2413 = v_c_248;
    break;
  }
  case TAG_IsType: {
    V v_t_249 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsType = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsType, TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2414));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0)}), heff_dup(v_sp_242)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_242)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_m_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_m_240, 2);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      heff_take_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tr(heff_call(heff_get_n(v_m_240, 1, 2), 2, (V[]){v_s_245, v_sp_246}));
        return heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_Cons, 2, (V[]){v_t_247, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_rest_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2410);
          V v_s_2415 = v_field_2414;
          V v_t_2421;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){v_s_2415, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_s0_2417 = heff_field(v_x11_2416, 0);
              V v_sp0_2418 = heff_field(v_x11_2416, 1);
              heff_take_n(v_x11_2416, 3ULL, 2);
              V v_t_2419 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2420 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2417, v_s_2415), v_t_2419});
              v_t_2421 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2420});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = v_t_2421;
          V t_3 = v_acc_243;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})}));
          V v_t_2427;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2427 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2423 = heff_field(v_run_242, 0);
            heff_take_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2423)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x21_2423, 0);
              V v_sp_2425 = heff_field(v_x21_2423, 1);
              heff_take_n(v_x21_2423, 3ULL, 2);
              V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 1)), 2, (V[]){v_s_2424, v_sp_2425}));
              v_t_2427 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2422, v_t_2427});
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eappOf_24tok2(V v_tok_240, V v_r_241, V v_h_242, V v_args_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_At: {
    V v_h1_245 = heff_dup(heff_field(v_h_242, 0));
    switch (heff_tag_of(v_h1_245)) {
    case TAG_ETag: {
      V v_t_247 = heff_field(v_h1_245, 0);
      V v_ru_24h1_245_24ETag = heff_take_reuse_n(v_h1_245, 1ULL, 1);
      switch (heff_tag_of(v_h_242)) {
      case TAG_At: {
        V v_tsp_249 = heff_field(v_h_242, 1);
        V v_ru_24h_242_24At = heff_take_reuse_n(v_h_242, 2ULL, 2);
        V v_t_2421 = (g_list_2emap_24tok2(v_ru_24h_242_24At, heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_24tok2_lam0, 1, 1, (V[]){v_r_241}), v_args_243));
        V v_t_2422 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, v_tsp_249, v_t_2421}), v_sp_244});
        return heff_tag_at_n(v_ru_24h1_245_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2422});
      }
      default: return heff_nomatch(v_h_242);
      }
    }
    case TAG_EWord: {
      V v_h11_2423 = heff_field(v_h1_245, 0);
      V v_ru_24h1_245_24EWord = heff_take_reuse_n(v_h1_245, 1ULL, 1);
      switch (heff_tag_of(v_h11_2423)) {
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_242, 2);
        switch (heff_tag_of(v_args_243)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_241, 2);
          V v_t_2424 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str0), NTAG(TAG_Nothing)});
          V v_t_2425 = heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_244)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_244})});
        }
        case TAG_Cons: {
          V v_a_2426 = heff_field(v_args_243, 0);
          V v_args2_2427 = heff_field(v_args_243, 1);
          V v_ru_24args_243_24Cons = heff_take_reuse_n(v_args_243, 3ULL, 2);
          switch (heff_tag_of(v_args2_2427)) {
          case TAG_Nil: {
            V v_x1_2428 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_a_2426}));
            V v_t_2438;
            switch (heff_tag_of(v_x1_2428)) {
            case TAG_IsInferable: {
              V v_i_2429 = heff_field(v_x1_2428, 0);
              heff_take_n(v_x1_2428, 1ULL, 1);
              V v_t_2432;
              switch (heff_tag_of(v_i_2429)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_i_2429);
              }
              v_t_2438 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2433 = heff_field(v_x1_2428, 0);
              heff_take_n(v_x1_2428, 1ULL, 1);
              V v_t_2436;
              switch (heff_tag_of(v_c_2433)) {
              case TAG_At: {
                V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
                v_t_2436 = v_s_2435;
                break;
              }
              default: heff_nomatch(v_c_2433);
              }
              v_t_2438 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
              break;
            }
            case TAG_IsType: {
              V v_t_2437 = heff_field(v_x1_2428, 0);
              heff_take_n(v_x1_2428, 1ULL, 1);
              heff_drop_cell(v_tok_240, 2);
              heff_drop_cell(v_ru_24h1_245_24EWord, 1);
              v_t_2438 = v_t_2437;
              break;
            }
            default: heff_nomatch(v_x1_2428);
            }
            V v_t_2439 = heff_tag_at_n(v_ru_24args_243_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2438}), v_sp_244});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2439});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2427, 0ULL, 2);
            heff_drop_rec(v_r_241, 2);
            heff_drop(v_a_2426);
            V v_t_2442 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str1), NTAG(TAG_Nothing)});
            V v_t_2443 = heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2442, heff_dup(v_sp_244)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args_243_24Cons, TAG_At, 2, (V[]){v_t_2443, v_sp_244})});
          }
          default: return heff_nomatch(v_args2_2427);
          }
        }
        default: return heff_nomatch(v_args_243);
        }
      }
      default: {
        heff_drop(v_h11_2423);
        V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){v_h_242}));
        V v_t_2445 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2444));
        V v_t_2446 = (g_list_2emap_24s942566919x1152393003(v_r_241, v_args_243));
        V v_t_2447 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, v_t_2446}), v_sp_244});
        return heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_IsInferable, 1, (V[]){v_t_2447});
      }
      }
    }
    default: {
      heff_drop(v_h1_245);
      V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){v_h_242}));
      V v_t_2449 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2448));
      V v_t_2450 = (g_list_2emap_24s942566919x1152393003(v_r_241, v_args_243));
      V v_t_2451 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2449, v_t_2450}), v_sp_244});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2451});
    }
    }
  }
  default: return heff_nomatch(v_h_242);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_lam0(V self, V *args) {
  V v_e_2410 = args[0];
  V v_r_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_e_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_IsInferable: {
    V v_i_2412 = heff_field(v_x1_2411, 0);
    V v_ru_24x1_2411_24IsInferable = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_i_2412)) {
    case TAG_At: {
      V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
      v_t_2415 = v_s_2414;
      break;
    }
    default: heff_nomatch(v_i_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsInferable, TAG_CInf, 1, (V[]){v_i_2412}), v_t_2415});
  }
  case TAG_IsCheckable: {
    V v_c_2416 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    return v_c_2416;
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_2411, 0);
    V v_ru_24x1_2411_24IsType = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_At: {
      V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
      v_t_2420 = v_s_2419;
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsType, TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
  }
  default: return heff_nomatch(v_x1_2411);
  }
}