// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IApp 21275
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_RuneWord 42901
#define TAG_SetPath 11095
#define TAG_StringWord 15530
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TRune 58776
#define TAG_TString 39883
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_names 305943394
#define LBL_part 9928890
#define LBL_pure 9948095
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2elastT(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
V g_heff_2esyntax_2epresyntax_2estmtT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2etryAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_244 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_245 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_244)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_x_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkPair: {
      V v_st_246 = heff_field(v_x1_245, 0);
      V v_y_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_246, v_xs_244));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_y_2412 = v_field_2410;
        return ((HeffT2){{v_x_2411, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_247, v_y_2412})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_dup(heff_field(v_x3_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_x3_242, 1));
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EBinary: {
      V v_segs_2411 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EBinary = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0, 2, 1, (V[]){v_f_240}), v_st_241, v_segs_2411));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_x_2428 = v_field_2426;
        V v_y_2429 = v_field_2427;
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EBinary, TAG_EBinary, 1, (V[]){v_y_2429}), v_sp_244});
        return ((HeffT2){{v_x_2428, v_t_2430}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EApp: {
      V v_h_2433 = heff_field(v_x31_243, 0);
      V v_args_2434 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2435 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_h_2433}));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_MkPair: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        V v_y_2437 = heff_field(v_x1_2435, 1);
        V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
        HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_x_2436, v_args_2434));
        {
          V v_field_2439 = v_t_2438.f[0];
          V v_field_2440 = v_t_2438.f[1];
          V v_x_2441 = v_field_2439;
          V v_y_2442 = v_field_2440;
          V v_t_2443 = heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EApp, TAG_EApp, 2, (V[]){v_y_2437, v_y_2442}), v_sp_244});
          return ((HeffT2){{v_x_2441, v_t_2443}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2435)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ENamed: {
      V v_x_2445 = heff_field(v_x31_243, 0);
      V v_e_2446 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ENamed = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2447 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2446}));
      switch (heff_tag_of(v_x1_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x1_2447, 0);
        V v_y_2449 = heff_field(v_x1_2447, 1);
        V v_ru_24x1_2447_24MkPair = heff_take_reuse_n(v_x1_2447, 3ULL, 2);
        V v_t_2450 = heff_tag_at_n(v_ru_24x1_2447_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENamed, TAG_ENamed, 2, (V[]){v_x_2445, v_y_2449}), v_sp_244});
        return ((HeffT2){{v_x_2448, v_t_2450}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2447)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ELam: {
      V v_b_2453 = heff_field(v_x31_243, 0);
      V v_body_2454 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELam = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2455 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_body_2454}));
      switch (heff_tag_of(v_x1_2455)) {
      case TAG_MkPair: {
        V v_x_2456 = heff_field(v_x1_2455, 0);
        V v_y_2457 = heff_field(v_x1_2455, 1);
        V v_ru_24x1_2455_24MkPair = heff_take_reuse_n(v_x1_2455, 3ULL, 2);
        V v_t_2458 = heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELam, TAG_ELam, 2, (V[]){v_b_2453, v_y_2457}), v_sp_244});
        return ((HeffT2){{v_x_2456, v_t_2458}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2455)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2459 = heff_field(v_x31_243, 0);
      V v_t_2460 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EAnn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2461 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2459}));
      switch (heff_tag_of(v_x1_2461)) {
      case TAG_MkPair: {
        V v_x_2462 = heff_field(v_x1_2461, 0);
        V v_y_2463 = heff_field(v_x1_2461, 1);
        V v_ru_24x1_2461_24MkPair = heff_take_reuse_n(v_x1_2461, 3ULL, 2);
        V v_t_2464 = heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAnn, TAG_EAnn, 2, (V[]){v_y_2463, v_t_2460}), v_sp_244});
        return ((HeffT2){{v_x_2462, v_t_2464}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2461)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2465 = heff_field(v_x31_243, 0);
      V v_x_2466 = heff_field(v_x31_243, 1);
      V v_xsp_2467 = heff_field(v_x31_243, 2);
      V v_v_2468 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24ESpec = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2469 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2465}));
      switch (heff_tag_of(v_x1_2469)) {
      case TAG_MkPair: {
        V v_x_2470 = heff_field(v_x1_2469, 0);
        V v_y_2471 = heff_field(v_x1_2469, 1);
        V v_ru_24x1_2469_24MkPair = heff_take_reuse_n(v_x1_2469, 3ULL, 2);
        V v_x1_2472 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_2470, v_v_2468}));
        switch (heff_tag_of(v_x1_2472)) {
        case TAG_MkPair: {
          V v_x_2473 = heff_field(v_x1_2472, 0);
          V v_y_2474 = heff_field(v_x1_2472, 1);
          heff_take_n(v_x1_2472, 3ULL, 2);
          V v_t_2475 = heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ESpec, TAG_ESpec, 4, (V[]){v_y_2471, v_x_2466, v_xsp_2467, v_y_2474}), v_sp_244});
          return ((HeffT2){{v_x_2473, v_t_2475}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2472)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2469)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EStruct: {
      V v_fs_2478 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EStruct = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_f_240, v_st_241, v_fs_2478));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_y_2483 = v_field_2481;
        V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EStruct, TAG_EStruct, 1, (V[]){v_y_2483}), v_sp_244});
        return ((HeffT2){{v_x_2482, v_t_2484}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2485 = heff_field(v_x31_243, 0);
      V v_fs_2486 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EUpdate = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2487 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2485}));
      switch (heff_tag_of(v_x1_2487)) {
      case TAG_MkPair: {
        V v_x_2488 = heff_field(v_x1_2487, 0);
        V v_y_2489 = heff_field(v_x1_2487, 1);
        V v_ru_24x1_2487_24MkPair = heff_take_reuse_n(v_x1_2487, 3ULL, 2);
        HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1, 2, 1, (V[]){v_f_240}), v_x_2488, v_fs_2486));
        {
          V v_field_24101 = v_t_24100.f[0];
          V v_field_24102 = v_t_24100.f[1];
          V v_x_24103 = v_field_24101;
          V v_y_24104 = v_field_24102;
          V v_t_24105 = heff_tag_at_n(v_ru_24x1_2487_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EUpdate, TAG_EUpdate, 2, (V[]){v_y_2489, v_y_24104}), v_sp_244});
          return ((HeffT2){{v_x_24103, v_t_24105}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2487)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24106 = heff_field(v_x31_243, 0);
      V v_alts_24107 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24108 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_s_24106}));
      switch (heff_tag_of(v_x1_24108)) {
      case TAG_MkPair: {
        V v_x_24109 = heff_field(v_x1_24108, 0);
        V v_y_24110 = heff_field(v_x1_24108, 1);
        V v_ru_24x1_24108_24MkPair = heff_take_reuse_n(v_x1_24108, 3ULL, 2);
        HeffT2 v_t_24121 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2, 2, 1, (V[]){v_f_240}), v_x_24109, v_alts_24107));
        {
          V v_field_24122 = v_t_24121.f[0];
          V v_field_24123 = v_t_24121.f[1];
          V v_x_24124 = v_field_24122;
          V v_y_24125 = v_field_24123;
          V v_t_24126 = heff_tag_at_n(v_ru_24x1_24108_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_24110, v_y_24125}), v_sp_244});
          return ((HeffT2){{v_x_24124, v_t_24126}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24108)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24127 = heff_field(v_x31_243, 0);
      V v_a_24128 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELetIn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24129 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_rhs_24127}));
      switch (heff_tag_of(v_x1_24129)) {
      case TAG_MkPair: {
        V v_x_24130 = heff_field(v_x1_24129, 0);
        V v_y_24131 = heff_field(v_x1_24129, 1);
        V v_ru_24x1_24129_24MkPair = heff_take_reuse_n(v_x1_24129, 3ULL, 2);
        switch (heff_tag_of(v_a_24128)) {
        case TAG_At: {
          V v_x31_24132 = heff_field(v_a_24128, 0);
          V v_sp_24133 = heff_field(v_a_24128, 1);
          V v_ru_24a_24128_24At = heff_take_reuse_n(v_a_24128, 3ULL, 2);
          switch (heff_tag_of(v_x31_24132)) {
          case TAG_MkAlt: {
            V v_p_24134 = heff_field(v_x31_24132, 0);
            V v_e_24135 = heff_field(v_x31_24132, 1);
            heff_take_n(v_x31_24132, 3ULL, 2);
            V v_x1_24136 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24130, v_e_24135}));
            switch (heff_tag_of(v_x1_24136)) {
            case TAG_MkPair: {
              V v_x_24137 = heff_field(v_x1_24136, 0);
              V v_y_24138 = heff_field(v_x1_24136, 1);
              heff_take_n(v_x1_24136, 3ULL, 2);
              V v_t_24139 = heff_tag_at_n(v_ru_24x1_24129_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24134, v_y_24138}), v_sp_24133});
              V v_t_24140 = heff_tag_at_n(v_ru_24a_24128_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24131, v_t_24139}), v_sp_244});
              return ((HeffT2){{v_x_24137, v_t_24140}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x1_24136)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_24132)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_a_24128)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24129)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24141 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EDo = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
      HeffT2 v_t_24143 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24142, v_st_241, v_ss_24141));
      {
        V v_field_24144 = v_t_24143.f[0];
        V v_field_24145 = v_t_24143.f[1];
        V v_x_24146 = v_field_24144;
        V v_y_24147 = v_field_24145;
        V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EDo, TAG_EDo, 1, (V[]){v_y_24147}), v_sp_244});
        return ((HeffT2){{v_x_24146, v_t_24148}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EAssign: {
      V v_x_24152 = heff_field(v_x31_243, 0);
      V v_xsp_24153 = heff_field(v_x31_243, 1);
      V v_e_24154 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EAssign = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24155 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24154}));
      switch (heff_tag_of(v_x1_24155)) {
      case TAG_MkPair: {
        V v_x_24156 = heff_field(v_x1_24155, 0);
        V v_y_24157 = heff_field(v_x1_24155, 1);
        V v_ru_24x1_24155_24MkPair = heff_take_reuse_n(v_x1_24155, 3ULL, 2);
        V v_t_24158 = heff_tag_at_n(v_ru_24x1_24155_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAssign, TAG_EAssign, 3, (V[]){v_x_24152, v_xsp_24153, v_y_24157}), v_sp_244});
        return ((HeffT2){{v_x_24156, v_t_24158}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24155)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24159 = heff_field(v_x31_243, 0);
      V v_body_24160 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EWhile = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24161 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24159}));
      switch (heff_tag_of(v_x1_24161)) {
      case TAG_MkPair: {
        V v_x_24162 = heff_field(v_x1_24161, 0);
        V v_y_24163 = heff_field(v_x1_24161, 1);
        V v_ru_24x1_24161_24MkPair = heff_take_reuse_n(v_x1_24161, 3ULL, 2);
        V v_t_24164 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24164, v_x_24162, v_body_24160));
        {
          V v_field_24166 = v_t_24165.f[0];
          V v_field_24167 = v_t_24165.f[1];
          V v_x_24168 = v_field_24166;
          V v_y_24169 = v_field_24167;
          V v_t_24170 = heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWhile, TAG_EWhile, 2, (V[]){v_y_24163, v_y_24169}), v_sp_244});
          return ((HeffT2){{v_x_24168, v_t_24170}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24161)}});
      }
    }
    case TAG_EFor: {
      V v_p_24171 = heff_field(v_x31_243, 0);
      V v_c_24172 = heff_field(v_x31_243, 1);
      V v_body_24173 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EFor = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24174 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24172}));
      switch (heff_tag_of(v_x1_24174)) {
      case TAG_MkPair: {
        V v_x_24175 = heff_field(v_x1_24174, 0);
        V v_y_24176 = heff_field(v_x1_24174, 1);
        V v_ru_24x1_24174_24MkPair = heff_take_reuse_n(v_x1_24174, 3ULL, 2);
        V v_t_24177 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_24178 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24177, v_x_24175, v_body_24173));
        {
          V v_field_24179 = v_t_24178.f[0];
          V v_field_24180 = v_t_24178.f[1];
          V v_x_24181 = v_field_24179;
          V v_y_24182 = v_field_24180;
          V v_t_24183 = heff_tag_at_n(v_ru_24x1_24174_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EFor, TAG_EFor, 3, (V[]){v_p_24171, v_y_24176, v_y_24182}), v_sp_244});
          return ((HeffT2){{v_x_24181, v_t_24183}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24174)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24184 = heff_field(v_x31_243, 0);
      V v_a_24185 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EIfThen = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24186 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24184}));
      switch (heff_tag_of(v_x1_24186)) {
      case TAG_MkPair: {
        V v_x_24187 = heff_field(v_x1_24186, 0);
        V v_y_24188 = heff_field(v_x1_24186, 1);
        V v_ru_24x1_24186_24MkPair = heff_take_reuse_n(v_x1_24186, 3ULL, 2);
        V v_x1_24189 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24187, v_a_24185}));
        switch (heff_tag_of(v_x1_24189)) {
        case TAG_MkPair: {
          V v_x_24190 = heff_field(v_x1_24189, 0);
          V v_y_24191 = heff_field(v_x1_24189, 1);
          heff_take_n(v_x1_24189, 3ULL, 2);
          V v_t_24192 = heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EIfThen, TAG_EIfThen, 2, (V[]){v_y_24188, v_y_24191}), v_sp_244});
          return ((HeffT2){{v_x_24190, v_t_24192}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24189)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24186)}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EContinue: {
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EReturn: {
      V v_e_24193 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EReturn = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24194 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24193}));
      switch (heff_tag_of(v_x1_24194)) {
      case TAG_MkPair: {
        V v_x_24195 = heff_field(v_x1_24194, 0);
        V v_y_24196 = heff_field(v_x1_24194, 1);
        V v_ru_24x1_24194_24MkPair = heff_take_reuse_n(v_x1_24194, 3ULL, 2);
        V v_t_24197 = heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EReturn, TAG_EReturn, 1, (V[]){v_y_24196}), v_sp_244});
        return ((HeffT2){{v_x_24195, v_t_24197}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24194)}});
      }
    }
    case TAG_ENest: {
      V v_e_24198 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ENest = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24199 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24198}));
      switch (heff_tag_of(v_x1_24199)) {
      case TAG_MkPair: {
        V v_x_24200 = heff_field(v_x1_24199, 0);
        V v_y_24201 = heff_field(v_x1_24199, 1);
        V v_ru_24x1_24199_24MkPair = heff_take_reuse_n(v_x1_24199, 3ULL, 2);
        V v_t_24202 = heff_tag_at_n(v_ru_24x1_24199_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENest, TAG_ENest, 1, (V[]){v_y_24201}), v_sp_244});
        return ((HeffT2){{v_x_24200, v_t_24202}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24199)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24203 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ELazy = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24204 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24203}));
      switch (heff_tag_of(v_x1_24204)) {
      case TAG_MkPair: {
        V v_x_24205 = heff_field(v_x1_24204, 0);
        V v_y_24206 = heff_field(v_x1_24204, 1);
        V v_ru_24x1_24204_24MkPair = heff_take_reuse_n(v_x1_24204, 3ULL, 2);
        V v_t_24207 = heff_tag_at_n(v_ru_24x1_24204_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELazy, TAG_ELazy, 1, (V[]){v_y_24206}), v_sp_244});
        return ((HeffT2){{v_x_24205, v_t_24207}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24204)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24208 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETuple = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_24209 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_241, v_es_24208));
      {
        V v_field_24210 = v_t_24209.f[0];
        V v_field_24211 = v_t_24209.f[1];
        V v_x_24212 = v_field_24210;
        V v_y_24213 = v_field_24211;
        V v_t_24214 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETuple, TAG_ETuple, 1, (V[]){v_y_24213}), v_sp_244});
        return ((HeffT2){{v_x_24212, v_t_24214}});
      }
    }
    case TAG_ETry: {
      V v_tr_24215 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETry = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_24216 = (g_heff_2esyntax_2epresyntax_2etryAcc_24cpr(v_f_240, v_st_241, v_tr_24215));
      {
        V v_field_24217 = v_t_24216.f[0];
        V v_field_24218 = v_t_24216.f[1];
        V v_x_24219 = v_field_24217;
        V v_y_24220 = v_field_24218;
        V v_t_24221 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETry, TAG_ETry, 1, (V[]){v_y_24220}), v_sp_244});
        return ((HeffT2){{v_x_24219, v_t_24221}});
      }
    }
    case TAG_EWith: {
      V v_w_24222 = heff_field(v_x31_243, 0);
      V v_x_24223 = heff_field(v_x31_243, 1);
      V v_xsp_24224 = heff_field(v_x31_243, 2);
      V v_body_24225 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24EWith = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24226 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_w_24222}));
      switch (heff_tag_of(v_x1_24226)) {
      case TAG_MkPair: {
        V v_x_24227 = heff_field(v_x1_24226, 0);
        V v_y_24228 = heff_field(v_x1_24226, 1);
        V v_ru_24x1_24226_24MkPair = heff_take_reuse_n(v_x1_24226, 3ULL, 2);
        V v_t_24229 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_24230 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24229, v_x_24227, v_body_24225));
        {
          V v_field_24231 = v_t_24230.f[0];
          V v_field_24232 = v_t_24230.f[1];
          V v_x_24233 = v_field_24231;
          V v_y_24234 = v_field_24232;
          V v_t_24235 = heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWith, TAG_EWith, 4, (V[]){v_y_24228, v_x_24223, v_xsp_24224, v_y_24234}), v_sp_244});
          return ((HeffT2){{v_x_24233, v_t_24235}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24226)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_x3_2413 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_At: {
    V v_x31_2414 = heff_field(v_x3_2413, 0);
    V v_sp_2415 = heff_field(v_x3_2413, 1);
    V v_ru_24x3_2413_24At = heff_take_reuse_n(v_x3_2413, 3ULL, 2);
    switch (heff_tag_of(v_x31_2414)) {
    case TAG_MkSegment: {
      V v_v_2416 = heff_field(v_x31_2414, 0);
      V v_ty_2417 = heff_field(v_x31_2414, 1);
      V v_size_2418 = heff_field(v_x31_2414, 2);
      V v_little_2419 = heff_field(v_x31_2414, 3);
      V v_signed_2420 = heff_field(v_x31_2414, 4);
      heff_take_n(v_x31_2414, 31ULL, 5);
      V v_x1_2421 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2412, v_v_2416}));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_field(v_x1_2421, 0);
        V v_y_2423 = heff_field(v_x1_2421, 1);
        V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
        V v_t_2424 = heff_tag_at_n(v_ru_24x3_2413_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_y_2423, v_ty_2417, v_size_2418, v_little_2419, v_signed_2420}), v_sp_2415});
        return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_t_2424});
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
    default: return heff_nomatch(v_x31_2414);
    }
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args) {
  V v_st_2490 = args[0];
  V v_x3_2491 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2491)) {
  case TAG_At: {
    V v_x31_2492 = heff_field(v_x3_2491, 0);
    V v_sp_2493 = heff_field(v_x3_2491, 1);
    V v_ru_24x3_2491_24At = heff_take_reuse_n(v_x3_2491, 3ULL, 2);
    switch (heff_tag_of(v_x31_2492)) {
    case TAG_SetPath: {
      V v_path_2494 = heff_field(v_x31_2492, 0);
      V v_e_2495 = heff_field(v_x31_2492, 1);
      V v_ru_24x31_2492_24SetPath = heff_take_reuse_n(v_x31_2492, 3ULL, 2);
      V v_x1_2496 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2490, v_e_2495}));
      switch (heff_tag_of(v_x1_2496)) {
      case TAG_MkPair: {
        V v_x_2497 = heff_field(v_x1_2496, 0);
        V v_y_2498 = heff_field(v_x1_2496, 1);
        heff_take_n(v_x1_2496, 3ULL, 2);
        V v_t_2499 = heff_tag_at_n(v_ru_24x3_2491_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_path_2494, v_y_2498}), v_sp_2493});
        return heff_tag_at_n(v_ru_24x31_2492_24SetPath, TAG_MkPair, 2, (V[]){v_x_2497, v_t_2499});
      }
      default: return heff_nomatch(v_x1_2496);
      }
    }
    default: return heff_nomatch(v_x31_2492);
    }
  }
  default: return heff_nomatch(v_x3_2491);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args) {
  V v_st_24111 = args[0];
  V v_x3_24112 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24112)) {
  case TAG_At: {
    V v_x31_24113 = heff_field(v_x3_24112, 0);
    V v_sp_24114 = heff_field(v_x3_24112, 1);
    V v_ru_24x3_24112_24At = heff_take_reuse_n(v_x3_24112, 3ULL, 2);
    switch (heff_tag_of(v_x31_24113)) {
    case TAG_MkAlt: {
      V v_p_24115 = heff_field(v_x31_24113, 0);
      V v_e_24116 = heff_field(v_x31_24113, 1);
      V v_ru_24x31_24113_24MkAlt = heff_take_reuse_n(v_x31_24113, 3ULL, 2);
      V v_x1_24117 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24111, v_e_24116}));
      switch (heff_tag_of(v_x1_24117)) {
      case TAG_MkPair: {
        V v_x_24118 = heff_field(v_x1_24117, 0);
        V v_y_24119 = heff_field(v_x1_24117, 1);
        heff_take_n(v_x1_24117, 3ULL, 2);
        V v_t_24120 = heff_tag_at_n(v_ru_24x3_24112_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24115, v_y_24119}), v_sp_24114});
        return heff_tag_at_n(v_ru_24x31_24113_24MkAlt, TAG_MkPair, 2, (V[]){v_x_24118, v_t_24120});
      }
      default: return heff_nomatch(v_x1_24117);
      }
    }
    default: return heff_nomatch(v_x31_24113);
    }
  }
  default: return heff_nomatch(v_x3_24112);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtsF_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsF_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2estmtsF(V v_t_240, V v_cx_241, V v_x3_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    V v_sp_244 = heff_dup(heff_rfield(v_cx_241, 3));
    switch (heff_tag_of(v_end_243)) {
    case TAG_EndValue: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 2);
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), heff_dup(v_sp_244)});
      V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtsF_str0)}), heff_dup(v_sp_244)});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_246, v_t_248));
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_241), v_sp_244, heff_get_n(v_cx_241, 4, 5), v_t_249);
    }
    case TAG_EndJump: {
      V v_j_2410 = heff_field(v_end_243, 0);
      heff_take_n(v_end_243, 1ULL, 1);
      return (g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_241, v_sp_244, v_j_2410));
    }
    default: return heff_nomatch(v_end_243);
    }
  }
  case TAG_Cons: {
    V v_s_2411 = heff_field(v_x3_242, 0);
    V v_x32_2412 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_2412)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_end_243)) {
      case TAG_EndValue: {
        return (g_heff_2esyntax_2epresyntax_2elastT(v_t_240, v_cx_241, heff_dup(v_s_2411)));
      }
      case TAG_EndJump: {
        return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_2411), heff_dup(v_x32_2412), v_end_243));
      }
      default: return heff_nomatch(v_end_243);
      }
    }
    case TAG_Cons: {
      return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_2411), heff_dup(v_x32_2412), v_end_243));
    }
    default: return heff_nomatch(v_x32_2412);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2estmtsF(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_242}});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_243}});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_244}});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_245}});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_246}});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241})}});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V v_r_240, V v_v_241, V v_sp_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_241}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_IsInferable: {
    V v_i_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsInferable = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    break;
  }
  case TAG_IsCheckable: {
    V v_c_248 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_t_2413 = v_c_248;
    break;
  }
  case TAG_IsType: {
    V v_t_249 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsType = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsType, TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2414));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0)}), heff_dup(v_sp_242)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_242)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_m_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_m_240, 2);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      heff_take_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tr(heff_call(heff_get_n(v_m_240, 1, 2), 2, (V[]){v_s_245, v_sp_246}));
        return heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_Cons, 2, (V[]){v_t_247, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_rest_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2410);
          V v_s_2416 = v_field_2414;
          V v_t_2422;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){v_s_2416, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2417 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2417)) {
            case TAG_MkPair: {
              V v_s0_2418 = heff_field(v_x11_2417, 0);
              V v_sp0_2419 = heff_field(v_x11_2417, 1);
              heff_take_n(v_x11_2417, 3ULL, 2);
              V v_t_2420 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2421 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2418, v_s_2416), v_t_2420});
              v_t_2422 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
              break;
            }
            default: heff_nomatch(v_x11_2417);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = v_t_2422;
          V t_3 = v_acc_243;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})}));
          V v_t_2428;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2428 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2424 = heff_field(v_run_242, 0);
            heff_take_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2424)) {
            case TAG_MkPair: {
              V v_s_2425 = heff_field(v_x21_2424, 0);
              V v_sp_2426 = heff_field(v_x21_2424, 1);
              heff_take_n(v_x21_2424, 3ULL, 2);
              V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 1)), 2, (V[]){v_s_2425, v_sp_2426}));
              v_t_2428 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2427, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2424);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2423, v_t_2428});
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 7ULL, 3);
      V v_t_246 = (g_list_2emap_24s1887874170x1747433177(v_args_245));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, v_t_246}), v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_247));
      V v_t_2422;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2412 = v_field_2410;
          V v_t_2415;
          switch (heff_tag_of(v_c_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_c_2412);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2417 = v_field_2410;
            V v_t_2420;
            switch (heff_tag_of(v_i_2417)) {
            case TAG_At: {
              V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
              v_t_2420 = v_s_2419;
              break;
            }
            default: heff_nomatch(v_i_2417);
            }
            v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2417}), v_t_2420});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2421 = v_field_2410;
            v_t_2422 = v_t_2421;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2422}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(a[0]);
}