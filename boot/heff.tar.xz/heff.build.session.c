// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_acc 305915
#define LBL_broken 566525696
#define LBL_cached 579094605
#define LBL_checked 974171621
#define LBL_defs 9574869
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_frozen 681056715
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_kept 9783717
#define LBL_keys 9783995
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_spans 310996611
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_unreached 121683306
#define LBL_watches 1357821955
static uint32_t shape_acc__fresh[] = {LBL_acc, LBL_fresh};
static uint32_t shape_checked__frozen[] = {LBL_checked, LBL_frozen};
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_program__kept[] = {LBL_program, LBL_kept};
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
HeffT2 g_heff_2ebuild_2ecache_2efreeze_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2ecache_2emeltFrom_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasQualified(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked(V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_clo;
V g_heff_2ebuild_2edriver_2ewithImportedInstances(V, V, V);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo;
V g_heff_2ebuild_2edriver_2ewithTwice(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithTwice_clo;
V g_heff_2ebuild_2esession_2ecacheDir(V);
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheDir_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_clo;
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(V, V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_clo;
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745(V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_clo;
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262(V, V, V, V);
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_clo;
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943(V, V, V, V);
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_clo;
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506(V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_clo;
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771(V, V, V, V);
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_clo;
V g_heff_2ebuild_2esession_2ewhereAdded(V, V, V);
V g_heff_2ebuild_2esession_2ewhereAdded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ewhereAdded_clo;
V g_heff_2ebuild_2esession_2ewhereFull(V, V, V);
V g_heff_2ebuild_2esession_2ewhereFull_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ewhereFull_clo;
V g_heff_2ebuild_2esession_2ezipSC(V, V);
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_clo;
V g_heff_2ebuild_2esession_2ezipSC_24dps(V, V, V);
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1722922134x788519507(V, V);
V g_list_2efoldl_24s1722922134x788519507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722922134x788519507_clo;
V g_list_2efoldl_24s1955438510x914057761(V, V);
V g_list_2efoldl_24s1955438510x914057761_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1955438510x914057761_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2esession_2ecacheDir_str0, 5, ".heff");
Clo g_heff_2ebuild_2esession_2ecacheDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheDir_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecacheDir(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_root_242));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2esession_2ecacheDir_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_d_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = v_style_241;
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_247));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_dup(g_heff_2ebuild_2ecache_2eversionDir_get())));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  return ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecacheDir(a[0]);
}
Clo g_heff_2ebuild_2esession_2ezipSC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_entry, 2, 0};

V g_heff_2ebuild_2esession_2ezipSC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_242);
      heff_drop(v_ss_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_cs_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_s_242, v_c_244}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2esession_2ezipSC_24dps(v_ss_243, v_cs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC(a[0], a[1]);
}
Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_24dps_entry, 3, 0};

V g_heff_2ebuild_2esession_2ezipSC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x1_240, 0);
    V v_ss_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_243);
      heff_drop(v_ss_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_c_245 = heff_field(v_x2_241, 0);
      V v_cs_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_s_243, v_c_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ss_244;
      V t_1 = v_cs_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC_24dps(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ewhereAdded_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ewhereAdded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ewhereAdded_entry, 3, 0};

V g_heff_2ebuild_2esession_2ewhereAdded(V v_w_240, V v_s_241, V v_c_242) {
top: ;
  V v_acc_243 = heff_take_field(v_w_240, 0);
  V v_fresh_244 = heff_get_n(v_w_240, 1, 2);
  V v_acc_245 = v_acc_243;
  V v_done_246 = heff_take_field(v_acc_245, 0);
  V v_hashes_247 = heff_get_n(v_acc_245, 1, 2);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_done_246, v_t_248));
  V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ewhereAdded_lam0, 2, 1, (V[]){heff_dup(v_c_242)}), v_hashes_247, heff_rfield(v_c_242, 7)));
  V v_t_2413 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2412, heff_dup(v_c_242)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_241, v_c_242}), v_fresh_244});
  return heff_rec_n(2, shape_acc__fresh, (V[]){heff_rec_n(2, shape_done__hashes, (V[]){v_t_249, v_t_2413}), v_t_2414});
}
V g_heff_2ebuild_2esession_2ewhereAdded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ewhereAdded(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ewhereAdded_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_o_2411 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2410, v_c_242, v_o_2411));
}
Clo g_heff_2ebuild_2esession_2ewhereFull_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ewhereFull_entry, 3, 0};

V g_heff_2ebuild_2esession_2ewhereFull(V v_kept_240, V v_w_241, V v_s_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_kept_240, heff_rfield(v_s_242, 2)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_k_246 = v_field_245;
      V v_checked_247 = heff_take_field(v_k_246, 0);
      V v_frozen_248 = heff_get_n(v_k_246, 1, 2);
      if (heff_strEq_c(heff_dup(heff_rfield(v_checked_247, 3)), heff_dup(heff_rfield(v_s_242, 4)))) {
        V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 1, 2);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
        HeffT3 v_t_2411 = (g_heff_2ebuild_2ecache_2emeltFrom_24cpr(v_t_249, v_t_2410, heff_dup(v_s_242), v_frozen_248, MK_INT(0LL)));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop_rec(v_s_242, 8);
            V v_x_2415 = v_field_2413;
            V v_x112_2416 = v_field_2414;
            heff_drop(v_x112_2416);
            V v_c_2417 = v_checked_247;
            V v_acc_2418 = heff_take_field(v_w_241, 0);
            V v_done_2419 = heff_take_field(v_acc_2418, 0);
            V v_hashes_2420 = heff_get_n(v_acc_2418, 1, 2);
            V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2417), NTAG(TAG_Nil)});
            V v_t_2422 = (g_prelude_2e_2b_2b(v_done_2419, v_t_2421));
            V v_t_2423 = ({ V a_0 = v_hashes_2420; V b_1 = heff_get_n(v_x_2415, 2, 3); V r_ = (g_list_2efoldl_24s1955438510x914057761(a_0, b_1)); heff_drop(b_1); r_; });
            V v_t_2424 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2423, v_c_2417));
            return ({ V rv_0 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_2422, v_t_2424}); V rr_ = heff_rec_reuse_nf(v_w_241, 2ULL, 2, shape_acc__fresh, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop_rec(v_checked_247, 14);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
            V v_t_2426 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2425, heff_dup(v_s_242), NTAG(TAG_Nothing)));
            V v_t_2427 = (g_heff_2ebuild_2edriver_2elean(v_t_2426));
            HEFF_LAST return g_heff_2ebuild_2esession_2ewhereAdded(v_w_241, v_s_242, v_t_2427);
          }
        }
      } else {
        heff_drop_rec(v_checked_247, 14);
        heff_drop(v_frozen_248);
        V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
        V v_t_2429 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2428, heff_dup(v_s_242), NTAG(TAG_Nothing)));
        V v_t_2430 = (g_heff_2ebuild_2edriver_2elean(v_t_2429));
        HEFF_LAST return g_heff_2ebuild_2esession_2ewhereAdded(v_w_241, v_s_242, v_t_2430);
      }
    } else {
      heff_drop(v_field_245);
      V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
      V v_t_2432 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2431, heff_dup(v_s_242), NTAG(TAG_Nothing)));
      V v_t_2433 = (g_heff_2ebuild_2edriver_2elean(v_t_2432));
      HEFF_LAST return g_heff_2ebuild_2esession_2ewhereAdded(v_w_241, v_s_242, v_t_2433);
    }
  }
}
V g_heff_2ebuild_2esession_2ewhereFull_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2esession_2ewhereFull(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam0, 3, 0};
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_entry, 4, 0};

V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771(V v_e_240, V v_ps_241, V v_s_242, V v_acc_243) {
top: ;
  V v_hashes_244 = heff_take_field(v_acc_243, 1);
  V v_done_245 = heff_get_n(v_acc_243, 0, 2);
  V v_d_246 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_241)));
  V v_st_247 = heff_get_n(v_ps_241, 5, 6);
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_247), v_d_246));
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_str0));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_247), v_t_249));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_248, v_t_2410));
  V v_s_2412 = ({ V a_0 = v_st_247; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2411); r_; });
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_c_2414 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2413; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2413); r_; });
  V v_t_2415 = (g_exception_2eattempted(v_e_240));
  V v_c_2419 = heff_tr(heff_call(v_c_2414, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam1, 2, 4, (V[]){v_c_2419, v_hashes_244, v_done_245, v_s_242});
}
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_hashes_244 = heff_env(self)[1];
  V v_done_245 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    heff_drop(v_hashes_244);
    heff_drop(v_done_245);
    heff_drop_rec(v_s_242, 8);
    V f_ = v_k_2421;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    HeffT3 v_t_2425 = (g_heff_2ebuild_2ecache_2emeltFrom_24cpr(v_hashes_244, v_done_245, v_s_242, v_y_2424, MK_INT(0LL)));
    {
      V v_field_2427 = v_t_2425.f[1];
      V v_field_2428 = v_t_2425.f[2];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      V v_t_2431;
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x_2429 = v_field_2427;
        V v_x112_2430 = v_field_2428;
        heff_drop(v_x112_2430);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Just, 1, (V[]){v_x_2429});
      } else {
        heff_drop_cell(v_ru_24x_2422_24Right, 1);
        heff_drop(v_field_2427);
        heff_drop(v_field_2428);
        v_t_2431 = NTAG(TAG_Nothing);
      }
      V f_ = v_k_2421;
      args[0] = v_t_2431;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_hashes_244 = heff_env(self)[1];
  V v_done_245 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771_lam2, 1, 4, (V[]){v_k_2421, v_hashes_244, v_done_245, v_s_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam5(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_entry, 4, 0};

V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(V v_e_240, V v_ps_241, V v_x2_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ps_241);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam0, 2, 1, (V[]){v_acc_243});
  }
  case TAG_Cons: {
    V v_s_246 = heff_field(v_x2_242, 0);
    V v_x22_247 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x22_247)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_ps_241);
      V v_c_248 = (g_heff_2ebuild_2edriver_2eelabNext(heff_dup(heff_rfield(v_acc_243, 0)), v_s_246, NTAG(TAG_Nothing)));
      V v_t_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_248), NTAG(TAG_Nil)});
      V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_243, 0), v_t_249));
      V v_t_2413 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam1, 2, 1, (V[]){heff_dup(v_c_248)}), heff_get_n(v_acc_243, 1, 2), heff_rfield(v_c_248, 7)));
      V v_t_2414 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2413, v_c_248));
      V v_x_2415 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_2410, v_t_2414});
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam2, 2, 1, (V[]){v_x_2415});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V v_c_2420 = (g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_s_246), heff_dup(v_acc_243)));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam3, 2, 6, (V[]){v_c_2420, v_acc_243, v_s_246, v_e_240, v_ps_241, v_x22_247});
    }
    default: return heff_nomatch(v_x22_247);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_acc_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_acc_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam1(V self, V *args) {
  V v_m_2411 = args[0];
  V v_o_2412 = args[1];
  V v_c_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2411, v_c_248, v_o_2412));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam5(V self, V *args) {
  V v_m_2432 = args[0];
  V v_o_2433 = args[1];
  V v_c_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2432, v_c_2429, v_o_2433));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_s_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_x22_247 = heff_env(self)[4];
  V v_hd_2421 = heff_env(self)[5];
  V v_k_2422 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_acc_2424 = heff_dup(v_acc_243);
  V v_done_2425 = heff_take_field(v_acc_2424, 0);
  V v_hashes_2426 = heff_get_n(v_acc_2424, 1, 2);
  V v_th_2427 = heff_dup(v_x_2423);
  V v_t_2428 = (g_heff_2ebuild_2edriver_2eelabNext(heff_get_n(v_acc_243, 0, 2), v_s_246, v_x_2423));
  V v_c_2429 = (g_heff_2ebuild_2edriver_2elean(v_t_2428));
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2429), NTAG(TAG_Nil)});
  V v_t_2431 = (g_prelude_2e_2b_2b(v_done_2425, v_t_2430));
  V v_t_2437;
  switch (heff_tag_of(v_th_2427)) {
  case TAG_Nothing: {
    V v_t_2434 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam5, 2, 1, (V[]){heff_dup(v_c_2429)}), v_hashes_2426, heff_rfield(v_c_2429, 7)));
    v_t_2437 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2434, v_c_2429));
    break;
  }
  case TAG_Just: {
    V v_t_2435 = heff_field(v_th_2427, 0);
    heff_take_n(v_th_2427, 1ULL, 1);
    V v_t_2436 = ({ V a_0 = v_hashes_2426; V b_1 = heff_get_n(v_t_2435, 2, 3); V r_ = (g_list_2efoldl_24s1955438510x914057761(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_2437 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2436, v_c_2429));
    break;
  }
  default: heff_nomatch(v_th_2427);
  }
  V v_t_2438 = (g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(v_e_240, v_ps_241, v_x22_247, heff_rec_n(2, shape_done__hashes, (V[]){v_t_2431, v_t_2437})));
  V f_ = v_t_2438;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_s_246 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_x22_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_lam4, 1, 7, (V[]){v_acc_243, v_s_246, v_e_240, v_ps_241, v_x22_247, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam1, 3, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam4(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam4, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam5(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam5, 2, 0};
Clo g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_entry, 4, 0};

V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943(V v_e_240, V v_ps_241, V v_acc_242, V v_x3_243) {
top: ;
  V v_hashes_244 = heff_take_field(v_acc_242, 1);
  V v_done_245 = heff_get_n(v_acc_242, 0, 2);
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x3_243, 0);
    V v_c_247 = heff_field(v_x3_243, 1);
    V v_t_248 = heff_dup(heff_rfield(v_c_247, 12));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_e_240);
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_hashes_244);
      heff_drop(v_done_245);
      heff_drop(v_t_248);
      return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam0_clo);
    } else {
      heff_drop(v_t_248);
      V v_t_2411 = heff_dup(heff_rfield(v_c_247, 6));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nil: {
        HeffT2 v_t_2412 = ({ V a_0 = v_hashes_244; V a_1 = v_done_245; V a_2 = heff_dup(v_s_246); V a_3 = heff_dup(v_c_247); HeffT2 r_ = (g_heff_2ebuild_2ecache_2efreeze_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_hashes_244); heff_drop(v_done_245); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_out_2415 = v_field_2414;
            V v_d_2416 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_241)));
            V v_st_2417 = heff_get_n(v_ps_241, 5, 6);
            V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_2416));
            V v_t_2419 = heff_strAppend(heff_dup(heff_rfield(v_c_247, 0)), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_str0));
            V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_t_2419));
            V v_t_2421 = (g_std_2epath_2ejoin(v_t_2418, v_t_2420));
            V v_s_2422 = ({ V a_0 = v_st_2417; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2421); r_; });
            V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
            V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V a_2 = v_out_2415; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2423); r_; });
            V v_t_2425 = (g_exception_2eattempted(v_e_240));
            V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam1_clo)}));
            return heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam2, 2, 1, (V[]){v_c_2429});
          } else {
            heff_drop(v_e_240);
            heff_drop_rec(v_ps_241, 6);
            heff_drop(v_field_2414);
            return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam4_clo);
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_2411, 0ULL, 2);
        heff_drop(v_e_240);
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_hashes_244);
        heff_drop(v_done_245);
        return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam5_clo);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam2(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2429;
  args[0] = v_hd_2430;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam3, 1, 1, (V[]){v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_entry, 4, 0};

V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262(V v_e_240, V v_ps_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ps_241);
    heff_drop(v_acc_242);
    return ((V)&g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_c_248 = (g_heff_2ebuild_2esession_2efreezeOne_24s1153148423x1615674943(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_acc_242), v_p_246));
    return heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam1, 2, 5, (V[]){v_c_248, v_e_240, v_ps_241, v_acc_242, heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  V v_t_2412 = ({ V a_0 = v_e_240; V a_1 = v_ps_241; V a_2 = v_acc_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262_lam2, 1, 6, (V[]){v_e_240, v_ps_241, v_acc_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam2, 3, 0};
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry, 2, 0};

V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V v_e_240, V v_l_241) {
top: ;
  V v_paths_242 = heff_take_field(v_l_241, 2);
  V v_sources_243 = heff_get_n(v_l_241, 0, 5);
  V v_t_244 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_c_245 = (g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(heff_dup(v_e_240), heff_dup(v_paths_242), heff_dup(v_sources_243), v_t_244));
  return heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam0, 2, 4, (V[]){v_c_245, v_paths_242, v_e_240, v_sources_243});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(a[0], a[1]);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2414 = args[1];
  V v_k_2415 = args[2];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_k_247;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sources_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_paths_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_t_2418 = (g_heff_2ebuild_2esession_2ezipSC(v_sources_243, heff_dup(heff_rfield(v_x_248, 0))));
  V v_c_2419 = ({ V a_0 = v_e_240; V a_1 = v_paths_242; V a_2 = heff_dup(v_x_248); V a_3 = v_t_2418; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s1180421154x414889262(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
  V f_ = v_c_2419;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam4, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_paths_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_sources_243 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_249 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_paths_242)));
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_249));
  V v_c_2411 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2410; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2410); r_; });
  V v_t_2412 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2416 = heff_tr(heff_call(v_c_2411, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam2_clo)}));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam3, 1, 6, (V[]){v_sources_243, v_x_248, v_e_240, v_paths_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_paths_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sources_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_lam1, 1, 5, (V[]){v_paths_242, v_e_240, v_hd_246, v_sources_243, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_entry, 6, 0};

V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745(V v_e_240, V v_full_241, V v_kept_242, V v_ps_243, V v_x4_244, V v_w_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_full_241);
    heff_drop(v_ps_243);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam0, 2, 1, (V[]){v_w_245});
  }
  case TAG_Cons: {
    V v_s_248 = heff_field(v_x4_244, 0);
    V v_rest_249 = heff_field(v_x4_244, 1);
    heff_take_n(v_x4_244, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_full_241), 1, (V[]){heff_dup(v_s_248)}));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_heff_2ebuild_2esession_2ewhereFull(v_kept_242, v_w_245, v_s_248));
      V t_0 = v_e_240;
      V t_1 = v_full_241;
      V t_2 = v_kept_242;
      V t_3 = v_ps_243;
      V t_4 = v_rest_249;
      V t_5 = v_t_2411;
      v_e_240 = t_0;
      v_full_241 = t_1;
      v_kept_242 = t_2;
      v_ps_243 = t_3;
      v_x4_244 = t_4;
      v_w_245 = t_5;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_c_2412 = (g_heff_2ebuild_2esession_2ethawTry_24s918840911x848712771(heff_dup(v_e_240), heff_dup(v_ps_243), heff_dup(v_s_248), heff_dup(heff_rfield(v_w_245, 0))));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam1, 2, 8, (V[]){v_c_2412, v_w_245, v_s_248, v_e_240, v_full_241, heff_dup(v_kept_242), v_ps_243, v_rest_249});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_w_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_w_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam3(V self, V *args) {
  V v_c_2435 = args[0];
  V v_reached_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2435, 0, 14); V a_1 = v_reached_2434; V r_ = (g_list_2eany_24s1006624359x760861690(b_0, a_1)); heff_drop(b_0); heff_drop(v_reached_2434); r_; });
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam4(V self, V *args) {
  V v_c_2441 = args[0];
  V v_imps_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = (g_heff_2ebuild_2edriver_2eopenNames(heff_get_n(v_imps_2431, 0, 4)));
  return ({ V b_0 = heff_get_n(v_c_2441, 0, 14); V a_1 = v_t_2442; V r_ = (g_list_2eany_24s1006624359x760861690(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2442); r_; });
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_w_245 = heff_env(self)[0];
  V v_s_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_full_241 = heff_env(self)[3];
  V v_kept_242 = heff_env(self)[4];
  V v_ps_243 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_w_2416 = v_w_245;
  V v_s_2417 = v_s_248;
  V v_x3_2418 = v_x_2415;
  V v_t_2466;
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_Nothing: {
    V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_w_2416, 0)), 0, 2);
    V v_t_2420 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2419, heff_dup(v_s_2417), NTAG(TAG_Nothing)));
    V v_t_2421 = (g_heff_2ebuild_2edriver_2elean(v_t_2420));
    v_t_2466 = (g_heff_2ebuild_2esession_2ewhereAdded(v_w_2416, v_s_2417, v_t_2421));
    break;
  }
  case TAG_Just: {
    V v_th_2422 = heff_field(v_x3_2418, 0);
    V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
    V v_lit_2423 = heff_dup(v_th_2422);
    V v_done_2424 = heff_get_n(heff_dup(heff_rfield(v_w_2416, 0)), 0, 2);
    V v_s_2425 = v_s_2417;
    V v_t_2426 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_2425, 6)), heff_dup(heff_rfield(v_s_2425, 4))));
    V v_imps_2427 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_2425, 5), v_t_2426));
    V v_lit_2428 = v_lit_2423;
    V v_done_2429 = heff_dup(v_done_2424);
    V v_s_2430 = v_s_2425;
    V v_imps_2431 = heff_dup(v_imps_2427);
    V v_t_2432 = (g_list_2emap_24s1817208647x1282894070(heff_get_n(v_imps_2427, 0, 4)));
    V v_ms_2433 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2432));
    V v_reached_2434 = ({ V a_0 = v_done_2424; V a_1 = NTAG(TAG_Nil); V a_2 = v_ms_2433; V r_ = (g_heff_2ebuild_2edriver_2eclosureGo(a_0, a_1, a_2)); heff_drop(v_done_2424); r_; });
    V v_needed_2436 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam3, 1, 1, (V[]){v_reached_2434}), heff_dup(v_done_2429)));
    V v_lit_2437 = v_lit_2428;
    V v_done_2438 = heff_dup(v_done_2429);
    V v_s_2439 = v_s_2430;
    V v_imps_2440 = heff_dup(v_imps_2431);
    V v_direct_2443 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam4, 1, 1, (V[]){heff_dup(v_imps_2431)}), heff_dup(v_done_2429)));
    V v_needed_2444 = heff_dup(v_needed_2436);
    V v_t_2445 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_2440, 0))));
    V v_t_2446 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2445));
    V v_t_2447 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_2440, 1))));
    V v_g_2448 = (g_list_2efoldl_24s1261443129x1682844402(heff_dup(g_heff_2eelab_2eglobals_2eemptyGlobals_get()), v_needed_2444));
    V v_t_2449 = ({ V a_0 = v_g_2448; V a_1 = v_needed_2444; V r_ = (g_list_2efoldl_24s1722922134x788519507(a_0, a_1)); heff_drop(v_needed_2444); r_; });
    V v_t_2450 = ({ V a_0 = heff_dup(v_done_2438); V a_1 = v_t_2447; V a_2 = v_t_2449; V a_3 = v_direct_2443; V r_ = (g_heff_2ebuild_2edriver_2ealiasOpen(a_0, a_1, a_2, a_3)); heff_drop(v_t_2447); heff_drop(v_direct_2443); r_; });
    V v_t_2451 = (g_heff_2ebuild_2edriver_2ealiasPairs(heff_dup(heff_rfield(v_imps_2440, 0))));
    V v_t_2452 = ({ V a_0 = v_done_2438; V a_1 = v_t_2450; V a_2 = v_t_2451; V r_ = (g_heff_2ebuild_2edriver_2ealiasQualified(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; });
    V v_g0_2453 = ({ V a_0 = v_done_2438; V a_1 = v_t_2446; V a_2 = v_t_2452; V r_ = (g_heff_2ebuild_2edriver_2ewithImportedInstances(a_0, a_1, a_2)); heff_drop(v_done_2438); heff_drop(v_t_2446); r_; });
    V v_t_2454 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_g0_2453, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2455 = (g_list_2efoldl_24s337463599x663364213(v_t_2454, heff_rfield(v_lit_2437, 1)));
    V v_t_2456 = (g_heff_2eelab_2etoplevel_2ethawDone(v_t_2455));
    V v_t_2457 = (g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(v_ru_24x3_2418_24Just, v_s_2439, v_imps_2440, v_lit_2437, v_t_2456));
    V v_c_2458 = ({ V a_0 = v_done_2429; V a_1 = v_imps_2431; V a_2 = v_needed_2436; V a_3 = v_t_2457; V r_ = (g_heff_2ebuild_2edriver_2ewithTwice(a_0, a_1, a_2, a_3)); heff_drop(v_needed_2436); r_; });
    V v_acc_2459 = heff_take_field(v_w_2416, 0);
    V v_done_2460 = heff_take_field(v_acc_2459, 0);
    V v_hashes_2461 = heff_get_n(v_acc_2459, 1, 2);
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2458), NTAG(TAG_Nil)});
    V v_t_2463 = (g_prelude_2e_2b_2b(v_done_2460, v_t_2462));
    V v_t_2464 = ({ V a_0 = v_hashes_2461; V b_1 = heff_get_n(v_th_2422, 2, 3); V r_ = (g_list_2efoldl_24s1955438510x914057761(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2465 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2464, v_c_2458));
    v_t_2466 = ({ V rv_0 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_2463, v_t_2465}); V rr_ = heff_rec_reuse_nf(v_w_2416, 2ULL, 2, shape_acc__fresh, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    break;
  }
  default: heff_nomatch(v_x3_2418);
  }
  V v_t_2467 = ({ V a_0 = v_e_240; V a_1 = v_full_241; V a_2 = v_kept_242; V a_3 = v_ps_243; V a_4 = v_rest_249; V a_5 = v_t_2466; V r_ = (g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kept_242); r_; });
  V f_ = v_t_2467;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_w_245 = heff_env(self)[1];
  V v_s_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_full_241 = heff_env(self)[4];
  V v_kept_242 = heff_env(self)[5];
  V v_ps_243 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745_lam2, 1, 9, (V[]){v_w_245, v_s_248, v_e_240, v_full_241, v_kept_242, v_ps_243, v_rest_249, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam1, 3, 0};
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam2(V self, V *args);
Clo g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_entry, 6, 0};

V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506(V v_e_240, V v_full_241, V v_ps_242, V v_acc_243, V v_kept_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_full_241);
    heff_drop_rec(v_ps_242, 6);
    heff_drop_rec(v_acc_243, 2);
    return heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam0, 2, 1, (V[]){v_kept_244});
  }
  case TAG_Cons: {
    V v_x51_248 = heff_field(v_x5_245, 0);
    V v_rest_249 = heff_field(v_x5_245, 1);
    switch (heff_tag_of(v_x51_248)) {
    case TAG_MkPair: {
      V v_s_2410 = heff_field(v_x51_248, 0);
      V v_c_2411 = heff_field(v_x51_248, 1);
      V v_t_2412 = heff_dup(heff_rfield(v_c_2411, 6));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nil: {
        HeffT2 v_t_2413 = (g_heff_2ebuild_2ecache_2efreeze_24cpr(heff_rfield(v_acc_243, 1), heff_rfield(v_acc_243, 0), heff_dup(v_s_2410), heff_dup(v_c_2411)));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_out_2416 = v_field_2415;
            V v_t_2417 = heff_tr(heff_call(heff_dup(v_full_241), 1, (V[]){heff_dup(v_s_2410)}));
            if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
              heff_drop(v_t_2417);
              V v_t_2418 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_kept_244, heff_dup(heff_rfield(v_s_2410, 2)), heff_rec_n(2, shape_checked__frozen, (V[]){heff_dup(v_c_2411), v_out_2416})));
              V t_0 = v_e_240;
              V t_1 = v_full_241;
              V t_2 = v_ps_242;
              V t_3 = v_acc_243;
              V t_4 = v_t_2418;
              V t_5 = v_rest_249;
              v_e_240 = t_0;
              v_full_241 = t_1;
              v_ps_242 = t_2;
              v_acc_243 = t_3;
              v_kept_244 = t_4;
              v_x5_245 = t_5;
              goto top;
            } else {
              heff_drop(v_t_2417);
              V v_d_2419 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_242)));
              V v_st_2420 = heff_dup(heff_rfield(v_ps_242, 5));
              V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_2420), v_d_2419));
              V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_c_2411, 0)), ((V)&g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_str0));
              V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2420), v_t_2422));
              V v_t_2424 = (g_std_2epath_2ejoin(v_t_2421, v_t_2423));
              V v_s_2425 = ({ V a_0 = v_st_2420; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2424); r_; });
              V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2425));
              V v_c_2427 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2426; V a_2 = v_out_2416; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2426); r_; });
              V v_t_2428 = (g_exception_2eattempted(heff_dup(v_e_240)));
              V v_c_2432 = heff_tr(heff_call(v_c_2427, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam1_clo)}));
              return heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam2, 2, 7, (V[]){v_c_2432, v_e_240, v_full_241, v_ps_242, v_acc_243, v_kept_244, heff_dup(v_rest_249)});
            }
          } else {
            heff_drop(v_field_2415);
            V t_0 = v_e_240;
            V t_1 = v_full_241;
            V t_2 = v_ps_242;
            V t_3 = v_acc_243;
            V t_4 = v_kept_244;
            V t_5 = v_rest_249;
            v_e_240 = t_0;
            v_full_241 = t_1;
            v_ps_242 = t_2;
            v_acc_243 = t_3;
            v_kept_244 = t_4;
            v_x5_245 = t_5;
            goto top;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_2412, 0ULL, 2);
        V t_0 = v_e_240;
        V t_1 = v_full_241;
        V t_2 = v_ps_242;
        V t_3 = v_acc_243;
        V t_4 = v_kept_244;
        V t_5 = v_rest_249;
        v_e_240 = t_0;
        v_full_241 = t_1;
        v_ps_242 = t_2;
        v_acc_243 = t_3;
        v_kept_244 = t_4;
        v_x5_245 = t_5;
        goto top;
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_x51_248);
    }
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_kept_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_kept_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_full_241 = heff_env(self)[1];
  V v_ps_242 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_kept_244 = heff_env(self)[4];
  V v_rest_249 = heff_env(self)[5];
  V v_hd_2433 = heff_env(self)[6];
  V v_k_2434 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2435);
  V v_t_2436 = ({ V a_0 = v_e_240; V a_1 = v_full_241; V a_2 = v_ps_242; V a_3 = v_acc_243; V a_4 = v_kept_244; V a_5 = v_rest_249; V r_ = (g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_249); r_; });
  V f_ = v_t_2436;
  heff_room[0] = v_hd_2433;
  heff_room[1] = v_k_2434;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam2(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_full_241 = heff_env(self)[2];
  V v_ps_242 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_kept_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506_lam3, 1, 8, (V[]){v_e_240, v_full_241, v_ps_242, v_acc_243, v_kept_244, v_rest_249, v_hd_2433, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam1, 3, 0};
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_entry, 7, 0};

V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(V v_e_240, V v_full_241, V v_kept_242, V v_ps_243, V v_sources_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_t_248 = heff_rec_n(2, shape_acc__fresh, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedWhereGo_24s1158768419x1914542745(heff_dup(v_e_240), heff_dup(v_full_241), v_kept_242, heff_dup(v_ps_243), v_sources_244, v_t_248));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam0, 1, 6, (V[]){v_ps_243, v_e_240, v_z_245, v_full_241, v_kept_242, v_z_246})});
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_2411 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_rec_n(2, shape_program__kept, (V[]){heff_get_n(v_acc_2411, 0, 2), v_x_2424});
  V f_ = v_z_246;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_fresh_2412 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_full_241 = heff_env(self)[2];
  V v_ps_243 = heff_env(self)[3];
  V v_acc_2411 = heff_env(self)[4];
  V v_kept_242 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2421);
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fresh_2412));
  V v_c_2423 = ({ V a_0 = v_e_240; V a_1 = v_full_241; V a_2 = v_ps_243; V a_3 = heff_dup(v_acc_2411); V a_4 = v_kept_242; V a_5 = v_t_2422; V r_ = (g_heff_2ebuild_2esession_2ekeepFresh_24s1778154496x927066506(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2422); r_; });
  V f_ = v_c_2423;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam3, 1, 2, (V[]){v_acc_2411, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_full_241 = heff_env(self)[3];
  V v_kept_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_acc_2411 = heff_take_field(v_x_2410, 0);
  V v_fresh_2412 = heff_get_n(v_x_2410, 1, 2);
  V v_s_2413 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_243)));
  V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2413));
  V v_c_2415 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2414; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2414); r_; });
  V v_t_2416 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2420 = heff_tr(heff_call(v_c_2415, 2, (V[]){v_t_2416, ((V)&g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam1_clo)}));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_lam2, 1, 8, (V[]){v_fresh_2412, v_e_240, v_full_241, v_ps_243, v_acc_2411, v_kept_242, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}