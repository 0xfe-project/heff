// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_MakeDirectory 16793
#define TAG_ReadFile 6783
#define TAG_WriteFile 62589
#define LBL_cached 579094605
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_hashes 722717031
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_sources 357464573
#define LBL_style 311138763
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
HeffT2 g_heff_2ebuild_2ecache_2efreeze_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2ecache_2emeltFrom_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2esession_2ecacheDir(V);
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheDir_clo;
V g_heff_2ebuild_2esession_2ecacheKeep(V, V, V);
V g_heff_2ebuild_2esession_2ecacheKeep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheKeep_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_clo;
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330(V, V, V);
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_clo;
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417(V, V, V);
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_clo;
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689(V, V, V);
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_clo;
V g_heff_2ebuild_2esession_2ezipSC(V, V);
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_clo;
V g_heff_2ebuild_2esession_2ezipSC_24dps(V, V, V);
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s354099975x1239835002(V, V);
V g_list_2efoldl_24s354099975x1239835002_entry(V self, V *a);
extern Clo g_list_2efoldl_24s354099975x1239835002_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2esession_2ecacheDir_str0, 5, ".heff");
Clo g_heff_2ebuild_2esession_2ecacheDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheDir_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecacheDir(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_take_field(v_ps_240, 0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2esession_2ecacheDir_str0)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_d_245 = ({ V a_0 = v_st_241; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_244); r_; });
  V v_st_246 = heff_get_n(v_ps_240, 5, 6);
  V v_t_247 = (g_std_2epath_2eparse(v_st_246, v_d_245));
  V v_t_248 = (g_std_2epath_2eparse(v_st_246, heff_dup(g_heff_2ebuild_2ecache_2eversionDir_get())));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_246; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecacheDir(a[0]);
}
V g_heff_2ebuild_2esession_2ecacheKeep_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecacheKeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheKeep_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecacheKeep(V v_acc_240, V v_th_241, V v_c_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), NTAG(TAG_Nil)});
  V v_t_244 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_240, 0), v_t_243));
  V v_t_2410;
  switch (heff_tag_of(v_th_241)) {
  case TAG_Nothing: {
    V v_t_247 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecacheKeep_lam0, 2, 1, (V[]){heff_dup(v_c_242)}), heff_get_n(v_acc_240, 1, 2), heff_rfield(v_c_242, 7)));
    v_t_2410 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_247, v_c_242));
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_th_241, 0);
    V v_t_249 = (g_list_2efoldl_24s354099975x1239835002(heff_get_n(v_acc_240, 1, 2), heff_rfield(v_t_248, 2)));
    v_t_2410 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_249, v_c_242));
    break;
  }
  default: heff_nomatch(v_th_241);
  }
  return heff_rec_n(2, shape_done__hashes, (V[]){v_t_244, v_t_2410});
}
V g_heff_2ebuild_2esession_2ecacheKeep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2esession_2ecacheKeep(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2esession_2ecacheKeep_lam0(V self, V *args) {
  V v_m_245 = args[0];
  V v_o_246 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_245, v_c_242, v_o_246));
}
Clo g_heff_2ebuild_2esession_2ezipSC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_entry, 2, 0};

V g_heff_2ebuild_2esession_2ezipSC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_242);
      heff_drop(v_ss_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_cs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_242, v_c_244}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2esession_2ezipSC_24dps(v_ss_243, v_cs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC(a[0], a[1]);
}
Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_24dps_entry, 3, 0};

V g_heff_2ebuild_2esession_2ezipSC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x1_240, 0);
    V v_ss_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_243);
      heff_drop(v_ss_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_c_245 = heff_field(v_x2_241, 0);
      V v_cs_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_243, v_c_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ss_244;
      V t_1 = v_cs_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam0, 1, 0};
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_entry, 3, 0};

V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689(V v_ps_240, V v_s_241, V v_acc_242) {
top: ;
  V v_d_243 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
  V v_st_244 = heff_get_n(v_ps_240, 5, 6);
  V v_t_245 = (g_std_2epath_2eparse(v_st_244, v_d_243));
  V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_str0));
  V v_t_247 = (g_std_2epath_2eparse(v_st_244, v_t_246));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_245, v_t_247));
  V v_s_249 = ({ V a_0 = v_st_244; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_248); r_; });
  V v_path_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_249; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
  V v_a_2413 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam1, 2, 3, (V[]){v_a_2413, v_acc_242, v_s_241});
}
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam0(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2431;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop_rec(v_acc_242, 2);
    heff_drop_rec(v_s_241, 8);
    v_x_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_txt_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    HeffT2 v_t_2424 = ({ V b_0 = heff_take_field(v_acc_242, 1); V a_1 = heff_get_n(v_acc_242, 0, 2); V a_2 = v_s_241; V a_3 = v_txt_2423; V a_4 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ecache_2emeltFrom_24cpr(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_x11_2428 = v_field_2426;
        switch (heff_tag_of(v_x11_2428)) {
        case TAG_MkPair: {
          V v_x_2429 = heff_field(v_x11_2428, 0);
          heff_take_n(v_x11_2428, 1ULL, 2);
          v_x_2431 = heff_tag_at_n(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){v_x_2429});
          break;
        }
        default: heff_nomatch(v_x11_2428);
        }
      } else {
        heff_drop_cell(v_ru_24x_2422_24Just, 1);
        heff_drop(v_field_2426);
        v_x_2431 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_2415;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_a_2413 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(v_t_2421, v_hd_2414, heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689_lam2, 1, 3, (V[]){v_acc_242, v_s_241, v_k_2415})));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(V v_ps_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x2_241, 0);
    V v_x22_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_246)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      V v_c_247 = ({ V a_0 = heff_dup(heff_rfield(v_acc_242, 0)); V a_1 = v_s_245; V b_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabNext(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_247), NTAG(TAG_Nil)});
      V v_t_249 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_242, 0), v_t_248));
      V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam1, 2, 1, (V[]){heff_dup(v_c_247)}), heff_get_n(v_acc_242, 1, 2), heff_rfield(v_c_247, 7)));
      V v_t_2413 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2412, v_c_247));
      V v_x_2414 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_249, v_t_2413});
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam2, 2, 1, (V[]){v_x_2414});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_c_2419 = (g_heff_2ebuild_2esession_2ethawTry_24s2037196805x101444689(heff_dup(v_ps_240), heff_dup(v_s_245), heff_dup(v_acc_242)));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam3, 2, 5, (V[]){v_c_2419, v_acc_242, v_s_245, v_ps_240, v_x22_246});
    }
    default: return heff_nomatch(v_x22_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_o_2411 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2410, v_c_247, v_o_2411));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_x22_246 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2ebuild_2edriver_2eelabNext(heff_dup(heff_rfield(v_acc_242, 0)), v_s_245, v_x_2422));
  V v_t_2424 = (g_heff_2ebuild_2edriver_2elean(v_t_2423));
  V v_t_2425 = ({ V a_0 = v_acc_242; V a_1 = v_x_2422; V a_2 = v_t_2424; V r_ = (g_heff_2ebuild_2esession_2ecacheKeep(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
  V v_t_2426 = (g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(v_ps_240, v_x22_246, v_t_2425));
  V f_ = v_t_2426;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_x22_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_lam4, 1, 6, (V[]){v_acc_242, v_s_245, v_ps_240, v_x22_246, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam1, 1, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam4(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam4, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam5(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam5, 2, 0};
Clo g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_c_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_dup(heff_rfield(v_c_244, 12));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop_rec(v_acc_241, 2);
      heff_drop(v_t_245);
      return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam0_clo);
    } else {
      heff_drop(v_t_245);
      V v_t_248 = heff_dup(heff_rfield(v_c_244, 6));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        HeffT2 v_t_249 = ({ V b_0 = heff_take_field(v_acc_241, 1); V a_1 = heff_get_n(v_acc_241, 0, 2); V a_2 = heff_dup(v_s_243); V a_3 = heff_dup(v_c_244); HeffT2 r_ = (g_heff_2ebuild_2ecache_2efreeze_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_out_2413 = v_field_2411;
            V v_d_2414 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
            V v_st_2415 = heff_get_n(v_ps_240, 5, 6);
            V v_t_2416 = (g_std_2epath_2eparse(v_st_2415, v_d_2414));
            V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_c_244, 0)), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_str0));
            V v_t_2418 = (g_std_2epath_2eparse(v_st_2415, v_t_2417));
            V v_t_2419 = (g_std_2epath_2ejoin(v_t_2416, v_t_2418));
            V v_s_2420 = ({ V a_0 = v_st_2415; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2419); r_; });
            V v_path_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
            V v_a_2424 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2422, v_out_2413, ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam1_clo)});
            return heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam2, 2, 1, (V[]){v_a_2424});
          } else {
            heff_drop_rec(v_ps_240, 6);
            heff_drop(v_field_2411);
            return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam4_clo);
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_248, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop_rec(v_acc_241, 2);
        return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam5_clo);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam1(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_a_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(v_t_2432, v_hd_2425, heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam3, 1, 1, (V[]){v_k_2426})));
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417_lam5(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_acc_241);
    return ((V)&g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2esession_2efreezeOne_24s168276452x358865417(heff_dup(v_ps_240), heff_dup(v_acc_241), v_p_245));
    return heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_acc_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_ps_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330_lam2, 1, 5, (V[]){v_ps_240, v_acc_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam2, 1, 0};
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V v_l_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get())});
  V v_c_242 = (g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(heff_dup(heff_rfield(v_l_240, 2)), heff_dup(heff_rfield(v_l_240, 0)), v_t_241));
  return heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam0, 2, 2, (V[]){v_c_242, v_l_240});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(a[0]);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam2(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_k_244;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2417);
  V v_t_2418 = (g_heff_2ebuild_2esession_2ezipSC(heff_take_field(v_l_240, 0), heff_dup(heff_rfield(v_x_245, 0))));
  V v_c_2419 = ({ V a_0 = heff_get_n(v_l_240, 2, 5); V a_1 = heff_dup(v_x_245); V a_2 = v_t_2418; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s1783742303x1935985330(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  V f_ = v_c_2419;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam4, 1, 2, (V[]){v_k_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_s_246 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(heff_rfield(v_l_240, 2))));
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_246; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam2_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam3, 1, 4, (V[]){v_l_240, v_x_245, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_lam1, 1, 3, (V[]){v_l_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}