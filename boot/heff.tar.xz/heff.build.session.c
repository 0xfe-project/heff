// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_cached 579094605
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_hashes 722717031
#define LBL_implicit 319715269
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
HeffT2 g_heff_2ebuild_2ecache_2efreeze_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2ecache_2emeltFrom_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2edriver_2eelabWith(V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabWith_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2esession_2ecacheDir(V);
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheDir_clo;
V g_heff_2ebuild_2esession_2ecacheKeep(V, V, V);
V g_heff_2ebuild_2esession_2ecacheKeep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheKeep_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_clo;
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(V, V, V);
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_clo;
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(V, V, V);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_clo;
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(V, V, V);
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_clo;
V g_heff_2ebuild_2esession_2ezipSC(V, V);
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_clo;
V g_heff_2ebuild_2esession_2ezipSC_24dps(V, V, V);
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1461302315x821592053(V, V);
V g_list_2efoldl_24s1461302315x821592053_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1461302315x821592053_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2esession_2ecacheDir_str0, 5, ".heff");
Clo g_heff_2ebuild_2esession_2ecacheDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheDir_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecacheDir(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, v_root_242));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2esession_2ecacheDir_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_d_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = v_style_241;
  V v_t_249 = (g_std_2epath_2eparse(v_st_248, v_d_247));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_248, heff_dup(g_heff_2ebuild_2ecache_2eversionDir_get())));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  return ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecacheDir(a[0]);
}
V g_heff_2ebuild_2esession_2ecacheKeep_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecacheKeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheKeep_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecacheKeep(V v_acc_240, V v_th_241, V v_c_242) {
top: ;
  V v_done_243 = heff_take_field(v_acc_240, 0);
  V v_hashes_244 = heff_get_n(v_acc_240, 1, 2);
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(v_done_243, v_t_245));
  V v_t_2412;
  switch (heff_tag_of(v_th_241)) {
  case TAG_Nothing: {
    V v_t_249 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecacheKeep_lam0, 2, 1, (V[]){heff_dup(v_c_242)}), v_hashes_244, heff_rfield(v_c_242, 7)));
    v_t_2412 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_249, v_c_242));
    break;
  }
  case TAG_Just: {
    V v_t_2410 = heff_field(v_th_241, 0);
    V v_t_2411 = (g_list_2efoldl_24s1461302315x821592053(v_hashes_244, heff_rfield(v_t_2410, 2)));
    v_t_2412 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2411, v_c_242));
    break;
  }
  default: heff_nomatch(v_th_241);
  }
  return heff_rec_n(2, shape_done__hashes, (V[]){v_t_246, v_t_2412});
}
V g_heff_2ebuild_2esession_2ecacheKeep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2esession_2ecacheKeep(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2esession_2ecacheKeep_lam0(V self, V *args) {
  V v_m_247 = args[0];
  V v_o_248 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_247, v_c_242, v_o_248));
}
Clo g_heff_2ebuild_2esession_2ezipSC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_entry, 2, 0};

V g_heff_2ebuild_2esession_2ezipSC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_242);
      heff_drop(v_ss_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_cs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_242, v_c_244}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2esession_2ezipSC_24dps(v_ss_243, v_cs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC(a[0], a[1]);
}
Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_24dps_entry, 3, 0};

V g_heff_2ebuild_2esession_2ezipSC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x1_240, 0);
    V v_ss_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_243);
      heff_drop(v_ss_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_c_245 = heff_field(v_x2_241, 0);
      V v_cs_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_243, v_c_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ss_244;
      V t_1 = v_cs_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0, 3, 0};
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_entry, 3, 0};

V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(V v_ps_240, V v_s_241, V v_acc_242) {
top: ;
  V v_hashes_243 = heff_take_field(v_acc_242, 1);
  V v_done_244 = heff_get_n(v_acc_242, 0, 2);
  V v_d_245 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
  V v_st_246 = heff_get_n(v_ps_240, 5, 6);
  V v_t_247 = (g_std_2epath_2eparse(v_st_246, v_d_245));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_str0));
  V v_t_249 = (g_std_2epath_2eparse(v_st_246, v_t_248));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_247, v_t_249));
  V v_s_2411 = ({ V a_0 = v_st_246; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_2410); r_; });
  V v_path_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2411; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2413 = ({ V a_0 = v_path_2412; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2412); r_; });
  V v_c_2417 = heff_tr(heff_call(v_c_2413, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1, 2, 4, (V[]){v_c_2417, v_hashes_243, v_done_244, v_s_241});
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2415 = args[1];
  V v_k_2416 = args[2];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_hashes_243 = heff_env(self)[1];
  V v_done_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_drop(v_hashes_243);
    heff_drop(v_done_244);
    heff_drop_rec(v_s_241, 8);
    V f_ = v_k_2419;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    HeffT2 v_t_2423 = ({ V a_0 = v_hashes_243; V a_1 = v_done_244; V a_2 = v_s_241; V a_3 = v_y_2422; V a_4 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2ecache_2emeltFrom_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_hashes_243); r_; });
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      V v_t_2429;
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_x11_2426 = v_field_2425;
        switch (heff_tag_of(v_x11_2426)) {
        case TAG_MkPair: {
          V v_x_2427 = heff_field(v_x11_2426, 0);
          heff_take_n(v_x11_2426, 1ULL, 2);
          v_t_2429 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Just, 1, (V[]){v_x_2427});
          break;
        }
        default: heff_nomatch(v_x11_2426);
        }
      } else {
        heff_drop_cell(v_ru_24x_2420_24Right, 1);
        heff_drop(v_field_2425);
        v_t_2429 = NTAG(TAG_Nothing);
      }
      V f_ = v_k_2419;
      args[0] = v_t_2429;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_hashes_243 = heff_env(self)[1];
  V v_done_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam2, 1, 4, (V[]){v_k_2419, v_hashes_243, v_done_244, v_s_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(V v_ps_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x2_241, 0);
    V v_x22_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_246)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      V v_t_247 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_245, 6)), heff_dup(heff_rfield(v_s_245, 4))));
      V v_t_248 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_245, 5), v_t_247));
      V v_c_249 = ({ V a_0 = heff_dup(heff_rfield(v_acc_242, 0)); V a_1 = v_s_245; V a_2 = v_t_248; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabWith(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_249), NTAG(TAG_Nil)});
      V v_t_2411 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_242, 0), v_t_2410));
      V v_t_2414 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam1, 2, 1, (V[]){heff_dup(v_c_249)}), heff_get_n(v_acc_242, 1, 2), heff_rfield(v_c_249, 7)));
      V v_t_2415 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2414, v_c_249));
      V v_x_2416 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_2411, v_t_2415});
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam2, 2, 1, (V[]){v_x_2416});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_c_2421 = (g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(heff_dup(v_ps_240), heff_dup(v_s_245), heff_dup(v_acc_242)));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam3, 2, 5, (V[]){v_c_2421, v_s_245, v_acc_242, v_ps_240, v_x22_246});
    }
    default: return heff_nomatch(v_x22_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam1(V self, V *args) {
  V v_m_2412 = args[0];
  V v_o_2413 = args[1];
  V v_c_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2412, v_c_249, v_o_2413));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_s_245 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_x22_246 = heff_env(self)[3];
  V v_hd_2422 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_245, 6)), heff_dup(heff_rfield(v_s_245, 4))));
  V v_t_2426 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_245, 5), v_t_2425));
  V v_t_2427 = (g_heff_2ebuild_2edriver_2eelabWith(heff_dup(heff_rfield(v_acc_242, 0)), v_s_245, v_t_2426, v_x_2424));
  V v_t_2428 = (g_heff_2ebuild_2edriver_2elean(v_t_2427));
  V v_t_2429 = ({ V a_0 = v_acc_242; V a_1 = v_x_2424; V a_2 = v_t_2428; V r_ = (g_heff_2ebuild_2esession_2ecacheKeep(a_0, a_1, a_2)); heff_drop(v_x_2424); r_; });
  V v_t_2430 = (g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(v_ps_240, v_x22_246, v_t_2429));
  V f_ = v_t_2430;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_x22_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam4, 1, 6, (V[]){v_s_245, v_acc_242, v_ps_240, v_x22_246, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1, 3, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5, 2, 0};
Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  V v_hashes_243 = heff_take_field(v_acc_241, 1);
  V v_done_244 = heff_get_n(v_acc_241, 0, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_s_245 = heff_field(v_x3_242, 0);
    V v_c_246 = heff_field(v_x3_242, 1);
    V v_t_247 = heff_dup(heff_rfield(v_c_246, 12));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hashes_243);
      heff_drop(v_done_244);
      heff_drop(v_t_247);
      return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0_clo);
    } else {
      heff_drop(v_t_247);
      V v_t_2410 = heff_dup(heff_rfield(v_c_246, 6));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nil: {
        HeffT2 v_t_2411 = ({ V a_0 = v_hashes_243; V a_1 = v_done_244; V a_2 = heff_dup(v_s_245); V a_3 = heff_dup(v_c_246); HeffT2 r_ = (g_heff_2ebuild_2ecache_2efreeze_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_hashes_243); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_out_2414 = v_field_2413;
            V v_d_2415 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
            V v_st_2416 = heff_get_n(v_ps_240, 5, 6);
            V v_t_2417 = (g_std_2epath_2eparse(v_st_2416, v_d_2415));
            V v_t_2418 = heff_strAppend(heff_dup(heff_rfield(v_c_246, 0)), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_str0));
            V v_t_2419 = (g_std_2epath_2eparse(v_st_2416, v_t_2418));
            V v_t_2420 = (g_std_2epath_2ejoin(v_t_2417, v_t_2419));
            V v_s_2421 = ({ V a_0 = v_st_2416; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2420); r_; });
            V v_path_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2421; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
            V v_c_2423 = ({ V a_0 = v_path_2422; V a_1 = v_out_2414; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2422); r_; });
            V v_c_2427 = heff_tr(heff_call(v_c_2423, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1_clo)}));
            return heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2, 2, 1, (V[]){v_c_2427});
          } else {
            heff_drop_rec(v_ps_240, 6);
            heff_drop(v_field_2413);
            return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4_clo);
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hashes_243);
        heff_drop(v_done_244);
        return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5_clo);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2425 = args[1];
  V v_k_2426 = args[2];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam3, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_acc_241);
    return ((V)&g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(heff_dup(v_ps_240), heff_dup(v_acc_241), v_p_245));
    return heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_acc_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_ps_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam2, 1, 5, (V[]){v_ps_240, v_acc_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2, 3, 0};
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V v_l_240) {
top: ;
  V v_paths_241 = heff_take_field(v_l_240, 2);
  V v_sources_242 = heff_get_n(v_l_240, 0, 5);
  V v_t_243 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get())});
  V v_c_244 = (g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(heff_dup(v_paths_241), heff_dup(v_sources_242), v_t_243));
  return heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam0, 2, 3, (V[]){v_c_244, v_paths_241, v_sources_242});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(a[0]);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V f_ = v_k_246;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_paths_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  V v_t_2416 = (g_heff_2ebuild_2esession_2ezipSC(v_sources_242, heff_dup(heff_rfield(v_x_247, 0))));
  V v_c_2417 = ({ V a_0 = v_paths_241; V a_1 = heff_dup(v_x_247); V a_2 = v_t_2416; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  V f_ = v_c_2417;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam4, 1, 2, (V[]){v_k_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_paths_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_sources_242 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_s_248 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_paths_241)));
  V v_path_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_248; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2410 = ({ V a_0 = v_path_249; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_249); r_; });
  V v_c_2414 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2_clo)}));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3, 1, 5, (V[]){v_sources_242, v_x_247, v_paths_241, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_paths_241 = heff_env(self)[1];
  V v_sources_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam1, 1, 4, (V[]){v_paths_241, v_hd_245, v_sources_242, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}