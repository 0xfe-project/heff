// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Throw 56084
#define TAG_WriteFile 62589
#define LBL_acc 305915
#define LBL_broken 566525696
#define LBL_cached 579094605
#define LBL_checked 974171621
#define LBL_defs 9574869
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_frozen 681056715
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_kept 9783717
#define LBL_keys 9783995
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_spans 310996611
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_unreached 121683306
#define LBL_watches 1357821955
static uint32_t shape_acc__fresh[] = {LBL_acc, LBL_fresh};
static uint32_t shape_checked__frozen[] = {LBL_checked, LBL_frozen};
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_program__kept[] = {LBL_program, LBL_kept};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
HeffT2 g_heff_2ebuild_2ecache_2efreeze_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2ecache_2emeltFrom_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasQualified(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked(V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_clo;
V g_heff_2ebuild_2edriver_2ewithImportedInstances(V, V, V);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo;
V g_heff_2ebuild_2edriver_2ewithTwice(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithTwice_clo;
V g_heff_2ebuild_2esession_2ecacheDir(V);
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheDir_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_clo;
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073(V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_clo;
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803(V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_clo;
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(V, V, V);
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_clo;
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(V, V, V);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_clo;
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957(V, V, V, V, V);
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_clo;
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(V, V, V);
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_clo;
V g_heff_2ebuild_2esession_2ewhereAdded(V, V, V);
V g_heff_2ebuild_2esession_2ewhereAdded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ewhereAdded_clo;
V g_heff_2ebuild_2esession_2ewhereFull(V, V, V);
V g_heff_2ebuild_2esession_2ewhereFull_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ewhereFull_clo;
V g_heff_2ebuild_2esession_2ezipSC(V, V);
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_clo;
V g_heff_2ebuild_2esession_2ezipSC_24dps(V, V, V);
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1722922134x788519507(V, V);
V g_list_2efoldl_24s1722922134x788519507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722922134x788519507_clo;
V g_list_2efoldl_24s1955438510x914057761(V, V);
V g_list_2efoldl_24s1955438510x914057761_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1955438510x914057761_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2esession_2ecacheDir_str0, 5, ".heff");
Clo g_heff_2ebuild_2esession_2ecacheDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheDir_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecacheDir(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_root_242));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2esession_2ecacheDir_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_d_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = v_style_241;
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_247));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_dup(g_heff_2ebuild_2ecache_2eversionDir_get())));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  return ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecacheDir(a[0]);
}
Clo g_heff_2ebuild_2esession_2ezipSC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_entry, 2, 0};

V g_heff_2ebuild_2esession_2ezipSC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_242);
      heff_drop(v_ss_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_cs_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_s_242, v_c_244}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2esession_2ezipSC_24dps(v_ss_243, v_cs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC(a[0], a[1]);
}
Clo g_heff_2ebuild_2esession_2ezipSC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_24dps_entry, 3, 0};

V g_heff_2ebuild_2esession_2ezipSC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x1_240, 0);
    V v_ss_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_243);
      heff_drop(v_ss_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_c_245 = heff_field(v_x2_241, 0);
      V v_cs_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_s_243, v_c_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ss_244;
      V t_1 = v_cs_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC_24dps(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ewhereAdded_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ewhereAdded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ewhereAdded_entry, 3, 0};

V g_heff_2ebuild_2esession_2ewhereAdded(V v_w_240, V v_s_241, V v_c_242) {
top: ;
  V v_acc_243 = heff_take_field(v_w_240, 0);
  V v_fresh_244 = heff_get_n(v_w_240, 1, 2);
  V v_acc_245 = v_acc_243;
  V v_done_246 = heff_take_field(v_acc_245, 0);
  V v_hashes_247 = heff_get_n(v_acc_245, 1, 2);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_done_246, v_t_248));
  V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ewhereAdded_lam0, 2, 1, (V[]){heff_dup(v_c_242)}), v_hashes_247, heff_rfield(v_c_242, 7)));
  V v_t_2413 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2412, heff_dup(v_c_242)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_241, v_c_242}), v_fresh_244});
  return heff_rec_n(2, shape_acc__fresh, (V[]){heff_rec_n(2, shape_done__hashes, (V[]){v_t_249, v_t_2413}), v_t_2414});
}
V g_heff_2ebuild_2esession_2ewhereAdded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ewhereAdded(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ewhereAdded_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_o_2411 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2410, v_c_242, v_o_2411));
}
Clo g_heff_2ebuild_2esession_2ewhereFull_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ewhereFull_entry, 3, 0};

V g_heff_2ebuild_2esession_2ewhereFull(V v_kept_240, V v_w_241, V v_s_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_kept_240, heff_rfield(v_s_242, 2)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_k_246 = v_field_245;
      V v_checked_247 = heff_take_field(v_k_246, 0);
      V v_frozen_248 = heff_get_n(v_k_246, 1, 2);
      if (heff_strEq_c(heff_dup(heff_rfield(v_checked_247, 3)), heff_dup(heff_rfield(v_s_242, 4)))) {
        V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 1, 2);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
        HeffT2 v_t_2411 = (g_heff_2ebuild_2ecache_2emeltFrom_24cpr(v_t_249, v_t_2410, heff_dup(v_s_242), v_frozen_248, MK_INT(0LL)));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop_rec(v_s_242, 8);
            V v_x11_2414 = v_field_2413;
            switch (heff_tag_of(v_x11_2414)) {
            case TAG_MkPair: {
              V v_x_2415 = heff_field(v_x11_2414, 0);
              V v_ru_24x11_2414_24MkPair = heff_take_reuse_n(v_x11_2414, 1ULL, 2);
              V v_c_2417 = v_checked_247;
              V v_acc_2418 = heff_take_field(v_w_241, 0);
              V v_done_2419 = heff_take_field(v_acc_2418, 0);
              V v_hashes_2420 = heff_get_n(v_acc_2418, 1, 2);
              V v_t_2421 = heff_tag_at_n(v_ru_24x11_2414_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_c_2417), NTAG(TAG_Nil)});
              V v_t_2422 = (g_prelude_2e_2b_2b(v_done_2419, v_t_2421));
              V v_t_2423 = ({ V a_0 = v_hashes_2420; V b_1 = heff_get_n(v_x_2415, 2, 3); V r_ = (g_list_2efoldl_24s1955438510x914057761(a_0, b_1)); heff_drop(b_1); r_; });
              V v_t_2424 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2423, v_c_2417));
              return ({ V rv_0 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_2422, v_t_2424}); V rr_ = heff_rec_reuse_nf(v_w_241, 2ULL, 2, shape_acc__fresh, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            }
            default: return heff_nomatch(v_x11_2414);
            }
          } else {
            heff_drop_rec(v_checked_247, 14);
            heff_drop(v_field_2413);
            V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
            V v_t_2426 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2425, heff_dup(v_s_242), NTAG(TAG_Nothing)));
            V v_t_2427 = (g_heff_2ebuild_2edriver_2elean(v_t_2426));
            HEFF_LAST return g_heff_2ebuild_2esession_2ewhereAdded(v_w_241, v_s_242, v_t_2427);
          }
        }
      } else {
        heff_drop_rec(v_checked_247, 14);
        heff_drop(v_frozen_248);
        V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
        V v_t_2429 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2428, heff_dup(v_s_242), NTAG(TAG_Nothing)));
        V v_t_2430 = (g_heff_2ebuild_2edriver_2elean(v_t_2429));
        HEFF_LAST return g_heff_2ebuild_2esession_2ewhereAdded(v_w_241, v_s_242, v_t_2430);
      }
    } else {
      heff_drop(v_field_245);
      V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_w_241, 0)), 0, 2);
      V v_t_2432 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2431, heff_dup(v_s_242), NTAG(TAG_Nothing)));
      V v_t_2433 = (g_heff_2ebuild_2edriver_2elean(v_t_2432));
      HEFF_LAST return g_heff_2ebuild_2esession_2ewhereAdded(v_w_241, v_s_242, v_t_2433);
    }
  }
}
V g_heff_2ebuild_2esession_2ewhereFull_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2esession_2ewhereFull(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0, 1, 0};
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1, 1, 0};
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_entry, 3, 0};

V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(V v_ps_240, V v_s_241, V v_acc_242) {
top: ;
  V v_hashes_243 = heff_take_field(v_acc_242, 1);
  V v_done_244 = heff_get_n(v_acc_242, 0, 2);
  V v_d_245 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
  V v_st_246 = heff_get_n(v_ps_240, 5, 6);
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_246), v_d_245));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_str0));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_246), v_t_248));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_247, v_t_249));
  V v_s_2411 = ({ V a_0 = v_st_246; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_2410); r_; });
  V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
  V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
  V v_a_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_c_2428 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam3, 2, 4, (V[]){v_c_2428, v_hashes_243, v_done_244, v_s_241});
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_err_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2423})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2424));
  }
  case TAG_Right: {
    V v_x_2425 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam2, 2, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_hashes_243 = heff_env(self)[1];
  V v_done_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    heff_take_n(v_x_2431, 0ULL, 1);
    heff_drop(v_hashes_243);
    heff_drop(v_done_244);
    heff_drop_rec(v_s_241, 8);
    V f_ = v_k_2430;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    HeffT2 v_t_2434 = (g_heff_2ebuild_2ecache_2emeltFrom_24cpr(v_hashes_243, v_done_244, v_s_241, v_y_2433, MK_INT(0LL)));
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      V v_t_2440;
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_x11_2437 = v_field_2436;
        switch (heff_tag_of(v_x11_2437)) {
        case TAG_MkPair: {
          V v_x_2438 = heff_field(v_x11_2437, 0);
          heff_take_n(v_x11_2437, 1ULL, 2);
          v_t_2440 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_Just, 1, (V[]){v_x_2438});
          break;
        }
        default: heff_nomatch(v_x11_2437);
        }
      } else {
        heff_drop_cell(v_ru_24x_2431_24Right, 1);
        heff_drop(v_field_2436);
        v_t_2440 = NTAG(TAG_Nothing);
      }
      V f_ = v_k_2430;
      args[0] = v_t_2440;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_hashes_243 = heff_env(self)[1];
  V v_done_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570_lam4, 1, 4, (V[]){v_k_2430, v_hashes_243, v_done_244, v_s_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam5(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(V v_ps_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x2_241, 0);
    V v_x22_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_246)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      V v_c_247 = (g_heff_2ebuild_2edriver_2eelabNext(heff_dup(heff_rfield(v_acc_242, 0)), v_s_245, NTAG(TAG_Nothing)));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_247), NTAG(TAG_Nil)});
      V v_t_249 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_242, 0), v_t_248));
      V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam1, 2, 1, (V[]){heff_dup(v_c_247)}), heff_get_n(v_acc_242, 1, 2), heff_rfield(v_c_247, 7)));
      V v_t_2413 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2412, v_c_247));
      V v_x_2414 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_249, v_t_2413});
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam2, 2, 1, (V[]){v_x_2414});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_c_2419 = (g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(heff_dup(v_ps_240), heff_dup(v_s_245), heff_dup(v_acc_242)));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam3, 2, 5, (V[]){v_c_2419, v_acc_242, v_s_245, v_ps_240, v_x22_246});
    }
    default: return heff_nomatch(v_x22_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_o_2411 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2410, v_c_247, v_o_2411));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam5(V self, V *args) {
  V v_m_2431 = args[0];
  V v_o_2432 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2431, v_c_2428, v_o_2432));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_x22_246 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_acc_2423 = heff_dup(v_acc_242);
  V v_done_2424 = heff_take_field(v_acc_2423, 0);
  V v_hashes_2425 = heff_get_n(v_acc_2423, 1, 2);
  V v_th_2426 = heff_dup(v_x_2422);
  V v_t_2427 = (g_heff_2ebuild_2edriver_2eelabNext(heff_get_n(v_acc_242, 0, 2), v_s_245, v_x_2422));
  V v_c_2428 = (g_heff_2ebuild_2edriver_2elean(v_t_2427));
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2428), NTAG(TAG_Nil)});
  V v_t_2430 = (g_prelude_2e_2b_2b(v_done_2424, v_t_2429));
  V v_t_2436;
  switch (heff_tag_of(v_th_2426)) {
  case TAG_Nothing: {
    V v_t_2433 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam5, 2, 1, (V[]){heff_dup(v_c_2428)}), v_hashes_2425, heff_rfield(v_c_2428, 7)));
    v_t_2436 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2433, v_c_2428));
    break;
  }
  case TAG_Just: {
    V v_t_2434 = heff_field(v_th_2426, 0);
    heff_take_n(v_th_2426, 1ULL, 1);
    V v_t_2435 = ({ V a_0 = v_hashes_2425; V b_1 = heff_get_n(v_t_2434, 2, 3); V r_ = (g_list_2efoldl_24s1955438510x914057761(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_2436 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2435, v_c_2428));
    break;
  }
  default: heff_nomatch(v_th_2426);
  }
  V v_t_2437 = (g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(v_ps_240, v_x22_246, heff_rec_n(2, shape_done__hashes, (V[]){v_t_2430, v_t_2436})));
  V f_ = v_t_2437;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_x22_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_lam4, 1, 6, (V[]){v_acc_242, v_s_245, v_ps_240, v_x22_246, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1, 1, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2, 1, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam6(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam6, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam7(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam7, 2, 0};
Clo g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  V v_hashes_243 = heff_take_field(v_acc_241, 1);
  V v_done_244 = heff_get_n(v_acc_241, 0, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_s_245 = heff_field(v_x3_242, 0);
    V v_c_246 = heff_field(v_x3_242, 1);
    V v_t_247 = heff_dup(heff_rfield(v_c_246, 12));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hashes_243);
      heff_drop(v_done_244);
      heff_drop(v_t_247);
      return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0_clo);
    } else {
      heff_drop(v_t_247);
      V v_t_2410 = heff_dup(heff_rfield(v_c_246, 6));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nil: {
        HeffT2 v_t_2411 = ({ V a_0 = v_hashes_243; V a_1 = v_done_244; V a_2 = heff_dup(v_s_245); V a_3 = heff_dup(v_c_246); HeffT2 r_ = (g_heff_2ebuild_2ecache_2efreeze_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_hashes_243); heff_drop(v_done_244); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_out_2414 = v_field_2413;
            V v_d_2415 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
            V v_st_2416 = heff_get_n(v_ps_240, 5, 6);
            V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_d_2415));
            V v_t_2418 = heff_strAppend(heff_dup(heff_rfield(v_c_246, 0)), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_str0));
            V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_t_2418));
            V v_t_2420 = (g_std_2epath_2ejoin(v_t_2417, v_t_2419));
            V v_s_2421 = ({ V a_0 = v_st_2416; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2420); r_; });
            V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2421));
            V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
            V v_a_2425 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2423, v_out_2414, ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1_clo)});
            V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
            V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
            V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
            V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
            V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
            V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
            V v_c_2438 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2_clo)));
            return heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4, 2, 1, (V[]){v_c_2438});
          } else {
            heff_drop_rec(v_ps_240, 6);
            heff_drop(v_field_2413);
            return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam6_clo);
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hashes_243);
        heff_drop(v_done_244);
        return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam7_clo);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam1(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_err_2433 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Left = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2432_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2433})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2434));
  }
  case TAG_Right: {
    V v_x_2435 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam3, 2, 1, (V[]){v_x_2435});
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2441);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam4(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam5, 1, 1, (V[]){v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam6(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298_lam7(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_acc_241);
    return ((V)&g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2esession_2efreezeOne_24s1080681267x1476378298(heff_dup(v_ps_240), heff_dup(v_acc_241), v_p_245));
    return heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_acc_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_ps_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582_lam2, 1, 5, (V[]){v_ps_240, v_acc_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2, 1, 0};
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3, 1, 0};
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam6(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam5(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V v_l_240) {
top: ;
  V v_paths_241 = heff_take_field(v_l_240, 2);
  V v_sources_242 = heff_get_n(v_l_240, 0, 5);
  V v_t_243 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_c_244 = (g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(heff_dup(v_paths_241), heff_dup(v_sources_242), v_t_243));
  return heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam0, 2, 3, (V[]){v_c_244, v_paths_241, v_sources_242});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(a[0]);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2420})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2421));
  }
  case TAG_Right: {
    V v_x_2422 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam4, 2, 1, (V[]){v_x_2422});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V f_ = v_k_246;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_paths_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2426);
  V v_t_2427 = (g_heff_2ebuild_2esession_2ezipSC(v_sources_242, heff_dup(heff_rfield(v_x_247, 0))));
  V v_c_2428 = ({ V a_0 = v_paths_241; V a_1 = heff_dup(v_x_247); V a_2 = v_t_2427; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s548663471x906014582(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
  V f_ = v_c_2428;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam6, 1, 2, (V[]){v_k_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_paths_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_sources_242 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_s_248 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_paths_241)));
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
  V v_a_2412 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam2_clo)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_c_2425 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam3_clo)));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam5, 1, 5, (V[]){v_sources_242, v_x_247, v_paths_241, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_paths_241 = heff_env(self)[1];
  V v_sources_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_lam1, 1, 4, (V[]){v_paths_241, v_hd_245, v_sources_242, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_entry, 5, 0};

V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803(V v_full_240, V v_kept_241, V v_ps_242, V v_x4_243, V v_w_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_full_240);
    heff_drop(v_ps_242);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam0, 2, 1, (V[]){v_w_244});
  }
  case TAG_Cons: {
    V v_s_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(v_full_240), 1, (V[]){heff_dup(v_s_247)}));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ebuild_2esession_2ewhereFull(v_kept_241, v_w_244, v_s_247));
      V t_0 = v_full_240;
      V t_1 = v_kept_241;
      V t_2 = v_ps_242;
      V t_3 = v_rest_248;
      V t_4 = v_t_2410;
      v_full_240 = t_0;
      v_kept_241 = t_1;
      v_ps_242 = t_2;
      v_x4_243 = t_3;
      v_w_244 = t_4;
      goto top;
    } else {
      heff_drop(v_t_249);
      V v_c_2411 = (g_heff_2ebuild_2esession_2ethawTry_24s802117973x1218957570(heff_dup(v_ps_242), heff_dup(v_s_247), heff_dup(heff_rfield(v_w_244, 0))));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam1, 2, 7, (V[]){v_c_2411, v_w_244, v_s_247, v_full_240, heff_dup(v_kept_241), v_ps_242, v_rest_248});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_w_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_w_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam3(V self, V *args) {
  V v_c_2434 = args[0];
  V v_reached_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2434, 0, 14)}));
  return ({ V a_0 = v_t_2435; V a_1 = v_reached_2433; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_reached_2433); r_; });
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam4(V self, V *args) {
  V v_c_2441 = args[0];
  V v_imps_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2442 = (g_heff_2ebuild_2edriver_2eopenNames(heff_get_n(v_imps_2430, 0, 4)));
  V v_t_2443 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2441, 0, 14)}));
  return ({ V a_0 = v_t_2443; V a_1 = v_xs_2442; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2442); r_; });
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_w_244 = heff_env(self)[0];
  V v_s_247 = heff_env(self)[1];
  V v_full_240 = heff_env(self)[2];
  V v_kept_241 = heff_env(self)[3];
  V v_ps_242 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_w_2415 = v_w_244;
  V v_s_2416 = v_s_247;
  V v_x3_2417 = v_x_2414;
  V v_t_2467;
  switch (heff_tag_of(v_x3_2417)) {
  case TAG_Nothing: {
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_w_2415, 0)), 0, 2);
    V v_t_2419 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2418, heff_dup(v_s_2416), NTAG(TAG_Nothing)));
    V v_t_2420 = (g_heff_2ebuild_2edriver_2elean(v_t_2419));
    v_t_2467 = (g_heff_2ebuild_2esession_2ewhereAdded(v_w_2415, v_s_2416, v_t_2420));
    break;
  }
  case TAG_Just: {
    V v_th_2421 = heff_field(v_x3_2417, 0);
    V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
    V v_lit_2422 = heff_dup(v_th_2421);
    V v_done_2423 = heff_get_n(heff_dup(heff_rfield(v_w_2415, 0)), 0, 2);
    V v_s_2424 = v_s_2416;
    V v_t_2425 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_2424, 6)), heff_dup(heff_rfield(v_s_2424, 4))));
    V v_imps_2426 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_2424, 5), v_t_2425));
    V v_lit_2427 = v_lit_2422;
    V v_done_2428 = heff_dup(v_done_2423);
    V v_s_2429 = v_s_2424;
    V v_imps_2430 = heff_dup(v_imps_2426);
    V v_t_2431 = (g_list_2emap_24s1817208647x1282894070(heff_get_n(v_imps_2426, 0, 4)));
    V v_ms_2432 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2431));
    V v_reached_2433 = ({ V a_0 = v_done_2423; V a_1 = NTAG(TAG_Nil); V a_2 = v_ms_2432; V r_ = (g_heff_2ebuild_2edriver_2eclosureGo(a_0, a_1, a_2)); heff_drop(v_done_2423); r_; });
    V v_needed_2436 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam3, 1, 1, (V[]){v_reached_2433}), heff_dup(v_done_2428)));
    V v_lit_2437 = v_lit_2427;
    V v_done_2438 = heff_dup(v_done_2428);
    V v_s_2439 = v_s_2429;
    V v_imps_2440 = heff_dup(v_imps_2430);
    V v_direct_2444 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam4, 1, 1, (V[]){heff_dup(v_imps_2430)}), heff_dup(v_done_2428)));
    V v_needed_2445 = heff_dup(v_needed_2436);
    V v_t_2446 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_2440, 0))));
    V v_t_2447 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2446));
    V v_t_2448 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_2440, 1))));
    V v_g_2449 = (g_list_2efoldl_24s1261443129x1682844402(heff_dup(g_heff_2eelab_2eglobals_2eemptyGlobals_get()), v_needed_2445));
    V v_t_2450 = ({ V a_0 = v_g_2449; V a_1 = v_needed_2445; V r_ = (g_list_2efoldl_24s1722922134x788519507(a_0, a_1)); heff_drop(v_needed_2445); r_; });
    V v_t_2451 = ({ V a_0 = heff_dup(v_done_2438); V a_1 = v_t_2448; V a_2 = v_t_2450; V a_3 = v_direct_2444; V r_ = (g_heff_2ebuild_2edriver_2ealiasOpen(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); heff_drop(v_direct_2444); r_; });
    V v_t_2452 = (g_heff_2ebuild_2edriver_2ealiasPairs(heff_dup(heff_rfield(v_imps_2440, 0))));
    V v_t_2453 = ({ V a_0 = v_done_2438; V a_1 = v_t_2451; V a_2 = v_t_2452; V r_ = (g_heff_2ebuild_2edriver_2ealiasQualified(a_0, a_1, a_2)); heff_drop(v_t_2452); r_; });
    V v_g0_2454 = ({ V a_0 = v_done_2438; V a_1 = v_t_2447; V a_2 = v_t_2453; V r_ = (g_heff_2ebuild_2edriver_2ewithImportedInstances(a_0, a_1, a_2)); heff_drop(v_done_2438); heff_drop(v_t_2447); r_; });
    V v_t_2455 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_g0_2454, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2456 = (g_list_2efoldl_24s337463599x663364213(v_t_2455, heff_rfield(v_lit_2437, 1)));
    V v_t_2457 = (g_heff_2eelab_2etoplevel_2ethawDone(v_t_2456));
    V v_t_2458 = (g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(v_ru_24x3_2417_24Just, v_s_2439, v_imps_2440, v_lit_2437, v_t_2457));
    V v_c_2459 = ({ V a_0 = v_done_2428; V a_1 = v_imps_2430; V a_2 = v_needed_2436; V a_3 = v_t_2458; V r_ = (g_heff_2ebuild_2edriver_2ewithTwice(a_0, a_1, a_2, a_3)); heff_drop(v_needed_2436); r_; });
    V v_acc_2460 = heff_take_field(v_w_2415, 0);
    V v_done_2461 = heff_take_field(v_acc_2460, 0);
    V v_hashes_2462 = heff_get_n(v_acc_2460, 1, 2);
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_2459), NTAG(TAG_Nil)});
    V v_t_2464 = (g_prelude_2e_2b_2b(v_done_2461, v_t_2463));
    V v_t_2465 = ({ V a_0 = v_hashes_2462; V b_1 = heff_get_n(v_th_2421, 2, 3); V r_ = (g_list_2efoldl_24s1955438510x914057761(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2466 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2465, v_c_2459));
    v_t_2467 = ({ V rv_0 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_2464, v_t_2466}); V rr_ = heff_rec_reuse_nf(v_w_2415, 2ULL, 2, shape_acc__fresh, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    break;
  }
  default: heff_nomatch(v_x3_2417);
  }
  V v_t_2468 = ({ V a_0 = v_full_240; V a_1 = v_kept_241; V a_2 = v_ps_242; V a_3 = v_rest_248; V a_4 = v_t_2467; V r_ = (g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_kept_241); r_; });
  V f_ = v_t_2468;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_s_247 = heff_env(self)[2];
  V v_full_240 = heff_env(self)[3];
  V v_kept_241 = heff_env(self)[4];
  V v_ps_242 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803_lam2, 1, 8, (V[]){v_w_244, v_s_247, v_full_240, v_kept_241, v_ps_242, v_rest_248, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_str0, 3, ".hc");
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam1, 1, 0};
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam2, 1, 0};
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam5(V self, V *args);
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam4(V self, V *args);
Clo g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_entry, 5, 0};

V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957(V v_full_240, V v_ps_241, V v_acc_242, V v_kept_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_full_240);
    heff_drop_rec(v_ps_241, 6);
    heff_drop_rec(v_acc_242, 2);
    return heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam0, 2, 1, (V[]){v_kept_243});
  }
  case TAG_Cons: {
    V v_x51_247 = heff_field(v_x5_244, 0);
    V v_rest_248 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_x51_247)) {
    case TAG_MkPair: {
      V v_s_249 = heff_field(v_x51_247, 0);
      V v_c_2410 = heff_field(v_x51_247, 1);
      V v_t_2411 = heff_dup(heff_rfield(v_c_2410, 6));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nil: {
        HeffT2 v_t_2412 = (g_heff_2ebuild_2ecache_2efreeze_24cpr(heff_rfield(v_acc_242, 1), heff_rfield(v_acc_242, 0), heff_dup(v_s_249), heff_dup(v_c_2410)));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_out_2415 = v_field_2414;
            V v_t_2416 = heff_tr(heff_call(heff_dup(v_full_240), 1, (V[]){heff_dup(v_s_249)}));
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop(v_t_2416);
              V v_t_2417 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_kept_243, heff_dup(heff_rfield(v_s_249, 2)), heff_rec_n(2, shape_checked__frozen, (V[]){heff_dup(v_c_2410), v_out_2415})));
              V t_0 = v_full_240;
              V t_1 = v_ps_241;
              V t_2 = v_acc_242;
              V t_3 = v_t_2417;
              V t_4 = v_rest_248;
              v_full_240 = t_0;
              v_ps_241 = t_1;
              v_acc_242 = t_2;
              v_kept_243 = t_3;
              v_x5_244 = t_4;
              goto top;
            } else {
              heff_drop(v_t_2416);
              V v_d_2418 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_241)));
              V v_st_2419 = heff_dup(heff_rfield(v_ps_241, 5));
              V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2419), v_d_2418));
              V v_t_2421 = heff_strAppend(heff_dup(heff_rfield(v_c_2410, 0)), ((V)&g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_str0));
              V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2419), v_t_2421));
              V v_t_2423 = (g_std_2epath_2ejoin(v_t_2420, v_t_2422));
              V v_s_2424 = ({ V a_0 = v_st_2419; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); heff_drop(v_t_2423); r_; });
              V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2424));
              V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
              V v_a_2428 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2426, v_out_2415, ((V)&g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam1_clo)});
              V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
              V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
              V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
              V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
              V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
              V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
              V v_c_2441 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam2_clo)));
              return heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam4, 2, 6, (V[]){v_c_2441, v_full_240, v_ps_241, v_acc_242, v_kept_243, heff_dup(v_rest_248)});
            }
          } else {
            heff_drop(v_field_2414);
            V t_0 = v_full_240;
            V t_1 = v_ps_241;
            V t_2 = v_acc_242;
            V t_3 = v_kept_243;
            V t_4 = v_rest_248;
            v_full_240 = t_0;
            v_ps_241 = t_1;
            v_acc_242 = t_2;
            v_kept_243 = t_3;
            v_x5_244 = t_4;
            goto top;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_2411, 0ULL, 2);
        V t_0 = v_full_240;
        V t_1 = v_ps_241;
        V t_2 = v_acc_242;
        V t_3 = v_kept_243;
        V t_4 = v_rest_248;
        v_full_240 = t_0;
        v_ps_241 = t_1;
        v_acc_242 = t_2;
        v_kept_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x51_247);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_kept_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_kept_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam1(V self, V *args) {
  V v_r_2427 = args[0];
  return v_r_2427;
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam3(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam2(V self, V *args) {
  V v_x_2435 = args[0];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_err_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2436})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2437));
  }
  case TAG_Right: {
    V v_x_2438 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam3, 2, 1, (V[]){v_x_2438});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_full_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_kept_243 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_hd_2442 = heff_env(self)[5];
  V v_k_2443 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2444);
  V v_t_2445 = ({ V a_0 = v_full_240; V a_1 = v_ps_241; V a_2 = v_acc_242; V a_3 = v_kept_243; V a_4 = v_rest_248; V r_ = (g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_248); r_; });
  V f_ = v_t_2445;
  heff_room[0] = v_hd_2442;
  heff_room[1] = v_k_2443;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam4(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_c_2441 = heff_env(self)[0];
  V v_full_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_kept_243 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2441;
  args[0] = heff_dup(v_hd_2442);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957_lam5, 1, 7, (V[]){v_full_240, v_ps_241, v_acc_242, v_kept_243, v_rest_248, v_hd_2442, v_k_2443});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam1, 1, 0};
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam2, 1, 0};
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam5(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_entry, 6, 0};

V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073(V v_full_240, V v_kept_241, V v_ps_242, V v_sources_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_t_247 = heff_rec_n(2, shape_acc__fresh, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_c_248 = (g_heff_2ebuild_2esession_2ecachedWhereGo_24s1494605626x2064998803(heff_dup(v_full_240), v_kept_241, heff_dup(v_ps_242), v_sources_243, v_t_247));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam0, 1, 5, (V[]){v_ps_242, v_z_244, v_full_240, v_kept_241, v_z_245})});
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam1(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2424})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2425));
  }
  case TAG_Right: {
    V v_x_2426 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam3, 2, 1, (V[]){v_x_2426});
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_acc_2410 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_program__kept, (V[]){heff_get_n(v_acc_2410, 0, 2), v_x_2433});
  V f_ = v_z_245;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_fresh_2411 = heff_env(self)[0];
  V v_full_240 = heff_env(self)[1];
  V v_ps_242 = heff_env(self)[2];
  V v_acc_2410 = heff_env(self)[3];
  V v_kept_241 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2430);
  V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fresh_2411));
  V v_c_2432 = ({ V a_0 = v_full_240; V a_1 = v_ps_242; V a_2 = heff_dup(v_acc_2410); V a_3 = v_kept_241; V a_4 = v_t_2431; V r_ = (g_heff_2ebuild_2esession_2ekeepFresh_24s511843493x956661957(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2431); r_; });
  V f_ = v_c_2432;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam5, 1, 2, (V[]){v_acc_2410, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_full_240 = heff_env(self)[2];
  V v_kept_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_acc_2410 = heff_take_field(v_x_249, 0);
  V v_fresh_2411 = heff_get_n(v_x_249, 1, 2);
  V v_s_2412 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_242)));
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
  V v_a_2416 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam1_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_c_2429 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam2_clo)));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedWhere_24s1671990239x1659206073_lam4, 1, 7, (V[]){v_fresh_2411, v_full_240, v_ps_242, v_acc_2410, v_kept_241, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}