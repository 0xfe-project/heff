// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_MkDir 57961
#define TAG_ReadFile 6783
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_cached 579094605
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_hashes 722717031
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_segments 1801007612
#define LBL_sources 357464573
#define LBL_style 311138763
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
V g_heff_2ebuild_2ecache_2efreeze(V, V, V, V);
V g_heff_2ebuild_2ecache_2efreeze_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreeze_clo;
V g_heff_2ebuild_2ecache_2emeltFrom(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2emeltFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFrom_clo;
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ebuild_2esession_2ecacheDir(V);
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheDir_clo;
V g_heff_2ebuild_2esession_2ecacheKeep(V, V, V);
V g_heff_2ebuild_2esession_2ecacheKeep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecacheKeep_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_clo;
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972(V);
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_clo;
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579(V, V, V);
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_clo;
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243(V, V, V);
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_clo;
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607(V, V, V);
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_clo;
V g_heff_2ebuild_2esession_2ezipSC(V, V);
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ezipSC_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1798985515x221942800(V, V);
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1798985515x221942800_clo;
V g_map_2eempty_get(void);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_STRA(g_heff_2ebuild_2esession_2ecacheDir_str0, 5, (46, 104, 101, 102, 102));
Clo g_heff_2ebuild_2esession_2ecacheDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheDir_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecacheDir(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2esession_2ecacheDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  return (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_247, heff_dup(g_heff_2ebuild_2ecache_2eversionDir_get())));
}
V g_heff_2ebuild_2esession_2ecacheDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecacheDir(a[0]);
}
V g_heff_2ebuild_2esession_2ecacheKeep_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecacheKeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecacheKeep_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecacheKeep(V v_acc_240, V v_th_241, V v_c_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), NTAG(TAG_Nil)});
  V v_t_244 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_240, 0), v_t_243));
  V v_t_2410;
  switch (heff_tag_of(v_th_241)) {
  case TAG_Nothing: {
    V v_t_247 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecacheKeep_lam0, 2, 1, (V[]){heff_dup(v_c_242)}), heff_get_n(v_acc_240, 1, 2), heff_rfield(v_c_242, 7)));
    v_t_2410 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_247, v_c_242));
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_th_241, 0);
    V v_t_249 = (g_list_2efoldl_24s1798985515x221942800(heff_get_n(v_acc_240, 1, 2), heff_rfield(v_t_248, 2)));
    v_t_2410 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_249, v_c_242));
    break;
  }
  default: heff_nomatch(v_th_241);
  }
  return heff_rec_n(2, shape_done__hashes, (V[]){v_t_244, v_t_2410});
}
V g_heff_2ebuild_2esession_2ecacheKeep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2esession_2ecacheKeep(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ebuild_2esession_2ecacheKeep_lam0(V self, V *args) {
  V v_m_245 = args[0];
  V v_o_246 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_245, v_c_242, v_o_246));
}
Clo g_heff_2ebuild_2esession_2ezipSC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ezipSC_entry, 2, 0};

V g_heff_2ebuild_2esession_2ezipSC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_242);
      heff_drop(v_ss_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_cs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_242, v_c_244}), (g_heff_2ebuild_2esession_2ezipSC(v_ss_243, v_cs_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2esession_2ezipSC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ezipSC(a[0], a[1]);
}
HEFF_STRA(g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_str0, 3, (46, 104, 99));
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam0, 1, 0};
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_entry, 3, 0};

V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607(V v_ps_240, V v_s_241, V v_acc_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
  V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), ((V)&g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_str0));
  V v_path_245 = (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_243, v_t_244));
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_245, ((V)&g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_c_2410 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_249}));
  return heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam1, 2, 3, (V[]){v_c_2410, v_acc_242, v_s_241});
}
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2419;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop_rec(v_acc_242, 2);
    heff_drop_rec(v_s_241, 7);
    v_x_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_txt_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_x1_2415 = ({ V b_0 = heff_take_field(v_acc_242, 1); V b_1 = heff_get_n(v_acc_242, 0, 2); V a_2 = v_s_241; V a_3 = v_txt_2414; V a_4 = MK_INT(0LL); V r_ = heff_tr(g_heff_2ebuild_2ecache_2emeltFrom(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x_2413_24Just, 1);
      v_x_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x11_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      switch (heff_tag_of(v_x11_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x11_2416, 0);
        heff_take_n(v_x11_2416, 1ULL, 2);
        v_x_2419 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_Just, 1, (V[]){v_x_2417});
        break;
      }
      default: heff_nomatch(v_x11_2416);
      }
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_2412;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2410;
  args[0] = v_hd_2411;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607_lam2, 1, 3, (V[]){v_acc_242, v_s_241, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam0(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_entry, 3, 0};

V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295(V v_ps_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x2_241, 0);
    V v_x22_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_246)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      V v_c_247 = ({ V a_0 = heff_dup(heff_rfield(v_acc_242, 0)); V a_1 = v_s_245; V b_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabNext(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_247), NTAG(TAG_Nil)});
      V v_t_249 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_242, 0), v_t_248));
      V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam1, 2, 1, (V[]){heff_dup(v_c_247)}), heff_get_n(v_acc_242, 1, 2), heff_rfield(v_c_247, 7)));
      V v_t_2413 = (g_heff_2ebuild_2ecache_2ewholeHash(v_t_2412, v_c_247));
      V v_x_2414 = heff_rec_n(2, shape_done__hashes, (V[]){v_t_249, v_t_2413});
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam2, 2, 1, (V[]){v_x_2414});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_c_2419 = (g_heff_2ebuild_2esession_2ethawTry_24s1292475500x76373607(heff_dup(v_ps_240), heff_dup(v_s_245), heff_dup(v_acc_242)));
      return heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam3, 2, 5, (V[]){v_c_2419, v_acc_242, v_s_245, v_ps_240, v_x22_246});
    }
    default: return heff_nomatch(v_x22_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_o_2411 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecache_2edefHashOne(v_m_2410, v_c_247, v_o_2411));
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_x22_246 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2ebuild_2edriver_2eelabNext(heff_dup(heff_rfield(v_acc_242, 0)), v_s_245, v_x_2422));
  V v_t_2424 = (g_heff_2ebuild_2edriver_2elean(v_t_2423));
  V v_t_2425 = ({ V a_0 = v_acc_242; V a_1 = v_x_2422; V a_2 = v_t_2424; V r_ = (g_heff_2ebuild_2esession_2ecacheKeep(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
  V v_t_2426 = (g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295(v_ps_240, v_x22_246, v_t_2425));
  return heff_tail(v_t_2426, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_x22_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295_lam4, 1, 6, (V[]){v_acc_242, v_s_245, v_ps_240, v_x22_246, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_str0, 3, (46, 104, 99));
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam1(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam1, 2, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam2, 1, 0};
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam3(V self, V *args);
Clo g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_c_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_dup(heff_rfield(v_c_244, 12));
    V v_t_2410;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_t_246 = heff_dup(heff_rfield(v_c_244, 6));
      V v_x1_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_x1_249 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        v_x1_249 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      switch (heff_tag_of(v_x1_249)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_ps_240);
      heff_drop_rec(v_acc_241, 2);
      return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam0_clo);
    }
    case TAG_False: {
      V v_t_2413 = ({ V b_0 = heff_take_field(v_acc_241, 1); V b_1 = heff_get_n(v_acc_241, 0, 2); V a_2 = heff_dup(v_s_243); V a_3 = heff_dup(v_c_244); V r_ = (g_heff_2ebuild_2ecache_2efreeze(b_0, b_1, a_2, a_3)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop(v_ps_240);
        return ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam1_clo);
      }
      case TAG_Just: {
        V v_out_2416 = heff_field(v_t_2413, 0);
        V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
        V v_t_2417 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(v_ps_240)));
        V v_t_2418 = heff_strAppend(heff_dup(heff_rfield(v_c_244, 0)), ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_str0));
        V v_path_2419 = (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_2417, v_t_2418));
        V v_t_2421 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2419, v_out_2416, ((V)&g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam2_clo)})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_c_2424 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2423}));
        return heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam3, 2, 1, (V[]){v_c_2424});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam2(V self, V *args) {
  V v_ok_2420 = args[0];
  return v_ok_2420;
}
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243_lam4, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam0(V self, V *args); static Clo g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam0, 2, 0};
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam2(V self, V *args);
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam1(V self, V *args);
Clo g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_entry, 3, 0};

V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_acc_241);
    return ((V)&g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2esession_2efreezeOne_24s2106123329x1076448243(heff_dup(v_ps_240), heff_dup(v_acc_241), v_p_245));
    return heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_acc_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_ps_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579_lam2, 1, 5, (V[]){v_ps_240, v_acc_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam2(V self, V *args); static Clo g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam2, 1, 0};
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam4(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam3(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam1(V self, V *args);
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam0(V self, V *args);
Clo g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_entry, 1, 0};

V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972(V v_l_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_map_2eempty_get())});
  V v_c_242 = (g_heff_2ebuild_2esession_2ecachedGo_24s415495370x1224329295(heff_dup(heff_rfield(v_l_240, 2)), heff_dup(heff_rfield(v_l_240, 0)), v_t_241));
  return heff_clo_n(g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam0, 2, 2, (V[]){v_c_242, v_l_240});
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972(a[0]);
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam2(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_244;
  args[0] = heff_get_n(v_x_245, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2412);
  V v_t_2413 = (g_heff_2ebuild_2esession_2ezipSC(heff_take_field(v_l_240, 0), heff_dup(heff_rfield(v_x_245, 0))));
  V v_c_2414 = ({ V a_0 = heff_get_n(v_l_240, 2, 5); V a_1 = heff_dup(v_x_245); V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2esession_2efreezeAll_24s1253014440x1825390579(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
  return heff_tail(v_c_2414, 2, (V[]){v_hd_243, heff_clo_n(g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam4, 1, 2, (V[]){v_k_244, v_x_245})});
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_246 = (g_heff_2ebuild_2esession_2ecacheDir(heff_dup(heff_rfield(v_l_240, 2))));
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_246, ((V)&g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_c_2411 = heff_tr(heff_apply(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2410}));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam3, 1, 4, (V[]){v_l_240, v_x_245, v_hd_243, v_k_244})});
}
V g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2esession_2ecachedProgram_24s93880629x1718236972_lam1, 1, 3, (V[]){v_l_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}