// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_HS 9084
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fuel 9649789
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_key__body__safe__touched[] = {LBL_key, LBL_body, LBL_safe, LBL_touched};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2earmOver(V, V, V);
V g_heff_2ecompile_2esimplify_2earmOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmOver_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
V g_heff_2ecompile_2esimplify_2efollowerCopied(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerCopied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerCopied_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eintOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2esafeAs_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esetOff_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2esumPushed(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V);
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_list_2efoldl_24f2082849937x387822498(V, V, V, V);
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2082849937x387822498_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2epartialHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialHead(V v_s_240, V v_argv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
    V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_g_244; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_t_245); r_; });
    return ({ V a_0 = v_s_240; V a_1 = v_argv_241; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialHead(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str0, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str1, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str3, 5, "False");

HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      V v_b_2454 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eintOp_24cpr(v_p_240, v_a_2428, v_b_2454);
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    V v_a_2469 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      V v_b_2497 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str0), 2)) {
        V v_f_2498 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2469, v_b_2497)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2498}});
      } else {
        heff_drop_cell(v_ru_24x2_241_24EStr, 1);
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str1), 2)) {
          V v_t_2499;
          if (heff_strEq_c(v_a_2469, v_b_2497)) {
            v_t_2499 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str2);
          } else {
            v_t_2499 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str3);
          }
          V v_f_24100 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2499, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24100}});
        } else {
          heff_drop(v_a_2469);
          heff_drop(v_b_2497);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2469);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2earmOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earmOver_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2earmOver(V v_budget_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_ts_243 = heff_field(v_x2_241, 0);
    V v_n_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x3_242, 0);
      V v_b_247 = heff_field(v_x3_242, 2);
      V v_t_248 = (g_list_2efoldl_24f2082849937x387822498(MK_INT(1LL), MK_INT(0LL), v_t_245, v_ts_243));
      V v_x_249 = heff_intAdd(v_t_248, heff_dup(v_n_244));
      if (heff_intLt_c(MK_INT(1LL), v_x_249)) {
        V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_245; V a_3 = v_ts_243; V r_ = (g_list_2efoldl_24f2082849937x387822498(a_0, a_1, a_2, a_3)); heff_drop(v_ts_243); r_; });
        V v_t_2411 = heff_intSub(heff_intAdd(v_t_2410, v_n_244), MK_INT(1LL));
        V v_lim_2412 = heff_intDiv(v_budget_240, v_t_2411);
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
        V v_x_2414 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2412), MK_INT(0LL), v_t_2413));
        V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_lim_2412, v_x_2414, 0));
        heff_drop(v_lim_2412);
        heff_drop(v_x_2414);
        return v_ret_24bool;
      } else {
        heff_drop(v_budget_240);
        heff_drop(v_ts_243);
        heff_drop(v_n_244);
        heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2earmOver_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2earmOver(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam20(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esumPushed_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumPushed_lam20, 1, 0};
V g_heff_2ecompile_2esimplify_2esumPushed_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam24(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esumPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumPushed_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esumPushed(V v_r_240, V v_x_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam0, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam1, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ELam: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam2, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EApp: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam3, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ELet: {
    V v_y_2434 = heff_field(v_x4_243, 0);
    V v_a_2435 = heff_field(v_x4_243, 1);
    V v_c_2436 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_m_2437 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_c_2436));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam4, 1, 3, (V[]){v_m_2437, v_y_2434, v_a_2435});
  }
  case TAG_ERecord: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam5, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EProj: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam6, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ETag: {
    V v_t_2460 = heff_field(v_x4_243, 0);
    V v_es_2461 = heff_field(v_x4_243, 1);
    V v_ts_2462 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam7, 1, 6, (V[]){v_es_2461, v_b_242, v_x_241, v_t_2460, v_ts_2462, v_r_240});
  }
  case TAG_EMatch: {
    V v_s_2484 = heff_field(v_x4_243, 0);
    V v_arms_2485 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_m_2495 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam8, 1, 3, (V[]){v_r_240, v_x_241, v_b_242}), v_arms_2485));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam10, 1, 2, (V[]){v_m_2495, v_s_2484});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam11, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EPrimCall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam12, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ECall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam13, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam14, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam15, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam16, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam17, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam18, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam19, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return ((V)&g_heff_2ecompile_2esimplify_2esumPushed_lam20_clo);
  }
  case TAG_EBool: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam21, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ESet: {
    V v_ys_24174 = heff_field(v_x4_243, 0);
    V v_a_24175 = heff_field(v_x4_243, 1);
    V v_c_24176 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_m_24177 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_c_24176));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam22, 1, 3, (V[]){v_m_24177, v_ys_24174, v_a_24175});
  }
  case TAG_EValues: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam23, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam24, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esumPushed(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_s_2410 = v_field_248;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_249});
    heff_room[1] = v_s_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2412));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_x_2416 = v_field_2414;
    V v_s_2417 = v_field_2415;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2416});
    heff_room[1] = v_s_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2421 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2420));
  {
    V v_field_2422 = v_t_2421.f[0];
    V v_field_2423 = v_t_2421.f[1];
    V v_x_2424 = v_field_2422;
    V v_s_2425 = v_field_2423;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2424});
    heff_room[1] = v_s_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam3(V self, V *args) {
  V v_s_2428 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2429 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2428));
  {
    V v_field_2430 = v_t_2429.f[0];
    V v_field_2431 = v_t_2429.f[1];
    V v_x_2432 = v_field_2430;
    V v_s_2433 = v_field_2431;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2432});
    heff_room[1] = v_s_2433;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam4(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_y_2434 = heff_env(self)[1];
  V v_a_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2434, v_a_2435, v_x_2440}), v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam5(V self, V *args) {
  V v_s_2444 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2445 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2444));
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_x_2448 = v_field_2446;
    V v_s_2449 = v_field_2447;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2448});
    heff_room[1] = v_s_2449;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam6(V self, V *args) {
  V v_s_2454 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2455 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2454));
  {
    V v_field_2456 = v_t_2455.f[0];
    V v_field_2457 = v_t_2455.f[1];
    V v_x_2458 = v_field_2456;
    V v_s_2459 = v_field_2457;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2458});
    heff_room[1] = v_s_2459;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam7(V self, V *args) {
  V v_s_2463 = args[0];
  V v_es_2461 = heff_env(self)[0];
  V v_b_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_t_2460 = heff_env(self)[3];
  V v_ts_2462 = heff_env(self)[4];
  V v_r_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2464 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_es_2461, v_s_2463));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    HeffT2 v_t_2467 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2466));
    {
      V v_field_2468 = v_t_2467.f[0];
      V v_field_2469 = v_t_2467.f[1];
      V v_x_2470 = v_field_2468;
      V v_s_2471 = v_field_2469;
      V v_t_2474;
      switch (heff_tag_of(v_x_2465)) {
      case TAG_MkPair: {
        V v_y_2473 = heff_dup(heff_field(v_x_2465, 1));
        v_t_2474 = v_y_2473;
        break;
      }
      default: heff_nomatch(v_x_2465);
      }
      V v_t_2475 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2460, v_t_2474, v_ts_2462}), v_x_2470});
      V v_m_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2475}));
      V v_x2_2477 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2471}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        V v_t_2482;
        switch (heff_tag_of(v_x_2465)) {
        case TAG_MkPair: {
          V v_x_2480 = heff_field(v_x_2465, 0);
          heff_take_n(v_x_2465, 1ULL, 2);
          v_t_2482 = v_x_2480;
          break;
        }
        default: heff_nomatch(v_x_2465);
        }
        V v_x_2483 = ({ V a_0 = v_t_2482; V a_1 = v_x_2478; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2482); r_; });
        return heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){v_x_2483, v_s_2479});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam9(V self, V *args) {
  V v_s_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_t_2487 = heff_env(self)[1];
  V v_vs_2488 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_s_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_s_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2487, v_vs_2488, v_x_2493}), v_s_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam8(V self, V *args) {
  V v_a_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_2486)) {
  case TAG_MkArm: {
    V v_t_2487 = heff_field(v_a_2486, 0);
    V v_vs_2488 = heff_field(v_a_2486, 1);
    V v_b_2489 = heff_field(v_a_2486, 2);
    heff_take_n(v_a_2486, 7ULL, 3);
    V v_m_2490 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_b_2489));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam9, 1, 3, (V[]){v_m_2490, v_t_2487, v_vs_2488});
  }
  default: return heff_nomatch(v_a_2486);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam10(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_s_2484 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2484, v_x_2498}), v_s_2499});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam11(V self, V *args) {
  V v_s_24101 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24102 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24101));
  {
    V v_field_24103 = v_t_24102.f[0];
    V v_field_24104 = v_t_24102.f[1];
    V v_x_24105 = v_field_24103;
    V v_s_24106 = v_field_24104;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24105});
    heff_room[1] = v_s_24106;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam12(V self, V *args) {
  V v_s_24109 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24110 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24109));
  {
    V v_field_24111 = v_t_24110.f[0];
    V v_field_24112 = v_t_24110.f[1];
    V v_x_24113 = v_field_24111;
    V v_s_24114 = v_field_24112;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24113});
    heff_room[1] = v_s_24114;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam13(V self, V *args) {
  V v_s_24117 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24118 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24117));
  {
    V v_field_24119 = v_t_24118.f[0];
    V v_field_24120 = v_t_24118.f[1];
    V v_x_24121 = v_field_24119;
    V v_s_24122 = v_field_24120;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24121});
    heff_room[1] = v_s_24122;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam14(V self, V *args) {
  V v_s_24124 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24125 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24124));
  {
    V v_field_24126 = v_t_24125.f[0];
    V v_field_24127 = v_t_24125.f[1];
    V v_x_24128 = v_field_24126;
    V v_s_24129 = v_field_24127;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24128});
    heff_room[1] = v_s_24129;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam15(V self, V *args) {
  V v_s_24131 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24132 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24131));
  {
    V v_field_24133 = v_t_24132.f[0];
    V v_field_24134 = v_t_24132.f[1];
    V v_x_24135 = v_field_24133;
    V v_s_24136 = v_field_24134;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24135});
    heff_room[1] = v_s_24136;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam16(V self, V *args) {
  V v_s_24138 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24139 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24138));
  {
    V v_field_24140 = v_t_24139.f[0];
    V v_field_24141 = v_t_24139.f[1];
    V v_x_24142 = v_field_24140;
    V v_s_24143 = v_field_24141;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24142});
    heff_room[1] = v_s_24143;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam17(V self, V *args) {
  V v_s_24145 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24146 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24145));
  {
    V v_field_24147 = v_t_24146.f[0];
    V v_field_24148 = v_t_24146.f[1];
    V v_x_24149 = v_field_24147;
    V v_s_24150 = v_field_24148;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24149});
    heff_room[1] = v_s_24150;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam18(V self, V *args) {
  V v_s_24153 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24154 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24153));
  {
    V v_field_24155 = v_t_24154.f[0];
    V v_field_24156 = v_t_24154.f[1];
    V v_x_24157 = v_field_24155;
    V v_s_24158 = v_field_24156;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24157});
    heff_room[1] = v_s_24158;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam19(V self, V *args) {
  V v_s_24160 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24161 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24160));
  {
    V v_field_24162 = v_t_24161.f[0];
    V v_field_24163 = v_t_24161.f[1];
    V v_x_24164 = v_field_24162;
    V v_s_24165 = v_field_24163;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24164});
    heff_room[1] = v_s_24165;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam20(V self, V *args) {
  V v_s_24166 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_s_24166});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam21(V self, V *args) {
  V v_s_24168 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24169 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24168));
  {
    V v_field_24170 = v_t_24169.f[0];
    V v_field_24171 = v_t_24169.f[1];
    V v_x_24172 = v_field_24170;
    V v_s_24173 = v_field_24171;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24172});
    heff_room[1] = v_s_24173;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam22(V self, V *args) {
  V v_s_24178 = args[0];
  V v_m_24177 = heff_env(self)[0];
  V v_ys_24174 = heff_env(self)[1];
  V v_a_24175 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24179 = heff_tr(heff_call(v_m_24177, 1, (V[]){v_s_24178}));
  switch (heff_tag_of(v_x2_24179)) {
  case TAG_MkPair: {
    V v_x_24180 = heff_field(v_x2_24179, 0);
    V v_s_24181 = heff_field(v_x2_24179, 1);
    V v_ru_24x2_24179_24MkPair = heff_take_reuse_n(v_x2_24179, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24179_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_24174, v_a_24175, v_x_24180}), v_s_24181});
  }
  default: return heff_nomatch(v_x2_24179);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam23(V self, V *args) {
  V v_s_24183 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24184 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24183));
  {
    V v_field_24185 = v_t_24184.f[0];
    V v_field_24186 = v_t_24184.f[1];
    V v_x_24187 = v_field_24185;
    V v_s_24188 = v_field_24186;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24187});
    heff_room[1] = v_s_24188;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam24(V self, V *args) {
  V v_s_24191 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24192 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24191));
  {
    V v_field_24193 = v_t_24192.f[0];
    V v_field_24194 = v_t_24192.f[1];
    V v_x_24195 = v_field_24193;
    V v_s_24196 = v_field_24194;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24195});
    heff_room[1] = v_s_24196;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_sp_244 = heff_take_field(v_s_243, 7);
  V v_supply_245 = heff_take_field(v_s_243, 0);
  V v_fuel_246 = heff_take_field(v_s_243, 1);
  V v_defs_247 = heff_take_field(v_s_243, 2);
  V v_safe_248 = heff_take_field(v_s_243, 3);
  V v_base_249 = heff_take_field(v_s_243, 4);
  V v_total_2410 = heff_take_field(v_s_243, 5);
  V v_plain_2411 = heff_take_field(v_s_243, 6);
  V v_kp_2412 = heff_get_n(v_s_243, 8, 9);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_x_2414 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_2413));
  V v_t_2415;
  if (!heff_intLt_c_lent(MK_INT(1200LL), v_x_2414, 1)) {
    heff_drop(v_x_2414);
    v_t_2415 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_sp_244, 0)), heff_dup(v_h_240), heff_dup(v_b0_241)));
  } else {
    heff_drop(v_x_2414);
    v_t_2415 = heff_dup(heff_rfield(v_sp_244, 0));
  }
  V v_t_2455;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2455 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2455 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2455 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2456;
  if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
    heff_drop(v_t_2455);
    v_t_2456 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_sp_244, 1)), heff_dup(v_h_240), NTAG(TAG_MkUnit)));
  } else {
    heff_drop(v_t_2455);
    v_t_2456 = heff_dup(heff_rfield(v_sp_244, 1));
  }
  V v_t_2457 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_sp_244, 2), heff_dup(v_h_240), v_b0_241));
  V v_t_2458 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_sp_244, 3), v_h_240, v_d_242));
  V v_t_2459 = heff_intAdd(heff_take_field(v_sp_244, 5), MK_INT(1LL));
  V v_p_2460 = ({ V rv_0 = v_t_2415; V rv_1 = v_t_2456; V rv_2 = v_t_2457; V rv_3 = v_t_2458; V rv_5 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_sp_244, 80ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 13056u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_f_2461 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_245, v_fuel_246, v_defs_247, v_safe_248, v_base_249, v_total_2410, v_plain_2411, v_p_2460, v_kp_2412});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2461}});
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam22(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBody_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_sh_243, V v_lam1_244) {
top: ;
  V v_args_245 = heff_take_field(v_sh_243, 0);
  V v_vars_246 = heff_get_n(v_sh_243, 1, 3);
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_2411 = heff_field(v_lam1_244, 0);
    V v_b1_2412 = heff_field(v_lam1_244, 1);
    V v_ru_24lam1_244_24ELam = heff_take_reuse_n(v_lam1_244, 3ULL, 2);
    V v_t_2413 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24lam1_244_24ELam, heff_dup(v_vars_246)));
    V v_t_2414 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_t_2413, heff_dup(v_marks_242), v_b1_2412));
    V v_m_2415 = ({ V a_0 = heff_dup(v_marks_242); V a_1 = heff_dup(v_xs1_2411); V a_2 = v_args_245; V a_3 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_args_245); r_; });
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam2, 1, 4, (V[]){v_m_2415, v_marks_242, v_xs1_2411, v_vars_246});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam17, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam18, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EBool: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam19, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ESet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam20, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EValues: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam21, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_args_245);
    heff_drop(v_vars_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam22, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_2411 = heff_env(self)[2];
  V v_vars_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_2411)));
    V v_x1_2421 = (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(v_vars_246), v_t_2420));
    V v_x_2426;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_2411);
      heff_drop(v_vars_246);
      v_x_2426 = v_x_2418;
      break;
    }
    case TAG_Cons: {
      V v_ru_24x1_2421_24Cons = heff_take_reuse_n(v_x1_2421, 0ULL, 2);
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2ekeepParams(v_marks_242, v_xs1_2411));
      V v_t_2425 = (g_heff_2ecompile_2esimplify_2eappendL(v_vars_246, v_t_2424));
      v_x_2426 = heff_tag_at_n(v_ru_24x1_2421_24Cons, TAG_ELam, 2, (V[]){v_t_2425, v_x_2418});
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2429 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2429});
}
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2433});
}
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2436 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2436});
}
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2441 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2441});
}
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2445});
}
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2448 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2448});
}
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2450 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2450});
}
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2453 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2453});
}
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2456 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2456});
}
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2458 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2458});
}
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2460 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2460});
}
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2462 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2462});
}
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2464 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2464});
}
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2467 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args) {
  V v_s_2469 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2469});
}
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args) {
  V v_s_2470 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2470});
}
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args) {
  V v_s_2472 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2472});
}
V g_heff_2ecompile_2esimplify_2especBody_lam20(V self, V *args) {
  V v_s_2476 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2476});
}
V g_heff_2ecompile_2esimplify_2especBody_lam21(V self, V *args) {
  V v_s_2478 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2478});
}
V g_heff_2ecompile_2esimplify_2especBody_lam22(V self, V *args) {
  V v_s_2481 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2481});
}

HeffT2 g_heff_2ecompile_2esimplify_2esetOff_24cpr(V v_o_240, V v_s_241) {
top: ;
  V v_supply_242 = heff_take_field(v_s_241, 0);
  V v_fuel_243 = heff_take_field(v_s_241, 1);
  V v_defs_244 = heff_take_field(v_s_241, 2);
  V v_safe_245 = heff_take_field(v_s_241, 3);
  V v_base_246 = heff_take_field(v_s_241, 4);
  V v_total_247 = heff_take_field(v_s_241, 5);
  V v_plain_248 = heff_take_field(v_s_241, 6);
  V v_sp_249 = heff_take_field(v_s_241, 7);
  V v_kp_2410 = heff_get_n(v_s_241, 8, 9);
  V v_t_2411 = ({ V rv_6 = v_o_240; V rr_ = heff_rec_reuse_nf(v_sp_249, 63ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  V v_f_2412 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_242, v_fuel_243, v_defs_244, v_safe_245, v_base_246, v_total_247, v_plain_248, v_t_2411, v_kp_2410});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2412}});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str1, 0, "");
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyVer_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecopyVer(V v_vers_240, V v_h_241, V v_g_242, V v_args_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
  V v_t_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopyVer_lam0, 1, 1, (V[]){heff_dup(v_vers_240)}), heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, v_t_245})));
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2eversAll_24cpr(v_t_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_vs_2411 = v_field_2410;
      V v_t_2412 = (g_list_2emap_24s1123370502x1982532655(v_vs_2411));
      V v_items_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_h_241}), v_t_2412});
      HeffT2 v_t_2414 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2413));
      {
        V v_field_2415 = v_t_2414.f[0];
        V v_field_2416 = v_t_2414.f[1];
        V v_a_2417 = v_field_2415;
        V v_b_2418 = v_field_2416;
        V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str0), heff_intShow(v_b_2418));
        return heff_strAppend(heff_intShow(v_a_2417), v_t_2419);
      }
    } else {
      heff_drop(v_h_241);
      heff_drop(v_field_2410);
      return ((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str1);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyVer(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_vers_240; V a_1 = v_k_246; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_vers_240); heff_drop(v_k_246); r_; });
}
Clo g_heff_2ecompile_2esimplify_2emissingOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emissingOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emissingOf(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    V v_e1_246 = heff_field(v_e_241, 0);
    V v_bs_247 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_e1_246, 0);
      V v_all_2410 = heff_get_n(v_s_240, 2, 9);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_2410, v_h_249));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2413 = ({ V a_0 = v_all_2410; V a_1 = v_h_249; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_2410); r_; });
        V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
        return heff_intSub(v_t_2413, v_t_2414);
      } else {
        heff_drop(v_all_2410);
        return MK_INT(0LL);
      }
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_e1_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EValues: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emissingOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2efollowerCopied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerCopied_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2efollowerCopied(V v_r_240, V v_saved_241, V v_orig_242, V v_k_243, V v_f_244, V v_m_245, V v_z_246) {
top: ;
  V v_defs_247 = heff_take_field(v_saved_241, 2);
  V v_total_248 = heff_get_n(v_saved_241, 5, 9);
  V v_m_249 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_k_243, v_f_244, v_m_245));
  V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_x_2411}));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_s_2416 = heff_field(v_x2_2414, 1);
      V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_orig_242), NTAG(TAG_Nil)});
      V v_t_2418 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2417));
      V v_lim_2419 = heff_intAdd(v_t_2418, MK_INT(160LL));
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2415), NTAG(TAG_Nil)});
      V v_x_2421 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2419), MK_INT(0LL), v_t_2420));
      if (!heff_intLt_c_lent(v_lim_2419, v_x_2421, 0)) {
        heff_drop(v_orig_242);
        heff_drop(v_defs_247);
        heff_drop(v_total_248);
        heff_drop(v_lim_2419);
        heff_drop(v_x_2421);
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2416});
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_lim_2419);
        heff_drop(v_x_2421);
        V v_t_2422 = ({ V rv_2 = v_defs_247; V rv_5 = v_total_248; V rr_ = heff_rec_reuse_nf(v_s_2416, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_orig_242, v_t_2422});
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerCopied_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2efollowerCopied(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_x1_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeEach(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2edoneOf_str0, 0, "");
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edoneOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edoneOf_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2edoneOf(V v_s_240, V v_d_241, V v_b_242, V v_t_243) {
top: ;
  V v_safe_244 = heff_take_field(v_s_240, 3);
  V v_kp_245 = heff_get_n(v_s_240, 8, 9);
  HeffT2 v_t_246 = ({ V a_0 = v_safe_244; V a_1 = heff_rfield(v_d_241, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_safe_244); r_; });
  V v_t_2410;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    v_t_2410 = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_249); c_; })));
    heff_drop(v_field_248);
  }
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  V v_t_2412 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2emap_2eempty_get()), v_t_2411));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2edoneOf_lam0, 1, 1, (V[]){v_kp_245}), v_t_2412));
  return heff_rec_n(4, shape_key__body__safe__touched, (V[]){heff_get_n(v_d_241, 0, 3), v_b_242, v_t_2410, v_t_2419});
}
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edoneOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args) {
  V v_h_2413 = args[0];
  V v_kp_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_kp_245, 0, 5); V a_1 = v_h_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2418;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2416;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2416);
      v_t_2418 = ((V)&g_heff_2ecompile_2esimplify_2edoneOf_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2413, v_t_2418});
}

HeffT2 g_heff_2ecompile_2esimplify_2esafeAs_24cpr(V v_x1_240, V v_k_241, V v_p_242) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_243 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_p_242, 3), v_k_241, NTAG(TAG_MkUnit)));
    V v_f_244 = ({ V rv_3 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_244}});
  } else {
    heff_drop(v_k_241);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_242}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2esimplify_2eappendL_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24tok2(a[0], a[1], a[2]);
}