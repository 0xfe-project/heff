// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HS 9084
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_off 319465
#define LBL_out 319944
#define LBL_placed 961367912
#define LBL_plain 308106724
#define LBL_pool 9942243
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__body__safe__touched[] = {LBL_key, LBL_body, LBL_safe, LBL_touched};
static uint32_t shape_pool__placed__out[] = {LBL_pool, LBL_placed, LBL_out};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2earmOver(V, V, V);
V g_heff_2ecompile_2esimplify_2earmOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmOver_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkKept_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ecanonVisit(V, V);
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
HeffT2 g_heff_2ecompile_2esimplify_2efindArm_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2ehandlerPushed(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eintOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ekeptAsk_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ekeptAt_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsRetied_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2erefsTouched_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esafeAs_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esetOff_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2esumPushed(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_clo;
V g_heff_2ecompile_2esimplify_2eunmade(V, V);
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunmade_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V);
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
V g_list_2efilter_24s1328865458x1020778875(V);
V g_list_2efilter_24s1328865458x1020778875_entry(V self, V *a);
extern Clo g_list_2efilter_24s1328865458x1020778875_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f226312210x181720981(V, V, V, V);
V g_list_2efoldl_24f226312210x181720981_entry(V self, V *a);
extern Clo g_list_2efoldl_24f226312210x181720981_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s139856607x1870756346(V, V);
V g_list_2efoldl_24s139856607x1870756346_entry(V self, V *a);
extern Clo g_list_2efoldl_24s139856607x1870756346_clo;
V g_list_2efoldl_24s419339443x1702462498(V, V);
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a);
extern Clo g_list_2efoldl_24s419339443x1702462498_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s688118489x1560799399(V, V, V);
V g_list_2efoldl_24s688118489x1560799399_entry(V self, V *a);
extern Clo g_list_2efoldl_24s688118489x1560799399_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1531069132x955165792(V);
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ecompile_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V v_e_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), heff_take_field(v_s_241, 0), v_e_240));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_e_27_245 = v_field_243;
    V v_n_246 = v_field_244;
    V v_f_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_e_27_245, v_f_247}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str0, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str1, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str2, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str3, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str4, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str5, 6, "intShl");

static V g_heff_2ecompile_2esimplify_2efailing_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2efailing_st;
static V g_heff_2ecompile_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str4), v_t_241})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str5), v_t_242});
}
V g_heff_2ecompile_2esimplify_2efailing_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2efailing_st)) return g_heff_2ecompile_2esimplify_2efailing_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2efailing_val, &g_heff_2ecompile_2esimplify_2efailing_st, g_heff_2ecompile_2esimplify_2efailing_init);
}
Clo g_heff_2ecompile_2esimplify_2epartialHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialHead(V v_s_240, V v_argv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
    V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_g_244; V r_ = (g_std_2emap_2elookup_24s1963842891x1660122411(a_0, a_1)); heff_drop(v_t_245); r_; });
    return ({ V a_0 = v_s_240; V a_1 = v_argv_241; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_argv_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialHead(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str0, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str1, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str3, 5, "False");

HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      V v_b_2454 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eintOp_24cpr(v_p_240, v_a_2428, v_b_2454);
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2428);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    V v_a_2464 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      V v_b_2492 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str0), 2)) {
        V v_f_2494 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2464, v_b_2492)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2494}});
      } else {
        heff_drop_cell(v_ru_24x2_241_24EStr, 1);
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str1), 2)) {
          V v_t_2497;
          if (heff_strEq_c(v_a_2464, v_b_2492)) {
            v_t_2497 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str2);
          } else {
            v_t_2497 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str3);
          }
          V v_f_2498 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2497, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2498}});
        } else {
          heff_drop(v_a_2464);
          heff_drop(v_b_2492);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_243, v_x_240, 0)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_a_241});
    } else {
      heff_drop(v_a_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2410 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_249));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_242, 0);
    V v_argv_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2417 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_f_2415));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam3, 1, 4, (V[]){v_m_2417, heff_dup(v_x_240), v_a_241, v_argv_2416});
  }
  case TAG_ELet: {
    V v_y_2428 = heff_field(v_e_242, 0);
    V v_e2_2429 = heff_field(v_e_242, 1);
    V v_b_2430 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_e2_2429));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam5, 1, 5, (V[]){v_m_2431, heff_dup(v_x_240), v_a_241, v_b_2430, v_y_2428});
  }
  case TAG_ERecord: {
    V v_fs_2440 = heff_field(v_e_242, 0);
    V v_ts_2441 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2450 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam6, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_fs_2440));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam8, 1, 2, (V[]){v_m_2450, v_ts_2441});
  }
  case TAG_EProj: {
    V v_e2_2455 = heff_field(v_e_242, 0);
    V v_l_2456 = heff_field(v_e_242, 1);
    V v_sh_2457 = heff_field(v_e_242, 2);
    V v_t_2458 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_m_2459 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2455));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam9, 1, 4, (V[]){v_m_2459, v_l_2456, v_sh_2457, v_t_2458});
  }
  case TAG_ETag: {
    V v_t_2464 = heff_field(v_e_242, 0);
    V v_argv_2465 = heff_field(v_e_242, 1);
    V v_ts_2466 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2468 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_argv_2465));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam11, 1, 3, (V[]){v_m_2468, v_t_2464, v_ts_2466});
  }
  case TAG_EMatch: {
    V v_s_2473 = heff_field(v_e_242, 0);
    V v_arms_2474 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2475 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_s_2473));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam12, 1, 4, (V[]){v_m_2475, heff_dup(v_x_240), v_a_241, v_arms_2474});
  }
  case TAG_EPrim: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam15, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2495 = heff_field(v_e_242, 0);
    V v_argv_2496 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2498 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam16, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_argv_2496));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_m_2498, v_p_2495});
  }
  case TAG_ECall: {
    V v_g_24103 = heff_field(v_e_242, 0);
    V v_argv_24104 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24106 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_argv_24104));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_m_24106, v_g_24103});
  }
  case TAG_EInt: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam20, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EBytes: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam26, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam27, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esubstCopies(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_245});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_248, v_x_2413}), v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_q_2422 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2422; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_argv_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_m_2423 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam4, 1, 2, (V[]){v_x_240, v_a_241}), v_argv_2416));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2421}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      V v_x_2427 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2420, v_x_2425));
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2430 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_2430; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2428, v_x_2434, v_x_2438}), v_s_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2443, v_x_2448}), v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_p_2442 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_l_2443 = heff_field(v_p_2442, 0);
    V v_e_2444 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 3ULL, 2);
    V v_m_2445 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_e_2444; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_m_2445, v_l_2443});
  }
  default: return heff_nomatch(v_p_2442);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_ts_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2453, v_ts_2441}), v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_l_2456 = heff_env(self)[1];
  V v_sh_2457 = heff_env(self)[2];
  V v_t_2458 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2461 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2462, v_l_2456, v_sh_2457, v_t_2458}), v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_q_2467 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2467; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_s_2469 = args[0];
  V v_m_2468 = heff_env(self)[0];
  V v_t_2464 = heff_env(self)[1];
  V v_ts_2466 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2470 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_s_2469}));
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkPair: {
    V v_x_2471 = heff_field(v_x2_2470, 0);
    V v_s_2472 = heff_field(v_x2_2470, 1);
    V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2464, v_x_2471, v_ts_2466}), v_s_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_s_2485 = args[0];
  V v_m_2484 = heff_env(self)[0];
  V v_t_2481 = heff_env(self)[1];
  V v_vs_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2486 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_s_2485}));
  switch (heff_tag_of(v_x2_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_field(v_x2_2486, 0);
    V v_s_2488 = heff_field(v_x2_2486, 1);
    V v_ru_24x2_2486_24MkPair = heff_take_reuse_n(v_x2_2486, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2481, v_vs_2482, v_x_2487}), v_s_2488});
  }
  default: return heff_nomatch(v_x2_2486);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_a_2480 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2480)) {
  case TAG_MkArm: {
    V v_t_2481 = heff_field(v_a_2480, 0);
    V v_vs_2482 = heff_field(v_a_2480, 1);
    V v_b_2483 = heff_field(v_a_2480, 2);
    heff_take_n(v_a_2480, 7ULL, 3);
    V v_m_2484 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_2483; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam14, 1, 3, (V[]){v_m_2484, v_t_2481, v_vs_2482});
  }
  default: return heff_nomatch(v_a_2480);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2474 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2477 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    V v_m_2489 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam13, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2474));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2479}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2478, v_x_2491}), v_s_2492});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2494 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_2494});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_q_2497 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2497; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_s_2499 = args[0];
  V v_m_2498 = heff_env(self)[0];
  V v_p_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24100 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_s_2499}));
  switch (heff_tag_of(v_x2_24100)) {
  case TAG_MkPair: {
    V v_x_24101 = heff_field(v_x2_24100, 0);
    V v_s_24102 = heff_field(v_x2_24100, 1);
    V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2495, v_x_24101}), v_s_24102});
  }
  default: return heff_nomatch(v_x2_24100);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_q_24105 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_24105; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_g_24103 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24103, v_x_24109}), v_s_24110});
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24112 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24112});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24114 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24114});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24116 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24116});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24118 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24118});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24121 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24121});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24123 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args) {
  V v_s_24124 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24124});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args) {
  V v_s_24127 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24127});
}
Clo g_heff_2ecompile_2esimplify_2eletSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletSplit(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2421 = heff_field(v_a_242, 0);
    V v_argv_2422 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EApp = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_x2_2423 = heff_tr(g_heff_2ecompile_2esimplify_2esplitArgs(v_argv_2422, v_z_244));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2427 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), v_t_2426));
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2429 = (g_heff_2ecompile_2eir_2elamW(v_x_241, v_t_2428));
      V v_t_2430 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2427, v_t_2429}), 0, 2);
      V v_t_2431 = heff_tag_at_n(v_ru_24a_242_24EApp, TAG_EApp, 2, (V[]){v_f_2421, heff_dup(heff_rfield(v_x_2424, 1))});
      V v_x2_2432 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_t_2431, v_b_243, v_t_2430, v_s_2425));
      switch (heff_tag_of(v_x2_2432)) {
      case TAG_MkPair: {
        V v_x_2433 = heff_field(v_x2_2432, 0);
        V v_s_2434 = heff_field(v_x2_2432, 1);
        heff_take_n(v_x2_2432, 3ULL, 2);
        V v_x_2435 = ({ V b_0 = heff_get_n(v_x_2424, 0, 2); V a_1 = v_x_2433; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(b_0, a_1)); heff_drop(b_0); r_; });
        return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_s_2434});
      }
      default: return heff_nomatch(v_x2_2432);
      }
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  case TAG_ELet: {
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_s_2442 = heff_field(v_x2_2440, 1);
      V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2441}), v_s_2442});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  case TAG_ERecord: {
    V v_m_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_MkPair: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_s_2448 = heff_field(v_x2_2446, 1);
      V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2447}), v_s_2448});
    }
    default: return heff_nomatch(v_x2_2446);
    }
  }
  case TAG_EProj: {
    V v_m_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_MkPair: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_s_2456 = heff_field(v_x2_2454, 1);
      V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2455}), v_s_2456});
    }
    default: return heff_nomatch(v_x2_2454);
    }
  }
  case TAG_ETag: {
    V v_m_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_s_2463 = heff_field(v_x2_2461, 1);
      V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2462}), v_s_2463});
    }
    default: return heff_nomatch(v_x2_2461);
    }
  }
  case TAG_EMatch: {
    V v_m_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2467 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2467)) {
    case TAG_MkPair: {
      V v_x_2468 = heff_field(v_x2_2467, 0);
      V v_s_2469 = heff_field(v_x2_2467, 1);
      V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2468}), v_s_2469});
    }
    default: return heff_nomatch(v_x2_2467);
    }
  }
  case TAG_EPrim: {
    V v_m_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2472 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2472)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_x2_2472, 0);
      V v_s_2474 = heff_field(v_x2_2472, 1);
      V v_ru_24x2_2472_24MkPair = heff_take_reuse_n(v_x2_2472, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2473}), v_s_2474});
    }
    default: return heff_nomatch(v_x2_2472);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_s_2480 = heff_field(v_x2_2478, 1);
      V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2479}), v_s_2480});
    }
    default: return heff_nomatch(v_x2_2478);
    }
  }
  case TAG_ECall: {
    V v_m_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2484 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_MkPair: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_s_2486 = heff_field(v_x2_2484, 1);
      V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2485}), v_s_2486});
    }
    default: return heff_nomatch(v_x2_2484);
    }
  }
  case TAG_EInt: {
    V v_m_2488 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2490}), v_s_2491});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  case TAG_EFloat: {
    V v_m_2493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2494 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2494)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_field(v_x2_2494, 0);
      V v_s_2496 = heff_field(v_x2_2494, 1);
      V v_ru_24x2_2494_24MkPair = heff_take_reuse_n(v_x2_2494, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2495}), v_s_2496});
    }
    default: return heff_nomatch(v_x2_2494);
    }
  }
  case TAG_EStr: {
    V v_m_2498 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2499)) {
    case TAG_MkPair: {
      V v_x_24100 = heff_field(v_x2_2499, 0);
      V v_s_24101 = heff_field(v_x2_2499, 1);
      V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24100}), v_s_24101});
    }
    default: return heff_nomatch(v_x2_2499);
    }
  }
  case TAG_EBytes: {
    V v_m_24103 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24104 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24104)) {
    case TAG_MkPair: {
      V v_x_24105 = heff_field(v_x2_24104, 0);
      V v_s_24106 = heff_field(v_x2_24104, 1);
      V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24105}), v_s_24106});
    }
    default: return heff_nomatch(v_x2_24104);
    }
  }
  case TAG_EFixed: {
    V v_m_24109 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24110)) {
    case TAG_MkPair: {
      V v_x_24111 = heff_field(v_x2_24110, 0);
      V v_s_24112 = heff_field(v_x2_24110, 1);
      V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24111}), v_s_24112});
    }
    default: return heff_nomatch(v_x2_24110);
    }
  }
  case TAG_EFloat32: {
    V v_m_24114 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_s_24117 = heff_field(v_x2_24115, 1);
      V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24116}), v_s_24117});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  case TAG_EAbandon: {
    V v_m_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_MkPair: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_s_24121 = heff_field(v_x2_24119, 1);
      V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24120}), v_s_24121});
    }
    default: return heff_nomatch(v_x2_24119);
    }
  }
  case TAG_EFix: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      V v_ru_24x2_24125_24MkPair = heff_take_reuse_n(v_x2_24125, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24126}), v_s_24127});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletSplit(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2earmOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earmOver_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2earmOver(V v_budget_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_ts_243 = heff_field(v_x2_241, 0);
    V v_n_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x3_242, 0);
      V v_b_247 = heff_field(v_x3_242, 2);
      V v_t_248 = (g_list_2efoldl_24f226312210x181720981(MK_INT(1LL), MK_INT(0LL), v_t_245, v_ts_243));
      V v_x_249 = heff_intAdd(v_t_248, heff_dup(v_n_244));
      V v_ret_24bool = heff_bool((heff_intLt_c_lent(MK_INT(1LL), v_x_249, 1) && ({ V v_t_2411 = (g_list_2efoldl_24f226312210x181720981(MK_INT(1LL), MK_INT(0LL), v_t_245, v_ts_243)); int c_ = ({ V v_t_2412 = heff_intSub(heff_intAdd(heff_dup(v_t_2411), heff_dup(v_n_244)), MK_INT(1LL)); int c_ = ({ V v_lim_2413 = heff_intDiv(heff_dup(v_budget_240), heff_dup(v_t_2412)); int c_ = ({ V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2415 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2413), MK_INT(0LL), heff_dup(v_t_2414))); int c_ = heff_intLt_c_lent(v_lim_2413, v_x_2415, 0); heff_drop(v_x_2415); c_; }); heff_drop(v_t_2414); c_; }); heff_drop(v_lim_2413); c_; }); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; })));
      heff_drop(v_budget_240);
      heff_drop(v_ts_243);
      heff_drop(v_n_244);
      heff_drop(v_x_249);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2earmOver_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2earmOver(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam20(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esumPushed_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumPushed_lam20, 1, 0};
V g_heff_2ecompile_2esimplify_2esumPushed_lam21(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esumPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumPushed_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esumPushed(V v_r_240, V v_x_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam0, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam1, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ELam: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam2, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EApp: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam3, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ELet: {
    V v_y_2434 = heff_field(v_x4_243, 0);
    V v_a_2435 = heff_field(v_x4_243, 1);
    V v_c_2436 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_m_2437 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_c_2436));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam4, 1, 3, (V[]){v_m_2437, v_y_2434, v_a_2435});
  }
  case TAG_ERecord: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam5, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EProj: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam6, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ETag: {
    V v_t_2460 = heff_field(v_x4_243, 0);
    V v_es_2461 = heff_field(v_x4_243, 1);
    V v_ts_2462 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam7, 1, 6, (V[]){v_es_2461, v_b_242, v_x_241, v_t_2460, v_ts_2462, v_r_240});
  }
  case TAG_EMatch: {
    V v_s_2484 = heff_field(v_x4_243, 0);
    V v_arms_2485 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_m_2495 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam8, 1, 3, (V[]){v_r_240, v_x_241, v_b_242}), v_arms_2485));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam10, 1, 2, (V[]){v_m_2495, v_s_2484});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam11, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EPrimCall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam12, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_ECall: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam13, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam14, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam15, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam16, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam17, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam18, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam19, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return ((V)&g_heff_2ecompile_2esimplify_2esumPushed_lam20_clo);
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam21, 1, 4, (V[]){v_b_242, v_r_240, v_x_241, v_x4_243});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esumPushed(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_s_2410 = v_field_248;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_249});
    heff_room[1] = v_s_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2412));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_x_2416 = v_field_2414;
    V v_s_2417 = v_field_2415;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2416});
    heff_room[1] = v_s_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2421 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2420));
  {
    V v_field_2422 = v_t_2421.f[0];
    V v_field_2423 = v_t_2421.f[1];
    V v_x_2424 = v_field_2422;
    V v_s_2425 = v_field_2423;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2424});
    heff_room[1] = v_s_2425;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam3(V self, V *args) {
  V v_s_2428 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2429 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2428));
  {
    V v_field_2430 = v_t_2429.f[0];
    V v_field_2431 = v_t_2429.f[1];
    V v_x_2432 = v_field_2430;
    V v_s_2433 = v_field_2431;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2432});
    heff_room[1] = v_s_2433;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam4(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_y_2434 = heff_env(self)[1];
  V v_a_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2434, v_a_2435, v_x_2440}), v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam5(V self, V *args) {
  V v_s_2444 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2445 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2444));
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_x_2448 = v_field_2446;
    V v_s_2449 = v_field_2447;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2448});
    heff_room[1] = v_s_2449;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam6(V self, V *args) {
  V v_s_2454 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2455 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2454));
  {
    V v_field_2456 = v_t_2455.f[0];
    V v_field_2457 = v_t_2455.f[1];
    V v_x_2458 = v_field_2456;
    V v_s_2459 = v_field_2457;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_2458});
    heff_room[1] = v_s_2459;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam7(V self, V *args) {
  V v_s_2463 = args[0];
  V v_es_2461 = heff_env(self)[0];
  V v_b_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_t_2460 = heff_env(self)[3];
  V v_ts_2462 = heff_env(self)[4];
  V v_r_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2464 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_es_2461, v_s_2463));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    HeffT2 v_t_2467 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_2466));
    {
      V v_field_2468 = v_t_2467.f[0];
      V v_field_2469 = v_t_2467.f[1];
      V v_x_2470 = v_field_2468;
      V v_s_2471 = v_field_2469;
      V v_t_2474;
      switch (heff_tag_of(v_x_2465)) {
      case TAG_MkPair: {
        V v_y_2473 = heff_dup(heff_field(v_x_2465, 1));
        v_t_2474 = v_y_2473;
        break;
      }
      default: heff_nomatch(v_x_2465);
      }
      V v_t_2475 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2460, v_t_2474, v_ts_2462}), v_x_2470});
      V v_m_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2475}));
      V v_x2_2477 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2471}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        V v_t_2482;
        switch (heff_tag_of(v_x_2465)) {
        case TAG_MkPair: {
          V v_x_2480 = heff_field(v_x_2465, 0);
          heff_take_n(v_x_2465, 1ULL, 2);
          v_t_2482 = v_x_2480;
          break;
        }
        default: heff_nomatch(v_x_2465);
        }
        V v_x_2483 = ({ V a_0 = v_t_2482; V a_1 = v_x_2478; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2482); r_; });
        return heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){v_x_2483, v_s_2479});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam9(V self, V *args) {
  V v_s_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_t_2487 = heff_env(self)[1];
  V v_vs_2488 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_s_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_s_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2487, v_vs_2488, v_x_2493}), v_s_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam8(V self, V *args) {
  V v_a_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_2486)) {
  case TAG_MkArm: {
    V v_t_2487 = heff_field(v_a_2486, 0);
    V v_vs_2488 = heff_field(v_a_2486, 1);
    V v_b_2489 = heff_field(v_a_2486, 2);
    heff_take_n(v_a_2486, 7ULL, 3);
    V v_m_2490 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_b_2489));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam9, 1, 3, (V[]){v_m_2490, v_t_2487, v_vs_2488});
  }
  default: return heff_nomatch(v_a_2486);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam10(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_s_2484 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2484, v_x_2498}), v_s_2499});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam11(V self, V *args) {
  V v_s_24101 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24102 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24101));
  {
    V v_field_24103 = v_t_24102.f[0];
    V v_field_24104 = v_t_24102.f[1];
    V v_x_24105 = v_field_24103;
    V v_s_24106 = v_field_24104;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24105});
    heff_room[1] = v_s_24106;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam12(V self, V *args) {
  V v_s_24109 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24110 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24109));
  {
    V v_field_24111 = v_t_24110.f[0];
    V v_field_24112 = v_t_24110.f[1];
    V v_x_24113 = v_field_24111;
    V v_s_24114 = v_field_24112;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24113});
    heff_room[1] = v_s_24114;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam13(V self, V *args) {
  V v_s_24117 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24118 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24117));
  {
    V v_field_24119 = v_t_24118.f[0];
    V v_field_24120 = v_t_24118.f[1];
    V v_x_24121 = v_field_24119;
    V v_s_24122 = v_field_24120;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24121});
    heff_room[1] = v_s_24122;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam14(V self, V *args) {
  V v_s_24124 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24125 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24124));
  {
    V v_field_24126 = v_t_24125.f[0];
    V v_field_24127 = v_t_24125.f[1];
    V v_x_24128 = v_field_24126;
    V v_s_24129 = v_field_24127;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24128});
    heff_room[1] = v_s_24129;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam15(V self, V *args) {
  V v_s_24131 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24132 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24131));
  {
    V v_field_24133 = v_t_24132.f[0];
    V v_field_24134 = v_t_24132.f[1];
    V v_x_24135 = v_field_24133;
    V v_s_24136 = v_field_24134;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24135});
    heff_room[1] = v_s_24136;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam16(V self, V *args) {
  V v_s_24138 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24139 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24138));
  {
    V v_field_24140 = v_t_24139.f[0];
    V v_field_24141 = v_t_24139.f[1];
    V v_x_24142 = v_field_24140;
    V v_s_24143 = v_field_24141;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24142});
    heff_room[1] = v_s_24143;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam17(V self, V *args) {
  V v_s_24145 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24146 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24145));
  {
    V v_field_24147 = v_t_24146.f[0];
    V v_field_24148 = v_t_24146.f[1];
    V v_x_24149 = v_field_24147;
    V v_s_24150 = v_field_24148;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24149});
    heff_room[1] = v_s_24150;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam18(V self, V *args) {
  V v_s_24153 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24154 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24153));
  {
    V v_field_24155 = v_t_24154.f[0];
    V v_field_24156 = v_t_24154.f[1];
    V v_x_24157 = v_field_24155;
    V v_s_24158 = v_field_24156;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24157});
    heff_room[1] = v_s_24158;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam19(V self, V *args) {
  V v_s_24160 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24161 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24160));
  {
    V v_field_24162 = v_t_24161.f[0];
    V v_field_24163 = v_t_24161.f[1];
    V v_x_24164 = v_field_24162;
    V v_s_24165 = v_field_24163;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24164});
    heff_room[1] = v_s_24165;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam20(V self, V *args) {
  V v_s_24166 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_s_24166});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam21(V self, V *args) {
  V v_s_24169 = args[0];
  V v_b_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_x4_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_24170 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_s_24169));
  {
    V v_field_24171 = v_t_24170.f[0];
    V v_field_24172 = v_t_24170.f[1];
    V v_x_24173 = v_field_24171;
    V v_s_24174 = v_field_24172;
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x4_243, v_x_24173});
    heff_room[1] = v_s_24174;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedPast_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ehandedPast(V v_kinds_240, V v_b_241, V v_argv_242) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_b_241, 0);
    V v_x_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    if (heff_intLt_c(v_y_248, v_x_247)) {
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_2411 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2410, v_argv_242));
      return ({ V a_0 = v_kinds_240; V a_1 = v_t_2411; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2411); r_; });
    } else {
      heff_drop(v_argv_242);
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_argv_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ehandedPast(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_f_245;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 6), v_k_240, v_p_241));
    v_f_245 = ({ V rv_6 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 447ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_f_245 = v_s_242;
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_245}});
}
Clo g_heff_2ecompile_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknownArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_245 = ({ V a_0 = v_kinds_240; V a_1 = v_g_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_g_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_247); int c_ = 1; heff_drop(v_x_249); c_; })));
      heff_drop(v_field_247);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    V v_t_2412 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EApp: {
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2415);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2415);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ELet: {
    V v_t_2419 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 3);
      heff_drop(v_t_2419);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2419);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ERecord: {
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2422);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2422);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EProj: {
    V v_t_2427 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 4);
      heff_drop(v_t_2427);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2427);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ETag: {
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 3);
      heff_drop(v_t_2431);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2431);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EMatch: {
    V v_t_2434 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2434);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2434);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EPrim: {
    V v_t_2436 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2436);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2436);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EPrimCall: {
    V v_t_2439 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2439);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2439);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_ECall: {
    V v_t_2442 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2442);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2442);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EInt: {
    V v_t_2444 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2444);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2444);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFloat: {
    V v_t_2446 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2446);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2446);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EStr: {
    V v_t_2448 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2448);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2448);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EBytes: {
    V v_t_2450 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2450);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2450);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFixed: {
    V v_t_2453 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2453);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2453);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFloat32: {
    V v_t_2455 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 1);
      heff_drop(v_t_2455);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2455);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EAbandon: {
    V v_t_2456 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
      heff_drop(v_t_2456);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2456);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  case TAG_EFix: {
    V v_t_2459 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_241)));
    if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_241, 2);
      heff_drop(v_t_2459);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2459);
      return (g_heff_2ecompile_2esimplify_2ehandlerLike(v_e_241));
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eknownArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_241, 0);
      V v_xs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2ekeepParams_24dps(v_ms_243, v_xs_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_x_245 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_244));
  V v_t_248;
  if (heff_intLt_c(MK_INT(1200LL), v_x_245)) {
    v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  } else {
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
    v_t_248 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_247, heff_dup(v_h_240), heff_dup(v_b0_241)));
  }
  V v_t_2443;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2443 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2443 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2445;
  if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
    heff_drop(v_t_2443);
    V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    v_t_2445 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_2444, heff_dup(v_h_240), NTAG(TAG_MkUnit)));
  } else {
    heff_drop(v_t_2443);
    v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
  }
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 2, 7);
  V v_t_2447 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_2446, heff_dup(v_h_240), v_b0_241));
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 3, 7);
  V v_t_2449 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_2448, v_h_240, v_d_242));
  V v_t_2450 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 4, 7);
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 5, 7);
  V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 6, 7);
  V v_p_2453 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_248, v_t_2445, v_t_2447, v_t_2449, v_t_2450, heff_intAdd(v_t_2451, MK_INT(1LL)), v_t_2452});
  V v_f_2454 = ({ V rv_7 = v_p_2453; V rr_ = heff_rec_reuse_nf(v_s_243, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2454}});
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBody_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_sh_243, V v_lam1_244) {
top: ;
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_249 = heff_field(v_lam1_244, 0);
    V v_b1_2410 = heff_field(v_lam1_244, 1);
    heff_take_n(v_lam1_244, 3ULL, 2);
    V v_t_2411 = (g_list_2emap_24s1809017761x1063871171(heff_dup(heff_rfield(v_sh_243, 1))));
    V v_t_2412 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_t_2411, heff_dup(v_marks_242), v_b1_2410));
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2esubstMarked(heff_dup(v_marks_242), heff_dup(v_xs1_249), heff_rfield(v_sh_243, 0), v_t_2412));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam2, 1, 4, (V[]){v_m_2413, v_marks_242, v_xs1_249, v_sh_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam17, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam18, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam19, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_246});
}
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_249 = heff_env(self)[2];
  V v_sh_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_249)));
    V v_x1_2419 = (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(heff_rfield(v_sh_243, 1)), v_t_2418));
    V v_x_2424;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_249);
      heff_drop_rec(v_sh_243, 3);
      v_x_2424 = v_x_2416;
      break;
    }
    case TAG_Cons: {
      V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 0ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2ekeepParams(v_marks_242, v_xs1_249));
      V v_t_2423 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_243, 1, 3), v_t_2422));
      v_x_2424 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_ELam, 2, (V[]){v_t_2423, v_x_2416});
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2434});
}
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2439 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2439});
}
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2443});
}
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2446 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2446});
}
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2448 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2448});
}
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2451 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2451});
}
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2454 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2456 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2456});
}
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2458 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2458});
}
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2460 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2460});
}
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2462 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2462});
}
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2465 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2465});
}
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args) {
  V v_s_2467 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args) {
  V v_s_2468 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2468});
}
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args) {
  V v_s_2471 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2471});
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_argv_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_argv_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ms_244;
        V t_1 = v_argv_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V v_s_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 1, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 3, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 4, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 6, 7);
  V v_f_247 = ({ V rv_1 = MK_INT(4000LL); V rv_6 = heff_dup(g_std_2emap_2eempty_get()); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, MK_INT(0LL), v_t_246}); V rr_ = heff_rec_reuse_nf(v_s_240, 317ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 200691u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_247}});
}

HeffT2 g_heff_2ecompile_2esimplify_2esetOff_24cpr(V v_o_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_f_248 = ({ V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_o_240}); V rr_ = heff_rec_reuse_nf(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_248}});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str1, 0, "");
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyVer_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecopyVer(V v_vers_240, V v_h_241, V v_g_242, V v_args_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
  V v_t_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopyVer_lam0, 1, 1, (V[]){heff_dup(v_vers_240)}), heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, v_t_245})));
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2eversAll_24cpr(v_t_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_vs_2412 = v_field_2410;
      V v_t_2413 = (g_list_2emap_24s1123370502x1982532655(v_vs_2412));
      V v_items_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_h_241}), v_t_2413});
      HeffT2 v_t_2415 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2414));
      {
        V v_field_2416 = v_t_2415.f[0];
        V v_field_2417 = v_t_2415.f[1];
        V v_a_2418 = v_field_2416;
        V v_b_2419 = v_field_2417;
        V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str0), heff_intShow(v_b_2419));
        return heff_strAppend(heff_intShow(v_a_2418), v_t_2420);
      }
    } else {
      heff_drop(v_h_241);
      heff_drop(v_field_2410);
      return ((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str1);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyVer(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_vers_240; V a_1 = v_k_246; V r_ = (g_std_2emap_2elookup_24s1963842891x1660122411(a_0, a_1)); heff_drop(v_vers_240); heff_drop(v_k_246); r_; });
}

HeffT2 g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(V v_x1_240, V v_h_241, V v_p_242) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_243 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_p_242, 4), heff_dup(v_h_241), NTAG(TAG_MkUnit)));
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_p_242, 3), v_h_241, NTAG(TAG_MkUnit)));
    V v_f_245 = ({ V rv_3 = v_t_244; V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_242, 487ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_245}});
  } else {
    heff_drop(v_h_241);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_242}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2ekeptAsk_24cpr(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_h_240);
      heff_drop(v_v_241);
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      return ((HeffT2){{NTAG(TAG_True), v_s_242}});
    } else {
      heff_drop(v_field_246);
      V v_k_249 = heff_take_field(v_s_242, 8);
      V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_k_249, 0), heff_dup(v_h_240), v_v_241));
      V v_k_2411 = ({ V rv_0 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_k_249, 30ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2412 = ({ V rv_8 = v_k_2411; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2ekeptAt_24cpr(heff_dup(v_t_2412), v_h_240));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_kc_2417 = v_field_2415;
          V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2417, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
          return ({ V a_0 = v_h_240; V a_1 = v_kc_2417; V a_2 = v_t_2418; V a_3 = v_t_2412; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2easkKept_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
        } else {
          heff_drop(v_h_240);
          heff_drop(v_field_2415);
          return ((HeffT2){{NTAG(TAG_False), v_t_2412}});
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2emissingOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emissingOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emissingOf(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    V v_e1_246 = heff_field(v_e_241, 0);
    V v_bs_247 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_e1_246, 0);
      V v_all_2410 = heff_get_n(v_s_240, 2, 9);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_2410, v_h_249));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2414 = ({ V a_0 = v_all_2410; V a_1 = v_h_249; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_2410); r_; });
        V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
        return heff_intSub(v_t_2414, v_t_2415);
      } else {
        heff_drop(v_all_2410);
        return MK_INT(0LL);
      }
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_e1_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emissingOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandlerPushed_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ehandlerPushed(V v_arms_240, V v_argv_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s1531069132x955165792(heff_dup(v_argv_241)));
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_242); r_; });
  V v_ret_24bool = heff_bool(((heff_dup(v_t_243) == NTAG(TAG_True)) && ({ V v_t_244 = (g_list_2eany_24s860380051x1466609135(v_argv_241)); int c_ = ((heff_dup(v_t_244) == NTAG(TAG_True)) && ({ V v_argv_245 = (g_list_2efilter_24s1328865458x1020778875(heff_dup(v_argv_241))); int c_ = ({ V v_t_246 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_245))); int c_ = ({ V v_t_247 = (g_heff_2ecompile_2eir_2eallI(v_t_246)); int c_ = ((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = (g_list_2efoldl_24s688118489x1560799399(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_245))); int c_ = ({ V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_240)); int c_ = ({ V v_t_2410 = heff_intMul(heff_dup(v_t_248), heff_intSub(heff_dup(v_t_249), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2410, MK_INT(120LL), 2); heff_drop(v_t_2410); c_; }); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; })); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; }); heff_drop(v_argv_245); c_; })); heff_drop(v_t_244); c_; })));
  heff_drop(v_argv_241);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ehandlerPushed(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam18(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2454 = heff_field(v_s_241, 0);
    V v_a_2455 = heff_field(v_s_241, 1);
    V v_b_2456 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_2456, v_arms_242}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam4, 1, 3, (V[]){v_m_2457, v_x_2454, v_a_2455});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2470 = heff_dup(heff_field(v_s_241, 0));
    V v_argv_2471 = heff_dup(heff_field(v_s_241, 1));
    HeffT2 v_t_2473 = ({ V a_0 = v_t_2470; V a_1 = heff_dup(v_arms_242); HeffT2 r_ = (g_heff_2ecompile_2esimplify_2efindArm_24cpr(a_0, a_1)); heff_drop(v_t_2470); r_; });
    {
      V v_field_2475 = v_t_2473.f[1];
      int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
      if ((v_tag_2474 == ((int64_t)0ULL))) {
        heff_drop_tag(v_s_241, 3);
        heff_drop(v_arms_242);
        V v_it1_2477 = v_field_2475;
        switch (heff_tag_of(v_it1_2477)) {
        case TAG_MkArm: {
          V v_vs_2479 = heff_field(v_it1_2477, 1);
          V v_b_2480 = heff_field(v_it1_2477, 2);
          heff_take_n(v_it1_2477, 6ULL, 3);
          V v_t_2481 = (g_heff_2ecompile_2esimplify_2ezipL(v_vs_2479, v_argv_2471));
          V v_t_2482 = ({ V a_0 = v_t_2481; V a_1 = v_b_2480; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2481); r_; });
          return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2482});
        }
        default: return heff_nomatch(v_it1_2477);
        }
      } else {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_argv_2471);
        heff_drop(v_field_2475);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
      }
    }
  }
  case TAG_EMatch: {
    V v_s2_2484 = heff_field(v_s_241, 0);
    V v_arms2_2485 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ecaseOfCase(v_r_240, v_s2_2484, v_arms2_2485, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam16, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam17, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam18, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = ({ V a_0 = heff_rfield(v_s_246, 2); V a_1 = v_g_245; V r_ = (g_std_2emap_2elookup_24s1963842891x1660122411(a_0, a_1)); heff_drop(v_g_245); r_; });
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_247, v_s_246));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_s_2412 = v_field_2410;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
    }
    case TAG_Just: {
      V v_it1_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ELam: {
        V v_ru_24it1_2413_24ELam = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EApp: {
        V v_ru_24it1_2413_24EApp = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2413, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ERecord: {
        V v_ru_24it1_2413_24ERecord = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24ERecord, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2413, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ETag: {
        V v_t2_2429 = heff_field(v_it1_2413, 0);
        V v_as2_2430 = heff_field(v_it1_2413, 1);
        V v_ts2_2431 = heff_field(v_it1_2413, 2);
        heff_take_n(v_it1_2413, 7ULL, 3);
        heff_drop_tag(v_s_241, 1);
        V f_ = heff_get_n(v_r_240, 3, 4);
        heff_room[0] = heff_tag_n(TAG_ETag, 3, (V[]){v_t2_2429, v_as2_2430, v_ts2_2431});
        heff_room[1] = v_arms_242;
        heff_room[2] = v_s_2412;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      case TAG_EMatch: {
        V v_ru_24it1_2413_24EMatch = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_2413_24EMatch, TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EPrimCall: {
        V v_ru_24it1_2413_24EPrimCall = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ECall: {
        V v_ru_24it1_2413_24ECall = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFixed: {
        V v_ru_24it1_2413_24EFixed = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EFixed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFix: {
        V v_ru_24it1_2413_24EFix = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EFix, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      default: return heff_nomatch(v_it1_2413);
      }
    }
    default: return heff_nomatch(v_x_2411);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args) {
  V v_s_2450 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2450});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args) {
  V v_s_2453 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2453});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_x_2454 = heff_env(self)[1];
  V v_a_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2454, v_a_2455, v_x_2460}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args) {
  V v_s_2464 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2464});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args) {
  V v_s_2469 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2469});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args) {
  V v_s_2483 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2483});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args) {
  V v_s_2487 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2487});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args) {
  V v_s_2490 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2490});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args) {
  V v_s_2493 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2493});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args) {
  V v_s_2495 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2495});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args) {
  V v_s_2497 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2497});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args) {
  V v_s_2499 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2499});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args) {
  V v_s_24101 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24101});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args) {
  V v_s_24104 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24104});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args) {
  V v_s_24106 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24106});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args) {
  V v_s_24107 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24107});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam18(V self, V *args) {
  V v_s_24110 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24110});
}
V g_heff_2ecompile_2esimplify_2erefsTouched_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsTouched_24cpr(V v_b_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_240));
  V v_hs_243 = (g_heff_2ecompile_2eir_2enubI(v_t_242));
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 8)), 2, 5);
  V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsTouched_24cpr_lam0, 2, 1, (V[]){heff_dup(v_s_241)}); V a_1 = v_t_244; V a_2 = v_hs_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_243); r_; });
  V v_k_2414 = heff_take_field(v_s_241, 8);
  V v_t_2415 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_k_2414, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_f_2416 = ({ V rv_8 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_241, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2416}});
}
V g_heff_2ecompile_2esimplify_2erefsTouched_24cpr_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_h_246 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_get_n(heff_get_n(v_s_241, 7, 9), 2, 7);
  HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_h_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2410;
      heff_drop(v_x_2412);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_246, v_acc_245});
    } else {
      heff_drop(v_h_246);
      heff_drop(v_field_2410);
      return v_acc_245;
    }
  }
}
V g_heff_2ecompile_2esimplify_2erefsRetied_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsRetied_24cpr(V v_k_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 4, 5);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_k_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_f_2423;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_t_248 = v_field_246;
      V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_241));
      V v_hs_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
      V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsRetied_24cpr_lam0, 2, 1, (V[]){heff_dup(v_s_242)}); V a_1 = v_t_248; V a_2 = v_hs_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_2410); r_; });
      V v_k_2420 = heff_take_field(v_s_242, 8);
      V v_t_2421 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_k_2420, 4), v_k_240, v_t_2419));
      V v_k_2422 = ({ V rv_4 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_k_2420, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      v_f_2423 = ({ V rv_8 = v_k_2422; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    } else {
      heff_drop(v_k_240);
      heff_drop(v_b_241);
      heff_drop(v_field_246);
      v_f_2423 = v_s_242;
    }
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2423}});
}
V g_heff_2ecompile_2esimplify_2erefsRetied_24cpr_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_h_2412 = args[1];
  V v_s_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_get_n(heff_get_n(v_s_242, 7, 9), 2, 7);
  HeffT2 v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_h_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_t_2413); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      heff_drop(v_x_2418);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2412, v_acc_2411});
    } else {
      heff_drop(v_h_2412);
      heff_drop(v_field_2416);
      return v_acc_2411;
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_x1_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeEach(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2edoneOf_str0, 0, "");
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edoneOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edoneOf_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2edoneOf(V v_s_240, V v_d_241, V v_b_242, V v_t_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_s_240, 3), heff_rfield(v_d_241, 0)));
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    v_t_249 = heff_bool(((v_tag_245 == ((int64_t)0ULL)) && ({ V v_x_248 = heff_dup(v_field_246); int c_ = 1; heff_drop(v_x_248); c_; })));
    heff_drop(v_field_246);
  }
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  V v_t_2411 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2emap_2eempty_get()), v_t_2410));
  V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2edoneOf_lam0, 1, 1, (V[]){v_s_240}), v_t_2411));
  return heff_rec_n(4, shape_key__body__safe__touched, (V[]){heff_get_n(v_d_241, 0, 3), v_b_242, v_t_249, v_t_2420});
}
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edoneOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args) {
  V v_h_2412 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_get_n(heff_get_n(v_s_240, 8, 9), 0, 5);
  HeffT2 v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_h_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_t_2419;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2416);
      v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2edoneOf_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2412, v_t_2419});
}
Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecanonVisit_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecanonVisit(V v_c_240, V v_h_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_c_240, 0), v_h_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_246 = v_field_244;
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_c_240, 1), v_h_241));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_h_241);
          heff_drop_rec(v_d_246, 3);
          V v_x_2411 = v_field_249;
          heff_drop(v_x_2411);
          return v_c_240;
        } else {
          heff_drop(v_field_249);
          V v_t_2412 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_c_240, 1), v_h_241, NTAG(TAG_MkUnit)));
          V v_t_2413 = ({ V rv_1 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_c_240, 5ULL, 3, shape_pool__placed__out, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2414 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_246, 2))));
          V v_t_2415 = (g_heff_2ecompile_2eir_2enubI(v_t_2414));
          V v_c_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2ecanonVisit_clo); V a_1 = v_t_2413; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_246, heff_take_field(v_c_2416, 2)});
          return ({ V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_c_2416, 3ULL, 3, shape_pool__placed__out, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        }
      }
    } else {
      heff_drop(v_h_241);
      heff_drop(v_field_244);
      return v_c_240;
    }
  }
}
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecanonVisit(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2einOrder_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2einOrder_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einOrder_lam2, 1, 0};
V g_heff_2ecompile_2esimplify_2einOrder_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2einOrder_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2einOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einOrder_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2einOrder(V v_b_240, V v_made_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s139856607x1870756346(heff_dup(g_std_2emap_2eempty_get()), v_made_241));
  V v_t_243 = heff_rec_n(3, shape_pool__placed__out, (V[]){v_t_242, heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil)});
  V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_240));
  V v_t_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
  V v_x_246 = ({ V a_0 = v_t_243; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s419339443x1702462498(a_0, a_1)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2ecompile_2esimplify_2einOrder_lam0, 1, 2, (V[]){v_x_246, v_made_241});
}
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einOrder(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2einOrder_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2414});
}
V g_heff_2ecompile_2esimplify_2einOrder_lam1(V self, V *args) {
  V v_d_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_x_246, 1, 3); V a_1 = heff_rfield(v_d_248, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_248, 3);
      V v_x_2413 = v_field_2411;
      heff_drop(v_x_2413);
      return ((V)&g_heff_2ecompile_2esimplify_2einOrder_lam2_clo);
    } else {
      heff_drop(v_field_2411);
      V f_ = ((V)&g_heff_2ecompile_2esimplify_2eunmade_clo);
      args[0] = heff_get_n(v_d_248, 0, 3);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ecompile_2esimplify_2einOrder_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_made_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_m_2415 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2einOrder_lam1, 1, 1, (V[]){heff_dup(v_x_246)}), v_made_241));
  V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 2ULL, 2);
    V v_x_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_246, 2, 3)));
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2esafeAs_24cpr(V v_x1_240, V v_k_241, V v_p_242) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_243 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_p_242, 3), v_k_241, NTAG(TAG_MkUnit)));
    V v_f_244 = ({ V rv_3 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_244}});
  } else {
    heff_drop(v_k_241);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_242}});
  }
}
Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2econcatDefs(a0); heff_drop(a0); return r;
}