// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_IntAdd 18227
#define TAG_IntEq 36665
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMul 30294
#define TAG_IntSub 36050
#define TAG_MkArm 55352
#define TAG_StrAppend 34515
#define TAG_StrEq 12955
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fuel 9649789
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_names 305943394
#define LBL_off 319465
#define LBL_out 319944
#define LBL_placed 961367912
#define LBL_plain 308106724
#define LBL_pool 9942243
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_unrolled 706233391
#define LBL_vars 10107635
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_pool__placed__out[] = {LBL_pool, LBL_placed, LBL_out};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2ehasDefault(V);
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ehasDefault_clo;
V g_heff_2ecompile_2eir_2enamesTag(V, V);
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enamesTag_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esurelyBool(V);
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esurelyBool_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo;
V g_heff_2ecompile_2esimplify_2ecanonVisit(V, V);
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efindField_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efoldCond(V);
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldCond_clo;
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
HeffT4 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
V g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739(V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_clo;
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownCopy_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emarksOf(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarksOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarksOf_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(V, V);
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_clo;
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438(V, V);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eorMarks(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_clo;
V g_heff_2ecompile_2esimplify_2eprunedB(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedB_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor(V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_24dps_clo;
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esharedIn(V, V);
V g_heff_2ecompile_2esimplify_2esharedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esharedIn_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_clo;
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_clo;
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_clo;
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etestsOf(V, V);
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etestsOf_clo;
V g_heff_2ecompile_2esimplify_2eunmade(V, V);
V g_heff_2ecompile_2esimplify_2eunmade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunmade_clo;
V g_heff_2ecompile_2esimplify_2evaluesAt(V, V);
V g_heff_2ecompile_2esimplify_2evaluesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesAt_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
HeffT2 g_heff_2ecompile_2espec_2edictGo_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_list_2eall_24s673599783x290475791(V, V);
V g_list_2eall_24s673599783x290475791_entry(V self, V *a);
extern Clo g_list_2eall_24s673599783x290475791_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1287822497x2111322144(V, V, V);
V g_list_2efoldl_24f1287822497x2111322144_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1287822497x2111322144_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s419339443x1702462498(V, V);
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a);
extern Clo g_list_2efoldl_24s419339443x1702462498_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s88009013x1334911863(V, V);
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s88009013x1334911863_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1531069132x955165792(V);
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s704759456x417074234(V, V, V, V, V);
V g_list_2ezipWith_24s704759456x417074234_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s704759456x417074234_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;

HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V v_e_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_241, 0), v_e_240));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_e_27_245 = v_field_243;
    V v_n_246 = v_field_244;
    V v_f_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_s_241, 1022ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048572u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_e_27_245, v_f_247}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str3, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str7, 5, "False");

HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      V v_b_2454 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      V v_p_2455 = v_p_240;
      V v_a_2456 = v_a_2428;
      V v_b_2457 = v_b_2454;
      switch (heff_tag_of(v_p_2455)) {
      case TAG_IntAdd: {
        V v_f_2458 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EInt, 1, (V[]){heff_intAdd(v_a_2456, v_b_2457)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2458}});
      }
      case TAG_IntSub: {
        V v_f_2459 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EInt, 1, (V[]){heff_intSub(v_a_2456, v_b_2457)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2459}});
      }
      case TAG_IntMul: {
        V v_f_2460 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EInt, 1, (V[]){heff_intMul(v_a_2456, v_b_2457)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2460}});
      }
      case TAG_IntEq: {
        heff_drop_cell(v_ru_24x2_241_24EInt, 1);
        V v_t_2461;
        if (heff_intEq_c(v_a_2456, v_b_2457)) {
          v_t_2461 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str0);
        } else {
          v_t_2461 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str1);
        }
        V v_f_2462 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2461, NTAG(TAG_Nil), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2462}});
      }
      case TAG_IntLt: {
        heff_drop_cell(v_ru_24x2_241_24EInt, 1);
        V v_t_2463;
        if (heff_intLt_c(v_a_2456, v_b_2457)) {
          v_t_2463 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str2);
        } else {
          v_t_2463 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str3);
        }
        V v_f_2464 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2463, NTAG(TAG_Nil), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2464}});
      }
      case TAG_IntLe: {
        heff_drop_cell(v_ru_24x2_241_24EInt, 1);
        V v_t_2465;
        if (heff_intLe_c(v_a_2456, v_b_2457)) {
          v_t_2465 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str4);
        } else {
          v_t_2465 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str5);
        }
        V v_f_2466 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2465, NTAG(TAG_Nil), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2466}});
      }
      default: {
        heff_drop_cell(v_ru_24x2_241_24EInt, 1);
        heff_drop(v_p_2455);
        heff_drop(v_a_2456);
        heff_drop(v_b_2457);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      }
    }
    case TAG_EFloat: {
      heff_take_nf(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    V v_a_2481 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      V v_b_24109 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      switch (heff_tag_of(v_p_240)) {
      case TAG_StrAppend: {
        V v_f_24110 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2481, v_b_24109)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24110}});
      }
      case TAG_StrEq: {
        heff_drop_cell(v_ru_24x2_241_24EStr, 1);
        V v_t_24111;
        if (heff_strEq_c(v_a_2481, v_b_24109)) {
          v_t_24111 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str6);
        } else {
          v_t_24111 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_24cpr_str7);
        }
        V v_f_24112 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_24111, NTAG(TAG_Nil), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24112}});
      }
      default: {
        heff_drop(v_p_240);
        heff_drop(v_a_2481);
        heff_drop_cell(v_ru_24x2_241_24EStr, 1);
        heff_drop(v_b_24109);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      }
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2481);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_243, v_x_240, 0)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_a_241});
    } else {
      heff_drop(v_a_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_242, 0);
    V v_argv_246 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, heff_dup(v_a_241), v_f_245));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam1, 1, 4, (V[]){v_m_247, heff_dup(v_x_240), v_a_241, v_argv_246});
  }
  default: {
    return (g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam3, 2, 2, (V[]){heff_dup(v_x_240), v_a_241}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esubstCopies(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_q_2412 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2412; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_argv_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2413 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam2, 1, 2, (V[]){v_x_240, v_a_241}), v_argv_246));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_s_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_x_2417 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2410, v_x_2415));
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_s_2416});
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_q_2419 = args[1];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  return ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_q_2419; V r_ = (g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str1, 2, "$_");

HeffT4 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2eapartOf_24cpr(v_x_240, v_b_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_ap_246 = v_field_245;
      V v_tags_247 = heff_take_field(v_ap_246, 0);
      V v_names_248 = heff_take_field(v_ap_246, 1);
      V v_body_249 = heff_get_n(v_ap_246, 2, 3);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2evaluesAt_clo), 1, (V[]){v_tags_247}));
      V v_x3_2411 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(v_t_2410, v_a_241));
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        heff_drop(v_x_240);
        heff_drop(v_names_248);
        heff_drop(v_body_249);
        return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x3_2411, 0);
        heff_take_n(v_x3_2411, 1ULL, 1);
        V v_ys_2413 = v_names_248;
        V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2413));
        V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
        V v_f_2416 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str0); V a_1 = v_x_240; V a_2 = ((V)&g_heff_2ecompile_2esimplify_2egivenSet_24cpr_str1); V a_3 = v_ys_2413; V a_4 = v_t_2415; V r_ = (g_list_2ezipWith_24s704759456x417074234(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_f_2417 = v_body_249;
        return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_f_2416, v_x_2412, v_f_2417}});
      }
      default: return ((HeffT4){{heff_nomatch(v_x3_2411)}});
      }
    } else {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_field_245);
      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2etestsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etestsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etestsOf(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    return MK_INT(0LL);
  }
  case TAG_CFalse: {
    return MK_INT(0LL);
  }
  case TAG_CRel: {
    return MK_INT(0LL);
  }
  case TAG_CTest: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_x21_245, 0);
      if (heff_strEq_c_lent(v_x_240, v_y_246, 0)) {
        return MK_INT(1LL);
      } else {
        return MK_INT(0LL);
      }
    }
    case TAG_EGlobal: {
      return MK_INT(0LL);
    }
    case TAG_ELam: {
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  case TAG_CNot: {
    V v_c_2445 = heff_field(v_x2_241, 0);
    V t_0 = v_x_240;
    V t_1 = v_c_2445;
    v_x_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2446 = heff_field(v_x2_241, 0);
    V v_b_2447 = heff_field(v_x2_241, 1);
    V v_c_2448 = heff_field(v_x2_241, 2);
    V v_t_2449 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_a_2446));
    V v_t_2450 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_b_2447));
    V v_t_2451 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_c_2448));
    return heff_intAdd(heff_intAdd(v_t_2449, v_t_2450), v_t_2451);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etestsOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedPast_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ehandedPast(V v_kinds_240, V v_b_241, V v_argv_242) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_b_241, 0);
    V v_x_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    if (heff_intLt_c(v_y_248, v_x_247)) {
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_2410 = (g_list_2edrop(v_t_249, v_argv_242));
      return ({ V a_0 = v_kinds_240; V a_1 = v_t_2410; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2410); r_; });
    } else {
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2ehandedPast(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprunedFor_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprunedFor_24dps(V v_known_240, V v_e_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_known_240;
    V t_1 = v_b_247;
    V t_2 = v_cell_248;
    V t_3 = MK_INT(1LL);
    v_known_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_e_241, 0);
    V v_argv_2411 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_f_2410));
    V v_t_2414 = (g_list_2emap_24tok2(v_ru_24e_241_24EApp, heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam0, 1, 1, (V[]){v_known_240}), v_argv_2411));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2412, v_t_2414}));
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_241, 0);
    V v_a_2416 = heff_field(v_e_241, 1);
    V v_b_2417 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_known_240;
    V t_1 = v_b_2417;
    V t_2 = v_cell_2419;
    V t_3 = MK_INT(2LL);
    v_known_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EProj: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ETag: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EMatch: {
    V v_sc_2430 = heff_field(v_e_241, 0);
    V v_arms_2431 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2496 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam1, 1, 3, (V[]){v_known_240, heff_dup(v_arms_2431), heff_dup(v_sc_2430)}), v_arms_2431));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2430, v_t_2496}));
  }
  case TAG_EPrim: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EPrimCall: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ECall: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EInt: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EStr: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBytes: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFixed: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBool: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ESet: {
    V v_xs_24110 = heff_field(v_e_241, 0);
    V v_a_24111 = heff_field(v_e_241, 1);
    V v_b_24112 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_24113 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_24111));
    V v_cell_24114 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_24110, v_t_24113, heff_hole()});
    V v_u_24115 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_24114));
    heff_drop(v_u_24115);
    V t_0 = v_known_240;
    V t_1 = v_b_24112;
    V t_2 = v_cell_24114;
    V t_3 = MK_INT(2LL);
    v_known_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFix: {
    heff_drop(v_known_240);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprunedFor_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_known_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2esimplify_2eprunedFor(v_known_240, v_a_2413));
}
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_known_240 = heff_env(self)[0];
  V v_arms_2431 = heff_env(self)[1];
  V v_sc_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_go_2433 = ((V)&g_heff_2ecompile_2esimplify_2eprunedFor_clo);
  V v_known_2434 = heff_dup(v_known_240);
  V v_arms_2435 = v_arms_2431;
  V v_x4_2475;
  switch (heff_tag_of(v_sc_2430)) {
  case TAG_EVar: {
    V v_x_2436 = heff_field(v_sc_2430, 0);
    V v_ru_24sc_2430_24EVar = heff_take_reuse_n(v_sc_2430, 1ULL, 1);
    v_x4_2475 = ({ V a_0 = v_ru_24sc_2430_24EVar; V a_1 = v_known_240; V a_2 = v_x_2436; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_known_240); heff_drop(v_x_2436); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_sc_2430, 0ULL, 3);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_sc_2430, 0ULL, 4);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_sc_2430, 0ULL, 3);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_sc_2430, 0ULL, 3);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_sc_2430, 0ULL, 1);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_sc_2430, 0ULL, 2);
    heff_drop(v_known_240);
    v_x4_2475 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_sc_2430);
  }
  V v_x5_2476 = v_a_2432;
  switch (heff_tag_of(v_x4_2475)) {
  case TAG_Nothing: {
    heff_drop(v_arms_2435);
    switch (heff_tag_of(v_x5_2476)) {
    case TAG_MkArm: {
      V v_t2_2477 = heff_field(v_x5_2476, 0);
      V v_vs_2478 = heff_field(v_x5_2476, 1);
      V v_b_2479 = heff_field(v_x5_2476, 2);
      V v_ru_24x5_2476_24MkArm = heff_take_reuse_n(v_x5_2476, 7ULL, 3);
      V v_t_2480 = heff_tr(heff_call(v_go_2433, 2, (V[]){v_known_2434, v_b_2479}));
      return heff_tag_at_n(v_ru_24x5_2476_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2477, v_vs_2478, v_t_2480});
    }
    default: return heff_nomatch(v_x5_2476);
    }
  }
  case TAG_Just: {
    V v_x41_2481 = heff_field(v_x4_2475, 0);
    heff_take_n(v_x4_2475, 1ULL, 1);
    switch (heff_tag_of(v_x41_2481)) {
    case TAG_ETag: {
      V v_t_2482 = heff_field(v_x41_2481, 0);
      V v_argv_2483 = heff_field(v_x41_2481, 1);
      V v_ru_24x41_2481_24ETag = heff_take_reuse_n(v_x41_2481, 3ULL, 3);
      switch (heff_tag_of(v_x5_2476)) {
      case TAG_MkArm: {
        V v_t2_2485 = heff_field(v_x5_2476, 0);
        V v_vs_2486 = heff_field(v_x5_2476, 1);
        V v_b_2487 = heff_field(v_x5_2476, 2);
        heff_take_n(v_x5_2476, 7ULL, 3);
        if (heff_strEq_c_lent(v_t_2482, v_t2_2485, 0)) {
          heff_drop(v_arms_2435);
          heff_drop(v_t_2482);
          V v_t_2488 = ({ V a_0 = v_vs_2486; V a_1 = v_argv_2483; V a_2 = v_known_2434; V r_ = (g_heff_2ecompile_2esimplify_2etagsGiven(a_0, a_1, a_2)); heff_drop(v_argv_2483); r_; });
          V v_t_2489 = heff_tr(heff_call(v_go_2433, 2, (V[]){v_t_2488, v_b_2487}));
          return heff_tag_at_n(v_ru_24x41_2481_24ETag, TAG_MkArm, 3, (V[]){v_t2_2485, v_vs_2486, v_t_2489});
        } else {
          heff_drop(v_argv_2483);
          if (heff_strEq_c(heff_dup(v_t2_2485), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
            V v_x1_2490 = ({ V a_0 = v_t_2482; V a_1 = v_arms_2435; V r_ = (g_heff_2ecompile_2eir_2enamesTag(a_0, a_1)); heff_drop(v_t_2482); heff_drop(v_arms_2435); r_; });
            if (!(heff_dup(v_x1_2490) == NTAG(TAG_True))) {
              heff_drop(v_x1_2490);
              V v_t_2491 = heff_tr(heff_call(v_go_2433, 2, (V[]){v_known_2434, v_b_2487}));
              return heff_tag_at_n(v_ru_24x41_2481_24ETag, TAG_MkArm, 3, (V[]){v_t2_2485, v_vs_2486, v_t_2491});
            } else {
              heff_drop(v_go_2433);
              heff_drop(v_known_2434);
              heff_drop(v_b_2487);
              heff_drop(v_x1_2490);
              return heff_tag_at_n(v_ru_24x41_2481_24ETag, TAG_MkArm, 3, (V[]){v_t2_2485, v_vs_2486, NTAG(TAG_EAbandon)});
            }
          } else {
            heff_drop(v_go_2433);
            heff_drop(v_known_2434);
            heff_drop(v_arms_2435);
            heff_drop(v_t_2482);
            heff_drop(v_b_2487);
            return heff_tag_at_n(v_ru_24x41_2481_24ETag, TAG_MkArm, 3, (V[]){v_t2_2485, v_vs_2486, NTAG(TAG_EAbandon)});
          }
        }
      }
      default: return heff_nomatch(v_x5_2476);
      }
    }
    default: {
      heff_drop(v_arms_2435);
      heff_drop(v_x41_2481);
      switch (heff_tag_of(v_x5_2476)) {
      case TAG_MkArm: {
        V v_t2_2492 = heff_field(v_x5_2476, 0);
        V v_vs_2493 = heff_field(v_x5_2476, 1);
        V v_b_2494 = heff_field(v_x5_2476, 2);
        V v_ru_24x5_2476_24MkArm = heff_take_reuse_n(v_x5_2476, 7ULL, 3);
        V v_t_2495 = heff_tr(heff_call(v_go_2433, 2, (V[]){v_known_2434, v_b_2494}));
        return heff_tag_at_n(v_ru_24x5_2476_24MkArm, TAG_MkArm, 3, (V[]){v_t2_2492, v_vs_2493, v_t_2495});
      }
      default: return heff_nomatch(v_x5_2476);
      }
    }
    }
  }
  default: return heff_nomatch(v_x4_2475);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eknownCopy_24cpr(V v_s_240, V v_g_241, V v_argv_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      heff_drop(v_x_247);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
      HeffT2 v_t_249 = ({ V a_0 = v_t_248; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2412 = v_field_2411;
          V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 1, 7);
          V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_b_2412; V a_2 = v_argv_242; V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
          V v_lim_2415;
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            v_lim_2415 = MK_INT(160LL);
          } else {
            heff_drop(v_t_2414);
            v_lim_2415 = MK_INT(50LL);
          }
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2412), NTAG(TAG_Nil)});
          V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2415), MK_INT(0LL), v_t_2416));
          if (!heff_intLt_c_lent(v_lim_2415, v_x_2417, 0)) {
            heff_drop_rec(v_s_240, 10);
            heff_drop(v_lim_2415);
            heff_drop(v_x_2417);
            V v_t_2418 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2412)));
            V v_xs_2419 = (g_heff_2ecompile_2eir_2enubI(v_t_2418));
            V v_x1_2420 = ({ V a_0 = v_g_241; V a_1 = v_xs_2419; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_g_241); heff_drop(v_xs_2419); r_; });
            if (!(heff_dup(v_x1_2420) == NTAG(TAG_True))) {
              heff_drop(v_x1_2420);
              V v_f_2421 = ({ V a_0 = v_b_2412; V a_1 = v_argv_242; V r_ = (g_heff_2ecompile_2esimplify_2eprunedCopy(a_0, a_1)); heff_drop(v_argv_242); r_; });
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
            } else {
              heff_drop(v_argv_242);
              heff_drop(v_b_2412);
              heff_drop(v_x1_2420);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_lim_2415);
            heff_drop(v_x_2417);
            V v_kinds_2422 = heff_get_n(heff_get_n(v_s_240, 7, 10), 1, 7);
            V v_g_2423 = heff_dup(v_g_241);
            heff_drop(v_g_2423);
            V v_b_2424 = heff_dup(v_b_2412);
            V v_argv_2425 = heff_dup(v_argv_242);
            V v_t_2426 = (g_heff_2ecompile_2esimplify_2ehandedPast(v_kinds_2422, v_b_2424, v_argv_2425));
            V v_x_2427;
            if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
              heff_drop(v_t_2426);
              v_x_2427 = MK_INT(160LL);
            } else {
              heff_drop(v_t_2426);
              v_x_2427 = MK_INT(50LL);
            }
            V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI(heff_dup(v_argv_2425), NTAG(TAG_Nil)));
            V v_t_2429 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(2LL), v_t_2428));
            V v_t_2430 = ({ V a_0 = v_kinds_2422; V a_1 = v_b_2424; V a_2 = v_argv_2425; V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_kinds_2422); heff_drop(v_b_2424); heff_drop(v_argv_2425); r_; });
            V v_t_2431;
            if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
              heff_drop(v_t_2430);
              v_t_2431 = MK_INT(160LL);
            } else {
              heff_drop(v_t_2430);
              v_t_2431 = MK_INT(24LL);
            }
            V v_y_2432 = heff_intAdd(v_t_2429, v_t_2431);
            V v_lim_2433;
            if (heff_intLe_c_lent(v_x_2427, v_y_2432, 0)) {
              heff_drop(v_y_2432);
              v_lim_2433 = v_x_2427;
            } else {
              heff_drop(v_x_2427);
              v_lim_2433 = v_y_2432;
            }
            V v_x2_2434 = heff_dup(v_b_2412);
            V v_argv_2435 = heff_dup(v_argv_242);
            V v_x1_2478;
            switch (heff_tag_of(v_x2_2434)) {
            case TAG_EVar: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EGlobal: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_ELam: {
              V v_xs_2438 = heff_field(v_x2_2434, 0);
              V v_b_2439 = heff_field(v_x2_2434, 1);
              V v_ru_24x2_2434_24ELam = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
              V v_t_2440 = ({ V a_0 = v_xs_2438; V a_1 = v_argv_2435; V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2esimplify_2etagsGiven(a_0, a_1, a_2)); heff_drop(v_argv_2435); r_; });
              V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_2434_24ELam, TAG_ELam, 2, (V[]){v_xs_2438, v_b_2439}), NTAG(TAG_Nil)});
              V v_x_2442 = (g_heff_2ecompile_2esimplify_2eprunedB(heff_dup(v_lim_2433), v_t_2440, MK_INT(0LL), v_t_2441));
              v_x1_2478 = heff_bool(heff_intLt_c_lent(v_lim_2433, v_x_2442, 0));
              heff_drop(v_lim_2433);
              heff_drop(v_x_2442);
              break;
            }
            case TAG_EApp: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_ELet: {
              heff_take_n(v_x2_2434, 0ULL, 3);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_ERecord: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EProj: {
              heff_take_n(v_x2_2434, 0ULL, 4);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_ETag: {
              heff_take_n(v_x2_2434, 0ULL, 3);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EMatch: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EPrim: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EPrimCall: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_ECall: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EInt: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EFloat: {
              heff_take_nf(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EStr: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EBytes: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EFixed: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EFloat32: {
              heff_take_na(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EAbandon: {
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EBool: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_ESet: {
              heff_take_n(v_x2_2434, 0ULL, 3);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EValues: {
              heff_take_n(v_x2_2434, 0ULL, 1);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            case TAG_EFix: {
              heff_take_n(v_x2_2434, 0ULL, 2);
              heff_drop(v_lim_2433);
              heff_drop(v_argv_2435);
              v_x1_2478 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x2_2434);
            }
            if (!(heff_dup(v_x1_2478) == NTAG(TAG_True))) {
              heff_drop(v_x1_2478);
              V v_t_2479 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2412)));
              V v_xs_2480 = (g_heff_2ecompile_2eir_2enubI(v_t_2479));
              V v_x1_2481 = ({ V a_0 = v_g_241; V a_1 = v_xs_2480; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_g_241); heff_drop(v_xs_2480); r_; });
              if (!(heff_dup(v_x1_2481) == NTAG(TAG_True))) {
                heff_drop(v_x1_2481);
                V v_f_2482 = ({ V a_0 = v_b_2412; V a_1 = v_argv_242; V r_ = (g_heff_2ecompile_2esimplify_2eprunedCopy(a_0, a_1)); heff_drop(v_argv_242); r_; });
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2482}});
              } else {
                heff_drop(v_argv_242);
                heff_drop(v_b_2412);
                heff_drop(v_x1_2481);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_g_241);
              heff_drop(v_argv_242);
              heff_drop(v_b_2412);
              heff_drop(v_x1_2478);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop_rec(v_s_240, 10);
          heff_drop(v_g_241);
          heff_drop(v_argv_242);
          heff_drop(v_field_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop_rec(v_s_240, 10);
      heff_drop(v_g_241);
      heff_drop(v_argv_242);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_f_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
    V v_t_243 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_242, 6), v_k_240, v_p_241));
    v_f_244 = ({ V rv_6 = v_t_243; V rr_ = heff_rec_reuse_nf(v_s_242, 959ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1036287u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_f_244 = v_s_242;
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_244}});
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_241, 0);
      V v_xs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2ekeepParams_24dps(v_ms_243, v_xs_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_x_245 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_244));
  V v_t_2414;
  if (!heff_intLt_c_lent(MK_INT(1200LL), v_x_245, 1)) {
    heff_drop(v_x_245);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
    V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esharedIn_clo), 1, (V[]){heff_dup(v_s_243)}));
    HeffT2 v_t_248 = (g_heff_2ecompile_2espec_2edictGo_24cpr(v_t_247, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_b0_241)));
    V v_t_2413;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_r_2411 = v_field_2410;
        V v_t_2412 = heff_tr(g_heff_2ecompile_2espec_2eclosedIn(NTAG(TAG_Nil), heff_dup(v_r_2411)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          v_t_2413 = v_r_2411;
        } else {
          heff_drop(v_r_2411);
          heff_drop(v_t_2412);
          v_t_2413 = heff_dup(v_b0_241);
        }
      } else {
        heff_drop(v_field_2410);
        v_t_2413 = heff_dup(v_b0_241);
      }
    }
    v_t_2414 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_246, heff_dup(v_h_240), v_t_2413));
  } else {
    heff_drop(v_x_245);
    v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  }
  V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esharedIn_clo), 1, (V[]){heff_dup(v_s_243)}));
  HeffT2 v_t_2416 = (g_heff_2ecompile_2espec_2edictGo_24cpr(v_t_2415, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_b0_241)));
  V v_t_2463;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_x1_2421;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_r_2419 = v_field_2418;
      V v_t_2420 = heff_tr(g_heff_2ecompile_2espec_2eclosedIn(NTAG(TAG_Nil), heff_dup(v_r_2419)));
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        v_x1_2421 = v_r_2419;
      } else {
        heff_drop(v_r_2419);
        heff_drop(v_t_2420);
        v_x1_2421 = heff_dup(v_b0_241);
      }
    } else {
      heff_drop(v_field_2418);
      v_x1_2421 = heff_dup(v_b0_241);
    }
    V v_t_2461;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_EVar: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x1_2421, 0ULL, 3);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_True);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x1_2421, 0ULL, 4);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x1_2421, 0ULL, 3);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x1_2421, 0ULL, 3);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x1_2421, 0ULL, 1);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x1_2421, 0ULL, 2);
      v_t_2461 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
      heff_drop(v_t_2461);
      V v_t_2462 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
      v_t_2463 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2462, heff_dup(v_h_240), NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_t_2461);
      v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    }
  }
  V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 2, 7);
  V v_t_2465 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2464, heff_dup(v_h_240), v_b0_241));
  V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 3, 7);
  V v_t_2467 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2466, v_h_240, v_d_242));
  V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 4, 7);
  V v_t_2469 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 5, 7);
  V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 6, 7);
  V v_p_2471 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_2414, v_t_2463, v_t_2465, v_t_2467, v_t_2468, heff_intAdd(v_t_2469, MK_INT(1LL)), v_t_2470});
  V v_f_2472 = ({ V rv_7 = v_p_2471; V rr_ = heff_rec_reuse_nf(v_s_243, 895ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 999423u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2472}});
}

HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V v_s_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 1, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 3, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 4, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 6, 7);
  V v_f_247 = ({ V rv_1 = MK_INT(4000LL); V rv_6 = heff_dup(g_std_2eordmap_2eempty_get()); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, MK_INT(0LL), v_t_246}); V rv_9 = heff_dup(g_std_2eordmap_2eempty_get()); V rr_ = heff_rec_reuse_nf(v_s_240, 317ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 200691u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 9) = rv_9; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_247}});
}

HeffT2 g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(V v_f_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_tr(heff_call(v_f_240, 1, (V[]){v_t_244}));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 6, 7);
  V v_p_2410 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249});
  V v_f_2411 = ({ V rv_7 = v_p_2410; V rr_ = heff_rec_reuse_nf(v_s_241, 895ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 999423u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2411}});
}
Clo g_heff_2ecompile_2esimplify_2emissingOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emissingOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emissingOf(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    V v_e1_246 = heff_field(v_e_241, 0);
    V v_bs_247 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_e1_246, 0);
      V v_all_2410 = heff_get_n(v_s_240, 2, 10);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_2410, v_h_249));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2413 = ({ V a_0 = v_all_2410; V a_1 = v_h_249; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_2410); r_; });
        V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
        return heff_intSub(v_t_2413, v_t_2414);
      } else {
        heff_drop(v_all_2410);
        return MK_INT(0LL);
      }
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 10);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_e1_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EValues: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 10);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emissingOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739(V v_f_240, V v_g_241, V v_argv_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_s_243, 2), v_g_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_b_247 = v_field_246;
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
      V v_x_249 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(50LL), v_x_249)) {
        heff_drop(v_b_247);
        V v_x_2410 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_s_243});
      } else {
        V v_t_2411 = (g_heff_2ecompile_2eir_2ehasDefault(v_b_247));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          V v_x_2412 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_s_243});
        } else {
          heff_drop(v_t_2411);
          V v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_s_243, 2), v_g_241));
          HeffT2 v_t_2414 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2413, v_s_243));
          {
            V v_field_2415 = v_t_2414.f[0];
            V v_field_2416 = v_t_2414.f[1];
            V v_x_2417 = v_field_2415;
            V v_s_2418 = v_field_2416;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_Nothing: {
              V v_x_2419 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
              return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
            }
            case TAG_Just: {
              V v_b_2420 = heff_field(v_x_2417, 0);
              heff_take_n(v_x_2417, 1ULL, 1);
              V v_orig_2421 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, heff_dup(v_argv_242)));
              V v_m_2422 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_2420, v_argv_242));
              HEFF_LAST return g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_2421, v_m_2422, v_s_2418);
            }
            default: return heff_nomatch(v_x_2417);
            }
          }
        }
      }
    } else {
      heff_drop(v_field_246);
      V v_t_2423 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_s_243, 2), v_g_241));
      HeffT2 v_t_2424 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2423, v_s_243));
      {
        V v_field_2425 = v_t_2424.f[0];
        V v_field_2426 = v_t_2424.f[1];
        V v_x_2427 = v_field_2425;
        V v_s_2428 = v_field_2426;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_Nothing: {
          V v_x_2429 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_s_2428});
        }
        case TAG_Just: {
          V v_b_2430 = heff_field(v_x_2427, 0);
          heff_take_n(v_x_2427, 1ULL, 1);
          V v_orig_2431 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, heff_dup(v_argv_242)));
          V v_m_2432 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_2430, v_argv_242));
          HEFF_LAST return g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_2431, v_m_2432, v_s_2428);
        }
        default: return heff_nomatch(v_x_2427);
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2einlineCall_24s399677765x1864100739(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str5, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str6, 2, "$s");
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749(V v_own_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_dup(heff_rfield(v_sh_246, 1));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2414 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_own_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_t_2414);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_247});
  } else {
    heff_drop(v_t_2414);
    V v_g_2416 = heff_dup(v_g_241);
    V v_marks_2417 = heff_dup(v_marks_245);
    V v_vars_2418 = heff_dup(heff_rfield(v_sh_246, 1));
    V v_argv_2419 = heff_dup(heff_rfield(v_sh_246, 0));
    V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_marks_2417));
    V v_t_2421 = (g_list_2etake(v_t_2420, v_argv_2419));
    V v_x2_2425 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_lam0, 2, 1, (V[]){v_vars_2418}), v_marks_2417, v_t_2421));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str2); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_t_2429 = heff_strAppend(heff_strAppend(v_g_2416, ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str3)), v_t_2428);
    V v_k_2430 = heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str4));
    V v_j_2431 = heff_strFind_lent(((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str5), v_g_241, MK_INT(0LL), 5);
    V v_t_2432;
    if (heff_intLt_c_lent(v_j_2431, MK_INT(0LL), 2)) {
      heff_drop(v_j_2431);
      v_t_2432 = heff_dup(v_g_241);
    } else {
      v_t_2432 = heff_strSlice_lent(v_g_241, MK_INT(0LL), v_j_2431, 6);
    }
    V v_t_2433 = ({ V a_0 = v_k_2430; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_k_2430); r_; });
    V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str6)), v_t_2433);
    V v_ds_2435 = heff_get_n(heff_dup(heff_rfield(v_s_247, 7)), 3, 7);
    V v_g_2436 = heff_dup(v_g_241);
    V v_f_2444 = heff_clo_n(g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_lam1, 2, 1, (V[]){v_ds_2435});
    V v_t_2445 = (g_list_2efoldl_24f1287822497x2111322144(NTAG(TAG_Nil), heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_t_2446 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2445; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_2445); r_; });
    V v_t_2447 = heff_tr(heff_call(heff_dup(v_f_2444), 2, (V[]){MK_INT(0LL), v_g_2436}));
    V v_t_2448 = ({ V a_0 = v_f_2444; V a_1 = v_t_2447; V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(v_own_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_sh_246, v_t_2434, heff_intAdd(MK_INT(1LL), v_t_2448), v_s_247));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_lam0(V self, V *args) {
  V v_m_2422 = args[0];
  V v_a_2423 = args[1];
  V v_vars_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_m_2422) == NTAG(TAG_True))) {
    heff_drop(v_m_2422);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_2418));
    return ({ V a_0 = v_t_2424; V a_1 = v_a_2423; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_a_2423); r_; });
  } else {
    heff_drop(v_m_2422);
    heff_drop(v_a_2423);
    heff_drop(v_vars_2418);
    return ((V)&g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_str0);
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_24s1452298477x790271749_lam1(V self, V *args) {
  V v_d_2437 = args[0];
  V v_n_2438 = args[1];
  V v_ds_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2439 = ({ V a_0 = v_ds_2435; V a_1 = v_n_2438; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ds_2435); heff_drop(v_n_2438); r_; });
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    V v_b_2443;
    if ((v_tag_2440 == ((int64_t)0ULL))) {
      V v_x_2442 = v_field_2441;
      v_b_2443 = v_x_2442;
    } else {
      heff_drop(v_field_2441);
      v_b_2443 = MK_INT(0LL);
    }
    if (heff_intLe_c_lent(v_b_2443, v_d_2437, 0)) {
      heff_drop(v_b_2443);
      return v_d_2437;
    } else {
      heff_drop(v_d_2437);
      return v_b_2443;
    }
  }
}
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(V v_g_240, V v_xs_241, V v_b_242, V v_argv_243, V v_made_244, V v_tags_245, V v_s_246) {
top: ;
  V v_kinds_247 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
  V v_back_2414 = heff_clo_n(g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam0, 1, 3, (V[]){heff_dup(v_s_246), heff_dup(v_argv_243), heff_dup(v_g_240)});
  V v_g_2415 = heff_dup(v_g_240);
  V v_b_2416 = heff_dup(v_b_242);
  V v_argv_2417 = heff_dup(v_argv_243);
  V v_t_2426 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam1, 1, 2, (V[]){v_kinds_247, v_back_2414}), v_argv_2417));
  V v_t_2430;
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop(v_g_2415);
    heff_drop(v_b_2416);
    heff_drop(v_argv_2417);
    heff_drop(v_t_2426);
    v_t_2430 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2426);
    V v_t_2427 = ({ V a_0 = v_argv_2417; V r_ = (g_list_2eany_24s378803910x892125795(a_0)); heff_drop(v_argv_2417); r_; });
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2416));
      V v_xs_2429 = (g_heff_2ecompile_2eir_2enubI(v_t_2428));
      v_t_2430 = ({ V a_0 = v_g_2415; V a_1 = v_xs_2429; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_g_2415); heff_drop(v_xs_2429); r_; });
    } else {
      heff_drop(v_g_2415);
      heff_drop(v_b_2416);
      heff_drop(v_t_2427);
      v_t_2430 = NTAG(TAG_False);
    }
  }
  V v_t_2433;
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop(v_t_2430);
    v_t_2433 = NTAG(TAG_False);
  } else {
    heff_drop(v_t_2430);
    V v_t_2431 = (g_list_2eany_24s228396297x1310020012(v_made_244));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_t_2431);
      v_t_2433 = NTAG(TAG_False);
    } else {
      heff_drop(v_t_2431);
      V v_x1_2432 = (g_list_2eany_24s228396297x1310020012(v_tags_245));
      v_t_2433 = heff_bool(!(heff_dup(v_x1_2432) == NTAG(TAG_True)));
      heff_drop(v_x1_2432);
    }
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    heff_drop(v_made_244);
    heff_drop(v_tags_245);
    heff_drop(v_t_2433);
    V v_x_2434 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_240}), v_argv_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_s_246});
  } else {
    heff_drop(v_t_2433);
    V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2442 = (g_heff_2ecompile_2esimplify_2emarksOf(v_t_2435, heff_clo_n(g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam2, 1, 3, (V[]){heff_dup(v_s_246), heff_dup(v_argv_243), heff_dup(v_g_240)}), heff_dup(v_g_240), heff_dup(v_xs_241), heff_dup(v_b_242), v_argv_243));
    V v_t_2443 = (g_heff_2ecompile_2esimplify_2eorMarks(v_t_2442, v_made_244));
    V v_t_2444 = (g_heff_2ecompile_2esimplify_2eorMarks(v_t_2443, v_tags_245));
    HEFF_LAST return g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(NTAG(TAG_True), v_g_240, v_xs_241, v_b_242, v_argv_243, v_t_2444, v_s_246);
  }
}
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_s_246 = heff_env(self)[0];
  V v_argv_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 0, 7);
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_e_248; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_249); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_e_248);
    heff_drop_rec(v_s_246, 10);
    heff_drop(v_argv_243);
    heff_drop(v_g_240);
    heff_drop(v_t_2410);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_argv_243; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_argv_243); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_get_n(heff_get_n(v_s_246, 7, 10), 0, 7);
      return ({ V a_0 = v_t_2413; V a_1 = v_g_240; V a_2 = v_e_248; V r_ = (g_heff_2ecompile_2esimplify_2eloopBack(a_0, a_1, a_2)); heff_drop(v_t_2413); heff_drop(v_e_248); r_; });
    } else {
      heff_drop(v_e_248);
      heff_drop_rec(v_s_246, 10);
      heff_drop(v_g_240);
      heff_drop(v_t_2412);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam1(V self, V *args) {
  V v_a_2418 = args[0];
  V v_kinds_247 = heff_env(self)[0];
  V v_back_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2418)) {
  case TAG_EGlobal: {
    V v_g_2419 = heff_dup(heff_field(v_a_2418, 0));
    HeffT2 v_t_2420 = ({ V a_0 = v_kinds_247; V a_1 = v_g_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_kinds_247); heff_drop(v_g_2419); r_; });
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        heff_drop_tag(v_a_2418, 1);
        heff_drop_clo(v_back_2414, 3);
        V v_x_2423 = v_field_2422;
        heff_drop(v_x_2423);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_2422);
        V f_ = v_back_2414;
        args[0] = v_a_2418;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: {
    heff_drop(v_kinds_247);
    V v_t_2424 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_2418)));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_a_2418);
      heff_drop_clo(v_back_2414, 3);
      heff_drop(v_t_2424);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2424);
      V v_t_2425 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_a_2418)));
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_a_2418);
        heff_drop_clo(v_back_2414, 3);
        heff_drop(v_t_2425);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2425);
        V f_ = v_back_2414;
        args[0] = v_a_2418;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_lam2(V self, V *args) {
  V v_e_2436 = args[0];
  V v_s_246 = heff_env(self)[0];
  V v_argv_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 0, 7);
  V v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = v_e_2436; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2437); r_; });
  if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
    heff_drop(v_e_2436);
    heff_drop_rec(v_s_246, 10);
    heff_drop(v_argv_243);
    heff_drop(v_g_240);
    heff_drop(v_t_2438);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2438);
    V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2440 = ({ V a_0 = v_t_2439; V a_1 = v_argv_243; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2439); heff_drop(v_argv_243); r_; });
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      V v_t_2441 = heff_get_n(heff_get_n(v_s_246, 7, 10), 0, 7);
      return ({ V a_0 = v_t_2441; V a_1 = v_g_240; V a_2 = v_e_2436; V r_ = (g_heff_2ecompile_2esimplify_2eloopBack(a_0, a_1, a_2)); heff_drop(v_t_2441); heff_drop(v_e_2436); r_; });
    } else {
      heff_drop(v_e_2436);
      heff_drop_rec(v_s_246, 10);
      heff_drop(v_g_240);
      heff_drop(v_t_2440);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam8(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(V v_l_240, V v_sh_241, V v_t_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EGlobal: {
    V v_g_244 = heff_dup(heff_field(v_e_243, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam0, 1, 5, (V[]){v_g_244, v_e_243, v_l_240, v_sh_241, v_t_242});
  }
  case TAG_EApp: {
    V v_e1_2414 = heff_dup(heff_field(v_e_243, 0));
    switch (heff_tag_of(v_e1_2414)) {
    case TAG_EGlobal: {
      heff_take_n(v_e1_2414, 0ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam1, 1, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242});
    }
    default: {
      heff_drop(v_e1_2414);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam3, 1, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242});
    }
    }
  }
  case TAG_ELet: {
    V v_x_2441 = heff_field(v_e_243, 0);
    V v_a_2442 = heff_field(v_e_243, 1);
    V v_b_2443 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2444 = (g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(v_l_240, v_sh_241, v_t_242, v_b_2443));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam4, 1, 3, (V[]){v_m_2444, v_x_2441, v_a_2442});
  }
  case TAG_ERecord: {
    V v_fs_2449 = heff_field(v_e_243, 0);
    V v_ts_2450 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    HeffT2 v_t_2451 = (g_heff_2ecompile_2esimplify_2efindField_24cpr(v_l_240, v_fs_2449));
    {
      V v_field_2453 = v_t_2451.f[1];
      int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
      if ((v_tag_2452 == ((int64_t)0ULL))) {
        V v_v_2454 = v_field_2453;
        V v_m_2455 = (g_heff_2ecompile_2esimplify_2eothersPure(v_l_240, heff_dup(v_fs_2449)));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam5, 1, 7, (V[]){v_m_2455, v_v_2454, v_fs_2449, v_ts_2450, v_l_240, v_sh_241, v_t_242});
      } else {
        heff_drop(v_field_2453);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam6, 1, 5, (V[]){v_fs_2449, v_ts_2450, v_l_240, v_sh_241, v_t_242});
      }
    }
  }
  case TAG_ESet: {
    V v_xs_2463 = heff_field(v_e_243, 0);
    V v_a_2464 = heff_field(v_e_243, 1);
    V v_b_2465 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2466 = (g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(v_l_240, v_sh_241, v_t_242, v_b_2465));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam7, 1, 3, (V[]){v_m_2466, v_xs_2463, v_a_2464});
  }
  default: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam8, 1, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242});
  }
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_l_240 = heff_env(self)[2];
  V v_sh_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = ({ V a_0 = heff_rfield(v_s_245, 2); V a_1 = v_g_244; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_g_244); r_; });
  HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_246, v_s_245));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x_2410 = v_field_248;
    V v_s_2411 = v_field_249;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242}), v_s_2411});
    }
    case TAG_Just: {
      V v_b_2412 = heff_field(v_x_2410, 0);
      heff_take_n(v_x_2410, 1ULL, 1);
      V v_m_2413 = (g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995(heff_dup(v_l_240), heff_dup(v_sh_241), heff_dup(v_t_242), v_b_2412));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242}), v_m_2413, v_s_2411));
    }
    default: return heff_nomatch(v_x_2410);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_sh_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_l_2421 = heff_dup(v_l_240);
  V v_e_2422 = heff_dup(v_e_243);
  V v_p_2423 = v_s_2420;
  V v_x2_2435;
  switch (heff_tag_of(v_e_2422)) {
  case TAG_EApp: {
    V v_e1_2424 = heff_field(v_e_2422, 0);
    V v_argv_2425 = heff_field(v_e_2422, 1);
    V v_ru_24e_2422_24EApp = heff_take_reuse_n(v_e_2422, 3ULL, 2);
    switch (heff_tag_of(v_e1_2424)) {
    case TAG_EGlobal: {
      V v_g_2426 = heff_field(v_e1_2424, 0);
      V v_ru_24e1_2424_24EGlobal = heff_take_reuse_n(v_e1_2424, 1ULL, 1);
      V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_p_2423, 7)), 0, 7);
      V v_t_2428 = ({ V a_0 = v_ru_24e1_2424_24EGlobal; V a_1 = v_t_2427; V a_2 = v_g_2426; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_t_2427); heff_drop(v_g_2426); r_; });
      HeffT2 v_t_2429 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2428, v_p_2423));
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_x_2432 = v_field_2430;
        V v_s_2433 = v_field_2431;
        V v_x_2434 = ({ V a_0 = v_l_2421; V a_1 = v_argv_2425; V a_2 = v_x_2432; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltFieldOf(a_0, a_1, a_2)); heff_drop(v_l_2421); r_; });
        v_x2_2435 = heff_tag_at_n(v_ru_24e_2422_24EApp, TAG_MkPair, 2, (V[]){v_x_2434, v_s_2433});
      }
      break;
    }
    default: {
      heff_drop(v_l_2421);
      heff_drop(v_e1_2424);
      heff_drop(v_argv_2425);
      v_x2_2435 = heff_tag_at_n(v_ru_24e_2422_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2423});
      break;
    }
    }
    break;
  }
  default: {
    heff_drop(v_l_2421);
    heff_drop(v_e_2422);
    v_x2_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2423});
    break;
  }
  }
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    switch (heff_tag_of(v_x_2436)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242}), v_s_2437});
    }
    case TAG_Just: {
      V v_v_2438 = heff_field(v_x_2436, 0);
      heff_take_n(v_x_2436, 1ULL, 1);
      heff_drop(v_l_240);
      heff_drop_tag(v_e_243, 2);
      heff_drop(v_sh_241);
      heff_drop(v_t_242);
      heff_drop_cell(v_ru_24x2_2435_24MkPair, 2);
      V v_t_2439 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_v_2438));
      V f_ = v_t_2439;
      args[0] = v_s_2437;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2436);
    }
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_sh_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_s_2417, 7)), 0, 7);
  V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_e_243; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2418); r_; });
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), heff_tag_n(TAG_EProj, 4, (V[]){heff_dup(v_e_243), heff_dup(v_l_240), heff_dup(v_sh_241), heff_dup(v_t_242)}), heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam2, 1, 4, (V[]){v_l_240, v_e_243, v_sh_241, v_t_242}), v_s_2417));
  } else {
    heff_drop(v_t_2419);
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242}), v_s_2417});
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam3(V self, V *args) {
  V v_s_2440 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_sh_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242}), v_s_2440});
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam4(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_x_2441 = heff_env(self)[1];
  V v_a_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2441, v_a_2442, v_x_2447}), v_s_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam5(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_v_2454 = heff_env(self)[1];
  V v_fs_2449 = heff_env(self)[2];
  V v_ts_2450 = heff_env(self)[3];
  V v_l_240 = heff_env(self)[4];
  V v_sh_241 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2460;
    if ((heff_dup(v_x_2458) == NTAG(TAG_True))) {
      heff_drop(v_fs_2449);
      heff_drop(v_ts_2450);
      heff_drop(v_l_240);
      heff_drop(v_sh_241);
      heff_drop(v_t_242);
      heff_drop(v_x_2458);
      v_t_2460 = v_v_2454;
    } else {
      heff_drop(v_v_2454);
      heff_drop(v_x_2458);
      v_t_2460 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2449, v_ts_2450}), v_l_240, v_sh_241, v_t_242});
    }
    return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_t_2460, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam6(V self, V *args) {
  V v_s_2461 = args[0];
  V v_fs_2449 = heff_env(self)[0];
  V v_ts_2450 = heff_env(self)[1];
  V v_l_240 = heff_env(self)[2];
  V v_sh_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2462 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2449, v_ts_2450}), v_l_240, v_sh_241, v_t_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_s_2461});
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam7(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_xs_2463 = heff_env(self)[1];
  V v_a_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2463, v_a_2464, v_x_2469}), v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_24s1073488100x510480995_lam8(V self, V *args) {
  V v_s_2471 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_sh_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_l_240, v_sh_241, v_t_242}), v_s_2471});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str3, 5, "False");
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(V v_s_240, V v_arms_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_arms_241)) {
  case TAG_Nil: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    v_t_244 = (g_list_2eall_24s673599783x290475791(v_s_240, v_arms_241));
    break;
  }
  default: heff_nomatch(v_arms_241);
  }
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_arms_241);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_lam0, 1, 1, (V[]){v_s_240});
  } else {
    heff_drop(v_t_244);
    HeffT3 v_t_246 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(heff_dup(v_arms_241)));
    {
      V v_field_248 = v_t_246.f[1];
      V v_field_249 = v_t_246.f[2];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_t_2410 = v_field_248;
        V v_f_2411 = v_field_249;
        V v_t_2412 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_t_2410)));
        V v_t_2415;
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_t_2413 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_f_2411)));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            V v_t_2414 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_t_2410)));
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop(v_t_2414);
              v_t_2415 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2414);
              v_t_2415 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_f_2411)));
            }
          } else {
            heff_drop(v_t_2413);
            v_t_2415 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_t_2412);
          v_t_2415 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_arms_241);
          heff_drop(v_t_2415);
          V v_t_2416 = (g_heff_2ecompile_2eir_2econdOf(v_s_240));
          V v_t_2417 = (g_heff_2ecompile_2eir_2econdOf(v_t_2410));
          V v_t_2418 = (g_heff_2ecompile_2eir_2econdOf(v_f_2411));
          V v_t_2419 = (g_heff_2ecompile_2eir_2econdIf(v_t_2416, v_t_2417, v_t_2418));
          V v_c_2420 = (g_heff_2ecompile_2esimplify_2efoldCond(v_t_2419));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_lam1, 1, 1, (V[]){v_c_2420});
        } else {
          heff_drop(v_t_2410);
          heff_drop(v_f_2411);
          heff_drop(v_t_2415);
          V v_t_2431 = (g_heff_2ecompile_2eir_2econdOf(v_s_240));
          V v_c_2432 = (g_heff_2ecompile_2esimplify_2efoldCond(v_t_2431));
          V v_t_2441;
          switch (heff_tag_of(v_c_2432)) {
          case TAG_CTrue: {
            v_t_2441 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
            break;
          }
          case TAG_CFalse: {
            v_t_2441 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str3), NTAG(TAG_Nil), NTAG(TAG_Nil)});
            break;
          }
          case TAG_CRel: {
            v_t_2441 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2432});
            break;
          }
          case TAG_CTest: {
            V v_e_2436 = heff_field(v_c_2432, 0);
            heff_take_n(v_c_2432, 1ULL, 1);
            v_t_2441 = v_e_2436;
            break;
          }
          case TAG_CNot: {
            v_t_2441 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2432});
            break;
          }
          case TAG_CIf: {
            v_t_2441 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2432});
            break;
          }
          default: heff_nomatch(v_c_2432);
          }
          HEFF_LAST return g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438(v_t_2441, v_arms_241);
        }
      } else {
        heff_drop(v_field_248);
        heff_drop(v_field_249);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438(v_s_240, v_arms_241);
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_s_240, v_s_245});
}
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_lam1(V self, V *args) {
  V v_s_2421 = args[0];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_c_2420)) {
  case TAG_CTrue: {
    v_t_2430 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    break;
  }
  case TAG_CFalse: {
    v_t_2430 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    break;
  }
  case TAG_CRel: {
    v_t_2430 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2420});
    break;
  }
  case TAG_CTest: {
    V v_e_2425 = heff_field(v_c_2420, 0);
    heff_take_n(v_c_2420, 1ULL, 1);
    v_t_2430 = v_e_2425;
    break;
  }
  case TAG_CNot: {
    v_t_2430 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2420});
    break;
  }
  case TAG_CIf: {
    v_t_2430 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2420});
    break;
  }
  default: heff_nomatch(v_c_2420);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_s_2421});
}
Clo g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024(V v_lit_240, V v_lit_241, V v_h_242, V v_argv_243, V v_z_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_lit_240));
  if (heff_intEq_c(v_t_245, v_t_246)) {
    heff_drop(v_h_242);
    HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_lit_240, v_lit_241}), v_z_244));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_s_2411 = v_field_249;
      V v_x_2415;
      switch (heff_tag_of(v_x_2410)) {
      case TAG_ELam: {
        V v_ys_2412 = heff_field(v_x_2410, 0);
        V v_b_2413 = heff_field(v_x_2410, 1);
        heff_take_n(v_x_2410, 3ULL, 2);
        V v_t_2414 = (g_list_2ezipWith_24s1876717925x1404326288(v_ys_2412, v_argv_243));
        v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = v_b_2413; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
        break;
      }
      default: {
        v_x_2415 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2410, v_argv_243));
        break;
      }
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_s_2411});
    }
  } else {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    V v_t_2416 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_242}), v_argv_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_z_244});
  }
}
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_x1_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeEach(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecanonVisit_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecanonVisit(V v_c_240, V v_h_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_c_240, 0), v_h_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_245 = v_field_244;
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_c_240, 1), v_h_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_h_241);
          heff_drop_rec(v_d_245, 3);
          V v_x_249 = v_field_248;
          heff_drop(v_x_249);
          return v_c_240;
        } else {
          heff_drop(v_field_248);
          V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_c_240, 1), v_h_241, NTAG(TAG_MkUnit)));
          V v_t_2411 = ({ V rv_1 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_c_240, 5ULL, 3, shape_pool__placed__out, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_245, 2))));
          V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
          V v_c_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2ecanonVisit_clo); V a_1 = v_t_2411; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
          V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_245, heff_take_field(v_c_2414, 2)});
          return ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_c_2414, 3ULL, 3, shape_pool__placed__out, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        }
      }
    } else {
      heff_drop(v_h_241);
      heff_drop(v_field_244);
      return v_c_240;
    }
  }
}
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecanonVisit(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2einOrder_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2einOrder_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einOrder_lam2, 1, 0};
V g_heff_2ecompile_2esimplify_2einOrder_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2einOrder_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2einOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einOrder_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2einOrder(V v_b_240, V v_made_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_made_241));
  V v_t_243 = heff_rec_n(3, shape_pool__placed__out, (V[]){v_t_242, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil)});
  V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_240));
  V v_t_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
  V v_x_246 = ({ V a_0 = v_t_243; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s419339443x1702462498(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_placed_247 = heff_take_field(v_x_246, 1);
  V v_out_248 = heff_get_n(v_x_246, 2, 3);
  return heff_clo_n(g_heff_2ecompile_2esimplify_2einOrder_lam0, 1, 3, (V[]){v_placed_247, v_made_241, v_out_248});
}
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einOrder(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2einOrder_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2415});
}
V g_heff_2ecompile_2esimplify_2einOrder_lam1(V self, V *args) {
  V v_d_2410 = args[0];
  V v_placed_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = ({ V a_0 = v_placed_247; V a_1 = heff_rfield(v_d_2410, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_placed_247); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_2410, 3);
      V v_x_2414 = v_field_2413;
      heff_drop(v_x_2414);
      return ((V)&g_heff_2ecompile_2esimplify_2einOrder_lam2_clo);
    } else {
      heff_drop(v_field_2413);
      V f_ = ((V)&g_heff_2ecompile_2esimplify_2eunmade_clo);
      args[0] = heff_get_n(v_d_2410, 0, 3);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ecompile_2esimplify_2einOrder_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_placed_247 = heff_env(self)[0];
  V v_made_241 = heff_env(self)[1];
  V v_out_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2416 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2einOrder_lam1, 1, 1, (V[]){v_placed_247}), v_made_241));
  V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 2ULL, 2);
    V v_x_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_out_248));
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2econcatDefs(v_rest_242));
    return (g_prelude_2e_2b_2b(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2econcatDefs(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2(V v_tok_240, V v_s_241, V v_arms_242, V v_argv_243, V v_z_244) {
top: ;
  V v_t_245 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_243)));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_245); r_; });
  if (((heff_dup(v_t_246) == NTAG(TAG_True)) && ({ V v_t_247 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_243))); int c_ = ({ V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_242)); int c_ = ({ V v_t_2433 = heff_intMul(heff_dup(v_t_247), heff_intSub(heff_dup(v_t_248), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2433, MK_INT(120LL), 2); heff_drop(v_t_2433); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }))) {
    heff_drop(v_t_246);
    V v_m_2418 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_lam0, 1, 1, (V[]){v_argv_243}), v_arms_242));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_s_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_EMatch, 2, (V[]){v_s_241, v_x_2420}), v_s_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_246);
    V v_arms_2422 = heff_dup(v_arms_242);
    V v_argv_2423 = heff_dup(v_argv_243);
    V v_t_2424 = (g_list_2emap_24s1531069132x955165792(heff_dup(v_argv_2423)));
    V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2424); r_; });
    V v_t_2432;
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      V v_t_2426 = (g_list_2eany_24s860380051x1466609135(v_argv_2423));
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_argv_2427 = (g_list_2ekeepIf_24s183165982x1490920686(v_argv_2423));
        V v_t_2428 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_2427)));
        V v_t_2429 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2428); r_; });
        v_t_2432 = heff_bool(((heff_dup(v_t_2429) == NTAG(TAG_True)) && ({ V v_t_2430 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_2427))); int c_ = ({ V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2422)); int c_ = ({ V v_t_2434 = heff_intMul(heff_dup(v_t_2430), heff_intSub(heff_dup(v_t_2431), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2434, MK_INT(120LL), 2); heff_drop(v_t_2434); c_; }); heff_drop(v_t_2431); c_; }); heff_drop(v_t_2430); c_; })));
        heff_drop(v_arms_2422);
        heff_drop(v_argv_2427);
        heff_drop(v_t_2429);
      } else {
        heff_drop(v_arms_2422);
        heff_drop(v_argv_2423);
        heff_drop(v_t_2426);
        v_t_2432 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_arms_2422);
      heff_drop(v_argv_2423);
      heff_drop(v_t_2425);
      v_t_2432 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      return (g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(v_s_241, v_arms_242, v_argv_243, v_z_244));
    } else {
      heff_drop(v_t_2432);
      return (g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(v_s_241, v_arms_242, v_argv_243, v_z_244));
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_argv_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_a_249, 0);
    V v_vs_2411 = heff_field(v_a_249, 1);
    V v_b_2412 = heff_field(v_a_249, 2);
    heff_take_n(v_a_249, 7ULL, 3);
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(v_b_2412, v_argv_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_24tok2_lam1, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}