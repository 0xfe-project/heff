// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HS 9084
#define TAG_Inlined 13187
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_match 305026527
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__body__safe__touched[] = {LBL_key, LBL_body, LBL_safe, LBL_touched};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebackTo(V, V);
V g_heff_2ecompile_2esimplify_2ebackTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebackTo_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebudget_get(void);
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2eclosedUses_get(void);
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eeta(V, V);
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eeta_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2efindArm(V, V);
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindArm_clo;
V g_heff_2ecompile_2esimplify_2efreshParams(V, V);
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshParams_clo;
V g_heff_2ecompile_2esimplify_2einlineCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_clo;
V g_heff_2ecompile_2esimplify_2einlineMax_get(void);
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknowing(V, V, V);
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknowing_clo;
V g_heff_2ecompile_2esimplify_2eknown(V, V);
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknown_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enthE(V, V);
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2enthE_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
V g_heff_2ecompile_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2eremember(V, V, V);
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eremember_clo;
V g_heff_2ecompile_2esimplify_2ereplayBody(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo;
V g_heff_2ecompile_2esimplify_2ereplayed(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayed_clo;
V g_heff_2ecompile_2esimplify_2esetOff(V, V);
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetOff_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2especArgSize_get(void);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2especDepth_get(void);
V g_heff_2ecompile_2esimplify_2especLimit_get(void);
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2eversAll(V);
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eversAll_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1978122382x394628613(V);
V g_list_2emap_24s1978122382x394628613_entry(V self, V *a);
extern Clo g_list_2emap_24s1978122382x394628613_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;

static V g_heff_2ecompile_2esimplify_2ebudget_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2ebudget_st;
static V g_heff_2ecompile_2esimplify_2ebudget_init(void) {
  return MK_INT(24LL);
}
V g_heff_2ecompile_2esimplify_2ebudget_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2ebudget_st)) return g_heff_2ecompile_2esimplify_2ebudget_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2ebudget_val, &g_heff_2ecompile_2esimplify_2ebudget_st, g_heff_2ecompile_2esimplify_2ebudget_init);
}
Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2etakeL_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edropL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edropL(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str0, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str1, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str2, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str3, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str4, 6, "intShr");

static V g_heff_2ecompile_2esimplify_2efailing_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2efailing_st;
static V g_heff_2ecompile_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str2), v_t_240})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str4), v_t_241})});
}
V g_heff_2ecompile_2esimplify_2efailing_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2efailing_st)) return g_heff_2ecompile_2esimplify_2efailing_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2efailing_val, &g_heff_2ecompile_2esimplify_2efailing_st, g_heff_2ecompile_2esimplify_2efailing_init);
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_244), v_safe_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_249 = heff_field(v_e_242, 0);
    V v_as_2410 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e1_249)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_e1_249, 0);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2412), v_total_241));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_ar_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2415 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2410));
        if (heff_intLe_c(v_t_2415, v_ar_2414)) {
          V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2410)));
          return ({ V a_0 = v_t_2418; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_249);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2453 = heff_field(v_e_242, 0);
    V v_t_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2453)));
    return ({ V a_0 = v_t_2458; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2458); r_; });
  }
  case TAG_EProj: {
    V v_e2_2459 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2459;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2464 = heff_field(v_e_242, 1);
    V v_t_2466 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2464)));
    return ({ V a_0 = v_t_2466; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2466); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2470 = heff_field(v_e_242, 0);
    V v_as_2471 = heff_field(v_e_242, 1);
    V v_x1_2472 = ({ V a_0 = heff_dup(v_p_2470); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2472) == NTAG(TAG_True))) {
      heff_drop(v_x1_2472);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2472);
      V v_t_2474 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2471)));
      return ({ V a_0 = v_t_2474; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2474); r_; });
    }
  }
  case TAG_ECall: {
    V v_g_2475 = heff_field(v_e_242, 0);
    V v_as_2476 = heff_field(v_e_242, 1);
    V v_t_2477 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2475), v_total_241));
    switch (heff_tag_of(v_t_2477)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_ar_2478 = heff_field(v_t_2477, 0);
      heff_take_n(v_t_2477, 1ULL, 1);
      V v_t_2479 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2476));
      if (heff_intLe_c(v_t_2479, v_ar_2478)) {
        V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2476)));
        return ({ V a_0 = v_t_2482; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2482); r_; });
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_2477);
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epureIn(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2417; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2417); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2455 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2455)) {
  case TAG_MkPair: {
    V v_e2_2457 = heff_field(v_p_2455, 1);
    heff_take_n(v_p_2455, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2457; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2457); r_; });
  }
  default: return heff_nomatch(v_p_2455);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2465 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2465; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2465); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_a_2473 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2473; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2473); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2481 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2481; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2481); r_; });
}
Clo g_heff_2ecompile_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_x_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    if (heff_intLt_c(MK_INT(0LL), v_x_245)) {
      V v_t_247 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
        V v_x1_2410 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
        if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
          heff_drop(v_x1_2410);
          V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_x1_2410);
          V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_241), NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          V v_t_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_key_241, v_t_2413, heff_get_n(v_acc_240, 1, 2)));
          return heff_rec_n(2, shape_safe__total, (V[]){v_t_2412, v_t_2414});
        }
      } else {
        heff_drop(v_t_247);
        V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
        return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
        V v_x1_2419 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
        if ((heff_dup(v_x1_2419) == NTAG(TAG_True))) {
          heff_drop(v_key_241);
          heff_drop(v_x1_2419);
          return v_acc_240;
        } else {
          heff_drop(v_x1_2419);
          V v_t_2420 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          return ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
      } else {
        heff_drop(v_key_241);
        heff_drop(v_t_2416);
        return v_acc_240;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esgFlat(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_241));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      if (heff_intLt_c(v_t_248, v_t_249)) {
        V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureIn_clo), 2, (V[]){heff_take_field(v_s_240, 3), heff_get_n(v_s_240, 5, 9)}));
        V v_t_2412 = (g_list_2emap(v_t_2411, v_as_241));
        return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
      } else {
        heff_drop_rec(v_s_240, 9);
        heff_drop(v_as_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialOf(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialHead(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
    V v_t_246 = ({ V a_0 = heff_dup(v_g_244); V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    return ({ V a_0 = v_s_240; V a_1 = v_as_241; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialHead(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_y_243), v_x_240)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_a_241});
    } else {
      heff_drop(v_a_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2410 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_249));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_242, 0);
    V v_as_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2417 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_f_2415));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam3, 1, 4, (V[]){v_m_2417, v_x_240, v_a_241, v_as_2416});
  }
  case TAG_ELet: {
    V v_y_2428 = heff_field(v_e_242, 0);
    V v_e2_2429 = heff_field(v_e_242, 1);
    V v_b_2430 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_e2_2429));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam5, 1, 5, (V[]){v_m_2431, v_x_240, v_a_241, v_b_2430, v_y_2428});
  }
  case TAG_ERecord: {
    V v_fs_2440 = heff_field(v_e_242, 0);
    V v_ts_2441 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2450 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam6, 1, 2, (V[]){v_x_240, v_a_241}), v_fs_2440));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam8, 1, 2, (V[]){v_m_2450, v_ts_2441});
  }
  case TAG_EProj: {
    V v_e2_2455 = heff_field(v_e_242, 0);
    V v_l_2456 = heff_field(v_e_242, 1);
    V v_sh_2457 = heff_field(v_e_242, 2);
    V v_t_2458 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_m_2459 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2455));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam9, 1, 4, (V[]){v_m_2459, v_l_2456, v_sh_2457, v_t_2458});
  }
  case TAG_ETag: {
    V v_t_2464 = heff_field(v_e_242, 0);
    V v_as_2465 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2467 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2465));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam11, 1, 2, (V[]){v_m_2467, v_t_2464});
  }
  case TAG_EMatch: {
    V v_s_2472 = heff_field(v_e_242, 0);
    V v_arms_2473 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2474 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_s_2472));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam12, 1, 4, (V[]){v_m_2474, v_x_240, v_a_241, v_arms_2473});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam15, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_e_242, 0);
    V v_as_2495 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2497 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam16, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2495));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_m_2497, v_p_2494});
  }
  case TAG_ECall: {
    V v_g_24102 = heff_field(v_e_242, 0);
    V v_as_24103 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24105 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){v_x_240, v_a_241}), v_as_24103));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_m_24105, v_g_24102});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam20, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam26, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam27, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esubstCopies(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_245});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_248, v_x_2413}), v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_q_2422 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2422));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_as_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam4, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2416));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2421}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      V v_x_2427 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2420, v_x_2425));
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2430 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2430));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2428, v_x_2434, v_x_2438}), v_s_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2443, v_x_2448}), v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_p_2442 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_l_2443 = heff_field(v_p_2442, 0);
    V v_e_2444 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 3ULL, 2);
    V v_m_2445 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e_2444));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_m_2445, v_l_2443});
  }
  default: return heff_nomatch(v_p_2442);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_ts_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2453, v_ts_2441}), v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_l_2456 = heff_env(self)[1];
  V v_sh_2457 = heff_env(self)[2];
  V v_t_2458 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2461 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2462, v_l_2456, v_sh_2457, v_t_2458}), v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_q_2466 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2466));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_s_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  V v_t_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_s_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x2_2469, 0);
    V v_s_2471 = heff_field(v_x2_2469, 1);
    V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2464, v_x_2470}), v_s_2471});
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_s_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_t_2480 = heff_env(self)[1];
  V v_vs_2481 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_s_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_s_2487 = heff_field(v_x2_2485, 1);
    V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2480, v_vs_2481, v_x_2486}), v_s_2487});
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_a_2479 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2479)) {
  case TAG_MkArm: {
    V v_t_2480 = heff_field(v_a_2479, 0);
    V v_vs_2481 = heff_field(v_a_2479, 1);
    V v_b_2482 = heff_field(v_a_2479, 2);
    heff_take_n(v_a_2479, 7ULL, 3);
    V v_m_2483 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2482));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam14, 1, 3, (V[]){v_m_2483, v_t_2480, v_vs_2481});
  }
  default: return heff_nomatch(v_a_2479);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2473 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_s_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    V v_m_2488 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam13, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2473));
    V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2478}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2477, v_x_2490}), v_s_2491});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2493 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_2493});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_q_2496 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2496));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_s_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  V v_p_2494 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2499 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_s_2498}));
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_MkPair: {
    V v_x_24100 = heff_field(v_x2_2499, 0);
    V v_s_24101 = heff_field(v_x2_2499, 1);
    V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2494, v_x_24100}), v_s_24101});
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_q_24104 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_24104));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_s_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  V v_g_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_s_24106}));
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_x_24108 = heff_field(v_x2_24107, 0);
    V v_s_24109 = heff_field(v_x2_24107, 1);
    V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24102, v_x_24108}), v_s_24109});
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24111 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24111});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24113 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24115 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24115});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24117 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24117});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24120 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24120});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24122 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24122});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args) {
  V v_s_24123 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args) {
  V v_s_24126 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24126});
}

static V g_heff_2ecompile_2esimplify_2especArgSize_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especArgSize_st;
static V g_heff_2ecompile_2esimplify_2especArgSize_init(void) {
  return MK_INT(60LL);
}
V g_heff_2ecompile_2esimplify_2especArgSize_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especArgSize_st)) return g_heff_2ecompile_2esimplify_2especArgSize_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especArgSize_val, &g_heff_2ecompile_2esimplify_2especArgSize_st, g_heff_2ecompile_2esimplify_2especArgSize_init);
}
V g_heff_2ecompile_2esimplify_2eletPure_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam4(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletPure_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  if (heff_intEq_c(heff_dup(v_o_244), MK_INT(0LL))) {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243});
  } else {
    V v_t_2439;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_t_2440 = heff_bool(((heff_dup(v_t_2439) == NTAG(TAG_True)) || heff_intEq_c(heff_dup(v_o_244), MK_INT(1LL))));
    heff_drop(v_t_2439);
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_o_244);
      heff_drop(v_t_2440);
      V v_m_2441 = (g_map_2einsert_24s1341440536x470972936(v_x_241, v_a_242, heff_dup(g_map_2eempty_get())));
      V v_t_2442 = (g_map_2esize(v_m_2441));
      V v_t_2444;
      if (heff_intEq_c(v_t_2442, MK_INT(0LL))) {
        heff_drop(v_m_2441);
        v_t_2444 = v_b_243;
      } else {
        v_t_2444 = ({ V a_0 = v_m_2441; V a_1 = v_b_243; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2441); r_; });
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2444});
    } else {
      heff_drop(v_t_2440);
      V v_t_2445 = (g_heff_2ecompile_2eir_2eisValue(v_a_242));
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_t_2445);
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_x_2447 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2446));
        if (heff_intLt_c(MK_INT(12LL), v_x_2447)) {
          if (heff_intLe_c(v_o_244, heff_dup(g_heff_2ecompile_2esimplify_2eclosedUses_get()))) {
            V v_t_2450 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_242)));
            if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
              heff_drop(v_t_2450);
              V v_m_2451 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
              return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam0, 1, 2, (V[]){v_m_2451, v_r_240});
            } else {
              heff_drop(v_t_2450);
              V v_m_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
              return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam1, 1, 3, (V[]){v_m_2456, v_x_241, v_a_242});
            }
          } else {
            V v_m_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam2, 1, 3, (V[]){v_m_2461, v_x_241, v_a_242});
          }
        } else {
          heff_drop(v_o_244);
          V v_m_2466 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam3, 1, 2, (V[]){v_m_2466, v_r_240});
        }
      } else {
        heff_drop(v_o_244);
        heff_drop(v_t_2445);
        V v_m_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam4, 1, 3, (V[]){v_m_2471, v_x_241, v_a_242});
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eletPure_lam0(V self, V *args) {
  V v_s_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_s_2452}));
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_MkPair: {
    V v_x_2454 = heff_field(v_x2_2453, 0);
    V v_s_2455 = heff_field(v_x2_2453, 1);
    heff_take_n(v_x2_2453, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_x_2454;
    heff_room[1] = v_s_2455;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam1(V self, V *args) {
  V v_s_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_s_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2459}), v_s_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam2(V self, V *args) {
  V v_s_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_s_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_s_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2464}), v_s_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam3(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    heff_take_n(v_x2_2468, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_x_2469;
    heff_room[1] = v_s_2470;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam4(V self, V *args) {
  V v_s_2472 = args[0];
  V v_m_2471 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2473 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_s_2472}));
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_field(v_x2_2473, 0);
    V v_s_2475 = heff_field(v_x2_2473, 1);
    V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2474}), v_s_2475});
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
Clo g_heff_2ecompile_2esimplify_2efewerThan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efewerThan_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efewerThan(V v_as_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_245 = heff_field(v_x21_242, 0);
      V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_240));
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      return heff_intLt(v_t_247, v_t_248);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efewerThan(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletSplit(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2421 = heff_field(v_a_242, 0);
    V v_as_2422 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EApp = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_x2_2423 = (g_heff_2ecompile_2esimplify_2esplitArgs(v_as_2422, v_z_244));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24a_242_24EApp, TAG_EApp, 2, (V[]){v_f_2421, heff_dup(heff_rfield(v_x_2424, 1))});
      V v_t_2427 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2428 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2427));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2430 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2429));
      V v_t_2431 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2428, v_t_2430}), 0, 2);
      V v_m_2432 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_t_2426, v_b_243, v_t_2431));
      V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2425}));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_s_2435 = heff_field(v_x2_2433, 1);
        V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
        V v_x_2436 = ({ V b_0 = heff_get_n(v_x_2424, 0, 2); V a_1 = v_x_2434; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(b_0, a_1)); heff_drop(b_0); r_; });
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  case TAG_ELet: {
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_s_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2442}), v_s_2443});
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_ERecord: {
    V v_m_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_s_2449 = heff_field(v_x2_2447, 1);
      V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2448}), v_s_2449});
    }
    default: return heff_nomatch(v_x2_2447);
    }
  }
  case TAG_EProj: {
    V v_m_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_MkPair: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_s_2457 = heff_field(v_x2_2455, 1);
      V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2456}), v_s_2457});
    }
    default: return heff_nomatch(v_x2_2455);
    }
  }
  case TAG_ETag: {
    V v_m_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_s_2463 = heff_field(v_x2_2461, 1);
      V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2462}), v_s_2463});
    }
    default: return heff_nomatch(v_x2_2461);
    }
  }
  case TAG_EMatch: {
    V v_m_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2467 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2467)) {
    case TAG_MkPair: {
      V v_x_2468 = heff_field(v_x2_2467, 0);
      V v_s_2469 = heff_field(v_x2_2467, 1);
      V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2468}), v_s_2469});
    }
    default: return heff_nomatch(v_x2_2467);
    }
  }
  case TAG_EPrim: {
    V v_m_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2472 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2472)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_x2_2472, 0);
      V v_s_2474 = heff_field(v_x2_2472, 1);
      V v_ru_24x2_2472_24MkPair = heff_take_reuse_n(v_x2_2472, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2473}), v_s_2474});
    }
    default: return heff_nomatch(v_x2_2472);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_s_2480 = heff_field(v_x2_2478, 1);
      V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2479}), v_s_2480});
    }
    default: return heff_nomatch(v_x2_2478);
    }
  }
  case TAG_ECall: {
    V v_m_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2484 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_MkPair: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_s_2486 = heff_field(v_x2_2484, 1);
      V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2485}), v_s_2486});
    }
    default: return heff_nomatch(v_x2_2484);
    }
  }
  case TAG_EInt: {
    V v_m_2488 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2490}), v_s_2491});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  case TAG_EFloat: {
    V v_m_2493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2494 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2494)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_field(v_x2_2494, 0);
      V v_s_2496 = heff_field(v_x2_2494, 1);
      V v_ru_24x2_2494_24MkPair = heff_take_reuse_n(v_x2_2494, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2495}), v_s_2496});
    }
    default: return heff_nomatch(v_x2_2494);
    }
  }
  case TAG_EStr: {
    V v_m_2498 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2499)) {
    case TAG_MkPair: {
      V v_x_24100 = heff_field(v_x2_2499, 0);
      V v_s_24101 = heff_field(v_x2_2499, 1);
      V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24100}), v_s_24101});
    }
    default: return heff_nomatch(v_x2_2499);
    }
  }
  case TAG_EBytes: {
    V v_m_24103 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24104 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24104)) {
    case TAG_MkPair: {
      V v_x_24105 = heff_field(v_x2_24104, 0);
      V v_s_24106 = heff_field(v_x2_24104, 1);
      V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24105}), v_s_24106});
    }
    default: return heff_nomatch(v_x2_24104);
    }
  }
  case TAG_EFixed: {
    V v_m_24109 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24110)) {
    case TAG_MkPair: {
      V v_x_24111 = heff_field(v_x2_24110, 0);
      V v_s_24112 = heff_field(v_x2_24110, 1);
      V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24111}), v_s_24112});
    }
    default: return heff_nomatch(v_x2_24110);
    }
  }
  case TAG_EFloat32: {
    V v_m_24114 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_s_24117 = heff_field(v_x2_24115, 1);
      V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24116}), v_s_24117});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  case TAG_EAbandon: {
    V v_m_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_MkPair: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_s_24121 = heff_field(v_x2_24119, 1);
      V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24120}), v_s_24121});
    }
    default: return heff_nomatch(v_x2_24119);
    }
  }
  case TAG_EFix: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      V v_ru_24x2_24125_24MkPair = heff_take_reuse_n(v_x2_24125, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24126}), v_s_24127});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletSplit(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eeta_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_as_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eparamsAre(v_xs_244, v_as_2411));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2ecompile_2esimplify_2eetaHead(v_kinds_240, v_xs_244, v_f_2410));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_xs_244);
          heff_drop(v_as_2411);
          heff_drop_cell(v_ru_24e2_245_24EApp, 2);
          heff_drop(v_t_2413);
          return v_f_2410;
        } else {
          heff_drop(v_t_2413);
          return heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag_n(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
        }
      } else {
        heff_drop(v_t_2412);
        return heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag_n(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 4);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eeta(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_e1_2416 = heff_field(v_e_241, 0);
    V v_as_2417 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2416)) {
    case TAG_EVar: {
      V v_m_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2419, v_r_240, v_as_2417});
    }
    case TAG_EGlobal: {
      V v_m_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam5, 1, 3, (V[]){v_m_2430, v_r_240, v_as_2417});
    }
    case TAG_ELam: {
      V v_m_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2442, v_r_240, v_as_2417});
    }
    case TAG_EApp: {
      V v_e11_2452 = heff_dup(heff_field(v_e1_2416, 0));
      V v_bs_2453 = heff_dup(heff_field(v_e1_2416, 1));
      switch (heff_tag_of(v_e11_2452)) {
      case TAG_EVar: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2455, v_r_240, v_as_2417});
      }
      case TAG_EGlobal: {
        V v_g_2465 = heff_field(v_e11_2452, 0);
        heff_take_n(v_e11_2452, 1ULL, 1);
        heff_drop_tag(v_e1_2416, 2);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2453, v_g_2465, v_as_2417, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2483, v_r_240, v_as_2417});
      }
      case TAG_EApp: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2495, v_r_240, v_as_2417});
      }
      case TAG_ELet: {
        heff_take_n(v_e11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24108 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24108, v_r_240, v_as_2417});
      }
      case TAG_ERecord: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24120 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24120, v_r_240, v_as_2417});
      }
      case TAG_EProj: {
        heff_take_n(v_e11_2452, 0ULL, 4);
        heff_drop(v_bs_2453);
        V v_m_24134 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24134, v_r_240, v_as_2417});
      }
      case TAG_ETag: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24146, v_r_240, v_as_2417});
      }
      case TAG_EMatch: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24158 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24158, v_r_240, v_as_2417});
      }
      case TAG_EPrim: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24169 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24169, v_r_240, v_as_2417});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24181 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24181, v_r_240, v_as_2417});
      }
      case TAG_ECall: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24193 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24193, v_r_240, v_as_2417});
      }
      case TAG_EInt: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24204 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24204, v_r_240, v_as_2417});
      }
      case TAG_EFloat: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24215 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24215, v_r_240, v_as_2417});
      }
      case TAG_EStr: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24226 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24226, v_r_240, v_as_2417});
      }
      case TAG_EBytes: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24237 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24237, v_r_240, v_as_2417});
      }
      case TAG_EFixed: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24249, v_r_240, v_as_2417});
      }
      case TAG_EFloat32: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24260 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24260, v_r_240, v_as_2417});
      }
      case TAG_EAbandon: {
        heff_drop(v_bs_2453);
        V v_m_24270 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24270, v_r_240, v_as_2417});
      }
      case TAG_EFix: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24282 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24282, v_r_240, v_as_2417});
      }
      default: return heff_nomatch(v_e11_2452);
      }
    }
    case TAG_ELet: {
      V v_m_24295 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24295, v_r_240, v_as_2417});
    }
    case TAG_ERecord: {
      V v_m_24307 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24307, v_r_240, v_as_2417});
    }
    case TAG_EProj: {
      V v_m_24321 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24321, v_r_240, v_as_2417});
    }
    case TAG_ETag: {
      V v_m_24333 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24333, v_r_240, v_as_2417});
    }
    case TAG_EMatch: {
      V v_m_24345 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24345, v_r_240, v_as_2417});
    }
    case TAG_EPrim: {
      V v_m_24356 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24356, v_r_240, v_as_2417});
    }
    case TAG_EPrimCall: {
      V v_m_24368 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24368, v_r_240, v_as_2417});
    }
    case TAG_ECall: {
      V v_m_24380 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24380, v_r_240, v_as_2417});
    }
    case TAG_EInt: {
      V v_m_24391 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24391, v_r_240, v_as_2417});
    }
    case TAG_EFloat: {
      V v_m_24402 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24402, v_r_240, v_as_2417});
    }
    case TAG_EStr: {
      V v_m_24413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam69, 1, 3, (V[]){v_m_24413, v_r_240, v_as_2417});
    }
    case TAG_EBytes: {
      V v_m_24424 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam71, 1, 3, (V[]){v_m_24424, v_r_240, v_as_2417});
    }
    case TAG_EFixed: {
      V v_m_24436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24436, v_r_240, v_as_2417});
    }
    case TAG_EFloat32: {
      V v_m_24447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam75, 1, 3, (V[]){v_m_24447, v_r_240, v_as_2417});
    }
    case TAG_EAbandon: {
      V v_m_24457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam77, 1, 3, (V[]){v_m_24457, v_r_240, v_as_2417});
    }
    case TAG_EFix: {
      V v_m_24469 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam79, 1, 3, (V[]){v_m_24469, v_r_240, v_as_2417});
    }
    default: return heff_nomatch(v_e1_2416);
    }
  }
  case TAG_ELet: {
    V v_x_24479 = heff_field(v_e_241, 0);
    V v_a_24480 = heff_field(v_e_241, 1);
    V v_b_24481 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24482 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24480}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam81, 1, 4, (V[]){v_m_24482, v_r_240, v_x_24479, v_b_24481});
  }
  case TAG_ERecord: {
    V v_fs_24488 = heff_field(v_e_241, 0);
    V v_ts_24489 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24498 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam82, 1, 1, (V[]){v_r_240}), v_fs_24488));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam84, 1, 2, (V[]){v_m_24498, v_ts_24489});
  }
  case TAG_EProj: {
    V v_e2_24503 = heff_field(v_e_241, 0);
    V v_l_24504 = heff_field(v_e_241, 1);
    V v_sh_24505 = heff_field(v_e_241, 2);
    V v_t_24506 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_24507 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e2_24503}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam85, 1, 5, (V[]){v_m_24507, v_r_240, v_l_24504, v_sh_24505, v_t_24506});
  }
  case TAG_ETag: {
    V v_t_24512 = heff_field(v_e_241, 0);
    V v_as_24513 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24515 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam86, 1, 1, (V[]){v_r_240}), v_as_24513));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam87, 1, 2, (V[]){v_m_24515, v_t_24512});
  }
  case TAG_EMatch: {
    V v_s_24520 = heff_field(v_e_241, 0);
    V v_arms_24521 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24522 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24520}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam88, 1, 3, (V[]){v_m_24522, v_r_240, v_arms_24521});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam91, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24542 = heff_field(v_e_241, 0);
    V v_as_24543 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24545 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam92, 1, 1, (V[]){v_r_240}), v_as_24543));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam93, 1, 2, (V[]){v_m_24545, v_p_24542});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam94, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam95, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam96, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam97, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam98, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam99, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam100, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam101, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam102, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_2412, 7)), 1, 7);
    V v_t_2414 = (g_heff_2ecompile_2esimplify_2elam(v_xs_246, v_x_2411));
    V v_x_2415 = ({ V a_0 = v_t_2413; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_s_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_s_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_m_2425 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_s_2423}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_s_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2422;
      heff_room[1] = v_x_2427;
      heff_room[2] = v_s_2428;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_a_2435 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    heff_take_n(v_x2_2432, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam6, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2433;
      heff_room[1] = v_x_2438;
      heff_room[2] = v_s_2439;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_s_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_s_2446 = heff_field(v_x2_2444, 1);
    heff_take_n(v_x2_2444, 3ULL, 2);
    V v_m_2448 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2446}));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_s_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2445;
      heff_room[1] = v_x_2450;
      heff_room[2] = v_s_2451;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2460 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_s_2459}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2458;
      heff_room[1] = v_x_2463;
      heff_room[2] = v_s_2464;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2476 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_bs_2453 = heff_env(self)[0];
  V v_g_2465 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_bs_2453));
  V v_t_2468 = (g_heff_2ecompile_2esimplify_2etakesMore(heff_dup(v_s_2466), heff_dup(v_g_2465), v_t_2467));
  if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
    heff_drop(v_t_2468);
    V v_t_2469 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2453, v_as_2417));
    V v_t_2470 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2465}), v_t_2469});
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_s_2466;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2468);
    V v_t_2471 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2465}), v_bs_2453});
    V v_m_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2471}));
    V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_s_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      V v_m_2477 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
      V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_s_2475}));
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_MkPair: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        V v_s_2480 = heff_field(v_x2_2478, 1);
        heff_take_n(v_x2_2478, 3ULL, 2);
        V f_ = heff_get_n(v_r_240, 1, 4);
        heff_room[0] = v_x_2474;
        heff_room[1] = v_x_2479;
        heff_room[2] = v_s_2480;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      default: return heff_nomatch(v_x2_2478);
      }
    }
    default: return heff_nomatch(v_x2_2473);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2488 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2488;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_s_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_s_2487 = heff_field(v_x2_2485, 1);
    heff_take_n(v_x2_2485, 3ULL, 2);
    V v_m_2489 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2487}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2486;
      heff_room[1] = v_x_2491;
      heff_room[2] = v_s_2492;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_24100 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24100;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    heff_take_n(v_x2_2497, 3ULL, 2);
    V v_m_24101 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24102 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_s_2499}));
    switch (heff_tag_of(v_x2_24102)) {
    case TAG_MkPair: {
      V v_x_24103 = heff_field(v_x2_24102, 0);
      V v_s_24104 = heff_field(v_x2_24102, 1);
      heff_take_n(v_x2_24102, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2498;
      heff_room[1] = v_x_24103;
      heff_room[2] = v_s_24104;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24102);
    }
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24113 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24113;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_s_24109}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_MkPair: {
    V v_x_24111 = heff_field(v_x2_24110, 0);
    V v_s_24112 = heff_field(v_x2_24110, 1);
    heff_take_n(v_x2_24110, 3ULL, 2);
    V v_m_24114 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_s_24112}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_s_24117 = heff_field(v_x2_24115, 1);
      heff_take_n(v_x2_24115, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24111;
      heff_room[1] = v_x_24116;
      heff_room[2] = v_s_24117;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24125 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24125;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_s_24124 = heff_field(v_x2_24122, 1);
    heff_take_n(v_x2_24122, 3ULL, 2);
    V v_m_24126 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24127 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24124}));
    switch (heff_tag_of(v_x2_24127)) {
    case TAG_MkPair: {
      V v_x_24128 = heff_field(v_x2_24127, 0);
      V v_s_24129 = heff_field(v_x2_24127, 1);
      heff_take_n(v_x2_24127, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24123;
      heff_room[1] = v_x_24128;
      heff_room[2] = v_s_24129;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24127);
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24139 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24139;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    heff_take_n(v_x2_24136, 3ULL, 2);
    V v_m_24140 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_s_24138}));
    switch (heff_tag_of(v_x2_24141)) {
    case TAG_MkPair: {
      V v_x_24142 = heff_field(v_x2_24141, 0);
      V v_s_24143 = heff_field(v_x2_24141, 1);
      heff_take_n(v_x2_24141, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24137;
      heff_room[1] = v_x_24142;
      heff_room[2] = v_s_24143;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24141);
    }
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24151 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24151;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24147 = args[0];
  V v_m_24146 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24148 = heff_tr(heff_call(v_m_24146, 1, (V[]){v_s_24147}));
  switch (heff_tag_of(v_x2_24148)) {
  case TAG_MkPair: {
    V v_x_24149 = heff_field(v_x2_24148, 0);
    V v_s_24150 = heff_field(v_x2_24148, 1);
    heff_take_n(v_x2_24148, 3ULL, 2);
    V v_m_24152 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24153 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24150}));
    switch (heff_tag_of(v_x2_24153)) {
    case TAG_MkPair: {
      V v_x_24154 = heff_field(v_x2_24153, 0);
      V v_s_24155 = heff_field(v_x2_24153, 1);
      heff_take_n(v_x2_24153, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24149;
      heff_room[1] = v_x_24154;
      heff_room[2] = v_s_24155;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24153);
    }
  }
  default: return heff_nomatch(v_x2_24148);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24163 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24163;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24159 = args[0];
  V v_m_24158 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24160 = heff_tr(heff_call(v_m_24158, 1, (V[]){v_s_24159}));
  switch (heff_tag_of(v_x2_24160)) {
  case TAG_MkPair: {
    V v_x_24161 = heff_field(v_x2_24160, 0);
    V v_s_24162 = heff_field(v_x2_24160, 1);
    heff_take_n(v_x2_24160, 3ULL, 2);
    V v_m_24164 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24165 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_s_24162}));
    switch (heff_tag_of(v_x2_24165)) {
    case TAG_MkPair: {
      V v_x_24166 = heff_field(v_x2_24165, 0);
      V v_s_24167 = heff_field(v_x2_24165, 1);
      heff_take_n(v_x2_24165, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24161;
      heff_room[1] = v_x_24166;
      heff_room[2] = v_s_24167;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24165);
    }
  }
  default: return heff_nomatch(v_x2_24160);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24174 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24174;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24170 = args[0];
  V v_m_24169 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24171 = heff_tr(heff_call(v_m_24169, 1, (V[]){v_s_24170}));
  switch (heff_tag_of(v_x2_24171)) {
  case TAG_MkPair: {
    V v_x_24172 = heff_field(v_x2_24171, 0);
    V v_s_24173 = heff_field(v_x2_24171, 1);
    heff_take_n(v_x2_24171, 3ULL, 2);
    V v_m_24175 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24176 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_s_24173}));
    switch (heff_tag_of(v_x2_24176)) {
    case TAG_MkPair: {
      V v_x_24177 = heff_field(v_x2_24176, 0);
      V v_s_24178 = heff_field(v_x2_24176, 1);
      heff_take_n(v_x2_24176, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24172;
      heff_room[1] = v_x_24177;
      heff_room[2] = v_s_24178;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24176);
    }
  }
  default: return heff_nomatch(v_x2_24171);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24186 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24186;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_s_24182}));
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    heff_take_n(v_x2_24183, 3ULL, 2);
    V v_m_24187 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24188 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_s_24185}));
    switch (heff_tag_of(v_x2_24188)) {
    case TAG_MkPair: {
      V v_x_24189 = heff_field(v_x2_24188, 0);
      V v_s_24190 = heff_field(v_x2_24188, 1);
      heff_take_n(v_x2_24188, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24184;
      heff_room[1] = v_x_24189;
      heff_room[2] = v_s_24190;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24188);
    }
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24198 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24198;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_s_24194}));
  switch (heff_tag_of(v_x2_24195)) {
  case TAG_MkPair: {
    V v_x_24196 = heff_field(v_x2_24195, 0);
    V v_s_24197 = heff_field(v_x2_24195, 1);
    heff_take_n(v_x2_24195, 3ULL, 2);
    V v_m_24199 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24200 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_s_24197}));
    switch (heff_tag_of(v_x2_24200)) {
    case TAG_MkPair: {
      V v_x_24201 = heff_field(v_x2_24200, 0);
      V v_s_24202 = heff_field(v_x2_24200, 1);
      heff_take_n(v_x2_24200, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24196;
      heff_room[1] = v_x_24201;
      heff_room[2] = v_s_24202;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24200);
    }
  }
  default: return heff_nomatch(v_x2_24195);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24209 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24209;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24206 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_s_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_x2_24206, 0);
    V v_s_24208 = heff_field(v_x2_24206, 1);
    heff_take_n(v_x2_24206, 3ULL, 2);
    V v_m_24210 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24211 = heff_tr(heff_call(v_m_24210, 1, (V[]){v_s_24208}));
    switch (heff_tag_of(v_x2_24211)) {
    case TAG_MkPair: {
      V v_x_24212 = heff_field(v_x2_24211, 0);
      V v_s_24213 = heff_field(v_x2_24211, 1);
      heff_take_n(v_x2_24211, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24207;
      heff_room[1] = v_x_24212;
      heff_room[2] = v_s_24213;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24211);
    }
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24220 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24220;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24216 = args[0];
  V v_m_24215 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24217 = heff_tr(heff_call(v_m_24215, 1, (V[]){v_s_24216}));
  switch (heff_tag_of(v_x2_24217)) {
  case TAG_MkPair: {
    V v_x_24218 = heff_field(v_x2_24217, 0);
    V v_s_24219 = heff_field(v_x2_24217, 1);
    heff_take_n(v_x2_24217, 3ULL, 2);
    V v_m_24221 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24222 = heff_tr(heff_call(v_m_24221, 1, (V[]){v_s_24219}));
    switch (heff_tag_of(v_x2_24222)) {
    case TAG_MkPair: {
      V v_x_24223 = heff_field(v_x2_24222, 0);
      V v_s_24224 = heff_field(v_x2_24222, 1);
      heff_take_n(v_x2_24222, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24218;
      heff_room[1] = v_x_24223;
      heff_room[2] = v_s_24224;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24222);
    }
  }
  default: return heff_nomatch(v_x2_24217);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24231 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24231;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24227 = args[0];
  V v_m_24226 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24228 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_s_24227}));
  switch (heff_tag_of(v_x2_24228)) {
  case TAG_MkPair: {
    V v_x_24229 = heff_field(v_x2_24228, 0);
    V v_s_24230 = heff_field(v_x2_24228, 1);
    heff_take_n(v_x2_24228, 3ULL, 2);
    V v_m_24232 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24233 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_s_24230}));
    switch (heff_tag_of(v_x2_24233)) {
    case TAG_MkPair: {
      V v_x_24234 = heff_field(v_x2_24233, 0);
      V v_s_24235 = heff_field(v_x2_24233, 1);
      heff_take_n(v_x2_24233, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24229;
      heff_room[1] = v_x_24234;
      heff_room[2] = v_s_24235;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24233);
    }
  }
  default: return heff_nomatch(v_x2_24228);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24242 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_s_24238}));
  switch (heff_tag_of(v_x2_24239)) {
  case TAG_MkPair: {
    V v_x_24240 = heff_field(v_x2_24239, 0);
    V v_s_24241 = heff_field(v_x2_24239, 1);
    heff_take_n(v_x2_24239, 3ULL, 2);
    V v_m_24243 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24244 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_s_24241}));
    switch (heff_tag_of(v_x2_24244)) {
    case TAG_MkPair: {
      V v_x_24245 = heff_field(v_x2_24244, 0);
      V v_s_24246 = heff_field(v_x2_24244, 1);
      heff_take_n(v_x2_24244, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24240;
      heff_room[1] = v_x_24245;
      heff_room[2] = v_s_24246;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24244);
    }
  }
  default: return heff_nomatch(v_x2_24239);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24254 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24254;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24250 = args[0];
  V v_m_24249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24251 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_s_24250}));
  switch (heff_tag_of(v_x2_24251)) {
  case TAG_MkPair: {
    V v_x_24252 = heff_field(v_x2_24251, 0);
    V v_s_24253 = heff_field(v_x2_24251, 1);
    heff_take_n(v_x2_24251, 3ULL, 2);
    V v_m_24255 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24256 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_s_24253}));
    switch (heff_tag_of(v_x2_24256)) {
    case TAG_MkPair: {
      V v_x_24257 = heff_field(v_x2_24256, 0);
      V v_s_24258 = heff_field(v_x2_24256, 1);
      heff_take_n(v_x2_24256, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24252;
      heff_room[1] = v_x_24257;
      heff_room[2] = v_s_24258;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24256);
    }
  }
  default: return heff_nomatch(v_x2_24251);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24265 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24265;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_s_24261}));
  switch (heff_tag_of(v_x2_24262)) {
  case TAG_MkPair: {
    V v_x_24263 = heff_field(v_x2_24262, 0);
    V v_s_24264 = heff_field(v_x2_24262, 1);
    heff_take_n(v_x2_24262, 3ULL, 2);
    V v_m_24266 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24267 = heff_tr(heff_call(v_m_24266, 1, (V[]){v_s_24264}));
    switch (heff_tag_of(v_x2_24267)) {
    case TAG_MkPair: {
      V v_x_24268 = heff_field(v_x2_24267, 0);
      V v_s_24269 = heff_field(v_x2_24267, 1);
      heff_take_n(v_x2_24267, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24263;
      heff_room[1] = v_x_24268;
      heff_room[2] = v_s_24269;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24267);
    }
  }
  default: return heff_nomatch(v_x2_24262);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24275 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24275;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24271 = args[0];
  V v_m_24270 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24272 = heff_tr(heff_call(v_m_24270, 1, (V[]){v_s_24271}));
  switch (heff_tag_of(v_x2_24272)) {
  case TAG_MkPair: {
    V v_x_24273 = heff_field(v_x2_24272, 0);
    V v_s_24274 = heff_field(v_x2_24272, 1);
    heff_take_n(v_x2_24272, 3ULL, 2);
    V v_m_24276 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24277 = heff_tr(heff_call(v_m_24276, 1, (V[]){v_s_24274}));
    switch (heff_tag_of(v_x2_24277)) {
    case TAG_MkPair: {
      V v_x_24278 = heff_field(v_x2_24277, 0);
      V v_s_24279 = heff_field(v_x2_24277, 1);
      heff_take_n(v_x2_24277, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24273;
      heff_room[1] = v_x_24278;
      heff_room[2] = v_s_24279;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24277);
    }
  }
  default: return heff_nomatch(v_x2_24272);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24287 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24287;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24283 = args[0];
  V v_m_24282 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24284 = heff_tr(heff_call(v_m_24282, 1, (V[]){v_s_24283}));
  switch (heff_tag_of(v_x2_24284)) {
  case TAG_MkPair: {
    V v_x_24285 = heff_field(v_x2_24284, 0);
    V v_s_24286 = heff_field(v_x2_24284, 1);
    heff_take_n(v_x2_24284, 3ULL, 2);
    V v_m_24288 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24289 = heff_tr(heff_call(v_m_24288, 1, (V[]){v_s_24286}));
    switch (heff_tag_of(v_x2_24289)) {
    case TAG_MkPair: {
      V v_x_24290 = heff_field(v_x2_24289, 0);
      V v_s_24291 = heff_field(v_x2_24289, 1);
      heff_take_n(v_x2_24289, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24285;
      heff_room[1] = v_x_24290;
      heff_room[2] = v_s_24291;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24289);
    }
  }
  default: return heff_nomatch(v_x2_24284);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24300 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24300;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_s_24296}));
  switch (heff_tag_of(v_x2_24297)) {
  case TAG_MkPair: {
    V v_x_24298 = heff_field(v_x2_24297, 0);
    V v_s_24299 = heff_field(v_x2_24297, 1);
    heff_take_n(v_x2_24297, 3ULL, 2);
    V v_m_24301 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24302 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_s_24299}));
    switch (heff_tag_of(v_x2_24302)) {
    case TAG_MkPair: {
      V v_x_24303 = heff_field(v_x2_24302, 0);
      V v_s_24304 = heff_field(v_x2_24302, 1);
      heff_take_n(v_x2_24302, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24298;
      heff_room[1] = v_x_24303;
      heff_room[2] = v_s_24304;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24302);
    }
  }
  default: return heff_nomatch(v_x2_24297);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24312 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24312;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24308 = args[0];
  V v_m_24307 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24309 = heff_tr(heff_call(v_m_24307, 1, (V[]){v_s_24308}));
  switch (heff_tag_of(v_x2_24309)) {
  case TAG_MkPair: {
    V v_x_24310 = heff_field(v_x2_24309, 0);
    V v_s_24311 = heff_field(v_x2_24309, 1);
    heff_take_n(v_x2_24309, 3ULL, 2);
    V v_m_24313 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24314 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_s_24311}));
    switch (heff_tag_of(v_x2_24314)) {
    case TAG_MkPair: {
      V v_x_24315 = heff_field(v_x2_24314, 0);
      V v_s_24316 = heff_field(v_x2_24314, 1);
      heff_take_n(v_x2_24314, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24310;
      heff_room[1] = v_x_24315;
      heff_room[2] = v_s_24316;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24314);
    }
  }
  default: return heff_nomatch(v_x2_24309);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24326 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24326;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24322 = args[0];
  V v_m_24321 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24323 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_s_24322}));
  switch (heff_tag_of(v_x2_24323)) {
  case TAG_MkPair: {
    V v_x_24324 = heff_field(v_x2_24323, 0);
    V v_s_24325 = heff_field(v_x2_24323, 1);
    heff_take_n(v_x2_24323, 3ULL, 2);
    V v_m_24327 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24328 = heff_tr(heff_call(v_m_24327, 1, (V[]){v_s_24325}));
    switch (heff_tag_of(v_x2_24328)) {
    case TAG_MkPair: {
      V v_x_24329 = heff_field(v_x2_24328, 0);
      V v_s_24330 = heff_field(v_x2_24328, 1);
      heff_take_n(v_x2_24328, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24324;
      heff_room[1] = v_x_24329;
      heff_room[2] = v_s_24330;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24328);
    }
  }
  default: return heff_nomatch(v_x2_24323);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24338 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24338;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24334 = args[0];
  V v_m_24333 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24335 = heff_tr(heff_call(v_m_24333, 1, (V[]){v_s_24334}));
  switch (heff_tag_of(v_x2_24335)) {
  case TAG_MkPair: {
    V v_x_24336 = heff_field(v_x2_24335, 0);
    V v_s_24337 = heff_field(v_x2_24335, 1);
    heff_take_n(v_x2_24335, 3ULL, 2);
    V v_m_24339 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24340 = heff_tr(heff_call(v_m_24339, 1, (V[]){v_s_24337}));
    switch (heff_tag_of(v_x2_24340)) {
    case TAG_MkPair: {
      V v_x_24341 = heff_field(v_x2_24340, 0);
      V v_s_24342 = heff_field(v_x2_24340, 1);
      heff_take_n(v_x2_24340, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24336;
      heff_room[1] = v_x_24341;
      heff_room[2] = v_s_24342;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24340);
    }
  }
  default: return heff_nomatch(v_x2_24335);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24350 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24350;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24346 = args[0];
  V v_m_24345 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24347 = heff_tr(heff_call(v_m_24345, 1, (V[]){v_s_24346}));
  switch (heff_tag_of(v_x2_24347)) {
  case TAG_MkPair: {
    V v_x_24348 = heff_field(v_x2_24347, 0);
    V v_s_24349 = heff_field(v_x2_24347, 1);
    heff_take_n(v_x2_24347, 3ULL, 2);
    V v_m_24351 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24352 = heff_tr(heff_call(v_m_24351, 1, (V[]){v_s_24349}));
    switch (heff_tag_of(v_x2_24352)) {
    case TAG_MkPair: {
      V v_x_24353 = heff_field(v_x2_24352, 0);
      V v_s_24354 = heff_field(v_x2_24352, 1);
      heff_take_n(v_x2_24352, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24348;
      heff_room[1] = v_x_24353;
      heff_room[2] = v_s_24354;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24352);
    }
  }
  default: return heff_nomatch(v_x2_24347);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24361 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24361;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_s_24357}));
  switch (heff_tag_of(v_x2_24358)) {
  case TAG_MkPair: {
    V v_x_24359 = heff_field(v_x2_24358, 0);
    V v_s_24360 = heff_field(v_x2_24358, 1);
    heff_take_n(v_x2_24358, 3ULL, 2);
    V v_m_24362 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24363 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_s_24360}));
    switch (heff_tag_of(v_x2_24363)) {
    case TAG_MkPair: {
      V v_x_24364 = heff_field(v_x2_24363, 0);
      V v_s_24365 = heff_field(v_x2_24363, 1);
      heff_take_n(v_x2_24363, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24359;
      heff_room[1] = v_x_24364;
      heff_room[2] = v_s_24365;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24363);
    }
  }
  default: return heff_nomatch(v_x2_24358);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24373 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24373;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24369 = args[0];
  V v_m_24368 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24370 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_s_24369}));
  switch (heff_tag_of(v_x2_24370)) {
  case TAG_MkPair: {
    V v_x_24371 = heff_field(v_x2_24370, 0);
    V v_s_24372 = heff_field(v_x2_24370, 1);
    heff_take_n(v_x2_24370, 3ULL, 2);
    V v_m_24374 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24375 = heff_tr(heff_call(v_m_24374, 1, (V[]){v_s_24372}));
    switch (heff_tag_of(v_x2_24375)) {
    case TAG_MkPair: {
      V v_x_24376 = heff_field(v_x2_24375, 0);
      V v_s_24377 = heff_field(v_x2_24375, 1);
      heff_take_n(v_x2_24375, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24371;
      heff_room[1] = v_x_24376;
      heff_room[2] = v_s_24377;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24375);
    }
  }
  default: return heff_nomatch(v_x2_24370);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24385 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24385;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24381 = args[0];
  V v_m_24380 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24382 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_s_24381}));
  switch (heff_tag_of(v_x2_24382)) {
  case TAG_MkPair: {
    V v_x_24383 = heff_field(v_x2_24382, 0);
    V v_s_24384 = heff_field(v_x2_24382, 1);
    heff_take_n(v_x2_24382, 3ULL, 2);
    V v_m_24386 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24387 = heff_tr(heff_call(v_m_24386, 1, (V[]){v_s_24384}));
    switch (heff_tag_of(v_x2_24387)) {
    case TAG_MkPair: {
      V v_x_24388 = heff_field(v_x2_24387, 0);
      V v_s_24389 = heff_field(v_x2_24387, 1);
      heff_take_n(v_x2_24387, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24383;
      heff_room[1] = v_x_24388;
      heff_room[2] = v_s_24389;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24387);
    }
  }
  default: return heff_nomatch(v_x2_24382);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24396 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24396;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24392 = args[0];
  V v_m_24391 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24393 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_s_24392}));
  switch (heff_tag_of(v_x2_24393)) {
  case TAG_MkPair: {
    V v_x_24394 = heff_field(v_x2_24393, 0);
    V v_s_24395 = heff_field(v_x2_24393, 1);
    heff_take_n(v_x2_24393, 3ULL, 2);
    V v_m_24397 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24398 = heff_tr(heff_call(v_m_24397, 1, (V[]){v_s_24395}));
    switch (heff_tag_of(v_x2_24398)) {
    case TAG_MkPair: {
      V v_x_24399 = heff_field(v_x2_24398, 0);
      V v_s_24400 = heff_field(v_x2_24398, 1);
      heff_take_n(v_x2_24398, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24394;
      heff_room[1] = v_x_24399;
      heff_room[2] = v_s_24400;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24398);
    }
  }
  default: return heff_nomatch(v_x2_24393);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24407 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24407;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_s_24403}));
  switch (heff_tag_of(v_x2_24404)) {
  case TAG_MkPair: {
    V v_x_24405 = heff_field(v_x2_24404, 0);
    V v_s_24406 = heff_field(v_x2_24404, 1);
    heff_take_n(v_x2_24404, 3ULL, 2);
    V v_m_24408 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24409 = heff_tr(heff_call(v_m_24408, 1, (V[]){v_s_24406}));
    switch (heff_tag_of(v_x2_24409)) {
    case TAG_MkPair: {
      V v_x_24410 = heff_field(v_x2_24409, 0);
      V v_s_24411 = heff_field(v_x2_24409, 1);
      heff_take_n(v_x2_24409, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24405;
      heff_room[1] = v_x_24410;
      heff_room[2] = v_s_24411;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24409);
    }
  }
  default: return heff_nomatch(v_x2_24404);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_a_24418 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24414 = args[0];
  V v_m_24413 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24415 = heff_tr(heff_call(v_m_24413, 1, (V[]){v_s_24414}));
  switch (heff_tag_of(v_x2_24415)) {
  case TAG_MkPair: {
    V v_x_24416 = heff_field(v_x2_24415, 0);
    V v_s_24417 = heff_field(v_x2_24415, 1);
    heff_take_n(v_x2_24415, 3ULL, 2);
    V v_m_24419 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam70, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24420 = heff_tr(heff_call(v_m_24419, 1, (V[]){v_s_24417}));
    switch (heff_tag_of(v_x2_24420)) {
    case TAG_MkPair: {
      V v_x_24421 = heff_field(v_x2_24420, 0);
      V v_s_24422 = heff_field(v_x2_24420, 1);
      heff_take_n(v_x2_24420, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24416;
      heff_room[1] = v_x_24421;
      heff_room[2] = v_s_24422;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24420);
    }
  }
  default: return heff_nomatch(v_x2_24415);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_a_24429 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24425 = args[0];
  V v_m_24424 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24426 = heff_tr(heff_call(v_m_24424, 1, (V[]){v_s_24425}));
  switch (heff_tag_of(v_x2_24426)) {
  case TAG_MkPair: {
    V v_x_24427 = heff_field(v_x2_24426, 0);
    V v_s_24428 = heff_field(v_x2_24426, 1);
    heff_take_n(v_x2_24426, 3ULL, 2);
    V v_m_24430 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam72, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24431 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_s_24428}));
    switch (heff_tag_of(v_x2_24431)) {
    case TAG_MkPair: {
      V v_x_24432 = heff_field(v_x2_24431, 0);
      V v_s_24433 = heff_field(v_x2_24431, 1);
      heff_take_n(v_x2_24431, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24427;
      heff_room[1] = v_x_24432;
      heff_room[2] = v_s_24433;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24431);
    }
  }
  default: return heff_nomatch(v_x2_24426);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24441 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24437 = args[0];
  V v_m_24436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24438 = heff_tr(heff_call(v_m_24436, 1, (V[]){v_s_24437}));
  switch (heff_tag_of(v_x2_24438)) {
  case TAG_MkPair: {
    V v_x_24439 = heff_field(v_x2_24438, 0);
    V v_s_24440 = heff_field(v_x2_24438, 1);
    heff_take_n(v_x2_24438, 3ULL, 2);
    V v_m_24442 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam74, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24443 = heff_tr(heff_call(v_m_24442, 1, (V[]){v_s_24440}));
    switch (heff_tag_of(v_x2_24443)) {
    case TAG_MkPair: {
      V v_x_24444 = heff_field(v_x2_24443, 0);
      V v_s_24445 = heff_field(v_x2_24443, 1);
      heff_take_n(v_x2_24443, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24439;
      heff_room[1] = v_x_24444;
      heff_room[2] = v_s_24445;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24443);
    }
  }
  default: return heff_nomatch(v_x2_24438);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_a_24452 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24448 = args[0];
  V v_m_24447 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24449 = heff_tr(heff_call(v_m_24447, 1, (V[]){v_s_24448}));
  switch (heff_tag_of(v_x2_24449)) {
  case TAG_MkPair: {
    V v_x_24450 = heff_field(v_x2_24449, 0);
    V v_s_24451 = heff_field(v_x2_24449, 1);
    heff_take_n(v_x2_24449, 3ULL, 2);
    V v_m_24453 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam76, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24454 = heff_tr(heff_call(v_m_24453, 1, (V[]){v_s_24451}));
    switch (heff_tag_of(v_x2_24454)) {
    case TAG_MkPair: {
      V v_x_24455 = heff_field(v_x2_24454, 0);
      V v_s_24456 = heff_field(v_x2_24454, 1);
      heff_take_n(v_x2_24454, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24450;
      heff_room[1] = v_x_24455;
      heff_room[2] = v_s_24456;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24454);
    }
  }
  default: return heff_nomatch(v_x2_24449);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_a_24462 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_s_24458 = args[0];
  V v_m_24457 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24459 = heff_tr(heff_call(v_m_24457, 1, (V[]){v_s_24458}));
  switch (heff_tag_of(v_x2_24459)) {
  case TAG_MkPair: {
    V v_x_24460 = heff_field(v_x2_24459, 0);
    V v_s_24461 = heff_field(v_x2_24459, 1);
    heff_take_n(v_x2_24459, 3ULL, 2);
    V v_m_24463 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam78, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24464 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_s_24461}));
    switch (heff_tag_of(v_x2_24464)) {
    case TAG_MkPair: {
      V v_x_24465 = heff_field(v_x2_24464, 0);
      V v_s_24466 = heff_field(v_x2_24464, 1);
      heff_take_n(v_x2_24464, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24460;
      heff_room[1] = v_x_24465;
      heff_room[2] = v_s_24466;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24464);
    }
  }
  default: return heff_nomatch(v_x2_24459);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_a_24474 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24470 = args[0];
  V v_m_24469 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24471 = heff_tr(heff_call(v_m_24469, 1, (V[]){v_s_24470}));
  switch (heff_tag_of(v_x2_24471)) {
  case TAG_MkPair: {
    V v_x_24472 = heff_field(v_x2_24471, 0);
    V v_s_24473 = heff_field(v_x2_24471, 1);
    heff_take_n(v_x2_24471, 3ULL, 2);
    V v_m_24475 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam80, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24476 = heff_tr(heff_call(v_m_24475, 1, (V[]){v_s_24473}));
    switch (heff_tag_of(v_x2_24476)) {
    case TAG_MkPair: {
      V v_x_24477 = heff_field(v_x2_24476, 0);
      V v_s_24478 = heff_field(v_x2_24476, 1);
      heff_take_n(v_x2_24476, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24472;
      heff_room[1] = v_x_24477;
      heff_room[2] = v_s_24478;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24476);
    }
  }
  default: return heff_nomatch(v_x2_24471);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24483 = args[0];
  V v_m_24482 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24479 = heff_env(self)[2];
  V v_b_24481 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24484 = heff_tr(heff_call(v_m_24482, 1, (V[]){v_s_24483}));
  switch (heff_tag_of(v_x2_24484)) {
  case TAG_MkPair: {
    V v_x_24485 = heff_field(v_x2_24484, 0);
    V v_s_24486 = heff_field(v_x2_24484, 1);
    heff_take_n(v_x2_24484, 3ULL, 2);
    V v_t_24487 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_24479, v_x_24485, v_b_24481));
    V f_ = v_t_24487;
    args[0] = v_s_24486;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24484);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24494 = args[0];
  V v_m_24493 = heff_env(self)[0];
  V v_l_24491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24495 = heff_tr(heff_call(v_m_24493, 1, (V[]){v_s_24494}));
  switch (heff_tag_of(v_x2_24495)) {
  case TAG_MkPair: {
    V v_x_24496 = heff_field(v_x2_24495, 0);
    V v_s_24497 = heff_field(v_x2_24495, 1);
    V v_ru_24x2_24495_24MkPair = heff_take_reuse_n(v_x2_24495, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24491, v_x_24496}), v_s_24497});
  }
  default: return heff_nomatch(v_x2_24495);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_p_24490 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24490)) {
  case TAG_MkPair: {
    V v_l_24491 = heff_field(v_p_24490, 0);
    V v_e_24492 = heff_field(v_p_24490, 1);
    heff_take_n(v_p_24490, 3ULL, 2);
    V v_m_24493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_e_24492}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam83, 1, 2, (V[]){v_m_24493, v_l_24491});
  }
  default: return heff_nomatch(v_p_24490);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_s_24499 = args[0];
  V v_m_24498 = heff_env(self)[0];
  V v_ts_24489 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24500 = heff_tr(heff_call(v_m_24498, 1, (V[]){v_s_24499}));
  switch (heff_tag_of(v_x2_24500)) {
  case TAG_MkPair: {
    V v_x_24501 = heff_field(v_x2_24500, 0);
    V v_s_24502 = heff_field(v_x2_24500, 1);
    V v_ru_24x2_24500_24MkPair = heff_take_reuse_n(v_x2_24500, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24500_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_24501, v_ts_24489}), v_s_24502});
  }
  default: return heff_nomatch(v_x2_24500);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_s_24508 = args[0];
  V v_m_24507 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24504 = heff_env(self)[2];
  V v_sh_24505 = heff_env(self)[3];
  V v_t_24506 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24509 = heff_tr(heff_call(v_m_24507, 1, (V[]){v_s_24508}));
  switch (heff_tag_of(v_x2_24509)) {
  case TAG_MkPair: {
    V v_x_24510 = heff_field(v_x2_24509, 0);
    V v_s_24511 = heff_field(v_x2_24509, 1);
    heff_take_n(v_x2_24509, 3ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 5, (V[]){v_l_24504, v_sh_24505, v_t_24506, v_x_24510, v_s_24511});
  }
  default: return heff_nomatch(v_x2_24509);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_a_24514 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24514;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24516 = args[0];
  V v_m_24515 = heff_env(self)[0];
  V v_t_24512 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24517 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_s_24516}));
  switch (heff_tag_of(v_x2_24517)) {
  case TAG_MkPair: {
    V v_x_24518 = heff_field(v_x2_24517, 0);
    V v_s_24519 = heff_field(v_x2_24517, 1);
    V v_ru_24x2_24517_24MkPair = heff_take_reuse_n(v_x2_24517, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24517_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_24512, v_x_24518}), v_s_24519});
  }
  default: return heff_nomatch(v_x2_24517);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args) {
  V v_s_24532 = args[0];
  V v_m_24531 = heff_env(self)[0];
  V v_t_24528 = heff_env(self)[1];
  V v_vs_24529 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24533 = heff_tr(heff_call(v_m_24531, 1, (V[]){v_s_24532}));
  switch (heff_tag_of(v_x2_24533)) {
  case TAG_MkPair: {
    V v_x_24534 = heff_field(v_x2_24533, 0);
    V v_s_24535 = heff_field(v_x2_24533, 1);
    V v_ru_24x2_24533_24MkPair = heff_take_reuse_n(v_x2_24533, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24533_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24528, v_vs_24529, v_x_24534}), v_s_24535});
  }
  default: return heff_nomatch(v_x2_24533);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args) {
  V v_a_24527 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24527)) {
  case TAG_MkArm: {
    V v_t_24528 = heff_field(v_a_24527, 0);
    V v_vs_24529 = heff_field(v_a_24527, 1);
    V v_b_24530 = heff_field(v_a_24527, 2);
    heff_take_n(v_a_24527, 7ULL, 3);
    V v_m_24531 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24530}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam90, 1, 3, (V[]){v_m_24531, v_t_24528, v_vs_24529});
  }
  default: return heff_nomatch(v_a_24527);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args) {
  V v_s_24523 = args[0];
  V v_m_24522 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24521 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24524 = heff_tr(heff_call(v_m_24522, 1, (V[]){v_s_24523}));
  switch (heff_tag_of(v_x2_24524)) {
  case TAG_MkPair: {
    V v_x_24525 = heff_field(v_x2_24524, 0);
    V v_s_24526 = heff_field(v_x2_24524, 1);
    heff_take_n(v_x2_24524, 3ULL, 2);
    V v_m_24536 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam89, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24521));
    V v_x2_24537 = heff_tr(heff_call(v_m_24536, 1, (V[]){v_s_24526}));
    switch (heff_tag_of(v_x2_24537)) {
    case TAG_MkPair: {
      V v_x_24538 = heff_field(v_x2_24537, 0);
      V v_s_24539 = heff_field(v_x2_24537, 1);
      heff_take_n(v_x2_24537, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 3, 4);
      heff_room[0] = v_x_24525;
      heff_room[1] = v_x_24538;
      heff_room[2] = v_s_24539;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24537);
    }
  }
  default: return heff_nomatch(v_x2_24524);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args) {
  V v_s_24541 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24541});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args) {
  V v_a_24544 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24544;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args) {
  V v_s_24546 = args[0];
  V v_m_24545 = heff_env(self)[0];
  V v_p_24542 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24547 = heff_tr(heff_call(v_m_24545, 1, (V[]){v_s_24546}));
  switch (heff_tag_of(v_x2_24547)) {
  case TAG_MkPair: {
    V v_x_24548 = heff_field(v_x2_24547, 0);
    V v_s_24549 = heff_field(v_x2_24547, 1);
    V v_ru_24x2_24547_24MkPair = heff_take_reuse_n(v_x2_24547, 3ULL, 2);
    V v_x2_24556;
    switch (heff_tag_of(v_x_24548)) {
    case TAG_Nil: {
      v_x2_24556 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_24550 = heff_dup(heff_field(v_x_24548, 0));
      V v_x22_24551 = heff_dup(heff_field(v_x_24548, 1));
      switch (heff_tag_of(v_x22_24551)) {
      case TAG_Nil: {
        v_x2_24556 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_24542), v_a_24550));
        break;
      }
      case TAG_Cons: {
        V v_b_24552 = heff_field(v_x22_24551, 0);
        V v_x222_24553 = heff_field(v_x22_24551, 1);
        heff_take_n(v_x22_24551, 3ULL, 2);
        switch (heff_tag_of(v_x222_24553)) {
        case TAG_Nil: {
          v_x2_24556 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_24542), v_a_24550, v_b_24552));
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x222_24553, 0ULL, 2);
          heff_drop(v_a_24550);
          heff_drop(v_b_24552);
          v_x2_24556 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x222_24553);
        }
        break;
      }
      default: heff_nomatch(v_x22_24551);
      }
      break;
    }
    default: heff_nomatch(v_x_24548);
    }
    V v_x_24558;
    switch (heff_tag_of(v_x2_24556)) {
    case TAG_Nothing: {
      v_x_24558 = heff_tag_at_n(v_ru_24x2_24547_24MkPair, TAG_EPrimCall, 2, (V[]){v_p_24542, v_x_24548});
      break;
    }
    case TAG_Just: {
      V v_x_24557 = heff_field(v_x2_24556, 0);
      heff_take_n(v_x2_24556, 1ULL, 1);
      heff_drop(v_p_24542);
      heff_drop(v_x_24548);
      heff_drop_cell(v_ru_24x2_24547_24MkPair, 2);
      v_x_24558 = v_x_24557;
      break;
    }
    default: heff_nomatch(v_x2_24556);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24558, v_s_24549});
  }
  default: return heff_nomatch(v_x2_24547);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args) {
  V v_s_24561 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24561});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args) {
  V v_s_24563 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24563});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args) {
  V v_s_24565 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24565});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args) {
  V v_s_24567 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24567});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args) {
  V v_s_24569 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24569});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args) {
  V v_s_24572 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24572});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args) {
  V v_s_24574 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24574});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args) {
  V v_s_24575 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24575});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args) {
  V v_s_24578 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24578});
}
Clo g_heff_2ecompile_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_242), heff_rfield(v_s_244, 2)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2eknown(v_g_242, v_s_244));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 4);
        V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_s_248});
      }
      case TAG_Just: {
        V v_b_2410 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V v_t_2411 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2410, v_as_243}));
        return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2411, v_t_2412, v_s_248));
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  case TAG_Just: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, NTAG(TAG_Nil)});
    V v_x_2415 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2einlineMax_get()), MK_INT(0LL), v_t_2414));
    if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2einlineMax_get()), v_x_2415)) {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_g_242);
      V v_x_2417 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_244});
    } else {
      V v_x2_2418 = (g_heff_2ecompile_2esimplify_2eknown(v_g_242, v_s_244));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_s_2420 = heff_field(v_x2_2418, 1);
        V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
        switch (heff_tag_of(v_x_2419)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2421 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2420});
        }
        case TAG_Just: {
          V v_b_2422 = heff_field(v_x_2419, 0);
          heff_take_n(v_x_2419, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
          V v_t_2423 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
          V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2422, v_as_243}));
          return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2423, v_t_2424, v_s_2420));
        }
        default: return heff_nomatch(v_x_2419);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlineCall(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str0, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str2, 1, "/");
Clo g_heff_2ecompile_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str0), heff_intShow(v_t_245));
  V v_it_247 = (g_map_2elookup_24s1546226666x2146984184(heff_strAppend(heff_dup(v_g_242), v_t_246), heff_rfield(v_s_244, 6)));
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_x2_249 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_248, heff_dup(v_s_244)));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eknown(heff_dup(v_g_242), v_s_2411));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
        switch (heff_tag_of(v_x_2413)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_g_242);
          heff_drop_rec(v_s_244, 9);
          heff_drop(v_x_2410);
          heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
          V v_x_2415 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2414});
        }
        case TAG_Just: {
          V v_b_2416 = heff_field(v_x_2413, 0);
          heff_take_n(v_x_2413, 1ULL, 1);
          V v_t_2417 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2410)));
          V v_m_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2416, v_t_2417}));
          V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2414}));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_s_2421 = heff_field(v_x2_2419, 1);
            V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
            V v_e_2422 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_as_243)));
            V v_t_2423 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){v_e_2422, NTAG(TAG_Nil)});
            V v_t_2424 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2423));
            V v_lim_2425 = heff_intAdd(v_t_2424, heff_dup(g_heff_2ecompile_2esimplify_2ebudget_get()));
            V v_t_2426 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2420), NTAG(TAG_Nil)});
            V v_x_2427 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2425), MK_INT(0LL), v_t_2426));
            V v_t_2429 = heff_bool(!heff_intLt_c(heff_dup(v_lim_2425), heff_dup(v_x_2427)));
            heff_drop(v_lim_2425);
            heff_drop(v_x_2427);
            if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
              heff_drop(v_f_241);
              heff_drop_rec(v_s_244, 9);
              heff_drop(v_t_2429);
              V v_t_2430 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str1), heff_intShow(v_t_2430));
              V v_t_2432 = heff_strAppend(v_g_242, v_t_2431);
              V v_x2_2433 = (g_heff_2ecompile_2esimplify_2eremember(v_t_2432, heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Inlined, 2, (V[]){heff_dup(v_x_2410), heff_dup(v_x_2420)}), v_s_2421));
              switch (heff_tag_of(v_x2_2433)) {
              case TAG_MkPair: {
                V v_s_2435 = heff_field(v_x2_2433, 1);
                V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 2ULL, 2);
                V v_t_2436 = (g_heff_2ecompile_2esimplify_2ezipL(v_x_2410, v_as_243));
                V v_m_2437 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2436; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_2436); r_; });
                V v_t_2438 = (g_map_2esize(v_m_2437));
                V v_x_2440;
                if (heff_intEq_c(v_t_2438, MK_INT(0LL))) {
                  heff_drop(v_m_2437);
                  v_x_2440 = v_x_2420;
                } else {
                  v_x_2440 = ({ V a_0 = v_m_2437; V a_1 = v_x_2420; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2437); r_; });
                }
                return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2440, v_s_2435});
              }
              default: return heff_nomatch(v_x2_2433);
              }
            } else {
              heff_drop(v_x_2410);
              heff_drop(v_x_2420);
              heff_drop(v_t_2429);
              V v_t_2441 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str2), heff_intShow(v_t_2441));
              V v_t_2443 = heff_strAppend(v_g_242, v_t_2442);
              V v_t_2444 = ({ V rv_2 = heff_take_field(v_s_244, 2); V rv_5 = heff_get_n(v_s_244, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_2421, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
              V v_x2_2445 = (g_heff_2ecompile_2esimplify_2eremember(v_t_2443, NTAG(TAG_NotInlined), v_t_2444));
              switch (heff_tag_of(v_x2_2445)) {
              case TAG_MkPair: {
                V v_s_2447 = heff_field(v_x2_2445, 1);
                heff_take_n(v_x2_2445, 2ULL, 2);
                V v_x_2448 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
                return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2448, v_s_2447});
              }
              default: return heff_nomatch(v_x2_2445);
              }
            }
          }
          default: return heff_nomatch(v_x2_2419);
          }
        }
        default: return heff_nomatch(v_x_2413);
        }
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  case TAG_Just: {
    V v_it1_2449 = heff_field(v_it_247, 0);
    heff_take_n(v_it_247, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_g_242);
    switch (heff_tag_of(v_it1_2449)) {
    case TAG_Inlined: {
      V v_ps_2450 = heff_field(v_it1_2449, 0);
      V v_e_2451 = heff_field(v_it1_2449, 1);
      V v_ru_24it1_2449_24Inlined = heff_take_reuse_n(v_it1_2449, 3ULL, 2);
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 1)))) {
        heff_drop(v_f_241);
        V v_t_2453 = heff_intSub(heff_take_field(v_s_244, 1), MK_INT(1LL));
        V v_t_2454 = ({ V rv_1 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_s_244, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x2_2455 = (g_heff_2ecompile_2esimplify_2ecopy(v_e_2451, v_t_2454));
        switch (heff_tag_of(v_x2_2455)) {
        case TAG_MkPair: {
          V v_x_2456 = heff_field(v_x2_2455, 0);
          V v_s_2457 = heff_field(v_x2_2455, 1);
          heff_take_n(v_x2_2455, 3ULL, 2);
          V v_t_2458 = (g_heff_2ecompile_2esimplify_2ezipL(v_ps_2450, v_as_243));
          V v_m_2459 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2458; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_2458); r_; });
          V v_t_2460 = (g_map_2esize(v_m_2459));
          V v_x_2462;
          if (heff_intEq_c(v_t_2460, MK_INT(0LL))) {
            heff_drop(v_m_2459);
            v_x_2462 = v_x_2456;
          } else {
            v_x_2462 = ({ V a_0 = v_m_2459; V a_1 = v_x_2456; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2459); r_; });
          }
          return heff_tag_at_n(v_ru_24it1_2449_24Inlined, TAG_MkPair, 2, (V[]){v_x_2462, v_s_2457});
        }
        default: return heff_nomatch(v_x2_2455);
        }
      } else {
        heff_drop(v_ps_2450);
        heff_drop(v_e_2451);
        V v_x_2463 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at_n(v_ru_24it1_2449_24Inlined, TAG_MkPair, 2, (V[]){v_x_2463, v_s_244});
      }
    }
    case TAG_NotInlined: {
      V v_x_2464 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2464, v_s_244});
    }
    default: return heff_nomatch(v_it1_2449);
    }
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_list_2emap_24s1978122382x394628613(heff_dup(v_as_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
        if (heff_intEq_c(v_t_2412, v_t_2413)) {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        } else {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
      } else {
        heff_drop(v_t_2411);
        return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EBytes: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFixed: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat32: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}

static V g_heff_2ecompile_2esimplify_2especLimit_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especLimit_st;
static V g_heff_2ecompile_2esimplify_2especLimit_init(void) {
  return MK_INT(50000LL);
}
V g_heff_2ecompile_2esimplify_2especLimit_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especLimit_st)) return g_heff_2ecompile_2esimplify_2especLimit_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especLimit_val, &g_heff_2ecompile_2esimplify_2especLimit_st, g_heff_2ecompile_2esimplify_2especLimit_init);
}

static V g_heff_2ecompile_2esimplify_2especDepth_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especDepth_st;
static V g_heff_2ecompile_2esimplify_2especDepth_init(void) {
  return MK_INT(16LL);
}
V g_heff_2ecompile_2esimplify_2especDepth_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especDepth_st)) return g_heff_2ecompile_2esimplify_2especDepth_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especDepth_val, &g_heff_2ecompile_2esimplify_2especDepth_st, g_heff_2ecompile_2esimplify_2especDepth_init);
}
Clo g_heff_2ecompile_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknownArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_g_243, v_kinds_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eknownArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2enthE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2enthE_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2enthE(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2enthE(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emarkGo(V v_all_240, V v_as_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248;
    if ((heff_dup(v_st_244) == NTAG(TAG_True))) {
      heff_drop(v_st_244);
      V v_x3_246 = (g_heff_2ecompile_2esimplify_2enthE(heff_dup(v_i_243), v_as_241));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        v_t_248 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_240, v_x_247));
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
    } else {
      heff_drop(v_st_244);
      v_t_248 = NTAG(TAG_False);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2esimplify_2emarkGo_24dps(v_all_240, v_as_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL)), heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams(V v_x1_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_xs_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_xs_241, 0);
      V v_xs2_245 = heff_field(v_xs_241, 1);
      heff_take_n(v_xs_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs2_245;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        goto top;
      } else {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2ekeepParams_24dps(v_ms_243, v_xs2_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_xs_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkCopySafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkCopySafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_244;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    v_t_244 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 4), heff_rfield(v_s_242, 5), v_b_241));
  }
  V v_t_248;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), heff_take_field(v_s_242, 4)));
    V v_s_246 = ({ V rv_4 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_242, 495ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_246, 3)));
    v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_246, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    heff_drop(v_h_240);
    heff_drop(v_t_244);
    v_t_248 = v_s_242;
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkCopySafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBody_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_sh_243, V v_lam1_244) {
top: ;
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_249 = heff_field(v_lam1_244, 0);
    V v_b1_2410 = heff_field(v_lam1_244, 1);
    heff_take_n(v_lam1_244, 3ULL, 2);
    V v_t_2411 = (g_list_2emap_24s1809017761x1063871171(heff_dup(heff_rfield(v_sh_243, 1))));
    V v_t_2412 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_t_2411, heff_dup(v_marks_242), v_b1_2410));
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2esubstMarked(heff_dup(v_marks_242), heff_dup(v_xs1_249), heff_rfield(v_sh_243, 0), v_t_2412));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam2, 1, 4, (V[]){v_m_2413, v_marks_242, v_xs1_249, v_sh_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam17, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam18, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam19, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_246});
}
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_249 = heff_env(self)[2];
  V v_sh_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_249)));
    V v_x1_2419 = (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(heff_rfield(v_sh_243, 1)), v_t_2418));
    V v_x_2424;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_249);
      heff_drop_rec(v_sh_243, 3);
      heff_drop_cell(v_ru_24x2_2415_24MkPair, 2);
      v_x_2424 = v_x_2416;
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2419, 0ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2ekeepParams(v_marks_242, v_xs1_249));
      V v_t_2423 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_243, 1, 3), v_t_2422));
      v_x_2424 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_ELam, 2, (V[]){v_t_2423, v_x_2416});
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2424, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2434});
}
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2439 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2439});
}
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2442 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2442});
}
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2445 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2445});
}
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2447 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2447});
}
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2450 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2450});
}
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2453 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2453});
}
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2455 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2455});
}
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2457 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2457});
}
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2459 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2459});
}
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2461 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2461});
}
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2464 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2464});
}
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args) {
  V v_s_2466 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2466});
}
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args) {
  V v_s_2467 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args) {
  V v_s_2470 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2470});
}
Clo g_heff_2ecompile_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elamsOut_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elamsOut(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_x2_241, 0);
    heff_drop(v_safe_240);
    return (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_244));
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), v_a_249));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V t_0 = v_safe_240;
      V t_1 = v_b_2410;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_t_2411);
      return MK_INT(0LL);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2420 = heff_field(v_x2_241, 0);
    V v_arms_2421 = heff_field(v_x2_241, 1);
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), v_sc_2420));
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V v_x1_2425;
      switch (heff_tag_of(v_arms_2421)) {
      case TAG_Nil: {
        v_x1_2425 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_2425 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_arms_2421);
      }
      if ((heff_dup(v_x1_2425) == NTAG(TAG_True))) {
        heff_drop(v_safe_240);
        heff_drop(v_x1_2425);
        return MK_INT(0LL);
      } else {
        heff_drop(v_x1_2425);
        V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2elamsOut_clo), 1, (V[]){v_safe_240}));
        V v_t_2427 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2421)));
        V v_x1_2428 = (g_list_2emap(v_t_2426, v_t_2427));
        switch (heff_tag_of(v_x1_2428)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2429 = heff_field(v_x1_2428, 0);
          V v_xs_2430 = heff_field(v_x1_2428, 1);
          heff_take_n(v_x1_2428, 3ULL, 2);
          return ({ V a_0 = v_x_2429; V a_1 = v_xs_2430; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_xs_2430); r_; });
        }
        default: return heff_nomatch(v_x1_2428);
        }
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_t_2422);
      return MK_INT(0LL);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2elamsOut(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_as_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2emarkedOf_24dps(v_ms_243, v_as_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ms_243;
        V t_1 = v_as_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_as_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_as_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ms_244;
        V t_1 = v_as_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edepthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edepthOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2edepthOf(V v_ds_240, V v_g_241, V v_args_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2edepthOf_lam0, 2, 1, (V[]){heff_dup(v_ds_240)}); V a_1 = MK_INT(0LL); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_241, v_t_244}); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_intAdd(MK_INT(1LL), v_t_2411);
}
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2edepthOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_n_246 = args[1];
  V v_ds_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = ({ V a_0 = v_n_246; V a_1 = v_ds_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_ds_240); r_; });
  V v_b_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_b_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_b_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  if (heff_intLe_c(heff_dup(v_b_249), heff_dup(v_d_245))) {
    heff_drop(v_b_249);
    return v_d_245;
  } else {
    heff_drop(v_d_245);
    return v_b_249;
  }
}
Clo g_heff_2ecompile_2esimplify_2esetOff_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esetOff_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esetOff(V v_o_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_248 = ({ V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_o_240}); V rr_ = heff_rec_reuse_nf(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esetOff(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ebackTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebackTo_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebackTo(V v_saved_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_saved_240, 7)), 5, 7);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_saved_240, 7)), 6, 7);
  V v_t_249 = ({ V rv_1 = heff_take_field(v_saved_240, 1); V rv_6 = heff_get_n(v_saved_240, 6, 9); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248}); V rr_ = heff_rec_reuse_nf(v_s_241, 317ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 200691u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_249});
}
V g_heff_2ecompile_2esimplify_2ebackTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebackTo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str1, 1, "-");
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyVer_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecopyVer(V v_vers_240, V v_h_241, V v_g_242, V v_args_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
  V v_t_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopyVer_lam0, 1, 1, (V[]){heff_dup(v_vers_240)}), heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, v_t_245})));
  V v_x2_248 = (g_heff_2ecompile_2esimplify_2eversAll(v_t_247));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    heff_drop(v_h_241);
    return ((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str0);
  }
  case TAG_Just: {
    V v_vs_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Just = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    V v_t_2410 = (g_list_2emap_24s1123370502x1982532655(v_vs_249));
    V v_items_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_248_24Just, TAG_HS, 1, (V[]){v_h_241}), v_t_2410});
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2ehashW(MK_INT(5381LL), MK_INT(7919LL), v_items_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_t_2412, 0);
      V v_b_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str1), heff_intShow(v_b_2414));
      return heff_strAppend(heff_intShow(v_a_2413), v_t_2415);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyVer(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_246; V a_1 = v_vers_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_vers_240); r_; });
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ekeptAt_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeptAt_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeptAt(V v_s_240, V v_h_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 8)), 0, 5);
  V v_t_243 = ({ V a_0 = heff_dup(v_h_241); V a_1 = v_t_242; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_242); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_h_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_get_n(heff_get_n(v_s_240, 8, 9), 1, 5);
    V v_x2_246 = ({ V a_0 = v_h_241; V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24t_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_kc_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_kc_247, 0)), heff_dup(v_v_244))) {
        if (heff_strEq_c(v_v_244, ((V)&g_heff_2ecompile_2esimplify_2ekeptAt_str0))) {
          heff_drop_cell(v_ru_24t_243_24Just, 1);
          heff_drop_rec(v_kc_247, 5);
          return NTAG(TAG_Nothing);
        } else {
          return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_kc_247});
        }
      } else {
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        heff_drop_rec(v_kc_247, 5);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeptAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknowing_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknowing(V v_r_240, V v_b0_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2esimplify_2eownSt(heff_dup(v_s_242)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_MkPair: {
    V v_s_245 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24MkPair = heff_take_reuse_n(v_t_243, 2ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2esetOff(NTAG(TAG_True), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 2ULL, 2);
      V v_m_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b0_241}));
      V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_s_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_x_2411}));
        V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2415, v_s_2416));
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x2_2417, 0);
            V v_s_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 3ULL, 2);
            V v_t_2420 = (g_heff_2ecompile_2esimplify_2ebackTo(v_s_242, v_s_2419));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_MkPair: {
              V v_s_2422 = heff_field(v_t_2420, 1);
              heff_take_n(v_t_2420, 2ULL, 2);
              return heff_tag_at_n(v_ru_24t_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_s_2422});
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
          default: return heff_nomatch(v_x2_2417);
          }
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      return heff_strEq(v_g_240, heff_dup(v_h_249));
    }
    case TAG_ELam: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2estillCall(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam18(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2450 = heff_field(v_s_241, 0);
    V v_a_2451 = heff_field(v_s_241, 1);
    V v_b_2452 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_2452, v_arms_242}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam4, 1, 3, (V[]){v_m_2453, v_x_2450, v_a_2451});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2466 = heff_dup(heff_field(v_s_241, 0));
    V v_as_2467 = heff_dup(heff_field(v_s_241, 1));
    V v_it_2468 = (g_heff_2ecompile_2esimplify_2efindArm(v_t_2466, v_arms_242));
    switch (heff_tag_of(v_it_2468)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_as_2467);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
    }
    case TAG_Just: {
      V v_it1_2470 = heff_field(v_it_2468, 0);
      heff_take_n(v_it_2468, 1ULL, 1);
      heff_drop_tag(v_s_241, 2);
      heff_drop(v_arms_242);
      switch (heff_tag_of(v_it1_2470)) {
      case TAG_MkArm: {
        V v_vs_2472 = heff_field(v_it1_2470, 1);
        V v_b_2473 = heff_field(v_it1_2470, 2);
        heff_take_n(v_it1_2470, 6ULL, 3);
        V v_t_2474 = (g_heff_2ecompile_2esimplify_2ezipL(v_vs_2472, v_as_2467));
        V v_t_2475 = ({ V a_0 = v_t_2474; V a_1 = v_b_2473; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2474); r_; });
        return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2475});
      }
      default: return heff_nomatch(v_it1_2470);
      }
    }
    default: return heff_nomatch(v_it_2468);
    }
  }
  case TAG_EMatch: {
    V v_s2_2476 = heff_field(v_s_241, 0);
    V v_arms2_2477 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ecaseOfCase(v_r_240, v_s2_2476, v_arms2_2477, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam16, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam17, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam18, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = (g_heff_2ecompile_2esimplify_2eknown(v_g_245, v_s_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2410, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2410, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ETag: {
        V v_t2_2426 = heff_field(v_it1_2410, 0);
        V v_as2_2427 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        heff_drop_tag(v_s_241, 1);
        heff_drop_cell(v_ru_24x2_247_24MkPair, 2);
        V f_ = heff_get_n(v_r_240, 3, 4);
        heff_room[0] = heff_tag_n(TAG_ETag, 2, (V[]){v_t2_2426, v_as2_2427});
        heff_room[1] = v_arms_242;
        heff_room[2] = v_s_249;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args) {
  V v_s_2446 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2446});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args) {
  V v_s_2449 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2449});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args) {
  V v_s_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_x_2450 = heff_env(self)[1];
  V v_a_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_s_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2450, v_a_2451, v_x_2456}), v_s_2457});
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args) {
  V v_s_2460 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2460});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args) {
  V v_s_2465 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2465});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args) {
  V v_s_2469 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2469});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args) {
  V v_s_2479 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2479});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args) {
  V v_s_2482 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2482});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args) {
  V v_s_2485 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2485});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args) {
  V v_s_2487 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2487});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args) {
  V v_s_2489 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2489});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args) {
  V v_s_2491 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2491});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args) {
  V v_s_2493 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2493});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args) {
  V v_s_2496 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2496});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args) {
  V v_s_2498 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2498});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args) {
  V v_s_2499 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2499});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam18(V self, V *args) {
  V v_s_24102 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24102});
}
V g_heff_2ecompile_2esimplify_2emakeEach_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2emakeEach_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_lam0, 1, 0};
Clo g_heff_2ecompile_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 4, 7);
    V v_x3_245 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_x3_248;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 2, 7);
      v_x3_248 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_x3_248 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    V v_m_2411;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nothing: {
      heff_drop(v_h_242);
      v_m_2411 = ((V)&g_heff_2ecompile_2esimplify_2emakeEach_lam0_clo);
      break;
    }
    case TAG_Just: {
      V v_b0_2410 = heff_field(v_x3_248, 0);
      heff_take_n(v_x3_248, 1ULL, 1);
      v_m_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeOne_clo), 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), v_h_242, v_b0_2410}));
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_p_241}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      V v_m_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), 1, (V[]){v_rest_243}));
      V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        V v_x_2419 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2413, v_x_2417));
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeEach(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2emakeEach_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_249});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2edoneOf_str0, 0, "");
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edoneOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edoneOf_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2edoneOf(V v_s_240, V v_d_241, V v_b_242, V v_t_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_d_241, 0)), heff_rfield(v_s_240, 3)));
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  V v_t_248 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_247));
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2edoneOf_lam0, 1, 1, (V[]){v_s_240}), v_t_248));
  return heff_rec_n(4, shape_key__body__safe__touched, (V[]){heff_get_n(v_d_241, 0, 3), v_b_242, v_t_246, v_t_2414});
}
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edoneOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args) {
  V v_h_249 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 8, 9), 0, 5);
  V v_x2_2411 = ({ V a_0 = heff_dup(v_h_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2ecompile_2esimplify_2edoneOf_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_249, v_t_2413});
}
Clo g_heff_2ecompile_2esimplify_2ereplayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayed_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayed(V v_k_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 7);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b0_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eallAsked(heff_dup(heff_rfield(v_k_240, 4)), v_p_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop(v_x_245);
        V v_x2_247 = (g_heff_2ecompile_2esimplify_2ereplayBody(v_k_240, v_b0_243, v_s_246));
        switch (heff_tag_of(v_x2_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_s_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
        }
        default: return heff_nomatch(v_x2_247);
        }
      } else {
        heff_drop_rec(v_k_240, 7);
        heff_drop(v_b0_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayed(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2econcatDefs(a0); heff_drop(a0); return r;
}