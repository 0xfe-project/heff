// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HS 9084
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_match 305026527
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__body__safe__touched[] = {LBL_key, LBL_body, LBL_safe, LBL_touched};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2ebackTo(V, V);
V g_heff_2ecompile_2esimplify_2ebackTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebackTo_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efindArm(V, V);
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindArm_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknowing(V, V, V);
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknowing_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enthE(V, V);
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2enthE_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2esetOff(V, V);
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetOff_clo;
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2esumPushed(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_clo;
V g_heff_2ecompile_2esimplify_2eversAll(V);
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eversAll_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
Clo g_heff_2ecompile_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str0, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str1, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str2, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str3, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str4, 6, "intShr");

static V g_heff_2ecompile_2esimplify_2efailing_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2efailing_st;
static V g_heff_2ecompile_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str2), v_t_240})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str4), v_t_241})});
}
V g_heff_2ecompile_2esimplify_2efailing_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2efailing_st)) return g_heff_2ecompile_2esimplify_2efailing_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2efailing_val, &g_heff_2ecompile_2esimplify_2efailing_st, g_heff_2ecompile_2esimplify_2efailing_init);
}
Clo g_heff_2ecompile_2esimplify_2epartialHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialHead(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
    V v_t_246 = ({ V a_0 = heff_dup(v_g_244); V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    return ({ V a_0 = v_s_240; V a_1 = v_as_241; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialHead(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_y_243), v_x_240)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_a_241});
    } else {
      heff_drop(v_a_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2410 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_249));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_242, 0);
    V v_as_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2417 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_f_2415));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam3, 1, 4, (V[]){v_m_2417, v_x_240, v_a_241, v_as_2416});
  }
  case TAG_ELet: {
    V v_y_2428 = heff_field(v_e_242, 0);
    V v_e2_2429 = heff_field(v_e_242, 1);
    V v_b_2430 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_e2_2429));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam5, 1, 5, (V[]){v_m_2431, v_x_240, v_a_241, v_b_2430, v_y_2428});
  }
  case TAG_ERecord: {
    V v_fs_2440 = heff_field(v_e_242, 0);
    V v_ts_2441 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2450 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam6, 1, 2, (V[]){v_x_240, v_a_241}), v_fs_2440));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam8, 1, 2, (V[]){v_m_2450, v_ts_2441});
  }
  case TAG_EProj: {
    V v_e2_2455 = heff_field(v_e_242, 0);
    V v_l_2456 = heff_field(v_e_242, 1);
    V v_sh_2457 = heff_field(v_e_242, 2);
    V v_t_2458 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_m_2459 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2455));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam9, 1, 4, (V[]){v_m_2459, v_l_2456, v_sh_2457, v_t_2458});
  }
  case TAG_ETag: {
    V v_t_2464 = heff_field(v_e_242, 0);
    V v_as_2465 = heff_field(v_e_242, 1);
    V v_ts_2466 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2468 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2465));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam11, 1, 3, (V[]){v_m_2468, v_t_2464, v_ts_2466});
  }
  case TAG_EMatch: {
    V v_s_2473 = heff_field(v_e_242, 0);
    V v_arms_2474 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2475 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_s_2473));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam12, 1, 4, (V[]){v_m_2475, v_x_240, v_a_241, v_arms_2474});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam15, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2495 = heff_field(v_e_242, 0);
    V v_as_2496 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2498 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam16, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2496));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_m_2498, v_p_2495});
  }
  case TAG_ECall: {
    V v_g_24103 = heff_field(v_e_242, 0);
    V v_as_24104 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24106 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){v_x_240, v_a_241}), v_as_24104));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_m_24106, v_g_24103});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam20, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam26, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam27, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esubstCopies(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_245});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_248, v_x_2413}), v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_q_2422 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2422));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_as_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam4, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2416));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2421}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      V v_x_2427 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2420, v_x_2425));
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2430 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2430));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2428, v_x_2434, v_x_2438}), v_s_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2443, v_x_2448}), v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_p_2442 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_l_2443 = heff_field(v_p_2442, 0);
    V v_e_2444 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 3ULL, 2);
    V v_m_2445 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e_2444));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_m_2445, v_l_2443});
  }
  default: return heff_nomatch(v_p_2442);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_ts_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2453, v_ts_2441}), v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_l_2456 = heff_env(self)[1];
  V v_sh_2457 = heff_env(self)[2];
  V v_t_2458 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2461 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2462, v_l_2456, v_sh_2457, v_t_2458}), v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_q_2467 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2467));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_s_2469 = args[0];
  V v_m_2468 = heff_env(self)[0];
  V v_t_2464 = heff_env(self)[1];
  V v_ts_2466 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2470 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_s_2469}));
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkPair: {
    V v_x_2471 = heff_field(v_x2_2470, 0);
    V v_s_2472 = heff_field(v_x2_2470, 1);
    V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2464, v_x_2471, v_ts_2466}), v_s_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_s_2485 = args[0];
  V v_m_2484 = heff_env(self)[0];
  V v_t_2481 = heff_env(self)[1];
  V v_vs_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2486 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_s_2485}));
  switch (heff_tag_of(v_x2_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_field(v_x2_2486, 0);
    V v_s_2488 = heff_field(v_x2_2486, 1);
    V v_ru_24x2_2486_24MkPair = heff_take_reuse_n(v_x2_2486, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2481, v_vs_2482, v_x_2487}), v_s_2488});
  }
  default: return heff_nomatch(v_x2_2486);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_a_2480 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2480)) {
  case TAG_MkArm: {
    V v_t_2481 = heff_field(v_a_2480, 0);
    V v_vs_2482 = heff_field(v_a_2480, 1);
    V v_b_2483 = heff_field(v_a_2480, 2);
    heff_take_n(v_a_2480, 7ULL, 3);
    V v_m_2484 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2483));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam14, 1, 3, (V[]){v_m_2484, v_t_2481, v_vs_2482});
  }
  default: return heff_nomatch(v_a_2480);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2474 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2477 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    V v_m_2489 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam13, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2474));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2479}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2478, v_x_2491}), v_s_2492});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2494 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_2494});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_q_2497 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2497));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_s_2499 = args[0];
  V v_m_2498 = heff_env(self)[0];
  V v_p_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24100 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_s_2499}));
  switch (heff_tag_of(v_x2_24100)) {
  case TAG_MkPair: {
    V v_x_24101 = heff_field(v_x2_24100, 0);
    V v_s_24102 = heff_field(v_x2_24100, 1);
    V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2495, v_x_24101}), v_s_24102});
  }
  default: return heff_nomatch(v_x2_24100);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_q_24105 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_24105));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_g_24103 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24103, v_x_24109}), v_s_24110});
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24112 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24112});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24114 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24114});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24116 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24116});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24118 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24118});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24121 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24121});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24123 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args) {
  V v_s_24124 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24124});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam27(V self, V *args) {
  V v_s_24127 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24127});
}
Clo g_heff_2ecompile_2esimplify_2eletSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletSplit(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2421 = heff_field(v_a_242, 0);
    V v_as_2422 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EApp = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_x2_2423 = heff_tr(g_heff_2ecompile_2esimplify_2esplitArgs(v_as_2422, v_z_244));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24a_242_24EApp, TAG_EApp, 2, (V[]){v_f_2421, heff_dup(heff_rfield(v_x_2424, 1))});
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2428 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2427));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2430 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2429));
      V v_t_2431 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2428, v_t_2430}), 0, 2);
      V v_m_2432 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_t_2426, v_b_243, v_t_2431));
      V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2425}));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_s_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        V v_x_2436 = ({ V b_0 = heff_get_n(v_x_2424, 0, 2); V a_1 = v_x_2434; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(b_0, a_1)); heff_drop(b_0); r_; });
        return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  case TAG_ELet: {
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_s_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2442}), v_s_2443});
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_ERecord: {
    V v_m_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_s_2449 = heff_field(v_x2_2447, 1);
      V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2448}), v_s_2449});
    }
    default: return heff_nomatch(v_x2_2447);
    }
  }
  case TAG_EProj: {
    V v_m_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_MkPair: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_s_2457 = heff_field(v_x2_2455, 1);
      V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2456}), v_s_2457});
    }
    default: return heff_nomatch(v_x2_2455);
    }
  }
  case TAG_ETag: {
    V v_m_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2463}), v_s_2464});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  case TAG_EMatch: {
    V v_m_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2468 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2468)) {
    case TAG_MkPair: {
      V v_x_2469 = heff_field(v_x2_2468, 0);
      V v_s_2470 = heff_field(v_x2_2468, 1);
      V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2469}), v_s_2470});
    }
    default: return heff_nomatch(v_x2_2468);
    }
  }
  case TAG_EPrim: {
    V v_m_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_s_2475 = heff_field(v_x2_2473, 1);
      V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2474}), v_s_2475});
    }
    default: return heff_nomatch(v_x2_2473);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2479)) {
    case TAG_MkPair: {
      V v_x_2480 = heff_field(v_x2_2479, 0);
      V v_s_2481 = heff_field(v_x2_2479, 1);
      V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2480}), v_s_2481});
    }
    default: return heff_nomatch(v_x2_2479);
    }
  }
  case TAG_ECall: {
    V v_m_2484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_s_2487 = heff_field(v_x2_2485, 1);
      V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2486}), v_s_2487});
    }
    default: return heff_nomatch(v_x2_2485);
    }
  }
  case TAG_EInt: {
    V v_m_2489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2491}), v_s_2492});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  case TAG_EFloat: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2495 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_MkPair: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_s_2497 = heff_field(v_x2_2495, 1);
      V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2496}), v_s_2497});
    }
    default: return heff_nomatch(v_x2_2495);
    }
  }
  case TAG_EStr: {
    V v_m_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24100 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24100)) {
    case TAG_MkPair: {
      V v_x_24101 = heff_field(v_x2_24100, 0);
      V v_s_24102 = heff_field(v_x2_24100, 1);
      V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24101}), v_s_24102});
    }
    default: return heff_nomatch(v_x2_24100);
    }
  }
  case TAG_EBytes: {
    V v_m_24104 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24105 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24105)) {
    case TAG_MkPair: {
      V v_x_24106 = heff_field(v_x2_24105, 0);
      V v_s_24107 = heff_field(v_x2_24105, 1);
      V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24106}), v_s_24107});
    }
    default: return heff_nomatch(v_x2_24105);
    }
  }
  case TAG_EFixed: {
    V v_m_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24111 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24111)) {
    case TAG_MkPair: {
      V v_x_24112 = heff_field(v_x2_24111, 0);
      V v_s_24113 = heff_field(v_x2_24111, 1);
      V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24112}), v_s_24113});
    }
    default: return heff_nomatch(v_x2_24111);
    }
  }
  case TAG_EFloat32: {
    V v_m_24115 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24116 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24116)) {
    case TAG_MkPair: {
      V v_x_24117 = heff_field(v_x2_24116, 0);
      V v_s_24118 = heff_field(v_x2_24116, 1);
      V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24117}), v_s_24118});
    }
    default: return heff_nomatch(v_x2_24116);
    }
  }
  case TAG_EAbandon: {
    V v_m_24119 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      V v_s_24122 = heff_field(v_x2_24120, 1);
      V v_ru_24x2_24120_24MkPair = heff_take_reuse_n(v_x2_24120, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24121}), v_s_24122});
    }
    default: return heff_nomatch(v_x2_24120);
    }
  }
  case TAG_EFix: {
    V v_m_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24126 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24126)) {
    case TAG_MkPair: {
      V v_x_24127 = heff_field(v_x2_24126, 0);
      V v_s_24128 = heff_field(v_x2_24126, 1);
      V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24127}), v_s_24128});
    }
    default: return heff_nomatch(v_x2_24126);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletSplit(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esumPushed_lam21(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esumPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumPushed_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esumPushed(V v_r_240, V v_x_241, V v_b_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam1, 1, 1, (V[]){v_e_243});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam2, 1, 1, (V[]){v_e_243});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam3, 1, 1, (V[]){v_e_243});
  }
  case TAG_ELet: {
    V v_y_2414 = heff_field(v_e_243, 0);
    V v_a_2415 = heff_field(v_e_243, 1);
    V v_c_2416 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2417 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_c_2416));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam4, 1, 3, (V[]){v_m_2417, v_y_2414, v_a_2415});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam5, 1, 1, (V[]){v_e_243});
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam6, 1, 1, (V[]){v_e_243});
  }
  case TAG_ETag: {
    V v_t_2430 = heff_field(v_e_243, 0);
    V v_es_2431 = heff_field(v_e_243, 1);
    V v_ts_2432 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam7, 1, 6, (V[]){v_es_2431, v_b_242, v_x_241, v_t_2430, v_ts_2432, v_r_240});
  }
  case TAG_EMatch: {
    V v_s_2452 = heff_field(v_e_243, 0);
    V v_arms_2453 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_m_2463 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam8, 1, 3, (V[]){v_r_240, v_x_241, v_b_242}), v_arms_2453));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam10, 1, 2, (V[]){v_m_2463, v_s_2452});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam11, 1, 1, (V[]){v_e_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam12, 1, 1, (V[]){v_e_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam13, 1, 1, (V[]){v_e_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam14, 1, 1, (V[]){v_e_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam15, 1, 1, (V[]){v_e_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam16, 1, 1, (V[]){v_e_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam17, 1, 1, (V[]){v_e_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam18, 1, 1, (V[]){v_e_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam19, 1, 1, (V[]){v_e_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam20, 1, 1, (V[]){v_e_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_x_241);
    heff_drop(v_b_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam21, 1, 1, (V[]){v_e_243});
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esumPushed(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_245});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam3(V self, V *args) {
  V v_s_2413 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2413});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam4(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_y_2414 = heff_env(self)[1];
  V v_a_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2414, v_a_2415, v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam5(V self, V *args) {
  V v_s_2424 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2424});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam6(V self, V *args) {
  V v_s_2429 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2429});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam7(V self, V *args) {
  V v_s_2433 = args[0];
  V v_es_2431 = heff_env(self)[0];
  V v_b_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_t_2430 = heff_env(self)[3];
  V v_ts_2432 = heff_env(self)[4];
  V v_r_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2434 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_es_2431, v_s_2433));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_s_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    V v_x2_2437 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_242, v_s_2436));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_t_2442;
      switch (heff_tag_of(v_x_2435)) {
      case TAG_MkPair: {
        V v_y_2441 = heff_dup(heff_field(v_x_2435, 1));
        v_t_2442 = v_y_2441;
        break;
      }
      default: heff_nomatch(v_x_2435);
      }
      V v_t_2443 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2430, v_t_2442, v_ts_2432}), v_x_2438});
      V v_m_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2443}));
      V v_x2_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2445)) {
      case TAG_MkPair: {
        V v_x_2446 = heff_field(v_x2_2445, 0);
        V v_s_2447 = heff_field(v_x2_2445, 1);
        heff_take_n(v_x2_2445, 3ULL, 2);
        V v_t_2450;
        switch (heff_tag_of(v_x_2435)) {
        case TAG_MkPair: {
          V v_x_2448 = heff_field(v_x_2435, 0);
          heff_take_n(v_x_2435, 1ULL, 2);
          v_t_2450 = v_x_2448;
          break;
        }
        default: heff_nomatch(v_x_2435);
        }
        V v_x_2451 = ({ V a_0 = v_t_2450; V a_1 = v_x_2446; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2450); r_; });
        return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_x_2451, v_s_2447});
      }
      default: return heff_nomatch(v_x2_2445);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam9(V self, V *args) {
  V v_s_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_t_2455 = heff_env(self)[1];
  V v_vs_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_s_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2455, v_vs_2456, v_x_2461}), v_s_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam8(V self, V *args) {
  V v_a_2454 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_2454)) {
  case TAG_MkArm: {
    V v_t_2455 = heff_field(v_a_2454, 0);
    V v_vs_2456 = heff_field(v_a_2454, 1);
    V v_b_2457 = heff_field(v_a_2454, 2);
    heff_take_n(v_a_2454, 7ULL, 3);
    V v_m_2458 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_242, v_b_2457));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esumPushed_lam9, 1, 3, (V[]){v_m_2458, v_t_2455, v_vs_2456});
  }
  default: return heff_nomatch(v_a_2454);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam10(V self, V *args) {
  V v_s_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_s_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_s_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2452, v_x_2466}), v_s_2467});
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam11(V self, V *args) {
  V v_s_2469 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2469});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam12(V self, V *args) {
  V v_s_2472 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2472});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam13(V self, V *args) {
  V v_s_2475 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2475});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam14(V self, V *args) {
  V v_s_2477 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2477});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam15(V self, V *args) {
  V v_s_2479 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2479});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam16(V self, V *args) {
  V v_s_2481 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2481});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam17(V self, V *args) {
  V v_s_2483 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2483});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam18(V self, V *args) {
  V v_s_2486 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2486});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam19(V self, V *args) {
  V v_s_2488 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2488});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam20(V self, V *args) {
  V v_s_2489 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2489});
}
V g_heff_2ecompile_2esimplify_2esumPushed_lam21(V self, V *args) {
  V v_s_2492 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2492});
}
Clo g_heff_2ecompile_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknownArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_g_243, v_kinds_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eknownArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2enthE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2enthE_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2enthE(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2enthE(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams(V v_x1_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_xs_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_xs_241, 0);
      V v_xs2_245 = heff_field(v_xs_241, 1);
      heff_take_n(v_xs_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs2_245;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        goto top;
      } else {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2ekeepParams_24dps(v_ms_243, v_xs2_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_xs_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBody_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_sh_243, V v_lam1_244) {
top: ;
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_249 = heff_field(v_lam1_244, 0);
    V v_b1_2410 = heff_field(v_lam1_244, 1);
    heff_take_n(v_lam1_244, 3ULL, 2);
    V v_t_2411 = (g_list_2emap_24s1809017761x1063871171(heff_dup(heff_rfield(v_sh_243, 1))));
    V v_t_2412 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_t_2411, heff_dup(v_marks_242), v_b1_2410));
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2esubstMarked(heff_dup(v_marks_242), heff_dup(v_xs1_249), heff_rfield(v_sh_243, 0), v_t_2412));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam2, 1, 4, (V[]){v_m_2413, v_marks_242, v_xs1_249, v_sh_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam17, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam18, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam19, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_246});
}
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_249 = heff_env(self)[2];
  V v_sh_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_249)));
    V v_x1_2419 = (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(heff_rfield(v_sh_243, 1)), v_t_2418));
    V v_x_2424;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_249);
      heff_drop_rec(v_sh_243, 3);
      v_x_2424 = v_x_2416;
      break;
    }
    case TAG_Cons: {
      V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 0ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2ekeepParams(v_marks_242, v_xs1_249));
      V v_t_2423 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_243, 1, 3), v_t_2422));
      v_x_2424 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_ELam, 2, (V[]){v_t_2423, v_x_2416});
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2434});
}
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2439 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2439});
}
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2443});
}
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2446 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2446});
}
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2448 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2448});
}
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2451 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2451});
}
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2454 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2454});
}
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2456 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2456});
}
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2458 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2458});
}
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2460 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2460});
}
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2462 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2462});
}
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2465 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2465});
}
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args) {
  V v_s_2467 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args) {
  V v_s_2468 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2468});
}
V g_heff_2ecompile_2esimplify_2especBody_lam19(V self, V *args) {
  V v_s_2471 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2471});
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_as_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_as_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ms_244;
        V t_1 = v_as_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ebackTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebackTo_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebackTo(V v_saved_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_saved_240, 7)), 5, 7);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_saved_240, 7)), 6, 7);
  V v_t_249 = ({ V rv_1 = heff_take_field(v_saved_240, 1); V rv_6 = heff_get_n(v_saved_240, 6, 9); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248}); V rr_ = heff_rec_reuse_nf(v_s_241, 317ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 200691u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_249});
}
V g_heff_2ecompile_2esimplify_2ebackTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebackTo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str1, 1, "-");
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyVer_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecopyVer(V v_vers_240, V v_h_241, V v_g_242, V v_args_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
  V v_t_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopyVer_lam0, 1, 1, (V[]){heff_dup(v_vers_240)}), heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, v_t_245})));
  V v_x2_248 = (g_heff_2ecompile_2esimplify_2eversAll(v_t_247));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    heff_drop(v_h_241);
    return ((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str0);
  }
  case TAG_Just: {
    V v_vs_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Just = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    V v_t_2410 = (g_list_2emap_24s1123370502x1982532655(v_vs_249));
    V v_items_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_248_24Just, TAG_HS, 1, (V[]){v_h_241}), v_t_2410});
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2ehashW(MK_INT(5381LL), MK_INT(7919LL), v_items_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_t_2412, 0);
      V v_b_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str1), heff_intShow(v_b_2414));
      return heff_strAppend(heff_intShow(v_a_2413), v_t_2415);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyVer(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_246; V a_1 = v_vers_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_vers_240); r_; });
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ekeptAt_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeptAt_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeptAt(V v_s_240, V v_h_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 8)), 0, 5);
  V v_t_243 = ({ V a_0 = heff_dup(v_h_241); V a_1 = v_t_242; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_242); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_h_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_get_n(heff_get_n(v_s_240, 8, 9), 1, 5);
    V v_x2_246 = ({ V a_0 = v_h_241; V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24t_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_kc_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_kc_247, 0)), heff_dup(v_v_244))) {
        if (heff_strEq_c(v_v_244, ((V)&g_heff_2ecompile_2esimplify_2ekeptAt_str0))) {
          heff_drop_cell(v_ru_24t_243_24Just, 1);
          heff_drop_rec(v_kc_247, 5);
          return NTAG(TAG_Nothing);
        } else {
          return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_kc_247});
        }
      } else {
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        heff_drop_rec(v_kc_247, 5);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeptAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknowing_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknowing(V v_r_240, V v_b0_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2esimplify_2eownSt(heff_dup(v_s_242)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_MkPair: {
    V v_s_245 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24MkPair = heff_take_reuse_n(v_t_243, 2ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2esetOff(NTAG(TAG_True), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 2ULL, 2);
      V v_m_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b0_241}));
      V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_s_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_x_2411}));
        V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2415, v_s_2416));
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x2_2417, 0);
            V v_s_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 3ULL, 2);
            V v_t_2420 = (g_heff_2ecompile_2esimplify_2ebackTo(v_s_242, v_s_2419));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_MkPair: {
              V v_s_2422 = heff_field(v_t_2420, 1);
              heff_take_n(v_t_2420, 2ULL, 2);
              return heff_tag_at_n(v_ru_24t_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_s_2422});
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
          default: return heff_nomatch(v_x2_2417);
          }
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emissingOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emissingOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emissingOf(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    V v_e1_246 = heff_field(v_e_241, 0);
    V v_bs_247 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_e1_246, 0);
      V v_all_2410 = heff_get_n(v_s_240, 2, 9);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_2410, heff_dup(v_h_249)));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2414 = ({ V a_0 = v_all_2410; V a_1 = heff_dup(v_h_249); V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_2410); r_; });
        V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_247));
        return heff_intSub(v_t_2414, v_t_2415);
      } else {
        heff_drop(v_all_2410);
        return MK_INT(0LL);
      }
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_e1_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emissingOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_m_2440;
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      v_m_2440 = heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_lam0, 1, 1, (V[]){v_x_242});
    } else {
      heff_drop(v_t_2438);
      v_m_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_x_242}));
    }
    V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_p_241}));
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_s_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      V v_x2_2444 = (g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(v_xs_243, v_s_2443));
      switch (heff_tag_of(v_x2_2444)) {
      case TAG_MkPair: {
        V v_x_2445 = heff_field(v_x2_2444, 0);
        V v_s_2446 = heff_field(v_x2_2444, 1);
        heff_take_n(v_x2_2444, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2442, v_x_2445}), v_s_2446});
      }
      default: return heff_nomatch(v_x2_2444);
      }
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_lam0(V self, V *args) {
  V v_a_2439 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_a_2439});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam18(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2452 = heff_field(v_s_241, 0);
    V v_a_2453 = heff_field(v_s_241, 1);
    V v_b_2454 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_2454, v_arms_242}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam4, 1, 3, (V[]){v_m_2455, v_x_2452, v_a_2453});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2468 = heff_dup(heff_field(v_s_241, 0));
    V v_as_2469 = heff_dup(heff_field(v_s_241, 1));
    V v_it_2471 = (g_heff_2ecompile_2esimplify_2efindArm(v_t_2468, v_arms_242));
    switch (heff_tag_of(v_it_2471)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_as_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
    }
    case TAG_Just: {
      V v_it1_2473 = heff_field(v_it_2471, 0);
      heff_take_n(v_it_2471, 1ULL, 1);
      heff_drop_tag(v_s_241, 3);
      heff_drop(v_arms_242);
      switch (heff_tag_of(v_it1_2473)) {
      case TAG_MkArm: {
        V v_vs_2475 = heff_field(v_it1_2473, 1);
        V v_b_2476 = heff_field(v_it1_2473, 2);
        heff_take_n(v_it1_2473, 6ULL, 3);
        V v_t_2477 = (g_heff_2ecompile_2esimplify_2ezipL(v_vs_2475, v_as_2469));
        V v_t_2478 = ({ V a_0 = v_t_2477; V a_1 = v_b_2476; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2477); r_; });
        return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2478});
      }
      default: return heff_nomatch(v_it1_2473);
      }
    }
    default: return heff_nomatch(v_it_2471);
    }
  }
  case TAG_EMatch: {
    V v_s2_2479 = heff_field(v_s_241, 0);
    V v_arms2_2480 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ecaseOfCase(v_r_240, v_s2_2479, v_arms2_2480, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam16, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam17, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam18, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_g_245, heff_rfield(v_s_246, 2)));
  V v_x2_248 = (g_heff_2ecompile_2esimplify_2efueled(v_t_247, v_s_246));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
    }
    case TAG_Just: {
      V v_it1_2411 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2411, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2411, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_ETag: {
        V v_t2_2427 = heff_field(v_it1_2411, 0);
        V v_as2_2428 = heff_field(v_it1_2411, 1);
        V v_ts2_2429 = heff_field(v_it1_2411, 2);
        heff_take_n(v_it1_2411, 7ULL, 3);
        heff_drop_tag(v_s_241, 1);
        heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
        V f_ = heff_get_n(v_r_240, 3, 4);
        heff_room[0] = heff_tag_n(TAG_ETag, 3, (V[]){v_t2_2427, v_as2_2428, v_ts2_2429});
        heff_room[1] = v_arms_242;
        heff_room[2] = v_s_2410;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_2411, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2411, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2410});
      }
      default: return heff_nomatch(v_it1_2411);
      }
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args) {
  V v_s_2448 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2448});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args) {
  V v_s_2451 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2451});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_x_2452 = heff_env(self)[1];
  V v_a_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2452, v_a_2453, v_x_2458}), v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args) {
  V v_s_2462 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2462});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args) {
  V v_s_2467 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2467});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args) {
  V v_s_2472 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2472});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args) {
  V v_s_2482 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2482});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args) {
  V v_s_2485 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2485});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args) {
  V v_s_2488 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2488});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args) {
  V v_s_2490 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2490});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args) {
  V v_s_2492 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2492});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args) {
  V v_s_2494 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2494});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args) {
  V v_s_2496 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2496});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args) {
  V v_s_2499 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2499});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args) {
  V v_s_24101 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24101});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args) {
  V v_s_24102 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24102});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam18(V self, V *args) {
  V v_s_24105 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24105});
}
Clo g_heff_2ecompile_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 4, 7);
    V v_x3_245 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_x3_248;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 2, 7);
      v_x3_248 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_x3_248 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    V v_x2_2410;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nothing: {
      heff_drop(v_h_242);
      v_x2_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
      break;
    }
    case TAG_Just: {
      V v_b0_249 = heff_field(v_x3_248, 0);
      heff_take_n(v_x3_248, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      v_x2_2410 = (g_heff_2ecompile_2esimplify_2emakeOne(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), v_h_242, v_b0_249, v_p_241));
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_m_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), 1, (V[]){v_rest_243}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_x_2417 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2411, v_x_2415));
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_s_2416});
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeEach(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2edoneOf_str0, 0, "");
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edoneOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edoneOf_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2edoneOf(V v_s_240, V v_d_241, V v_b_242, V v_t_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_d_241, 0)), heff_rfield(v_s_240, 3)));
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  V v_t_248 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_247));
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2edoneOf_lam0, 1, 1, (V[]){v_s_240}), v_t_248));
  return heff_rec_n(4, shape_key__body__safe__touched, (V[]){heff_get_n(v_d_241, 0, 3), v_b_242, v_t_246, v_t_2414});
}
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edoneOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args) {
  V v_h_249 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 8, 9), 0, 5);
  V v_x2_2411 = ({ V a_0 = heff_dup(v_h_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2ecompile_2esimplify_2edoneOf_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_249, v_t_2413});
}
Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2econcatDefs(a0); heff_drop(a0); return r;
}