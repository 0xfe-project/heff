// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrowDown 21357
#define TAG_ArrowLeft 52976
#define TAG_ArrowRight 29566
#define TAG_ArrowUp 57900
#define TAG_BackTab 60780
#define TAG_Backspace 1027
#define TAG_Bold 53386
#define TAG_Char 10597
#define TAG_Continue 52606
#define TAG_Control 37853
#define TAG_Delete 50238
#define TAG_Dim 16148
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Home 35586
#define TAG_Inverse 25398
#define TAG_PageDown 11812
#define TAG_PageUp 3751
#define TAG_Plain 3036
#define TAG_Sequence 46672
#define TAG_Tab 31265
#define TAG_Underline 15894
#define LBL_at 9882
#define LBL_columns 1181578779
#define LBL_cursor 598022785
#define LBL_key 315609
#define LBL_next 9873338
#define LBL_options 1129866465
#define LBL_rows 10002080
#define LBL_style 311138763
#define LBL_text 10052084
static uint32_t shape_at[] = {LBL_at};
static uint32_t shape_key__next[] = {LBL_key, LBL_next};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s857425298x1024652640(V);
V g_list_2emap_24s857425298x1024652640_entry(V self, V *a);
extern Clo g_list_2emap_24s857425298x1024652640_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_rune_2eisSpace(V);
V g_rune_2eisSpace_entry(V self, V *a);
extern Clo g_rune_2eisSpace_clo;
V g_std_2eterminal_2ewidget_2ebold(V);
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ebold_clo;
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(V, V, V, V);
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_clo;
V g_std_2eterminal_2ewidget_2echoiceKey(V, V);
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceKey_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
V g_std_2eterminal_2ewidget_2econtrolEdit(V, V);
V g_std_2eterminal_2ewidget_2econtrolEdit_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolEdit_clo;
V g_std_2eterminal_2ewidget_2econtrolKey(V);
V g_std_2eterminal_2ewidget_2econtrolKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolKey_clo;
V g_std_2eterminal_2ewidget_2econtrolMove(V, V, V);
V g_std_2eterminal_2ewidget_2econtrolMove_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolMove_clo;
V g_std_2eterminal_2ewidget_2ecsiAt(V, V);
V g_std_2eterminal_2ewidget_2ecsiAt_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecsiAt_clo;
V g_std_2eterminal_2ewidget_2ecsiEnd(V, V);
V g_std_2eterminal_2ewidget_2ecsiEnd_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecsiEnd_clo;
V g_std_2eterminal_2ewidget_2ecutRunes(V, V);
V g_std_2eterminal_2ewidget_2ecutRunes_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecutRunes_clo;
V g_std_2eterminal_2ewidget_2ecutRunes_24dps(V, V, V);
V g_std_2eterminal_2ewidget_2ecutRunes_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecutRunes_24dps_clo;
V g_std_2eterminal_2ewidget_2edecodeFrom(V, V);
V g_std_2eterminal_2ewidget_2edecodeFrom_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecodeFrom_clo;
V g_std_2eterminal_2ewidget_2edecodeFrom_24dps(V, V, V);
V g_std_2eterminal_2ewidget_2edecodeFrom_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecodeFrom_24dps_clo;
V g_std_2eterminal_2ewidget_2eescapeAt(V, V);
V g_std_2eterminal_2ewidget_2eescapeAt_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2eescapeAt_clo;
V g_std_2eterminal_2ewidget_2efieldKey(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_clo;
V g_std_2eterminal_2ewidget_2efinalKey(V, V, V);
V g_std_2eterminal_2ewidget_2efinalKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efinalKey_clo;
V g_std_2eterminal_2ewidget_2einverse(V);
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2einverse_clo;
V g_std_2eterminal_2ewidget_2ekeyAt(V, V);
V g_std_2eterminal_2ewidget_2ekeyAt_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ekeyAt_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
V g_std_2eterminal_2ewidget_2emenuFrom(V, V, V);
V g_std_2eterminal_2ewidget_2emenuFrom_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuFrom_clo;
V g_std_2eterminal_2ewidget_2emenuFrom_24dps(V, V, V, V);
V g_std_2eterminal_2ewidget_2emenuFrom_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuFrom_24dps_clo;
V g_std_2eterminal_2ewidget_2emenuKey(V, V, V);
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuKey_clo;
V g_std_2eterminal_2ewidget_2epad(V, V);
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epad_clo;
V g_std_2eterminal_2ewidget_2epaint(V, V);
V g_std_2eterminal_2ewidget_2epaint_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaint_clo;
V g_std_2eterminal_2ewidget_2epaintSpans(V, V);
V g_std_2eterminal_2ewidget_2epaintSpans_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaintSpans_clo;
V g_std_2eterminal_2ewidget_2epaintSpans_24acc(V, V, V);
V g_std_2eterminal_2ewidget_2epaintSpans_24acc_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaintSpans_24acc_clo;
V g_std_2eterminal_2ewidget_2ess3At(V, V);
V g_std_2eterminal_2ewidget_2ess3At_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ess3At_clo;
HeffT2 g_std_2eterminal_2ewidget_2estepAll_24cpr(V, V, V);
V g_std_2eterminal_2ewidget_2etildeKey(V, V);
V g_std_2eterminal_2ewidget_2etildeKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2etildeKey_clo;
V g_std_2eterminal_2ewidget_2ewordFrom(V, V);
V g_std_2eterminal_2ewidget_2ewordFrom_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewordFrom_clo;
V g_std_2eterminal_2ewidget_2ewordStart(V, V);
V g_std_2eterminal_2ewidget_2ewordStart_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewordStart_clo;
V g_std_2eterminal_2ewidget_2ewrapGo(V, V, V);
V g_std_2eterminal_2ewidget_2ewrapGo_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrapGo_clo;
V g_std_2eterminal_2ewidget_2ewrapGo_24dps(V, V, V, V);
V g_std_2eterminal_2ewidget_2ewrapGo_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrapGo_24dps_clo;
Clo g_std_2eterminal_2ewidget_2ecsiEnd_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecsiEnd_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ecsiEnd(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_j_241))) {
    heff_drop(v_j_241);
    return MK_INT(-1LL);
  } else {
    if ((((int64_t)64ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) <= ((int64_t)126ULL))) {
        return v_j_241;
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_j_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
  }
}
V g_std_2eterminal_2ewidget_2ecsiEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ecsiEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2etildeKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2etildeKey_entry, 2, 0};

V g_std_2eterminal_2ewidget_2etildeKey(V v_seq_240, V v_n_241) {
top: ;
  if (heff_intEq_c_lent(v_n_241, MK_INT(1LL), 2)) {
    heff_drop(v_seq_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Home);
  } else {
    if (heff_intEq_c_lent(v_n_241, MK_INT(7LL), 2)) {
      heff_drop(v_seq_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Home);
    } else {
      if (heff_intEq_c_lent(v_n_241, MK_INT(4LL), 2)) {
        heff_drop(v_seq_240);
        heff_drop(v_n_241);
        return NTAG(TAG_End);
      } else {
        if (heff_intEq_c_lent(v_n_241, MK_INT(8LL), 2)) {
          heff_drop(v_seq_240);
          heff_drop(v_n_241);
          return NTAG(TAG_End);
        } else {
          if (heff_intEq_c_lent(v_n_241, MK_INT(3LL), 2)) {
            heff_drop(v_seq_240);
            heff_drop(v_n_241);
            return NTAG(TAG_Delete);
          } else {
            if (heff_intEq_c_lent(v_n_241, MK_INT(5LL), 2)) {
              heff_drop(v_seq_240);
              heff_drop(v_n_241);
              return NTAG(TAG_PageUp);
            } else {
              if (heff_intEq_c(v_n_241, MK_INT(6LL))) {
                heff_drop(v_seq_240);
                return NTAG(TAG_PageDown);
              } else {
                return heff_tag_n(TAG_Sequence, 1, (V[]){v_seq_240});
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2etildeKey_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2etildeKey(a[0], a[1]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2efinalKey_str0, 1, ";");
HEFF_LIT(g_std_2eterminal_2ewidget_2efinalKey_str1, 1, ";");
Clo g_std_2eterminal_2ewidget_2efinalKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2efinalKey_entry, 3, 0};

V g_std_2eterminal_2ewidget_2efinalKey(V v_seq_240, V v_params_241, V v_box_24b_242) {
  int64_t v_b_242 = heff_unbox_word(v_box_24b_242);
top: ;
  if ((v_b_242 == ((int64_t)65ULL))) {
    heff_drop(v_seq_240);
    return NTAG(TAG_ArrowUp);
  } else {
    if ((v_b_242 == ((int64_t)66ULL))) {
      heff_drop(v_seq_240);
      return NTAG(TAG_ArrowDown);
    } else {
      if ((v_b_242 == ((int64_t)67ULL))) {
        heff_drop(v_seq_240);
        return NTAG(TAG_ArrowRight);
      } else {
        if ((v_b_242 == ((int64_t)68ULL))) {
          heff_drop(v_seq_240);
          return NTAG(TAG_ArrowLeft);
        } else {
          if ((v_b_242 == ((int64_t)72ULL))) {
            heff_drop(v_seq_240);
            return NTAG(TAG_Home);
          } else {
            if ((v_b_242 == ((int64_t)70ULL))) {
              heff_drop(v_seq_240);
              return NTAG(TAG_End);
            } else {
              if ((v_b_242 == ((int64_t)90ULL))) {
                heff_drop(v_seq_240);
                return NTAG(TAG_BackTab);
              } else {
                if ((v_b_242 == ((int64_t)126ULL))) {
                  V v_x1_2411 = ({ V b_0 = ((V)&g_std_2eterminal_2ewidget_2efinalKey_str0); V a_1 = v_params_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2eterminal_2ewidget_2efinalKey_str1), v_params_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
                  V v_t_2419;
                  switch (heff_tag_of(v_x1_2411)) {
                  case TAG_Nil: {
                    v_t_2419 = MK_INT(0LL);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_2412 = heff_field(v_x1_2411, 0);
                    heff_take_n(v_x1_2411, 1ULL, 2);
                    HeffT2 v_t_2414 = ({ V a_0 = v_x_2412; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_x_2412); r_; });
                    {
                      V v_field_2416 = v_t_2414.f[1];
                      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                      if ((v_tag_2415 == ((int64_t)0ULL))) {
                        V v_x_2418 = v_field_2416;
                        v_t_2419 = v_x_2418;
                      } else {
                        heff_drop(v_field_2416);
                        v_t_2419 = MK_INT(0LL);
                      }
                    }
                    break;
                  }
                  default: heff_nomatch(v_x1_2411);
                  }
                  return (g_std_2eterminal_2ewidget_2etildeKey(v_seq_240, v_t_2419));
                } else {
                  return heff_tag_n(TAG_Sequence, 1, (V[]){v_seq_240});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2efinalKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2efinalKey(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2eterminal_2ewidget_2ecsiAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecsiAt_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ecsiAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
  if (heff_intLt_c(v_t_242, MK_INT(0LL))) {
    V v_t_244 = heff_strSlice(heff_dup(v_s_240), v_i_241, heff_strLength_lent(v_s_240, 0));
    return heff_rec_n(2, shape_key__next, (V[]){heff_tag_n(TAG_Sequence, 1, (V[]){v_t_244}), heff_strLength_lent(v_s_240, 0)});
  } else {
    V v_t_245 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
    V v_t_246 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(v_t_245, MK_INT(1LL)));
    V v_t_247 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
    V v_t_248 = heff_strSlice(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)), v_t_247);
    V v_t_249 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
    V v_t_2410 = ({ V a_0 = v_t_246; V a_1 = v_t_248; V a_2 = heff_strByteAt_lent(v_s_240, v_t_249, 2); V r_ = (g_std_2eterminal_2ewidget_2efinalKey(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V v_t_2411 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_240, heff_intAdd(v_i_241, MK_INT(2LL))));
    return heff_rec_n(2, shape_key__next, (V[]){v_t_2410, heff_intAdd(v_t_2411, MK_INT(1LL))});
  }
}
V g_std_2eterminal_2ewidget_2ecsiAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ecsiAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2ess3At_str0, 0, "");
Clo g_std_2eterminal_2ewidget_2ess3At_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ess3At_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ess3At(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)))) {
    return heff_rec_n(2, shape_key__next, (V[]){NTAG(TAG_Escape), heff_intAdd(v_i_241, MK_INT(1LL))});
  } else {
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(3LL)));
    V v_t_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
    V v_t_245 = ({ V a_0 = v_t_243; V b_1 = ((V)&g_std_2eterminal_2ewidget_2ess3At_str0); V a_2 = v_t_244; V r_ = (g_std_2eterminal_2ewidget_2efinalKey(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    return heff_rec_n(2, shape_key__next, (V[]){v_t_245, heff_intAdd(v_i_241, MK_INT(3LL))});
  }
}
V g_std_2eterminal_2ewidget_2ess3At_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ess3At(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2eescapeAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2eescapeAt_entry, 2, 0};

V g_std_2eterminal_2ewidget_2eescapeAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
  if ((heff_unbox_word(v_t_242) == ((int64_t)91ULL))) {
    HEFF_LAST return g_std_2eterminal_2ewidget_2ecsiAt(v_s_240, v_i_241);
  } else {
    V v_t_244 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_244) == ((int64_t)79ULL))) {
      HEFF_LAST return g_std_2eterminal_2ewidget_2ess3At(v_s_240, v_i_241);
    } else {
      return heff_rec_n(2, shape_key__next, (V[]){NTAG(TAG_Escape), heff_intAdd(v_i_241, MK_INT(1LL))});
    }
  }
}
V g_std_2eterminal_2ewidget_2eescapeAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2eescapeAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2econtrolKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2econtrolKey_entry, 1, 0};

V g_std_2eterminal_2ewidget_2econtrolKey(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  if ((v_b_240 == ((int64_t)13ULL))) {
    return NTAG(TAG_Enter);
  } else {
    if ((v_b_240 == ((int64_t)10ULL))) {
      return NTAG(TAG_Enter);
    } else {
      if ((v_b_240 == ((int64_t)9ULL))) {
        return NTAG(TAG_Tab);
      } else {
        if ((v_b_240 == ((int64_t)8ULL))) {
          return NTAG(TAG_Backspace);
        } else {
          if ((v_b_240 == ((int64_t)127ULL))) {
            return NTAG(TAG_Backspace);
          } else {
            if ((((int64_t)1ULL) <= v_b_240)) {
              if ((v_b_240 <= ((int64_t)26ULL))) {
                V v_t_248 = heff_runeFromInt(heff_box_word((v_b_240 + ((int64_t)96ULL))));
                return heff_tag_n(TAG_Control, 1, (V[]){v_t_248});
              } else {
                V v_t_249 = heff_runeFromInt(heff_box_word((v_b_240 + ((int64_t)64ULL))));
                return heff_tag_n(TAG_Control, 1, (V[]){v_t_249});
              }
            } else {
              V v_t_2410 = heff_runeFromInt(heff_box_word((v_b_240 + ((int64_t)64ULL))));
              return heff_tag_n(TAG_Control, 1, (V[]){v_t_2410});
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2econtrolKey_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2econtrolKey(a[0]);
}
Clo g_std_2eterminal_2ewidget_2ekeyAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ekeyAt_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ekeyAt(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)27ULL))) {
    HEFF_LAST return g_std_2eterminal_2ewidget_2eescapeAt(v_s_240, v_i_241);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)32ULL))) {
      V v_t_244 = (g_std_2eterminal_2ewidget_2econtrolKey(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
      return heff_rec_n(2, shape_key__next, (V[]){v_t_244, heff_intAdd(v_i_241, MK_INT(1LL))});
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)127ULL))) {
        V v_t_246 = (g_std_2eterminal_2ewidget_2econtrolKey(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
        return heff_rec_n(2, shape_key__next, (V[]){v_t_246, heff_intAdd(v_i_241, MK_INT(1LL))});
      } else {
        V v_t_247 = heff_tag_n(TAG_Char, 1, (V[]){heff_strRuneAt_lent(v_s_240, v_i_241, 0)});
        V v_t_248 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_s_240, v_i_241, 2));
        return heff_rec_n(2, shape_key__next, (V[]){v_t_247, v_t_248});
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2ekeyAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ekeyAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2edecodeFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecodeFrom_entry, 2, 0};

V g_std_2eterminal_2ewidget_2edecodeFrom(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_t_243 = (g_std_2eterminal_2ewidget_2ekeyAt(v_s_240, heff_dup(v_i_241)));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_243, 0, 2), heff_hole()});
    V v_t_245 = (g_std_2eterminal_2ewidget_2ekeyAt(v_s_240, v_i_241));
    V v_u_246 = (g_std_2eterminal_2ewidget_2edecodeFrom_24dps(v_s_240, heff_get_n(v_t_245, 1, 2), heff_dup(v_cell_244)));
    heff_drop(v_u_246);
    return v_cell_244;
  }
}
V g_std_2eterminal_2ewidget_2edecodeFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2edecodeFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2edecodeFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecodeFrom_24dps_entry, 3, 0};

V g_std_2eterminal_2ewidget_2edecodeFrom_24dps(V v_s_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_244 = (g_std_2eterminal_2ewidget_2ekeyAt(v_s_240, heff_dup(v_i_241)));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_244, 0, 2), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V v_t_247 = (g_std_2eterminal_2ewidget_2ekeyAt(v_s_240, v_i_241));
    V t_0 = v_s_240;
    V t_1 = heff_get_n(v_t_247, 1, 2);
    V t_2 = v_cell_245;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_std_2eterminal_2ewidget_2edecodeFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2edecodeFrom_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2ecolumns_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecolumns_entry, 1, 0};

V g_std_2eterminal_2ewidget_2ecolumns(V v_c_240) {
top: ;
  V v_t_242 = heff_bool((heff_runeLe_c(MK_INT(4352LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(4447LL))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_c_240);
    heff_drop(v_t_242);
    return MK_INT(2LL);
  } else {
    heff_drop(v_t_242);
    V v_t_244 = heff_bool((heff_runeLe_c(MK_INT(11904LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(42191LL))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_t_244);
      return MK_INT(2LL);
    } else {
      heff_drop(v_t_244);
      V v_t_246 = heff_bool((heff_runeLe_c(MK_INT(44032LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(55203LL))));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_c_240);
        heff_drop(v_t_246);
        return MK_INT(2LL);
      } else {
        heff_drop(v_t_246);
        V v_t_248 = heff_bool((heff_runeLe_c(MK_INT(63744LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(64255LL))));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_c_240);
          heff_drop(v_t_248);
          return MK_INT(2LL);
        } else {
          heff_drop(v_t_248);
          V v_t_2410 = heff_bool((heff_runeLe_c(MK_INT(65072LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(65103LL))));
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop(v_c_240);
            heff_drop(v_t_2410);
            return MK_INT(2LL);
          } else {
            heff_drop(v_t_2410);
            V v_t_2412 = heff_bool((heff_runeLe_c(MK_INT(65280LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(65376LL))));
            if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
              heff_drop(v_c_240);
              heff_drop(v_t_2412);
              return MK_INT(2LL);
            } else {
              heff_drop(v_t_2412);
              V v_t_2414 = heff_bool((heff_runeLe_c(MK_INT(65504LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(65510LL))));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_c_240);
                heff_drop(v_t_2414);
                return MK_INT(2LL);
              } else {
                heff_drop(v_t_2414);
                if (heff_runeLe_c(MK_INT(127744LL), heff_dup(v_c_240))) {
                  if (heff_runeLe_c(heff_dup(v_c_240), MK_INT(128591LL))) {
                    heff_drop(v_c_240);
                    return MK_INT(2LL);
                  } else {
                    if (heff_runeLe_c(MK_INT(129280LL), heff_dup(v_c_240))) {
                      if (heff_runeLe_c(heff_dup(v_c_240), MK_INT(129535LL))) {
                        heff_drop(v_c_240);
                        return MK_INT(2LL);
                      } else {
                        if (heff_runeLe_c(MK_INT(131072LL), heff_dup(v_c_240))) {
                          if (heff_runeLe_c(v_c_240, MK_INT(262141LL))) {
                            return MK_INT(2LL);
                          } else {
                            return MK_INT(1LL);
                          }
                        } else {
                          heff_drop(v_c_240);
                          return MK_INT(1LL);
                        }
                      }
                    } else {
                      if (heff_runeLe_c(MK_INT(131072LL), heff_dup(v_c_240))) {
                        if (heff_runeLe_c(v_c_240, MK_INT(262141LL))) {
                          return MK_INT(2LL);
                        } else {
                          return MK_INT(1LL);
                        }
                      } else {
                        heff_drop(v_c_240);
                        return MK_INT(1LL);
                      }
                    }
                  }
                } else {
                  if (heff_runeLe_c(MK_INT(129280LL), heff_dup(v_c_240))) {
                    if (heff_runeLe_c(heff_dup(v_c_240), MK_INT(129535LL))) {
                      heff_drop(v_c_240);
                      return MK_INT(2LL);
                    } else {
                      if (heff_runeLe_c(MK_INT(131072LL), heff_dup(v_c_240))) {
                        if (heff_runeLe_c(v_c_240, MK_INT(262141LL))) {
                          return MK_INT(2LL);
                        } else {
                          return MK_INT(1LL);
                        }
                      } else {
                        heff_drop(v_c_240);
                        return MK_INT(1LL);
                      }
                    }
                  } else {
                    if (heff_runeLe_c(MK_INT(131072LL), heff_dup(v_c_240))) {
                      if (heff_runeLe_c(v_c_240, MK_INT(262141LL))) {
                        return MK_INT(2LL);
                      } else {
                        return MK_INT(1LL);
                      }
                    } else {
                      heff_drop(v_c_240);
                      return MK_INT(1LL);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ecolumns(a[0]);
}
Clo g_std_2eterminal_2ewidget_2ecutRunes_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecutRunes_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ecutRunes(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_c_242)));
    if (heff_intLt_c_lent(v_w_240, v_x_244, 2)) {
      heff_drop(v_w_240);
      heff_drop(v_c_242);
      heff_drop(v_cs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
      V v_t_247 = (g_std_2eterminal_2ewidget_2ecolumns(v_c_242));
      V v_u_248 = (g_std_2eterminal_2ewidget_2ecutRunes_24dps(heff_intSub(v_w_240, v_t_247), v_cs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_248);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2ecutRunes_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ecutRunes(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2ecutRunes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecutRunes_24dps_entry, 3, 0};

V g_std_2eterminal_2ewidget_2ecutRunes_24dps(V v_w_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_cs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_c_243)));
    if (heff_intLt_c_lent(v_w_240, v_x_245, 2)) {
      heff_drop(v_w_240);
      heff_drop(v_c_243);
      heff_drop(v_cs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_243), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_t_249 = (g_std_2eterminal_2ewidget_2ecolumns(v_c_243));
      V t_0 = heff_intSub(v_w_240, v_t_249);
      V t_1 = v_cs_244;
      V t_2 = v_cell_247;
      v_w_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2ecutRunes_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ecutRunes_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epad_str0, 1, " ");
HEFF_LIT(g_std_2eterminal_2ewidget_2epad_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epad_str2, 0, "");
Clo g_std_2eterminal_2ewidget_2epad_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epad_entry, 2, 0};

V g_std_2eterminal_2ewidget_2epad(V v_w_240, V v_s_241) {
top: ;
  V v_t_242 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(heff_dup(v_s_241))));
  V v_t_243 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(v_s_241)));
  V v_s_244 = heff_strOfRunes(v_t_243);
  V v_t_245 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(v_s_244); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x2_246 = (g_list_2ereplicate(heff_intSub(v_w_240, v_t_245), ((V)&g_std_2eterminal_2ewidget_2epad_str0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_std_2eterminal_2ewidget_2epad_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_std_2eterminal_2ewidget_2epad_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  return heff_strAppend(heff_strOfRunes(v_t_242), v_t_249);
}
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2epad(a[0], a[1]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrapGo_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrapGo_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrapGo_str2, 1, " ");
Clo g_std_2eterminal_2ewidget_2ewrapGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewrapGo_entry, 3, 0};

V g_std_2eterminal_2ewidget_2ewrapGo(V v_w_240, V v_line_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrapGo_str0), 2)) {
      heff_drop(v_line_241);
      return NTAG(TAG_Nil);
    } else {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_line_241, NTAG(TAG_Nil)});
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrapGo_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_244;
      V t_2 = v_xs_245;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      V v_t_247 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_line_241)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_248 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_x_244)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_249 = heff_intAdd(heff_intAdd(v_t_247, MK_INT(1LL)), v_t_248);
      if (heff_intLe_c_lent(v_t_249, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2411 = heff_strAppend(v_line_241, heff_strAppend(((V)&g_std_2eterminal_2ewidget_2ewrapGo_str2), v_x_244));
        V t_0 = v_w_240;
        V t_1 = v_t_2411;
        V t_2 = v_xs_245;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_line_241, heff_hole()});
        V v_u_2413 = (g_std_2eterminal_2ewidget_2ewrapGo_24dps(v_w_240, v_x_244, v_xs_245, heff_dup(v_cell_2412)));
        heff_drop(v_u_2413);
        return v_cell_2412;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eterminal_2ewidget_2ewrapGo_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ewrapGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrapGo_24dps_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrapGo_24dps_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrapGo_24dps_str2, 1, " ");
Clo g_std_2eterminal_2ewidget_2ewrapGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewrapGo_24dps_entry, 4, 0};

V g_std_2eterminal_2ewidget_2ewrapGo_24dps(V v_w_240, V v_line_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrapGo_24dps_str0), 2)) {
      heff_drop(v_line_241);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_line_241, NTAG(TAG_Nil)});
      return heff_setField(v_d_243, MK_INT(1LL), v_t_245);
    }
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_242, 0);
    V v_xs_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrapGo_24dps_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_246;
      V t_2 = v_xs_247;
      V t_3 = v_d_243;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_t_249 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_line_241)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2410 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_x_246)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2411 = heff_intAdd(heff_intAdd(v_t_249, MK_INT(1LL)), v_t_2410);
      if (heff_intLe_c_lent(v_t_2411, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2413 = heff_strAppend(v_line_241, heff_strAppend(((V)&g_std_2eterminal_2ewidget_2ewrapGo_24dps_str2), v_x_246));
        V t_0 = v_w_240;
        V t_1 = v_t_2413;
        V t_2 = v_xs_247;
        V t_3 = v_d_243;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        V v_cell_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_line_241, heff_hole()});
        V v_u_2415 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V t_0 = v_w_240;
        V t_1 = v_x_246;
        V t_2 = v_xs_247;
        V t_3 = v_cell_2414;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eterminal_2ewidget_2ewrapGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ewrapGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_std_2eterminal_2ewidget_2ebold_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ebold_entry, 1, 0};

V g_std_2eterminal_2ewidget_2ebold(V v_s_240) {
top: ;
  return heff_rec_n(2, shape_text__style, (V[]){v_s_240, NTAG(TAG_Bold)});
}
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ebold(a[0]);
}
Clo g_std_2eterminal_2ewidget_2einverse_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2einverse_entry, 1, 0};

V g_std_2eterminal_2ewidget_2einverse(V v_s_240) {
top: ;
  return heff_rec_n(2, shape_text__style, (V[]){v_s_240, NTAG(TAG_Inverse)});
}
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2einverse(a[0]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str1, 4, "\033[0m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str2, 6, "\033[0;1m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str3, 6, "\033[0;2m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str4, 6, "\033[0;7m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str5, 6, "\033[0;4m");
Clo g_std_2eterminal_2ewidget_2epaintSpans_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epaintSpans_entry, 2, 0};

V g_std_2eterminal_2ewidget_2epaintSpans(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str0);
  }
  case TAG_Cons: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_sp_242, 1));
    V v_s_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Plain: {
      v_s_245 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str1);
      break;
    }
    case TAG_Bold: {
      v_s_245 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str2);
      break;
    }
    case TAG_Dim: {
      v_s_245 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str3);
      break;
    }
    case TAG_Inverse: {
      v_s_245 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str4);
      break;
    }
    case TAG_Underline: {
      v_s_245 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str5);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_246 = heff_strRunes(heff_dup(heff_rfield(v_sp_242, 0)));
    V v_t_247 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), v_t_246));
    V v_s_248 = heff_strAppend(v_s_245, heff_strOfRunes(v_t_247));
    V v_t_249 = heff_strRunes(heff_dup(heff_rfield(v_sp_242, 0)));
    V v_t_2410 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), v_t_249));
    V v_s_2411 = heff_strOfRunes(v_t_2410);
    V v_t_2412 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(v_s_2411); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
    return (g_std_2eterminal_2ewidget_2epaintSpans_24acc(heff_intSub(v_w_240, v_t_2412), v_rest_243, v_s_248));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2epaintSpans_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2epaintSpans(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str1, 4, "\033[0m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str2, 6, "\033[0;1m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str3, 6, "\033[0;2m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str4, 6, "\033[0;7m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str5, 6, "\033[0;4m");
Clo g_std_2eterminal_2ewidget_2epaintSpans_24acc_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epaintSpans_24acc_entry, 3, 0};

V g_std_2eterminal_2ewidget_2epaintSpans_24acc(V v_w_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return heff_strAppend(v_acc_242, ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str0));
  }
  case TAG_Cons: {
    V v_sp_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_dup(heff_rfield(v_sp_243, 1));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Plain: {
      v_t_246 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str1);
      break;
    }
    case TAG_Bold: {
      v_t_246 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str2);
      break;
    }
    case TAG_Dim: {
      v_t_246 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str3);
      break;
    }
    case TAG_Inverse: {
      v_t_246 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str4);
      break;
    }
    case TAG_Underline: {
      v_t_246 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str5);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_s_247 = heff_strAppend(v_acc_242, v_t_246);
    V v_t_248 = heff_strRunes(heff_dup(heff_rfield(v_sp_243, 0)));
    V v_t_249 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), v_t_248));
    V v_s_2410 = heff_strAppend(v_s_247, heff_strOfRunes(v_t_249));
    V v_t_2411 = heff_strRunes(heff_dup(heff_rfield(v_sp_243, 0)));
    V v_t_2412 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), v_t_2411));
    V v_s_2413 = heff_strOfRunes(v_t_2412);
    V v_t_2414 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(v_s_2413); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
    V t_0 = heff_intSub(v_w_240, v_t_2414);
    V t_1 = v_rest_244;
    V t_2 = v_s_2410;
    v_w_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2epaintSpans_24acc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2epaintSpans_24acc(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str0, 7, "\033[0m\033[K");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str2, 2, "\015\012");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str3, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str4, 1, ";");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str5, 7, "H\033[\?25h");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str6, 2, "\033[");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str7, 7, "\033[0m\033[J");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str8, 8, "\033[\?2026l");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaint_str9, 17, "\033[\?2026h\033[\?25l\033[H");
V g_std_2eterminal_2ewidget_2epaint_lam0(V self, V *args);
Clo g_std_2eterminal_2ewidget_2epaint_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epaint_entry, 2, 0};

V g_std_2eterminal_2ewidget_2epaint(V v_size_240, V v_f_241) {
top: ;
  V v_t_242 = (g_list_2etake(heff_dup(heff_rfield(v_size_240, 1)), heff_take_field(v_f_241, 0)));
  V v_x2_245 = (g_list_2emap(heff_clo_n(g_std_2eterminal_2ewidget_2epaint_lam0, 1, 1, (V[]){v_size_240}), v_t_242));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_std_2eterminal_2ewidget_2epaint_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_std_2eterminal_2ewidget_2epaint_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_get_n(v_f_241, 1, 2);
  V v_t_2416;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_std_2eterminal_2ewidget_2epaint_str3);
    break;
  }
  case TAG_Just: {
    V v_x11_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_MkPair: {
      V v_c_2411 = heff_field(v_x11_2410, 0);
      V v_r_2412 = heff_field(v_x11_2410, 1);
      heff_take_n(v_x11_2410, 3ULL, 2);
      V v_t_2413 = heff_intShow(heff_intAdd(v_r_2412, MK_INT(1LL)));
      V v_t_2414 = heff_intShow(heff_intAdd(v_c_2411, MK_INT(1LL)));
      V v_t_2415 = heff_strAppend(((V)&g_std_2eterminal_2ewidget_2epaint_str4), heff_strAppend(v_t_2414, ((V)&g_std_2eterminal_2ewidget_2epaint_str5)));
      v_t_2416 = heff_strAppend(((V)&g_std_2eterminal_2ewidget_2epaint_str6), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x11_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2417 = heff_strAppend(((V)&g_std_2eterminal_2ewidget_2epaint_str7), heff_strAppend(v_t_2416, ((V)&g_std_2eterminal_2ewidget_2epaint_str8)));
  return heff_strAppend(((V)&g_std_2eterminal_2ewidget_2epaint_str9), heff_strAppend(v_t_248, v_t_2417));
}
V g_std_2eterminal_2ewidget_2epaint_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2epaint(a[0], a[1]);
}
V g_std_2eterminal_2ewidget_2epaint_lam0(V self, V *args) {
  V v_r_243 = args[0];
  V v_size_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_get_n(v_size_240, 0, 2); V a_1 = v_r_243; V r_ = (g_std_2eterminal_2ewidget_2epaintSpans(a_0, a_1)); heff_drop(v_r_243); r_; });
  return heff_strAppend(v_t_244, ((V)&g_std_2eterminal_2ewidget_2epaint_str0));
}

static V g_std_2eterminal_2ewidget_2emenu_val;
static HEFF_ONCE g_std_2eterminal_2ewidget_2emenu_st;
static V g_std_2eterminal_2ewidget_2emenu_init(void) {
  return heff_rec_n(1, shape_at, (V[]){MK_INT(0LL)});
}
V g_std_2eterminal_2ewidget_2emenu_get(void) {
  if (HEFF_DONE(g_std_2eterminal_2ewidget_2emenu_st)) return g_std_2eterminal_2ewidget_2emenu_val;
  return heff_global(&g_std_2eterminal_2ewidget_2emenu_val, &g_std_2eterminal_2ewidget_2emenu_st, g_std_2eterminal_2ewidget_2emenu_init);
}
Clo g_std_2eterminal_2ewidget_2econtrolMove_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2econtrolMove_entry, 3, 0};

V g_std_2eterminal_2ewidget_2econtrolMove(V v_n_240, V v_c_241, V v_m_242) {
top: ;
  if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(110LL))) {
    heff_drop(v_c_241);
    V v_i_244 = heff_intAdd(heff_get_n(v_m_242, 0, 1), MK_INT(1LL));
    V v_t_249;
    if (heff_intLe_c_lent(v_n_240, v_i_244, 0)) {
      heff_drop(v_i_244);
      V v_y_246 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
        v_t_249 = v_y_246;
      } else {
        heff_drop(v_y_246);
        v_t_249 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_244, MK_INT(0LL), 2)) {
        heff_drop(v_i_244);
        v_t_249 = MK_INT(0LL);
      } else {
        v_t_249 = v_i_244;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_249});
  } else {
    if (heff_runeEq_c(v_c_241, MK_INT(112LL))) {
      V v_i_2411 = heff_intAdd(heff_get_n(v_m_242, 0, 1), MK_INT(-1LL));
      V v_t_2416;
      if (heff_intLe_c_lent(v_n_240, v_i_2411, 0)) {
        heff_drop(v_i_2411);
        V v_y_2413 = heff_intSub(v_n_240, MK_INT(1LL));
        if (heff_intLe_c_lent(MK_INT(0LL), v_y_2413, 1)) {
          v_t_2416 = v_y_2413;
        } else {
          heff_drop(v_y_2413);
          v_t_2416 = MK_INT(0LL);
        }
      } else {
        heff_drop(v_n_240);
        if (heff_intLt_c_lent(v_i_2411, MK_INT(0LL), 2)) {
          heff_drop(v_i_2411);
          v_t_2416 = MK_INT(0LL);
        } else {
          v_t_2416 = v_i_2411;
        }
      }
      return heff_rec_n(1, shape_at, (V[]){v_t_2416});
    } else {
      heff_drop(v_n_240);
      return v_m_242;
    }
  }
}
V g_std_2eterminal_2ewidget_2econtrolMove_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2econtrolMove(a[0], a[1], a[2]);
}
Clo g_std_2eterminal_2ewidget_2emenuKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2emenuKey_entry, 3, 0};

V g_std_2eterminal_2ewidget_2emenuKey(V v_n_240, V v_k_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_k_241)) {
  case TAG_Char: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Enter: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Escape: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Tab: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_BackTab: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Backspace: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Delete: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_ArrowUp: {
    V v_i_244 = heff_intAdd(heff_get_n(v_m_242, 0, 1), MK_INT(-1LL));
    V v_t_249;
    if (heff_intLe_c_lent(v_n_240, v_i_244, 0)) {
      heff_drop(v_i_244);
      V v_y_246 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
        v_t_249 = v_y_246;
      } else {
        heff_drop(v_y_246);
        v_t_249 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_244, MK_INT(0LL), 2)) {
        heff_drop(v_i_244);
        v_t_249 = MK_INT(0LL);
      } else {
        v_t_249 = v_i_244;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_249});
  }
  case TAG_ArrowDown: {
    V v_i_2410 = heff_intAdd(heff_get_n(v_m_242, 0, 1), MK_INT(1LL));
    V v_t_2415;
    if (heff_intLe_c_lent(v_n_240, v_i_2410, 0)) {
      heff_drop(v_i_2410);
      V v_y_2412 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2412, 1)) {
        v_t_2415 = v_y_2412;
      } else {
        heff_drop(v_y_2412);
        v_t_2415 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2410, MK_INT(0LL), 2)) {
        heff_drop(v_i_2410);
        v_t_2415 = MK_INT(0LL);
      } else {
        v_t_2415 = v_i_2410;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_2415});
  }
  case TAG_ArrowLeft: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_ArrowRight: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Home: {
    heff_drop(v_n_240);
    heff_drop_rec(v_m_242, 1);
    return heff_rec_n(1, shape_at, (V[]){MK_INT(0LL)});
  }
  case TAG_End: {
    heff_drop_rec(v_m_242, 1);
    V v_i_2416 = heff_intSub(heff_dup(v_n_240), MK_INT(1LL));
    V v_t_2421;
    if (heff_intLe_c_lent(v_n_240, v_i_2416, 0)) {
      heff_drop(v_i_2416);
      V v_y_2418 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2418, 1)) {
        v_t_2421 = v_y_2418;
      } else {
        heff_drop(v_y_2418);
        v_t_2421 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2416, MK_INT(0LL), 2)) {
        heff_drop(v_i_2416);
        v_t_2421 = MK_INT(0LL);
      } else {
        v_t_2421 = v_i_2416;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_2421});
  }
  case TAG_PageUp: {
    V v_i_2422 = heff_intAdd(heff_get_n(v_m_242, 0, 1), MK_INT(-10LL));
    V v_t_2427;
    if (heff_intLe_c_lent(v_n_240, v_i_2422, 0)) {
      heff_drop(v_i_2422);
      V v_y_2424 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2424, 1)) {
        v_t_2427 = v_y_2424;
      } else {
        heff_drop(v_y_2424);
        v_t_2427 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2422, MK_INT(0LL), 2)) {
        heff_drop(v_i_2422);
        v_t_2427 = MK_INT(0LL);
      } else {
        v_t_2427 = v_i_2422;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_2427});
  }
  case TAG_PageDown: {
    V v_i_2428 = heff_intAdd(heff_get_n(v_m_242, 0, 1), MK_INT(10LL));
    V v_t_2433;
    if (heff_intLe_c_lent(v_n_240, v_i_2428, 0)) {
      heff_drop(v_i_2428);
      V v_y_2430 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2430, 1)) {
        v_t_2433 = v_y_2430;
      } else {
        heff_drop(v_y_2430);
        v_t_2433 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2428, MK_INT(0LL), 2)) {
        heff_drop(v_i_2428);
        v_t_2433 = MK_INT(0LL);
      } else {
        v_t_2433 = v_i_2428;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_2433});
  }
  case TAG_Control: {
    V v_c_2434 = heff_field(v_k_241, 0);
    HEFF_LAST return g_std_2eterminal_2ewidget_2econtrolMove(v_n_240, heff_dup(v_c_2434), v_m_242);
  }
  case TAG_Sequence: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  default: return heff_nomatch(v_k_241);
  }
}
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2emenuKey(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuFrom_str0, 2, "> ");
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuFrom_str1, 2, "  ");
Clo g_std_2eterminal_2ewidget_2emenuFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2emenuFrom_entry, 3, 0};

V g_std_2eterminal_2ewidget_2emenuFrom(V v_at_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249;
    if (heff_intEq_c_lent(v_i_241, v_at_240, 0)) {
      V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuFrom_str0), NTAG(TAG_Inverse)});
      V v_t_247 = (g_list_2emap_24s857425298x1024652640(v_r_243));
      v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, v_t_247});
    } else {
      V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuFrom_str1), NTAG(TAG_Plain)});
      v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_r_243});
    }
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_std_2eterminal_2ewidget_2emenuFrom_24dps(v_at_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), v_rs_244, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eterminal_2ewidget_2emenuFrom_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2emenuFrom(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuFrom_24dps_str0, 2, "> ");
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuFrom_24dps_str1, 2, "  ");
Clo g_std_2eterminal_2ewidget_2emenuFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2emenuFrom_24dps_entry, 4, 0};

V g_std_2eterminal_2ewidget_2emenuFrom_24dps(V v_at_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x3_242, 0);
    V v_rs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410;
    if (heff_intEq_c_lent(v_i_241, v_at_240, 0)) {
      V v_t_247 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuFrom_24dps_str0), NTAG(TAG_Inverse)});
      V v_t_248 = (g_list_2emap_24s857425298x1024652640(v_r_244));
      v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_t_248});
    } else {
      V v_t_249 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuFrom_24dps_str1), NTAG(TAG_Plain)});
      v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_r_244});
    }
    V v_cell_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_at_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_rs_245;
    V t_3 = v_cell_2411;
    v_at_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eterminal_2ewidget_2emenuFrom_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2emenuFrom_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_std_2eterminal_2ewidget_2ewordFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewordFrom_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ewordFrom(V v_rs_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    HeffT3 v_t_243 = (g_list_2edrop_24cpr(heff_intSub(heff_dup(v_i_241), MK_INT(1LL)), v_rs_240));
    V v_t_2410;
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_245;
        V v_x12_249 = v_field_246;
        heff_drop(v_x12_249);
        v_t_2410 = v_x_248;
      } else {
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        v_t_2410 = MK_INT(32LL);
      }
    }
    V v_x1_2411 = (g_rune_2eisSpace(v_t_2410));
    if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
      heff_drop(v_x1_2411);
      return v_i_241;
    } else {
      heff_drop(v_x1_2411);
      V t_0 = v_rs_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_rs_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  } else {
    return v_i_241;
  }
}
V g_std_2eterminal_2ewidget_2ewordFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ewordFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2ewordStart_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewordStart_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ewordStart(V v_rs_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    HeffT3 v_t_243 = (g_list_2edrop_24cpr(heff_intSub(heff_dup(v_i_241), MK_INT(1LL)), v_rs_240));
    V v_t_2410;
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_245;
        V v_x12_249 = v_field_246;
        heff_drop(v_x12_249);
        v_t_2410 = v_x_248;
      } else {
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        v_t_2410 = MK_INT(32LL);
      }
    }
    V v_t_2411 = (g_rune_2eisSpace(v_t_2410));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V t_0 = v_rs_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_rs_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_2411);
      HEFF_LAST return g_std_2eterminal_2ewidget_2ewordFrom(v_rs_240, v_i_241);
    }
  } else {
    HEFF_LAST return g_std_2eterminal_2ewidget_2ewordFrom(v_rs_240, v_i_241);
  }
}
V g_std_2eterminal_2ewidget_2ewordStart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ewordStart(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2econtrolEdit_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2econtrolEdit_entry, 2, 0};

V g_std_2eterminal_2ewidget_2econtrolEdit(V v_c_240, V v_f_241) {
top: ;
  if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(97LL))) {
    heff_drop(v_c_240);
    V v_x_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_245;
    if (heff_intLe_c_lent(v_x_243, MK_INT(0LL), 2)) {
      v_y_245 = v_x_243;
    } else {
      heff_drop(v_x_243);
      v_y_245 = MK_INT(0LL);
    }
    V v_t_247;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_245, 1)) {
      v_t_247 = v_y_245;
    } else {
      heff_drop(v_y_245);
      v_t_247 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(101LL))) {
      heff_drop(v_c_240);
      V v_i_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
      V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
      V v_y_2412;
      if (heff_intLe_c_lent(v_x_2410, v_i_249, 0)) {
        heff_drop(v_i_249);
        v_y_2412 = v_x_2410;
      } else {
        heff_drop(v_x_2410);
        v_y_2412 = v_i_249;
      }
      V v_t_2414;
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2412, 1)) {
        v_t_2414 = v_y_2412;
      } else {
        heff_drop(v_y_2412);
        v_t_2414 = MK_INT(0LL);
      }
      return ({ V rv_1 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(98LL))) {
        heff_drop(v_c_240);
        V v_i_2416 = heff_intSub(heff_take_field(v_f_241, 1), MK_INT(1LL));
        V v_x_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
        V v_y_2419;
        if (heff_intLe_c_lent(v_x_2417, v_i_2416, 0)) {
          heff_drop(v_i_2416);
          v_y_2419 = v_x_2417;
        } else {
          heff_drop(v_x_2417);
          v_y_2419 = v_i_2416;
        }
        V v_t_2421;
        if (heff_intLe_c_lent(MK_INT(0LL), v_y_2419, 1)) {
          v_t_2421 = v_y_2419;
        } else {
          heff_drop(v_y_2419);
          v_t_2421 = MK_INT(0LL);
        }
        return ({ V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(102LL))) {
          heff_drop(v_c_240);
          V v_i_2423 = heff_intAdd(heff_take_field(v_f_241, 1), MK_INT(1LL));
          V v_x_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
          V v_y_2426;
          if (heff_intLe_c_lent(v_x_2424, v_i_2423, 0)) {
            heff_drop(v_i_2423);
            v_y_2426 = v_x_2424;
          } else {
            heff_drop(v_x_2424);
            v_y_2426 = v_i_2423;
          }
          V v_t_2428;
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_2426, 1)) {
            v_t_2428 = v_y_2426;
          } else {
            heff_drop(v_y_2426);
            v_t_2428 = MK_INT(0LL);
          }
          return ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(104LL))) {
            heff_drop(v_c_240);
            if (heff_intEq_c(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(0LL))) {
              return v_f_241;
            } else {
              V v_t_2431 = heff_intSub(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
              V v_t_2432 = (g_list_2etake(v_t_2431, heff_dup(heff_rfield(v_f_241, 0))));
              V v_t_2433 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
              V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2432, v_t_2433));
              V v_t_2435 = heff_intSub(heff_get_n(v_f_241, 1, 2), MK_INT(1LL));
              return heff_rec_n(2, shape_text__at, (V[]){v_t_2434, v_t_2435});
            }
          } else {
            if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(100LL))) {
              heff_drop(v_c_240);
              V v_t_2437 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_dup(heff_rfield(v_f_241, 0))));
              V v_t_2438 = heff_intAdd(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
              V v_t_2439 = (g_list_2edrop(v_t_2438, heff_rfield(v_f_241, 0)));
              V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2437, v_t_2439));
              return ({ V rv_0 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_f_241, 2ULL, 2, shape_text__at, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            } else {
              if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(117LL))) {
                heff_drop(v_c_240);
                V v_t_2442 = ({ V a_0 = heff_take_field(v_f_241, 1); V b_1 = heff_get_n(v_f_241, 0, 2); V r_ = (g_list_2edrop(a_0, b_1)); heff_drop(b_1); r_; });
                return heff_rec_n(2, shape_text__at, (V[]){v_t_2442, MK_INT(0LL)});
              } else {
                if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(107LL))) {
                  heff_drop(v_c_240);
                  V v_t_2444 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_take_field(v_f_241, 0)));
                  return ({ V rv_0 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_f_241, 2ULL, 2, shape_text__at, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                } else {
                  if (heff_runeEq_c(v_c_240, MK_INT(119LL))) {
                    V v_t_2446 = (g_std_2eterminal_2ewidget_2ewordStart(heff_rfield(v_f_241, 0), heff_dup(heff_rfield(v_f_241, 1))));
                    V v_t_2447 = (g_list_2etake(v_t_2446, heff_dup(heff_rfield(v_f_241, 0))));
                    V v_t_2448 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
                    V v_t_2449 = (g_prelude_2e_2b_2b(v_t_2447, v_t_2448));
                    V v_t_2450 = ({ V b_0 = heff_take_field(v_f_241, 0); V a_1 = heff_get_n(v_f_241, 1, 2); V r_ = (g_std_2eterminal_2ewidget_2ewordStart(b_0, a_1)); heff_drop(b_0); r_; });
                    return heff_rec_n(2, shape_text__at, (V[]){v_t_2449, v_t_2450});
                  } else {
                    return v_f_241;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2econtrolEdit_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2econtrolEdit(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2efieldKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2efieldKey_entry, 2, 0};

V g_std_2eterminal_2ewidget_2efieldKey(V v_k_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_242 = heff_field(v_k_240, 0);
    V v_t_243 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_dup(heff_rfield(v_f_241, 0))));
    V v_t_244 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), v_t_244})));
    V v_t_246 = heff_intAdd(heff_get_n(v_f_241, 1, 2), MK_INT(1LL));
    return heff_rec_n(2, shape_text__at, (V[]){v_t_245, v_t_246});
  }
  case TAG_Enter: {
    return v_f_241;
  }
  case TAG_Escape: {
    return v_f_241;
  }
  case TAG_Tab: {
    return v_f_241;
  }
  case TAG_BackTab: {
    return v_f_241;
  }
  case TAG_Backspace: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(0LL))) {
      return v_f_241;
    } else {
      V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
      V v_t_249 = (g_list_2etake(v_t_248, heff_dup(heff_rfield(v_f_241, 0))));
      V v_t_2410 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
      V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
      V v_t_2412 = heff_intSub(heff_get_n(v_f_241, 1, 2), MK_INT(1LL));
      return heff_rec_n(2, shape_text__at, (V[]){v_t_2411, v_t_2412});
    }
  }
  case TAG_Delete: {
    V v_t_2413 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_dup(heff_rfield(v_f_241, 0))));
    V v_t_2414 = heff_intAdd(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
    V v_t_2415 = (g_list_2edrop(v_t_2414, heff_rfield(v_f_241, 0)));
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
    return ({ V rv_0 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_f_241, 2ULL, 2, shape_text__at, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_ArrowUp: {
    return v_f_241;
  }
  case TAG_ArrowDown: {
    return v_f_241;
  }
  case TAG_ArrowLeft: {
    V v_i_2417 = heff_intSub(heff_take_field(v_f_241, 1), MK_INT(1LL));
    V v_x_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2420;
    if (heff_intLe_c_lent(v_x_2418, v_i_2417, 0)) {
      heff_drop(v_i_2417);
      v_y_2420 = v_x_2418;
    } else {
      heff_drop(v_x_2418);
      v_y_2420 = v_i_2417;
    }
    V v_t_2422;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2420, 1)) {
      v_t_2422 = v_y_2420;
    } else {
      heff_drop(v_y_2420);
      v_t_2422 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ArrowRight: {
    V v_i_2423 = heff_intAdd(heff_take_field(v_f_241, 1), MK_INT(1LL));
    V v_x_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2426;
    if (heff_intLe_c_lent(v_x_2424, v_i_2423, 0)) {
      heff_drop(v_i_2423);
      v_y_2426 = v_x_2424;
    } else {
      heff_drop(v_x_2424);
      v_y_2426 = v_i_2423;
    }
    V v_t_2428;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2426, 1)) {
      v_t_2428 = v_y_2426;
    } else {
      heff_drop(v_y_2426);
      v_t_2428 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Home: {
    V v_x_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2431;
    if (heff_intLe_c_lent(v_x_2429, MK_INT(0LL), 2)) {
      v_y_2431 = v_x_2429;
    } else {
      heff_drop(v_x_2429);
      v_y_2431 = MK_INT(0LL);
    }
    V v_t_2433;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2431, 1)) {
      v_t_2433 = v_y_2431;
    } else {
      heff_drop(v_y_2431);
      v_t_2433 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_End: {
    V v_i_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_x_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2437;
    if (heff_intLe_c_lent(v_x_2435, v_i_2434, 0)) {
      heff_drop(v_i_2434);
      v_y_2437 = v_x_2435;
    } else {
      heff_drop(v_x_2435);
      v_y_2437 = v_i_2434;
    }
    V v_t_2439;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2437, 1)) {
      v_t_2439 = v_y_2437;
    } else {
      heff_drop(v_y_2437);
      v_t_2439 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_PageUp: {
    return v_f_241;
  }
  case TAG_PageDown: {
    return v_f_241;
  }
  case TAG_Control: {
    V v_c_2440 = heff_field(v_k_240, 0);
    HEFF_LAST return g_std_2eterminal_2ewidget_2econtrolEdit(heff_dup(v_c_2440), v_f_241);
  }
  case TAG_Sequence: {
    return v_f_241;
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2efieldKey(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2echoiceKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2echoiceKey_entry, 2, 0};

V g_std_2eterminal_2ewidget_2echoiceKey(V v_k_240, V v_c_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_x_242 = heff_field(v_k_240, 0);
    if (heff_runeEq_c(heff_dup(v_x_242), MK_INT(32LL))) {
      V v_t_244 = heff_dup(heff_rfield(v_c_241, 0));
      V v_t_2410;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        v_t_2410 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(1LL));
        V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
        V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
        v_t_2410 = heff_intMod(heff_intAdd(v_t_247, v_t_248), v_t_249);
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      return ({ V rv_1 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      if (heff_runeEq_c(heff_dup(v_x_242), MK_INT(108LL))) {
        V v_t_2412 = heff_dup(heff_rfield(v_c_241, 0));
        V v_t_2418;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_Nil: {
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2412, 0ULL, 2);
          V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(1LL));
          V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
          V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
          v_t_2418 = heff_intMod(heff_intAdd(v_t_2415, v_t_2416), v_t_2417);
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        return ({ V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_x_242), MK_INT(104LL))) {
          V v_t_2420 = heff_dup(heff_rfield(v_c_241, 0));
          V v_t_2426;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            v_t_2426 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_t_2420, 0ULL, 2);
            V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(-1LL));
            V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
            V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
            v_t_2426 = heff_intMod(heff_intAdd(v_t_2423, v_t_2424), v_t_2425);
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          return ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        } else {
          return v_c_241;
        }
      }
    }
  }
  case TAG_Enter: {
    return v_c_241;
  }
  case TAG_Escape: {
    return v_c_241;
  }
  case TAG_Tab: {
    return v_c_241;
  }
  case TAG_BackTab: {
    return v_c_241;
  }
  case TAG_Backspace: {
    return v_c_241;
  }
  case TAG_Delete: {
    return v_c_241;
  }
  case TAG_ArrowUp: {
    return v_c_241;
  }
  case TAG_ArrowDown: {
    return v_c_241;
  }
  case TAG_ArrowLeft: {
    V v_t_2427 = heff_dup(heff_rfield(v_c_241, 0));
    V v_t_2433;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nil: {
      v_t_2433 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2427, 0ULL, 2);
      V v_t_2430 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(-1LL));
      V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      v_t_2433 = heff_intMod(heff_intAdd(v_t_2430, v_t_2431), v_t_2432);
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return ({ V rv_1 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ArrowRight: {
    V v_t_2434 = heff_dup(heff_rfield(v_c_241, 0));
    V v_t_2440;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Nil: {
      v_t_2440 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2434, 0ULL, 2);
      V v_t_2437 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(1LL));
      V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      v_t_2440 = heff_intMod(heff_intAdd(v_t_2437, v_t_2438), v_t_2439);
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    return ({ V rv_1 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Home: {
    return v_c_241;
  }
  case TAG_End: {
    return v_c_241;
  }
  case TAG_PageUp: {
    return v_c_241;
  }
  case TAG_PageDown: {
    return v_c_241;
  }
  case TAG_Control: {
    return v_c_241;
  }
  case TAG_Sequence: {
    return v_c_241;
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2echoiceKey(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_std_2eterminal_2ewidget_2estepAll_24cpr(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Continue: {
    V v_st_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_st_243}});
    }
    case TAG_Cons: {
      V v_k_244 = heff_field(v_x3_242, 0);
      V v_ks_245 = heff_field(v_x3_242, 1);
      V v_t_246 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_k_244), v_st_243}));
      V t_0 = v_f_240;
      V t_1 = v_t_246;
      V t_2 = v_ks_245;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_Done: {
    V v_r_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_f_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_r_247}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str1, 6, "(none)");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str2, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str3, 6, "(none)");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str4, 2, "  ");
Clo g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_entry, 4, 0};

V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(V v_mark_240, V v_at_241, V v_i_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_mark_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x5_243, 0);
    V v_os_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24Cons = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_2411;
    if (heff_intEq_c_lent(v_i_242, v_at_241, 0)) {
      V v_t_248;
      if (heff_strEq_c_lent(v_o_244, ((V)&g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str0), 2)) {
        heff_drop(v_o_244);
        v_t_248 = ((V)&g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str1);
      } else {
        v_t_248 = v_o_244;
      }
      v_t_2411 = heff_tr(heff_call(heff_dup(v_mark_240), 1, (V[]){v_t_248}));
    } else {
      V v_t_2410;
      if (heff_strEq_c_lent(v_o_244, ((V)&g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str2), 2)) {
        heff_drop(v_o_244);
        v_t_2410 = ((V)&g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str3);
      } else {
        v_t_2410 = v_o_244;
      }
      v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){v_t_2410, NTAG(TAG_Plain)});
    }
    V v_t_2415;
    switch (heff_tag_of(v_os_245)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x5_243_24Cons, 2);
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_t_2414 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_str4), NTAG(TAG_Plain)});
      v_t_2415 = heff_tag_at_n(v_ru_24x5_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_os_245);
    }
    V v_t_2416 = (g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(v_mark_240, v_at_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_os_245));
    V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2416));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2417});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2echoiceFrom_24s1924908356x1719214747(a[0], a[1], a[2], a[3]);
}