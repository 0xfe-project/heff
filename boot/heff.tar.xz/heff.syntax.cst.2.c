// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_App 13485
#define TAG_DEqn 7245
#define TAG_DInstance 19095
#define TAG_DSig 20444
#define TAG_DTheory 52633
#define TAG_Do 8988
#define TAG_ELet 43397
#define TAG_Get 18914
#define TAG_MkLetHead 58143
#define TAG_MkSep 6724
#define TAG_Op 9330
#define TAG_Ops 26942
#define TAG_PField 28847
#define TAG_PRec 49217
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_opExpr 935619233
#define LBL_patAtom 1586746071
#define LBL_patHead 1586939750
#define LBL_pattern 1588251091
#define LBL_raw 322210
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_userOps 84709677
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE[] = {LBL_expr, LBL_opExpr, LBL_userOps, LBL_app, LBL_atom, LBL_pattern, LBL_patHead, LBL_patAtom, LBL_lambda, LBL_caseE, LBL_ifE, LBL_doE, LBL_letE};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2earrowRhsF(V, V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatTok(V, V, V);
V g_heff_2esyntax_2ecst_2eatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatTok_clo;
V g_heff_2esyntax_2ecst_2eatomBase(V, V);
V g_heff_2esyntax_2ecst_2eatomBase_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_clo;
V g_heff_2esyntax_2ecst_2eatomF(V, V, V);
V g_heff_2esyntax_2ecst_2eatomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_clo;
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_clo;
V g_heff_2esyntax_2ecst_2ecaseExprF(V, V, V);
V g_heff_2esyntax_2ecst_2ecaseExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecaseExprF_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2eendBefore(V, V);
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eendBefore_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF(V, V, V);
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2efieldDefault(V, V);
V g_heff_2esyntax_2ecst_2efieldDefault_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldDefault_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eifExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eifExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifExprF_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2einstanceDecl(V, V, V);
V g_heff_2esyntax_2ecst_2einstanceDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einstanceDecl_clo;
V g_heff_2esyntax_2ecst_2eisSpecTok(V);
V g_heff_2esyntax_2ecst_2eisSpecTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eisSpecTok_clo;
V g_heff_2esyntax_2ecst_2elambdaF(V, V, V);
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elambdaF_clo;
V g_heff_2esyntax_2ecst_2eletExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eletExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletExprF_clo;
V g_heff_2esyntax_2ecst_2eletHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletHeadF_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emanyParams(V, V, V);
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyParams_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eopLoopF(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_clo;
V g_heff_2esyntax_2ecst_2epatAtomF(V, V, V);
V g_heff_2esyntax_2ecst_2epatAtomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatAtomF_clo;
V g_heff_2esyntax_2ecst_2epatHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatHeadF_clo;
V g_heff_2esyntax_2ecst_2epatternF(V, V, V);
V g_heff_2esyntax_2ecst_2epatternF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatternF_clo;
V g_heff_2esyntax_2ecst_2erecordPatF(V, V, V);
V g_heff_2esyntax_2ecst_2erecordPatF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2erecordPatF_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_clo;
V g_heff_2esyntax_2ecst_2esegValueF(V, V, V);
V g_heff_2esyntax_2ecst_2esegValueF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegValueF_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo;
V g_heff_2esyntax_2ecst_2eskipFrom(V);
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipFrom_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2estatementF(V, V, V);
V g_heff_2esyntax_2ecst_2estatementF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estatementF_clo;
V g_heff_2esyntax_2ecst_2etheoryDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
Clo g_heff_2esyntax_2ecst_2eendBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eendBefore_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eendBefore(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_j_241), MK_INT(0LL))) {
    heff_drop_rec(v_s_240, 5);
    heff_drop(v_j_241);
    return MK_INT(0LL);
  } else {
    V v_xs_243 = heff_dup(heff_rfield(v_s_240, 0));
    V v_y_244 = heff_arrayLength(heff_get_n(v_s_240, 0, 5));
    V v_t_246;
    if (heff_intLe_c(heff_dup(v_j_241), heff_dup(v_y_244))) {
      heff_drop(v_y_244);
      v_t_246 = v_j_241;
    } else {
      heff_drop(v_j_241);
      v_t_246 = v_y_244;
    }
    V v_i_247 = heff_intSub(v_t_246, MK_INT(1LL));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_247))) {
      if (heff_intLt_c(heff_dup(v_i_247), heff_arrayLength_lent(v_xs_243, 0))) {
        V v_t_2410 = heff_arrayIndex(v_xs_243, v_i_247);
        return heff_get_n(v_t_2410, 4, 9);
      } else {
        heff_drop(v_xs_243);
        heff_drop(v_i_247);
        return MK_INT(0LL);
      }
    } else {
      heff_drop(v_xs_243);
      heff_drop(v_i_247);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eendBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str7, 0, "");
Clo g_heff_2esyntax_2ecst_2eatTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatTok_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eatTok(V v_s_240, V v_j_241, V v_t_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2ecst_2eatTok_str0))) {
    heff_drop_rec(v_t_242, 9);
    V v_e_244 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
    return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2eatTok_str1), ((V)&g_heff_2esyntax_2ecst_2eatTok_str2), ((V)&g_heff_2esyntax_2ecst_2eatTok_str3), heff_dup(v_e_244), v_e_244, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  } else {
    if (heff_intLt_c(heff_dup(heff_rfield(v_s_240, 2)), heff_dup(v_j_241))) {
      V v_t_246 = heff_dup(heff_rfield(v_t_242, 6));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 5)), MK_INT(0LL))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2ecst_2eatTok_str4))) {
            heff_drop_rec(v_s_240, 5);
            heff_drop(v_j_241);
            return v_t_242;
          } else {
            heff_drop_rec(v_t_242, 9);
            V v_e_249 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
            return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2eatTok_str5), ((V)&g_heff_2esyntax_2ecst_2eatTok_str6), ((V)&g_heff_2esyntax_2ecst_2eatTok_str7), heff_dup(v_e_249), v_e_249, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          }
        } else {
          heff_drop_rec(v_s_240, 5);
          heff_drop(v_j_241);
          return v_t_242;
        }
      } else {
        heff_drop_rec(v_s_240, 5);
        heff_drop(v_j_241);
        heff_drop(v_t_246);
        return v_t_242;
      }
    } else {
      heff_drop_rec(v_s_240, 5);
      heff_drop(v_j_241);
      return v_t_242;
    }
  }
}
V g_heff_2esyntax_2ecst_2eatTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatTok(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str5, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str6, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str7, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str8, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str11, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str12, 10, "expected `");
V g_heff_2esyntax_2ecst_2eexpectPunct_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectPunct_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectPunct(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectPunct_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectPunct(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectPunct_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), heff_dup(v_x_240))) {
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_x_240);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
    } else {
      V v_t_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str1))) {
        v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str2);
      } else {
        V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str3));
        v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str4), v_t_249);
      }
      V v_t_2411 = heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str5), v_t_2410));
      V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str6), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
      V f_ = heff_get_n(v_hd_241, 1, 3);
      heff_room[0] = v_t_2415;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  } else {
    V v_t_2418;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str7))) {
      v_t_2418 = ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str8);
    } else {
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str9));
      v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str10), v_t_2417);
    }
    V v_t_2419 = heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str11), v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str12), v_t_2419), v_t_2420, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str4, 6, ", not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str5, 9, "expected ");
V g_heff_2esyntax_2ecst_2eexpectKind_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectKind_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eexpectKind(V v_k_240, V v_what_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectKind_lam0, 1, 4, (V[]){v_k_240, v_hd_242, v_k_243, v_what_241})});
}
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectKind(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eexpectKind_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_what_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), v_k_240)) {
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_what_241);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_242, v_k_243));
  } else {
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str0))) {
      v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str1);
    } else {
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str2));
      v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str3), v_t_249);
    }
    V v_t_2411 = heff_strAppend(v_what_241, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str4), v_t_2410));
    V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 3), heff_get_n(v_x_246, 4, 9)});
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str5), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eblock(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_item_240})});
}
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eblock_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_t_2412 = heff_get_n(v_s_2411, 3, 5);
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 2);
    return v_x_2413;
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2esyntax_2ecst_2eblock_lam3(V self, V *args) {
  V v_s_2424 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_245, 5, 9), heff_take_field(v_s_2424, 3)});
  return ({ V rv_3 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_s_2424, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_lam7(V self, V *args) {
  V v_s_2433 = args[0];
  V v_k_2434 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2433, 3)));
  return ({ V rv_3 = v_k_2434; V rr_ = heff_rec_reuse_nf(v_s_2433, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_lam9(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V f_ = v_k_242;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2438 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2437, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2439;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam9, 1, 2, (V[]){v_k_242, v_x_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_lam7_clo)})});
  V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2435}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2436;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam8, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2431);
  return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, heff_get_n(v_x_245, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eblock_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam5, 1, 4, (V[]){v_item_240, v_x_245, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_dup(heff_rfield(v_x_245, 6));
  V v_t_2419 = heff_bool(((heff_dup(v_t_2418) == NTAG(TAG_True)) && heff_intLe_c(heff_dup(heff_rfield(v_x_245, 5)), heff_dup(v_x_2417))));
  heff_drop(v_x_2417);
  heff_drop(v_t_2418);
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_item_240);
    heff_drop(v_t_2419);
    V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_str2), v_t_2420, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2419);
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam3, 1, 1, (V[]){heff_dup(v_x_245)})})});
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2426}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2427;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam4, 1, 4, (V[]){v_hd_241, v_item_240, v_x_245, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_str0))) {
    heff_drop(v_item_240);
    V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_str1), v_t_247, NTAG(TAG_Nothing)});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_249}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2410;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_lam1_clo)})});
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2415}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2416;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam2, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_item_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str5, 4, "case");
V g_heff_2esyntax_2ecst_2earrowRhsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earrowRhsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earrowRhsF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2earrowRhsF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2earrowRhsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earrowRhsF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2earrowRhsF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str0))) {
    heff_drop_rec(v_x_245, 9);
    V f_ = heff_get_n(v_g_240, 0, 13);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str1))) {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_245, 1, 9)}));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str2), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str4), v_t_249})});
      V v_t_2411 = ({ V a_0 = v_t_248; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str5), v_t_2410}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2411);
        V f_ = heff_get_n(v_g_240, 1, 13);
        heff_room[0] = MK_INT(1LL);
        heff_room[1] = v_hd_241;
        heff_room[2] = v_k_242;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
    } else {
      heff_drop_rec(v_x_245, 9);
      V f_ = heff_get_n(v_g_240, 1, 13);
      heff_room[0] = MK_INT(1LL);
      heff_room[1] = v_hd_241;
      heff_room[2] = v_k_242;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str2, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str4, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str6, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str8, 1, "~");
V g_heff_2esyntax_2ecst_2eopLoopF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eopLoopF(V v_g_240, V v_minPrec_241, V v_lhs_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam0, 1, 5, (V[]){v_hd_243, v_minPrec_241, v_g_240, v_lhs_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_lhs_242 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eopLoopF(v_g_240, v_minPrec_241, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_242, v_x_2421, v_x_2432}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_minPrec_241 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2422 = heff_dup(heff_rfield(v_x_247, 1));
  V v_t_2425;
  if (heff_strEq_c_lent(v_s_2422, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str5), 2)) {
    heff_drop(v_s_2422);
    v_t_2425 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2422, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str6))) {
      v_t_2425 = MK_INT(2LL);
    } else {
      v_t_2425 = MK_INT(-1LL);
    }
  }
  V v_c_2431;
  if (heff_intEq_c(v_t_2425, MK_INT(1LL))) {
    heff_drop_rec(v_x_247, 9);
    v_c_2431 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2earrowRhsF_clo), 1, (V[]){heff_dup(v_g_240)}));
  } else {
    V v_s_2427 = heff_get_n(v_x_247, 1, 9);
    V v_t_2430;
    if (heff_strEq_c_lent(v_s_2427, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str7), 2)) {
      heff_drop(v_s_2427);
      v_t_2430 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2427, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str8))) {
        v_t_2430 = MK_INT(2LL);
      } else {
        v_t_2430 = MK_INT(-1LL);
      }
    }
    v_c_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 1)), 1, (V[]){v_t_2430}));
  }
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam3, 1, 6, (V[]){v_g_240, v_minPrec_241, v_lhs_242, v_x_2421, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str0))) {
    V v_s_2410 = heff_dup(heff_rfield(v_x_247, 1));
    V v_t_2413;
    if (heff_strEq_c_lent(v_s_2410, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str1), 2)) {
      heff_drop(v_s_2410);
      v_t_2413 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2410, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str2))) {
        v_t_2413 = MK_INT(2LL);
      } else {
        v_t_2413 = MK_INT(-1LL);
      }
    }
    if (heff_intLe_c(MK_INT(1LL), v_t_2413)) {
      V v_s_2415 = heff_dup(heff_rfield(v_x_247, 1));
      V v_t_2418;
      if (heff_strEq_c_lent(v_s_2415, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str3), 2)) {
        heff_drop(v_s_2415);
        v_t_2418 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2415, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str4))) {
          v_t_2418 = MK_INT(2LL);
        } else {
          v_t_2418 = MK_INT(-1LL);
        }
      }
      v_t_2420 = heff_bool((heff_intLe_c(heff_dup(v_minPrec_241), heff_dup(v_t_2418)) && !(heff_dup(v_x_248) == NTAG(TAG_True))));
      heff_drop(v_x_248);
      heff_drop(v_t_2418);
    } else {
      heff_drop(v_x_248);
      v_t_2420 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_248);
    v_t_2420 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam2, 1, 6, (V[]){v_x_247, v_g_240, v_hd_243, v_minPrec_241, v_lhs_242, v_k_244})));
  } else {
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_minPrec_241);
    heff_drop_rec(v_hd_243, 3);
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_t_2420);
    V f_ = v_k_244;
    args[0] = v_lhs_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_lhs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam1, 1, 6, (V[]){v_x_247, v_minPrec_241, v_hd_243, v_g_240, v_lhs_242, v_k_244})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str5, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str6, 1, "-");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str7, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str8, 1, "-");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str10, 1, "-");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str11, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eisSpecTok_str12, 1, "-");
Clo g_heff_2esyntax_2ecst_2eisSpecTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eisSpecTok_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eisSpecTok(V v_t_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str0)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str1)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str2)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str3)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str4)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str5)) ? heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str6)) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str7)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str8)))))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str9)) ? heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str10)) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str11)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eisSpecTok_str12))))))));
  heff_drop_rec(v_t_240, 9);
  return v_ret_24bool;
}
V g_heff_2esyntax_2ecst_2eisSpecTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eisSpecTok(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_str5, 4, "case");
V g_heff_2esyntax_2ecst_2esegValueF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegValueF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegValueF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2esegValueF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2esegValueF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegValueF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2esegValueF_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nil: {
    v_t_2416 = v_x_2412;
    break;
  }
  case TAG_Cons: {
    v_t_2416 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2412, v_x_2413});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_242;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegValueF_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2esegOperandsF(v_g_240, NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_lam2, 1, 2, (V[]){v_x_2412, v_k_242})));
}
V g_heff_2esyntax_2ecst_2esegValueF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    v_t_2421 = v_x_2417;
    break;
  }
  case TAG_Cons: {
    v_t_2421 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2417, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_242;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegValueF_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2esegOperandsF(v_g_240, NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_lam4, 1, 2, (V[]){v_x_2417, v_k_242})));
}
V g_heff_2esyntax_2ecst_2esegValueF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2esegValueF_str0))) {
    heff_drop_rec(v_x_245, 9);
    V f_ = heff_get_n(v_g_240, 0, 13);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegValueF_str1))) {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_245, 1, 9)}));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_str2), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_str4), v_t_249})});
      V v_t_2411 = ({ V a_0 = v_t_248; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_str5), v_t_2410}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2411);
        V f_ = heff_dup(heff_rfield(v_g_240, 3));
        heff_room[0] = heff_dup(v_hd_241);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_lam1, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_245, 9);
      V f_ = heff_dup(heff_rfield(v_g_240, 3));
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_lam3, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str4, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eatomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2eatomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eatomF_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2417, v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2eatomF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_bool(((heff_dup(v_x_246) == NTAG(TAG_True)) || ({ V v_x1_247 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_245))); int c_ = !(heff_dup(v_x1_247) == NTAG(TAG_True)); heff_drop(v_x1_247); c_; })));
  heff_drop(v_x_246);
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_248);
    V v_t_2411;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_str0))) {
      v_t_2411 = ((V)&g_heff_2esyntax_2ecst_2eatomF_str1);
    } else {
      V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_str2));
      v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str3), v_t_2410);
    }
    V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str4), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_248);
    V v_c_2416 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase(v_g_240, v_x_245));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eatomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam1, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_g_240})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletExprF_str0, 2, "in");
V g_heff_2esyntax_2ecst_2eletExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_247 = heff_field(v_x_244, 0);
    V v_ann_248 = heff_field(v_x_244, 1);
    V v_eq_249 = heff_field(v_x_244, 2);
    V v_e_2410 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_x_246})});
    v_t_2412 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_247, v_ann_248, v_eq_249, v_e_2410, v_t_2411});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam3, 1, 4, (V[]){v_x_244, v_x_245, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eletExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str1, 12, "a field name");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str2, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str3, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str4, 1, "}");
V g_heff_2esyntax_2ecst_2erecordPatF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2erecordPatF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2erecordPatF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2erecordPatF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2erecordPatF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_PField, 3, (V[]){v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 5, 13);
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam4, 1, 3, (V[]){v_k_245, v_x_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str2), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam3, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str0), ((V)&g_heff_2esyntax_2ecst_2erecordPatF_str1), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam2, 1, 3, (V[]){v_hd_244, v_g_240, v_k_245})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam8(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkSep: {
    V v_items_2416 = heff_field(v_x_2414, 0);
    V v_seps_2417 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_t_2418 = heff_tag_n(TAG_PRec, 4, (V[]){v_x_243, v_items_2416, v_seps_2417, v_x_2415});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2411;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str4), v_hd_2410, heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam8, 1, 3, (V[]){v_x_2414, v_x_243, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam6(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str3), v_p_249, v_t_2413, NTAG(TAG_Nil), heff_dup(v_hd_2410), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam7, 1, 3, (V[]){v_hd_2410, v_x_243, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam5(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(v_p_249);
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam6, 1, 4, (V[]){v_p_249, v_hd_2410, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_249 = heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam1, 2, 1, (V[]){v_g_240});
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam5, 2, 2, (V[]){v_p_249, v_x_243}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2egram_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam1, 2, 0};
V g_heff_2esyntax_2ecst_2egram_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam8, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam12(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam12, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam13(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam13, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam14(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam14, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam15(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam15, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam16(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam16, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam17(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam17, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam18, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam22(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam21(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam19(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam19, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam23(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam23, 1, 0};

static V g_heff_2esyntax_2ecst_2egram_val;
static HEFF_ONCE g_heff_2esyntax_2ecst_2egram_st;
static V g_heff_2esyntax_2ecst_2egram_init(void) {
  return heff_rec_n(13, shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE, (V[]){((V)&g_heff_2esyntax_2ecst_2egram_lam0_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam1_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam4_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam8_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam12_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam13_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam14_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam15_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam16_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam17_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam18_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam19_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam23_clo)});
}
V g_heff_2esyntax_2ecst_2egram_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2ecst_2egram_st)) return g_heff_2esyntax_2ecst_2egram_val;
  return heff_global(&g_heff_2esyntax_2ecst_2egram_val, &g_heff_2esyntax_2ecst_2egram_st, g_heff_2esyntax_2ecst_2egram_init);
}
V g_heff_2esyntax_2ecst_2egram_lam0(V self, V *args) {
  V v_st_240 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eexprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_240;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eopLoopF(v_g_243, v_minPrec_241, v_x_245, v_st_242, v_k_244));
}
V g_heff_2esyntax_2ecst_2egram_lam2(V self, V *args) {
  V v_k_244 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_minPrec_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_243, 2));
  heff_room[0] = heff_dup(v_st_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam3, 1, 4, (V[]){v_g_243, v_minPrec_241, v_st_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam1(V self, V *args) {
  V v_minPrec_241 = args[0];
  V v_st_242 = args[1];
  V v_g_243 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam2, 1, 3, (V[]){v_g_243, v_st_242, v_minPrec_241});
}
V g_heff_2esyntax_2ecst_2egram_lam7(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nil: {
    v_t_2413 = v_x_249;
    break;
  }
  case TAG_Cons: {
    v_t_2413 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_249, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam6(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_247, NTAG(TAG_Nil), v_st_246, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam7, 1, 2, (V[]){v_x_249, v_k_248})));
}
V g_heff_2esyntax_2ecst_2egram_lam5(V self, V *args) {
  V v_k_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_g_247, 3));
  heff_room[0] = heff_dup(v_st_246);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam6, 1, 3, (V[]){v_g_247, v_st_246, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam4(V self, V *args) {
  V v_st_246 = args[0];
  V v_g_247 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam5, 1, 2, (V[]){v_g_247, v_st_246});
}
V g_heff_2esyntax_2ecst_2egram_lam11(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    v_t_2421 = v_x_2417;
    break;
  }
  case TAG_Cons: {
    v_t_2421 = heff_tag_n(TAG_App, 2, (V[]){v_x_2417, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2416;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam10(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_st_2414 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_2415, 4, 13), NTAG(TAG_Nil), v_st_2414, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam11, 1, 2, (V[]){v_x_2417, v_k_2416})));
}
V g_heff_2esyntax_2ecst_2egram_lam9(V self, V *args) {
  V v_k_2416 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_st_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_g_2415, 4));
  heff_room[0] = heff_dup(v_st_2414);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam10, 1, 3, (V[]){v_g_2415, v_st_2414, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam8(V self, V *args) {
  V v_st_2414 = args[0];
  V v_g_2415 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam9, 1, 2, (V[]){v_g_2415, v_st_2414});
}
V g_heff_2esyntax_2ecst_2egram_lam12(V self, V *args) {
  V v_st_2422 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eatomF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam13(V self, V *args) {
  V v_st_2423 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatternF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam14(V self, V *args) {
  V v_st_2424 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatHeadF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam15(V self, V *args) {
  V v_st_2425 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatAtomF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam16(V self, V *args) {
  V v_st_2426 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2elambdaF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2426;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam17(V self, V *args) {
  V v_st_2427 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2ecaseExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam18(V self, V *args) {
  V v_st_2428 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eifExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam22(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Do, 2, (V[]){v_x_2432, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam21(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_st_2429 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2estatementF_clo), 1, (V[]){v_g_2430}));
  return (g_heff_2esyntax_2ecst_2eblock(v_t_2433, v_st_2429, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam22, 1, 2, (V[]){v_k_2431, v_x_2432})));
}
V g_heff_2esyntax_2ecst_2egram_lam20(V self, V *args) {
  V v_k_2431 = args[0];
  V v_st_2429 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_st_2429), heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam21, 1, 3, (V[]){v_g_2430, v_st_2429, v_k_2431})));
}
V g_heff_2esyntax_2ecst_2egram_lam19(V self, V *args) {
  V v_st_2429 = args[0];
  V v_g_2430 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam20, 1, 2, (V[]){v_st_2429, v_g_2430});
}
V g_heff_2esyntax_2ecst_2egram_lam23(V self, V *args) {
  V v_st_2435 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eletExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldDefault_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldDefault_str1, 1, "=");
V g_heff_2esyntax_2ecst_2efieldDefault_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldDefault_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldDefault_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldDefault_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldDefault_entry, 2, 0};

V g_heff_2esyntax_2ecst_2efieldDefault(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2efieldDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldDefault(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_x_249})});
  V f_ = v_k_241;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam3, 1, 2, (V[]){v_x_248, v_k_241})));
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2efieldDefault_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_244, 1, 9), ((V)&g_heff_2esyntax_2ecst_2efieldDefault_str1))) {
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop(v_x_245);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = NTAG(TAG_Nothing);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_245);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
      }
    } else {
      heff_drop(v_x_245);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_245);
    heff_drop_rec(v_x_244, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam1, 1, 3, (V[]){v_x_244, v_k_241, v_hd_240})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get_n(v_s_2410, 3, 5);
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    return v_x_2412;
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_244, 5, 9), heff_take_field(v_s_2423, 3)});
  return ({ V rv_3 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_s_2423, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7(V self, V *args) {
  V v_s_2432 = args[0];
  V v_k_2433 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2432, 3)));
  return ({ V rv_3 = v_k_2433; V rr_ = heff_rec_reuse_nf(v_s_2432, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  V f_ = v_k_241;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2436, NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9, 1, 2, (V[]){v_k_241, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7_clo)})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2434}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(heff_get_n(v_x_244, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2427, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_dup(heff_rfield(v_x_244, 6));
  V v_t_2418 = heff_bool(((heff_dup(v_t_2417) == NTAG(TAG_True)) && heff_intLe_c(heff_dup(heff_rfield(v_x_244, 5)), heff_dup(v_x_2416))));
  heff_drop(v_x_2416);
  heff_drop(v_t_2417);
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str2), v_t_2419, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2421}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2422;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2418);
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2425}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2426;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str0))) {
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1_clo)})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str1, 20, "the name of a theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str2, 5, "where");
V g_heff_2esyntax_2ecst_2etheoryDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etheoryDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etheoryDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_248 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_248, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etheoryDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DTheory, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam4, 1, 5, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str0), ((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str4, 1, ")");
Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclNameLen_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edeclNameLen(V v_t_240, V v_t2_241, V v_t3_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str0))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop_rec(v_t2_241, 9);
    heff_drop_rec(v_t3_242, 9);
    return MK_INT(1LL);
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str1))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop_rec(v_t2_241, 9);
      heff_drop_rec(v_t3_242, 9);
      return MK_INT(1LL);
    } else {
      if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str2))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t2_241, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str3))) {
          V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t2_241, 1, 9)}));
          V v_x1_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_x1_248) == NTAG(TAG_True))) {
            heff_drop_rec(v_t3_242, 9);
            heff_drop(v_x1_248);
            return MK_INT(0LL);
          } else {
            heff_drop(v_x1_248);
            if (heff_strEq_c(heff_get_n(v_t3_242, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str4))) {
              return MK_INT(3LL);
            } else {
              return MK_INT(0LL);
            }
          }
        } else {
          heff_drop_rec(v_t2_241, 9);
          heff_drop_rec(v_t3_242, 9);
          return MK_INT(0LL);
        }
      } else {
        heff_drop_rec(v_t2_241, 9);
        heff_drop_rec(v_t3_242, 9);
        return MK_INT(0LL);
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclNameLen(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2einstanceDecl_str0, 38, "an instance is named: `instance f : T`");
V g_heff_2esyntax_2ecst_2einstanceDecl_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einstanceDecl_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einstanceDecl_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2einstanceDecl_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einstanceDecl_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einstanceDecl_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2einstanceDecl_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2einstanceDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einstanceDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2einstanceDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_2427 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_2427, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2einstanceDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2einstanceDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_s_247, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_247, v_t_248));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam4(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_2413 = heff_intAdd(heff_dup(heff_rfield(v_s_2412, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2412, v_t_2413));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DInstance, 4, (V[]){v_x_243, v_x_2424, v_x_2425, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam8, 1, 4, (V[]){v_k_241, v_x_243, v_x_2424, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam7, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_2424})));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_x_246), heff_dup(v_x_2411), heff_dup(v_x_2416)));
  if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
    heff_drop(v_x_2416);
    heff_drop(v_x_2411);
    heff_drop(v_x_243);
    V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 3), heff_get_n(v_x_246, 4, 9)});
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2einstanceDecl_str0), v_t_2419, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2421}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2422;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2423 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_x_246, v_x_2411, v_x_2416));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2423, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam6, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
  }
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einstanceDecl_lam4_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam5, 1, 5, (V[]){v_x_246, v_x_2411, v_hd_240, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einstanceDecl_lam2_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam3, 1, 4, (V[]){v_hd_240, v_x_246, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str1, 33, "a declaration cannot start with `");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str3, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str5, 5, "where");
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry, 4, 0};

V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V v_t_240, V v_hd_241, V v_k_242, V v_z_243) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 3, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1, 1, 3, (V[]){v_hd_241, v_t_240, v_k_242}), v_z_243});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_244, v_t_245));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_s_2422, 1)), v_k_2421);
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2422, v_t_2423));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_DSig, 3, (V[]){v_x_2429, v_x_2430, v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8, 1, 3, (V[]){v_k_242, v_x_2429, v_x_2430})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2429})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_x_2445})});
  V f_ = v_k_2443;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2442 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(v_hd_2442, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16, 1, 2, (V[]){v_x_2444, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2442), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15, 1, 2, (V[]){v_hd_2442, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2433, v_x_2434, v_x_2435, v_x_2436, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_x_2436 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2451;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2439, 0)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str4))) {
    if (heff_strEq_c(heff_get_n(v_x_2439, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str5))) {
      v_t_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14_clo);
    } else {
      v_t_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17_clo);
    }
  } else {
    heff_drop_rec(v_x_2439, 9);
    v_t_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18_clo);
  }
  V f_ = v_t_2451;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19, 1, 5, (V[]){v_k_242, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2437}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13, 1, 6, (V[]){v_hd_241, v_k_242, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12, 1, 5, (V[]){v_hd_241, v_k_242, v_x_2433, v_x_2434, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str3), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2433, v_x_2434})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 7)), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2433})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2426, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str2))) {
    V v_t_2428 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_240, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2428, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
  } else {
    V v_t_2432 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_240, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2432, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_248), heff_dup(v_x_2413)));
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    V v_t_2416 = heff_strAppend(heff_take_field(v_t_240, 1), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str0));
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str1), v_t_2416), v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_k_2421 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_248), heff_dup(v_x_2413)));
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4, 1, 1, (V[]){v_k_2421})})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2424}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2425;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5, 1, 5, (V[]){v_t_240, v_x_248, v_x_2413, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3, 1, 4, (V[]){v_t_240, v_x_248, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eskipFrom_str0, 3, "eof");
Clo g_heff_2esyntax_2ecst_2eskipFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eskipFrom_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eskipFrom(V v_s_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_241, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eskipFrom_str0))) {
    return v_s_240;
  } else {
    V v_t_243 = heff_intAdd(heff_take_field(v_s_240, 1), MK_INT(1LL));
    V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_s_240, 29ULL, 5, shape_toks__i__top__stack__start, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V t_0 = v_t_244;
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eskipFrom(a[0]);
}