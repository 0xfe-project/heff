// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_App 13485
#define TAG_Braces 8205
#define TAG_DEqn 7245
#define TAG_DInstance 19095
#define TAG_DSig 20444
#define TAG_DTheory 52633
#define TAG_Do 8988
#define TAG_ECatch 45587
#define TAG_EFSet 34673
#define TAG_ELet 43397
#define TAG_Get 18914
#define TAG_InstB 37114
#define TAG_MkLetHead 58143
#define TAG_MkSep 6724
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_app 306331
#define LBL_arm 306390
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_head 9693863
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_opExpr 935619233
#define LBL_patAtom 1586746071
#define LBL_patHead 1586939750
#define LBL_pattern 1588251091
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_userOps 84709677
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE__head__stmt__arm__blockArg[] = {LBL_expr, LBL_opExpr, LBL_userOps, LBL_app, LBL_atom, LBL_pattern, LBL_patHead, LBL_patAtom, LBL_lambda, LBL_caseE, LBL_ifE, LBL_doE, LBL_letE, LBL_head, LBL_stmt, LBL_arm, LBL_blockArg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2eappF(V, V, V);
V g_heff_2esyntax_2ecst_2eappF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_clo;
V g_heff_2esyntax_2ecst_2earmF(V, V, V);
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earmF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase(V, V);
V g_heff_2esyntax_2ecst_2eatomBase_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_clo;
V g_heff_2esyntax_2ecst_2eatomF(V, V, V);
V g_heff_2esyntax_2ecst_2eatomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo;
V g_heff_2esyntax_2ecst_2ebindRhsF(V, V, V);
V g_heff_2esyntax_2ecst_2ebindRhsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebindRhsF_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_clo;
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_clo;
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546(V, V);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_clo;
V g_heff_2esyntax_2ecst_2ecaseExprF(V, V, V);
V g_heff_2esyntax_2ecst_2ecaseExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecaseExprF_clo;
V g_heff_2esyntax_2ecst_2ecatchF(V, V, V);
V g_heff_2esyntax_2ecst_2ecatchF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecatchF_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_clo;
V g_heff_2esyntax_2ecst_2eendBefore(V, V);
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eendBefore_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF(V, V, V);
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_clo;
V g_heff_2esyntax_2ecst_2efieldNameF(V, V, V, V);
V g_heff_2esyntax_2ecst_2efieldNameF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldNameF_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2eforF(V, V, V);
V g_heff_2esyntax_2ecst_2eforF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eforF_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2eifExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eifExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifExprF_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2einstanceDecl(V, V, V);
V g_heff_2esyntax_2ecst_2einstanceDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einstanceDecl_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elambdaF(V, V, V);
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elambdaF_clo;
V g_heff_2esyntax_2ecst_2eletExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eletExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletExprF_clo;
V g_heff_2esyntax_2ecst_2eletHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletHeadF_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258(V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emanyParams(V, V, V);
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyParams_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eopLoopF(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_clo;
V g_heff_2esyntax_2ecst_2epatAtomF(V, V, V);
V g_heff_2esyntax_2ecst_2epatAtomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatAtomF_clo;
V g_heff_2esyntax_2ecst_2epatHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatHeadF_clo;
V g_heff_2esyntax_2ecst_2epatternF(V, V, V);
V g_heff_2esyntax_2ecst_2epatternF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatternF_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s121904211x184271991(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s121904211x184271991_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s121904211x184271991_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo;
V g_heff_2esyntax_2ecst_2esettingF(V, V, V);
V g_heff_2esyntax_2ecst_2esettingF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esettingF_clo;
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886(V, V);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_clo;
V g_heff_2esyntax_2ecst_2esigName(V, V);
V g_heff_2esyntax_2ecst_2esigName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigName_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo;
V g_heff_2esyntax_2ecst_2eskipDecl(V);
V g_heff_2esyntax_2ecst_2eskipDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipDecl_clo;
V g_heff_2esyntax_2ecst_2eskipFrom(V);
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipFrom_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2estartsClosed(V);
V g_heff_2esyntax_2ecst_2estartsClosed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsClosed_clo;
V g_heff_2esyntax_2ecst_2estmtF(V, V, V);
V g_heff_2esyntax_2ecst_2estmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estmtF_clo;
V g_heff_2esyntax_2ecst_2etheoryDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2ecst_2eendBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eendBefore_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eendBefore(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLe_c_lent(v_j_241, MK_INT(0LL), 2)) {
    heff_drop_rec(v_s_240, 5);
    heff_drop(v_j_241);
    return MK_INT(0LL);
  } else {
    V v_xs_242 = heff_dup(heff_rfield(v_s_240, 0));
    V v_y_243 = heff_arrayLength(heff_get_n(v_s_240, 0, 5));
    V v_t_244;
    if (heff_intLe_c_lent(v_j_241, v_y_243, 0)) {
      heff_drop(v_y_243);
      v_t_244 = v_j_241;
    } else {
      heff_drop(v_j_241);
      v_t_244 = v_y_243;
    }
    int64_t v_i_245 = (heff_unbox_word(v_t_244) - ((int64_t)1ULL));
    if (((((int64_t)0ULL) <= v_i_245) && (v_i_245 < heff_unbox_word(heff_arrayLength_lent(v_xs_242, 0))))) {
      V v_t_246 = heff_arrayIndexIn(v_xs_242, heff_box_word(v_i_245));
      return heff_get_n(v_t_246, 4, 9);
    } else {
      heff_drop(v_xs_242);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eendBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str1, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str2, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str4, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str6, 1, "`");
V g_heff_2esyntax_2ecst_2eexpectPunct_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectPunct_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectPunct(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectPunct_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectPunct(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectPunct_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_take_field(v_x_245, 1);
  V v_start_248 = heff_take_field(v_x_245, 3);
  V v_end_249 = heff_get_n(v_x_245, 4, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str0), 2) && heff_strEq_c_lent(v_text_247, v_x_240, 0))) {
    heff_drop(v_x_240);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    heff_drop(v_start_248);
    heff_drop(v_end_249);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
  } else {
    V v_span_2410 = heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249});
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str1), v_x_240), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str2));
    V v_t_2412;
    if (heff_strEq_c(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str3))) {
      heff_drop(v_text_247);
      v_t_2412 = ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str4);
    } else {
      v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str5), v_text_247), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str6));
    }
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2411, v_t_2412), v_span_2410, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str0, 9, "expected ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str1, 6, ", not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str2, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str3, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str5, 1, "`");
V g_heff_2esyntax_2ecst_2eexpectKind_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectKind_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eexpectKind(V v_k_240, V v_what_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectKind_lam0, 1, 4, (V[]){heff_dup(v_k_240), v_hd_242, v_k_243, v_what_241})});
}
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2eexpectKind(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2eexpectKind_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_what_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_start_248 = heff_take_field(v_x_246, 3);
  V v_end_249 = heff_take_field(v_x_246, 4);
  V v_text_2410 = heff_get_n(v_x_246, 1, 9);
  if (heff_strEq_c_lent(v_kind_247, v_k_240, 2)) {
    heff_drop(v_what_241);
    heff_drop(v_kind_247);
    heff_drop(v_start_248);
    heff_drop(v_end_249);
    heff_drop(v_text_2410);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_242, v_k_243));
  } else {
    V v_span_2411 = heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249});
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str0), v_what_241), ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str1));
    V v_t_2413;
    if (heff_strEq_c(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str2))) {
      heff_drop(v_text_2410);
      v_t_2413 = ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str3);
    } else {
      v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str4), v_text_2410), ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str5));
    }
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2412, v_t_2413), v_span_2411, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eblock(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_item_240})});
}
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eblock_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_t_2415 = heff_get_n(v_s_2414, 3, 5);
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 2);
    return v_x_2416;
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2esyntax_2ecst_2eblock_lam3(V self, V *args) {
  V v_s_2424 = args[0];
  V v_col_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_take_field(v_s_2424, 3);
  V v_top_2426 = heff_take_field(v_s_2424, 2);
  V v_start_2427 = heff_take_field(v_s_2424, 4);
  return ({ V rv_2 = v_top_2426; V rv_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_col_2410, v_t_2425}); V rv_4 = v_start_2427; V rr_ = heff_rec_reuse_nf(v_s_2424, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_lam7(V self, V *args) {
  V v_s_2435 = args[0];
  V v_k_2436 = (g_list_2edrop(MK_INT(1LL), heff_rfield(v_s_2435, 3)));
  V v_top_2437 = heff_take_field(v_s_2435, 2);
  V v_start_2438 = heff_take_field(v_s_2435, 4);
  return ({ V rv_2 = v_top_2437; V rv_3 = v_k_2436; V rv_4 = v_start_2438; V rr_ = heff_rec_reuse_nf(v_s_2435, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_lam9(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V f_ = v_k_242;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2442 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2441, NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2443;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam9, 1, 2, (V[]){v_k_242, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_lam7_clo)})});
  V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2439}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam8, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_col_2410 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, v_col_2410, NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eblock_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_2410 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2430, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam5, 1, 4, (V[]){v_item_240, v_col_2410, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_first_249 = heff_env(self)[0];
  V v_col_2410 = heff_env(self)[1];
  V v_start_247 = heff_env(self)[2];
  V v_end_248 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  V v_item_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if (((heff_dup(v_first_249) == NTAG(TAG_True)) && heff_intLe_c_lent(v_col_2410, v_x_2420, 0))) {
    heff_drop(v_x_2420);
    heff_drop(v_first_249);
    heff_drop(v_col_2410);
    heff_drop(v_item_240);
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_str2), heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2420);
    heff_drop(v_first_249);
    heff_drop(v_start_247);
    heff_drop(v_end_248);
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam3, 1, 1, (V[]){heff_dup(v_col_2410)})})});
    V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2428}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2429;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam4, 1, 4, (V[]){v_hd_241, v_item_240, v_col_2410, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_start_247 = heff_take_field(v_x_245, 3);
  V v_end_248 = heff_take_field(v_x_245, 4);
  V v_first_249 = heff_take_field(v_x_245, 6);
  V v_col_2410 = heff_get_n(v_x_245, 5, 9);
  if (heff_strEq_c(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eblock_str0))) {
    heff_drop(v_item_240);
    heff_drop(v_first_249);
    heff_drop(v_col_2410);
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), NTAG(TAG_Nothing)});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2412}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2413;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_lam1_clo)})});
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2418}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2419;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam2, 1, 7, (V[]){v_first_249, v_col_2410, v_start_247, v_end_248, v_hd_241, v_k_242, v_item_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str2, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str4, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str6, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str8, 1, "@");
V g_heff_2esyntax_2ecst_2eopLoopF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eopLoopF(V v_g_240, V v_minPrec_241, V v_lhs_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam0, 1, 5, (V[]){v_hd_243, v_minPrec_241, v_g_240, v_lhs_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tr(g_heff_2esyntax_2ecst_2estartsClosed(v_x_2422));
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_t_2423);
    V f_ = heff_get_n(v_g_240, 0, 17);
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2423);
    V f_ = heff_get_n(v_g_240, 1, 17);
    heff_room[0] = MK_INT(1LL);
    heff_room[1] = v_hd_2418;
    heff_room[2] = v_k_2419;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2418, 2)), 1, (V[]){v_t_2420}));
  V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
  args[0] = v_t_2421;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam4, 1, 3, (V[]){v_g_240, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_lhs_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eopLoopF(v_g_240, v_minPrec_241, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_242, v_x_2415, v_x_2427}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_text_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_minPrec_241 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2416 = heff_dup(v_text_249);
  int64_t v_t_2417;
  if (heff_strEq_c_lent(v_s_2416, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str5), 2)) {
    heff_drop(v_s_2416);
    v_t_2417 = ((int64_t)1ULL);
  } else {
    if (heff_strEq_c(v_s_2416, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str6))) {
      v_t_2417 = ((int64_t)2ULL);
    } else {
      v_t_2417 = ((int64_t)-1ULL);
    }
  }
  V v_c_2426;
  if ((v_t_2417 == ((int64_t)1ULL))) {
    heff_drop(v_text_249);
    v_c_2426 = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam3, 2, 1, (V[]){heff_dup(v_g_240)});
  } else {
    V v_s_2424 = v_text_249;
    int64_t v_t_2425;
    if (heff_strEq_c_lent(v_s_2424, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str7), 2)) {
      heff_drop(v_s_2424);
      v_t_2425 = ((int64_t)1ULL);
    } else {
      if (heff_strEq_c(v_s_2424, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str8))) {
        v_t_2425 = ((int64_t)2ULL);
      } else {
        v_t_2425 = ((int64_t)-1ULL);
      }
    }
    v_c_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 1)), 1, (V[]){heff_box_word((v_t_2425 + ((int64_t)1ULL)))}));
  }
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam5, 1, 6, (V[]){v_g_240, v_minPrec_241, v_lhs_242, v_x_2415, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_kind_248 = heff_env(self)[0];
  V v_text_249 = heff_env(self)[1];
  V v_minPrec_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_lhs_242 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428;
  if (heff_strEq_c(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str0))) {
    V v_s_2411 = heff_dup(v_text_249);
    int64_t v_t_2412;
    if (heff_strEq_c_lent(v_s_2411, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str1), 2)) {
      heff_drop(v_s_2411);
      v_t_2412 = ((int64_t)1ULL);
    } else {
      if (heff_strEq_c(v_s_2411, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str2))) {
        v_t_2412 = ((int64_t)2ULL);
      } else {
        v_t_2412 = ((int64_t)-1ULL);
      }
    }
    V v_t_2429 = heff_bool((((int64_t)1ULL) <= v_t_2412));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      V v_s_2413 = heff_dup(v_text_249);
      V v_t_2414;
      if (heff_strEq_c_lent(v_s_2413, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str3), 2)) {
        heff_drop(v_s_2413);
        v_t_2414 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2413, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str4))) {
          v_t_2414 = MK_INT(2LL);
        } else {
          v_t_2414 = MK_INT(-1LL);
        }
      }
      V v_t_2430 = heff_bool(heff_intLe_c_lent(v_minPrec_241, v_t_2414, 0));
      heff_drop(v_t_2414);
      switch (heff_tag_of(v_t_2430)) {
      case TAG_True: {
        v_t_2428 = heff_bool(!(heff_dup(v_x_2410) == NTAG(TAG_True)));
        heff_drop(v_x_2410);
        break;
      }
      case TAG_False: {
        heff_drop(v_x_2410);
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2430);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_x_2410);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
  } else {
    heff_drop(v_x_2410);
    v_t_2428 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2428)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam2, 1, 6, (V[]){v_text_249, v_g_240, v_hd_243, v_minPrec_241, v_lhs_242, v_k_244})));
  }
  case TAG_False: {
    heff_drop(v_text_249);
    heff_drop(v_minPrec_241);
    heff_drop_rec(v_hd_243, 3);
    heff_drop_rec(v_g_240, 17);
    V f_ = v_k_244;
    args[0] = v_lhs_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_lhs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_kind_248 = heff_take_field(v_x_247, 0);
  V v_text_249 = heff_get_n(v_x_247, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam1, 1, 7, (V[]){v_kind_248, v_text_249, v_minPrec_241, v_hd_243, v_g_240, v_lhs_242, v_k_244})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esettingF_str0, 1, "=");
V g_heff_2esyntax_2ecst_2esettingF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esettingF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esettingF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2esettingF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esettingF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esettingF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2esettingF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2esettingF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esettingF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2esettingF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2esettingF_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EFSet, 3, (V[]){v_x_2412, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esettingF_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_lam6, 1, 3, (V[]){v_k_242, v_x_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esettingF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esettingF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_lam5, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2esettingF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_lam4, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2esettingF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2efieldNameF(v_x_245, v_x_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_lam3, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2esettingF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esettingF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_lam2, 1, 4, (V[]){v_x_245, v_hd_241, v_g_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str4, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str6, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str9, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eatomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2eatomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eatomF_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2421, v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2eatomF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
    heff_drop(v_x_246);
    heff_drop(v_g_240);
    V v_span_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_take_field(v_x_245, 4)});
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_str0))) {
      heff_drop_rec(v_x_245, 9);
      v_t_249 = ((V)&g_heff_2esyntax_2ecst_2eatomF_str1);
    } else {
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str2), heff_get_n(v_x_245, 1, 9));
      v_t_249 = heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2ecst_2eatomF_str3));
    }
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str4), v_t_249), v_span_247, NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_246);
    V v_x1_2413 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_245)));
    if (!(heff_dup(v_x1_2413) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_x1_2413);
      V v_span_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_take_field(v_x_245, 4)});
      V v_t_2416;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_str5))) {
        heff_drop_rec(v_x_245, 9);
        v_t_2416 = ((V)&g_heff_2esyntax_2ecst_2eatomF_str6);
      } else {
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str7), heff_get_n(v_x_245, 1, 9));
        v_t_2416 = heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2ecst_2eatomF_str8));
      }
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str9), v_t_2416), v_span_2414, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2418}));
      V f_ = heff_get_n(v_hd_241, 1, 3);
      heff_room[0] = v_t_2419;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2413);
      V v_c_2420 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase(v_g_240, v_x_245));
      V f_ = v_c_2420;
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam1, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_g_240})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletExprF_str0, 2, "in");
V g_heff_2esyntax_2ecst_2eletExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_247 = heff_field(v_x_244, 0);
    V v_ann_248 = heff_field(v_x_244, 1);
    V v_eq_249 = heff_field(v_x_244, 2);
    V v_e_2410 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_x_246})});
    v_t_2412 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_247, v_ann_248, v_eq_249, v_e_2410, v_t_2411});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam3, 1, 4, (V[]){v_x_244, v_x_245, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eletExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ecatchF_str0, 2, "->");
V g_heff_2esyntax_2ecst_2ecatchF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ecatchF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ecatchF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ecatchF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ecatchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ecatchF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ecatchF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecatchF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ecatchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ecatchF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ecatchF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ECatch, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecatchF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2ecatchF_lam3, 1, 4, (V[]){v_k_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2ecatchF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ecatchF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecatchF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2ecatchF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecatchF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindRhsF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindRhsF_str1, 3, "for");
V g_heff_2esyntax_2ecst_2ebindRhsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebindRhsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebindRhsF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ebindRhsF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebindRhsF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2ebindRhsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebindRhsF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ebindRhsF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_get_n(v_x_245, 1, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2ebindRhsF_str0), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2ebindRhsF_str1), 2))) {
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    return (g_heff_2esyntax_2ecst_2eforF(v_g_240, v_hd_241, v_k_242));
  } else {
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    V f_ = heff_get_n(v_g_240, 0, 17);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str1, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str2, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str3, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str6, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str8, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str9, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str11, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str12, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str13, 1, "}");
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam22(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam21(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_entry, 2, 0};

V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam3(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_s_2410, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2410, v_t_2411));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam8(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_InstB, 5, (V[]){v_x_242, v_x_2415, v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str3), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam8, 1, 5, (V[]){v_k_244, v_x_242, v_x_2415, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str2), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam7, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 0)), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam6, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam9(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2419});
  V f_ = v_k_244;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam12(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkSep: {
    V v_items_2425 = heff_field(v_x_2423, 0);
    V v_seps_2426 = heff_field(v_x_2423, 1);
    heff_take_n(v_x_2423, 3ULL, 2);
    v_t_2427 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2425, v_seps_2426, v_x_2424});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_244;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam11(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str7), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam12, 1, 3, (V[]){v_x_2423, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam10(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2421, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str6); V a_1 = v_t_2422; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_243); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam11, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam18(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_MkSep: {
    V v_items_2443 = heff_field(v_x_2441, 0);
    V v_seps_2444 = heff_field(v_x_2441, 1);
    heff_take_n(v_x_2441, 3ULL, 2);
    v_t_2445 = heff_tag_n(TAG_Update, 6, (V[]){v_o_2434, v_r_2435, v_x_2438, v_items_2443, v_seps_2444, v_x_2442});
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam17(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str11), v_hd_2436, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam18, 1, 5, (V[]){v_x_2441, v_o_2434, v_r_2435, v_x_2438, v_k_2437})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam16(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str10); V a_1 = v_t_2440; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_2436); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam17, 1, 5, (V[]){v_hd_2436, v_o_2434, v_r_2435, v_x_2438, v_k_2437}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam15(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(heff_dup(v_hd_2436), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam16, 1, 5, (V[]){v_hd_2436, v_o_2434, v_r_2435, v_x_2438, v_k_2437})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam20(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2450 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2454;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkSep: {
    V v_items_2452 = heff_field(v_x_2450, 0);
    V v_seps_2453 = heff_field(v_x_2450, 1);
    heff_take_n(v_x_2450, 3ULL, 2);
    v_t_2454 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2452, v_seps_2453, v_x_2451});
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_k_244;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam19(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str13), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam20, 1, 3, (V[]){v_x_2450, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam22(V self, V *args) {
  V v_x_2459 = args[0];
  V v_sep_2446 = heff_env(self)[0];
  V v_items_2447 = heff_env(self)[1];
  V v_seps_2448 = heff_env(self)[2];
  V v_hd_2449 = heff_env(self)[3];
  V v_k_2455 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2446, v_items_2447, v_x_2459, v_seps_2448, heff_dup(v_hd_2449), v_k_2455, v_hd_2449));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam21(V self, V *args) {
  V v_x_2458 = args[0];
  V v_sep_2446 = heff_env(self)[0];
  V v_hd_2449 = heff_env(self)[1];
  V v_items_2447 = heff_env(self)[2];
  V v_seps_2448 = heff_env(self)[3];
  V v_k_2455 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2458, 1, 9), heff_dup(v_sep_2446))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2449), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam22, 1, 5, (V[]){v_sep_2446, v_items_2447, v_seps_2448, v_hd_2449, v_k_2455})));
  } else {
    heff_drop(v_sep_2446);
    heff_drop_rec(v_hd_2449, 3);
    V v_t_2460 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2447));
    V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2448));
    V v_x_2462 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2460, v_t_2461});
    V f_ = v_k_2455;
    args[0] = v_x_2462;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam14(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_kind_2432 = heff_take_field(v_x_2431, 0);
  V v_text_2433 = heff_get_n(v_x_2431, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2432, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str8), 2) && heff_strEq_c_lent(v_text_2433, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str9), 2))) {
    heff_drop(v_kind_2432);
    heff_drop(v_text_2433);
    V v_o_2434 = v_x_242;
    V v_r_2435 = v_x_2428;
    V v_hd_2436 = v_hd_243;
    V v_k_2437 = v_k_244;
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2436), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam15, 1, 4, (V[]){v_hd_2436, v_o_2434, v_r_2435, v_k_2437})));
  } else {
    heff_drop(v_kind_2432);
    heff_drop(v_text_2433);
    V v_sep_2446 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str12);
    V v_items_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2428, NTAG(TAG_Nil)});
    V v_seps_2448 = NTAG(TAG_Nil);
    V v_hd_2449 = heff_dup(v_hd_243);
    V v_k_2455 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam19, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){v_t_2456}));
    V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
    heff_room[0] = v_t_2457;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam21, 1, 5, (V[]){v_sep_2446, v_hd_2449, v_items_2447, v_seps_2448, v_k_2455});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam13(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2429}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam14, 1, 4, (V[]){v_x_242, v_x_2428, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_kind_248 = heff_env(self)[0];
  V v_text_249 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str0), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str1), 2))) {
    heff_drop_rec(v_x_2414, 9);
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam5, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
  } else {
    heff_drop(v_kind_248);
    if (heff_strEq_c(v_text_249, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str4))) {
      heff_drop_rec(v_x_2414, 9);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam9, 1, 2, (V[]){v_x_242, v_k_244})));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2414, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_str5))) {
        return (g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam10, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      } else {
        return (g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kind_248 = heff_take_field(v_x_247, 0);
  V v_text_249 = heff_get_n(v_x_247, 1, 9);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam3_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam4, 1, 5, (V[]){v_kind_248, v_text_249, v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_hd_244) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam0, 1, 5, (V[]){v_hd_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2413, v_x_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_x_246, v_t_2415));
  V v_x_2417 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_x_2417}), v_lit_241});
  return (g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(v_t_2418, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 14)), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam5, 1, 7, (V[]){v_x_2413, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_kind_2410 = heff_env(self)[0];
  V v_text_2411 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if (((heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 16)) == NTAG(TAG_True)) && ((heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_str0), 2) && heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_str1), 2)) && !(heff_dup(v_x_2412) == NTAG(TAG_True))))) {
    heff_drop(v_x_2412);
    heff_drop(v_kind_2410);
    heff_drop(v_text_2411);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam4, 1, 7, (V[]){v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
  } else {
    heff_drop(v_x_2412);
    heff_drop(v_kind_2410);
    heff_drop(v_text_2411);
    heff_drop_rec(v_hd_244, 3);
    V v_t_2421;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Nil: {
      v_t_2421 = v_x_245;
      break;
    }
    case TAG_Cons: {
      v_t_2421 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_x_246});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_t_2421}), v_lit_241});
    return (g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(v_t_2422, v_lit_242, v_lit_243));
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_kind_2410 = heff_take_field(v_x_249, 0);
  V v_text_2411 = heff_get_n(v_x_249, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam3, 1, 9, (V[]){v_kind_2410, v_text_2411, v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam2, 1, 7, (V[]){v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_lam1, 1, 6, (V[]){v_hd_244, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_str1, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_str2, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam3, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam4, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam3(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V v_t_2410 = heff_tag_n(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_249;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_str1); V a_1 = v_t_2414; V a_2 = NTAG(TAG_Nil); V a_3 = v_hd_2411; V a_4 = v_k_2412; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s121904211x184271991(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam4(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  return (g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(heff_dup(v_hd_2411), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam5, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkSep: {
    V v_items_2418 = heff_field(v_x_2416, 0);
    V v_seps_2419 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    v_t_2420 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2418, v_seps_2419, v_x_2417});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_244;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_str2), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam7, 1, 3, (V[]){v_x_2416, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415;
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_str0))) {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam3_clo);
  } else {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam4_clo);
  }
  V f_ = v_t_2415;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam6, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_entry, 8, 0};

V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_hd_247) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam0, 1, 8, (V[]){v_hd_247, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2416, v_x_2417}), NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_x_249, v_t_2418));
  V v_x_2420 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_t_2419});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_x_2420}), v_lit_245});
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2421, v_lit_246));
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 14)), v_hd_247, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam5, 1, 10, (V[]){v_x_2416, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_kind_2413 = heff_env(self)[0];
  V v_text_2414 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_lit_242 = heff_env(self)[9];
  V v_lit_243 = heff_env(self)[10];
  V v_lit_246 = heff_env(self)[11];
  heff_clo_take(self, 12);
  if (((heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 16)) == NTAG(TAG_True)) && ((heff_strEq_c_lent(v_kind_2413, ((V)&g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_str0), 2) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_str1), 2)) && !(heff_dup(v_x_2415) == NTAG(TAG_True))))) {
    heff_drop(v_x_2415);
    heff_drop(v_kind_2413);
    heff_drop(v_text_2414);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam4, 1, 10, (V[]){v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
  } else {
    heff_drop(v_x_2415);
    heff_drop(v_kind_2413);
    heff_drop(v_text_2414);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2424;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nil: {
      v_t_2424 = v_x_248;
      break;
    }
    case TAG_Cons: {
      v_t_2424 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_x_249});
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_t_2424}), v_lit_245});
    return (g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2425, v_lit_246));
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_kind_2413 = heff_take_field(v_x_2412, 0);
  V v_text_2414 = heff_get_n(v_x_2412, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam3, 1, 12, (V[]){v_kind_2413, v_text_2414, v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_lit_244 = heff_env(self)[2];
  V v_lit_245 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam2, 1, 10, (V[]){v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_lit_244 = heff_env(self)[1];
  V v_lit_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_lit_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_lam1, 1, 9, (V[]){v_hd_247, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2egram_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam1, 2, 0};
V g_heff_2esyntax_2ecst_2egram_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam8, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam9(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam9, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam10(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam10, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam11(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam11, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam12(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam12, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam13(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam13, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam14(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam14, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam15(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam15, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam16(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam16, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam20(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam20, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam21(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam21, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam22(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam22, 1, 0};

static V g_heff_2esyntax_2ecst_2egram_val;
static HEFF_ONCE g_heff_2esyntax_2ecst_2egram_st;
static V g_heff_2esyntax_2ecst_2egram_init(void) {
  return heff_rec_n(17, shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE__head__stmt__arm__blockArg, (V[]){((V)&g_heff_2esyntax_2ecst_2egram_lam0_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam1_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam4_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam8_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam9_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam10_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam11_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam12_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam13_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam14_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam15_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam16_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam20_clo), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam21_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam22_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2ecst_2egram_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2ecst_2egram_st)) return g_heff_2esyntax_2ecst_2egram_val;
  return heff_global(&g_heff_2esyntax_2ecst_2egram_val, &g_heff_2esyntax_2ecst_2egram_st, g_heff_2esyntax_2ecst_2egram_init);
}
V g_heff_2esyntax_2ecst_2egram_lam0(V self, V *args) {
  V v_st_240 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eexprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_240;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eopLoopF(v_g_243, v_minPrec_241, v_x_245, v_st_242, v_k_244));
}
V g_heff_2esyntax_2ecst_2egram_lam2(V self, V *args) {
  V v_k_244 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_minPrec_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_243, 2));
  heff_room[0] = heff_dup(v_st_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam3, 1, 4, (V[]){v_g_243, v_minPrec_241, v_st_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam1(V self, V *args) {
  V v_minPrec_241 = args[0];
  V v_st_242 = args[1];
  V v_g_243 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam2, 1, 3, (V[]){v_g_243, v_st_242, v_minPrec_241});
}
V g_heff_2esyntax_2ecst_2egram_lam7(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nil: {
    v_t_2413 = v_x_249;
    break;
  }
  case TAG_Cons: {
    v_t_2413 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_249, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam6(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_247, NTAG(TAG_Nil), v_st_246, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam7, 1, 2, (V[]){v_x_249, v_k_248})));
}
V g_heff_2esyntax_2ecst_2egram_lam5(V self, V *args) {
  V v_k_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_g_247, 3));
  heff_room[0] = heff_dup(v_st_246);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam6, 1, 3, (V[]){v_g_247, v_st_246, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam4(V self, V *args) {
  V v_st_246 = args[0];
  V v_g_247 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam5, 1, 2, (V[]){v_g_247, v_st_246});
}
V g_heff_2esyntax_2ecst_2egram_lam8(V self, V *args) {
  V v_st_2414 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eappF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam9(V self, V *args) {
  V v_st_2415 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eatomF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam10(V self, V *args) {
  V v_st_2416 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatternF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam11(V self, V *args) {
  V v_st_2417 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatHeadF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam12(V self, V *args) {
  V v_st_2418 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatAtomF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam13(V self, V *args) {
  V v_st_2419 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2elambdaF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam14(V self, V *args) {
  V v_st_2420 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2ecaseExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam15(V self, V *args) {
  V v_st_2421 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eifExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam19(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Do, 2, (V[]){v_x_2425, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam18(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_2423 = heff_env(self)[0];
  V v_st_2422 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_2423, 14, 17), v_st_2422, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam19, 1, 2, (V[]){v_k_2424, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2egram_lam17(V self, V *args) {
  V v_k_2424 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_g_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_st_2422), heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam18, 1, 3, (V[]){v_g_2423, v_st_2422, v_k_2424})));
}
V g_heff_2esyntax_2ecst_2egram_lam16(V self, V *args) {
  V v_st_2422 = args[0];
  V v_g_2423 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam17, 1, 2, (V[]){v_st_2422, v_g_2423});
}
V g_heff_2esyntax_2ecst_2egram_lam20(V self, V *args) {
  V v_st_2427 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eletExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam21(V self, V *args) {
  V v_st_2428 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2estmtF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam22(V self, V *args) {
  V v_st_2429 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2earmF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2429;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_t_2414 = heff_get_n(v_s_2413, 3, 5);
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 2);
    return v_x_2415;
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_col_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_take_field(v_s_2423, 3);
  V v_top_2425 = heff_take_field(v_s_2423, 2);
  V v_start_2426 = heff_take_field(v_s_2423, 4);
  return ({ V rv_2 = v_top_2425; V rv_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_col_249, v_t_2424}); V rv_4 = v_start_2426; V rr_ = heff_rec_reuse_nf(v_s_2423, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_k_2435 = (g_list_2edrop(MK_INT(1LL), heff_rfield(v_s_2434, 3)));
  V v_top_2436 = heff_take_field(v_s_2434, 2);
  V v_start_2437 = heff_take_field(v_s_2434, 4);
  return ({ V rv_2 = v_top_2436; V rv_3 = v_k_2435; V rv_4 = v_start_2437; V rr_ = heff_rec_reuse_nf(v_s_2434, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V f_ = v_k_241;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2441 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2440, NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9, 1, 2, (V[]){v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7_clo)})});
  V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2438}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2439;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_col_249 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(v_col_249, NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_col_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5, 1, 3, (V[]){v_col_249, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_first_248 = heff_env(self)[0];
  V v_col_249 = heff_env(self)[1];
  V v_start_246 = heff_env(self)[2];
  V v_end_247 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (((heff_dup(v_first_248) == NTAG(TAG_True)) && heff_intLe_c_lent(v_col_249, v_x_2419, 0))) {
    heff_drop(v_x_2419);
    heff_drop(v_first_248);
    heff_drop(v_col_249);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str2), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2421}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2422;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2419);
    heff_drop(v_first_248);
    heff_drop(v_start_246);
    heff_drop(v_end_247);
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3, 1, 1, (V[]){heff_dup(v_col_249)})})});
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2427}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2428;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4, 1, 3, (V[]){v_hd_240, v_col_249, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_kind_245 = heff_take_field(v_x_244, 0);
  V v_start_246 = heff_take_field(v_x_244, 3);
  V v_end_247 = heff_take_field(v_x_244, 4);
  V v_first_248 = heff_take_field(v_x_244, 6);
  V v_col_249 = heff_get_n(v_x_244, 5, 9);
  if (heff_strEq_c(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str0))) {
    heff_drop(v_first_248);
    heff_drop(v_col_249);
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1_clo)})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2417}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2, 1, 6, (V[]){v_first_248, v_col_249, v_start_246, v_end_247, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str1, 20, "the name of a theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str2, 5, "where");
V g_heff_2esyntax_2ecst_2etheoryDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etheoryDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etheoryDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_248 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_248, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etheoryDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DTheory, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam4, 1, 5, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str1); V a_2 = heff_dup(v_hd_240); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str4, 1, ")");
Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclNameLen_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edeclNameLen(V v_t_240, V v_t2_241, V v_t3_242) {
top: ;
  V v_kind_243 = heff_take_field(v_t2_241, 0);
  V v_text_244 = heff_get_n(v_t2_241, 1, 9);
  V v_kind_245 = heff_take_field(v_t_240, 0);
  V v_text_246 = heff_get_n(v_t_240, 1, 9);
  if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str0), 2) || heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str1), 2))) {
    heff_drop_rec(v_t3_242, 9);
    heff_drop(v_kind_243);
    heff_drop(v_text_244);
    heff_drop(v_kind_245);
    heff_drop(v_text_246);
    return MK_INT(1LL);
  } else {
    heff_drop(v_kind_245);
    if ((heff_strEq_c_lent(v_text_246, ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str2), 2) && ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str3), 2) && ({ V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_244)})); int c_ = ({ V v_x1_248 = ({ V a_0 = heff_dup(v_t_247); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; }); int c_ = !(heff_dup(v_x1_248) == NTAG(TAG_True)); heff_drop(v_x1_248); c_; }); heff_drop(v_t_247); c_; })) && heff_strEq_c(heff_dup(heff_rfield(v_t3_242, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str4))))) {
      heff_drop_rec(v_t3_242, 9);
      heff_drop(v_kind_243);
      heff_drop(v_text_244);
      heff_drop(v_text_246);
      return MK_INT(3LL);
    } else {
      heff_drop_rec(v_t3_242, 9);
      heff_drop(v_kind_243);
      heff_drop(v_text_244);
      heff_drop(v_text_246);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclNameLen(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2einstanceDecl_str0, 38, "an instance is named: `instance f : T`");
V g_heff_2esyntax_2ecst_2einstanceDecl_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einstanceDecl_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einstanceDecl_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2einstanceDecl_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einstanceDecl_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einstanceDecl_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2einstanceDecl_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2einstanceDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2einstanceDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einstanceDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2einstanceDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_2426 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_2426, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2einstanceDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2einstanceDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_s_247, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_247, v_t_248));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam4(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_2413 = heff_intAdd(heff_dup(heff_rfield(v_s_2412, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2412, v_t_2413));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DInstance, 4, (V[]){v_x_243, v_x_2423, v_x_2424, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam8, 1, 4, (V[]){v_k_241, v_x_243, v_x_2423, v_x_2424})));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam7, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_2423})));
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_x_246), heff_dup(v_x_2411), heff_dup(v_x_2416)));
  if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
    heff_drop(v_x_2416);
    heff_drop(v_x_2411);
    heff_drop(v_x_243);
    V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 3), heff_get_n(v_x_246, 4, 9)});
    V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2einstanceDecl_str0), v_t_2418, NTAG(TAG_Nothing)});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2420}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2421;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2422 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_x_246, v_x_2411, v_x_2416));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2422, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam6, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
  }
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einstanceDecl_lam4_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam5, 1, 5, (V[]){v_x_246, v_x_2411, v_hd_240, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einstanceDecl_lam2_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam3, 1, 4, (V[]){v_hd_240, v_x_246, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einstanceDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einstanceDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str0, 33, "a declaration cannot start with `");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str3, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str4, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str7, 5, "where");
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry, 3, 0};

V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V v_t_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1, 1, 3, (V[]){v_hd_241, v_t_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_s_243, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_243, v_t_244));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4(V self, V *args) {
  V v_s_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_intAdd(heff_dup(heff_rfield(v_s_2420, 1)), v_k_2419);
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2420, v_t_2421));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkSep: {
    V v_names_2430 = heff_field(v_x_2427, 0);
    V v_commas_2431 = heff_field(v_x_2427, 1);
    heff_take_n(v_x_2427, 3ULL, 2);
    v_t_2432 = heff_tag_n(TAG_DSig, 4, (V[]){v_names_2430, v_commas_2431, v_x_2428, v_x_2429});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_242;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9, 1, 3, (V[]){v_x_2427, v_x_2428, v_k_242})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8, 1, 3, (V[]){v_hd_241, v_x_2427, v_k_242})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str4); V a_1 = v_t_2426; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_241); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7, 1, 2, (V[]){v_hd_241, v_k_242}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17(V self, V *args) {
  V v_x_2446 = args[0];
  V v_x_2445 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2445, v_x_2446})});
  V f_ = v_k_2444;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_2443 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(v_hd_2443, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17, 1, 2, (V[]){v_x_2445, v_k_2444})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2443), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16, 1, 2, (V[]){v_hd_2443, v_k_2444})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  heff_drop(v_hd_2448);
  V f_ = v_k_2449;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_x_2436 = heff_env(self)[3];
  V v_x_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2434, v_x_2435, v_x_2436, v_x_2437, v_x_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_x_2437 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_kind_2441 = heff_take_field(v_x_2440, 0);
  V v_text_2442 = heff_get_n(v_x_2440, 1, 9);
  V v_t_2450;
  if ((heff_strEq_c_lent(v_kind_2441, ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str6), 2) && heff_strEq_c_lent(v_text_2442, ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str7), 2))) {
    heff_drop(v_kind_2441);
    heff_drop(v_text_2442);
    v_t_2450 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15_clo);
  } else {
    heff_drop(v_kind_2441);
    heff_drop(v_text_2442);
    v_t_2450 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18_clo);
  }
  V f_ = v_t_2450;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19, 1, 5, (V[]){v_k_242, v_x_2434, v_x_2435, v_x_2436, v_x_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2438}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2439;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14, 1, 6, (V[]){v_hd_241, v_k_242, v_x_2434, v_x_2435, v_x_2436, v_x_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13, 1, 5, (V[]){v_hd_241, v_k_242, v_x_2434, v_x_2435, v_x_2436})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str5), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2434, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 7)), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2434})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_t_240 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_strEq_c(heff_dup(heff_rfield(v_x_2424, 1)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_x_2424, 1)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str3)))) {
    heff_drop_rec(v_x_2424, 9);
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_x_247);
    heff_drop(v_x_2412);
    return (g_heff_2esyntax_2ecst_2esigName(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
  } else {
    heff_drop_rec(v_x_2424, 9);
    V v_t_2433 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_240, v_x_247, v_x_2412));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2433, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_247), heff_dup(v_x_2412)));
  if (heff_intEq_c(v_t_2413, MK_INT(0LL))) {
    heff_drop(v_x_2412);
    heff_drop(v_x_247);
    V v_span_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_take_field(v_t_240, 4)});
    V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str0), heff_get_n(v_t_240, 1, 9));
    V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str1)), v_span_2414, NTAG(TAG_Nothing)});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2417}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2418;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_k_2419 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_247), heff_dup(v_x_2412)));
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4, 1, 1, (V[]){v_k_2419})})});
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2422}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2423;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5, 1, 5, (V[]){v_hd_241, v_k_242, v_t_240, v_x_247, v_x_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3, 1, 4, (V[]){v_t_240, v_x_247, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eskipFrom_str0, 3, "eof");
Clo g_heff_2esyntax_2ecst_2eskipFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eskipFrom_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eskipFrom(V v_s_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_241, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eskipFrom_str0))) {
    return v_s_240;
  } else {
    V v_i_242 = heff_intAdd(heff_take_field(v_s_240, 1), MK_INT(1LL));
    V v_top_243 = heff_take_field(v_s_240, 2);
    V v_stack_244 = heff_take_field(v_s_240, 3);
    V v_start_245 = heff_take_field(v_s_240, 4);
    V v_t_246 = ({ V rv_1 = v_i_242; V rv_2 = v_top_243; V rv_3 = v_stack_244; V rv_4 = v_start_245; V rr_ = heff_rec_reuse_nf(v_s_240, 1ULL, 5, shape_toks__i__top__stack__start, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    V t_0 = v_t_246;
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eskipFrom(a[0]);
}
Clo g_heff_2esyntax_2ecst_2eskipDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eskipDecl_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eskipDecl(V v_s_240) {
top: ;
  V v_t_241 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
  V v_i_242;
  if (heff_intLt_c(heff_dup(heff_rfield(v_s_240, 1)), v_t_241)) {
    v_i_242 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
  } else {
    v_i_242 = heff_dup(heff_rfield(v_s_240, 1));
  }
  V v_top_243 = heff_take_field(v_s_240, 2);
  V v_start_244 = heff_take_field(v_s_240, 4);
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_246 = ({ V rv_1 = v_i_242; V rv_2 = v_top_243; V rv_3 = v_t_245; V rv_4 = v_start_244; V rr_ = heff_rec_reuse_nf(v_s_240, 1ULL, 5, shape_toks__i__top__stack__start, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  HEFF_LAST return g_heff_2esyntax_2ecst_2eskipFrom(v_t_246);
}
V g_heff_2esyntax_2ecst_2eskipDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eskipDecl(a[0]);
}