// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_json_2ejoinInto_2erestInto_240(V, V, V, V);
V g_json_2ejoinInto_2erestInto_240_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_clo;
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V, V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
Clo g_json_2ejoinInto_2erestInto_240_clo = {{0x80000000u, K_CLO, 0}, g_json_2ejoinInto_2erestInto_240_entry, 4, 0};

V g_json_2ejoinInto_2erestInto_240(V v_write_240, V v_sep_241, V v_acc_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_write_240);
    heff_drop(v_sep_241);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_write_240), 2, (V[]){heff_strAppend(v_acc_242, heff_dup(v_sep_241)), heff_dup(v_x_244)}));
    V t_0 = v_write_240;
    V t_1 = v_sep_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_write_240 = t_0;
    v_sep_241 = t_1;
    v_acc_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_json_2ejoinInto_2erestInto_240_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_json_2ejoinInto_2erestInto_240(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_str0, 1, "\"");
HEFF_LIT(g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_str1, 1, "\"");
HEFF_LIT(g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_str2, 1, ":");
Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo = {{0x80000000u, K_CLO, 0}, g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry, 3, 0};

V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V v_sep_240, V v_acc_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_sep_240);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x_243, 0);
      V v_v_246 = heff_field(v_x_243, 1);
      V v_t_247 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_sep_240)), ((V)&g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_str0));
      V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(heff_dup(v_k_245), v_t_247, MK_INT(0LL)));
      V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_str1)), ((V)&g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_str2));
      v_t_2410 = (g_json_2estringify_2ewriteInto_240(v_t_249, v_v_246));
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_sep_240;
    V t_1 = v_t_2410;
    V t_2 = v_xs_244;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a[0], a[1], a2); heff_drop(a2); return r;
}