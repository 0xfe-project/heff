// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HGlobal 55847
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SpId 35501
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2etop_2evalueOf_lam0(V self, V *args);
V g_heff_2eelab_2etop_2evalueOf_lam1(V self, V *args);
Clo g_heff_2eelab_2etop_2evalueOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etop_2evalueOf_entry, 4, 0};

V g_heff_2eelab_2etop_2evalueOf(V v_g_240, V v_k_241, V v_tyStx_242, V v_bodyStx_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etop_2evalueOf_lam0, 1, 4, (V[]){heff_dup(v_g_240), heff_dup(v_k_241), heff_dup(v_tyStx_242), heff_dup(v_bodyStx_243)})});
  V v_t_246 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(v_g_240), NTAG(TAG_De), v_bodyStx_243, v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nom: {
    V v_v_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_k_241);
    heff_drop(v_tyStx_242);
    return v_v_247;
  }
  case TAG_Describe: {
    V v_desc_248 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Describe = heff_take_reuse_n(v_t_246, 1ULL, 1);
    HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_at_n(v_ru_24t_246_24Describe, TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etop_2evalueOf_lam1, 1, 2, (V[]){v_g_240, v_tyStx_242}), heff_tag_n(TAG_Just, 1, (V[]){v_desc_248}));
  }
  case TAG_Become: {
    V v_v_2418 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_k_241);
    heff_drop(v_tyStx_242);
    return v_v_2418;
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etop_2evalueOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etop_2evalueOf_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_tyStx_242 = heff_env(self)[2];
  V v_bodyStx_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_244);
  return (g_heff_2eelab_2etop_2evalueOf(v_g_240, v_k_241, v_tyStx_242, v_bodyStx_243));
}
V g_heff_2eelab_2etop_2evalueOf_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_249);
  HeffT2 v_t_2410 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_tyStx_242, NTAG(TAG_LNil)));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      return v_x_2414;
    } else {
      if ((v_tag_2411 == ((int64_t)1ULL))) {
        V v_x11_2416 = v_field_2412;
        heff_drop(v_x11_2416);
        return heff_abandon();
      } else {
        V v_x_2417 = v_field_2412;
        return v_x_2417;
      }
    }
  }
}