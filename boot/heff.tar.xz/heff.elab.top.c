// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_De 8978
#define TAG_HGlobal 55847
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_N 306
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2eelab_2etop_2evalueOf_lam0(V self, V *args);
V g_heff_2eelab_2etop_2evalueOf_lam1(V self, V *args);
Clo g_heff_2eelab_2etop_2evalueOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etop_2evalueOf_entry, 4, 0};

V g_heff_2eelab_2etop_2evalueOf(V v_g_240, V v_k_241, V v_tyStx_242, V v_bodyStx_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etop_2evalueOf_lam0, 1, 4, (V[]){heff_dup(v_g_240), heff_dup(v_k_241), heff_dup(v_tyStx_242), heff_dup(v_bodyStx_243)})});
  V v_t_246 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_dup(v_g_240), NTAG(TAG_De), v_bodyStx_243, v_t_245));
  return (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), heff_clo_n(g_heff_2eelab_2etop_2evalueOf_lam1, 1, 2, (V[]){v_g_240, v_tyStx_242}), heff_tag_n(TAG_Just, 1, (V[]){v_t_246})));
}
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etop_2evalueOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etop_2evalueOf_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_tyStx_242 = heff_env(self)[2];
  V v_bodyStx_243 = heff_env(self)[3];
  heff_drop(v_u_244);
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2etop_2evalueOf(v_g_240, v_k_241, v_tyStx_242, v_bodyStx_243));
}
V g_heff_2eelab_2etop_2evalueOf_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_242 = heff_env(self)[1];
  heff_drop(v_u_247);
  heff_clo_take(self, 2);
  HeffT2 v_t_248 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_tyStx_242, NTAG(TAG_LNil)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      return v_x_2411;
    } else {
      if ((v_tag_249 == ((int64_t)1ULL))) {
        V v_x11_2412 = v_field_2410;
        heff_drop(v_x11_2412);
        return heff_abandon();
      } else {
        V v_x_2413 = v_field_2410;
        return v_x_2413;
      }
    }
  }
}