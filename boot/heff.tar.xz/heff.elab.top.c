// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HGlobal 55847
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SpId 35501
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2etop_2evalueOf_lam0(V self, V *args);
V g_heff_2eelab_2etop_2evalueOf_lam1(V self, V *args);
Clo g_heff_2eelab_2etop_2evalueOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etop_2evalueOf_entry, 4, 0};

V g_heff_2eelab_2etop_2evalueOf(V v_g_240, V v_k_241, V v_tyStx_242, V v_bodyStx_243) {
top: ;
  V v_ty_249 = heff_clo_n(g_heff_2eelab_2etop_2evalueOf_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_242)});
  V v_t_2411 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etop_2evalueOf_lam1, 1, 4, (V[]){heff_dup(v_g_240), heff_dup(v_k_241), v_tyStx_242, heff_dup(v_bodyStx_243)})});
  V v_edesc_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_De), v_bodyStx_243, v_t_2411))});
  switch (heff_tag_of(v_edesc_2412)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), v_ty_249, NTAG(TAG_Nothing));
  }
  case TAG_Just: {
    V v_it1_2413 = heff_field(v_edesc_2412, 0);
    V v_ru_24edesc_2412_24Just = heff_take_reuse_n(v_edesc_2412, 1ULL, 1);
    switch (heff_tag_of(v_it1_2413)) {
    case TAG_Nom: {
      V v_v_2414 = heff_field(v_it1_2413, 0);
      heff_take_n(v_it1_2413, 1ULL, 1);
      heff_drop(v_k_241);
      heff_drop_clo(v_ty_249, 2);
      heff_drop_cell(v_ru_24edesc_2412_24Just, 1);
      return v_v_2414;
    }
    case TAG_Describe: {
      V v_desc_2415 = heff_field(v_it1_2413, 0);
      V v_ru_24it1_2413_24Describe = heff_take_reuse_n(v_it1_2413, 1ULL, 1);
      HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_at_n(v_ru_24edesc_2412_24Just, TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), v_ty_249, heff_tag_at_n(v_ru_24it1_2413_24Describe, TAG_Just, 1, (V[]){v_desc_2415}));
    }
    case TAG_Become: {
      V v_v_2416 = heff_field(v_it1_2413, 0);
      heff_take_n(v_it1_2413, 1ULL, 1);
      heff_drop(v_k_241);
      heff_drop_clo(v_ty_249, 2);
      heff_drop_cell(v_ru_24edesc_2412_24Just, 1);
      return v_v_2416;
    }
    default: return heff_nomatch(v_it1_2413);
    }
  }
  default: return heff_nomatch(v_edesc_2412);
  }
}
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etop_2evalueOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etop_2evalueOf_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_244);
  V v_x1_245 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_tyStx_242, NTAG(TAG_LNil)));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nom: {
    V v_x_246 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    return v_x_246;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_248 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 1);
    return v_x_248;
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2etop_2evalueOf_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_tyStx_242 = heff_env(self)[2];
  V v_bodyStx_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2410);
  return (g_heff_2eelab_2etop_2evalueOf(v_g_240, v_k_241, v_tyStx_242, v_bodyStx_243));
}