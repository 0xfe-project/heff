// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclPrimitive 46335
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_If 9134
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_binder 558177493
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2earrowAfter(V, V);
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowAfter_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edigitsVal(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edigitsVal_clo;
V g_heff_2esyntax_2esurface_2eemptySpec_get(void);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efitsIn(V, V, V, V);
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efitsIn_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str0, 2, "0x");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str1, 2, "0X");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str2, 2, "0b");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str3, 2, "0B");
Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emagnitudeOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emagnitudeOf(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
  V v_t_245 = heff_bool((heff_strEq_c(heff_dup(v_t_242), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str0)) || ({ V v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))); int c_ = heff_strEq_c(heff_dup(v_t_244), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str1)); heff_drop(v_t_244); c_; })));
  heff_drop(v_t_242);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(16LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
  } else {
    heff_drop(v_t_245);
    V v_t_246 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str2))) {
      return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
    } else {
      V v_t_248 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str3))) {
        return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
      } else {
        return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(10LL), heff_dup(v_s_240), v_i_241, heff_strLength(v_s_240), MK_INT(0LL)));
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emagnitudeOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eboundBy(V v_pv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_243 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_243);
  }
  case TAG_PAtom: {
    V v_t_245 = heff_field(v_x2_241, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str2))) {
          V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_245, 1))}));
          V v_t_2410 = (g_list_2eany(v_t_249, v_pv_240));
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop(v_t_2410);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
          } else {
            heff_drop(v_t_2410);
            return NTAG(TAG_Nil);
          }
        } else {
          return NTAG(TAG_Nil);
        }
      } else {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str3))) {
        V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_245, 1))}));
        V v_t_2413 = (g_list_2eany(v_t_2412, v_pv_240));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2413);
          return NTAG(TAG_Nil);
        }
      } else {
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2415 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2415;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2418 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2418);
  }
  case TAG_POp: {
    V v_l_2422 = heff_field(v_x2_241, 0);
    V v_q_2424 = heff_field(v_x2_241, 2);
    V v_t_2425 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2422));
    V v_t_2426 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2424));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2425, v_t_2426);
  }
  case TAG_PRec: {
    V v_fs_2428 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2428);
  }
  case TAG_PField: {
    V v_q_2434 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2434;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2435 = heff_field(v_x2_241, 0);
    V v_q_2437 = heff_field(v_x2_241, 2);
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2435, 1)), heff_hole()});
    V v_u_2439 = (g_heff_2esyntax_2esurface_2eboundBy_24dps(v_pv_240, v_q_2437, heff_dup(v_cell_2438)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  case TAG_PSeg: {
    V v_q_2440 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2440;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args) {
  V v_q_244 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_244); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args) {
  V v_q_2421 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2421; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2421); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args) {
  V v_q_2431 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2431; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2431); r_; });
}
Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisNameE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowAfter_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowAfter_str1, 2, "->");
Clo g_heff_2esyntax_2esurface_2earrowAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowAfter_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowAfter(V v_s_240, V v_t_241) {
top: ;
  V v_xs_242 = heff_get_n(v_s_240, 0, 8);
  V v_i_243 = heff_intAdd(heff_get_n(v_t_241, 7, 9), MK_INT(1LL));
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(v_i_243)) && (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_242))) && ({ V v_u_246 = heff_arrayIndex(heff_dup(v_xs_242), heff_dup(v_i_243)); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_u_246, 0)), ((V)&g_heff_2esyntax_2esurface_2earrowAfter_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_u_246, 1)), ((V)&g_heff_2esyntax_2esurface_2earrowAfter_str1))); heff_drop(v_u_246); c_; }))));
  heff_drop(v_xs_242);
  heff_drop(v_i_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowAfter(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(v_z_240, v_xs_243));
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_a_244)});
    V v_t_246 = heff_get_n(heff_get_n(v_x_242, 1, 2), 0, 2);
    V v_t_249;
    switch (heff_tag_of(v_a_244)) {
    case TAG_At: {
      V v_a_248 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_t_2410 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_t_2410});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efitsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efitsIn_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efitsIn(V v_x1_240, V v_signed_241, V v_n_242, V v_v_243) {
top: ;
  V v_ret_24bool = heff_bool(((heff_dup(v_x1_240) == NTAG(TAG_True)) ? ((heff_dup(v_signed_241) == NTAG(TAG_True)) ? ({ V v_t_244 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(heff_dup(v_n_242), MK_INT(1LL)))); int c_ = (heff_intLe_c(heff_intSub(MK_INT(0LL), heff_dup(v_t_244)), heff_dup(v_v_243)) && ({ V v_t_246 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(heff_dup(v_n_242), MK_INT(1LL)))); int c_ = heff_intLt_c(heff_dup(v_v_243), heff_dup(v_t_246)); heff_drop(v_t_246); c_; })); heff_drop(v_t_244); c_; }) : (heff_intLe_c(MK_INT(0LL), heff_dup(v_v_243)) && ({ V v_t_248 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_242))); int c_ = heff_intLt_c(heff_dup(v_v_243), heff_dup(v_t_248)); heff_drop(v_t_248); c_; }))) : ({ V v_t_249 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(heff_dup(v_n_242), MK_INT(1LL)))); int c_ = (heff_intLe_c(heff_intSub(MK_INT(0LL), heff_dup(v_t_249)), heff_dup(v_v_243)) && ({ V v_t_2411 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_242))); int c_ = heff_intLt_c(heff_dup(v_v_243), heff_dup(v_t_2411)); heff_drop(v_t_2411); c_; })); heff_drop(v_t_249); c_; })));
  heff_drop(v_n_242);
  heff_drop(v_v_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efitsIn(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esegmentL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esegmentL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam0, 1, 2, (V[]){v_m_243, v_e_241});
  }
  case TAG_EParen: {
    V v_m_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam1, 1, 2, (V[]){v_m_2419, v_e_241});
  }
  case TAG_Named: {
    V v_m_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam2, 1, 2, (V[]){v_m_2437, v_e_241});
  }
  case TAG_Tup: {
    V v_m_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam3, 1, 2, (V[]){v_m_2454, v_e_241});
  }
  case TAG_Seg: {
    V v_v_2467 = heff_field(v_e_241, 0);
    V v_cc_2468 = heff_field(v_e_241, 1);
    V v_spec_2469 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_v_2467)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam4, 1, 4, (V[]){v_m_2470, v_cc_2468, v_spec_2469, v_v_2467});
  }
  case TAG_Braces: {
    V v_m_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam5, 1, 2, (V[]){v_m_2495, v_e_241});
  }
  case TAG_Update: {
    V v_m_24114 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam6, 1, 2, (V[]){v_m_24114, v_e_241});
  }
  case TAG_EUSet: {
    V v_m_24130 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam7, 1, 2, (V[]){v_m_24130, v_e_241});
  }
  case TAG_InstB: {
    V v_m_24148 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam8, 1, 2, (V[]){v_m_24148, v_e_241});
  }
  case TAG_EFSet: {
    V v_m_24164 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam9, 1, 2, (V[]){v_m_24164, v_e_241});
  }
  case TAG_EFDefault: {
    V v_m_24180 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam10, 1, 2, (V[]){v_m_24180, v_e_241});
  }
  case TAG_Sum: {
    V v_m_24198 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam11, 1, 2, (V[]){v_m_24198, v_e_241});
  }
  case TAG_ECon: {
    V v_m_24213 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam12, 1, 2, (V[]){v_m_24213, v_e_241});
  }
  case TAG_EField: {
    V v_m_24228 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam13, 1, 2, (V[]){v_m_24228, v_e_241});
  }
  case TAG_ENeg: {
    V v_m_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam14, 1, 2, (V[]){v_m_24243, v_e_241});
  }
  case TAG_App: {
    V v_m_24258 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam15, 1, 2, (V[]){v_m_24258, v_e_241});
  }
  case TAG_Op: {
    V v_m_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam16, 1, 2, (V[]){v_m_24274, v_e_241});
  }
  case TAG_Ops: {
    V v_m_24289 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam17, 1, 2, (V[]){v_m_24289, v_e_241});
  }
  case TAG_OpRhs: {
    V v_m_24304 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam18, 1, 2, (V[]){v_m_24304, v_e_241});
  }
  case TAG_Ann: {
    V v_m_24320 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam19, 1, 2, (V[]){v_m_24320, v_e_241});
  }
  case TAG_BVar: {
    V v_m_24334 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam20, 1, 2, (V[]){v_m_24334, v_e_241});
  }
  case TAG_BImp: {
    V v_m_24350 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam21, 1, 2, (V[]){v_m_24350, v_e_241});
  }
  case TAG_BAnn: {
    V v_m_24368 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam22, 1, 2, (V[]){v_m_24368, v_e_241});
  }
  case TAG_Lam: {
    V v_m_24385 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam23, 1, 2, (V[]){v_m_24385, v_e_241});
  }
  case TAG_Case: {
    V v_m_24402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam24, 1, 2, (V[]){v_m_24402, v_e_241});
  }
  case TAG_EAlt: {
    V v_m_24418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam25, 1, 2, (V[]){v_m_24418, v_e_241});
  }
  case TAG_If: {
    V v_m_24437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam26, 1, 2, (V[]){v_m_24437, v_e_241});
  }
  case TAG_Do: {
    V v_m_24452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam27, 1, 2, (V[]){v_m_24452, v_e_241});
  }
  case TAG_ESBind: {
    V v_m_24468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam28, 1, 2, (V[]){v_m_24468, v_e_241});
  }
  case TAG_ELet: {
    V v_m_24487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam29, 1, 2, (V[]){v_m_24487, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esegmentL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V v_a_2410 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2410, 3, 9), v_e_2412});
      V v_t_2414 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_249));
      V v_t_2415 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2413; V a_2 = v_x_249; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_2415;
      args[0] = v_st_247;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args) {
  V v_st_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_st_2420}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_MkPair: {
    V v_x11_2422 = heff_field(v_x1_2421, 0);
    V v_st_2423 = heff_field(v_x1_2421, 1);
    V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
    switch (heff_tag_of(v_x11_2422)) {
    case TAG_Left: {
      V v_e_2424 = heff_field(v_x11_2422, 0);
      heff_take_n(v_x11_2422, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_x11_2422, 0);
      heff_take_n(v_x11_2422, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24MkPair, 2);
      V v_a_2426 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2427 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2428 = heff_get_n(v_t_2427, 4, 9);
      V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2426, 3, 9), v_e_2428});
      V v_t_2430 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2425));
      V v_t_2431 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2429; V a_2 = v_x_2425; V a_3 = v_t_2430; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_2431;
      args[0] = v_st_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2422);
    }
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam2(V self, V *args) {
  V v_st_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_st_2438}));
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_MkPair: {
    V v_x11_2440 = heff_field(v_x1_2439, 0);
    V v_st_2441 = heff_field(v_x1_2439, 1);
    V v_ru_24x1_2439_24MkPair = heff_take_reuse_n(v_x1_2439, 3ULL, 2);
    switch (heff_tag_of(v_x11_2440)) {
    case TAG_Left: {
      V v_e_2442 = heff_field(v_x11_2440, 0);
      heff_take_n(v_x11_2440, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
    }
    case TAG_Right: {
      V v_x_2443 = heff_field(v_x11_2440, 0);
      heff_take_n(v_x11_2440, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2439_24MkPair, 2);
      V v_a_2444 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2445 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2446 = heff_get_n(v_t_2445, 4, 9);
      V v_t_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2444, 3, 9), v_e_2446});
      V v_t_2448 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2443));
      V v_t_2449 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2447; V a_2 = v_x_2443; V a_3 = v_t_2448; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_2449;
      args[0] = v_st_2441;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2440);
    }
  }
  default: return heff_nomatch(v_x1_2439);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam3(V self, V *args) {
  V v_st_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_st_2455}));
  switch (heff_tag_of(v_x1_2456)) {
  case TAG_MkPair: {
    V v_x11_2457 = heff_field(v_x1_2456, 0);
    V v_st_2458 = heff_field(v_x1_2456, 1);
    V v_ru_24x1_2456_24MkPair = heff_take_reuse_n(v_x1_2456, 3ULL, 2);
    switch (heff_tag_of(v_x11_2457)) {
    case TAG_Left: {
      V v_e_2459 = heff_field(v_x11_2457, 0);
      heff_take_n(v_x11_2457, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2459}), v_st_2458});
    }
    case TAG_Right: {
      V v_x_2460 = heff_field(v_x11_2457, 0);
      heff_take_n(v_x11_2457, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2456_24MkPair, 2);
      V v_a_2461 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2462 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2463 = heff_get_n(v_t_2462, 4, 9);
      V v_t_2464 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2461, 3, 9), v_e_2463});
      V v_t_2465 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2460));
      V v_t_2466 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2464; V a_2 = v_x_2460; V a_3 = v_t_2465; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_2466;
      args[0] = v_st_2458;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2457);
    }
  }
  default: return heff_nomatch(v_x1_2456);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam4(V self, V *args) {
  V v_st_2471 = args[0];
  V v_m_2470 = heff_env(self)[0];
  V v_cc_2468 = heff_env(self)[1];
  V v_spec_2469 = heff_env(self)[2];
  V v_v_2467 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2472 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_st_2471}));
  switch (heff_tag_of(v_x1_2472)) {
  case TAG_MkPair: {
    V v_x11_2473 = heff_field(v_x1_2472, 0);
    V v_st_2474 = heff_field(v_x1_2472, 1);
    V v_ru_24x1_2472_24MkPair = heff_take_reuse_n(v_x1_2472, 3ULL, 2);
    switch (heff_tag_of(v_x11_2473)) {
    case TAG_Left: {
      V v_e_2475 = heff_field(v_x11_2473, 0);
      heff_take_n(v_x11_2473, 1ULL, 1);
      heff_drop_rec(v_cc_2468, 9);
      heff_drop(v_spec_2469);
      heff_drop(v_v_2467);
      return heff_tag_at_n(v_ru_24x1_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2475}), v_st_2474});
    }
    case TAG_Right: {
      V v_x_2476 = heff_field(v_x11_2473, 0);
      heff_take_n(v_x11_2473, 1ULL, 1);
      V v_t_2477 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_cc_2468, 3)), heff_dup(heff_rfield(v_cc_2468, 4))});
      V v_t_2478 = (g_heff_2esyntax_2esurface_2especGroups(heff_dup(v_spec_2469), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_m_2479 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_t_2477, heff_dup(g_heff_2esyntax_2esurface_2eemptySpec_get()), v_t_2478));
      V v_x1_2480 = heff_tr(heff_call(v_m_2479, 1, (V[]){v_st_2474}));
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_MkPair: {
        V v_x11_2481 = heff_field(v_x1_2480, 0);
        V v_st_2482 = heff_field(v_x1_2480, 1);
        heff_take_n(v_x1_2480, 3ULL, 2);
        switch (heff_tag_of(v_x11_2481)) {
        case TAG_Left: {
          V v_e_2483 = heff_field(v_x11_2481, 0);
          heff_take_n(v_x11_2481, 1ULL, 1);
          heff_drop_rec(v_cc_2468, 9);
          heff_drop(v_spec_2469);
          heff_drop(v_v_2467);
          heff_drop(v_x_2476);
          return heff_tag_at_n(v_ru_24x1_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2483}), v_st_2482});
        }
        case TAG_Right: {
          V v_x_2484 = heff_field(v_x11_2481, 0);
          heff_take_n(v_x11_2481, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_2472_24MkPair, 2);
          V v_a_2485 = (g_heff_2esyntax_2ecst_2efirstE(v_v_2467));
          V v_t_2486 = (g_heff_2esyntax_2ecst_2elastE(heff_tag_n(TAG_Seg, 3, (V[]){v_v_2467, v_cc_2468, v_spec_2469})));
          V v_e_2487 = heff_get_n(v_t_2486, 4, 9);
          V v_t_2488 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2485, 3, 9), v_e_2487});
          V v_t_2489 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2476));
          V v_t_2490 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2488; V a_2 = v_x_2476; V a_3 = v_t_2489; V a_4 = v_x_2484; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V f_ = v_t_2490;
          args[0] = v_st_2482;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        default: return heff_nomatch(v_x11_2481);
        }
      }
      default: return heff_nomatch(v_x1_2480);
      }
    }
    default: return heff_nomatch(v_x11_2473);
    }
  }
  default: return heff_nomatch(v_x1_2472);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam5(V self, V *args) {
  V v_st_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_st_2496}));
  switch (heff_tag_of(v_x1_2497)) {
  case TAG_MkPair: {
    V v_x11_2498 = heff_field(v_x1_2497, 0);
    V v_st_2499 = heff_field(v_x1_2497, 1);
    V v_ru_24x1_2497_24MkPair = heff_take_reuse_n(v_x1_2497, 3ULL, 2);
    switch (heff_tag_of(v_x11_2498)) {
    case TAG_Left: {
      V v_e_24100 = heff_field(v_x11_2498, 0);
      heff_take_n(v_x11_2498, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24100}), v_st_2499});
    }
    case TAG_Right: {
      V v_x_24101 = heff_field(v_x11_2498, 0);
      heff_take_n(v_x11_2498, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2497_24MkPair, 2);
      V v_a_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24103 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24104 = heff_get_n(v_t_24103, 4, 9);
      V v_t_24105 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24102, 3, 9), v_e_24104});
      V v_t_24106 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24101));
      V v_t_24107 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24105; V a_2 = v_x_24101; V a_3 = v_t_24106; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24107;
      args[0] = v_st_2499;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2498);
    }
  }
  default: return heff_nomatch(v_x1_2497);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam6(V self, V *args) {
  V v_st_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24116 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_st_24115}));
  switch (heff_tag_of(v_x1_24116)) {
  case TAG_MkPair: {
    V v_x11_24117 = heff_field(v_x1_24116, 0);
    V v_st_24118 = heff_field(v_x1_24116, 1);
    V v_ru_24x1_24116_24MkPair = heff_take_reuse_n(v_x1_24116, 3ULL, 2);
    switch (heff_tag_of(v_x11_24117)) {
    case TAG_Left: {
      V v_e_24119 = heff_field(v_x11_24117, 0);
      heff_take_n(v_x11_24117, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24119}), v_st_24118});
    }
    case TAG_Right: {
      V v_x_24120 = heff_field(v_x11_24117, 0);
      heff_take_n(v_x11_24117, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24116_24MkPair, 2);
      V v_a_24121 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24122 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24123 = heff_get_n(v_t_24122, 4, 9);
      V v_t_24124 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24121, 3, 9), v_e_24123});
      V v_t_24125 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24120));
      V v_t_24126 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24124; V a_2 = v_x_24120; V a_3 = v_t_24125; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24126;
      args[0] = v_st_24118;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24117);
    }
  }
  default: return heff_nomatch(v_x1_24116);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam7(V self, V *args) {
  V v_st_24131 = args[0];
  V v_m_24130 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24132 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_st_24131}));
  switch (heff_tag_of(v_x1_24132)) {
  case TAG_MkPair: {
    V v_x11_24133 = heff_field(v_x1_24132, 0);
    V v_st_24134 = heff_field(v_x1_24132, 1);
    V v_ru_24x1_24132_24MkPair = heff_take_reuse_n(v_x1_24132, 3ULL, 2);
    switch (heff_tag_of(v_x11_24133)) {
    case TAG_Left: {
      V v_e_24135 = heff_field(v_x11_24133, 0);
      heff_take_n(v_x11_24133, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24135}), v_st_24134});
    }
    case TAG_Right: {
      V v_x_24136 = heff_field(v_x11_24133, 0);
      heff_take_n(v_x11_24133, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24MkPair, 2);
      V v_a_24137 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24138 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24139 = heff_get_n(v_t_24138, 4, 9);
      V v_t_24140 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24137, 3, 9), v_e_24139});
      V v_t_24141 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24136));
      V v_t_24142 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24140; V a_2 = v_x_24136; V a_3 = v_t_24141; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24142;
      args[0] = v_st_24134;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24133);
    }
  }
  default: return heff_nomatch(v_x1_24132);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam8(V self, V *args) {
  V v_st_24149 = args[0];
  V v_m_24148 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24150 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_st_24149}));
  switch (heff_tag_of(v_x1_24150)) {
  case TAG_MkPair: {
    V v_x11_24151 = heff_field(v_x1_24150, 0);
    V v_st_24152 = heff_field(v_x1_24150, 1);
    V v_ru_24x1_24150_24MkPair = heff_take_reuse_n(v_x1_24150, 3ULL, 2);
    switch (heff_tag_of(v_x11_24151)) {
    case TAG_Left: {
      V v_e_24153 = heff_field(v_x11_24151, 0);
      heff_take_n(v_x11_24151, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24150_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24153}), v_st_24152});
    }
    case TAG_Right: {
      V v_x_24154 = heff_field(v_x11_24151, 0);
      heff_take_n(v_x11_24151, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24150_24MkPair, 2);
      V v_a_24155 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24156 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24157 = heff_get_n(v_t_24156, 4, 9);
      V v_t_24158 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24155, 3, 9), v_e_24157});
      V v_t_24159 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24154));
      V v_t_24160 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24158; V a_2 = v_x_24154; V a_3 = v_t_24159; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24160;
      args[0] = v_st_24152;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24151);
    }
  }
  default: return heff_nomatch(v_x1_24150);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam9(V self, V *args) {
  V v_st_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24166 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_st_24165}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_MkPair: {
    V v_x11_24167 = heff_field(v_x1_24166, 0);
    V v_st_24168 = heff_field(v_x1_24166, 1);
    V v_ru_24x1_24166_24MkPair = heff_take_reuse_n(v_x1_24166, 3ULL, 2);
    switch (heff_tag_of(v_x11_24167)) {
    case TAG_Left: {
      V v_e_24169 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24169}), v_st_24168});
    }
    case TAG_Right: {
      V v_x_24170 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24MkPair, 2);
      V v_a_24171 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24172 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24173 = heff_get_n(v_t_24172, 4, 9);
      V v_t_24174 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24171, 3, 9), v_e_24173});
      V v_t_24175 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24170));
      V v_t_24176 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24174; V a_2 = v_x_24170; V a_3 = v_t_24175; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24176;
      args[0] = v_st_24168;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24167);
    }
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam10(V self, V *args) {
  V v_st_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24182 = heff_tr(heff_call(v_m_24180, 1, (V[]){v_st_24181}));
  switch (heff_tag_of(v_x1_24182)) {
  case TAG_MkPair: {
    V v_x11_24183 = heff_field(v_x1_24182, 0);
    V v_st_24184 = heff_field(v_x1_24182, 1);
    V v_ru_24x1_24182_24MkPair = heff_take_reuse_n(v_x1_24182, 3ULL, 2);
    switch (heff_tag_of(v_x11_24183)) {
    case TAG_Left: {
      V v_e_24185 = heff_field(v_x11_24183, 0);
      heff_take_n(v_x11_24183, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24185}), v_st_24184});
    }
    case TAG_Right: {
      V v_x_24186 = heff_field(v_x11_24183, 0);
      heff_take_n(v_x11_24183, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24182_24MkPair, 2);
      V v_a_24187 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24188 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24189 = heff_get_n(v_t_24188, 4, 9);
      V v_t_24190 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24187, 3, 9), v_e_24189});
      V v_t_24191 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24186));
      V v_t_24192 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24190; V a_2 = v_x_24186; V a_3 = v_t_24191; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24192;
      args[0] = v_st_24184;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24183);
    }
  }
  default: return heff_nomatch(v_x1_24182);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam11(V self, V *args) {
  V v_st_24199 = args[0];
  V v_m_24198 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24200 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_st_24199}));
  switch (heff_tag_of(v_x1_24200)) {
  case TAG_MkPair: {
    V v_x11_24201 = heff_field(v_x1_24200, 0);
    V v_st_24202 = heff_field(v_x1_24200, 1);
    V v_ru_24x1_24200_24MkPair = heff_take_reuse_n(v_x1_24200, 3ULL, 2);
    switch (heff_tag_of(v_x11_24201)) {
    case TAG_Left: {
      V v_e_24203 = heff_field(v_x11_24201, 0);
      heff_take_n(v_x11_24201, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24203}), v_st_24202});
    }
    case TAG_Right: {
      V v_x_24204 = heff_field(v_x11_24201, 0);
      heff_take_n(v_x11_24201, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24200_24MkPair, 2);
      V v_a_24205 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24206 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24207 = heff_get_n(v_t_24206, 4, 9);
      V v_t_24208 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24205, 3, 9), v_e_24207});
      V v_t_24209 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24204));
      V v_t_24210 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24208; V a_2 = v_x_24204; V a_3 = v_t_24209; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24210;
      args[0] = v_st_24202;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24201);
    }
  }
  default: return heff_nomatch(v_x1_24200);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam12(V self, V *args) {
  V v_st_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24215 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_st_24214}));
  switch (heff_tag_of(v_x1_24215)) {
  case TAG_MkPair: {
    V v_x11_24216 = heff_field(v_x1_24215, 0);
    V v_st_24217 = heff_field(v_x1_24215, 1);
    V v_ru_24x1_24215_24MkPair = heff_take_reuse_n(v_x1_24215, 3ULL, 2);
    switch (heff_tag_of(v_x11_24216)) {
    case TAG_Left: {
      V v_e_24218 = heff_field(v_x11_24216, 0);
      heff_take_n(v_x11_24216, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24215_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24218}), v_st_24217});
    }
    case TAG_Right: {
      V v_x_24219 = heff_field(v_x11_24216, 0);
      heff_take_n(v_x11_24216, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24215_24MkPair, 2);
      V v_a_24220 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24221 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24222 = heff_get_n(v_t_24221, 4, 9);
      V v_t_24223 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24220, 3, 9), v_e_24222});
      V v_t_24224 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24219));
      V v_t_24225 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24223; V a_2 = v_x_24219; V a_3 = v_t_24224; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24225;
      args[0] = v_st_24217;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24216);
    }
  }
  default: return heff_nomatch(v_x1_24215);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam13(V self, V *args) {
  V v_st_24229 = args[0];
  V v_m_24228 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24230 = heff_tr(heff_call(v_m_24228, 1, (V[]){v_st_24229}));
  switch (heff_tag_of(v_x1_24230)) {
  case TAG_MkPair: {
    V v_x11_24231 = heff_field(v_x1_24230, 0);
    V v_st_24232 = heff_field(v_x1_24230, 1);
    V v_ru_24x1_24230_24MkPair = heff_take_reuse_n(v_x1_24230, 3ULL, 2);
    switch (heff_tag_of(v_x11_24231)) {
    case TAG_Left: {
      V v_e_24233 = heff_field(v_x11_24231, 0);
      heff_take_n(v_x11_24231, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24233}), v_st_24232});
    }
    case TAG_Right: {
      V v_x_24234 = heff_field(v_x11_24231, 0);
      heff_take_n(v_x11_24231, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24230_24MkPair, 2);
      V v_a_24235 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24236 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24237 = heff_get_n(v_t_24236, 4, 9);
      V v_t_24238 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24235, 3, 9), v_e_24237});
      V v_t_24239 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24234));
      V v_t_24240 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24238; V a_2 = v_x_24234; V a_3 = v_t_24239; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24240;
      args[0] = v_st_24232;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24231);
    }
  }
  default: return heff_nomatch(v_x1_24230);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam14(V self, V *args) {
  V v_st_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24245 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_st_24244}));
  switch (heff_tag_of(v_x1_24245)) {
  case TAG_MkPair: {
    V v_x11_24246 = heff_field(v_x1_24245, 0);
    V v_st_24247 = heff_field(v_x1_24245, 1);
    V v_ru_24x1_24245_24MkPair = heff_take_reuse_n(v_x1_24245, 3ULL, 2);
    switch (heff_tag_of(v_x11_24246)) {
    case TAG_Left: {
      V v_e_24248 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24248}), v_st_24247});
    }
    case TAG_Right: {
      V v_x_24249 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24245_24MkPair, 2);
      V v_a_24250 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24251 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24252 = heff_get_n(v_t_24251, 4, 9);
      V v_t_24253 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24250, 3, 9), v_e_24252});
      V v_t_24254 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24249));
      V v_t_24255 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24253; V a_2 = v_x_24249; V a_3 = v_t_24254; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24255;
      args[0] = v_st_24247;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24246);
    }
  }
  default: return heff_nomatch(v_x1_24245);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam15(V self, V *args) {
  V v_st_24259 = args[0];
  V v_m_24258 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24260 = heff_tr(heff_call(v_m_24258, 1, (V[]){v_st_24259}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_MkPair: {
    V v_x11_24261 = heff_field(v_x1_24260, 0);
    V v_st_24262 = heff_field(v_x1_24260, 1);
    V v_ru_24x1_24260_24MkPair = heff_take_reuse_n(v_x1_24260, 3ULL, 2);
    switch (heff_tag_of(v_x11_24261)) {
    case TAG_Left: {
      V v_e_24263 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24263}), v_st_24262});
    }
    case TAG_Right: {
      V v_x_24264 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24MkPair, 2);
      V v_a_24265 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24266 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24267 = heff_get_n(v_t_24266, 4, 9);
      V v_t_24268 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24265, 3, 9), v_e_24267});
      V v_t_24269 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24264));
      V v_t_24270 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24268; V a_2 = v_x_24264; V a_3 = v_t_24269; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24270;
      args[0] = v_st_24262;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24261);
    }
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam16(V self, V *args) {
  V v_st_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24276 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_st_24275}));
  switch (heff_tag_of(v_x1_24276)) {
  case TAG_MkPair: {
    V v_x11_24277 = heff_field(v_x1_24276, 0);
    V v_st_24278 = heff_field(v_x1_24276, 1);
    V v_ru_24x1_24276_24MkPair = heff_take_reuse_n(v_x1_24276, 3ULL, 2);
    switch (heff_tag_of(v_x11_24277)) {
    case TAG_Left: {
      V v_e_24279 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24279}), v_st_24278});
    }
    case TAG_Right: {
      V v_x_24280 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24276_24MkPair, 2);
      V v_a_24281 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24282 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24283 = heff_get_n(v_t_24282, 4, 9);
      V v_t_24284 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24281, 3, 9), v_e_24283});
      V v_t_24285 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24280));
      V v_t_24286 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24284; V a_2 = v_x_24280; V a_3 = v_t_24285; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24286;
      args[0] = v_st_24278;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24277);
    }
  }
  default: return heff_nomatch(v_x1_24276);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam17(V self, V *args) {
  V v_st_24290 = args[0];
  V v_m_24289 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24291 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_st_24290}));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_MkPair: {
    V v_x11_24292 = heff_field(v_x1_24291, 0);
    V v_st_24293 = heff_field(v_x1_24291, 1);
    V v_ru_24x1_24291_24MkPair = heff_take_reuse_n(v_x1_24291, 3ULL, 2);
    switch (heff_tag_of(v_x11_24292)) {
    case TAG_Left: {
      V v_e_24294 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24294}), v_st_24293});
    }
    case TAG_Right: {
      V v_x_24295 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24291_24MkPair, 2);
      V v_a_24296 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24297 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24298 = heff_get_n(v_t_24297, 4, 9);
      V v_t_24299 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24296, 3, 9), v_e_24298});
      V v_t_24300 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24295));
      V v_t_24301 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24299; V a_2 = v_x_24295; V a_3 = v_t_24300; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24301;
      args[0] = v_st_24293;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24292);
    }
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam18(V self, V *args) {
  V v_st_24305 = args[0];
  V v_m_24304 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24306 = heff_tr(heff_call(v_m_24304, 1, (V[]){v_st_24305}));
  switch (heff_tag_of(v_x1_24306)) {
  case TAG_MkPair: {
    V v_x11_24307 = heff_field(v_x1_24306, 0);
    V v_st_24308 = heff_field(v_x1_24306, 1);
    V v_ru_24x1_24306_24MkPair = heff_take_reuse_n(v_x1_24306, 3ULL, 2);
    switch (heff_tag_of(v_x11_24307)) {
    case TAG_Left: {
      V v_e_24309 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24309}), v_st_24308});
    }
    case TAG_Right: {
      V v_x_24310 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24306_24MkPair, 2);
      V v_a_24311 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24312 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24313 = heff_get_n(v_t_24312, 4, 9);
      V v_t_24314 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24311, 3, 9), v_e_24313});
      V v_t_24315 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24310));
      V v_t_24316 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24314; V a_2 = v_x_24310; V a_3 = v_t_24315; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24316;
      args[0] = v_st_24308;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24307);
    }
  }
  default: return heff_nomatch(v_x1_24306);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam19(V self, V *args) {
  V v_st_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_st_24321}));
  switch (heff_tag_of(v_x1_24322)) {
  case TAG_MkPair: {
    V v_x11_24323 = heff_field(v_x1_24322, 0);
    V v_st_24324 = heff_field(v_x1_24322, 1);
    V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
    switch (heff_tag_of(v_x11_24323)) {
    case TAG_Left: {
      V v_e_24325 = heff_field(v_x11_24323, 0);
      heff_take_n(v_x11_24323, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
    }
    case TAG_Right: {
      V v_x_24326 = heff_field(v_x11_24323, 0);
      heff_take_n(v_x11_24323, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24322_24MkPair, 2);
      V v_a_24327 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24328 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24329 = heff_get_n(v_t_24328, 4, 9);
      V v_t_24330 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24327, 3, 9), v_e_24329});
      V v_t_24331 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24326));
      V v_t_24332 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24330; V a_2 = v_x_24326; V a_3 = v_t_24331; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24332;
      args[0] = v_st_24324;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24323);
    }
  }
  default: return heff_nomatch(v_x1_24322);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam20(V self, V *args) {
  V v_st_24335 = args[0];
  V v_m_24334 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24336 = heff_tr(heff_call(v_m_24334, 1, (V[]){v_st_24335}));
  switch (heff_tag_of(v_x1_24336)) {
  case TAG_MkPair: {
    V v_x11_24337 = heff_field(v_x1_24336, 0);
    V v_st_24338 = heff_field(v_x1_24336, 1);
    V v_ru_24x1_24336_24MkPair = heff_take_reuse_n(v_x1_24336, 3ULL, 2);
    switch (heff_tag_of(v_x11_24337)) {
    case TAG_Left: {
      V v_e_24339 = heff_field(v_x11_24337, 0);
      heff_take_n(v_x11_24337, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24339}), v_st_24338});
    }
    case TAG_Right: {
      V v_x_24340 = heff_field(v_x11_24337, 0);
      heff_take_n(v_x11_24337, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24336_24MkPair, 2);
      V v_a_24341 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24342 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24343 = heff_get_n(v_t_24342, 4, 9);
      V v_t_24344 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24341, 3, 9), v_e_24343});
      V v_t_24345 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24340));
      V v_t_24346 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24344; V a_2 = v_x_24340; V a_3 = v_t_24345; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24346;
      args[0] = v_st_24338;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24337);
    }
  }
  default: return heff_nomatch(v_x1_24336);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam21(V self, V *args) {
  V v_st_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24352 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_st_24351}));
  switch (heff_tag_of(v_x1_24352)) {
  case TAG_MkPair: {
    V v_x11_24353 = heff_field(v_x1_24352, 0);
    V v_st_24354 = heff_field(v_x1_24352, 1);
    V v_ru_24x1_24352_24MkPair = heff_take_reuse_n(v_x1_24352, 3ULL, 2);
    switch (heff_tag_of(v_x11_24353)) {
    case TAG_Left: {
      V v_e_24355 = heff_field(v_x11_24353, 0);
      heff_take_n(v_x11_24353, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24352_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24355}), v_st_24354});
    }
    case TAG_Right: {
      V v_x_24356 = heff_field(v_x11_24353, 0);
      heff_take_n(v_x11_24353, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24352_24MkPair, 2);
      V v_a_24357 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24358 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24359 = heff_get_n(v_t_24358, 4, 9);
      V v_t_24360 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24357, 3, 9), v_e_24359});
      V v_t_24361 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24356));
      V v_t_24362 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24360; V a_2 = v_x_24356; V a_3 = v_t_24361; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24362;
      args[0] = v_st_24354;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24353);
    }
  }
  default: return heff_nomatch(v_x1_24352);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam22(V self, V *args) {
  V v_st_24369 = args[0];
  V v_m_24368 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24370 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_st_24369}));
  switch (heff_tag_of(v_x1_24370)) {
  case TAG_MkPair: {
    V v_x11_24371 = heff_field(v_x1_24370, 0);
    V v_st_24372 = heff_field(v_x1_24370, 1);
    V v_ru_24x1_24370_24MkPair = heff_take_reuse_n(v_x1_24370, 3ULL, 2);
    switch (heff_tag_of(v_x11_24371)) {
    case TAG_Left: {
      V v_e_24373 = heff_field(v_x11_24371, 0);
      heff_take_n(v_x11_24371, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24370_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24373}), v_st_24372});
    }
    case TAG_Right: {
      V v_x_24374 = heff_field(v_x11_24371, 0);
      heff_take_n(v_x11_24371, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24370_24MkPair, 2);
      V v_a_24375 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24376 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24377 = heff_get_n(v_t_24376, 4, 9);
      V v_t_24378 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24375, 3, 9), v_e_24377});
      V v_t_24379 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24374));
      V v_t_24380 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24378; V a_2 = v_x_24374; V a_3 = v_t_24379; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24380;
      args[0] = v_st_24372;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24371);
    }
  }
  default: return heff_nomatch(v_x1_24370);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam23(V self, V *args) {
  V v_st_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_st_24386}));
  switch (heff_tag_of(v_x1_24387)) {
  case TAG_MkPair: {
    V v_x11_24388 = heff_field(v_x1_24387, 0);
    V v_st_24389 = heff_field(v_x1_24387, 1);
    V v_ru_24x1_24387_24MkPair = heff_take_reuse_n(v_x1_24387, 3ULL, 2);
    switch (heff_tag_of(v_x11_24388)) {
    case TAG_Left: {
      V v_e_24390 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24390}), v_st_24389});
    }
    case TAG_Right: {
      V v_x_24391 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24387_24MkPair, 2);
      V v_a_24392 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24393 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24394 = heff_get_n(v_t_24393, 4, 9);
      V v_t_24395 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24392, 3, 9), v_e_24394});
      V v_t_24396 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24391));
      V v_t_24397 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24395; V a_2 = v_x_24391; V a_3 = v_t_24396; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24397;
      args[0] = v_st_24389;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24388);
    }
  }
  default: return heff_nomatch(v_x1_24387);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam24(V self, V *args) {
  V v_st_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_st_24403}));
  switch (heff_tag_of(v_x1_24404)) {
  case TAG_MkPair: {
    V v_x11_24405 = heff_field(v_x1_24404, 0);
    V v_st_24406 = heff_field(v_x1_24404, 1);
    V v_ru_24x1_24404_24MkPair = heff_take_reuse_n(v_x1_24404, 3ULL, 2);
    switch (heff_tag_of(v_x11_24405)) {
    case TAG_Left: {
      V v_e_24407 = heff_field(v_x11_24405, 0);
      heff_take_n(v_x11_24405, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24407}), v_st_24406});
    }
    case TAG_Right: {
      V v_x_24408 = heff_field(v_x11_24405, 0);
      heff_take_n(v_x11_24405, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24404_24MkPair, 2);
      V v_a_24409 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24410 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24411 = heff_get_n(v_t_24410, 4, 9);
      V v_t_24412 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24409, 3, 9), v_e_24411});
      V v_t_24413 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24408));
      V v_t_24414 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24412; V a_2 = v_x_24408; V a_3 = v_t_24413; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24414;
      args[0] = v_st_24406;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24405);
    }
  }
  default: return heff_nomatch(v_x1_24404);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam25(V self, V *args) {
  V v_st_24419 = args[0];
  V v_m_24418 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24420 = heff_tr(heff_call(v_m_24418, 1, (V[]){v_st_24419}));
  switch (heff_tag_of(v_x1_24420)) {
  case TAG_MkPair: {
    V v_x11_24421 = heff_field(v_x1_24420, 0);
    V v_st_24422 = heff_field(v_x1_24420, 1);
    V v_ru_24x1_24420_24MkPair = heff_take_reuse_n(v_x1_24420, 3ULL, 2);
    switch (heff_tag_of(v_x11_24421)) {
    case TAG_Left: {
      V v_e_24423 = heff_field(v_x11_24421, 0);
      heff_take_n(v_x11_24421, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24423}), v_st_24422});
    }
    case TAG_Right: {
      V v_x_24424 = heff_field(v_x11_24421, 0);
      heff_take_n(v_x11_24421, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24MkPair, 2);
      V v_a_24425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24426 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24427 = heff_get_n(v_t_24426, 4, 9);
      V v_t_24428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24425, 3, 9), v_e_24427});
      V v_t_24429 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24424));
      V v_t_24430 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24428; V a_2 = v_x_24424; V a_3 = v_t_24429; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24430;
      args[0] = v_st_24422;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24421);
    }
  }
  default: return heff_nomatch(v_x1_24420);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam26(V self, V *args) {
  V v_st_24438 = args[0];
  V v_m_24437 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24439 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_st_24438}));
  switch (heff_tag_of(v_x1_24439)) {
  case TAG_MkPair: {
    V v_x11_24440 = heff_field(v_x1_24439, 0);
    V v_st_24441 = heff_field(v_x1_24439, 1);
    V v_ru_24x1_24439_24MkPair = heff_take_reuse_n(v_x1_24439, 3ULL, 2);
    switch (heff_tag_of(v_x11_24440)) {
    case TAG_Left: {
      V v_e_24442 = heff_field(v_x11_24440, 0);
      heff_take_n(v_x11_24440, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24442}), v_st_24441});
    }
    case TAG_Right: {
      V v_x_24443 = heff_field(v_x11_24440, 0);
      heff_take_n(v_x11_24440, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24439_24MkPair, 2);
      V v_a_24444 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24445 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24446 = heff_get_n(v_t_24445, 4, 9);
      V v_t_24447 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24444, 3, 9), v_e_24446});
      V v_t_24448 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24443));
      V v_t_24449 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24447; V a_2 = v_x_24443; V a_3 = v_t_24448; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24449;
      args[0] = v_st_24441;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24440);
    }
  }
  default: return heff_nomatch(v_x1_24439);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam27(V self, V *args) {
  V v_st_24453 = args[0];
  V v_m_24452 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24454 = heff_tr(heff_call(v_m_24452, 1, (V[]){v_st_24453}));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24454_24MkPair, 2);
      V v_a_24459 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24460 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24461 = heff_get_n(v_t_24460, 4, 9);
      V v_t_24462 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24459, 3, 9), v_e_24461});
      V v_t_24463 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24458));
      V v_t_24464 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24462; V a_2 = v_x_24458; V a_3 = v_t_24463; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24464;
      args[0] = v_st_24456;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam28(V self, V *args) {
  V v_st_24469 = args[0];
  V v_m_24468 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24470 = heff_tr(heff_call(v_m_24468, 1, (V[]){v_st_24469}));
  switch (heff_tag_of(v_x1_24470)) {
  case TAG_MkPair: {
    V v_x11_24471 = heff_field(v_x1_24470, 0);
    V v_st_24472 = heff_field(v_x1_24470, 1);
    V v_ru_24x1_24470_24MkPair = heff_take_reuse_n(v_x1_24470, 3ULL, 2);
    switch (heff_tag_of(v_x11_24471)) {
    case TAG_Left: {
      V v_e_24473 = heff_field(v_x11_24471, 0);
      heff_take_n(v_x11_24471, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24473}), v_st_24472});
    }
    case TAG_Right: {
      V v_x_24474 = heff_field(v_x11_24471, 0);
      heff_take_n(v_x11_24471, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24MkPair, 2);
      V v_a_24475 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24476 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24477 = heff_get_n(v_t_24476, 4, 9);
      V v_t_24478 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24475, 3, 9), v_e_24477});
      V v_t_24479 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24474));
      V v_t_24480 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24478; V a_2 = v_x_24474; V a_3 = v_t_24479; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24480;
      args[0] = v_st_24472;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24471);
    }
  }
  default: return heff_nomatch(v_x1_24470);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam29(V self, V *args) {
  V v_st_24488 = args[0];
  V v_m_24487 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24489 = heff_tr(heff_call(v_m_24487, 1, (V[]){v_st_24488}));
  switch (heff_tag_of(v_x1_24489)) {
  case TAG_MkPair: {
    V v_x11_24490 = heff_field(v_x1_24489, 0);
    V v_st_24491 = heff_field(v_x1_24489, 1);
    V v_ru_24x1_24489_24MkPair = heff_take_reuse_n(v_x1_24489, 3ULL, 2);
    switch (heff_tag_of(v_x11_24490)) {
    case TAG_Left: {
      V v_e_24492 = heff_field(v_x11_24490, 0);
      heff_take_n(v_x11_24490, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24492}), v_st_24491});
    }
    case TAG_Right: {
      V v_x_24493 = heff_field(v_x11_24490, 0);
      heff_take_n(v_x11_24490, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24489_24MkPair, 2);
      V v_a_24494 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24495 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24496 = heff_get_n(v_t_24495, 4, 9);
      V v_t_24497 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24494, 3, 9), v_e_24496});
      V v_t_24498 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24493));
      V v_t_24499 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24497; V a_2 = v_x_24493; V a_3 = v_t_24498; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V f_ = v_t_24499;
      args[0] = v_st_24491;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_24490);
    }
  }
  default: return heff_nomatch(v_x1_24489);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str0, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str2, 3, "int");
Clo g_heff_2esyntax_2esurface_2esegmentValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentValue_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esegmentValue(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PCon: {
    return NTAG(TAG_False);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_243, 0))}));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str0), NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str2), v_t_245})});
    return ({ V a_0 = v_t_244; V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_246, 2); r_; });
  }
  case TAG_PParen: {
    V v_p2_248 = heff_field(v_p_240, 1);
    V t_0 = v_p2_248;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_PList: {
    return NTAG(TAG_False);
  }
  case TAG_POp: {
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    return NTAG(TAG_False);
  }
  case TAG_PField: {
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    return NTAG(TAG_False);
  }
  case TAG_PSeg: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str1, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamOf(V v_r_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2ebracedOne(v_e_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam0, 1, 2, (V[]){v_m_243, v_e_241});
  }
  case TAG_Just: {
    V v_f_2420 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_m_2421 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_2420));
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam2, 1, 2, (V[]){v_m_2421, v_e_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2413});
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
      V v_m_2414;
      if (heff_strEq_c(heff_get_n(v_t_2410, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str0))) {
        V v_t_2412 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_249));
        v_m_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2412}));
      } else {
        v_m_2414 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam1, 1, 1, (V[]){v_x_249});
      }
      V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_247}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
          return ({ V a_0 = v_x_2419; V a_1 = v_st_2417; V r_ = (g_heff_2esyntax_2esurface_2eparamOf(a_0, a_1)); heff_drop(v_x_2419); r_; });
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args) {
  V v_st_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_st_2422}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_MkPair: {
    V v_x11_2424 = heff_field(v_x1_2423, 0);
    V v_st_2425 = heff_field(v_x1_2423, 1);
    V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_e_2426 = heff_field(v_x11_2424, 0);
      heff_take_n(v_x11_2424, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2426}), v_st_2425});
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_x11_2424, 0);
      heff_take_n(v_x11_2424, 1ULL, 1);
      V v_t_2428 = (g_heff_2esyntax_2esurface_2enameAnn(v_x_2427));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_Nothing: {
        heff_drop(v_e_241);
        V v_t_2431;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str1), v_t_2431, NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2425});
      }
      case TAG_Just: {
        V v_q_2433 = heff_field(v_t_2428, 0);
        heff_take_n(v_t_2428, 1ULL, 1);
        heff_drop(v_x_2427);
        V v_t_2434 = heff_tag_n(TAG_ImplicitParam, 3, (V[]){heff_take_field(v_q_2433, 0), heff_take_field(v_q_2433, 1), heff_get_n(v_q_2433, 2, 3)});
        V v_a_2435 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
        V v_b_2436 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
        V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2435, 3, 9), heff_get_n(v_b_2436, 4, 9)});
        V v_x_2438 = heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_t_2437});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_st_2425});
      }
      default: return heff_nomatch(v_t_2428);
      }
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_245 = (g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(v_x_243));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1, 1, 2, (V[]){v_m_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(a[0]);
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_m_2412 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_xs_244));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417})});
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V v_kw_240, V v_x_241, V v_ty_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_242), v_st_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop_rec(v_x_241, 9);
      heff_drop(v_ty_242);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 3), heff_take_field(v_x_241, 4)});
      V v_t_2410 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){heff_get_n(v_x_241, 1, 9), v_t_249, v_x_248});
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_ty_242));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2412});
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2413})});
      V v_x_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2415}), v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2elineColFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elineColFrom_entry, 4, 0};

V g_heff_2esyntax_2esurface_2elineColFrom(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str0), heff_dup(v_src_240), heff_dup(v_start_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
    V v_t_246 = heff_intShow(heff_intAdd(v_t_245, MK_INT(1LL)));
    return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str1), v_t_246));
  }
  case TAG_Just: {
    V v_nl_247 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    if (heff_intLt_c(heff_dup(v_nl_247), heff_dup(v_i_241))) {
      heff_drop(v_start_243);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_247, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    } else {
      heff_drop(v_nl_247);
      V v_t_249 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
      V v_t_2410 = heff_intShow(heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str2), v_t_2410));
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elineColFrom(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2enoKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enoKnown_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enoKnown(V v_x_240) {
top: ;
  return NTAG(TAG_False);
}
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enoKnown(a0); heff_drop(a0); return r;
}