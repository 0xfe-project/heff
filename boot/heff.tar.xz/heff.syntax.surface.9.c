// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclEquations 25755
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PiAnon 44344
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_fix 310927
#define LBL_kind 9787483
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edigitsVal(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edigitsVal_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
V g_heff_2esyntax_2esurface_2eemptySpec_get(void);
V g_heff_2esyntax_2esurface_2efitsIn(V, V, V, V);
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efitsIn_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2emutualBody(V, V, V);
V g_heff_2esyntax_2esurface_2emutualBody_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualBody_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2emap_24s892909862x1245535974(V, V, V, V);
V g_list_2emap_24s892909862x1245535974_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str0, 2, "0x");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str1, 2, "0X");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str2, 2, "0b");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str3, 2, "0B");
Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emagnitudeOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emagnitudeOf(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  V v_t_242 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6);
  if ((heff_strEq_c_lent(v_t_242, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str0), 2) || heff_strEq_c(heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str1)))) {
    heff_drop(v_t_242);
    return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(16LL), v_s_240, heff_box_word((v_i_241 + ((int64_t)2ULL))), heff_strLength_lent(v_s_240, 0), MK_INT(0LL)));
  } else {
    heff_drop(v_t_242);
    V v_t_243 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6);
    if ((heff_strEq_c_lent(v_t_243, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str2), 2) || heff_strEq_c(heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str3)))) {
      heff_drop(v_t_243);
      return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), v_s_240, heff_box_word((v_i_241 + ((int64_t)2ULL))), heff_strLength_lent(v_s_240, 0), MK_INT(0LL)));
    } else {
      heff_drop(v_t_243);
      return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(10LL), v_s_240, heff_box_word(v_i_241), heff_strLength_lent(v_s_240, 0), MK_INT(0LL)));
    }
  }
}
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2emagnitudeOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eboundBy(V v_pv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_243 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_243);
  }
  case TAG_PAtom: {
    V v_t_245 = heff_field(v_x2_241, 0);
    V v_kind_246 = heff_dup(heff_rfield(v_t_245, 0));
    V v_text_247 = heff_dup(heff_rfield(v_t_245, 1));
    if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2esurface_2eboundBy_str0), 2) && !heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2esurface_2eboundBy_str1), 2))) {
      heff_drop(v_kind_246);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_text_247, NTAG(TAG_Nil)});
    } else {
      if (heff_strEq_c(v_kind_246, ((V)&g_heff_2esyntax_2esurface_2eboundBy_str2))) {
        V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_247)}));
        V v_t_249 = (g_list_2eany(v_t_248, v_pv_240));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          return heff_tag_n(TAG_Cons, 2, (V[]){v_text_247, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_text_247);
          heff_drop(v_t_249);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_text_247);
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2411 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2411;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2414 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2414);
  }
  case TAG_POp: {
    V v_l_2418 = heff_field(v_x2_241, 0);
    V v_q_2420 = heff_field(v_x2_241, 2);
    V v_t_2421 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2418));
    V v_t_2422 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2420));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2421, v_t_2422);
  }
  case TAG_PRec: {
    V v_fs_2424 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2424);
  }
  case TAG_PField: {
    V v_q_2430 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2430;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2431 = heff_field(v_x2_241, 0);
    V v_q_2433 = heff_field(v_x2_241, 2);
    V v_cell_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2431, 1)), heff_hole()});
    V v_u_2435 = (g_heff_2esyntax_2esurface_2eboundBy_24dps(v_pv_240, v_q_2433, heff_dup(v_cell_2434)));
    heff_drop(v_u_2435);
    return v_cell_2434;
  }
  case TAG_PSeg: {
    V v_q_2436 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2436;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args) {
  V v_q_244 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_244); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args) {
  V v_q_2417 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2417; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2417); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args) {
  V v_q_2427 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2427; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2427); r_; });
}
Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisNameE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str77, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str78, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str79, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str81, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str82, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str83, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str84, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str85, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str86, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str87, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str88, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str89, 12, "unexpected `");

HeffT2 g_heff_2esyntax_2esurface_2eletL_24cpr(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    heff_drop(v_r_240);
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_245 = heff_take_field(v_t_244, 3);
    V v_end_246 = heff_get_n(v_t_244, 4, 9);
    V v_t_247 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_248 = heff_strAppend(heff_get_n(v_t_247, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str0));
    V v_msg_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str1), v_t_248);
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_249, heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246}), NTAG(TAG_Nothing)});
    V v_f_2411 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2410});
    return ((HeffT2){{v_f_2411, v_z_242}});
  }
  case TAG_EParen: {
    heff_drop(v_r_240);
    V v_t_2415 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2416 = heff_take_field(v_t_2415, 3);
    V v_end_2417 = heff_get_n(v_t_2415, 4, 9);
    V v_t_2418 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2419 = heff_strAppend(heff_get_n(v_t_2418, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str2));
    V v_msg_2420 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str3), v_t_2419);
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2420, heff_rec_n(2, shape_start__end, (V[]){v_start_2416, v_end_2417}), NTAG(TAG_Nothing)});
    V v_f_2422 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
    return ((HeffT2){{v_f_2422, v_z_242}});
  }
  case TAG_Named: {
    heff_drop(v_r_240);
    V v_t_2428 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2429 = heff_take_field(v_t_2428, 3);
    V v_end_2430 = heff_get_n(v_t_2428, 4, 9);
    V v_t_2431 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_2432 = heff_strAppend(heff_get_n(v_t_2431, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str4));
    V v_msg_2433 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str5), v_t_2432);
    V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2433, heff_rec_n(2, shape_start__end, (V[]){v_start_2429, v_end_2430}), NTAG(TAG_Nothing)});
    V v_f_2435 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2434});
    return ((HeffT2){{v_f_2435, v_z_242}});
  }
  case TAG_Tup: {
    heff_drop(v_r_240);
    V v_t_2440 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2441 = heff_take_field(v_t_2440, 3);
    V v_end_2442 = heff_get_n(v_t_2440, 4, 9);
    V v_t_2443 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2444 = heff_strAppend(heff_get_n(v_t_2443, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str6));
    V v_msg_2445 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str7), v_t_2444);
    V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2445, heff_rec_n(2, shape_start__end, (V[]){v_start_2441, v_end_2442}), NTAG(TAG_Nothing)});
    V v_f_2447 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2446});
    return ((HeffT2){{v_f_2447, v_z_242}});
  }
  case TAG_Seg: {
    heff_drop(v_r_240);
    V v_t_2451 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2452 = heff_take_field(v_t_2451, 3);
    V v_end_2453 = heff_get_n(v_t_2451, 4, 9);
    V v_t_2454 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2455 = heff_strAppend(heff_get_n(v_t_2454, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str8));
    V v_msg_2456 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str9), v_t_2455);
    V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2456, heff_rec_n(2, shape_start__end, (V[]){v_start_2452, v_end_2453}), NTAG(TAG_Nothing)});
    V v_f_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2457});
    return ((HeffT2){{v_f_2458, v_z_242}});
  }
  case TAG_Braces: {
    heff_drop(v_r_240);
    V v_t_2463 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2464 = heff_take_field(v_t_2463, 3);
    V v_end_2465 = heff_get_n(v_t_2463, 4, 9);
    V v_t_2466 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2467 = heff_strAppend(heff_get_n(v_t_2466, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str10));
    V v_msg_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str11), v_t_2467);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2468, heff_rec_n(2, shape_start__end, (V[]){v_start_2464, v_end_2465}), NTAG(TAG_Nothing)});
    V v_f_2470 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2469});
    return ((HeffT2){{v_f_2470, v_z_242}});
  }
  case TAG_Update: {
    heff_drop(v_r_240);
    V v_t_2477 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2478 = heff_take_field(v_t_2477, 3);
    V v_end_2479 = heff_get_n(v_t_2477, 4, 9);
    V v_t_2480 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_2481 = heff_strAppend(heff_get_n(v_t_2480, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str12));
    V v_msg_2482 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str13), v_t_2481);
    V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2482, heff_rec_n(2, shape_start__end, (V[]){v_start_2478, v_end_2479}), NTAG(TAG_Nothing)});
    V v_f_2484 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2483});
    return ((HeffT2){{v_f_2484, v_z_242}});
  }
  case TAG_EUSet: {
    heff_drop(v_r_240);
    V v_t_2488 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2489 = heff_take_field(v_t_2488, 3);
    V v_end_2490 = heff_get_n(v_t_2488, 4, 9);
    V v_t_2491 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2492 = heff_strAppend(heff_get_n(v_t_2491, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str14));
    V v_msg_2493 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str15), v_t_2492);
    V v_t_2494 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2493, heff_rec_n(2, shape_start__end, (V[]){v_start_2489, v_end_2490}), NTAG(TAG_Nothing)});
    V v_f_2495 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2494});
    return ((HeffT2){{v_f_2495, v_z_242}});
  }
  case TAG_InstB: {
    heff_drop(v_r_240);
    V v_t_24101 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24102 = heff_take_field(v_t_24101, 3);
    V v_end_24103 = heff_get_n(v_t_24101, 4, 9);
    V v_t_24104 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24105 = heff_strAppend(heff_get_n(v_t_24104, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str16));
    V v_msg_24106 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str17), v_t_24105);
    V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24106, heff_rec_n(2, shape_start__end, (V[]){v_start_24102, v_end_24103}), NTAG(TAG_Nothing)});
    V v_f_24108 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24107});
    return ((HeffT2){{v_f_24108, v_z_242}});
  }
  case TAG_EFSet: {
    heff_drop(v_r_240);
    V v_t_24112 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24113 = heff_take_field(v_t_24112, 3);
    V v_end_24114 = heff_get_n(v_t_24112, 4, 9);
    V v_t_24115 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24116 = heff_strAppend(heff_get_n(v_t_24115, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str18));
    V v_msg_24117 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str19), v_t_24116);
    V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24117, heff_rec_n(2, shape_start__end, (V[]){v_start_24113, v_end_24114}), NTAG(TAG_Nothing)});
    V v_f_24119 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24118});
    return ((HeffT2){{v_f_24119, v_z_242}});
  }
  case TAG_EFDefault: {
    heff_drop(v_r_240);
    V v_t_24123 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24124 = heff_take_field(v_t_24123, 3);
    V v_end_24125 = heff_get_n(v_t_24123, 4, 9);
    V v_t_24126 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24127 = heff_strAppend(heff_get_n(v_t_24126, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str20));
    V v_msg_24128 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str21), v_t_24127);
    V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24128, heff_rec_n(2, shape_start__end, (V[]){v_start_24124, v_end_24125}), NTAG(TAG_Nothing)});
    V v_f_24130 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24129});
    return ((HeffT2){{v_f_24130, v_z_242}});
  }
  case TAG_Sum: {
    heff_drop(v_r_240);
    V v_t_24136 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24137 = heff_take_field(v_t_24136, 3);
    V v_end_24138 = heff_get_n(v_t_24136, 4, 9);
    V v_t_24139 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24140 = heff_strAppend(heff_get_n(v_t_24139, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str22));
    V v_msg_24141 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str23), v_t_24140);
    V v_t_24142 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24141, heff_rec_n(2, shape_start__end, (V[]){v_start_24137, v_end_24138}), NTAG(TAG_Nothing)});
    V v_f_24143 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24142});
    return ((HeffT2){{v_f_24143, v_z_242}});
  }
  case TAG_ECon: {
    heff_drop(v_r_240);
    V v_t_24146 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24147 = heff_take_field(v_t_24146, 3);
    V v_end_24148 = heff_get_n(v_t_24146, 4, 9);
    V v_t_24149 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24150 = heff_strAppend(heff_get_n(v_t_24149, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str24));
    V v_msg_24151 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str25), v_t_24150);
    V v_t_24152 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24151, heff_rec_n(2, shape_start__end, (V[]){v_start_24147, v_end_24148}), NTAG(TAG_Nothing)});
    V v_f_24153 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24152});
    return ((HeffT2){{v_f_24153, v_z_242}});
  }
  case TAG_EField: {
    heff_drop(v_r_240);
    V v_t_24156 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24157 = heff_take_field(v_t_24156, 3);
    V v_end_24158 = heff_get_n(v_t_24156, 4, 9);
    V v_t_24159 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24160 = heff_strAppend(heff_get_n(v_t_24159, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str26));
    V v_msg_24161 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str27), v_t_24160);
    V v_t_24162 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24161, heff_rec_n(2, shape_start__end, (V[]){v_start_24157, v_end_24158}), NTAG(TAG_Nothing)});
    V v_f_24163 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24162});
    return ((HeffT2){{v_f_24163, v_z_242}});
  }
  case TAG_ENeg: {
    heff_drop(v_r_240);
    V v_t_24166 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24167 = heff_take_field(v_t_24166, 3);
    V v_end_24168 = heff_get_n(v_t_24166, 4, 9);
    V v_t_24169 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24170 = heff_strAppend(heff_get_n(v_t_24169, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str28));
    V v_msg_24171 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str29), v_t_24170);
    V v_t_24172 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24171, heff_rec_n(2, shape_start__end, (V[]){v_start_24167, v_end_24168}), NTAG(TAG_Nothing)});
    V v_f_24173 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24172});
    return ((HeffT2){{v_f_24173, v_z_242}});
  }
  case TAG_ETilde: {
    heff_drop(v_r_240);
    V v_t_24176 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24177 = heff_take_field(v_t_24176, 3);
    V v_end_24178 = heff_get_n(v_t_24176, 4, 9);
    V v_t_24179 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24180 = heff_strAppend(heff_get_n(v_t_24179, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str30));
    V v_msg_24181 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str31), v_t_24180);
    V v_t_24182 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24181, heff_rec_n(2, shape_start__end, (V[]){v_start_24177, v_end_24178}), NTAG(TAG_Nothing)});
    V v_f_24183 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24182});
    return ((HeffT2){{v_f_24183, v_z_242}});
  }
  case TAG_App: {
    heff_drop(v_r_240);
    V v_t_24186 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24187 = heff_take_field(v_t_24186, 3);
    V v_end_24188 = heff_get_n(v_t_24186, 4, 9);
    V v_t_24189 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str32));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str33), v_t_24190);
    V v_t_24192 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, heff_rec_n(2, shape_start__end, (V[]){v_start_24187, v_end_24188}), NTAG(TAG_Nothing)});
    V v_f_24193 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24192});
    return ((HeffT2){{v_f_24193, v_z_242}});
  }
  case TAG_Op: {
    heff_drop(v_r_240);
    V v_t_24197 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24198 = heff_take_field(v_t_24197, 3);
    V v_end_24199 = heff_get_n(v_t_24197, 4, 9);
    V v_t_24200 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24201 = heff_strAppend(heff_get_n(v_t_24200, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str34));
    V v_msg_24202 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str35), v_t_24201);
    V v_t_24203 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24202, heff_rec_n(2, shape_start__end, (V[]){v_start_24198, v_end_24199}), NTAG(TAG_Nothing)});
    V v_f_24204 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24203});
    return ((HeffT2){{v_f_24204, v_z_242}});
  }
  case TAG_Ops: {
    heff_drop(v_r_240);
    V v_t_24207 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24208 = heff_take_field(v_t_24207, 3);
    V v_end_24209 = heff_get_n(v_t_24207, 4, 9);
    V v_t_24210 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24211 = heff_strAppend(heff_get_n(v_t_24210, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str36));
    V v_msg_24212 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str37), v_t_24211);
    V v_t_24213 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24212, heff_rec_n(2, shape_start__end, (V[]){v_start_24208, v_end_24209}), NTAG(TAG_Nothing)});
    V v_f_24214 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24213});
    return ((HeffT2){{v_f_24214, v_z_242}});
  }
  case TAG_OpRhs: {
    heff_drop(v_r_240);
    V v_t_24217 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24218 = heff_take_field(v_t_24217, 3);
    V v_end_24219 = heff_get_n(v_t_24217, 4, 9);
    V v_t_24220 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24221 = heff_strAppend(heff_get_n(v_t_24220, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str38));
    V v_msg_24222 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str39), v_t_24221);
    V v_t_24223 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24222, heff_rec_n(2, shape_start__end, (V[]){v_start_24218, v_end_24219}), NTAG(TAG_Nothing)});
    V v_f_24224 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24223});
    return ((HeffT2){{v_f_24224, v_z_242}});
  }
  case TAG_Ann: {
    heff_drop(v_r_240);
    V v_t_24228 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24229 = heff_take_field(v_t_24228, 3);
    V v_end_24230 = heff_get_n(v_t_24228, 4, 9);
    V v_t_24231 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24232 = heff_strAppend(heff_get_n(v_t_24231, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str40));
    V v_msg_24233 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str41), v_t_24232);
    V v_t_24234 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24233, heff_rec_n(2, shape_start__end, (V[]){v_start_24229, v_end_24230}), NTAG(TAG_Nothing)});
    V v_f_24235 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24234});
    return ((HeffT2){{v_f_24235, v_z_242}});
  }
  case TAG_BVar: {
    heff_drop(v_r_240);
    V v_t_24237 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24238 = heff_take_field(v_t_24237, 3);
    V v_end_24239 = heff_get_n(v_t_24237, 4, 9);
    V v_t_24240 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24241 = heff_strAppend(heff_get_n(v_t_24240, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str42));
    V v_msg_24242 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str43), v_t_24241);
    V v_t_24243 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24242, heff_rec_n(2, shape_start__end, (V[]){v_start_24238, v_end_24239}), NTAG(TAG_Nothing)});
    V v_f_24244 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24243});
    return ((HeffT2){{v_f_24244, v_z_242}});
  }
  case TAG_BImp: {
    heff_drop(v_r_240);
    V v_t_24248 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24249 = heff_take_field(v_t_24248, 3);
    V v_end_24250 = heff_get_n(v_t_24248, 4, 9);
    V v_t_24251 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24252 = heff_strAppend(heff_get_n(v_t_24251, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str44));
    V v_msg_24253 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str45), v_t_24252);
    V v_t_24254 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24253, heff_rec_n(2, shape_start__end, (V[]){v_start_24249, v_end_24250}), NTAG(TAG_Nothing)});
    V v_f_24255 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24254});
    return ((HeffT2){{v_f_24255, v_z_242}});
  }
  case TAG_BAnn: {
    heff_drop(v_r_240);
    V v_t_24261 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24262 = heff_take_field(v_t_24261, 3);
    V v_end_24263 = heff_get_n(v_t_24261, 4, 9);
    V v_t_24264 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24265 = heff_strAppend(heff_get_n(v_t_24264, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str46));
    V v_msg_24266 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str47), v_t_24265);
    V v_t_24267 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24266, heff_rec_n(2, shape_start__end, (V[]){v_start_24262, v_end_24263}), NTAG(TAG_Nothing)});
    V v_f_24268 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24267});
    return ((HeffT2){{v_f_24268, v_z_242}});
  }
  case TAG_BPat: {
    heff_drop(v_r_240);
    V v_t_24270 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24271 = heff_take_field(v_t_24270, 3);
    V v_end_24272 = heff_get_n(v_t_24270, 4, 9);
    V v_t_24273 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24274 = heff_strAppend(heff_get_n(v_t_24273, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str48));
    V v_msg_24275 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str49), v_t_24274);
    V v_t_24276 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24275, heff_rec_n(2, shape_start__end, (V[]){v_start_24271, v_end_24272}), NTAG(TAG_Nothing)});
    V v_f_24277 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24276});
    return ((HeffT2){{v_f_24277, v_z_242}});
  }
  case TAG_Lam: {
    heff_drop(v_r_240);
    V v_t_24282 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24283 = heff_take_field(v_t_24282, 3);
    V v_end_24284 = heff_get_n(v_t_24282, 4, 9);
    V v_t_24285 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24286 = heff_strAppend(heff_get_n(v_t_24285, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str50));
    V v_msg_24287 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str51), v_t_24286);
    V v_t_24288 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24287, heff_rec_n(2, shape_start__end, (V[]){v_start_24283, v_end_24284}), NTAG(TAG_Nothing)});
    V v_f_24289 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24288});
    return ((HeffT2){{v_f_24289, v_z_242}});
  }
  case TAG_Case: {
    heff_drop(v_r_240);
    V v_t_24294 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24295 = heff_take_field(v_t_24294, 3);
    V v_end_24296 = heff_get_n(v_t_24294, 4, 9);
    V v_t_24297 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24298 = heff_strAppend(heff_get_n(v_t_24297, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str52));
    V v_msg_24299 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str53), v_t_24298);
    V v_t_24300 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24299, heff_rec_n(2, shape_start__end, (V[]){v_start_24295, v_end_24296}), NTAG(TAG_Nothing)});
    V v_f_24301 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24300});
    return ((HeffT2){{v_f_24301, v_z_242}});
  }
  case TAG_EAlt: {
    heff_drop(v_r_240);
    V v_t_24305 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24306 = heff_take_field(v_t_24305, 3);
    V v_end_24307 = heff_get_n(v_t_24305, 4, 9);
    V v_t_24308 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24309 = heff_strAppend(heff_get_n(v_t_24308, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str54));
    V v_msg_24310 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str55), v_t_24309);
    V v_t_24311 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24310, heff_rec_n(2, shape_start__end, (V[]){v_start_24306, v_end_24307}), NTAG(TAG_Nothing)});
    V v_f_24312 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24311});
    return ((HeffT2){{v_f_24312, v_z_242}});
  }
  case TAG_If: {
    heff_drop(v_r_240);
    V v_t_24319 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24320 = heff_take_field(v_t_24319, 3);
    V v_end_24321 = heff_get_n(v_t_24319, 4, 9);
    V v_t_24322 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24323 = heff_strAppend(heff_get_n(v_t_24322, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str56));
    V v_msg_24324 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str57), v_t_24323);
    V v_t_24325 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24324, heff_rec_n(2, shape_start__end, (V[]){v_start_24320, v_end_24321}), NTAG(TAG_Nothing)});
    V v_f_24326 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24325});
    return ((HeffT2){{v_f_24326, v_z_242}});
  }
  case TAG_Do: {
    heff_drop(v_r_240);
    V v_t_24329 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24330 = heff_take_field(v_t_24329, 3);
    V v_end_24331 = heff_get_n(v_t_24329, 4, 9);
    V v_t_24332 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24333 = heff_strAppend(heff_get_n(v_t_24332, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str58));
    V v_msg_24334 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str59), v_t_24333);
    V v_t_24335 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24334, heff_rec_n(2, shape_start__end, (V[]){v_start_24330, v_end_24331}), NTAG(TAG_Nothing)});
    V v_f_24336 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24335});
    return ((HeffT2){{v_f_24336, v_z_242}});
  }
  case TAG_ESBind: {
    heff_drop(v_r_240);
    V v_t_24340 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24341 = heff_take_field(v_t_24340, 3);
    V v_end_24342 = heff_get_n(v_t_24340, 4, 9);
    V v_t_24343 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24344 = heff_strAppend(heff_get_n(v_t_24343, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str60));
    V v_msg_24345 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str61), v_t_24344);
    V v_t_24346 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24345, heff_rec_n(2, shape_start__end, (V[]){v_start_24341, v_end_24342}), NTAG(TAG_Nothing)});
    V v_f_24347 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24346});
    return ((HeffT2){{v_f_24347, v_z_242}});
  }
  case TAG_ELet: {
    V v_x26_24353 = heff_dup(heff_field(v_x2_241, 5));
    switch (heff_tag_of(v_x26_24353)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      V v_t_24354 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
      V v_start_24355 = heff_take_field(v_t_24354, 3);
      V v_end_24356 = heff_get_n(v_t_24354, 4, 9);
      V v_t_24357 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
      V v_t_24358 = heff_strAppend(heff_get_n(v_t_24357, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str62));
      V v_msg_24359 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str63), v_t_24358);
      V v_t_24360 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24359, heff_rec_n(2, shape_start__end, (V[]){v_start_24355, v_end_24356}), NTAG(TAG_Nothing)});
      V v_f_24361 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24360});
      return ((HeffT2){{v_f_24361, v_z_242}});
    }
    case TAG_Just: {
      V v_x261_24362 = heff_field(v_x26_24353, 0);
      V v_ru_24x26_24353_24Just = heff_take_reuse_n(v_x26_24353, 1ULL, 1);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_ELet: {
        V v_kw_24363 = heff_field(v_x2_241, 0);
        V v_p_24364 = heff_field(v_x2_241, 1);
        V v_ann0_24365 = heff_field(v_x2_241, 2);
        V v_e_24367 = heff_field(v_x2_241, 4);
        heff_take_n(v_x2_241, 23ULL, 6);
        switch (heff_tag_of(v_x261_24362)) {
        case TAG_MkPair: {
          V v_body_24370 = heff_field(v_x261_24362, 1);
          heff_take_n(v_x261_24362, 2ULL, 2);
          V v_m_24371 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_240), heff_dup(v_p_24364), v_ann0_24365, v_e_24367));
          V v_x1_24372 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_z_242}));
          switch (heff_tag_of(v_x1_24372)) {
          case TAG_MkPair: {
            V v_x11_24373 = heff_field(v_x1_24372, 0);
            V v_st_24374 = heff_field(v_x1_24372, 1);
            heff_take_n(v_x1_24372, 3ULL, 2);
            switch (heff_tag_of(v_x11_24373)) {
            case TAG_Left: {
              V v_e_24375 = heff_field(v_x11_24373, 0);
              heff_take_n(v_x11_24373, 1ULL, 1);
              heff_drop(v_r_240);
              heff_drop(v_kw_24363);
              heff_drop(v_p_24364);
              heff_drop(v_body_24370);
              return ((HeffT2){{heff_tag_at_n(v_ru_24x26_24353_24Just, TAG_Left, 1, (V[]){v_e_24375}), v_st_24374}});
            }
            case TAG_Right: {
              V v_x_24376 = heff_field(v_x11_24373, 0);
              heff_take_n(v_x11_24373, 1ULL, 1);
              heff_drop_cell(v_ru_24x26_24353_24Just, 1);
              V v_t_24377 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24364; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24364); r_; });
              return (g_heff_2esyntax_2esurface_2eletBodyL_24cpr(v_r_240, v_kw_24363, v_x_24376, v_t_24377, v_body_24370, v_st_24374));
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_24373)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_24372)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x261_24362)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x26_24353)}});
    }
  }
  case TAG_ELetElse: {
    heff_drop(v_r_240);
    V v_t_24385 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24386 = heff_take_field(v_t_24385, 3);
    V v_end_24387 = heff_get_n(v_t_24385, 4, 9);
    V v_t_24388 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 7); r_; });
    V v_t_24389 = heff_strAppend(heff_get_n(v_t_24388, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str64));
    V v_msg_24390 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str65), v_t_24389);
    V v_t_24391 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24390, heff_rec_n(2, shape_start__end, (V[]){v_start_24386, v_end_24387}), NTAG(TAG_Nothing)});
    V v_f_24392 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24391});
    return ((HeffT2){{v_f_24392, v_z_242}});
  }
  case TAG_ELetMut: {
    heff_drop(v_r_240);
    V v_t_24399 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24400 = heff_take_field(v_t_24399, 3);
    V v_end_24401 = heff_get_n(v_t_24399, 4, 9);
    V v_t_24402 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24403 = heff_strAppend(heff_get_n(v_t_24402, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str66));
    V v_msg_24404 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str67), v_t_24403);
    V v_t_24405 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24404, heff_rec_n(2, shape_start__end, (V[]){v_start_24400, v_end_24401}), NTAG(TAG_Nothing)});
    V v_f_24406 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24405});
    return ((HeffT2){{v_f_24406, v_z_242}});
  }
  case TAG_EAssign: {
    heff_drop(v_r_240);
    V v_t_24410 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24411 = heff_take_field(v_t_24410, 3);
    V v_end_24412 = heff_get_n(v_t_24410, 4, 9);
    V v_t_24413 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24414 = heff_strAppend(heff_get_n(v_t_24413, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str68));
    V v_msg_24415 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str69), v_t_24414);
    V v_t_24416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24415, heff_rec_n(2, shape_start__end, (V[]){v_start_24411, v_end_24412}), NTAG(TAG_Nothing)});
    V v_f_24417 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24416});
    return ((HeffT2){{v_f_24417, v_z_242}});
  }
  case TAG_EWhile: {
    heff_drop(v_r_240);
    V v_t_24422 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24423 = heff_take_field(v_t_24422, 3);
    V v_end_24424 = heff_get_n(v_t_24422, 4, 9);
    V v_t_24425 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24426 = heff_strAppend(heff_get_n(v_t_24425, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str70));
    V v_msg_24427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str71), v_t_24426);
    V v_t_24428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24427, heff_rec_n(2, shape_start__end, (V[]){v_start_24423, v_end_24424}), NTAG(TAG_Nothing)});
    V v_f_24429 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24428});
    return ((HeffT2){{v_f_24429, v_z_242}});
  }
  case TAG_EFor: {
    heff_drop(v_r_240);
    V v_t_24436 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24437 = heff_take_field(v_t_24436, 3);
    V v_end_24438 = heff_get_n(v_t_24436, 4, 9);
    V v_t_24439 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24440 = heff_strAppend(heff_get_n(v_t_24439, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str72));
    V v_msg_24441 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str73), v_t_24440);
    V v_t_24442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24441, heff_rec_n(2, shape_start__end, (V[]){v_start_24437, v_end_24438}), NTAG(TAG_Nothing)});
    V v_f_24443 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24442});
    return ((HeffT2){{v_f_24443, v_z_242}});
  }
  case TAG_EJump: {
    heff_drop(v_r_240);
    V v_t_24445 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24446 = heff_take_field(v_t_24445, 3);
    V v_end_24447 = heff_get_n(v_t_24445, 4, 9);
    V v_t_24448 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24449 = heff_strAppend(heff_get_n(v_t_24448, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str74));
    V v_msg_24450 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str75), v_t_24449);
    V v_t_24451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24450, heff_rec_n(2, shape_start__end, (V[]){v_start_24446, v_end_24447}), NTAG(TAG_Nothing)});
    V v_f_24452 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24451});
    return ((HeffT2){{v_f_24452, v_z_242}});
  }
  case TAG_EReturn: {
    heff_drop(v_r_240);
    V v_t_24455 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24456 = heff_take_field(v_t_24455, 3);
    V v_end_24457 = heff_get_n(v_t_24455, 4, 9);
    V v_t_24458 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24459 = heff_strAppend(heff_get_n(v_t_24458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str76));
    V v_msg_24460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str77), v_t_24459);
    V v_t_24461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24460, heff_rec_n(2, shape_start__end, (V[]){v_start_24456, v_end_24457}), NTAG(TAG_Nothing)});
    V v_f_24462 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24461});
    return ((HeffT2){{v_f_24462, v_z_242}});
  }
  case TAG_ENest: {
    heff_drop(v_r_240);
    V v_t_24467 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24468 = heff_take_field(v_t_24467, 3);
    V v_end_24469 = heff_get_n(v_t_24467, 4, 9);
    V v_t_24470 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24471 = heff_strAppend(heff_get_n(v_t_24470, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str78));
    V v_msg_24472 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str79), v_t_24471);
    V v_t_24473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24472, heff_rec_n(2, shape_start__end, (V[]){v_start_24468, v_end_24469}), NTAG(TAG_Nothing)});
    V v_f_24474 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24473});
    return ((HeffT2){{v_f_24474, v_z_242}});
  }
  case TAG_EArrow: {
    heff_drop(v_r_240);
    V v_t_24477 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24478 = heff_take_field(v_t_24477, 3);
    V v_end_24479 = heff_get_n(v_t_24477, 4, 9);
    V v_t_24480 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24481 = heff_strAppend(heff_get_n(v_t_24480, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str80));
    V v_msg_24482 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str81), v_t_24481);
    V v_t_24483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24482, heff_rec_n(2, shape_start__end, (V[]){v_start_24478, v_end_24479}), NTAG(TAG_Nothing)});
    V v_f_24484 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24483});
    return ((HeffT2){{v_f_24484, v_z_242}});
  }
  case TAG_IfThen: {
    heff_drop(v_r_240);
    V v_t_24489 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24490 = heff_take_field(v_t_24489, 3);
    V v_end_24491 = heff_get_n(v_t_24489, 4, 9);
    V v_t_24492 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24493 = heff_strAppend(heff_get_n(v_t_24492, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str82));
    V v_msg_24494 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str83), v_t_24493);
    V v_t_24495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24494, heff_rec_n(2, shape_start__end, (V[]){v_start_24490, v_end_24491}), NTAG(TAG_Nothing)});
    V v_f_24496 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24495});
    return ((HeffT2){{v_f_24496, v_z_242}});
  }
  case TAG_ETry: {
    heff_drop(v_r_240);
    V v_t_24501 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24502 = heff_take_field(v_t_24501, 3);
    V v_end_24503 = heff_get_n(v_t_24501, 4, 9);
    V v_t_24504 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24505 = heff_strAppend(heff_get_n(v_t_24504, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str84));
    V v_msg_24506 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str85), v_t_24505);
    V v_t_24507 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24506, heff_rec_n(2, shape_start__end, (V[]){v_start_24502, v_end_24503}), NTAG(TAG_Nothing)});
    V v_f_24508 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24507});
    return ((HeffT2){{v_f_24508, v_z_242}});
  }
  case TAG_ECatch: {
    heff_drop(v_r_240);
    V v_t_24513 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24514 = heff_take_field(v_t_24513, 3);
    V v_end_24515 = heff_get_n(v_t_24513, 4, 9);
    V v_t_24516 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24517 = heff_strAppend(heff_get_n(v_t_24516, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str86));
    V v_msg_24518 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str87), v_t_24517);
    V v_t_24519 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24518, heff_rec_n(2, shape_start__end, (V[]){v_start_24514, v_end_24515}), NTAG(TAG_Nothing)});
    V v_f_24520 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24519});
    return ((HeffT2){{v_f_24520, v_z_242}});
  }
  case TAG_EWith: {
    heff_drop(v_r_240);
    V v_t_24527 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24528 = heff_take_field(v_t_24527, 3);
    V v_end_24529 = heff_get_n(v_t_24527, 4, 9);
    V v_t_24530 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24531 = heff_strAppend(heff_get_n(v_t_24530, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str88));
    V v_msg_24532 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str89), v_t_24531);
    V v_t_24533 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24532, heff_rec_n(2, shape_start__end, (V[]){v_start_24528, v_end_24529}), NTAG(TAG_Nothing)});
    V v_f_24534 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24533});
    return ((HeffT2){{v_f_24534, v_z_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2efitsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efitsIn_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efitsIn(V v_x1_240, V v_signed_241, V v_box_24n_242, V v_v_243) {
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  V v_ret_24bool = heff_bool(((heff_dup(v_x1_240) == NTAG(TAG_True)) ? ((heff_dup(v_signed_241) == NTAG(TAG_True)) ? ({ V v_t_244 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((v_n_242 - ((int64_t)1ULL))))); int c_ = ({ V v_t_246 = heff_intSub(MK_INT(0LL), heff_dup(v_t_244)); int c_ = (heff_intLe_c_lent(v_t_246, v_v_243, 0) && ({ V v_t_247 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((v_n_242 - ((int64_t)1ULL))))); int c_ = heff_intLt_c_lent(v_v_243, v_t_247, 0); heff_drop(v_t_247); c_; })); heff_drop(v_t_246); c_; }); heff_drop(v_t_244); c_; }) : (heff_intLe_c_lent(MK_INT(0LL), v_v_243, 1) && ({ V v_t_248 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word(v_n_242))); int c_ = heff_intLt_c_lent(v_v_243, v_t_248, 0); heff_drop(v_t_248); c_; }))) : ({ V v_t_245 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((v_n_242 - ((int64_t)1ULL))))); int c_ = ({ V v_t_249 = heff_intSub(MK_INT(0LL), heff_dup(v_t_245)); int c_ = (heff_intLe_c_lent(v_t_249, v_v_243, 0) && ({ V v_t_2410 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word(v_n_242))); int c_ = heff_intLt_c_lent(v_v_243, v_t_2410, 0); heff_drop(v_t_2410); c_; })); heff_drop(v_t_249); c_; }); heff_drop(v_t_245); c_; })));
  heff_drop(v_v_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efitsIn(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str0, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str1, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str2, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str3, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str4, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str5, 51, "a float's size is a number, 32 or 64: `x::float-32`");
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15, 1, 0};
Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry, 5, 0};

V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V v_inPat_240, V v_sp_241, V v_v_242, V v_x5_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SegmentInteger: {
    V v_t_249;
    switch (heff_tag_of(v_x6_244)) {
    case TAG_SizeDefault: {
      v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_245 = heff_field(v_x6_244, 0);
      V v_ru_24x6_244_24SizeNumber = heff_take_reuse_n(v_x6_244, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24x6_244_24SizeNumber, TAG_Just, 1, (V[]){v_n_245});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_244, 0ULL, 3);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_244);
    }
    return (g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(v_inPat_240, v_sp_241, v_v_242, v_t_249));
  }
  case TAG_SegmentBinary: {
    heff_drop(v_x6_244);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      heff_drop(v_sp_241);
      return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0_clo);
    }
    case TAG_IntValue: {
      heff_take_n(v_v_242, 0ULL, 1);
      if (!((((int64_t)8ULL) % ((int64_t)8ULL)) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2_clo);
      }
    }
    case TAG_FloatValue: {
      if (!((((int64_t)8ULL) % ((int64_t)8ULL)) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4_clo);
      }
    }
    case TAG_RuneValue: {
      if (!((((int64_t)8ULL) % ((int64_t)8ULL)) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6_clo);
      }
    }
    case TAG_OtherValue: {
      if (!((((int64_t)8ULL) % ((int64_t)8ULL)) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8_clo);
      }
    }
    default: return heff_nomatch(v_v_242);
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_x6_244);
    return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9_clo);
  }
  case TAG_SegmentFloat: {
    heff_drop(v_v_242);
    switch (heff_tag_of(v_x6_244)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10_clo);
    }
    case TAG_SizeNumber: {
      V v_x61_2433 = heff_field(v_x6_244, 0);
      heff_take_n(v_x6_244, 1ULL, 1);
      if (heff_intEq_c_lent(v_x61_2433, MK_INT(64LL), 2)) {
        heff_drop(v_sp_241);
        heff_drop(v_x61_2433);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11_clo);
      } else {
        if (heff_intEq_c_lent(v_x61_2433, MK_INT(32LL), 2)) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2433);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12_clo);
        } else {
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam13, 1, 2, (V[]){v_x61_2433, v_sp_241});
        }
      }
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_244, 0ULL, 3);
      return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam14, 1, 1, (V[]){v_sp_241});
    }
    default: return heff_nomatch(v_x6_244);
    }
  }
  case TAG_SegmentUtf: {
    heff_take_n(v_x5_243, 0ULL, 1);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_x6_244);
    return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15_clo);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str0), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_2413});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_t_2416 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_p_2415});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3(V self, V *args) {
  V v_st_2417 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str1), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4(V self, V *args) {
  V v_p_2419 = args[0];
  V v_t_2420 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_p_2419});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5(V self, V *args) {
  V v_st_2421 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str2), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2422}), v_st_2421});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6(V self, V *args) {
  V v_p_2423 = args[0];
  V v_t_2424 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_p_2423});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7(V self, V *args) {
  V v_st_2425 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str3), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2426}), v_st_2425});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8(V self, V *args) {
  V v_p_2427 = args[0];
  V v_t_2428 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_p_2427});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9(V self, V *args) {
  V v_p_2429 = args[0];
  V v_t_2430 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_p_2429});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10(V self, V *args) {
  V v_st_2431 = args[0];
  V v_t_2432 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, v_st_2431});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11(V self, V *args) {
  V v_st_2434 = args[0];
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_st_2434});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12(V self, V *args) {
  V v_st_2436 = args[0];
  V v_t_2437 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_st_2436});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam13(V self, V *args) {
  V v_st_2438 = args[0];
  V v_x61_2433 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str4), heff_intShow(v_x61_2433));
  V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2439, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2440}), v_st_2438});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam14(V self, V *args) {
  V v_st_2444 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str5), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2445}), v_st_2444});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15(V self, V *args) {
  V v_st_2447 = args[0];
  V v_t_2448 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_st_2447});
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam44(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esegmentL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esegmentL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam0, 1, 2, (V[]){v_m_243, v_e_241});
  }
  case TAG_EParen: {
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam1, 1, 2, (V[]){v_m_2418, v_e_241});
  }
  case TAG_Named: {
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam2, 1, 2, (V[]){v_m_2435, v_e_241});
  }
  case TAG_Tup: {
    V v_m_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam3, 1, 2, (V[]){v_m_2451, v_e_241});
  }
  case TAG_Seg: {
    V v_v_2463 = heff_field(v_e_241, 0);
    V v_cc_2464 = heff_field(v_e_241, 1);
    V v_spec_2465 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_v_2463)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam4, 1, 4, (V[]){v_m_2466, v_cc_2464, v_spec_2465, v_v_2463});
  }
  case TAG_Braces: {
    V v_m_2490 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam5, 1, 2, (V[]){v_m_2490, v_e_241});
  }
  case TAG_Update: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam6, 1, 2, (V[]){v_m_24108, v_e_241});
  }
  case TAG_EUSet: {
    V v_m_24123 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam7, 1, 2, (V[]){v_m_24123, v_e_241});
  }
  case TAG_InstB: {
    V v_m_24140 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam8, 1, 2, (V[]){v_m_24140, v_e_241});
  }
  case TAG_EFSet: {
    V v_m_24155 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam9, 1, 2, (V[]){v_m_24155, v_e_241});
  }
  case TAG_EFDefault: {
    V v_m_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam10, 1, 2, (V[]){v_m_24170, v_e_241});
  }
  case TAG_Sum: {
    V v_m_24187 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam11, 1, 2, (V[]){v_m_24187, v_e_241});
  }
  case TAG_ECon: {
    V v_m_24201 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam12, 1, 2, (V[]){v_m_24201, v_e_241});
  }
  case TAG_EField: {
    V v_m_24215 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam13, 1, 2, (V[]){v_m_24215, v_e_241});
  }
  case TAG_ENeg: {
    V v_m_24229 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam14, 1, 2, (V[]){v_m_24229, v_e_241});
  }
  case TAG_ETilde: {
    V v_m_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam15, 1, 2, (V[]){v_m_24243, v_e_241});
  }
  case TAG_App: {
    V v_m_24257 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam16, 1, 2, (V[]){v_m_24257, v_e_241});
  }
  case TAG_Op: {
    V v_m_24272 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam17, 1, 2, (V[]){v_m_24272, v_e_241});
  }
  case TAG_Ops: {
    V v_m_24286 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam18, 1, 2, (V[]){v_m_24286, v_e_241});
  }
  case TAG_OpRhs: {
    V v_m_24300 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam19, 1, 2, (V[]){v_m_24300, v_e_241});
  }
  case TAG_Ann: {
    V v_m_24315 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam20, 1, 2, (V[]){v_m_24315, v_e_241});
  }
  case TAG_BVar: {
    V v_m_24328 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam21, 1, 2, (V[]){v_m_24328, v_e_241});
  }
  case TAG_BImp: {
    V v_m_24343 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam22, 1, 2, (V[]){v_m_24343, v_e_241});
  }
  case TAG_BAnn: {
    V v_m_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam23, 1, 2, (V[]){v_m_24360, v_e_241});
  }
  case TAG_BPat: {
    V v_m_24373 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam24, 1, 2, (V[]){v_m_24373, v_e_241});
  }
  case TAG_Lam: {
    V v_m_24389 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam25, 1, 2, (V[]){v_m_24389, v_e_241});
  }
  case TAG_Case: {
    V v_m_24405 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam26, 1, 2, (V[]){v_m_24405, v_e_241});
  }
  case TAG_EAlt: {
    V v_m_24420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam27, 1, 2, (V[]){v_m_24420, v_e_241});
  }
  case TAG_If: {
    V v_m_24438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam28, 1, 2, (V[]){v_m_24438, v_e_241});
  }
  case TAG_Do: {
    V v_m_24452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam29, 1, 2, (V[]){v_m_24452, v_e_241});
  }
  case TAG_ESBind: {
    V v_m_24467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam30, 1, 2, (V[]){v_m_24467, v_e_241});
  }
  case TAG_ELet: {
    V v_m_24485 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam31, 1, 2, (V[]){v_m_24485, v_e_241});
  }
  case TAG_ELetElse: {
    V v_m_24504 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam32, 1, 2, (V[]){v_m_24504, v_e_241});
  }
  case TAG_ELetMut: {
    V v_m_24522 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam33, 1, 2, (V[]){v_m_24522, v_e_241});
  }
  case TAG_EAssign: {
    V v_m_24537 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam34, 1, 2, (V[]){v_m_24537, v_e_241});
  }
  case TAG_EWhile: {
    V v_m_24553 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam35, 1, 2, (V[]){v_m_24553, v_e_241});
  }
  case TAG_EFor: {
    V v_m_24571 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam36, 1, 2, (V[]){v_m_24571, v_e_241});
  }
  case TAG_EJump: {
    V v_m_24584 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam37, 1, 2, (V[]){v_m_24584, v_e_241});
  }
  case TAG_EReturn: {
    V v_m_24598 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam38, 1, 2, (V[]){v_m_24598, v_e_241});
  }
  case TAG_ENest: {
    V v_m_24614 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam39, 1, 2, (V[]){v_m_24614, v_e_241});
  }
  case TAG_EArrow: {
    V v_m_24628 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam40, 1, 2, (V[]){v_m_24628, v_e_241});
  }
  case TAG_IfThen: {
    V v_m_24644 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam41, 1, 2, (V[]){v_m_24644, v_e_241});
  }
  case TAG_ETry: {
    V v_m_24660 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam42, 1, 2, (V[]){v_m_24660, v_e_241});
  }
  case TAG_ECatch: {
    V v_m_24676 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam43, 1, 2, (V[]){v_m_24676, v_e_241});
  }
  case TAG_EWith: {
    V v_m_24694 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam44, 1, 2, (V[]){v_m_24694, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esegmentL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_a_2410 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2410, 3, 9), v_e_2412});
      V v_t_2414 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_249));
      return ({ V a_0 = v_ru_24x1_245_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_2413; V a_3 = v_x_249; V a_4 = v_t_2414; V a_5 = v_st_247; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args) {
  V v_st_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_st_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_MkPair: {
    V v_x11_2421 = heff_field(v_x1_2420, 0);
    V v_st_2422 = heff_field(v_x1_2420, 1);
    V v_ru_24x1_2420_24MkPair = heff_take_reuse_n(v_x1_2420, 3ULL, 2);
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      V v_a_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2426 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2427 = heff_get_n(v_t_2426, 4, 9);
      V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2425, 3, 9), v_e_2427});
      V v_t_2429 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2424));
      return ({ V a_0 = v_ru_24x1_2420_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_2428; V a_3 = v_x_2424; V a_4 = v_t_2429; V a_5 = v_st_2422; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_st_2436}));
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_MkPair: {
    V v_x11_2438 = heff_field(v_x1_2437, 0);
    V v_st_2439 = heff_field(v_x1_2437, 1);
    V v_ru_24x1_2437_24MkPair = heff_take_reuse_n(v_x1_2437, 3ULL, 2);
    switch (heff_tag_of(v_x11_2438)) {
    case TAG_Left: {
      V v_e_2440 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
    }
    case TAG_Right: {
      V v_x_2441 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      V v_a_2442 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2443 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2444 = heff_get_n(v_t_2443, 4, 9);
      V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2442, 3, 9), v_e_2444});
      V v_t_2446 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2441));
      return ({ V a_0 = v_ru_24x1_2437_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_2445; V a_3 = v_x_2441; V a_4 = v_t_2446; V a_5 = v_st_2439; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_2438);
    }
  }
  default: return heff_nomatch(v_x1_2437);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam3(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      V v_a_2458 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2459 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2460 = heff_get_n(v_t_2459, 4, 9);
      V v_t_2461 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2458, 3, 9), v_e_2460});
      V v_t_2462 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2457));
      return ({ V a_0 = v_ru_24x1_2453_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_2461; V a_3 = v_x_2457; V a_4 = v_t_2462; V a_5 = v_st_2455; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam4(V self, V *args) {
  V v_st_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_cc_2464 = heff_env(self)[1];
  V v_spec_2465 = heff_env(self)[2];
  V v_v_2463 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_st_2467}));
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_MkPair: {
    V v_x11_2469 = heff_field(v_x1_2468, 0);
    V v_st_2470 = heff_field(v_x1_2468, 1);
    V v_ru_24x1_2468_24MkPair = heff_take_reuse_n(v_x1_2468, 3ULL, 2);
    switch (heff_tag_of(v_x11_2469)) {
    case TAG_Left: {
      V v_e_2471 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      heff_drop_rec(v_cc_2464, 9);
      heff_drop(v_spec_2465);
      heff_drop(v_v_2463);
      return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2471}), v_st_2470});
    }
    case TAG_Right: {
      V v_x_2472 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      V v_t_2473 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_cc_2464, 3)), heff_dup(heff_rfield(v_cc_2464, 4))});
      V v_t_2474 = (g_heff_2esyntax_2esurface_2especGroups(heff_dup(v_spec_2465), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_m_2475 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_t_2473, heff_dup(g_heff_2esyntax_2esurface_2eemptySpec_get()), v_t_2474));
      V v_x1_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_st_2470}));
      switch (heff_tag_of(v_x1_2476)) {
      case TAG_MkPair: {
        V v_x11_2477 = heff_field(v_x1_2476, 0);
        V v_st_2478 = heff_field(v_x1_2476, 1);
        heff_take_n(v_x1_2476, 3ULL, 2);
        switch (heff_tag_of(v_x11_2477)) {
        case TAG_Left: {
          V v_e_2479 = heff_field(v_x11_2477, 0);
          heff_take_n(v_x11_2477, 1ULL, 1);
          heff_drop_rec(v_cc_2464, 9);
          heff_drop(v_spec_2465);
          heff_drop(v_v_2463);
          heff_drop(v_x_2472);
          return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2479}), v_st_2478});
        }
        case TAG_Right: {
          V v_x_2480 = heff_field(v_x11_2477, 0);
          heff_take_n(v_x11_2477, 1ULL, 1);
          V v_a_2481 = (g_heff_2esyntax_2ecst_2efirstE(v_v_2463));
          V v_t_2482 = (g_heff_2esyntax_2ecst_2elastE(heff_tag_n(TAG_Seg, 3, (V[]){v_v_2463, v_cc_2464, v_spec_2465})));
          V v_e_2483 = heff_get_n(v_t_2482, 4, 9);
          V v_t_2484 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2481, 3, 9), v_e_2483});
          V v_t_2485 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2472));
          return ({ V a_0 = v_ru_24x1_2468_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_2484; V a_3 = v_x_2472; V a_4 = v_t_2485; V a_5 = v_x_2480; V a_6 = v_st_2478; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24tok2(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
        }
        default: return heff_nomatch(v_x11_2477);
        }
      }
      default: return heff_nomatch(v_x1_2476);
      }
    }
    default: return heff_nomatch(v_x11_2469);
    }
  }
  default: return heff_nomatch(v_x1_2468);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam5(V self, V *args) {
  V v_st_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_st_2491}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      V v_a_2497 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2498 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2499 = heff_get_n(v_t_2498, 4, 9);
      V v_t_24100 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2497, 3, 9), v_e_2499});
      V v_t_24101 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2496));
      return ({ V a_0 = v_ru_24x1_2492_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24100; V a_3 = v_x_2496; V a_4 = v_t_24101; V a_5 = v_st_2494; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam6(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      V v_a_24115 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24116 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24117 = heff_get_n(v_t_24116, 4, 9);
      V v_t_24118 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24115, 3, 9), v_e_24117});
      V v_t_24119 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24114));
      return ({ V a_0 = v_ru_24x1_24110_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24118; V a_3 = v_x_24114; V a_4 = v_t_24119; V a_5 = v_st_24112; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam7(V self, V *args) {
  V v_st_24124 = args[0];
  V v_m_24123 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24125 = heff_tr(heff_call(v_m_24123, 1, (V[]){v_st_24124}));
  switch (heff_tag_of(v_x1_24125)) {
  case TAG_MkPair: {
    V v_x11_24126 = heff_field(v_x1_24125, 0);
    V v_st_24127 = heff_field(v_x1_24125, 1);
    V v_ru_24x1_24125_24MkPair = heff_take_reuse_n(v_x1_24125, 3ULL, 2);
    switch (heff_tag_of(v_x11_24126)) {
    case TAG_Left: {
      V v_e_24128 = heff_field(v_x11_24126, 0);
      heff_take_n(v_x11_24126, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24128}), v_st_24127});
    }
    case TAG_Right: {
      V v_x_24129 = heff_field(v_x11_24126, 0);
      heff_take_n(v_x11_24126, 1ULL, 1);
      V v_a_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24131 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24132 = heff_get_n(v_t_24131, 4, 9);
      V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24130, 3, 9), v_e_24132});
      V v_t_24134 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24129));
      return ({ V a_0 = v_ru_24x1_24125_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24133; V a_3 = v_x_24129; V a_4 = v_t_24134; V a_5 = v_st_24127; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24126);
    }
  }
  default: return heff_nomatch(v_x1_24125);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam8(V self, V *args) {
  V v_st_24141 = args[0];
  V v_m_24140 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24142 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_st_24141}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_MkPair: {
    V v_x11_24143 = heff_field(v_x1_24142, 0);
    V v_st_24144 = heff_field(v_x1_24142, 1);
    V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
    switch (heff_tag_of(v_x11_24143)) {
    case TAG_Left: {
      V v_e_24145 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
    }
    case TAG_Right: {
      V v_x_24146 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      V v_a_24147 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24148 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24149 = heff_get_n(v_t_24148, 4, 9);
      V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24147, 3, 9), v_e_24149});
      V v_t_24151 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24146));
      return ({ V a_0 = v_ru_24x1_24142_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24150; V a_3 = v_x_24146; V a_4 = v_t_24151; V a_5 = v_st_24144; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24143);
    }
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam9(V self, V *args) {
  V v_st_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_st_24156}));
  switch (heff_tag_of(v_x1_24157)) {
  case TAG_MkPair: {
    V v_x11_24158 = heff_field(v_x1_24157, 0);
    V v_st_24159 = heff_field(v_x1_24157, 1);
    V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_Left: {
      V v_e_24160 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24160}), v_st_24159});
    }
    case TAG_Right: {
      V v_x_24161 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      V v_a_24162 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24163 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24164 = heff_get_n(v_t_24163, 4, 9);
      V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24162, 3, 9), v_e_24164});
      V v_t_24166 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24161));
      return ({ V a_0 = v_ru_24x1_24157_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24165; V a_3 = v_x_24161; V a_4 = v_t_24166; V a_5 = v_st_24159; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24158);
    }
  }
  default: return heff_nomatch(v_x1_24157);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam10(V self, V *args) {
  V v_st_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_st_24171}));
  switch (heff_tag_of(v_x1_24172)) {
  case TAG_MkPair: {
    V v_x11_24173 = heff_field(v_x1_24172, 0);
    V v_st_24174 = heff_field(v_x1_24172, 1);
    V v_ru_24x1_24172_24MkPair = heff_take_reuse_n(v_x1_24172, 3ULL, 2);
    switch (heff_tag_of(v_x11_24173)) {
    case TAG_Left: {
      V v_e_24175 = heff_field(v_x11_24173, 0);
      heff_take_n(v_x11_24173, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24175}), v_st_24174});
    }
    case TAG_Right: {
      V v_x_24176 = heff_field(v_x11_24173, 0);
      heff_take_n(v_x11_24173, 1ULL, 1);
      V v_a_24177 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24178 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24179 = heff_get_n(v_t_24178, 4, 9);
      V v_t_24180 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24177, 3, 9), v_e_24179});
      V v_t_24181 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24176));
      return ({ V a_0 = v_ru_24x1_24172_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24180; V a_3 = v_x_24176; V a_4 = v_t_24181; V a_5 = v_st_24174; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24173);
    }
  }
  default: return heff_nomatch(v_x1_24172);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam11(V self, V *args) {
  V v_st_24188 = args[0];
  V v_m_24187 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24189 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_st_24188}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      V v_a_24194 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24195 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24196 = heff_get_n(v_t_24195, 4, 9);
      V v_t_24197 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24194, 3, 9), v_e_24196});
      V v_t_24198 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24193));
      return ({ V a_0 = v_ru_24x1_24189_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24197; V a_3 = v_x_24193; V a_4 = v_t_24198; V a_5 = v_st_24191; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam12(V self, V *args) {
  V v_st_24202 = args[0];
  V v_m_24201 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24203 = heff_tr(heff_call(v_m_24201, 1, (V[]){v_st_24202}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_MkPair: {
    V v_x11_24204 = heff_field(v_x1_24203, 0);
    V v_st_24205 = heff_field(v_x1_24203, 1);
    V v_ru_24x1_24203_24MkPair = heff_take_reuse_n(v_x1_24203, 3ULL, 2);
    switch (heff_tag_of(v_x11_24204)) {
    case TAG_Left: {
      V v_e_24206 = heff_field(v_x11_24204, 0);
      heff_take_n(v_x11_24204, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24203_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24206}), v_st_24205});
    }
    case TAG_Right: {
      V v_x_24207 = heff_field(v_x11_24204, 0);
      heff_take_n(v_x11_24204, 1ULL, 1);
      V v_a_24208 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24209 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24210 = heff_get_n(v_t_24209, 4, 9);
      V v_t_24211 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24208, 3, 9), v_e_24210});
      V v_t_24212 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24207));
      return ({ V a_0 = v_ru_24x1_24203_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24211; V a_3 = v_x_24207; V a_4 = v_t_24212; V a_5 = v_st_24205; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24204);
    }
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam13(V self, V *args) {
  V v_st_24216 = args[0];
  V v_m_24215 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24217 = heff_tr(heff_call(v_m_24215, 1, (V[]){v_st_24216}));
  switch (heff_tag_of(v_x1_24217)) {
  case TAG_MkPair: {
    V v_x11_24218 = heff_field(v_x1_24217, 0);
    V v_st_24219 = heff_field(v_x1_24217, 1);
    V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
    switch (heff_tag_of(v_x11_24218)) {
    case TAG_Left: {
      V v_e_24220 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
    }
    case TAG_Right: {
      V v_x_24221 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      V v_a_24222 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24223 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24224 = heff_get_n(v_t_24223, 4, 9);
      V v_t_24225 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24222, 3, 9), v_e_24224});
      V v_t_24226 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24221));
      return ({ V a_0 = v_ru_24x1_24217_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24225; V a_3 = v_x_24221; V a_4 = v_t_24226; V a_5 = v_st_24219; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24218);
    }
  }
  default: return heff_nomatch(v_x1_24217);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam14(V self, V *args) {
  V v_st_24230 = args[0];
  V v_m_24229 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24231 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_st_24230}));
  switch (heff_tag_of(v_x1_24231)) {
  case TAG_MkPair: {
    V v_x11_24232 = heff_field(v_x1_24231, 0);
    V v_st_24233 = heff_field(v_x1_24231, 1);
    V v_ru_24x1_24231_24MkPair = heff_take_reuse_n(v_x1_24231, 3ULL, 2);
    switch (heff_tag_of(v_x11_24232)) {
    case TAG_Left: {
      V v_e_24234 = heff_field(v_x11_24232, 0);
      heff_take_n(v_x11_24232, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24234}), v_st_24233});
    }
    case TAG_Right: {
      V v_x_24235 = heff_field(v_x11_24232, 0);
      heff_take_n(v_x11_24232, 1ULL, 1);
      V v_a_24236 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24237 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24238 = heff_get_n(v_t_24237, 4, 9);
      V v_t_24239 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24236, 3, 9), v_e_24238});
      V v_t_24240 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24235));
      return ({ V a_0 = v_ru_24x1_24231_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24239; V a_3 = v_x_24235; V a_4 = v_t_24240; V a_5 = v_st_24233; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24232);
    }
  }
  default: return heff_nomatch(v_x1_24231);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam15(V self, V *args) {
  V v_st_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24245 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_st_24244}));
  switch (heff_tag_of(v_x1_24245)) {
  case TAG_MkPair: {
    V v_x11_24246 = heff_field(v_x1_24245, 0);
    V v_st_24247 = heff_field(v_x1_24245, 1);
    V v_ru_24x1_24245_24MkPair = heff_take_reuse_n(v_x1_24245, 3ULL, 2);
    switch (heff_tag_of(v_x11_24246)) {
    case TAG_Left: {
      V v_e_24248 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24248}), v_st_24247});
    }
    case TAG_Right: {
      V v_x_24249 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      V v_a_24250 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24251 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24252 = heff_get_n(v_t_24251, 4, 9);
      V v_t_24253 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24250, 3, 9), v_e_24252});
      V v_t_24254 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24249));
      return ({ V a_0 = v_ru_24x1_24245_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24253; V a_3 = v_x_24249; V a_4 = v_t_24254; V a_5 = v_st_24247; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24246);
    }
  }
  default: return heff_nomatch(v_x1_24245);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam16(V self, V *args) {
  V v_st_24258 = args[0];
  V v_m_24257 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24259 = heff_tr(heff_call(v_m_24257, 1, (V[]){v_st_24258}));
  switch (heff_tag_of(v_x1_24259)) {
  case TAG_MkPair: {
    V v_x11_24260 = heff_field(v_x1_24259, 0);
    V v_st_24261 = heff_field(v_x1_24259, 1);
    V v_ru_24x1_24259_24MkPair = heff_take_reuse_n(v_x1_24259, 3ULL, 2);
    switch (heff_tag_of(v_x11_24260)) {
    case TAG_Left: {
      V v_e_24262 = heff_field(v_x11_24260, 0);
      heff_take_n(v_x11_24260, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24259_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24262}), v_st_24261});
    }
    case TAG_Right: {
      V v_x_24263 = heff_field(v_x11_24260, 0);
      heff_take_n(v_x11_24260, 1ULL, 1);
      V v_a_24264 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24265 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24266 = heff_get_n(v_t_24265, 4, 9);
      V v_t_24267 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24264, 3, 9), v_e_24266});
      V v_t_24268 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24263));
      return ({ V a_0 = v_ru_24x1_24259_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24267; V a_3 = v_x_24263; V a_4 = v_t_24268; V a_5 = v_st_24261; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24260);
    }
  }
  default: return heff_nomatch(v_x1_24259);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam17(V self, V *args) {
  V v_st_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24273}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      V v_a_24279 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24280 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24281 = heff_get_n(v_t_24280, 4, 9);
      V v_t_24282 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24279, 3, 9), v_e_24281});
      V v_t_24283 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24278));
      return ({ V a_0 = v_ru_24x1_24274_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24282; V a_3 = v_x_24278; V a_4 = v_t_24283; V a_5 = v_st_24276; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam18(V self, V *args) {
  V v_st_24287 = args[0];
  V v_m_24286 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24288 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_st_24287}));
  switch (heff_tag_of(v_x1_24288)) {
  case TAG_MkPair: {
    V v_x11_24289 = heff_field(v_x1_24288, 0);
    V v_st_24290 = heff_field(v_x1_24288, 1);
    V v_ru_24x1_24288_24MkPair = heff_take_reuse_n(v_x1_24288, 3ULL, 2);
    switch (heff_tag_of(v_x11_24289)) {
    case TAG_Left: {
      V v_e_24291 = heff_field(v_x11_24289, 0);
      heff_take_n(v_x11_24289, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24288_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24291}), v_st_24290});
    }
    case TAG_Right: {
      V v_x_24292 = heff_field(v_x11_24289, 0);
      heff_take_n(v_x11_24289, 1ULL, 1);
      V v_a_24293 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24294 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24295 = heff_get_n(v_t_24294, 4, 9);
      V v_t_24296 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24293, 3, 9), v_e_24295});
      V v_t_24297 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24292));
      return ({ V a_0 = v_ru_24x1_24288_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24296; V a_3 = v_x_24292; V a_4 = v_t_24297; V a_5 = v_st_24290; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24289);
    }
  }
  default: return heff_nomatch(v_x1_24288);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam19(V self, V *args) {
  V v_st_24301 = args[0];
  V v_m_24300 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24302 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_st_24301}));
  switch (heff_tag_of(v_x1_24302)) {
  case TAG_MkPair: {
    V v_x11_24303 = heff_field(v_x1_24302, 0);
    V v_st_24304 = heff_field(v_x1_24302, 1);
    V v_ru_24x1_24302_24MkPair = heff_take_reuse_n(v_x1_24302, 3ULL, 2);
    switch (heff_tag_of(v_x11_24303)) {
    case TAG_Left: {
      V v_e_24305 = heff_field(v_x11_24303, 0);
      heff_take_n(v_x11_24303, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24305}), v_st_24304});
    }
    case TAG_Right: {
      V v_x_24306 = heff_field(v_x11_24303, 0);
      heff_take_n(v_x11_24303, 1ULL, 1);
      V v_a_24307 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24308 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24309 = heff_get_n(v_t_24308, 4, 9);
      V v_t_24310 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24307, 3, 9), v_e_24309});
      V v_t_24311 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24306));
      return ({ V a_0 = v_ru_24x1_24302_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24310; V a_3 = v_x_24306; V a_4 = v_t_24311; V a_5 = v_st_24304; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24303);
    }
  }
  default: return heff_nomatch(v_x1_24302);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam20(V self, V *args) {
  V v_st_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24317 = heff_tr(heff_call(v_m_24315, 1, (V[]){v_st_24316}));
  switch (heff_tag_of(v_x1_24317)) {
  case TAG_MkPair: {
    V v_x11_24318 = heff_field(v_x1_24317, 0);
    V v_st_24319 = heff_field(v_x1_24317, 1);
    V v_ru_24x1_24317_24MkPair = heff_take_reuse_n(v_x1_24317, 3ULL, 2);
    switch (heff_tag_of(v_x11_24318)) {
    case TAG_Left: {
      V v_e_24320 = heff_field(v_x11_24318, 0);
      heff_take_n(v_x11_24318, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24317_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24320}), v_st_24319});
    }
    case TAG_Right: {
      V v_x_24321 = heff_field(v_x11_24318, 0);
      heff_take_n(v_x11_24318, 1ULL, 1);
      V v_a_24322 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24323 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24324 = heff_get_n(v_t_24323, 4, 9);
      V v_t_24325 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24322, 3, 9), v_e_24324});
      V v_t_24326 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24321));
      return ({ V a_0 = v_ru_24x1_24317_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24325; V a_3 = v_x_24321; V a_4 = v_t_24326; V a_5 = v_st_24319; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24318);
    }
  }
  default: return heff_nomatch(v_x1_24317);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam21(V self, V *args) {
  V v_st_24329 = args[0];
  V v_m_24328 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24330 = heff_tr(heff_call(v_m_24328, 1, (V[]){v_st_24329}));
  switch (heff_tag_of(v_x1_24330)) {
  case TAG_MkPair: {
    V v_x11_24331 = heff_field(v_x1_24330, 0);
    V v_st_24332 = heff_field(v_x1_24330, 1);
    V v_ru_24x1_24330_24MkPair = heff_take_reuse_n(v_x1_24330, 3ULL, 2);
    switch (heff_tag_of(v_x11_24331)) {
    case TAG_Left: {
      V v_e_24333 = heff_field(v_x11_24331, 0);
      heff_take_n(v_x11_24331, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_24330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24333}), v_st_24332});
    }
    case TAG_Right: {
      V v_x_24334 = heff_field(v_x11_24331, 0);
      heff_take_n(v_x11_24331, 1ULL, 1);
      V v_a_24335 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24336 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24337 = heff_get_n(v_t_24336, 4, 9);
      V v_t_24338 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24335, 3, 9), v_e_24337});
      V v_t_24339 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24334));
      return ({ V a_0 = v_ru_24x1_24330_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24338; V a_3 = v_x_24334; V a_4 = v_t_24339; V a_5 = v_st_24332; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24331);
    }
  }
  default: return heff_nomatch(v_x1_24330);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam22(V self, V *args) {
  V v_st_24344 = args[0];
  V v_m_24343 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24345 = heff_tr(heff_call(v_m_24343, 1, (V[]){v_st_24344}));
  switch (heff_tag_of(v_x1_24345)) {
  case TAG_MkPair: {
    V v_x11_24346 = heff_field(v_x1_24345, 0);
    V v_st_24347 = heff_field(v_x1_24345, 1);
    V v_ru_24x1_24345_24MkPair = heff_take_reuse_n(v_x1_24345, 3ULL, 2);
    switch (heff_tag_of(v_x11_24346)) {
    case TAG_Left: {
      V v_e_24348 = heff_field(v_x11_24346, 0);
      heff_take_n(v_x11_24346, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24345_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24348}), v_st_24347});
    }
    case TAG_Right: {
      V v_x_24349 = heff_field(v_x11_24346, 0);
      heff_take_n(v_x11_24346, 1ULL, 1);
      V v_a_24350 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24351 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24352 = heff_get_n(v_t_24351, 4, 9);
      V v_t_24353 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24350, 3, 9), v_e_24352});
      V v_t_24354 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24349));
      return ({ V a_0 = v_ru_24x1_24345_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24353; V a_3 = v_x_24349; V a_4 = v_t_24354; V a_5 = v_st_24347; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24346);
    }
  }
  default: return heff_nomatch(v_x1_24345);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam23(V self, V *args) {
  V v_st_24361 = args[0];
  V v_m_24360 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24362 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_st_24361}));
  switch (heff_tag_of(v_x1_24362)) {
  case TAG_MkPair: {
    V v_x11_24363 = heff_field(v_x1_24362, 0);
    V v_st_24364 = heff_field(v_x1_24362, 1);
    V v_ru_24x1_24362_24MkPair = heff_take_reuse_n(v_x1_24362, 3ULL, 2);
    switch (heff_tag_of(v_x11_24363)) {
    case TAG_Left: {
      V v_e_24365 = heff_field(v_x11_24363, 0);
      heff_take_n(v_x11_24363, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24365}), v_st_24364});
    }
    case TAG_Right: {
      V v_x_24366 = heff_field(v_x11_24363, 0);
      heff_take_n(v_x11_24363, 1ULL, 1);
      V v_a_24367 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24368 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24369 = heff_get_n(v_t_24368, 4, 9);
      V v_t_24370 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24367, 3, 9), v_e_24369});
      V v_t_24371 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24366));
      return ({ V a_0 = v_ru_24x1_24362_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24370; V a_3 = v_x_24366; V a_4 = v_t_24371; V a_5 = v_st_24364; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24363);
    }
  }
  default: return heff_nomatch(v_x1_24362);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam24(V self, V *args) {
  V v_st_24374 = args[0];
  V v_m_24373 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24375 = heff_tr(heff_call(v_m_24373, 1, (V[]){v_st_24374}));
  switch (heff_tag_of(v_x1_24375)) {
  case TAG_MkPair: {
    V v_x11_24376 = heff_field(v_x1_24375, 0);
    V v_st_24377 = heff_field(v_x1_24375, 1);
    V v_ru_24x1_24375_24MkPair = heff_take_reuse_n(v_x1_24375, 3ULL, 2);
    switch (heff_tag_of(v_x11_24376)) {
    case TAG_Left: {
      V v_e_24378 = heff_field(v_x11_24376, 0);
      heff_take_n(v_x11_24376, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_24375_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24378}), v_st_24377});
    }
    case TAG_Right: {
      V v_x_24379 = heff_field(v_x11_24376, 0);
      heff_take_n(v_x11_24376, 1ULL, 1);
      V v_a_24380 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24381 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24382 = heff_get_n(v_t_24381, 4, 9);
      V v_t_24383 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24380, 3, 9), v_e_24382});
      V v_t_24384 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24379));
      return ({ V a_0 = v_ru_24x1_24375_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24383; V a_3 = v_x_24379; V a_4 = v_t_24384; V a_5 = v_st_24377; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24376);
    }
  }
  default: return heff_nomatch(v_x1_24375);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam25(V self, V *args) {
  V v_st_24390 = args[0];
  V v_m_24389 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24391 = heff_tr(heff_call(v_m_24389, 1, (V[]){v_st_24390}));
  switch (heff_tag_of(v_x1_24391)) {
  case TAG_MkPair: {
    V v_x11_24392 = heff_field(v_x1_24391, 0);
    V v_st_24393 = heff_field(v_x1_24391, 1);
    V v_ru_24x1_24391_24MkPair = heff_take_reuse_n(v_x1_24391, 3ULL, 2);
    switch (heff_tag_of(v_x11_24392)) {
    case TAG_Left: {
      V v_e_24394 = heff_field(v_x11_24392, 0);
      heff_take_n(v_x11_24392, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24391_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24394}), v_st_24393});
    }
    case TAG_Right: {
      V v_x_24395 = heff_field(v_x11_24392, 0);
      heff_take_n(v_x11_24392, 1ULL, 1);
      V v_a_24396 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24397 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24398 = heff_get_n(v_t_24397, 4, 9);
      V v_t_24399 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24396, 3, 9), v_e_24398});
      V v_t_24400 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24395));
      return ({ V a_0 = v_ru_24x1_24391_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24399; V a_3 = v_x_24395; V a_4 = v_t_24400; V a_5 = v_st_24393; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24392);
    }
  }
  default: return heff_nomatch(v_x1_24391);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam26(V self, V *args) {
  V v_st_24406 = args[0];
  V v_m_24405 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24407 = heff_tr(heff_call(v_m_24405, 1, (V[]){v_st_24406}));
  switch (heff_tag_of(v_x1_24407)) {
  case TAG_MkPair: {
    V v_x11_24408 = heff_field(v_x1_24407, 0);
    V v_st_24409 = heff_field(v_x1_24407, 1);
    V v_ru_24x1_24407_24MkPair = heff_take_reuse_n(v_x1_24407, 3ULL, 2);
    switch (heff_tag_of(v_x11_24408)) {
    case TAG_Left: {
      V v_e_24410 = heff_field(v_x11_24408, 0);
      heff_take_n(v_x11_24408, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24410}), v_st_24409});
    }
    case TAG_Right: {
      V v_x_24411 = heff_field(v_x11_24408, 0);
      heff_take_n(v_x11_24408, 1ULL, 1);
      V v_a_24412 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24413 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24414 = heff_get_n(v_t_24413, 4, 9);
      V v_t_24415 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24412, 3, 9), v_e_24414});
      V v_t_24416 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24411));
      return ({ V a_0 = v_ru_24x1_24407_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24415; V a_3 = v_x_24411; V a_4 = v_t_24416; V a_5 = v_st_24409; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24408);
    }
  }
  default: return heff_nomatch(v_x1_24407);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam27(V self, V *args) {
  V v_st_24421 = args[0];
  V v_m_24420 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24422 = heff_tr(heff_call(v_m_24420, 1, (V[]){v_st_24421}));
  switch (heff_tag_of(v_x1_24422)) {
  case TAG_MkPair: {
    V v_x11_24423 = heff_field(v_x1_24422, 0);
    V v_st_24424 = heff_field(v_x1_24422, 1);
    V v_ru_24x1_24422_24MkPair = heff_take_reuse_n(v_x1_24422, 3ULL, 2);
    switch (heff_tag_of(v_x11_24423)) {
    case TAG_Left: {
      V v_e_24425 = heff_field(v_x11_24423, 0);
      heff_take_n(v_x11_24423, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24425}), v_st_24424});
    }
    case TAG_Right: {
      V v_x_24426 = heff_field(v_x11_24423, 0);
      heff_take_n(v_x11_24423, 1ULL, 1);
      V v_a_24427 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24428 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24429 = heff_get_n(v_t_24428, 4, 9);
      V v_t_24430 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24427, 3, 9), v_e_24429});
      V v_t_24431 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24426));
      return ({ V a_0 = v_ru_24x1_24422_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24430; V a_3 = v_x_24426; V a_4 = v_t_24431; V a_5 = v_st_24424; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24423);
    }
  }
  default: return heff_nomatch(v_x1_24422);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam28(V self, V *args) {
  V v_st_24439 = args[0];
  V v_m_24438 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24440 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_st_24439}));
  switch (heff_tag_of(v_x1_24440)) {
  case TAG_MkPair: {
    V v_x11_24441 = heff_field(v_x1_24440, 0);
    V v_st_24442 = heff_field(v_x1_24440, 1);
    V v_ru_24x1_24440_24MkPair = heff_take_reuse_n(v_x1_24440, 3ULL, 2);
    switch (heff_tag_of(v_x11_24441)) {
    case TAG_Left: {
      V v_e_24443 = heff_field(v_x11_24441, 0);
      heff_take_n(v_x11_24441, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24443}), v_st_24442});
    }
    case TAG_Right: {
      V v_x_24444 = heff_field(v_x11_24441, 0);
      heff_take_n(v_x11_24441, 1ULL, 1);
      V v_a_24445 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24446 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24447 = heff_get_n(v_t_24446, 4, 9);
      V v_t_24448 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24445, 3, 9), v_e_24447});
      V v_t_24449 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24444));
      return ({ V a_0 = v_ru_24x1_24440_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24448; V a_3 = v_x_24444; V a_4 = v_t_24449; V a_5 = v_st_24442; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24441);
    }
  }
  default: return heff_nomatch(v_x1_24440);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam29(V self, V *args) {
  V v_st_24453 = args[0];
  V v_m_24452 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24454 = heff_tr(heff_call(v_m_24452, 1, (V[]){v_st_24453}));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      V v_a_24459 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24460 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24461 = heff_get_n(v_t_24460, 4, 9);
      V v_t_24462 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24459, 3, 9), v_e_24461});
      V v_t_24463 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24458));
      return ({ V a_0 = v_ru_24x1_24454_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24462; V a_3 = v_x_24458; V a_4 = v_t_24463; V a_5 = v_st_24456; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam30(V self, V *args) {
  V v_st_24468 = args[0];
  V v_m_24467 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24469 = heff_tr(heff_call(v_m_24467, 1, (V[]){v_st_24468}));
  switch (heff_tag_of(v_x1_24469)) {
  case TAG_MkPair: {
    V v_x11_24470 = heff_field(v_x1_24469, 0);
    V v_st_24471 = heff_field(v_x1_24469, 1);
    V v_ru_24x1_24469_24MkPair = heff_take_reuse_n(v_x1_24469, 3ULL, 2);
    switch (heff_tag_of(v_x11_24470)) {
    case TAG_Left: {
      V v_e_24472 = heff_field(v_x11_24470, 0);
      heff_take_n(v_x11_24470, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24472}), v_st_24471});
    }
    case TAG_Right: {
      V v_x_24473 = heff_field(v_x11_24470, 0);
      heff_take_n(v_x11_24470, 1ULL, 1);
      V v_a_24474 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24475 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24476 = heff_get_n(v_t_24475, 4, 9);
      V v_t_24477 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24474, 3, 9), v_e_24476});
      V v_t_24478 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24473));
      return ({ V a_0 = v_ru_24x1_24469_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24477; V a_3 = v_x_24473; V a_4 = v_t_24478; V a_5 = v_st_24471; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24470);
    }
  }
  default: return heff_nomatch(v_x1_24469);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam31(V self, V *args) {
  V v_st_24486 = args[0];
  V v_m_24485 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24487 = heff_tr(heff_call(v_m_24485, 1, (V[]){v_st_24486}));
  switch (heff_tag_of(v_x1_24487)) {
  case TAG_MkPair: {
    V v_x11_24488 = heff_field(v_x1_24487, 0);
    V v_st_24489 = heff_field(v_x1_24487, 1);
    V v_ru_24x1_24487_24MkPair = heff_take_reuse_n(v_x1_24487, 3ULL, 2);
    switch (heff_tag_of(v_x11_24488)) {
    case TAG_Left: {
      V v_e_24490 = heff_field(v_x11_24488, 0);
      heff_take_n(v_x11_24488, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24490}), v_st_24489});
    }
    case TAG_Right: {
      V v_x_24491 = heff_field(v_x11_24488, 0);
      heff_take_n(v_x11_24488, 1ULL, 1);
      V v_a_24492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24493 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24494 = heff_get_n(v_t_24493, 4, 9);
      V v_t_24495 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24492, 3, 9), v_e_24494});
      V v_t_24496 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24491));
      return ({ V a_0 = v_ru_24x1_24487_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24495; V a_3 = v_x_24491; V a_4 = v_t_24496; V a_5 = v_st_24489; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24488);
    }
  }
  default: return heff_nomatch(v_x1_24487);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam32(V self, V *args) {
  V v_st_24505 = args[0];
  V v_m_24504 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24506 = heff_tr(heff_call(v_m_24504, 1, (V[]){v_st_24505}));
  switch (heff_tag_of(v_x1_24506)) {
  case TAG_MkPair: {
    V v_x11_24507 = heff_field(v_x1_24506, 0);
    V v_st_24508 = heff_field(v_x1_24506, 1);
    V v_ru_24x1_24506_24MkPair = heff_take_reuse_n(v_x1_24506, 3ULL, 2);
    switch (heff_tag_of(v_x11_24507)) {
    case TAG_Left: {
      V v_e_24509 = heff_field(v_x11_24507, 0);
      heff_take_n(v_x11_24507, 1ULL, 1);
      heff_drop_tag(v_e_241, 7);
      return heff_tag_at_n(v_ru_24x1_24506_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24509}), v_st_24508});
    }
    case TAG_Right: {
      V v_x_24510 = heff_field(v_x11_24507, 0);
      heff_take_n(v_x11_24507, 1ULL, 1);
      V v_a_24511 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24512 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24513 = heff_get_n(v_t_24512, 4, 9);
      V v_t_24514 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24511, 3, 9), v_e_24513});
      V v_t_24515 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24510));
      return ({ V a_0 = v_ru_24x1_24506_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24514; V a_3 = v_x_24510; V a_4 = v_t_24515; V a_5 = v_st_24508; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24507);
    }
  }
  default: return heff_nomatch(v_x1_24506);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam33(V self, V *args) {
  V v_st_24523 = args[0];
  V v_m_24522 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24524 = heff_tr(heff_call(v_m_24522, 1, (V[]){v_st_24523}));
  switch (heff_tag_of(v_x1_24524)) {
  case TAG_MkPair: {
    V v_x11_24525 = heff_field(v_x1_24524, 0);
    V v_st_24526 = heff_field(v_x1_24524, 1);
    V v_ru_24x1_24524_24MkPair = heff_take_reuse_n(v_x1_24524, 3ULL, 2);
    switch (heff_tag_of(v_x11_24525)) {
    case TAG_Left: {
      V v_e_24527 = heff_field(v_x11_24525, 0);
      heff_take_n(v_x11_24525, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24524_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24527}), v_st_24526});
    }
    case TAG_Right: {
      V v_x_24528 = heff_field(v_x11_24525, 0);
      heff_take_n(v_x11_24525, 1ULL, 1);
      V v_a_24529 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24530 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24531 = heff_get_n(v_t_24530, 4, 9);
      V v_t_24532 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24529, 3, 9), v_e_24531});
      V v_t_24533 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24528));
      return ({ V a_0 = v_ru_24x1_24524_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24532; V a_3 = v_x_24528; V a_4 = v_t_24533; V a_5 = v_st_24526; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24525);
    }
  }
  default: return heff_nomatch(v_x1_24524);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam34(V self, V *args) {
  V v_st_24538 = args[0];
  V v_m_24537 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24539 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_st_24538}));
  switch (heff_tag_of(v_x1_24539)) {
  case TAG_MkPair: {
    V v_x11_24540 = heff_field(v_x1_24539, 0);
    V v_st_24541 = heff_field(v_x1_24539, 1);
    V v_ru_24x1_24539_24MkPair = heff_take_reuse_n(v_x1_24539, 3ULL, 2);
    switch (heff_tag_of(v_x11_24540)) {
    case TAG_Left: {
      V v_e_24542 = heff_field(v_x11_24540, 0);
      heff_take_n(v_x11_24540, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24542}), v_st_24541});
    }
    case TAG_Right: {
      V v_x_24543 = heff_field(v_x11_24540, 0);
      heff_take_n(v_x11_24540, 1ULL, 1);
      V v_a_24544 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24545 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24546 = heff_get_n(v_t_24545, 4, 9);
      V v_t_24547 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24544, 3, 9), v_e_24546});
      V v_t_24548 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24543));
      return ({ V a_0 = v_ru_24x1_24539_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24547; V a_3 = v_x_24543; V a_4 = v_t_24548; V a_5 = v_st_24541; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24540);
    }
  }
  default: return heff_nomatch(v_x1_24539);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam35(V self, V *args) {
  V v_st_24554 = args[0];
  V v_m_24553 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24555 = heff_tr(heff_call(v_m_24553, 1, (V[]){v_st_24554}));
  switch (heff_tag_of(v_x1_24555)) {
  case TAG_MkPair: {
    V v_x11_24556 = heff_field(v_x1_24555, 0);
    V v_st_24557 = heff_field(v_x1_24555, 1);
    V v_ru_24x1_24555_24MkPair = heff_take_reuse_n(v_x1_24555, 3ULL, 2);
    switch (heff_tag_of(v_x11_24556)) {
    case TAG_Left: {
      V v_e_24558 = heff_field(v_x11_24556, 0);
      heff_take_n(v_x11_24556, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24555_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24558}), v_st_24557});
    }
    case TAG_Right: {
      V v_x_24559 = heff_field(v_x11_24556, 0);
      heff_take_n(v_x11_24556, 1ULL, 1);
      V v_a_24560 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24561 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24562 = heff_get_n(v_t_24561, 4, 9);
      V v_t_24563 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24560, 3, 9), v_e_24562});
      V v_t_24564 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24559));
      return ({ V a_0 = v_ru_24x1_24555_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24563; V a_3 = v_x_24559; V a_4 = v_t_24564; V a_5 = v_st_24557; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24556);
    }
  }
  default: return heff_nomatch(v_x1_24555);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam36(V self, V *args) {
  V v_st_24572 = args[0];
  V v_m_24571 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24573 = heff_tr(heff_call(v_m_24571, 1, (V[]){v_st_24572}));
  switch (heff_tag_of(v_x1_24573)) {
  case TAG_MkPair: {
    V v_x11_24574 = heff_field(v_x1_24573, 0);
    V v_st_24575 = heff_field(v_x1_24573, 1);
    V v_ru_24x1_24573_24MkPair = heff_take_reuse_n(v_x1_24573, 3ULL, 2);
    switch (heff_tag_of(v_x11_24574)) {
    case TAG_Left: {
      V v_e_24576 = heff_field(v_x11_24574, 0);
      heff_take_n(v_x11_24574, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24576}), v_st_24575});
    }
    case TAG_Right: {
      V v_x_24577 = heff_field(v_x11_24574, 0);
      heff_take_n(v_x11_24574, 1ULL, 1);
      V v_a_24578 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24579 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24580 = heff_get_n(v_t_24579, 4, 9);
      V v_t_24581 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24578, 3, 9), v_e_24580});
      V v_t_24582 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24577));
      return ({ V a_0 = v_ru_24x1_24573_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24581; V a_3 = v_x_24577; V a_4 = v_t_24582; V a_5 = v_st_24575; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24574);
    }
  }
  default: return heff_nomatch(v_x1_24573);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam37(V self, V *args) {
  V v_st_24585 = args[0];
  V v_m_24584 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24586 = heff_tr(heff_call(v_m_24584, 1, (V[]){v_st_24585}));
  switch (heff_tag_of(v_x1_24586)) {
  case TAG_MkPair: {
    V v_x11_24587 = heff_field(v_x1_24586, 0);
    V v_st_24588 = heff_field(v_x1_24586, 1);
    V v_ru_24x1_24586_24MkPair = heff_take_reuse_n(v_x1_24586, 3ULL, 2);
    switch (heff_tag_of(v_x11_24587)) {
    case TAG_Left: {
      V v_e_24589 = heff_field(v_x11_24587, 0);
      heff_take_n(v_x11_24587, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_24586_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24589}), v_st_24588});
    }
    case TAG_Right: {
      V v_x_24590 = heff_field(v_x11_24587, 0);
      heff_take_n(v_x11_24587, 1ULL, 1);
      V v_a_24591 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24592 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24593 = heff_get_n(v_t_24592, 4, 9);
      V v_t_24594 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24591, 3, 9), v_e_24593});
      V v_t_24595 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24590));
      return ({ V a_0 = v_ru_24x1_24586_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24594; V a_3 = v_x_24590; V a_4 = v_t_24595; V a_5 = v_st_24588; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24587);
    }
  }
  default: return heff_nomatch(v_x1_24586);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam38(V self, V *args) {
  V v_st_24599 = args[0];
  V v_m_24598 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24600 = heff_tr(heff_call(v_m_24598, 1, (V[]){v_st_24599}));
  switch (heff_tag_of(v_x1_24600)) {
  case TAG_MkPair: {
    V v_x11_24601 = heff_field(v_x1_24600, 0);
    V v_st_24602 = heff_field(v_x1_24600, 1);
    V v_ru_24x1_24600_24MkPair = heff_take_reuse_n(v_x1_24600, 3ULL, 2);
    switch (heff_tag_of(v_x11_24601)) {
    case TAG_Left: {
      V v_e_24603 = heff_field(v_x11_24601, 0);
      heff_take_n(v_x11_24601, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24600_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24603}), v_st_24602});
    }
    case TAG_Right: {
      V v_x_24604 = heff_field(v_x11_24601, 0);
      heff_take_n(v_x11_24601, 1ULL, 1);
      V v_a_24605 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24606 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24607 = heff_get_n(v_t_24606, 4, 9);
      V v_t_24608 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24605, 3, 9), v_e_24607});
      V v_t_24609 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24604));
      return ({ V a_0 = v_ru_24x1_24600_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24608; V a_3 = v_x_24604; V a_4 = v_t_24609; V a_5 = v_st_24602; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24601);
    }
  }
  default: return heff_nomatch(v_x1_24600);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam39(V self, V *args) {
  V v_st_24615 = args[0];
  V v_m_24614 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24616 = heff_tr(heff_call(v_m_24614, 1, (V[]){v_st_24615}));
  switch (heff_tag_of(v_x1_24616)) {
  case TAG_MkPair: {
    V v_x11_24617 = heff_field(v_x1_24616, 0);
    V v_st_24618 = heff_field(v_x1_24616, 1);
    V v_ru_24x1_24616_24MkPair = heff_take_reuse_n(v_x1_24616, 3ULL, 2);
    switch (heff_tag_of(v_x11_24617)) {
    case TAG_Left: {
      V v_e_24619 = heff_field(v_x11_24617, 0);
      heff_take_n(v_x11_24617, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24616_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24619}), v_st_24618});
    }
    case TAG_Right: {
      V v_x_24620 = heff_field(v_x11_24617, 0);
      heff_take_n(v_x11_24617, 1ULL, 1);
      V v_a_24621 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24622 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24623 = heff_get_n(v_t_24622, 4, 9);
      V v_t_24624 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24621, 3, 9), v_e_24623});
      V v_t_24625 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24620));
      return ({ V a_0 = v_ru_24x1_24616_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24624; V a_3 = v_x_24620; V a_4 = v_t_24625; V a_5 = v_st_24618; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24617);
    }
  }
  default: return heff_nomatch(v_x1_24616);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam40(V self, V *args) {
  V v_st_24629 = args[0];
  V v_m_24628 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24630 = heff_tr(heff_call(v_m_24628, 1, (V[]){v_st_24629}));
  switch (heff_tag_of(v_x1_24630)) {
  case TAG_MkPair: {
    V v_x11_24631 = heff_field(v_x1_24630, 0);
    V v_st_24632 = heff_field(v_x1_24630, 1);
    V v_ru_24x1_24630_24MkPair = heff_take_reuse_n(v_x1_24630, 3ULL, 2);
    switch (heff_tag_of(v_x11_24631)) {
    case TAG_Left: {
      V v_e_24633 = heff_field(v_x11_24631, 0);
      heff_take_n(v_x11_24631, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24630_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24633}), v_st_24632});
    }
    case TAG_Right: {
      V v_x_24634 = heff_field(v_x11_24631, 0);
      heff_take_n(v_x11_24631, 1ULL, 1);
      V v_a_24635 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24636 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24637 = heff_get_n(v_t_24636, 4, 9);
      V v_t_24638 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24635, 3, 9), v_e_24637});
      V v_t_24639 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24634));
      return ({ V a_0 = v_ru_24x1_24630_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24638; V a_3 = v_x_24634; V a_4 = v_t_24639; V a_5 = v_st_24632; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24631);
    }
  }
  default: return heff_nomatch(v_x1_24630);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam41(V self, V *args) {
  V v_st_24645 = args[0];
  V v_m_24644 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24646 = heff_tr(heff_call(v_m_24644, 1, (V[]){v_st_24645}));
  switch (heff_tag_of(v_x1_24646)) {
  case TAG_MkPair: {
    V v_x11_24647 = heff_field(v_x1_24646, 0);
    V v_st_24648 = heff_field(v_x1_24646, 1);
    V v_ru_24x1_24646_24MkPair = heff_take_reuse_n(v_x1_24646, 3ULL, 2);
    switch (heff_tag_of(v_x11_24647)) {
    case TAG_Left: {
      V v_e_24649 = heff_field(v_x11_24647, 0);
      heff_take_n(v_x11_24647, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24649}), v_st_24648});
    }
    case TAG_Right: {
      V v_x_24650 = heff_field(v_x11_24647, 0);
      heff_take_n(v_x11_24647, 1ULL, 1);
      V v_a_24651 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24652 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24653 = heff_get_n(v_t_24652, 4, 9);
      V v_t_24654 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24651, 3, 9), v_e_24653});
      V v_t_24655 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24650));
      return ({ V a_0 = v_ru_24x1_24646_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24654; V a_3 = v_x_24650; V a_4 = v_t_24655; V a_5 = v_st_24648; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24647);
    }
  }
  default: return heff_nomatch(v_x1_24646);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam42(V self, V *args) {
  V v_st_24661 = args[0];
  V v_m_24660 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24662 = heff_tr(heff_call(v_m_24660, 1, (V[]){v_st_24661}));
  switch (heff_tag_of(v_x1_24662)) {
  case TAG_MkPair: {
    V v_x11_24663 = heff_field(v_x1_24662, 0);
    V v_st_24664 = heff_field(v_x1_24662, 1);
    V v_ru_24x1_24662_24MkPair = heff_take_reuse_n(v_x1_24662, 3ULL, 2);
    switch (heff_tag_of(v_x11_24663)) {
    case TAG_Left: {
      V v_e_24665 = heff_field(v_x11_24663, 0);
      heff_take_n(v_x11_24663, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24665}), v_st_24664});
    }
    case TAG_Right: {
      V v_x_24666 = heff_field(v_x11_24663, 0);
      heff_take_n(v_x11_24663, 1ULL, 1);
      V v_a_24667 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24668 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24669 = heff_get_n(v_t_24668, 4, 9);
      V v_t_24670 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24667, 3, 9), v_e_24669});
      V v_t_24671 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24666));
      return ({ V a_0 = v_ru_24x1_24662_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24670; V a_3 = v_x_24666; V a_4 = v_t_24671; V a_5 = v_st_24664; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24663);
    }
  }
  default: return heff_nomatch(v_x1_24662);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam43(V self, V *args) {
  V v_st_24677 = args[0];
  V v_m_24676 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24678 = heff_tr(heff_call(v_m_24676, 1, (V[]){v_st_24677}));
  switch (heff_tag_of(v_x1_24678)) {
  case TAG_MkPair: {
    V v_x11_24679 = heff_field(v_x1_24678, 0);
    V v_st_24680 = heff_field(v_x1_24678, 1);
    V v_ru_24x1_24678_24MkPair = heff_take_reuse_n(v_x1_24678, 3ULL, 2);
    switch (heff_tag_of(v_x11_24679)) {
    case TAG_Left: {
      V v_e_24681 = heff_field(v_x11_24679, 0);
      heff_take_n(v_x11_24679, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24678_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24681}), v_st_24680});
    }
    case TAG_Right: {
      V v_x_24682 = heff_field(v_x11_24679, 0);
      heff_take_n(v_x11_24679, 1ULL, 1);
      V v_a_24683 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24684 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24685 = heff_get_n(v_t_24684, 4, 9);
      V v_t_24686 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24683, 3, 9), v_e_24685});
      V v_t_24687 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24682));
      return ({ V a_0 = v_ru_24x1_24678_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24686; V a_3 = v_x_24682; V a_4 = v_t_24687; V a_5 = v_st_24680; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24679);
    }
  }
  default: return heff_nomatch(v_x1_24678);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam44(V self, V *args) {
  V v_st_24695 = args[0];
  V v_m_24694 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24696 = heff_tr(heff_call(v_m_24694, 1, (V[]){v_st_24695}));
  switch (heff_tag_of(v_x1_24696)) {
  case TAG_MkPair: {
    V v_x11_24697 = heff_field(v_x1_24696, 0);
    V v_st_24698 = heff_field(v_x1_24696, 1);
    V v_ru_24x1_24696_24MkPair = heff_take_reuse_n(v_x1_24696, 3ULL, 2);
    switch (heff_tag_of(v_x11_24697)) {
    case TAG_Left: {
      V v_e_24699 = heff_field(v_x11_24697, 0);
      heff_take_n(v_x11_24697, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24696_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24699}), v_st_24698});
    }
    case TAG_Right: {
      V v_x_24700 = heff_field(v_x11_24697, 0);
      heff_take_n(v_x11_24697, 1ULL, 1);
      V v_a_24701 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24702 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24703 = heff_get_n(v_t_24702, 4, 9);
      V v_t_24704 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24701, 3, 9), v_e_24703});
      V v_t_24705 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24700));
      return ({ V a_0 = v_ru_24x1_24696_24MkPair; V b_1 = NTAG(TAG_False); V a_2 = v_t_24704; V a_3 = v_x_24700; V a_4 = v_t_24705; V a_5 = v_st_24698; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok2(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x11_24697);
    }
  }
  default: return heff_nomatch(v_x1_24696);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str4, 3, "int");
Clo g_heff_2esyntax_2esurface_2esegmentValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentValue_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esegmentValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    return NTAG(TAG_False);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_x1_240, 0);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_243, 0))}));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str0), NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str2), v_t_245})});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str4), v_t_246})});
    return ({ V a_0 = v_t_244; V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
  }
  case TAG_PParen: {
    V v_p_249 = heff_field(v_x1_240, 1);
    V t_0 = v_p_249;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PList: {
    return NTAG(TAG_False);
  }
  case TAG_POp: {
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    return NTAG(TAG_False);
  }
  case TAG_PField: {
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    return NTAG(TAG_False);
  }
  case TAG_PSeg: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str1, 1, "(");
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamOf(V v_r_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(heff_dup(v_e_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_f_245 = v_field_244;
      V v_m_246 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_245));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam0, 1, 2, (V[]){v_m_246, v_e_241});
    } else {
      heff_drop(v_field_244);
      V v_m_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam1, 1, 2, (V[]){v_m_2428, v_e_241});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      HeffT2 v_t_2413 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(heff_dup(v_x_2412)));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_x_2412);
          V v_q_2416 = v_field_2415;
          V v_name_2417 = heff_take_field(v_q_2416, 0);
          V v_span_2418 = heff_take_field(v_q_2416, 1);
          V v_ty_2419 = heff_get_n(v_q_2416, 2, 3);
          V v_a_2420 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
          V v_b_2421 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2420, 3, 9), heff_get_n(v_b_2421, 4, 9)});
          V v_x_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_name_2417, v_span_2418, v_ty_2419}), v_t_2422});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2423}), v_st_2410});
        } else {
          heff_drop(v_e_241);
          heff_drop(v_field_2415);
          V v_t_2426;
          switch (heff_tag_of(v_x_2412)) {
          case TAG_At: {
            V v_s_2425 = heff_field(v_x_2412, 1);
            heff_take_n(v_x_2412, 2ULL, 2);
            v_t_2426 = v_s_2425;
            break;
          }
          default: heff_nomatch(v_x_2412);
          }
          V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str0), v_t_2426, NTAG(TAG_Nothing)});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2427}), v_st_2410});
        }
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args) {
  V v_st_2437 = args[0];
  V v_x_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2437});
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args) {
  V v_st_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_st_2429}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_MkPair: {
    V v_x11_2431 = heff_field(v_x1_2430, 0);
    V v_st_2432 = heff_field(v_x1_2430, 1);
    V v_ru_24x1_2430_24MkPair = heff_take_reuse_n(v_x1_2430, 3ULL, 2);
    switch (heff_tag_of(v_x11_2431)) {
    case TAG_Left: {
      V v_e_2433 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2433}), v_st_2432});
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      V v_t_2435 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
      V v_m_2438;
      if (heff_strEq_c(heff_get_n(v_t_2435, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str1))) {
        V v_t_2436 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2434));
        v_m_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2436}));
      } else {
        v_m_2438 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam2, 1, 1, (V[]){v_x_2434});
      }
      V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_st_2432}));
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_MkPair: {
        V v_x11_2440 = heff_field(v_x1_2439, 0);
        V v_st_2441 = heff_field(v_x1_2439, 1);
        heff_take_n(v_x1_2439, 3ULL, 2);
        switch (heff_tag_of(v_x11_2440)) {
        case TAG_Left: {
          V v_e_2442 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
        }
        case TAG_Right: {
          V v_x_2443 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          return (g_heff_2esyntax_2esurface_2eparamOf_24tok2(v_ru_24x1_2430_24MkPair, v_x_2443, v_st_2441));
        }
        default: return heff_nomatch(v_x11_2440);
        }
      }
      default: return heff_nomatch(v_x1_2439);
      }
    }
    default: return heff_nomatch(v_x11_2431);
    }
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualBody_str0, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualBody_str1, 7, "#mutual");
Clo g_heff_2esyntax_2esurface_2emutualBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualBody_entry, 3, 0};

V g_heff_2esyntax_2esurface_2emutualBody(V v_tyE_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_d_242, 0)), ((V)&g_heff_2esyntax_2esurface_2emutualBody_str0));
  V v_t_244 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_tyE_240}), heff_dup(heff_rfield(v_d_242, 2))});
  V v_t_245 = heff_dup(heff_rfield(v_d_242, 2));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_At: {
    V v_s_247 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 2ULL, 2);
    v_t_248 = v_s_247;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_249 = (g_list_2emap_24s892909862x1245535974(heff_dup(v_d_242), ((V)&g_heff_2esyntax_2esurface_2emutualBody_str1), v_k_241, heff_dup(heff_rfield(v_d_242, 3))));
  V v_t_2410 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_t_243, heff_take_field(v_d_242, 1), NTAG(TAG_AsDefinition), heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_t_248}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_get_n(v_d_242, 4, 5)});
  return heff_tag_n(TAG_Whole, 1, (V[]){v_t_2411});
}
V g_heff_2esyntax_2esurface_2emutualBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualBody(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2esurface_2eedgesOf(heff_dup(v_lit_240), heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_lit_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2elineColFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elineColFrom_entry, 4, 0};

V g_heff_2esyntax_2esurface_2elineColFrom(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str0), v_src_240, v_start_243, 1);
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    V v_t_245 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
    V v_t_246 = heff_intShow(heff_intAdd(v_t_245, MK_INT(1LL)));
    return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str1), v_t_246));
  } else {
    if (heff_intLt_c_lent(v_j_244, v_i_241, 0)) {
      heff_drop(v_start_243);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_j_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    } else {
      heff_drop(v_j_244);
      V v_t_247 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
      V v_t_248 = heff_intShow(heff_intAdd(v_t_247, MK_INT(1LL)));
      return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str2), v_t_248));
    }
  }
}
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2elineColFrom(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2enoKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enoKnown_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enoKnown(V v_x_240) {
top: ;
  return NTAG(TAG_False);
}
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enoKnown(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2(V v_tok_240, V v_e0_241, V v_rest_242, V v_st_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_243, 5));
  V v_t_245 = heff_dup(heff_rfield(v_st_243, 6));
  V v_m_246 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_244), v_t_245, heff_dup(v_rest_242)));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_e0_241);
      heff_drop(v_rest_242);
      heff_drop(v_t_244);
      heff_drop(v_t_245);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      heff_take_n(v_x11_248, 0ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_e0_241), NTAG(TAG_Nil)});
      V v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2412});
      V v_m_2414 = ({ V a_0 = v_t_244; V a_1 = v_t_245; V a_2 = v_t_2413; V a_3 = v_rest_242; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
      V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop(v_e0_241);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          V v_st_2420 = (g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(v_x_2419));
          V v_t_2421 = heff_get_n(v_st_2420, 1, 2);
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            v_t_2424 = v_e0_241;
            break;
          }
          case TAG_Cons: {
            V v_x_2422 = heff_field(v_t_2421, 0);
            heff_take_n(v_t_2421, 1ULL, 2);
            heff_drop(v_e0_241);
            v_t_2424 = v_x_2422;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2424}), v_st_2417});
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2(a[0], a[1], a[2], a[3]);
}