// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclPrimitive 46335
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_binder 558177493
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2earrowAfter(V, V);
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowAfter_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edigitsVal(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edigitsVal_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
V g_heff_2esyntax_2esurface_2eemptySpec_get(void);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efitsIn(V, V, V, V);
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efitsIn_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str0, 2, "0x");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str1, 2, "0X");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str2, 2, "0b");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str3, 2, "0B");
Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emagnitudeOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emagnitudeOf(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
  V v_t_245 = heff_bool((heff_strEq_c_lent(v_t_242, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str0), 2) || ({ V v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))); int c_ = heff_strEq_c_lent(v_t_244, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str1), 2); heff_drop(v_t_244); c_; })));
  heff_drop(v_t_242);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(16LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
  } else {
    heff_drop(v_t_245);
    V v_t_246 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str2))) {
      return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
    } else {
      V v_t_248 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str3))) {
        return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
      } else {
        return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(10LL), heff_dup(v_s_240), v_i_241, heff_strLength(v_s_240), MK_INT(0LL)));
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emagnitudeOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eboundBy(V v_pv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_243 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_243);
  }
  case TAG_PAtom: {
    V v_t_245 = heff_field(v_x2_241, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str2))) {
          V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_245, 1))}));
          V v_t_2410 = (g_list_2eany(v_t_249, v_pv_240));
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop(v_t_2410);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
          } else {
            heff_drop(v_t_2410);
            return NTAG(TAG_Nil);
          }
        } else {
          return NTAG(TAG_Nil);
        }
      } else {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str3))) {
        V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_245, 1))}));
        V v_t_2413 = (g_list_2eany(v_t_2412, v_pv_240));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2413);
          return NTAG(TAG_Nil);
        }
      } else {
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2415 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2415;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2418 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2418);
  }
  case TAG_POp: {
    V v_l_2422 = heff_field(v_x2_241, 0);
    V v_q_2424 = heff_field(v_x2_241, 2);
    V v_t_2425 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2422));
    V v_t_2426 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2424));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2425, v_t_2426);
  }
  case TAG_PRec: {
    V v_fs_2428 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2428);
  }
  case TAG_PField: {
    V v_q_2434 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2434;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2435 = heff_field(v_x2_241, 0);
    V v_q_2437 = heff_field(v_x2_241, 2);
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2435, 1)), heff_hole()});
    V v_u_2439 = (g_heff_2esyntax_2esurface_2eboundBy_24dps(v_pv_240, v_q_2437, heff_dup(v_cell_2438)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  case TAG_PSeg: {
    V v_q_2440 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2440;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args) {
  V v_q_244 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_244); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args) {
  V v_q_2421 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2421; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2421); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args) {
  V v_q_2431 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2431; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2431); r_; });
}
Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisNameE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowAfter_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowAfter_str1, 2, "->");
Clo g_heff_2esyntax_2esurface_2earrowAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowAfter_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowAfter(V v_s_240, V v_t_241) {
top: ;
  V v_xs_242 = heff_get_n(v_s_240, 0, 8);
  V v_i_243 = heff_intAdd(heff_get_n(v_t_241, 7, 9), MK_INT(1LL));
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(v_i_243)) && (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength_lent(v_xs_242, 0)) && ({ V v_u_246 = heff_arrayIndex_lent(v_xs_242, v_i_243, 0); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_u_246, 0)), ((V)&g_heff_2esyntax_2esurface_2earrowAfter_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_u_246, 1)), ((V)&g_heff_2esyntax_2esurface_2earrowAfter_str1))); heff_drop(v_u_246); c_; }))));
  heff_drop(v_xs_242);
  heff_drop(v_i_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowAfter(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(v_z_240, v_xs_243));
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_a_244)});
    V v_t_246 = heff_get_n(heff_get_n(v_x_242, 1, 2), 0, 2);
    V v_t_249;
    switch (heff_tag_of(v_a_244)) {
    case TAG_At: {
      V v_a_248 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_t_2410 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_t_2410});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efoldr_24s942751315x429561917(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2efitsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efitsIn_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efitsIn(V v_x1_240, V v_signed_241, V v_n_242, V v_v_243) {
top: ;
  V v_ret_24bool = heff_bool(((heff_dup(v_x1_240) == NTAG(TAG_True)) ? ((heff_dup(v_signed_241) == NTAG(TAG_True)) ? ({ V v_t_244 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(heff_dup(v_n_242), MK_INT(1LL)))); int c_ = (heff_intLe_c(heff_intSub(MK_INT(0LL), heff_dup(v_t_244)), heff_dup(v_v_243)) && ({ V v_t_246 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(heff_dup(v_n_242), MK_INT(1LL)))); int c_ = heff_intLt_c(heff_dup(v_v_243), heff_dup(v_t_246)); heff_drop(v_t_246); c_; })); heff_drop(v_t_244); c_; }) : (heff_intLe_c(MK_INT(0LL), heff_dup(v_v_243)) && ({ V v_t_248 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_242))); int c_ = heff_intLt_c(heff_dup(v_v_243), heff_dup(v_t_248)); heff_drop(v_t_248); c_; }))) : ({ V v_t_249 = (g_heff_2esyntax_2esurface_2etwoToS(heff_intSub(heff_dup(v_n_242), MK_INT(1LL)))); int c_ = (heff_intLe_c(heff_intSub(MK_INT(0LL), heff_dup(v_t_249)), heff_dup(v_v_243)) && ({ V v_t_2411 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_242))); int c_ = heff_intLt_c(heff_dup(v_v_243), heff_dup(v_t_2411)); heff_drop(v_t_2411); c_; })); heff_drop(v_t_249); c_; })));
  heff_drop(v_n_242);
  heff_drop(v_v_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2efitsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efitsIn(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str0, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str1, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str2, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str3, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str4, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str5, 51, "a float's size is a number, 32 or 64: `x::float-32`");
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15, 1, 0};
Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry, 5, 0};

V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V v_inPat_240, V v_sp_241, V v_v_242, V v_x5_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SegmentInteger: {
    V v_t_249;
    switch (heff_tag_of(v_x6_244)) {
    case TAG_SizeDefault: {
      v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_245 = heff_field(v_x6_244, 0);
      V v_ru_24x6_244_24SizeNumber = heff_take_reuse_n(v_x6_244, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24x6_244_24SizeNumber, TAG_Just, 1, (V[]){v_n_245});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_244, 0ULL, 3);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_244);
    }
    return (g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(v_inPat_240, v_sp_241, v_v_242, v_t_249));
  }
  case TAG_SegmentBinary: {
    heff_drop(v_x6_244);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      heff_drop(v_sp_241);
      return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0_clo);
    }
    case TAG_IntValue: {
      heff_take_n(v_v_242, 0ULL, 1);
      if (heff_intEq_c(heff_intMod(MK_INT(8LL), MK_INT(8LL)), MK_INT(0LL))) {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1_clo);
      } else {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2, 1, 1, (V[]){v_sp_241});
      }
    }
    case TAG_FloatValue: {
      if (heff_intEq_c(heff_intMod(MK_INT(8LL), MK_INT(8LL)), MK_INT(0LL))) {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3_clo);
      } else {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4, 1, 1, (V[]){v_sp_241});
      }
    }
    case TAG_RuneValue: {
      if (heff_intEq_c(heff_intMod(MK_INT(8LL), MK_INT(8LL)), MK_INT(0LL))) {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5_clo);
      } else {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6, 1, 1, (V[]){v_sp_241});
      }
    }
    case TAG_OtherValue: {
      if (heff_intEq_c(heff_intMod(MK_INT(8LL), MK_INT(8LL)), MK_INT(0LL))) {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7_clo);
      } else {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8, 1, 1, (V[]){v_sp_241});
      }
    }
    default: return heff_nomatch(v_v_242);
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_x6_244);
    return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9_clo);
  }
  case TAG_SegmentFloat: {
    heff_drop(v_v_242);
    switch (heff_tag_of(v_x6_244)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10_clo);
    }
    case TAG_SizeNumber: {
      V v_x61_2437 = heff_field(v_x6_244, 0);
      heff_take_n(v_x6_244, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_x61_2437), MK_INT(64LL))) {
        heff_drop(v_sp_241);
        heff_drop(v_x61_2437);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11_clo);
      } else {
        if (heff_intEq_c(heff_dup(v_x61_2437), MK_INT(32LL))) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2437);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12_clo);
        } else {
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam13, 1, 2, (V[]){v_x61_2437, v_sp_241});
        }
      }
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_244, 0ULL, 3);
      return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam14, 1, 1, (V[]){v_sp_241});
    }
    default: return heff_nomatch(v_x6_244);
    }
  }
  case TAG_SegmentUtf: {
    heff_take_n(v_x5_243, 0ULL, 1);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_x6_244);
    return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15_clo);
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam0(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_t_2415 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_p_2414});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str0), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam3(V self, V *args) {
  V v_p_2419 = args[0];
  V v_t_2420 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_p_2419});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam4(V self, V *args) {
  V v_st_2421 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str1), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2422}), v_st_2421});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam5(V self, V *args) {
  V v_p_2424 = args[0];
  V v_t_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_p_2424});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam6(V self, V *args) {
  V v_st_2426 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str2), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2427}), v_st_2426});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam7(V self, V *args) {
  V v_p_2429 = args[0];
  V v_t_2430 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_p_2429});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam8(V self, V *args) {
  V v_st_2431 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str3), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2431});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam9(V self, V *args) {
  V v_p_2433 = args[0];
  V v_t_2434 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_p_2433});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam10(V self, V *args) {
  V v_st_2435 = args[0];
  V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_st_2435});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam11(V self, V *args) {
  V v_st_2439 = args[0];
  V v_t_2440 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_st_2439});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam12(V self, V *args) {
  V v_st_2442 = args[0];
  V v_t_2443 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_st_2442});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam13(V self, V *args) {
  V v_st_2444 = args[0];
  V v_x61_2437 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str4), heff_intShow(v_x61_2437));
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2445, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2446}), v_st_2444});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam14(V self, V *args) {
  V v_st_2450 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_str5), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2451}), v_st_2450});
}
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_lam15(V self, V *args) {
  V v_st_2453 = args[0];
  V v_t_2454 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2454, v_st_2453});
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esegmentL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esegmentL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam0, 1, 2, (V[]){v_m_243, v_e_241});
  }
  case TAG_EParen: {
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam1, 1, 2, (V[]){v_m_2418, v_e_241});
  }
  case TAG_Named: {
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam2, 1, 2, (V[]){v_m_2435, v_e_241});
  }
  case TAG_Tup: {
    V v_m_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam3, 1, 2, (V[]){v_m_2451, v_e_241});
  }
  case TAG_Seg: {
    V v_v_2463 = heff_field(v_e_241, 0);
    V v_cc_2464 = heff_field(v_e_241, 1);
    V v_spec_2465 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_v_2463)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam4, 1, 4, (V[]){v_m_2466, v_cc_2464, v_spec_2465, v_v_2463});
  }
  case TAG_Braces: {
    V v_m_2490 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam5, 1, 2, (V[]){v_m_2490, v_e_241});
  }
  case TAG_Update: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam6, 1, 2, (V[]){v_m_24108, v_e_241});
  }
  case TAG_EUSet: {
    V v_m_24123 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam7, 1, 2, (V[]){v_m_24123, v_e_241});
  }
  case TAG_InstB: {
    V v_m_24140 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam8, 1, 2, (V[]){v_m_24140, v_e_241});
  }
  case TAG_EFSet: {
    V v_m_24155 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam9, 1, 2, (V[]){v_m_24155, v_e_241});
  }
  case TAG_EFDefault: {
    V v_m_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam10, 1, 2, (V[]){v_m_24170, v_e_241});
  }
  case TAG_Sum: {
    V v_m_24187 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam11, 1, 2, (V[]){v_m_24187, v_e_241});
  }
  case TAG_ECon: {
    V v_m_24201 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam12, 1, 2, (V[]){v_m_24201, v_e_241});
  }
  case TAG_EField: {
    V v_m_24215 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam13, 1, 2, (V[]){v_m_24215, v_e_241});
  }
  case TAG_ENeg: {
    V v_m_24229 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam14, 1, 2, (V[]){v_m_24229, v_e_241});
  }
  case TAG_App: {
    V v_m_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam15, 1, 2, (V[]){v_m_24243, v_e_241});
  }
  case TAG_Op: {
    V v_m_24258 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam16, 1, 2, (V[]){v_m_24258, v_e_241});
  }
  case TAG_Ops: {
    V v_m_24272 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam17, 1, 2, (V[]){v_m_24272, v_e_241});
  }
  case TAG_OpRhs: {
    V v_m_24286 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam18, 1, 2, (V[]){v_m_24286, v_e_241});
  }
  case TAG_Ann: {
    V v_m_24301 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam19, 1, 2, (V[]){v_m_24301, v_e_241});
  }
  case TAG_BVar: {
    V v_m_24314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam20, 1, 2, (V[]){v_m_24314, v_e_241});
  }
  case TAG_BImp: {
    V v_m_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam21, 1, 2, (V[]){v_m_24329, v_e_241});
  }
  case TAG_BAnn: {
    V v_m_24346 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam22, 1, 2, (V[]){v_m_24346, v_e_241});
  }
  case TAG_Lam: {
    V v_m_24362 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam23, 1, 2, (V[]){v_m_24362, v_e_241});
  }
  case TAG_Case: {
    V v_m_24378 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam24, 1, 2, (V[]){v_m_24378, v_e_241});
  }
  case TAG_EAlt: {
    V v_m_24393 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam25, 1, 2, (V[]){v_m_24393, v_e_241});
  }
  case TAG_If: {
    V v_m_24411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam26, 1, 2, (V[]){v_m_24411, v_e_241});
  }
  case TAG_Do: {
    V v_m_24425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam27, 1, 2, (V[]){v_m_24425, v_e_241});
  }
  case TAG_ESBind: {
    V v_m_24440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam28, 1, 2, (V[]){v_m_24440, v_e_241});
  }
  case TAG_ELet: {
    V v_m_24458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam29, 1, 2, (V[]){v_m_24458, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esegmentL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V v_a_2410 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2410, 3, 9), v_e_2412});
      V v_t_2414 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_249));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2413; V a_2 = v_x_249; V a_3 = v_t_2414; V a_4 = v_st_247; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args) {
  V v_st_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_st_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_MkPair: {
    V v_x11_2421 = heff_field(v_x1_2420, 0);
    V v_st_2422 = heff_field(v_x1_2420, 1);
    V v_ru_24x1_2420_24MkPair = heff_take_reuse_n(v_x1_2420, 3ULL, 2);
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2420_24MkPair, 2);
      V v_a_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2426 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2427 = heff_get_n(v_t_2426, 4, 9);
      V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2425, 3, 9), v_e_2427});
      V v_t_2429 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2424));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2428; V a_2 = v_x_2424; V a_3 = v_t_2429; V a_4 = v_st_2422; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_st_2436}));
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_MkPair: {
    V v_x11_2438 = heff_field(v_x1_2437, 0);
    V v_st_2439 = heff_field(v_x1_2437, 1);
    V v_ru_24x1_2437_24MkPair = heff_take_reuse_n(v_x1_2437, 3ULL, 2);
    switch (heff_tag_of(v_x11_2438)) {
    case TAG_Left: {
      V v_e_2440 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
    }
    case TAG_Right: {
      V v_x_2441 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2437_24MkPair, 2);
      V v_a_2442 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2443 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2444 = heff_get_n(v_t_2443, 4, 9);
      V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2442, 3, 9), v_e_2444});
      V v_t_2446 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2441));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2445; V a_2 = v_x_2441; V a_3 = v_t_2446; V a_4 = v_st_2439; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_2438);
    }
  }
  default: return heff_nomatch(v_x1_2437);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam3(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24MkPair, 2);
      V v_a_2458 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2459 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2460 = heff_get_n(v_t_2459, 4, 9);
      V v_t_2461 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2458, 3, 9), v_e_2460});
      V v_t_2462 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2457));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2461; V a_2 = v_x_2457; V a_3 = v_t_2462; V a_4 = v_st_2455; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam4(V self, V *args) {
  V v_st_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_cc_2464 = heff_env(self)[1];
  V v_spec_2465 = heff_env(self)[2];
  V v_v_2463 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_st_2467}));
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_MkPair: {
    V v_x11_2469 = heff_field(v_x1_2468, 0);
    V v_st_2470 = heff_field(v_x1_2468, 1);
    V v_ru_24x1_2468_24MkPair = heff_take_reuse_n(v_x1_2468, 3ULL, 2);
    switch (heff_tag_of(v_x11_2469)) {
    case TAG_Left: {
      V v_e_2471 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      heff_drop_rec(v_cc_2464, 9);
      heff_drop(v_spec_2465);
      heff_drop(v_v_2463);
      return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2471}), v_st_2470});
    }
    case TAG_Right: {
      V v_x_2472 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      V v_t_2473 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_cc_2464, 3)), heff_dup(heff_rfield(v_cc_2464, 4))});
      V v_t_2474 = (g_heff_2esyntax_2esurface_2especGroups(heff_dup(v_spec_2465), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_m_2475 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_t_2473, heff_dup(g_heff_2esyntax_2esurface_2eemptySpec_get()), v_t_2474));
      V v_x1_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_st_2470}));
      switch (heff_tag_of(v_x1_2476)) {
      case TAG_MkPair: {
        V v_x11_2477 = heff_field(v_x1_2476, 0);
        V v_st_2478 = heff_field(v_x1_2476, 1);
        heff_take_n(v_x1_2476, 3ULL, 2);
        switch (heff_tag_of(v_x11_2477)) {
        case TAG_Left: {
          V v_e_2479 = heff_field(v_x11_2477, 0);
          heff_take_n(v_x11_2477, 1ULL, 1);
          heff_drop_rec(v_cc_2464, 9);
          heff_drop(v_spec_2465);
          heff_drop(v_v_2463);
          heff_drop(v_x_2472);
          return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2479}), v_st_2478});
        }
        case TAG_Right: {
          V v_x_2480 = heff_field(v_x11_2477, 0);
          heff_take_n(v_x11_2477, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_2468_24MkPair, 2);
          V v_a_2481 = (g_heff_2esyntax_2ecst_2efirstE(v_v_2463));
          V v_t_2482 = (g_heff_2esyntax_2ecst_2elastE(heff_tag_n(TAG_Seg, 3, (V[]){v_v_2463, v_cc_2464, v_spec_2465})));
          V v_e_2483 = heff_get_n(v_t_2482, 4, 9);
          V v_t_2484 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2481, 3, 9), v_e_2483});
          V v_t_2485 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2472));
          return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2484; V a_2 = v_x_2472; V a_3 = v_t_2485; V a_4 = v_x_2480; V a_5 = v_st_2478; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
        }
        default: return heff_nomatch(v_x11_2477);
        }
      }
      default: return heff_nomatch(v_x1_2476);
      }
    }
    default: return heff_nomatch(v_x11_2469);
    }
  }
  default: return heff_nomatch(v_x1_2468);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam5(V self, V *args) {
  V v_st_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_st_2491}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2492_24MkPair, 2);
      V v_a_2497 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2498 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2499 = heff_get_n(v_t_2498, 4, 9);
      V v_t_24100 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2497, 3, 9), v_e_2499});
      V v_t_24101 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2496));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24100; V a_2 = v_x_2496; V a_3 = v_t_24101; V a_4 = v_st_2494; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam6(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24110_24MkPair, 2);
      V v_a_24115 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24116 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24117 = heff_get_n(v_t_24116, 4, 9);
      V v_t_24118 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24115, 3, 9), v_e_24117});
      V v_t_24119 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24114));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24118; V a_2 = v_x_24114; V a_3 = v_t_24119; V a_4 = v_st_24112; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam7(V self, V *args) {
  V v_st_24124 = args[0];
  V v_m_24123 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24125 = heff_tr(heff_call(v_m_24123, 1, (V[]){v_st_24124}));
  switch (heff_tag_of(v_x1_24125)) {
  case TAG_MkPair: {
    V v_x11_24126 = heff_field(v_x1_24125, 0);
    V v_st_24127 = heff_field(v_x1_24125, 1);
    V v_ru_24x1_24125_24MkPair = heff_take_reuse_n(v_x1_24125, 3ULL, 2);
    switch (heff_tag_of(v_x11_24126)) {
    case TAG_Left: {
      V v_e_24128 = heff_field(v_x11_24126, 0);
      heff_take_n(v_x11_24126, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24128}), v_st_24127});
    }
    case TAG_Right: {
      V v_x_24129 = heff_field(v_x11_24126, 0);
      heff_take_n(v_x11_24126, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24125_24MkPair, 2);
      V v_a_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24131 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24132 = heff_get_n(v_t_24131, 4, 9);
      V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24130, 3, 9), v_e_24132});
      V v_t_24134 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24129));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24133; V a_2 = v_x_24129; V a_3 = v_t_24134; V a_4 = v_st_24127; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24126);
    }
  }
  default: return heff_nomatch(v_x1_24125);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam8(V self, V *args) {
  V v_st_24141 = args[0];
  V v_m_24140 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24142 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_st_24141}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_MkPair: {
    V v_x11_24143 = heff_field(v_x1_24142, 0);
    V v_st_24144 = heff_field(v_x1_24142, 1);
    V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
    switch (heff_tag_of(v_x11_24143)) {
    case TAG_Left: {
      V v_e_24145 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
    }
    case TAG_Right: {
      V v_x_24146 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24MkPair, 2);
      V v_a_24147 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24148 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24149 = heff_get_n(v_t_24148, 4, 9);
      V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24147, 3, 9), v_e_24149});
      V v_t_24151 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24146));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24150; V a_2 = v_x_24146; V a_3 = v_t_24151; V a_4 = v_st_24144; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24143);
    }
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam9(V self, V *args) {
  V v_st_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_st_24156}));
  switch (heff_tag_of(v_x1_24157)) {
  case TAG_MkPair: {
    V v_x11_24158 = heff_field(v_x1_24157, 0);
    V v_st_24159 = heff_field(v_x1_24157, 1);
    V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_Left: {
      V v_e_24160 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24160}), v_st_24159});
    }
    case TAG_Right: {
      V v_x_24161 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24157_24MkPair, 2);
      V v_a_24162 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24163 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24164 = heff_get_n(v_t_24163, 4, 9);
      V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24162, 3, 9), v_e_24164});
      V v_t_24166 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24161));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24165; V a_2 = v_x_24161; V a_3 = v_t_24166; V a_4 = v_st_24159; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24158);
    }
  }
  default: return heff_nomatch(v_x1_24157);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam10(V self, V *args) {
  V v_st_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_st_24171}));
  switch (heff_tag_of(v_x1_24172)) {
  case TAG_MkPair: {
    V v_x11_24173 = heff_field(v_x1_24172, 0);
    V v_st_24174 = heff_field(v_x1_24172, 1);
    V v_ru_24x1_24172_24MkPair = heff_take_reuse_n(v_x1_24172, 3ULL, 2);
    switch (heff_tag_of(v_x11_24173)) {
    case TAG_Left: {
      V v_e_24175 = heff_field(v_x11_24173, 0);
      heff_take_n(v_x11_24173, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24175}), v_st_24174});
    }
    case TAG_Right: {
      V v_x_24176 = heff_field(v_x11_24173, 0);
      heff_take_n(v_x11_24173, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24172_24MkPair, 2);
      V v_a_24177 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24178 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24179 = heff_get_n(v_t_24178, 4, 9);
      V v_t_24180 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24177, 3, 9), v_e_24179});
      V v_t_24181 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24176));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24180; V a_2 = v_x_24176; V a_3 = v_t_24181; V a_4 = v_st_24174; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24173);
    }
  }
  default: return heff_nomatch(v_x1_24172);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam11(V self, V *args) {
  V v_st_24188 = args[0];
  V v_m_24187 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24189 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_st_24188}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24MkPair, 2);
      V v_a_24194 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24195 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24196 = heff_get_n(v_t_24195, 4, 9);
      V v_t_24197 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24194, 3, 9), v_e_24196});
      V v_t_24198 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24193));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24197; V a_2 = v_x_24193; V a_3 = v_t_24198; V a_4 = v_st_24191; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam12(V self, V *args) {
  V v_st_24202 = args[0];
  V v_m_24201 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24203 = heff_tr(heff_call(v_m_24201, 1, (V[]){v_st_24202}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_MkPair: {
    V v_x11_24204 = heff_field(v_x1_24203, 0);
    V v_st_24205 = heff_field(v_x1_24203, 1);
    V v_ru_24x1_24203_24MkPair = heff_take_reuse_n(v_x1_24203, 3ULL, 2);
    switch (heff_tag_of(v_x11_24204)) {
    case TAG_Left: {
      V v_e_24206 = heff_field(v_x11_24204, 0);
      heff_take_n(v_x11_24204, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24203_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24206}), v_st_24205});
    }
    case TAG_Right: {
      V v_x_24207 = heff_field(v_x11_24204, 0);
      heff_take_n(v_x11_24204, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24MkPair, 2);
      V v_a_24208 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24209 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24210 = heff_get_n(v_t_24209, 4, 9);
      V v_t_24211 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24208, 3, 9), v_e_24210});
      V v_t_24212 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24207));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24211; V a_2 = v_x_24207; V a_3 = v_t_24212; V a_4 = v_st_24205; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24204);
    }
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam13(V self, V *args) {
  V v_st_24216 = args[0];
  V v_m_24215 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24217 = heff_tr(heff_call(v_m_24215, 1, (V[]){v_st_24216}));
  switch (heff_tag_of(v_x1_24217)) {
  case TAG_MkPair: {
    V v_x11_24218 = heff_field(v_x1_24217, 0);
    V v_st_24219 = heff_field(v_x1_24217, 1);
    V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
    switch (heff_tag_of(v_x11_24218)) {
    case TAG_Left: {
      V v_e_24220 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
    }
    case TAG_Right: {
      V v_x_24221 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24217_24MkPair, 2);
      V v_a_24222 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24223 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24224 = heff_get_n(v_t_24223, 4, 9);
      V v_t_24225 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24222, 3, 9), v_e_24224});
      V v_t_24226 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24221));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24225; V a_2 = v_x_24221; V a_3 = v_t_24226; V a_4 = v_st_24219; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24218);
    }
  }
  default: return heff_nomatch(v_x1_24217);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam14(V self, V *args) {
  V v_st_24230 = args[0];
  V v_m_24229 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24231 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_st_24230}));
  switch (heff_tag_of(v_x1_24231)) {
  case TAG_MkPair: {
    V v_x11_24232 = heff_field(v_x1_24231, 0);
    V v_st_24233 = heff_field(v_x1_24231, 1);
    V v_ru_24x1_24231_24MkPair = heff_take_reuse_n(v_x1_24231, 3ULL, 2);
    switch (heff_tag_of(v_x11_24232)) {
    case TAG_Left: {
      V v_e_24234 = heff_field(v_x11_24232, 0);
      heff_take_n(v_x11_24232, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24234}), v_st_24233});
    }
    case TAG_Right: {
      V v_x_24235 = heff_field(v_x11_24232, 0);
      heff_take_n(v_x11_24232, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24231_24MkPair, 2);
      V v_a_24236 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24237 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24238 = heff_get_n(v_t_24237, 4, 9);
      V v_t_24239 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24236, 3, 9), v_e_24238});
      V v_t_24240 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24235));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24239; V a_2 = v_x_24235; V a_3 = v_t_24240; V a_4 = v_st_24233; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24232);
    }
  }
  default: return heff_nomatch(v_x1_24231);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam15(V self, V *args) {
  V v_st_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24245 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_st_24244}));
  switch (heff_tag_of(v_x1_24245)) {
  case TAG_MkPair: {
    V v_x11_24246 = heff_field(v_x1_24245, 0);
    V v_st_24247 = heff_field(v_x1_24245, 1);
    V v_ru_24x1_24245_24MkPair = heff_take_reuse_n(v_x1_24245, 3ULL, 2);
    switch (heff_tag_of(v_x11_24246)) {
    case TAG_Left: {
      V v_e_24248 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24248}), v_st_24247});
    }
    case TAG_Right: {
      V v_x_24249 = heff_field(v_x11_24246, 0);
      heff_take_n(v_x11_24246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24245_24MkPair, 2);
      V v_a_24250 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24251 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24252 = heff_get_n(v_t_24251, 4, 9);
      V v_t_24253 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24250, 3, 9), v_e_24252});
      V v_t_24254 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24249));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24253; V a_2 = v_x_24249; V a_3 = v_t_24254; V a_4 = v_st_24247; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24246);
    }
  }
  default: return heff_nomatch(v_x1_24245);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam16(V self, V *args) {
  V v_st_24259 = args[0];
  V v_m_24258 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24260 = heff_tr(heff_call(v_m_24258, 1, (V[]){v_st_24259}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_MkPair: {
    V v_x11_24261 = heff_field(v_x1_24260, 0);
    V v_st_24262 = heff_field(v_x1_24260, 1);
    V v_ru_24x1_24260_24MkPair = heff_take_reuse_n(v_x1_24260, 3ULL, 2);
    switch (heff_tag_of(v_x11_24261)) {
    case TAG_Left: {
      V v_e_24263 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24263}), v_st_24262});
    }
    case TAG_Right: {
      V v_x_24264 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24260_24MkPair, 2);
      V v_a_24265 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24266 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24267 = heff_get_n(v_t_24266, 4, 9);
      V v_t_24268 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24265, 3, 9), v_e_24267});
      V v_t_24269 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24264));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24268; V a_2 = v_x_24264; V a_3 = v_t_24269; V a_4 = v_st_24262; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24261);
    }
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam17(V self, V *args) {
  V v_st_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24273}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24274_24MkPair, 2);
      V v_a_24279 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24280 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24281 = heff_get_n(v_t_24280, 4, 9);
      V v_t_24282 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24279, 3, 9), v_e_24281});
      V v_t_24283 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24278));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24282; V a_2 = v_x_24278; V a_3 = v_t_24283; V a_4 = v_st_24276; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam18(V self, V *args) {
  V v_st_24287 = args[0];
  V v_m_24286 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24288 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_st_24287}));
  switch (heff_tag_of(v_x1_24288)) {
  case TAG_MkPair: {
    V v_x11_24289 = heff_field(v_x1_24288, 0);
    V v_st_24290 = heff_field(v_x1_24288, 1);
    V v_ru_24x1_24288_24MkPair = heff_take_reuse_n(v_x1_24288, 3ULL, 2);
    switch (heff_tag_of(v_x11_24289)) {
    case TAG_Left: {
      V v_e_24291 = heff_field(v_x11_24289, 0);
      heff_take_n(v_x11_24289, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24288_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24291}), v_st_24290});
    }
    case TAG_Right: {
      V v_x_24292 = heff_field(v_x11_24289, 0);
      heff_take_n(v_x11_24289, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24288_24MkPair, 2);
      V v_a_24293 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24294 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24295 = heff_get_n(v_t_24294, 4, 9);
      V v_t_24296 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24293, 3, 9), v_e_24295});
      V v_t_24297 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24292));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24296; V a_2 = v_x_24292; V a_3 = v_t_24297; V a_4 = v_st_24290; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24289);
    }
  }
  default: return heff_nomatch(v_x1_24288);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam19(V self, V *args) {
  V v_st_24302 = args[0];
  V v_m_24301 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24303 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_st_24302}));
  switch (heff_tag_of(v_x1_24303)) {
  case TAG_MkPair: {
    V v_x11_24304 = heff_field(v_x1_24303, 0);
    V v_st_24305 = heff_field(v_x1_24303, 1);
    V v_ru_24x1_24303_24MkPair = heff_take_reuse_n(v_x1_24303, 3ULL, 2);
    switch (heff_tag_of(v_x11_24304)) {
    case TAG_Left: {
      V v_e_24306 = heff_field(v_x11_24304, 0);
      heff_take_n(v_x11_24304, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24303_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24306}), v_st_24305});
    }
    case TAG_Right: {
      V v_x_24307 = heff_field(v_x11_24304, 0);
      heff_take_n(v_x11_24304, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24303_24MkPair, 2);
      V v_a_24308 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24309 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24310 = heff_get_n(v_t_24309, 4, 9);
      V v_t_24311 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24308, 3, 9), v_e_24310});
      V v_t_24312 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24307));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24311; V a_2 = v_x_24307; V a_3 = v_t_24312; V a_4 = v_st_24305; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24304);
    }
  }
  default: return heff_nomatch(v_x1_24303);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam20(V self, V *args) {
  V v_st_24315 = args[0];
  V v_m_24314 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24316 = heff_tr(heff_call(v_m_24314, 1, (V[]){v_st_24315}));
  switch (heff_tag_of(v_x1_24316)) {
  case TAG_MkPair: {
    V v_x11_24317 = heff_field(v_x1_24316, 0);
    V v_st_24318 = heff_field(v_x1_24316, 1);
    V v_ru_24x1_24316_24MkPair = heff_take_reuse_n(v_x1_24316, 3ULL, 2);
    switch (heff_tag_of(v_x11_24317)) {
    case TAG_Left: {
      V v_e_24319 = heff_field(v_x11_24317, 0);
      heff_take_n(v_x11_24317, 1ULL, 1);
      heff_drop_tag(v_e_241, 1);
      return heff_tag_at_n(v_ru_24x1_24316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24319}), v_st_24318});
    }
    case TAG_Right: {
      V v_x_24320 = heff_field(v_x11_24317, 0);
      heff_take_n(v_x11_24317, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24316_24MkPair, 2);
      V v_a_24321 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24322 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24323 = heff_get_n(v_t_24322, 4, 9);
      V v_t_24324 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24321, 3, 9), v_e_24323});
      V v_t_24325 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24320));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24324; V a_2 = v_x_24320; V a_3 = v_t_24325; V a_4 = v_st_24318; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24317);
    }
  }
  default: return heff_nomatch(v_x1_24316);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam21(V self, V *args) {
  V v_st_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_st_24330}));
  switch (heff_tag_of(v_x1_24331)) {
  case TAG_MkPair: {
    V v_x11_24332 = heff_field(v_x1_24331, 0);
    V v_st_24333 = heff_field(v_x1_24331, 1);
    V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
    switch (heff_tag_of(v_x11_24332)) {
    case TAG_Left: {
      V v_e_24334 = heff_field(v_x11_24332, 0);
      heff_take_n(v_x11_24332, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
    }
    case TAG_Right: {
      V v_x_24335 = heff_field(v_x11_24332, 0);
      heff_take_n(v_x11_24332, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24331_24MkPair, 2);
      V v_a_24336 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24337 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24338 = heff_get_n(v_t_24337, 4, 9);
      V v_t_24339 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24336, 3, 9), v_e_24338});
      V v_t_24340 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24335));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24339; V a_2 = v_x_24335; V a_3 = v_t_24340; V a_4 = v_st_24333; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24332);
    }
  }
  default: return heff_nomatch(v_x1_24331);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam22(V self, V *args) {
  V v_st_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_st_24347}));
  switch (heff_tag_of(v_x1_24348)) {
  case TAG_MkPair: {
    V v_x11_24349 = heff_field(v_x1_24348, 0);
    V v_st_24350 = heff_field(v_x1_24348, 1);
    V v_ru_24x1_24348_24MkPair = heff_take_reuse_n(v_x1_24348, 3ULL, 2);
    switch (heff_tag_of(v_x11_24349)) {
    case TAG_Left: {
      V v_e_24351 = heff_field(v_x11_24349, 0);
      heff_take_n(v_x11_24349, 1ULL, 1);
      heff_drop_tag(v_e_241, 5);
      return heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24351}), v_st_24350});
    }
    case TAG_Right: {
      V v_x_24352 = heff_field(v_x11_24349, 0);
      heff_take_n(v_x11_24349, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24348_24MkPair, 2);
      V v_a_24353 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24354 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24355 = heff_get_n(v_t_24354, 4, 9);
      V v_t_24356 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24353, 3, 9), v_e_24355});
      V v_t_24357 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24352));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24356; V a_2 = v_x_24352; V a_3 = v_t_24357; V a_4 = v_st_24350; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24349);
    }
  }
  default: return heff_nomatch(v_x1_24348);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam23(V self, V *args) {
  V v_st_24363 = args[0];
  V v_m_24362 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24364 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_st_24363}));
  switch (heff_tag_of(v_x1_24364)) {
  case TAG_MkPair: {
    V v_x11_24365 = heff_field(v_x1_24364, 0);
    V v_st_24366 = heff_field(v_x1_24364, 1);
    V v_ru_24x1_24364_24MkPair = heff_take_reuse_n(v_x1_24364, 3ULL, 2);
    switch (heff_tag_of(v_x11_24365)) {
    case TAG_Left: {
      V v_e_24367 = heff_field(v_x11_24365, 0);
      heff_take_n(v_x11_24365, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24367}), v_st_24366});
    }
    case TAG_Right: {
      V v_x_24368 = heff_field(v_x11_24365, 0);
      heff_take_n(v_x11_24365, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24364_24MkPair, 2);
      V v_a_24369 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24370 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24371 = heff_get_n(v_t_24370, 4, 9);
      V v_t_24372 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24369, 3, 9), v_e_24371});
      V v_t_24373 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24368));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24372; V a_2 = v_x_24368; V a_3 = v_t_24373; V a_4 = v_st_24366; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24365);
    }
  }
  default: return heff_nomatch(v_x1_24364);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam24(V self, V *args) {
  V v_st_24379 = args[0];
  V v_m_24378 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24380 = heff_tr(heff_call(v_m_24378, 1, (V[]){v_st_24379}));
  switch (heff_tag_of(v_x1_24380)) {
  case TAG_MkPair: {
    V v_x11_24381 = heff_field(v_x1_24380, 0);
    V v_st_24382 = heff_field(v_x1_24380, 1);
    V v_ru_24x1_24380_24MkPair = heff_take_reuse_n(v_x1_24380, 3ULL, 2);
    switch (heff_tag_of(v_x11_24381)) {
    case TAG_Left: {
      V v_e_24383 = heff_field(v_x11_24381, 0);
      heff_take_n(v_x11_24381, 1ULL, 1);
      heff_drop_tag(v_e_241, 4);
      return heff_tag_at_n(v_ru_24x1_24380_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24383}), v_st_24382});
    }
    case TAG_Right: {
      V v_x_24384 = heff_field(v_x11_24381, 0);
      heff_take_n(v_x11_24381, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24380_24MkPair, 2);
      V v_a_24385 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24386 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24387 = heff_get_n(v_t_24386, 4, 9);
      V v_t_24388 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24385, 3, 9), v_e_24387});
      V v_t_24389 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24384));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24388; V a_2 = v_x_24384; V a_3 = v_t_24389; V a_4 = v_st_24382; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24381);
    }
  }
  default: return heff_nomatch(v_x1_24380);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam25(V self, V *args) {
  V v_st_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_st_24394}));
  switch (heff_tag_of(v_x1_24395)) {
  case TAG_MkPair: {
    V v_x11_24396 = heff_field(v_x1_24395, 0);
    V v_st_24397 = heff_field(v_x1_24395, 1);
    V v_ru_24x1_24395_24MkPair = heff_take_reuse_n(v_x1_24395, 3ULL, 2);
    switch (heff_tag_of(v_x11_24396)) {
    case TAG_Left: {
      V v_e_24398 = heff_field(v_x11_24396, 0);
      heff_take_n(v_x11_24396, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24398}), v_st_24397});
    }
    case TAG_Right: {
      V v_x_24399 = heff_field(v_x11_24396, 0);
      heff_take_n(v_x11_24396, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24395_24MkPair, 2);
      V v_a_24400 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24401 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24402 = heff_get_n(v_t_24401, 4, 9);
      V v_t_24403 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24400, 3, 9), v_e_24402});
      V v_t_24404 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24399));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24403; V a_2 = v_x_24399; V a_3 = v_t_24404; V a_4 = v_st_24397; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24396);
    }
  }
  default: return heff_nomatch(v_x1_24395);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam26(V self, V *args) {
  V v_st_24412 = args[0];
  V v_m_24411 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24413 = heff_tr(heff_call(v_m_24411, 1, (V[]){v_st_24412}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_MkPair: {
    V v_x11_24414 = heff_field(v_x1_24413, 0);
    V v_st_24415 = heff_field(v_x1_24413, 1);
    V v_ru_24x1_24413_24MkPair = heff_take_reuse_n(v_x1_24413, 3ULL, 2);
    switch (heff_tag_of(v_x11_24414)) {
    case TAG_Left: {
      V v_e_24416 = heff_field(v_x11_24414, 0);
      heff_take_n(v_x11_24414, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24416}), v_st_24415});
    }
    case TAG_Right: {
      V v_x_24417 = heff_field(v_x11_24414, 0);
      heff_take_n(v_x11_24414, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24MkPair, 2);
      V v_a_24418 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24419 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24420 = heff_get_n(v_t_24419, 4, 9);
      V v_t_24421 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24418, 3, 9), v_e_24420});
      V v_t_24422 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24417));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24421; V a_2 = v_x_24417; V a_3 = v_t_24422; V a_4 = v_st_24415; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24414);
    }
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam27(V self, V *args) {
  V v_st_24426 = args[0];
  V v_m_24425 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24427 = heff_tr(heff_call(v_m_24425, 1, (V[]){v_st_24426}));
  switch (heff_tag_of(v_x1_24427)) {
  case TAG_MkPair: {
    V v_x11_24428 = heff_field(v_x1_24427, 0);
    V v_st_24429 = heff_field(v_x1_24427, 1);
    V v_ru_24x1_24427_24MkPair = heff_take_reuse_n(v_x1_24427, 3ULL, 2);
    switch (heff_tag_of(v_x11_24428)) {
    case TAG_Left: {
      V v_e_24430 = heff_field(v_x11_24428, 0);
      heff_take_n(v_x11_24428, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_at_n(v_ru_24x1_24427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24430}), v_st_24429});
    }
    case TAG_Right: {
      V v_x_24431 = heff_field(v_x11_24428, 0);
      heff_take_n(v_x11_24428, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24427_24MkPair, 2);
      V v_a_24432 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24433 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24434 = heff_get_n(v_t_24433, 4, 9);
      V v_t_24435 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24432, 3, 9), v_e_24434});
      V v_t_24436 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24431));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24435; V a_2 = v_x_24431; V a_3 = v_t_24436; V a_4 = v_st_24429; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24428);
    }
  }
  default: return heff_nomatch(v_x1_24427);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam28(V self, V *args) {
  V v_st_24441 = args[0];
  V v_m_24440 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24442 = heff_tr(heff_call(v_m_24440, 1, (V[]){v_st_24441}));
  switch (heff_tag_of(v_x1_24442)) {
  case TAG_MkPair: {
    V v_x11_24443 = heff_field(v_x1_24442, 0);
    V v_st_24444 = heff_field(v_x1_24442, 1);
    V v_ru_24x1_24442_24MkPair = heff_take_reuse_n(v_x1_24442, 3ULL, 2);
    switch (heff_tag_of(v_x11_24443)) {
    case TAG_Left: {
      V v_e_24445 = heff_field(v_x11_24443, 0);
      heff_take_n(v_x11_24443, 1ULL, 1);
      heff_drop_tag(v_e_241, 3);
      return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24445}), v_st_24444});
    }
    case TAG_Right: {
      V v_x_24446 = heff_field(v_x11_24443, 0);
      heff_take_n(v_x11_24443, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24442_24MkPair, 2);
      V v_a_24447 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24448 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24449 = heff_get_n(v_t_24448, 4, 9);
      V v_t_24450 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24447, 3, 9), v_e_24449});
      V v_t_24451 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24446));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24450; V a_2 = v_x_24446; V a_3 = v_t_24451; V a_4 = v_st_24444; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24443);
    }
  }
  default: return heff_nomatch(v_x1_24442);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam29(V self, V *args) {
  V v_st_24459 = args[0];
  V v_m_24458 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24460 = heff_tr(heff_call(v_m_24458, 1, (V[]){v_st_24459}));
  switch (heff_tag_of(v_x1_24460)) {
  case TAG_MkPair: {
    V v_x11_24461 = heff_field(v_x1_24460, 0);
    V v_st_24462 = heff_field(v_x1_24460, 1);
    V v_ru_24x1_24460_24MkPair = heff_take_reuse_n(v_x1_24460, 3ULL, 2);
    switch (heff_tag_of(v_x11_24461)) {
    case TAG_Left: {
      V v_e_24463 = heff_field(v_x11_24461, 0);
      heff_take_n(v_x11_24461, 1ULL, 1);
      heff_drop_tag(v_e_241, 6);
      return heff_tag_at_n(v_ru_24x1_24460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24463}), v_st_24462});
    }
    case TAG_Right: {
      V v_x_24464 = heff_field(v_x11_24461, 0);
      heff_take_n(v_x11_24461, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24460_24MkPair, 2);
      V v_a_24465 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_24466 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_24467 = heff_get_n(v_t_24466, 4, 9);
      V v_t_24468 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_24465, 3, 9), v_e_24467});
      V v_t_24469 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_24464));
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_24468; V a_2 = v_x_24464; V a_3 = v_t_24469; V a_4 = v_st_24462; V r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    }
    default: return heff_nomatch(v_x11_24461);
    }
  }
  default: return heff_nomatch(v_x1_24460);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str4, 3, "int");
Clo g_heff_2esyntax_2esurface_2esegmentValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentValue_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esegmentValue(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PCon: {
    return NTAG(TAG_False);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_243, 0))}));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str0), NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str2), v_t_245})});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2esegmentValue_str4), v_t_246})});
    return ({ V a_0 = v_t_244; V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
  }
  case TAG_PParen: {
    V v_p2_249 = heff_field(v_p_240, 1);
    V t_0 = v_p2_249;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_PList: {
    return NTAG(TAG_False);
  }
  case TAG_POp: {
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    return NTAG(TAG_False);
  }
  case TAG_PField: {
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    return NTAG(TAG_False);
  }
  case TAG_PSeg: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str1, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamOf(V v_r_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2ebracedOne(v_e_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam0, 1, 2, (V[]){v_m_243, v_e_241});
  }
  case TAG_Just: {
    V v_f_2420 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_m_2421 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_2420));
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam2, 1, 2, (V[]){v_m_2421, v_e_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2413});
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
      V v_m_2414;
      if (heff_strEq_c(heff_get_n(v_t_2410, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str0))) {
        V v_t_2412 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_249));
        v_m_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2412}));
      } else {
        v_m_2414 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam1, 1, 1, (V[]){v_x_249});
      }
      V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_247}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
          return ({ V a_0 = v_x_2419; V a_1 = v_st_2417; V r_ = (g_heff_2esyntax_2esurface_2eparamOf(a_0, a_1)); heff_drop(v_x_2419); r_; });
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args) {
  V v_st_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_st_2422}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_MkPair: {
    V v_x11_2424 = heff_field(v_x1_2423, 0);
    V v_st_2425 = heff_field(v_x1_2423, 1);
    V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_e_2426 = heff_field(v_x11_2424, 0);
      heff_take_n(v_x11_2424, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2426}), v_st_2425});
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_x11_2424, 0);
      heff_take_n(v_x11_2424, 1ULL, 1);
      V v_t_2428 = (g_heff_2esyntax_2esurface_2enameAnn(v_x_2427));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_Nothing: {
        heff_drop(v_e_241);
        V v_t_2431;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str1), v_t_2431, NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2425});
      }
      case TAG_Just: {
        V v_q_2433 = heff_field(v_t_2428, 0);
        heff_take_n(v_t_2428, 1ULL, 1);
        heff_drop(v_x_2427);
        V v_t_2434 = heff_tag_n(TAG_ImplicitParam, 3, (V[]){heff_take_field(v_q_2433, 0), heff_take_field(v_q_2433, 1), heff_get_n(v_q_2433, 2, 3)});
        V v_a_2435 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
        V v_b_2436 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
        V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2435, 3, 9), heff_get_n(v_b_2436, 4, 9)});
        V v_x_2438 = heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_t_2437});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_st_2425});
      }
      default: return heff_nomatch(v_t_2428);
      }
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2esurface_2eedgesOf(heff_dup(v_lit_240), heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_lit_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_245 = (g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(v_x_243));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1, 1, 2, (V[]){v_m_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(a[0]);
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_m_2412 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_xs_244));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417})});
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V v_kw_240, V v_x_241, V v_ty_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_242), v_st_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop_rec(v_x_241, 9);
      heff_drop(v_ty_242);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 3), heff_take_field(v_x_241, 4)});
      V v_t_2410 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){heff_get_n(v_x_241, 1, 9), v_t_249, v_x_248});
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_ty_242));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2412});
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2413})});
      V v_x_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2415}), v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2elineColFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elineColFrom_entry, 4, 0};

V g_heff_2esyntax_2esurface_2elineColFrom(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str0), v_src_240, v_start_243, 1);
  V v_t_246;
  if (heff_intLt_c(heff_dup(v_j_244), MK_INT(0LL))) {
    heff_drop(v_j_244);
    v_t_246 = NTAG(TAG_Nothing);
  } else {
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_j_244});
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
    V v_t_248 = heff_intShow(heff_intAdd(v_t_247, MK_INT(1LL)));
    return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str1), v_t_248));
  }
  case TAG_Just: {
    V v_nl_249 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_intLt_c(heff_dup(v_nl_249), heff_dup(v_i_241))) {
      heff_drop(v_start_243);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_249, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    } else {
      heff_drop(v_nl_249);
      V v_t_2411 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
      V v_t_2412 = heff_intShow(heff_intAdd(v_t_2411, MK_INT(1LL)));
      return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str2), v_t_2412));
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elineColFrom(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2enoKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enoKnown_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enoKnown(V v_x_240) {
top: ;
  return NTAG(TAG_False);
}
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enoKnown(a0); heff_drop(a0); return r;
}