// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclPrimitive 46335
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Whole 6035
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2earrowAfter(V, V);
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowAfter_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edigitsVal(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edigitsVal_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str0, 2, "0x");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str1, 2, "0X");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str2, 2, "0b");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str3, 2, "0B");
Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emagnitudeOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emagnitudeOf(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
  V v_t_245 = heff_bool((heff_strEq_c(heff_dup(v_t_242), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str0)) || ({ V v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))); int c_ = heff_strEq_c(heff_dup(v_t_244), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str1)); heff_drop(v_t_244); c_; })));
  heff_drop(v_t_242);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(16LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
  } else {
    heff_drop(v_t_245);
    V v_t_246 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str2))) {
      return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
    } else {
      V v_t_248 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
      if (heff_strEq_c(v_t_248, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str3))) {
        return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(2LL), heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(2LL)), heff_strLength(v_s_240), MK_INT(0LL)));
      } else {
        return (g_heff_2esyntax_2esurface_2edigitsVal(MK_INT(10LL), heff_dup(v_s_240), v_i_241, heff_strLength(v_s_240), MK_INT(0LL)));
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emagnitudeOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eboundBy(V v_pv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_243 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_243);
  }
  case TAG_PAtom: {
    V v_t_245 = heff_field(v_x2_241, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str2))) {
          V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_245, 1))}));
          V v_t_2410 = (g_list_2eany(v_t_249, v_pv_240));
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop(v_t_2410);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
          } else {
            heff_drop(v_t_2410);
            return NTAG(TAG_Nil);
          }
        } else {
          return NTAG(TAG_Nil);
        }
      } else {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str3))) {
        V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_245, 1))}));
        V v_t_2413 = (g_list_2eany(v_t_2412, v_pv_240));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2413);
          return NTAG(TAG_Nil);
        }
      } else {
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2415 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2415;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2418 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2418);
  }
  case TAG_POp: {
    V v_l_2422 = heff_field(v_x2_241, 0);
    V v_q_2424 = heff_field(v_x2_241, 2);
    V v_t_2425 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2422));
    V v_t_2426 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2424));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2425, v_t_2426);
  }
  case TAG_PRec: {
    V v_fs_2428 = heff_field(v_x2_241, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2428);
  }
  case TAG_PField: {
    V v_q_2434 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2434;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2435 = heff_field(v_x2_241, 0);
    V v_q_2437 = heff_field(v_x2_241, 2);
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2435, 1)), heff_hole()});
    V v_u_2439 = (g_heff_2esyntax_2esurface_2eboundBy_24dps(v_pv_240, v_q_2437, heff_dup(v_cell_2438)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args) {
  V v_q_244 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_244); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args) {
  V v_q_2421 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2421; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2421); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args) {
  V v_q_2431 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2431; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2431); r_; });
}
Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisNameE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowAfter_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowAfter_str1, 2, "->");
Clo g_heff_2esyntax_2esurface_2earrowAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowAfter_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowAfter(V v_s_240, V v_t_241) {
top: ;
  V v_xs_242 = heff_get_n(v_s_240, 0, 8);
  V v_i_243 = heff_intAdd(heff_get_n(v_t_241, 7, 9), MK_INT(1LL));
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(v_i_243)) && (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_242))) && ({ V v_u_246 = heff_arrayIndex(heff_dup(v_xs_242), heff_dup(v_i_243)); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_u_246, 0)), ((V)&g_heff_2esyntax_2esurface_2earrowAfter_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_u_246, 1)), ((V)&g_heff_2esyntax_2esurface_2earrowAfter_str1))); heff_drop(v_u_246); c_; }))));
  heff_drop(v_xs_242);
  heff_drop(v_i_243);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowAfter(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str1, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamOf(V v_r_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2ebracedOne(v_e_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam0, 1, 2, (V[]){v_m_243, v_e_241});
  }
  case TAG_Just: {
    V v_f_2420 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_m_2421 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_2420));
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam2, 1, 2, (V[]){v_m_2421, v_e_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2413});
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
      V v_m_2414;
      if (heff_strEq_c(heff_get_n(v_t_2410, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str0))) {
        V v_t_2412 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_249));
        v_m_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2412}));
      } else {
        v_m_2414 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam1, 1, 1, (V[]){v_x_249});
      }
      V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_247}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
          return ({ V a_0 = v_x_2419; V a_1 = v_st_2417; V r_ = (g_heff_2esyntax_2esurface_2eparamOf(a_0, a_1)); heff_drop(v_x_2419); r_; });
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args) {
  V v_st_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_st_2422}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_MkPair: {
    V v_x11_2424 = heff_field(v_x1_2423, 0);
    V v_st_2425 = heff_field(v_x1_2423, 1);
    V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_e_2426 = heff_field(v_x11_2424, 0);
      heff_take_n(v_x11_2424, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2426}), v_st_2425});
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Right = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      V v_t_2428 = (g_heff_2esyntax_2esurface_2enameAnn(v_x_2427));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_Nothing: {
        heff_drop(v_e_241);
        heff_drop_cell(v_ru_24x11_2424_24Right, 1);
        V v_span_2431;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_span_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str1), v_span_2431, NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2425});
      }
      case TAG_Just: {
        V v_q_2433 = heff_field(v_t_2428, 0);
        heff_take_n(v_t_2428, 1ULL, 1);
        heff_drop(v_x_2427);
        V v_t_2434 = heff_tag_n(TAG_ImplicitParam, 3, (V[]){heff_take_field(v_q_2433, 0), heff_take_field(v_q_2433, 1), heff_get_n(v_q_2433, 2, 3)});
        V v_a_2435 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
        V v_b_2436 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
        V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2435, 3, 9), heff_get_n(v_b_2436, 4, 9)});
        V v_x_2438 = heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_At, 2, (V[]){v_t_2434, v_t_2437});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2424_24Right, TAG_Right, 1, (V[]){v_x_2438}), v_st_2425});
      }
      default: return heff_nomatch(v_t_2428);
      }
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_245 = (g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(v_x_243));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1, 1, 2, (V[]){v_m_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(a[0]);
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_m_2412 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_xs_244));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, v_x_2417})});
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
Clo g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(V v_kw_240, V v_x_241, V v_ty_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_242), v_st_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop_rec(v_x_241, 9);
      heff_drop(v_ty_242);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 3), heff_take_field(v_x_241, 4)});
      V v_t_2410 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){heff_get_n(v_x_241, 1, 9), v_t_249, v_x_248});
      V v_t_2411 = (g_heff_2esyntax_2ecst_2elastE(v_ty_242));
      V v_e_2412 = heff_get_n(v_t_2411, 4, 9);
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2412});
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Whole, 1, (V[]){heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_At, 2, (V[]){v_t_2410, v_t_2413})});
      V v_x_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2415}), v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2elineColFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elineColFrom_entry, 4, 0};

V g_heff_2esyntax_2esurface_2elineColFrom(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str0), heff_dup(v_src_240), heff_dup(v_start_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
    V v_t_246 = heff_intShow(heff_intAdd(v_t_245, MK_INT(1LL)));
    return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str1), v_t_246));
  }
  case TAG_Just: {
    V v_nl_247 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    if (heff_intLt_c(heff_dup(v_nl_247), heff_dup(v_i_241))) {
      heff_drop(v_start_243);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_247, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    } else {
      heff_drop(v_nl_247);
      V v_t_249 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
      V v_t_2410 = heff_intShow(heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_strAppend(heff_intShow(v_l_242), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str2), v_t_2410));
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elineColFrom(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2enoKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enoKnown_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enoKnown(V v_x_240) {
top: ;
  return NTAG(TAG_False);
}
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enoKnown(a0); heff_drop(a0); return r;
}