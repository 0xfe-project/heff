// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Asg 13569
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_KnownCell 38933
#define TAG_KnownTag 34380
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_Ret 29485
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_after 294093302
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_arms 9498206
#define LBL_body 9524841
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_name 9869138
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_op 10312
#define LBL_owned 307523263
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_prefix 967031229
#define LBL_prim 9944941
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_self 10021907
#define LBL_shapes 1043573789
#define LBL_source 1050636102
#define LBL_strs 10036521
#define LBL_tags 10047712
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_prim__args__arms[] = {LBL_prim, LBL_args, LBL_arms};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known[] = {LBL_tags, LBL_lbls, LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known};
V g_heff_2eeffect_2elastOr(V, V);
V g_heff_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eeffect_2elastOr_clo;
V g_heff_2eemit_2ebounceGo(V, V);
V g_heff_2eemit_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebounceGo_clo;
V g_heff_2eemitc_2eaddLam(V, V, V);
V g_heff_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eaddLam_clo;
V g_heff_2eemitc_2eagain(V, V);
V g_heff_2eemitc_2eagain_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eagain_clo;
V g_heff_2eemitc_2eagrees(V, V, V);
V g_heff_2eemitc_2eagrees_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eagrees_clo;
V g_heff_2eemitc_2earityOne(V, V);
V g_heff_2eemitc_2earityOne_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earityOne_clo;
V g_heff_2eemitc_2earmFor(V, V);
V g_heff_2eemitc_2earmFor_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earmFor_clo;
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earmKept_24s1599190246x1726307436_clo;
V g_heff_2eemitc_2earmLines_24s1383923797x88700679(V, V, V, V, V, V);
V g_heff_2eemitc_2earmLines_24s1383923797x88700679_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earmLines_24s1383923797x88700679_clo;
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827(V, V, V);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebindTo_24s468035823x1139231827_clo;
V g_heff_2eemitc_2eborAll(V, V);
V g_heff_2eemitc_2eborAll_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborAll_clo;
V g_heff_2eemitc_2eborDef(V, V);
V g_heff_2eemitc_2eborDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborDef_clo;
V g_heff_2eemitc_2eborFix(V, V, V);
V g_heff_2eemitc_2eborFix_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborFix_clo;
V g_heff_2eemitc_2ebuildsSize(V, V);
V g_heff_2eemitc_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebuildsSize_clo;
V g_heff_2eemitc_2ebuiltOf(V);
V g_heff_2eemitc_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebuiltOf_clo;
V g_heff_2eemitc_2ecallText(V, V, V);
V g_heff_2eemitc_2ecallText_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecallText_clo;
V g_heff_2eemitc_2ecatMaybesC(V);
V g_heff_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecatMaybesC_clo;
V g_heff_2eemitc_2eceOf(V, V, V);
V g_heff_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eceOf_clo;
V g_heff_2eemitc_2echeckEnd(V, V, V);
V g_heff_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2eemitc_2echeckEnd_clo;
V g_heff_2eemitc_2echeckOut(V, V, V);
V g_heff_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2eemitc_2echeckOut_clo;
V g_heff_2eemitc_2ecompF_24s2137331x87770527(V, V, V);
V g_heff_2eemitc_2ecompF_24s2137331x87770527_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecompF_24s2137331x87770527_clo;
V g_heff_2eemitc_2econdArm_24s142880068x1419285363(V, V, V, V);
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_entry(V self, V *a);
extern Clo g_heff_2eemitc_2econdArm_24s142880068x1419285363_clo;
V g_heff_2eemitc_2econdLet(V, V, V);
V g_heff_2eemitc_2econdLet_entry(V self, V *a);
extern Clo g_heff_2eemitc_2econdLet_clo;
V g_heff_2eemitc_2econdOn(V, V, V, V, V);
V g_heff_2eemitc_2econdOn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2econdOn_clo;
V g_heff_2eemitc_2econdPrims_get(void);
V g_heff_2eemitc_2econdWith_24s1979740468x338110168(V, V, V, V, V);
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_entry(V self, V *a);
extern Clo g_heff_2eemitc_2econdWith_24s1979740468x338110168_clo;
V g_heff_2eemitc_2edeclOf(V, V);
V g_heff_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edeclOf_clo;
V g_heff_2eemitc_2edefC(V, V);
V g_heff_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edefC_clo;
V g_heff_2eemitc_2edefOwn(V, V);
V g_heff_2eemitc_2edefOwn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edefOwn_clo;
V g_heff_2eemitc_2edropAs(V, V);
V g_heff_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edropAs_clo;
V g_heff_2eemitc_2edropsIn(V, V);
V g_heff_2eemitc_2edropsIn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2edropsIn_clo;
V g_heff_2eemitc_2eelemI(V, V);
V g_heff_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eelemI_clo;
V g_heff_2eemitc_2eelemS(V, V);
V g_heff_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eelemS_clo;
V g_heff_2eemitc_2eemptyCS_get(void);
V g_heff_2eemitc_2eentryCall(V, V, V);
V g_heff_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eentryCall_clo;
V g_heff_2eemitc_2eentryPart_get(void);
V g_heff_2eemitc_2efieldLine(V, V, V, V);
V g_heff_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efieldLine_clo;
V g_heff_2eemitc_2efieldMask(V, V, V);
V g_heff_2eemitc_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efieldMask_clo;
V g_heff_2eemitc_2efixedLit(V, V);
V g_heff_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efixedLit_clo;
V g_heff_2eemitc_2efreeGo(V, V, V, V);
V g_heff_2eemitc_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efreeGo_clo;
V g_heff_2eemitc_2efreeOf(V, V);
V g_heff_2eemitc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efreeOf_clo;
V g_heff_2eemitc_2efunDef(V, V, V, V);
V g_heff_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efunDef_clo;
V g_heff_2eemitc_2efvW(V, V, V);
V g_heff_2eemitc_2efvW_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efvW_clo;
V g_heff_2eemitc_2eglobalGet(V, V);
V g_heff_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eglobalGet_clo;
V g_heff_2eemitc_2ehashBelow(V, V, V, V);
V g_heff_2eemitc_2ehashBelow_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ehashBelow_clo;
V g_heff_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ehashedGo_clo;
V g_heff_2eemitc_2eheldVar(V, V);
V g_heff_2eemitc_2eheldVar_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eheldVar_clo;
V g_heff_2eemitc_2eidentAt(V, V, V);
V g_heff_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eidentAt_clo;
V g_heff_2eemitc_2einPlace(V);
V g_heff_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2eemitc_2einPlace_clo;
V g_heff_2eemitc_2eisAlnum(V);
V g_heff_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eisAlnum_clo;
V g_heff_2eemitc_2eisCondCall(V);
V g_heff_2eemitc_2eisCondCall_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eisCondCall_clo;
V g_heff_2eemitc_2eisMatchOn(V, V);
V g_heff_2eemitc_2eisMatchOn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eisMatchOn_clo;
V g_heff_2eemitc_2eknowCell(V, V, V);
V g_heff_2eemitc_2eknowCell_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eknowCell_clo;
V g_heff_2eemitc_2eknowing(V, V, V);
V g_heff_2eemitc_2eknowing_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eknowing_clo;
V g_heff_2eemitc_2eknownLet(V, V, V);
V g_heff_2eemitc_2eknownLet_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eknownLet_clo;
V g_heff_2eemitc_2eknownTags_get(void);
V g_heff_2eemitc_2elamBody_24s1136853347x1274611651(V, V, V, V);
V g_heff_2eemitc_2elamBody_24s1136853347x1274611651_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elamBody_24s1136853347x1274611651_clo;
V g_heff_2eemitc_2elamLines(V, V, V, V, V);
V g_heff_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elamLines_clo;
V g_heff_2eemitc_2elamWith_24s1720691912x77217039(V, V, V, V, V, V);
V g_heff_2eemitc_2elamWith_24s1720691912x77217039_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elamWith_24s1720691912x77217039_clo;
V g_heff_2eemitc_2elastDotGo(V, V, V);
V g_heff_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elastDotGo_clo;
V g_heff_2eemitc_2elentOne_24s809384060x928837097(V, V, V, V, V);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentOne_24s809384060x928837097_clo;
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519(V, V, V, V, V);
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentOperands_24s789057135x1152969519_clo;
V g_heff_2eemitc_2elentVar(V, V, V);
V g_heff_2eemitc_2elentVar_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentVar_clo;
V g_heff_2eemitc_2elentVars(V, V);
V g_heff_2eemitc_2elentVars_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elentVars_clo;
V g_heff_2eemitc_2eletOrCond_24s941639003x471531944(V, V, V, V, V, V);
V g_heff_2eemitc_2eletOrCond_24s941639003x471531944_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eletOrCond_24s941639003x471531944_clo;
V g_heff_2eemitc_2eletReuse(V, V, V, V, V);
V g_heff_2eemitc_2eletReuse_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eletReuse_clo;
V g_heff_2eemitc_2eletWith_24s1758357723x678407587(V, V, V, V, V, V, V);
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eletWith_24s1758357723x678407587_clo;
V g_heff_2eemitc_2eloopLent(V, V, V, V);
V g_heff_2eemitc_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eloopLent_clo;
V g_heff_2eemitc_2emangleChar(V);
V g_heff_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emangleChar_clo;
V g_heff_2eemitc_2emangleW(V, V, V, V);
V g_heff_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emangleW_clo;
V g_heff_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emodulePart_clo;
V g_heff_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enamesInGo_clo;
V g_heff_2eemitc_2enamesTable(V, V);
V g_heff_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enamesTable_clo;
V g_heff_2eemitc_2enewLam(V);
V g_heff_2eemitc_2enewLam_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enewLam_clo;
V g_heff_2eemitc_2enumbered(V, V, V);
V g_heff_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enumbered_clo;
V g_heff_2eemitc_2enumbersOf(V, V);
V g_heff_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enumbersOf_clo;
V g_heff_2eemitc_2eonceInOrder(V, V);
V g_heff_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eonceInOrder_clo;
V g_heff_2eemitc_2eonlyLent(V, V, V);
V g_heff_2eemitc_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eonlyLent_clo;
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247(V, V, V);
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eoperandsF_24s483563689x9672247_clo;
V g_heff_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eoutputOf_clo;
V g_heff_2eemitc_2eownHas(V, V, V);
V g_heff_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eownHas_clo;
V g_heff_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eownLines_clo;
V g_heff_2eemitc_2eparamsAt(V, V, V);
V g_heff_2eemitc_2eparamsAt_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eparamsAt_clo;
V g_heff_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epartsWith_clo;
V g_heff_2eemitc_2eperformNodes(V, V);
V g_heff_2eemitc_2eperformNodes_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eperformNodes_clo;
V g_heff_2eemitc_2eplusDone(V, V, V, V);
V g_heff_2eemitc_2eplusDone_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eplusDone_clo;
V g_heff_2eemitc_2epow2(V);
V g_heff_2eemitc_2epow2_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epow2_clo;
V g_heff_2eemitc_2eprimCloDef(V);
V g_heff_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprimCloDef_clo;
V g_heff_2eemitc_2eprimLit(V, V);
V g_heff_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprimLit_clo;
V g_heff_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprogramCE_clo;
V g_heff_2eemitc_2eprogramParts(V, V, V, V);
V g_heff_2eemitc_2eprogramParts_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprogramParts_clo;
V g_heff_2eemitc_2epubLine(V);
V g_heff_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epubLine_clo;
V g_heff_2eemitc_2erelFixed(V);
V g_heff_2eemitc_2erelFixed_entry(V self, V *a);
extern Clo g_heff_2eemitc_2erelFixed_clo;
V g_heff_2eemitc_2ereuseArgs(V, V);
V g_heff_2eemitc_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuseArgs_clo;
V g_heff_2eemitc_2ereuseIn(V, V, V);
V g_heff_2eemitc_2ereuseIn_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuseIn_clo;
V g_heff_2eemitc_2ereusePrim_get(void);
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724(V, V, V);
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_clo;
V g_heff_2eemitc_2ereusedOf(V);
V g_heff_2eemitc_2ereusedOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereusedOf_clo;
V g_heff_2eemitc_2ereuses(V, V);
V g_heff_2eemitc_2ereuses_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereuses_clo;
V g_heff_2eemitc_2ereusing(V, V, V, V);
V g_heff_2eemitc_2ereusing_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ereusing_clo;
V g_heff_2eemitc_2erunEnd(V, V);
V g_heff_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2eemitc_2erunEnd_clo;
V g_heff_2eemitc_2escrutF_24s625241799x1100958611(V, V);
V g_heff_2eemitc_2escrutF_24s625241799x1100958611_entry(V self, V *a);
extern Clo g_heff_2eemitc_2escrutF_24s625241799x1100958611_clo;
V g_heff_2eemitc_2eshapeDef(V);
V g_heff_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eshapeDef_clo;
V g_heff_2eemitc_2eshapeLit(V, V);
V g_heff_2eemitc_2eshapeLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eshapeLit_clo;
V g_heff_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eslotFrom_clo;
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(V, V, V);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_entry(V self, V *a);
extern Clo g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_clo;
V g_heff_2eemitc_2estrDef(V, V);
V g_heff_2eemitc_2estrDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2estrDef_clo;
V g_heff_2eemitc_2estrLit(V, V);
V g_heff_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2eemitc_2estrLit_clo;
V g_heff_2eemitc_2esunkGo(V, V, V);
V g_heff_2eemitc_2esunkGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2esunkGo_clo;
V g_heff_2eemitc_2etagsLbls(V);
V g_heff_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etagsLbls_clo;
V g_heff_2eemitc_2etakeKept(V, V, V, V);
V g_heff_2eemitc_2etakeKept_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etakeKept_clo;
V g_heff_2eemitc_2etakenFv(V, V, V, V);
V g_heff_2eemitc_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etakenFv_clo;
V g_heff_2eemitc_2etraverseC(V, V);
V g_heff_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etraverseC_clo;
V g_heff_2eemitc_2eusedBy(V, V);
V g_heff_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eusedBy_clo;
V g_heff_2eemitc_2evalDef(V, V);
V g_heff_2eemitc_2evalDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2evalDef_clo;
V g_heff_2eemitc_2evalF_24s1143988364x1058982433(V, V, V);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_entry(V self, V *a);
extern Clo g_heff_2eemitc_2evalF_24s1143988364x1058982433_clo;
V g_heff_2eemitc_2evarUse(V, V, V);
V g_heff_2eemitc_2evarUse_entry(V self, V *a);
extern Clo g_heff_2eemitc_2evarUse_clo;
V g_heff_2eemitc_2ezipDE(V, V);
V g_heff_2eemitc_2ezipDE_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ezipDE_clo;
V g_heff_2efixed_2efixedPrimOf(V);
V g_heff_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedPrimOf_clo;
V g_heff_2eir_2efreshGo_24s1749472566x1664180022(V, V, V);
V g_heff_2eir_2efreshGo_24s1749472566x1664180022_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshGo_24s1749472566x1664180022_clo;
V g_heff_2eir_2epushArms(V, V);
V g_heff_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2eir_2epushArms_clo;
V g_heff_2eir_2epushFields(V, V);
V g_heff_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2eir_2epushFields_clo;
V g_heff_2elower_2eentryKey_get(void);
V g_heff_2eprims_2eallPrims_get(void);
V g_heff_2eprims_2eprimArityGo(V, V);
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2eprims_2eprimArityGo_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1175244903x419753027(V);
V g_list_2eall_24s1175244903x419753027_entry(V self, V *a);
extern Clo g_list_2eall_24s1175244903x419753027_clo;
V g_list_2eall_24s1225041428x2030583288(V);
V g_list_2eall_24s1225041428x2030583288_entry(V self, V *a);
extern Clo g_list_2eall_24s1225041428x2030583288_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1438978125x414501573(V);
V g_list_2eany_24s1438978125x414501573_entry(V self, V *a);
extern Clo g_list_2eany_24s1438978125x414501573_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1412390516x2102311772(V);
V g_list_2efilter_24s1412390516x2102311772_entry(V self, V *a);
extern Clo g_list_2efilter_24s1412390516x2102311772_clo;
V g_list_2efilter_24s1477606187x944222946(V);
V g_list_2efilter_24s1477606187x944222946_entry(V self, V *a);
extern Clo g_list_2efilter_24s1477606187x944222946_clo;
V g_list_2efilter_24s2056490818x625949248(V, V);
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_clo;
V g_list_2efilter_24s314366508x59199896(V);
V g_list_2efilter_24s314366508x59199896_entry(V self, V *a);
extern Clo g_list_2efilter_24s314366508x59199896_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1112037391x343083959(V, V, V, V);
V g_list_2efoldl_24s1112037391x343083959_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1112037391x343083959_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1127955551x950394381(V, V);
V g_list_2efoldl_24s1127955551x950394381_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1127955551x950394381_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1187012699x1099443358(V, V);
V g_list_2efoldl_24s1187012699x1099443358_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1187012699x1099443358_clo;
V g_list_2efoldl_24s122245128x1667515165(V, V);
V g_list_2efoldl_24s122245128x1667515165_entry(V self, V *a);
extern Clo g_list_2efoldl_24s122245128x1667515165_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1537290326x1300290376(V, V);
V g_list_2efoldl_24s1537290326x1300290376_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1537290326x1300290376_clo;
V g_list_2efoldl_24s153737048x1104410749(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s153737048x1104410749_entry(V self, V *a);
extern Clo g_list_2efoldl_24s153737048x1104410749_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1670799345x2002421308(V, V);
V g_list_2efoldl_24s1670799345x2002421308_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1670799345x2002421308_clo;
V g_list_2efoldl_24s1885051946x1524849902(V, V);
V g_list_2efoldl_24s1885051946x1524849902_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1885051946x1524849902_clo;
V g_list_2efoldl_24s1889728774x506508078(V, V);
V g_list_2efoldl_24s1889728774x506508078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1889728774x506508078_clo;
V g_list_2efoldl_24s1958541883x442288263(V, V);
V g_list_2efoldl_24s1958541883x442288263_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1958541883x442288263_clo;
V g_list_2efoldl_24s1984245835x1989432102(V, V);
V g_list_2efoldl_24s1984245835x1989432102_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1984245835x1989432102_clo;
V g_list_2efoldl_24s638445529x932797857(V, V);
V g_list_2efoldl_24s638445529x932797857_entry(V self, V *a);
extern Clo g_list_2efoldl_24s638445529x932797857_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s966961137x2098673946(V, V);
V g_list_2efoldl_24s966961137x2098673946_entry(V self, V *a);
extern Clo g_list_2efoldl_24s966961137x2098673946_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1006477676x1816442814(V, V, V);
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_clo;
V g_list_2emap_24s1039286686x792451646(V, V, V, V, V, V, V);
V g_list_2emap_24s1039286686x792451646_entry(V self, V *a);
extern Clo g_list_2emap_24s1039286686x792451646_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1328195927x21044528(V, V);
V g_list_2emap_24s1328195927x21044528_entry(V self, V *a);
extern Clo g_list_2emap_24s1328195927x21044528_clo;
V g_list_2emap_24s1339179958x587003135(V);
V g_list_2emap_24s1339179958x587003135_entry(V self, V *a);
extern Clo g_list_2emap_24s1339179958x587003135_clo;
V g_list_2emap_24s1363203549x1204645634(V);
V g_list_2emap_24s1363203549x1204645634_entry(V self, V *a);
extern Clo g_list_2emap_24s1363203549x1204645634_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1377907145x510226651(V);
V g_list_2emap_24s1377907145x510226651_entry(V self, V *a);
extern Clo g_list_2emap_24s1377907145x510226651_clo;
V g_list_2emap_24s1378753456x1787722089(V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_clo;
V g_list_2emap_24s1573559022x513331157(V, V, V);
V g_list_2emap_24s1573559022x513331157_entry(V self, V *a);
extern Clo g_list_2emap_24s1573559022x513331157_clo;
V g_list_2emap_24s1653859898x762241412(V);
V g_list_2emap_24s1653859898x762241412_entry(V self, V *a);
extern Clo g_list_2emap_24s1653859898x762241412_clo;
V g_list_2emap_24s1711626084x463433445(V);
V g_list_2emap_24s1711626084x463433445_entry(V self, V *a);
extern Clo g_list_2emap_24s1711626084x463433445_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1953731716x1367196380(V);
V g_list_2emap_24s1953731716x1367196380_entry(V self, V *a);
extern Clo g_list_2emap_24s1953731716x1367196380_clo;
V g_list_2emap_24s2006210321x387008715(V);
V g_list_2emap_24s2006210321x387008715_entry(V self, V *a);
extern Clo g_list_2emap_24s2006210321x387008715_clo;
V g_list_2emap_24s231476130x1974273190(V, V, V, V, V, V);
V g_list_2emap_24s231476130x1974273190_entry(V self, V *a);
extern Clo g_list_2emap_24s231476130x1974273190_clo;
V g_list_2emap_24s242536205x1745537053(V);
V g_list_2emap_24s242536205x1745537053_entry(V self, V *a);
extern Clo g_list_2emap_24s242536205x1745537053_clo;
V g_list_2emap_24s455042168x142217368(V, V, V, V, V, V, V);
V g_list_2emap_24s455042168x142217368_entry(V self, V *a);
extern Clo g_list_2emap_24s455042168x142217368_clo;
V g_list_2emap_24s46845351x1913259050(V);
V g_list_2emap_24s46845351x1913259050_entry(V self, V *a);
extern Clo g_list_2emap_24s46845351x1913259050_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1947952772x1156675739(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1947952772x1156675739_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1947952772x1156675739_clo;
V g_list_2ezipWith_24s2075573643x1334977728(V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s2075573643x1334977728_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2075573643x1334977728_clo;
V g_list_2ezipWith_24s259431397x671561817(V, V);
V g_list_2ezipWith_24s259431397x671561817_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s259431397x671561817_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2eemitc_2eisAlnum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eisAlnum_entry, 1, 0};

V g_heff_2eemitc_2eisAlnum(V v_c_240) {
top: ;
  if (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240))) {
    if (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL))) {
      heff_drop(v_c_240);
      return NTAG(TAG_True);
    } else {
      if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240))) {
        if (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL))) {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        } else {
          if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
            return heff_intLe(v_c_240, MK_INT(57LL));
          } else {
            heff_drop(v_c_240);
            return NTAG(TAG_False);
          }
        }
      } else {
        if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
          return heff_intLe(v_c_240, MK_INT(57LL));
        } else {
          heff_drop(v_c_240);
          return NTAG(TAG_False);
        }
      }
    }
  } else {
    if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240))) {
      if (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL))) {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      } else {
        if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
          return heff_intLe(v_c_240, MK_INT(57LL));
        } else {
          heff_drop(v_c_240);
          return NTAG(TAG_False);
        }
      }
    } else {
      if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
        return heff_intLe(v_c_240, MK_INT(57LL));
      } else {
        heff_drop(v_c_240);
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2eemitc_2eisAlnum_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eisAlnum(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2emangleChar_str0 = {{0x80000000u, K_STR, 0}, 16, 16, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2emangleChar_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2emangleChar_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2eemitc_2emangleChar(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2eemitc_2eisAlnum(heff_dup(v_c_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    return heff_strFromCharCode(v_c_240);
  }
  case TAG_False: {
    V v_t_242 = heff_intMod(heff_dup(v_c_240), MK_INT(256LL));
    V v_d_243 = heff_intDiv(v_t_242, MK_INT(16LL));
    V v_t_244 = heff_strSlice(((V)&g_heff_2eemitc_2emangleChar_str0), heff_dup(v_d_243), heff_intAdd(v_d_243, MK_INT(1LL)));
    V v_d_245 = heff_intMod(v_c_240, MK_INT(16LL));
    V v_t_246 = heff_strSlice(((V)&g_heff_2eemitc_2emangleChar_str1), heff_dup(v_d_245), heff_intAdd(v_d_245, MK_INT(1LL)));
    return heff_strAppend(((V)&g_heff_2eemitc_2emangleChar_str2), heff_strAppend(v_t_244, v_t_246));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2emangleChar(a[0]);
}
Clo g_heff_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_j_242), heff_strLength(heff_dup(v_s_240)))) {
    v_t_245 = (g_heff_2eemitc_2eisAlnum(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_242))));
  } else {
    v_t_245 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V t_0 = v_s_240;
    V t_1 = v_i_241;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_acc_243;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  case TAG_False: {
    if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_242))) {
      return heff_strAppend(v_acc_243, heff_strSlice(v_s_240, v_i_241, v_j_242));
    } else {
      V v_t_247 = heff_strAppend(v_acc_243, heff_strAppend(heff_strSlice(heff_dup(v_s_240), v_i_241, heff_dup(v_j_242)), (g_heff_2eemitc_2emangleChar(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_242))))));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
      V t_3 = v_t_247;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2emangleW(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eknownTags_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eknownTags_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {77, 107, 80, 97, 105, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eknownTags_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eknownTags_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {74, 117, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2eknownTags_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {78, 111, 116, 104, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eknownTags_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eknownTags_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {77, 107, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eknownTags_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eknownTags_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eknownTags_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};

static V g_heff_2eemitc_2eknownTags_val;
static int g_heff_2eemitc_2eknownTags_st;
static V g_heff_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2eemitc_2eknownTags_get(void) {
  if (g_heff_2eemitc_2eknownTags_st == 2) return g_heff_2eemitc_2eknownTags_val;
  if (g_heff_2eemitc_2eknownTags_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2eknownTags_st = 1;
  g_heff_2eemitc_2eknownTags_val = heff_tr(g_heff_2eemitc_2eknownTags_init());
  g_heff_2eemitc_2eknownTags_st = 2;
  return g_heff_2eemitc_2eknownTags_val;
}
Clo g_heff_2eemitc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eelemS_entry, 2, 0};

V g_heff_2eemitc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eelemS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eelemS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_list_2efoldl_24s1127955551x950394381(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_list_2efoldl_24s1127955551x950394381(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_ls_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2415)));
    V v_es_2417 = (g_list_2emap_24s1173914895x100384474(v_fs_2415));
    V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2417));
    V v_x2_2420 = (g_list_2efoldl_24s1127955551x950394381(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, (g_prelude_2e_2b_2b(v_ls_2416, v_ls2_2422))});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2423 = heff_field(v_x1_240, 0);
    V v_l_2424 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EProj = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_2425 = (g_heff_2eemitc_2etagsLbls(v_e_2423));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_ts_2426 = heff_field(v_x2_2425, 0);
      V v_ls2_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
      V v_t_2428 = heff_tag_at(v_ru_24x1_240_24EProj, TAG_Cons, 2, (V[]){v_l_2424, NTAG(TAG_Nil)});
      return heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2426, (g_prelude_2e_2b_2b(v_t_2428, v_ls2_2427))});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  case TAG_ETag: {
    V v_t_2429 = heff_field(v_x1_240, 0);
    V v_as_2430 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2431 = heff_tag_at(v_ru_24x1_240_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2430));
    V v_x2_2433 = (g_list_2efoldl_24s1127955551x950394381(v_t_2431, v_t_2432));
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_MkPair: {
      V v_ts2_2434 = heff_field(v_x2_2433, 0);
      V v_ls_2435 = heff_field(v_x2_2433, 1);
      V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
      V v_t_2436 = heff_tag_at(v_ru_24x2_2433_24MkPair, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
      V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2436, v_ts2_2434));
      return heff_tag(TAG_MkPair, 2, (V[]){v_t_2437, v_ls_2435});
    }
    default: return heff_nomatch(v_x2_2433);
    }
  }
  case TAG_EMatch: {
    V v_s_2438 = heff_field(v_x1_240, 0);
    V v_arms_2439 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2440 = (g_list_2emap_24s46845351x1913259050(heff_dup(v_arms_2439)));
    V v_es_2441 = heff_tag_at(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2438, (g_list_2emap_24s2006210321x387008715(v_arms_2439))});
    V v_t_2442 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2441));
    V v_x2_2444 = (g_list_2efoldl_24s1127955551x950394381(v_t_2442, v_t_2443));
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_MkPair: {
      V v_ts2_2445 = heff_field(v_x2_2444, 0);
      V v_ls_2446 = heff_field(v_x2_2444, 1);
      V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
      V v_t_2447 = (g_prelude_2e_2b_2b(v_ts_2440, v_ts2_2445));
      return heff_tag_at(v_ru_24x2_2444_24MkPair, TAG_MkPair, 2, (V[]){v_t_2447, v_ls_2446});
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2450 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2451 = heff_tag_at(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2450));
    return (g_list_2efoldl_24s1127955551x950394381(v_t_2451, v_t_2452));
  }
  case TAG_ECall: {
    V v_as_2454 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2455 = heff_tag_at(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2454));
    return (g_list_2efoldl_24s1127955551x950394381(v_t_2455, v_t_2456));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength(heff_dup(v_text_240)))) {
    V v_t_244 = (g_heff_2eemitc_2eisAlnum(heff_strCharCode(heff_dup(v_text_240), heff_dup(v_i_242))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    case TAG_False: {
      if (heff_intEq_c(heff_strCharCode(heff_dup(v_text_240), heff_dup(v_i_242)), MK_INT(95LL))) {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
}
V g_heff_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_text_241), heff_dup(v_i_242), heff_strLength(heff_dup(v_text_241)));
  V v_t_245 = (g_prelude_2eindexFrom(heff_dup(v_pre_240), v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_pre_240);
    heff_drop(v_text_241);
    heff_drop(v_i_242);
    return v_acc_243;
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_248 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_249 = heff_intAdd(heff_intAdd(v_i_242, v_j_246), heff_strLength(heff_dup(v_pre_240)));
    V v_t_2410 = (g_heff_2eemitc_2eidentAt(heff_dup(v_text_241), v_t_248, v_t_249));
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_247;
    V t_3 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2enamesInGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_m_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), heff_dup(v_n_240), v_m_242));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_t_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V t_0 = v_n_240;
      V t_1 = v_xs_244;
      V t_2 = v_m_242;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2enumbered(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2eemitc_2ehashBelow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ehashBelow_entry, 4, 0};

V g_heff_2eemitc_2ehashBelow(V v_t_240, V v_m_241, V v_i_242, V v_a_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_t_240)), heff_dup(v_i_242))) {
    heff_drop(v_t_240);
    heff_drop(v_m_241);
    heff_drop(v_i_242);
    return v_a_243;
  } else {
    V v_t_245 = heff_intAdd(heff_intMul(v_a_243, MK_INT(31LL)), heff_strCharCode(heff_dup(v_t_240), heff_dup(v_i_242)));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), heff_dup(v_m_241));
    V t_0 = v_t_240;
    V t_1 = v_m_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_t_246;
    v_t_240 = t_0;
    v_m_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  }
}
V g_heff_2eemitc_2ehashBelow_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ehashBelow(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s1338854231x236594845(heff_intAdd(heff_dup(v_base_240), heff_dup(v_h_242)), v_taken_243));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return heff_intAdd(v_base_240, v_h_242);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_246 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
    V t_0 = v_base_240;
    V t_1 = v_m_241;
    V t_2 = v_t_246;
    V t_3 = v_taken_243;
    v_base_240 = t_0;
    v_m_241 = t_1;
    v_h_242 = t_2;
    v_taken_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eslotFrom(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_heff_2eemitc_2ehashedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ehashedGo_entry, 5, 0};

V g_heff_2eemitc_2ehashedGo(V v_base_240, V v_m_241, V v_x3_242, V v_names_243, V v_taken_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_base_240);
    heff_drop(v_m_241);
    heff_drop(v_taken_244);
    return v_names_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_245), v_names_243));
    V v_t_249;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      v_t_249 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_xs_246;
      V t_3 = v_names_243;
      V t_4 = v_taken_244;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      v_names_243 = t_3;
      v_taken_244 = t_4;
      goto top;
    }
    case TAG_False: {
      V v_t_2410 = (g_heff_2eemitc_2ehashBelow(heff_dup(v_x_245), heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
      V v_t_2411 = (g_heff_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2410, v_taken_244));
      V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_245), v_t_2411, v_names_243));
      V v_t_2413 = (g_heff_2eemitc_2ehashBelow(heff_dup(v_x_245), heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
      V v_t_2414 = (g_heff_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2413, v_taken_244));
      V v_t_2415 = (g_map_2einsert_24s1689409319x1710080871(v_t_2414, NTAG(TAG_MkUnit), v_taken_244));
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_xs_246;
      V t_3 = v_t_2412;
      V t_4 = v_t_2415;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      v_names_243 = t_3;
      v_taken_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2ehashedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ehashedGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2etraverseC_lam0(V self, V *args); static Clo g_heff_2eemitc_2etraverseC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etraverseC_lam0, 1, 0};
V g_heff_2eemitc_2etraverseC_lam1(V self, V *args);
Clo g_heff_2eemitc_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etraverseC_entry, 2, 0};

V g_heff_2eemitc_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eemitc_2etraverseC_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo(g_heff_2eemitc_2etraverseC_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2etraverseC(a[0], a[1]);
}
V g_heff_2eemitc_2etraverseC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2eemitc_2etraverseC_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2eemitc_2etraverseC(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_apply(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estrDef_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estrDef_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estrDef_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eemitc_2estrDef_str3 = {{0x80000000u, K_STR, 0}, 60, 60, {115, 116, 97, 116, 105, 99, 32, 115, 116, 114, 117, 99, 116, 32, 123, 32, 79, 98, 106, 32, 104, 59, 32, 105, 110, 116, 54, 52, 95, 116, 32, 108, 101, 110, 59, 32, 105, 110, 116, 54, 52, 95, 116, 32, 99, 97, 112, 59, 32, 117, 105, 110, 116, 49, 54, 95, 116, 32, 115, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2estrDef_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {93, 59, 32, 125, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eemitc_2estrDef_str5 = {{0x80000000u, K_STR, 0}, 29, 29, {32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 83, 84, 82, 44, 32, 48, 125, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estrDef_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estrDef_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {44, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estrDef_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {125, 125, 59}};
V g_heff_2eemitc_2estrDef_lam0(V self, V *args);
Clo g_heff_2eemitc_2estrDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2estrDef_entry, 2, 0};

V g_heff_2eemitc_2estrDef(V v_name_240, V v_str_241) {
top: ;
  V v_t_243;
  if (heff_intEq_c(heff_strLength(heff_dup(v_str_241)), MK_INT(0LL))) {
    v_t_243 = MK_INT(1LL);
  } else {
    v_t_243 = heff_strLength(heff_dup(v_str_241));
  }
  V v_t_244 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
  V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
  V v_t_2413;
  if (heff_intEq_c(heff_strLength(heff_dup(v_str_241)), MK_INT(0LL))) {
    heff_drop(v_str_241);
    v_t_2413 = ((V)&g_heff_2eemitc_2estrDef_str0);
  } else {
    V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_str_241)), MK_INT(1LL));
    V v_t_248 = (g_list_2erange(MK_INT(0LL), v_t_247));
    V v_x2_2410 = (g_list_2emap(heff_clo(g_heff_2eemitc_2estrDef_lam0, 1, 1, (V[]){v_str_241}), v_t_248));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2eemitc_2estrDef_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2eemitc_2estrDef_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str3), heff_strAppend(heff_intShow(v_t_243), heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str4), heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str5), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str6), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str7), heff_strAppend(v_t_2413, ((V)&g_heff_2eemitc_2estrDef_str8)))))))))));
}
V g_heff_2eemitc_2estrDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2estrDef(a[0], a[1]);
}
V g_heff_2eemitc_2estrDef_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_str_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intShow(heff_strCharCode(v_str_241, v_i_249));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2estrLit_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estrLit_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estrLit_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estrLit_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 115, 116, 114}};
Clo g_heff_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2estrLit_entry, 2, 0};

V g_heff_2eemitc_2estrLit(V v_str_240, V v_s_241) {
top: ;
  V v_t_242 = heff_intShow(heff_get(heff_dup(v_s_241), LBL_nstr));
  V v_t_243 = heff_strAppend(((V)&g_heff_2eemitc_2estrLit_str0), heff_strAppend(heff_get(heff_dup(v_s_241), LBL_owner), heff_strAppend(((V)&g_heff_2eemitc_2estrLit_str1), heff_strAppend(v_t_242, ((V)&g_heff_2eemitc_2estrLit_str2)))));
  V v_t_244 = heff_intAdd(heff_get(heff_dup(v_s_241), LBL_nstr), MK_INT(1LL));
  V v_t_245 = heff_intShow(heff_get(heff_dup(v_s_241), LBL_nstr));
  V v_t_246 = heff_strAppend(heff_get(heff_dup(v_s_241), LBL_owner), heff_strAppend(((V)&g_heff_2eemitc_2estrLit_str3), v_t_245));
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), (g_heff_2eemitc_2estrDef(v_t_246, v_str_240))});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, heff_get(heff_dup(v_s_241), LBL_strs)});
  V v_t_249 = heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), heff_get(heff_dup(v_s_241), LBL_nlam), heff_get(heff_dup(v_s_241), LBL_lams), heff_get(heff_dup(v_s_241), LBL_protos), v_t_244, v_t_248, heff_get(heff_dup(v_s_241), LBL_shapes), heff_get(v_s_241, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_243, v_t_249});
}
V g_heff_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2estrLit(a[0], a[1]);
}
Clo g_heff_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c(heff_dup(v_o_240), heff_dup(v_o2_245))) {
        if (heff_strEq_c(heff_dup(v_k_241), heff_dup(v_k2_246))) {
          heff_drop(v_o_240);
          heff_drop(v_k_241);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_o_240);
        heff_drop(v_k_241);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eownHas(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eshapeLit_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eshapeLit_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {95, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eshapeLit_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eshapeLit_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {95, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eshapeLit_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 104, 97, 112, 101, 95}};
Clo g_heff_2eemitc_2eshapeLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eshapeLit_entry, 2, 0};

V g_heff_2eemitc_2eshapeLit(V v_ls_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s1953731716x1367196380(heff_dup(v_ls_240)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2eemitc_2eshapeLit_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2eemitc_2eshapeLit_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_o_246 = heff_get(heff_dup(v_s_241), LBL_owner);
  V v_x2_247 = (g_list_2emap_24s1953731716x1367196380(v_ls_240));
  V v_k_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_k_2410 = ((V)&g_heff_2eemitc_2eshapeLit_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_k_2410 = ({ V a_0 = ((V)&g_heff_2eemitc_2eshapeLit_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_ps_2411 = heff_get(heff_dup(v_s_241), LBL_shapes);
  V v_t_2412 = (g_heff_2eemitc_2eownHas(heff_dup(v_o_246), heff_dup(v_k_2410), v_ps_2411));
  V v_t_2413;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_o_246);
    heff_drop(v_k_2410);
    v_t_2413 = v_ps_2411;
    break;
  }
  case TAG_False: {
    v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_o_246, v_k_2410}), v_ps_2411});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2414 = heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), heff_get(heff_dup(v_s_241), LBL_nlam), heff_get(heff_dup(v_s_241), LBL_lams), heff_get(heff_dup(v_s_241), LBL_protos), heff_get(heff_dup(v_s_241), LBL_nstr), heff_get(heff_dup(v_s_241), LBL_strs), v_t_2413, heff_get(v_s_241, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2eemitc_2eshapeLit_str4), v_t_245), v_t_2414});
}
V g_heff_2eemitc_2eshapeLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eshapeLit(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2eprimLit_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 40, 86, 41, 38, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eprimLit_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
Clo g_heff_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2eemitc_2eprimLit_str0), heff_strAppend(heff_dup(v_p_240), ((V)&g_heff_2eemitc_2eprimLit_str1)));
  V v_o_243 = heff_get(heff_dup(v_s_241), LBL_owner);
  V v_ps_244 = heff_get(heff_dup(v_s_241), LBL_prims);
  V v_t_245 = (g_heff_2eemitc_2eownHas(heff_dup(v_o_243), heff_dup(v_p_240), v_ps_244));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_p_240);
    heff_drop(v_o_243);
    v_t_246 = v_ps_244;
    break;
  }
  case TAG_False: {
    v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_o_243, v_p_240}), v_ps_244});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), heff_get(heff_dup(v_s_241), LBL_nlam), heff_get(heff_dup(v_s_241), LBL_lams), heff_get(heff_dup(v_s_241), LBL_protos), heff_get(heff_dup(v_s_241), LBL_nstr), heff_get(heff_dup(v_s_241), LBL_strs), heff_get(v_s_241, LBL_shapes), v_t_246});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_242, v_t_247});
}
V g_heff_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprimLit(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2enewLam_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 108, 97, 109}};
Clo g_heff_2eemitc_2enewLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enewLam_entry, 1, 0};

V g_heff_2eemitc_2enewLam(V v_s_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get(heff_dup(v_s_240), LBL_nlam));
  V v_t_242 = heff_strAppend(heff_get(heff_dup(v_s_240), LBL_owner), heff_strAppend(((V)&g_heff_2eemitc_2enewLam_str0), v_t_241));
  V v_t_243 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_nlam), MK_INT(1LL));
  V v_t_244 = heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){heff_get(heff_dup(v_s_240), LBL_owner), v_t_243, heff_get(heff_dup(v_s_240), LBL_lams), heff_get(heff_dup(v_s_240), LBL_protos), heff_get(heff_dup(v_s_240), LBL_nstr), heff_get(heff_dup(v_s_240), LBL_strs), heff_get(heff_dup(v_s_240), LBL_shapes), heff_get(v_s_240, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_242, v_t_244});
}
V g_heff_2eemitc_2enewLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2enewLam(a[0]);
}
Clo g_heff_2eemitc_2eaddLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eaddLam_entry, 3, 0};

V g_heff_2eemitc_2eaddLam(V v_proto_240, V v_def_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_s_242), LBL_owner), v_def_241});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_get(heff_dup(v_s_242), LBL_lams)});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_s_242), LBL_owner), v_proto_240});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_get(heff_dup(v_s_242), LBL_protos)});
  V v_t_247 = heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){heff_get(heff_dup(v_s_242), LBL_owner), heff_get(heff_dup(v_s_242), LBL_nlam), v_t_244, v_t_246, heff_get(heff_dup(v_s_242), LBL_nstr), heff_get(heff_dup(v_s_242), LBL_strs), heff_get(heff_dup(v_s_242), LBL_shapes), heff_get(v_s_242, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2eemitc_2eaddLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eaddLam(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2efvW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efvW_entry, 3, 0};

V g_heff_2eemitc_2efvW(V v_bs_240, V v_ms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_bs_240, v_ms_241});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_x_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V t_0 = v_bs_240;
      V t_1 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_ms_241});
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_249 = (g_prelude_2e_2b_2b(v_xs_247, v_bs_240));
      V t_0 = v_t_249;
      V t_1 = v_ms_241;
      V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x31_243, 0);
      V v_as_2411 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2412 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, (g_prelude_2e_2b_2b(v_as_2411, v_rest_244))});
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2412;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2413 = heff_field(v_x31_243, 0);
      V v_a_2414 = heff_field(v_x31_243, 1);
      V v_b_2415 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2416 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
      V t_0 = heff_tag(TAG_Cons, 2, (V[]){v_x_2413, v_bs_240});
      V t_1 = v_ms_241;
      V t_2 = v_t_2416;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2eir_2epushFields(v_fs_2417, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2418;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2422 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2423 = (g_prelude_2e_2b_2b(v_as_2422, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2423;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2424 = heff_field(v_x31_243, 0);
      V v_arms_2425 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2425)));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_2426); r_; });
      V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_bs_240));
      V v_t_2429 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2424, (g_heff_2eir_2epushArms(v_arms_2425, v_rest_244))});
      V t_0 = v_t_2428;
      V t_1 = v_ms_241;
      V t_2 = v_t_2429;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2432 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2433 = (g_prelude_2e_2b_2b(v_as_2432, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2433;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2435 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2436 = (g_prelude_2e_2b_2b(v_as_2435, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2436;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2efvW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2efvW(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efreeGo_entry, 4, 0};

V g_heff_2eemitc_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_bs_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_v_244), v_seen_241));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_v_244), NTAG(TAG_MkUnit), v_seen_241));
        V t_0 = v_bs_240;
        V t_1 = v_t_248;
        V t_2 = v_vs_245;
        V t_3 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_seen_241;
      V t_2 = v_vs_245;
      V t_3 = v_acc_243;
      v_bs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2efreeGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efreeGo(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2efreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efreeOf_entry, 2, 0};

V g_heff_2eemitc_2efreeOf(V v_xs_240, V v_b_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){v_b_241, NTAG(TAG_Nil)});
  V v_x2_243 = (g_heff_2eemitc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_bs_244 = heff_field(v_x2_243, 0);
    V v_ms_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_bs_246 = (g_prelude_2e_2b_2b(v_xs_240, v_bs_244));
    V v_ms_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_245));
    V v_t_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_246; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_246); r_; });
    return ({ V a_0 = v_t_248; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_247; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2eemitc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2eemitc_2efreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2efreeOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evarUse_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evarUse_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 100, 117, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evarUse_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evarUse_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 100, 117, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evarUse_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2evarUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evarUse_entry, 3, 0};

V g_heff_2eemitc_2evarUse(V v_lent_240, V v_live_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_live_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evarUse_str1))));
    return heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eemitc_2evarUse_str3)));
  }
  case TAG_False: {
    V v_t_245 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_lent_240));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str4), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evarUse_str5))));
      return heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str6), heff_strAppend(v_t_246, ((V)&g_heff_2eemitc_2evarUse_str7)));
    }
    case TAG_False: {
      return heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str8), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evarUse_str9))));
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2evarUse_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2evarUse(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edropAs_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2edropAs_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 116, 97, 103, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edropAs_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemitc_2edropAs_str7 = {{0x80000000u, K_STR, 0}, 15, 15, {104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 99, 101, 108, 108, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemitc_2edropAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edropAs_entry, 2, 0};

V g_heff_2eemitc_2edropAs(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_KnownTag: {
    V v_n_242 = heff_field(v_x2_241, 0);
    if (heff_intEq_c(heff_dup(v_n_242), MK_INT(0LL))) {
      heff_drop(v_x_240);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str0), (g_heff_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edropAs_str1))));
      V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str2), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str3), heff_strAppend(heff_intShow(heff_dup(v_n_242)), ((V)&g_heff_2eemitc_2edropAs_str4)))));
      return heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    }
  }
  case TAG_KnownCell: {
    V v_n_246 = heff_field(v_x2_241, 0);
    V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str5), (g_heff_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edropAs_str6))));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str7), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str8), heff_strAppend(heff_intShow(heff_dup(v_n_246)), ((V)&g_heff_2eemitc_2edropAs_str9)))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2edropAs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2edropAs(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropsIn_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edropsIn_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2edropsIn_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropsIn_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
V g_heff_2eemitc_2edropsIn_lam0(V self, V *args);
Clo g_heff_2eemitc_2edropsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edropsIn_entry, 2, 0};

V g_heff_2eemitc_2edropsIn(V v_ce_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2edropsIn_lam0, 2, 1, (V[]){v_ce_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eemitc_2edropsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edropsIn(a[0], a[1]);
}
V g_heff_2eemitc_2edropsIn_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get(v_ce_240, LBL_known); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2edropsIn_str0), (g_heff_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edropsIn_str1))));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2edropsIn_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eemitc_2edropsIn_str3)));
    v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_k_248 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_243));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2efixedLit_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {77, 75, 95, 73, 78, 84, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2efixedLit_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {76, 76, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2efixedLit_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {72, 69, 70, 70, 95, 66, 73, 71, 40, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efixedLit_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2efixedLit_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {72, 69, 70, 70, 95, 66, 73, 71, 40, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efixedLit_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2efixedLit_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {77, 75, 95, 73, 78, 84, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2efixedLit_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {76, 76, 41}};
Clo g_heff_2eemitc_2efixedLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efixedLit_entry, 2, 0};

V g_heff_2eemitc_2efixedLit(V v_w_240, V v_n_241) {
top: ;
  V v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if (heff_intEq_c(v_t_242, MK_INT(64LL))) {
    if (heff_intLt_c(heff_dup(v_n_241), HEFF_BIG("4611686018427387904"))) {
      if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_241))) {
        return heff_strAppend(((V)&g_heff_2eemitc_2efixedLit_str0), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2eemitc_2efixedLit_str1)));
      } else {
        return heff_strAppend(((V)&g_heff_2eemitc_2efixedLit_str2), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2eemitc_2efixedLit_str3)));
      }
    } else {
      return heff_strAppend(((V)&g_heff_2eemitc_2efixedLit_str4), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2eemitc_2efixedLit_str5)));
    }
  } else {
    return heff_strAppend(((V)&g_heff_2eemitc_2efixedLit_str6), heff_strAppend(heff_intShow(v_n_241), ((V)&g_heff_2eemitc_2efixedLit_str7)));
  }
}
V g_heff_2eemitc_2efixedLit_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efixedLit(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eelemI(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentVar_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentVar_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentVar_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentVar_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentVar_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentVar_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2elentVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentVar_entry, 3, 0};

V g_heff_2eemitc_2elentVar(V v_ce_240, V v_live_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_live_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_ce_240);
    V v_v_244 = heff_strAppend(((V)&g_heff_2eemitc_2elentVar_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elentVar_str1))));
    return heff_rec(3, shape_arg__pre__post, (V[]){v_v_244, NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_False: {
    V v_t_245 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_ce_240), LBL_borrowed); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_ce_240);
      V v_v_246 = heff_strAppend(((V)&g_heff_2eemitc_2elentVar_str2), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elentVar_str3))));
      return heff_rec(3, shape_arg__pre__post, (V[]){v_v_246, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_False: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2elentVar_str4), (g_heff_2eemitc_2emangleW(heff_dup(v_x_242), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elentVar_str5))));
      V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2eemitc_2edropsIn(v_ce_240, v_t_248));
      return heff_rec(3, shape_arg__pre__post, (V[]){v_t_247, NTAG(TAG_Nil), v_t_249});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2elentVar_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentVar(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2ecallText_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 95, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2ecallText_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 95, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ecallText_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {40, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2ecallText_str19 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 86, 32, 114, 95, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ecallText_str21 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 41, 59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2ecallText_str22 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 114, 95, 59, 32, 125, 41}};
Clo g_heff_2eemitc_2ecallText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ecallText_entry, 3, 0};

V g_heff_2eemitc_2ecallText(V v_g_240, V v_tr_241, V v_ls_242) {
top: ;
  V v_t_243 = (g_list_2eall_24s1175244903x419753027(v_ls_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244;
    switch (heff_tag_of(v_tr_241)) {
    case TAG_True: {
      v_t_244 = ((V)&g_heff_2eemitc_2ecallText_str0);
      break;
    }
    case TAG_False: {
      v_t_244 = ((V)&g_heff_2eemitc_2ecallText_str1);
      break;
    }
    default: heff_nomatch(v_tr_241);
    }
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str2), (g_heff_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ecallText_str3))));
    V v_x2_246 = (g_list_2emap_24s1363203549x1204645634(v_ls_242));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eemitc_2ecallText_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2eemitc_2ecallText_str5); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(v_t_244, heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str6), heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2ecallText_str7)))));
  }
  case TAG_False: {
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ls_242));
    V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_ordered_2412 = (g_list_2ezipWith_24s259431397x671561817(v_ls_242, v_t_2411));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ordered_2412)));
    V v_x2_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s638445529x932797857(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2eemitc_2ecallText_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2eemitc_2ecallText_str9); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2418;
    switch (heff_tag_of(v_tr_241)) {
    case TAG_True: {
      v_t_2418 = ((V)&g_heff_2eemitc_2ecallText_str10);
      break;
    }
    case TAG_False: {
      v_t_2418 = ((V)&g_heff_2eemitc_2ecallText_str11);
      break;
    }
    default: heff_nomatch(v_tr_241);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str12), (g_heff_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ecallText_str13))));
    V v_x2_2420 = (g_list_2emap_24s1363203549x1204645634(heff_dup(v_ordered_2412)));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2eemitc_2ecallText_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2eemitc_2ecallText_str15); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ordered_2412));
    V v_x2_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s1958541883x442288263(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2eemitc_2ecallText_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2eemitc_2ecallText_str17); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    return heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str18), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str19), heff_strAppend(v_t_2418, heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str20), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str21), heff_strAppend(v_t_2428, ((V)&g_heff_2eemitc_2ecallText_str22))))))))));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2ecallText_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ecallText(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamLines_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2elamLines_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elamLines_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamLines_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2elamLines_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 61, 32, 97, 114, 103, 115, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elamLines_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamLines_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2elamLines_str10 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 61, 32, 104, 101, 102, 102, 95, 101, 110, 118, 40, 115, 101, 108, 102, 41, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2elamLines_str12 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 32, 104, 101, 102, 102, 95, 99, 108, 111, 95, 116, 97, 107, 101, 40, 115, 101, 108, 102, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2elamLines_str14 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamLines_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamLines_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
Clo g_heff_2eemitc_2elamLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elamLines_entry, 5, 0};

V g_heff_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_dead_243, V v_body_244) {
top: ;
  V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2elamLines_str0), heff_strAppend(v_k_240, ((V)&g_heff_2eemitc_2elamLines_str1)));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
  V v_t_249 = (g_list_2ezipWith_24s1947952772x1156675739(((V)&g_heff_2eemitc_2elamLines_str2), ((V)&g_heff_2eemitc_2elamLines_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elamLines_str4), ((V)&g_heff_2eemitc_2elamLines_str5), ((V)&g_heff_2eemitc_2elamLines_str6), v_xs_241, v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fv_242));
  V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
  V v_t_2412 = (g_list_2ezipWith_24s1947952772x1156675739(((V)&g_heff_2eemitc_2elamLines_str7), ((V)&g_heff_2eemitc_2elamLines_str8), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elamLines_str9), ((V)&g_heff_2eemitc_2elamLines_str10), ((V)&g_heff_2eemitc_2elamLines_str11), heff_dup(v_fv_242), v_t_2411));
  V v_t_2417;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2elamLines_str12), heff_strAppend(heff_intShow(v_t_2415), ((V)&g_heff_2eemitc_2elamLines_str13)));
    v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2418 = (g_list_2emap_24s455042168x142217368(((V)&g_heff_2eemitc_2elamLines_str14), ((V)&g_heff_2eemitc_2elamLines_str15), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elamLines_str16), ((V)&g_heff_2eemitc_2elamLines_str17), v_dead_243));
  V v_t_2419 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2elamLines_str18), v_t_2418));
  V v_t_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2elamLines_str19), v_body_244));
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2elamLines_str20), NTAG(TAG_Nil)});
  V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2421));
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2422));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2423));
  V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2424));
  V v_t_2426 = (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2426));
}
V g_heff_2eemitc_2elamLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elamLines(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2ereusePrim_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 114, 101, 117, 115, 101}};

static V g_heff_2eemitc_2ereusePrim_val;
static int g_heff_2eemitc_2ereusePrim_st;
static V g_heff_2eemitc_2ereusePrim_init(void) {
  return ((V)&g_heff_2eemitc_2ereusePrim_str0);
}
V g_heff_2eemitc_2ereusePrim_get(void) {
  if (g_heff_2eemitc_2ereusePrim_st == 2) return g_heff_2eemitc_2ereusePrim_val;
  if (g_heff_2eemitc_2ereusePrim_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2ereusePrim_st = 1;
  g_heff_2eemitc_2ereusePrim_val = heff_tr(g_heff_2eemitc_2ereusePrim_init());
  g_heff_2eemitc_2ereusePrim_st = 2;
  return g_heff_2eemitc_2ereusePrim_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eagain_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eagain_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eagain_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eagain_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eagain_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eagain_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 61, 32, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eagain_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eagain_str7 = {{0x80000000u, K_STR, 0}, 9, 9, {103, 111, 116, 111, 32, 116, 111, 112, 59}};
Clo g_heff_2eemitc_2eagain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eagain_entry, 2, 0};

V g_heff_2eemitc_2eagain(V v_ce_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_get(v_ce_240, LBL_self);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_vs_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_241));
    V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
    V v_t_246 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2eemitc_2eagain_str0), ((V)&g_heff_2eemitc_2eagain_str1), ((V)&g_heff_2eemitc_2eagain_str2), heff_dup(v_vs_241), v_t_245));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_241); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    V v_t_249 = (g_list_2ezipWith_24s2075573643x1334977728(((V)&g_heff_2eemitc_2eagain_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eagain_str4), ((V)&g_heff_2eemitc_2eagain_str5), ((V)&g_heff_2eemitc_2eagain_str6), heff_get(v_s_243, LBL_params), v_t_248));
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eagain_str7), NTAG(TAG_Nil)});
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_246, v_t_2411);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2eagain_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eagain(a[0], a[1]);
}
Clo g_heff_2eemitc_2eagrees_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eagrees_entry, 3, 0};

V g_heff_2eemitc_2eagrees(V v_ce_240, V v_g_241, V v_as_242) {
top: ;
  V v_m_243 = ({ V a_0 = v_g_241; V b_1 = heff_get(heff_dup(v_ce_240), LBL_funs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_n_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
  V v_t_245 = heff_get(v_ce_240, LBL_self);
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_m_243);
    heff_drop(v_n_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get(v_s_246, LBL_params); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_t_247, heff_dup(v_n_244))) {
      switch (heff_tag_of(v_m_243)) {
      case TAG_Nothing: {
        heff_drop(v_n_244);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_m_249 = heff_field(v_m_243, 0);
        heff_take_n(v_m_243, 1ULL, 1);
        return heff_intEq(v_n_244, v_m_249);
      }
      default: return heff_nomatch(v_m_243);
      }
    } else {
      heff_drop(v_m_243);
      heff_drop(v_n_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2eagrees_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eagrees(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2einPlace_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2einPlace_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {86, 32, 102, 95, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2einPlace_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2einPlace_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 114, 103, 115, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2einPlace_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {93, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2einPlace_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2einPlace_str6 = {{0x80000000u, K_STR, 0}, 19, 19, {105, 102, 32, 40, 104, 101, 102, 102, 95, 101, 120, 97, 99, 116, 40, 102, 95, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2eemitc_2einPlace_str7 = {{0x80000000u, K_STR, 0}, 52, 52, {44, 32, 97, 114, 103, 115, 41, 41, 32, 72, 69, 70, 70, 95, 76, 65, 83, 84, 32, 114, 101, 116, 117, 114, 110, 32, 40, 40, 67, 108, 111, 32, 42, 41, 102, 95, 41, 45, 62, 102, 110, 40, 102, 95, 44, 32, 97, 114, 103, 115, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2einPlace_str8 = {{0x80000000u, K_STR, 0}, 21, 21, {114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 116, 97, 105, 108, 40, 102, 95, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2einPlace_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 97, 114, 103, 115, 41, 59}};
Clo g_heff_2eemitc_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2einPlace_entry, 1, 0};

V g_heff_2eemitc_2einPlace(V v_vs_240) {
top: ;
  V v_x2_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_x2_243 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_vs_240, 0));
    v_x2_243 = heff_tag(TAG_Just, 1, (V[]){v_x_241});
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2eemitc_2einPlace_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2einPlace_str1), heff_strAppend(v_t_245, ((V)&g_heff_2eemitc_2einPlace_str2)));
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2edrop(MK_INT(1LL), heff_dup(v_vs_240)));
  V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(2LL))));
  V v_t_2411 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2eemitc_2einPlace_str3), ((V)&g_heff_2eemitc_2einPlace_str4), ((V)&g_heff_2eemitc_2einPlace_str5), v_t_248, v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2413 = heff_intShow(heff_intSub(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2eemitc_2einPlace_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2eemitc_2einPlace_str7)));
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
  V v_t_2416 = heff_intShow(heff_intSub(v_t_2415, MK_INT(1LL)));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2eemitc_2einPlace_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2eemitc_2einPlace_str9)));
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2411, heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_t_2418})));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2419));
}
V g_heff_2eemitc_2einPlace_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2einPlace(a[0]);
}
Clo g_heff_2eemitc_2etakenFv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etakenFv_entry, 4, 0};

V g_heff_2eemitc_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_x1_247 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      heff_drop(v_ce_240);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
      if (heff_intLe_c(v_t_248, MK_INT(60LL))) {
        V v_x1_2410 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_244), v_fb_243));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          heff_drop(v_ce_240);
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          V v_x1_2411 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get(v_ce_240, LBL_after); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_x1_2411)) {
          case TAG_True: {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_False: {
            return heff_tag_at(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_244});
          }
          default: return heff_nomatch(v_x1_2411);
          }
        }
        default: return heff_nomatch(v_x1_2410);
        }
      } else {
        heff_drop(v_ce_240);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2etakenFv_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2etakenFv(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efieldLine_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2efieldLine_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efieldLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2efieldLine_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2efieldLine_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2efieldLine_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efieldLine_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemitc_2efieldLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efieldLine_entry, 4, 0};

V g_heff_2eemitc_2efieldLine(V v_sv_240, V v_plain_241, V v_used_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_i_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2eemitc_2eelemS(heff_dup(v_v_244), v_used_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str0), (g_heff_2eemitc_2emangleW(v_v_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efieldLine_str1))));
      V v_t_248;
      switch (heff_tag_of(v_plain_241)) {
      case TAG_True: {
        v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str2), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str3), heff_strAppend(heff_intShow(v_i_245), ((V)&g_heff_2eemitc_2efieldLine_str4)))));
        break;
      }
      case TAG_False: {
        v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str5), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str6), heff_strAppend(heff_intShow(v_i_245), ((V)&g_heff_2eemitc_2efieldLine_str7)))));
        break;
      }
      default: heff_nomatch(v_plain_241);
      }
      V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str8), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str9), heff_strAppend(v_t_248, ((V)&g_heff_2eemitc_2efieldLine_str10)))));
      return heff_tag_at(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      heff_drop(v_sv_240);
      heff_drop(v_v_244);
      heff_drop(v_i_245);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eemitc_2efieldLine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efieldLine(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eemitc_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epow2_entry, 1, 0};

V g_heff_2eemitc_2epow2(V v_n_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2eemitc_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2eemitc_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epow2(a[0]);
}
Clo g_heff_2eemitc_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efieldMask_entry, 3, 0};

V g_heff_2eemitc_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eemitc_2eelemS(heff_dup(v_v_243), v_used_240));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_246 = (g_heff_2eemitc_2epow2(heff_dup(v_i_241)));
      break;
    }
    case TAG_False: {
      v_t_246 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = (g_heff_2eemitc_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2efieldMask_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efieldMask(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2eemitc_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseArgs_entry, 2, 0};

V g_heff_2eemitc_2ereuseArgs(V v_go_240, V v_es_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return (g_list_2efoldl(heff_clo(g_heff_2eemitc_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}), v_t_242, v_es_241));
}
V g_heff_2eemitc_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ereuseArgs(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_e_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_go_240);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), (g_prelude_2e_2b_2b(v_t_2410, v_t_2411))});
  }
  case TAG_False: {
    V v_done_2414;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_done_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_x2_2415 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_244}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_b_2416 = heff_field(v_x2_2415, 0);
      V v_e_2417 = heff_field(v_x2_2415, 1);
      V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
      V v_t_2418 = heff_tag_at(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_e_2417, NTAG(TAG_Nil)});
      return heff_tag(TAG_MkPair, 2, (V[]){v_b_2416, (g_prelude_2e_2b_2b(v_done_2414, v_t_2418))});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
Clo g_heff_2eemitc_2eletReuse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eletReuse_entry, 5, 0};

V g_heff_2eemitc_2eletReuse(V v_go_240, V v_x_241, V v_a_242, V v_b_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_a2_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_True: {
      heff_drop(v_go_240);
      heff_drop(v_a_242);
      return heff_tag_at(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a2_246, v_b_243})});
    }
    case TAG_False: {
      heff_drop(v_a2_246);
      V v_x1_247 = heff_tr(heff_apply(v_go_240, 1, (V[]){heff_dup(v_b_243)}));
      V v_x2_2411;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_MkPair: {
        V v_b_248 = heff_field(v_x1_247, 0);
        V v_e_249 = heff_field(v_x1_247, 1);
        V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
        V v_t_2410 = heff_tag_at(v_ru_24x5_244_24MkPair, TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
        v_x2_2411 = heff_tag_at(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_b_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_b_2412 = heff_field(v_x2_2411, 0);
        V v_es_2413 = heff_field(v_x2_2411, 1);
        V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
        V v_x2_2416;
        switch (heff_tag_of(v_es_2413)) {
        case TAG_Nil: {
          v_x2_2416 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_es_2413, 0);
          heff_take_n(v_es_2413, 1ULL, 2);
          v_x2_2416 = heff_tag(TAG_Just, 1, (V[]){v_x_2414});
          break;
        }
        default: heff_nomatch(v_es_2413);
        }
        V v_t_2418;
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_Nothing: {
          v_t_2418 = v_b_243;
          break;
        }
        case TAG_Just: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          heff_take_n(v_x2_2416, 1ULL, 1);
          heff_drop(v_b_243);
          v_t_2418 = v_x_2417;
          break;
        }
        default: heff_nomatch(v_x2_2416);
        }
        return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_b_2412, heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_t_2418})});
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eemitc_2eletReuse_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eletReuse(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eemitc_2ereuseIn_lam0(V self, V *args);
Clo g_heff_2eemitc_2ereuseIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseIn_entry, 3, 0};

V g_heff_2eemitc_2ereuseIn(V v_ru_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EGlobal: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ELam: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EApp: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuseIn_clo), 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}));
    V v_t_2413 = (g_heff_2eemitc_2ereuseIn(v_ru_240, v_n_241, heff_dup(v_a_2410)));
    return (g_heff_2eemitc_2eletReuse(v_t_2412, v_x_249, v_a_2410, v_b_2411, v_t_2413));
  }
  case TAG_ERecord: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EProj: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_242, 0);
    V v_as_2418 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2419 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2418));
    if (heff_intEq_c(v_t_2419, heff_dup(v_n_241))) {
      heff_drop(v_n_241);
      V v_t_2421 = heff_tag_at(v_ru_24e_242_24ETag, TAG_Cons, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2417, v_as_2418}), NTAG(TAG_Nil)});
      V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_ru_240}), v_t_2421});
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2eemitc_2ereusePrim_get()), v_t_2422})});
    } else {
      V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuseIn_clo), 2, (V[]){v_ru_240, v_n_241}));
      V v_x2_2424 = ({ V a_0 = v_t_2423; V a_1 = v_as_2418; V r_ = (g_heff_2eemitc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2418); r_; });
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_MkPair: {
        V v_b_2425 = heff_field(v_x2_2424, 0);
        V v_es_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        return heff_tag_at(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){v_b_2425, heff_tag(TAG_ETag, 2, (V[]){v_t_2417, v_es_2426})});
      }
      default: return heff_nomatch(v_x2_2424);
      }
    }
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_e_242, 0);
    V v_arms_2428 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_ps_2440 = (g_list_2emap(heff_clo(g_heff_2eemitc_2ereuseIn_lam0, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_2428));
    V v_t_2441 = (g_list_2eany_24s910662703x1730636603(v_ps_2440));
    V v_t_2442 = heff_tag_at(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2427, (g_list_2emap_24s1173914895x100384474(v_ps_2440))});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2441, v_t_2442});
  }
  case TAG_EPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EPrimCall: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ECall: {
    V v_g_2446 = heff_field(v_e_242, 0);
    V v_as_2447 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2448 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuseIn_clo), 2, (V[]){v_ru_240, v_n_241}));
    V v_x2_2449 = ({ V a_0 = v_t_2448; V a_1 = v_as_2447; V r_ = (g_heff_2eemitc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2447); r_; });
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_b_2450 = heff_field(v_x2_2449, 0);
      V v_es_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){v_b_2450, heff_tag(TAG_ECall, 2, (V[]){v_g_2446, v_es_2451})});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  case TAG_EInt: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2ereuseIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ereuseIn(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ereuseIn_lam0(V self, V *args) {
  V v_a_2429 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433;
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_b_2432 = heff_dup(heff_field(v_a_2429, 2));
    v_t_2433 = v_b_2432;
    break;
  }
  default: heff_nomatch(v_a_2429);
  }
  V v_x2_2434 = (g_heff_2eemitc_2ereuseIn(v_ru_240, v_n_241, v_t_2433));
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_field(v_a_2429, 0);
    V v_vs_2436 = heff_field(v_a_2429, 1);
    V v_ru_24a_2429_24MkArm = heff_take_reuse_n(v_a_2429, 3ULL, 3);
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_r_2438 = heff_field(v_x2_2434, 0);
      V v_b_2439 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_r_2438, heff_tag_at(v_ru_24a_2429_24MkArm, TAG_MkArm, 3, (V[]){v_t_2435, v_vs_2436, v_b_2439})});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  default: return heff_nomatch(v_a_2429);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ereusing_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereusing_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ereusing_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereusing_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2eemitc_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereusing_entry, 4, 0};

V g_heff_2eemitc_2ereusing(V v_x1_240, V v_t_241, V v_vs_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str0), heff_strAppend(heff_dup(v_x_244), heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str1), heff_dup(v_t_241))));
    V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_it_247 = (g_heff_2eemitc_2ereuseIn(v_t_245, v_t_246, heff_dup(v_b_243)));
    switch (heff_tag_of(v_it_247)) {
    case TAG_MkPair: {
      V v_it1_248 = heff_field(v_it_247, 0);
      V v_b2_249 = heff_field(v_it_247, 1);
      V v_ru_24it_247_24MkPair = heff_take_reuse_n(v_it_247, 3ULL, 2);
      switch (heff_tag_of(v_it1_248)) {
      case TAG_True: {
        heff_drop(v_b_243);
        V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str2), heff_strAppend(v_x_244, heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str3), v_t_241)));
        return heff_tag_at(v_ru_24it_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_t_2410}), v_b2_249});
      }
      case TAG_False: {
        heff_drop(v_t_241);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        heff_drop(v_b2_249);
        return heff_tag_at(v_ru_24it_247_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
      }
      default: return heff_nomatch(v_it1_248);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ereusing_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ereusing(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2etakeKept_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2etakeKept_str3 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 114, 101, 117, 115, 101, 95, 110, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2etakeKept_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 76, 76, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemitc_2etakeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etakeKept_entry, 4, 0};

V g_heff_2eemitc_2etakeKept(V v_sv_240, V v_x2_241, V v_vs_242, V v_used_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_sv_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_ru_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str0), (g_heff_2eemitc_2emangleW(heff_dup(v_ru_244), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2etakeKept_str1))));
    V v_t_246 = (g_heff_2eemitc_2efieldMask(v_used_243, MK_INT(0LL), v_vs_242));
    V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str2), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str3), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str4), heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str5), heff_strAppend(heff_intShow(v_t_247), ((V)&g_heff_2eemitc_2etakeKept_str6)))))))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2etakeKept_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2etakeKept(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
Clo g_heff_2eemitc_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eknowing_entry, 3, 0};

V g_heff_2eemitc_2eknowing(V v_x1_240, V v_n_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_x_243, heff_tag_at(v_ru_24x1_240_24Just, TAG_KnownTag, 1, (V[]){v_n_241}), heff_get(heff_dup(v_ce_242), LBL_known)));
    return heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), heff_get(heff_dup(v_ce_242), LBL_owned), heff_get(heff_dup(v_ce_242), LBL_after), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(v_ce_242, LBL_bor), v_t_244});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2eknowCell_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eknowCell_entry, 3, 0};

V g_heff_2eemitc_2eknowCell(V v_x1_240, V v_n_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_ru_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_ru_243, heff_tag_at(v_ru_24x1_240_24Just, TAG_KnownCell, 1, (V[]){v_n_241}), heff_get(heff_dup(v_ce_242), LBL_known)));
    return heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), heff_get(heff_dup(v_ce_242), LBL_owned), heff_get(heff_dup(v_ce_242), LBL_after), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(v_ce_242, LBL_bor), v_t_244});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eknowCell_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eknowCell(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2eheldVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eheldVar_entry, 2, 0};

V g_heff_2eemitc_2eheldVar(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(v_ce_240, LBL_owned); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_241_24EVar, TAG_Just, 1, (V[]){v_x_242});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24EVar, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eheldVar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eheldVar(a[0], a[1]);
}
Clo g_heff_2eemitc_2ereusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereusedOf_entry, 1, 0};

V g_heff_2eemitc_2ereusedOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_EVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EGlobal: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        V v_as_2418 = heff_field(v_x121_243, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_Nil: {
          V v_t_2419 = heff_tag(TAG_KnownTag, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2418))});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2419});
        }
        case TAG_Cons: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_EMatch: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ereusedOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ereusedOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ebuiltOf_entry, 1, 0};

V g_heff_2eemitc_2ebuiltOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    V v_as_2414 = heff_field(v_x1_240, 1);
    V v_t_2415 = heff_tag(TAG_KnownTag, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2414))});
    return heff_tag(TAG_Just, 1, (V[]){v_t_2415});
  }
  case TAG_EMatch: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2419 = heff_field(v_x1_240, 0);
    V v_as_2420 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(v_p_2419), heff_dup(g_heff_2eemitc_2ereusePrim_get()))) {
      HEFF_LAST return g_heff_2eemitc_2ereusedOf(v_as_2420);
    } else {
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ebuiltOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2eknownLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eknownLet_entry, 3, 0};

V g_heff_2eemitc_2eknownLet(V v_x_240, V v_x2_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_x_240, heff_dup(v_k_243), heff_get(heff_dup(v_ce_242), LBL_known)));
    return heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), heff_get(heff_dup(v_ce_242), LBL_owned), heff_get(heff_dup(v_ce_242), LBL_after), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(v_ce_242, LBL_bor), v_t_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eknownLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eknownLet(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2econdPrims_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 117, 110, 101, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2econdPrims_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 117, 110, 101, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2econdPrims_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 117, 110, 101, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdPrims_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdPrims_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2econdPrims_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2econdPrims_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdPrims_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2econdPrims_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdPrims_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdPrims_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};

static V g_heff_2eemitc_2econdPrims_val;
static int g_heff_2eemitc_2econdPrims_st;
static V g_heff_2eemitc_2econdPrims_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str8), v_t_243})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdPrims_str10), v_t_244})});
}
V g_heff_2eemitc_2econdPrims_get(void) {
  if (g_heff_2eemitc_2econdPrims_st == 2) return g_heff_2eemitc_2econdPrims_val;
  if (g_heff_2eemitc_2econdPrims_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2econdPrims_st = 1;
  g_heff_2eemitc_2econdPrims_val = heff_tr(g_heff_2eemitc_2econdPrims_init());
  g_heff_2eemitc_2econdPrims_st = 2;
  return g_heff_2eemitc_2econdPrims_val;
}
Clo g_heff_2eemitc_2erelFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2erelFixed_entry, 1, 0};

V g_heff_2eemitc_2erelFixed(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_get(heff_dup(v_p_241), LBL_op);
    switch (heff_tag_of(v_t_242)) {
    case TAG_OpAdd: {
      return NTAG(TAG_False);
    }
    case TAG_OpSub: {
      return NTAG(TAG_False);
    }
    case TAG_OpMul: {
      return NTAG(TAG_False);
    }
    case TAG_OpDiv: {
      return NTAG(TAG_False);
    }
    case TAG_OpRem: {
      return NTAG(TAG_False);
    }
    case TAG_OpEq: {
      return NTAG(TAG_True);
    }
    case TAG_OpLt: {
      return NTAG(TAG_True);
    }
    case TAG_OpLe: {
      return NTAG(TAG_True);
    }
    case TAG_OpAnd: {
      return NTAG(TAG_False);
    }
    case TAG_OpOr: {
      return NTAG(TAG_False);
    }
    case TAG_OpXor: {
      return NTAG(TAG_False);
    }
    case TAG_OpShl: {
      return NTAG(TAG_False);
    }
    case TAG_OpShr: {
      return NTAG(TAG_False);
    }
    case TAG_OpShow: {
      return NTAG(TAG_False);
    }
    case TAG_OpFromInt: {
      return NTAG(TAG_False);
    }
    case TAG_OpToInt: {
      return NTAG(TAG_False);
    }
    case TAG_OpSqrt: {
      return NTAG(TAG_False);
    }
    case TAG_OpFromFloat: {
      return NTAG(TAG_False);
    }
    case TAG_OpToFloat: {
      return NTAG(TAG_False);
    }
    case TAG_OpFloor: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2erelFixed_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2erelFixed(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2econdOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2econdOn_entry, 5, 0};

V g_heff_2eemitc_2econdOn(V v_x_240, V v_p_241, V v_as_242, V v_s_243, V v_arms_244) {
top: ;
  V v_t_245 = ({ V a_0 = heff_dup(v_p_241); V b_1 = heff_dup(g_heff_2eemitc_2econdPrims_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_t_246 = (g_heff_2efixed_2efixedPrimOf(heff_dup(v_p_241)));
    v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eemitc_2erelFixed(a_0)); heff_drop(v_t_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_2437;
    switch (heff_tag_of(v_s_243)) {
    case TAG_EVar: {
      V v_y_248 = heff_field(v_s_243, 0);
      v_t_2437 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_248));
      break;
    }
    case TAG_EGlobal: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_243);
    }
    switch (heff_tag_of(v_t_2437)) {
    case TAG_True: {
      V v_t_2438 = (g_list_2eall_24s1225041428x2030583288(v_arms_244));
      switch (heff_tag_of(v_t_2438)) {
      case TAG_True: {
        V v_es_2439 = (g_list_2emap_24s2006210321x387008715(heff_dup(v_arms_244)));
        V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2439));
        V v_t_2441 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2440; V r_ = (g_list_2efoldl_24s1187012699x1099443358(a_0, a_1)); heff_drop(v_t_2440); r_; });
        V v_x1_2442 = ({ V a_0 = v_x_240; V a_1 = v_t_2441; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2441); r_; });
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_True: {
          heff_drop(v_p_241);
          heff_drop(v_as_242);
          heff_drop(v_arms_244);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          return heff_tag(TAG_Just, 1, (V[]){heff_rec(3, shape_prim__args__arms, (V[]){v_p_241, v_as_242, v_arms_244})});
        }
        default: return heff_nomatch(v_x1_2442);
        }
      }
      case TAG_False: {
        heff_drop(v_x_240);
        heff_drop(v_p_241);
        heff_drop(v_as_242);
        heff_drop(v_arms_244);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2438);
      }
    }
    case TAG_False: {
      heff_drop(v_x_240);
      heff_drop(v_p_241);
      heff_drop(v_as_242);
      heff_drop(v_arms_244);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
  case TAG_False: {
    heff_drop(v_x_240);
    heff_drop(v_p_241);
    heff_drop(v_as_242);
    heff_drop(v_arms_244);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eemitc_2econdOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2econdOn(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
Clo g_heff_2eemitc_2econdLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2econdLet_entry, 3, 0};

V g_heff_2eemitc_2econdLet(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2420 = heff_field(v_a_241, 0);
    V v_as_2421 = heff_field(v_a_241, 1);
    switch (heff_tag_of(v_b_242)) {
    case TAG_EVar: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      V v_s_2436 = heff_field(v_b_242, 0);
      V v_arms_2437 = heff_field(v_b_242, 1);
      return (g_heff_2eemitc_2econdOn(v_x_240, heff_dup(v_p_2420), heff_dup(v_as_2421), v_s_2436, heff_dup(v_arms_2437)));
    }
    case TAG_EPrim: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_b_242);
    }
  }
  case TAG_ECall: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2eemitc_2econdLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2econdLet(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eemitc_2eisCondCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eisCondCall_entry, 1, 0};

V g_heff_2eemitc_2eisCondCall(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2418 = heff_field(v_x1_240, 0);
    V v_t_2420 = ({ V a_0 = heff_dup(v_p_2418); V b_1 = heff_dup(g_heff_2eemitc_2econdPrims_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2421 = (g_heff_2efixed_2efixedPrimOf(heff_dup(v_p_2418)));
      return ({ V a_0 = v_t_2421; V r_ = (g_heff_2eemitc_2erelFixed(a_0)); heff_drop(v_t_2421); r_; });
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eisCondCall_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eisCondCall(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2eisMatchOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eisMatchOn_entry, 2, 0};

V g_heff_2eemitc_2eisMatchOn(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2416 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_s_2416)) {
    case TAG_EVar: {
      V v_y_2418 = heff_field(v_s_2416, 0);
      return heff_strEq(v_x_240, heff_dup(v_y_2418));
    }
    case TAG_EGlobal: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_2416);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eisMatchOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eisMatchOn(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eemitc_2esunkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2esunkGo_entry, 3, 0};

V g_heff_2eemitc_2esunkGo(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_b_242, 0);
    V v_m_2410 = heff_field(v_b_242, 1);
    V v_e_2411 = heff_field(v_b_242, 2);
    V v_ru_24b_242_24ELet = heff_take_reuse_n(v_b_242, 7ULL, 3);
    V v_t_2412 = (g_heff_2eemitc_2eisMatchOn(heff_dup(v_x_240), v_m_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      V v_t_2413 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_e_2411)));
      V v_x1_2414 = ({ V a_0 = heff_dup(v_x_240); V a_1 = v_t_2413; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2413); r_; });
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_True: {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_y_249);
        heff_drop(v_m_2410);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_t_2415 = heff_tag_at(v_ru_24b_242_24ELet, TAG_ELet, 3, (V[]){v_y_249, heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_m_2410}), v_e_2411});
        return heff_tag(TAG_Just, 1, (V[]){v_t_2415});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_False: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_y_249);
      heff_drop(v_m_2410);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2eemitc_2esunkGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2esunkGo(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2earmFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2earmFor_entry, 2, 0};

V g_heff_2eemitc_2earmFor(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_u_244 = heff_field(v_x21_242, 0);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c(heff_dup(v_t_240), heff_dup(v_u_244))) {
        heff_drop(v_t_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_b_246)});
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2earmFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2earmFor(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2eparamsAt_lam0(V self, V *args);
Clo g_heff_2eemitc_2eparamsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eparamsAt_entry, 3, 0};

V g_heff_2eemitc_2eparamsAt(V v_want_240, V v_bi_241, V v_xs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_245 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_242, v_t_244));
  V v_t_2414 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eparamsAt_lam0, 1, 2, (V[]){heff_dup(v_want_240), heff_dup(v_bi_241)}), v_t_245));
  return (g_list_2emap_24s1937570095x2110149801(v_t_2414));
}
V g_heff_2eemitc_2eparamsAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eparamsAt(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2eparamsAt_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_want_240 = heff_env(self)[0];
  V v_bi_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_want_240)) {
  case TAG_True: {
    V v_t_249;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_p_246, 1);
      heff_take_n(v_p_246, 2ULL, 2);
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    return ({ V a_0 = v_t_249; V a_1 = v_bi_241; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  }
  case TAG_False: {
    V v_t_2412;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_p_246, 1);
      heff_take_n(v_p_246, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    V v_x1_2413 = ({ V a_0 = v_t_2412; V a_1 = v_bi_241; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  default: return heff_nomatch(v_want_240);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eentryCall_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2eentryCall_str15 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eentryCall_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2eentryCall_str19 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 86, 32, 114, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eentryCall_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2eentryCall_str22 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 101, 116, 117, 114, 110, 32, 114, 59}};
Clo g_heff_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_bi_241);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str0), (g_heff_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eentryCall_str1))));
    V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_248 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2eemitc_2eentryCall_str2), ((V)&g_heff_2eemitc_2eentryCall_str3), v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2eemitc_2eentryCall_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2eemitc_2eentryCall_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str6), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str7), heff_strAppend(v_t_2411, ((V)&g_heff_2eemitc_2eentryCall_str8)))));
  }
  case TAG_False: {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str9), (g_heff_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eentryCall_str10))));
    V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2414 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2eemitc_2eentryCall_str11), ((V)&g_heff_2eemitc_2eentryCall_str12), v_t_2413));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2eemitc_2eentryCall_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2eemitc_2eentryCall_str14); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_x2_2418 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2eemitc_2eentryCall_str15), ((V)&g_heff_2eemitc_2eentryCall_str16), v_bi_241));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2eemitc_2eentryCall_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2eemitc_2eentryCall_str18); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    return heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str19), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str20), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str21), heff_strAppend(v_t_2421, ((V)&g_heff_2eemitc_2eentryCall_str22)))))));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2elamBody_24s1136853347x1274611651_lam0(V self, V *args);
Clo g_heff_2eemitc_2elamBody_24s1136853347x1274611651_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elamBody_24s1136853347x1274611651_entry, 4, 0};

V g_heff_2eemitc_2elamBody_24s1136853347x1274611651(V v_ce_240, V v_xs_241, V v_b_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_242)));
  V v_owned_247 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2elamBody_24s1136853347x1274611651_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_n_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
  V v_ce_249 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), NTAG(TAG_Nothing), v_n_248, heff_get(heff_dup(v_ce_240), LBL_owned), heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(v_ce_240, LBL_known)});
  V v_ce_2410 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_249), LBL_tags), heff_get(heff_dup(v_ce_249), LBL_lbls), heff_get(heff_dup(v_ce_249), LBL_funs), heff_get(heff_dup(v_ce_249), LBL_bounce), heff_get(heff_dup(v_ce_249), LBL_self), heff_get(heff_dup(v_ce_249), LBL_lam), heff_get(heff_dup(v_ce_249), LBL_owned), heff_get(heff_dup(v_ce_249), LBL_after), NTAG(TAG_Nil), heff_get(heff_dup(v_ce_249), LBL_bor), heff_get(v_ce_249, LBL_known)});
  V v_ce_2411 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_2410), LBL_tags), heff_get(heff_dup(v_ce_2410), LBL_lbls), heff_get(heff_dup(v_ce_2410), LBL_funs), heff_get(heff_dup(v_ce_2410), LBL_bounce), heff_get(heff_dup(v_ce_2410), LBL_self), heff_get(heff_dup(v_ce_2410), LBL_lam), v_owned_247, NTAG(TAG_Nil), heff_get(heff_dup(v_ce_2410), LBL_borrowed), heff_get(heff_dup(v_ce_2410), LBL_bor), heff_get(v_ce_2410, LBL_known)});
  return (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_2411, NTAG(TAG_Ret), v_b_242));
}
V g_heff_2eemitc_2elamBody_24s1136853347x1274611651_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elamBody_24s1136853347x1274611651(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemitc_2elamBody_24s1136853347x1274611651_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str1 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 59, 32, 115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str2 = {{0x80000000u, K_STR, 0}, 33, 33, {95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 48, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str6 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str14 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str16 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 99, 108, 111, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s1720691912x77217039_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eemitc_2elamWith_24s1720691912x77217039_lam0(V self, V *args);
Clo g_heff_2eemitc_2elamWith_24s1720691912x77217039_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elamWith_24s1720691912x77217039_entry, 6, 0};

V g_heff_2eemitc_2elamWith_24s1720691912x77217039(V v_ce_240, V v_live_241, V v_xs_242, V v_b_243, V v_fv_244, V v_s_245) {
top: ;
  V v_x2_246 = (g_heff_2eemitc_2enewLam(v_s_245));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_heff_2eemitc_2elamBody_24s1136853347x1274611651(heff_dup(v_ce_240), heff_dup(v_xs_242), heff_dup(v_b_243), heff_dup(v_fv_244)));
    V v_x2_2410 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_n_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
      V v_t_2416;
      switch (heff_tag_of(v_fv_244)) {
      case TAG_Nil: {
        v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str0), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str1), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str2), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str3), heff_strAppend(heff_intShow(v_n_2413), ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str4)))))))));
        break;
      }
      case TAG_Cons: {
        heff_drop(v_n_2413);
        v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str5), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str6)));
        break;
      }
      default: heff_nomatch(v_fv_244);
      }
      V v_wanted_2417 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_243));
      V v_t_2420 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2elamWith_24s1720691912x77217039_lam0, 1, 1, (V[]){v_wanted_2417}), heff_dup(v_xs_242)));
      V v_x2_2421 = (g_heff_2eemitc_2elamLines(heff_dup(v_x_247), heff_dup(v_xs_242), heff_dup(v_fv_244), v_t_2420, v_x_2411));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_m_2425 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2416, v_t_2424}));
      V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_s_2428 = heff_field(v_x2_2426, 1);
        heff_take_n(v_x2_2426, 2ULL, 2);
        V v_t_2431;
        switch (heff_tag_of(v_fv_244)) {
        case TAG_Nil: {
          v_t_2431 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          v_t_2431 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_fv_244);
        }
        V v_x_2442;
        switch (heff_tag_of(v_t_2431)) {
        case TAG_True: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          heff_drop(v_xs_242);
          heff_drop(v_fv_244);
          v_x_2442 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str9), heff_strAppend(v_x_247, ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str10)));
          break;
        }
        case TAG_False: {
          V v_t_2432 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
          V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fv_244));
          V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2evarUse_clo), 2, (V[]){heff_get(v_ce_240, LBL_borrowed), v_live_241}));
          V v_vs_2435 = (g_list_2emap(v_t_2434, v_fv_244));
          V v_t_2441;
          switch (heff_tag_of(v_vs_2435)) {
          case TAG_Nil: {
            v_t_2441 = ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str11);
            break;
          }
          case TAG_Cons: {
            V v_t_2440;
            switch (heff_tag_of(v_vs_2435)) {
            case TAG_Nil: {
              v_t_2440 = ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str12);
              break;
            }
            case TAG_Cons: {
              V v_x_2438 = heff_field(v_vs_2435, 0);
              V v_xs_2439 = heff_field(v_vs_2435, 1);
              heff_take_n(v_vs_2435, 3ULL, 2);
              v_t_2440 = ({ V a_0 = ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str13); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
              break;
            }
            default: heff_nomatch(v_vs_2435);
            }
            v_t_2441 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str14), heff_strAppend(v_t_2440, ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str15)));
            break;
          }
          default: heff_nomatch(v_vs_2435);
          }
          v_x_2442 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str16), heff_strAppend(v_x_247, heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str17), heff_strAppend(heff_intShow(v_t_2432), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str18), heff_strAppend(heff_intShow(v_t_2433), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str19), heff_strAppend(v_t_2441, ((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_str20)))))))));
          break;
        }
        default: heff_nomatch(v_t_2431);
        }
        return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2442, v_s_2428});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eemitc_2elamWith_24s1720691912x77217039_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elamWith_24s1720691912x77217039(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eemitc_2elamWith_24s1720691912x77217039_lam0(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2417); r_; });
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam0(V self, V *args); static Clo g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam0, 1, 0};
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam1(V self, V *args);
Clo g_heff_2eemitc_2eoperandsF_24s483563689x9672247_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eoperandsF_24s483563689x9672247_entry, 3, 0};

V g_heff_2eemitc_2eoperandsF_24s483563689x9672247(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1187012699x1099443358(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_live_241)));
    V v_m_249 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(heff_dup(v_ce_240), v_live_248, v_e_244));
    return heff_clo(g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam1, 1, 4, (V[]){v_m_249, v_ce_240, v_live_241, v_es_245});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eoperandsF_24s483563689x9672247(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_243});
}
V g_heff_2eemitc_2eoperandsF_24s483563689x9672247_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_live_241 = heff_env(self)[2];
  V v_es_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_m_2414 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_ce_240, v_live_241, v_es_245));
    V v_x2_2415 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_s_2413}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_s_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2412, v_x_2416}), v_s_2417});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str17 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 116, 97, 103, 95, 97, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam0(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam0, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam1(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam1, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam2(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam2, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam3(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam3, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam4(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam4, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam5(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam5, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam6(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam6, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam7(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam7, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam8(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam8, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam9(V self, V *args);
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam10(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam10, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam11(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam11, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam12(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam12, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam13(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam13, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam14(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam14, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam15(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam15, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam16(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam16, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam17(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam17, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam18(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam18, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam19(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam19, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam20(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam20, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam21(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam21, 1, 0};
Clo g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_entry, 3, 0};

V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam0_clo);
  }
  case TAG_Cons: {
    V v_ru_244 = heff_field(v_x4_242, 0);
    V v_x42_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_ru_244);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam1_clo);
    }
    case TAG_Cons: {
      V v_x421_247 = heff_field(v_x42_245, 0);
      V v_x422_248 = heff_field(v_x42_245, 1);
      heff_take_n(v_x42_245, 3ULL, 2);
      switch (heff_tag_of(v_x421_247)) {
      case TAG_EVar: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam2_clo);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam3_clo);
      }
      case TAG_ELam: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam4_clo);
      }
      case TAG_EApp: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam5_clo);
      }
      case TAG_ELet: {
        heff_take_n(v_x421_247, 0ULL, 3);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam6_clo);
      }
      case TAG_ERecord: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam7_clo);
      }
      case TAG_EProj: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam8_clo);
      }
      case TAG_ETag: {
        V v_t_2428 = heff_field(v_x421_247, 0);
        V v_as_2429 = heff_field(v_x421_247, 1);
        heff_take_n(v_x421_247, 3ULL, 2);
        switch (heff_tag_of(v_x422_248)) {
        case TAG_Nil: {
          V v_m_2430 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_ce_240, v_live_241, heff_tag_at(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_ru_244, heff_dup(v_as_2429)})));
          return heff_clo(g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam9, 1, 3, (V[]){v_m_2430, v_t_2428, v_as_2429});
        }
        case TAG_Cons: {
          heff_take_n(v_x422_248, 0ULL, 2);
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          heff_drop(v_ru_244);
          heff_drop_cell(v_ru_24x4_242_24Cons, 2);
          heff_drop(v_t_2428);
          heff_drop(v_as_2429);
          return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam10_clo);
        }
        default: return heff_nomatch(v_x422_248);
        }
      }
      case TAG_EMatch: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam11_clo);
      }
      case TAG_EPrim: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam12_clo);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam13_clo);
      }
      case TAG_ECall: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam14_clo);
      }
      case TAG_EInt: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam15_clo);
      }
      case TAG_EFloat: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam16_clo);
      }
      case TAG_EStr: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam17_clo);
      }
      case TAG_EFixed: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam18_clo);
      }
      case TAG_EFloat32: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam19_clo);
      }
      case TAG_EAbandon: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam20_clo);
      }
      case TAG_EFix: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam21_clo);
      }
      default: return heff_nomatch(v_x421_247);
      }
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ereuseVal_24s471200110x1984229724(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str0), v_s_243});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam1(V self, V *args) {
  V v_s_246 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str1), v_s_246});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str2), v_s_2410});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str3), v_s_2412});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str4), v_s_2415});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam5(V self, V *args) {
  V v_s_2418 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str5), v_s_2418});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam6(V self, V *args) {
  V v_s_2422 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str6), v_s_2422});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam7(V self, V *args) {
  V v_s_2424 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str7), v_s_2424});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam8(V self, V *args) {
  V v_s_2427 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str8), v_s_2427});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam9(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_as_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_x2_2437;
    switch (heff_tag_of(v_x_2433)) {
    case TAG_Nil: {
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_dup(heff_field(v_x_2433, 0));
      v_x2_2437 = heff_tag(TAG_Just, 1, (V[]){v_x_2435});
      break;
    }
    default: heff_nomatch(v_x_2433);
    }
    V v_t_2439;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nothing: {
      v_t_2439 = ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str9);
      break;
    }
    case TAG_Just: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      heff_take_n(v_x2_2437, 1ULL, 1);
      v_t_2439 = v_x_2438;
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    V v_t_2440 = heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str10), (g_heff_2eemitc_2emangleW(v_t_2428, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str11))));
    V v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2429; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2429); r_; });
    V v_vs_2442 = (g_list_2edrop(MK_INT(1LL), v_x_2433));
    V v_t_2448;
    switch (heff_tag_of(v_vs_2442)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str12);
      break;
    }
    case TAG_Cons: {
      V v_t_2447;
      switch (heff_tag_of(v_vs_2442)) {
      case TAG_Nil: {
        v_t_2447 = ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2445 = heff_field(v_vs_2442, 0);
        V v_xs_2446 = heff_field(v_vs_2442, 1);
        heff_take_n(v_vs_2442, 3ULL, 2);
        v_t_2447 = ({ V a_0 = ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str14); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2442);
      }
      v_t_2448 = heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str15), heff_strAppend(v_t_2447, ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str16)));
      break;
    }
    default: heff_nomatch(v_vs_2442);
    }
    V v_x_2449 = heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str17), heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str18), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str19), heff_strAppend(heff_intShow(v_t_2441), heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str20), heff_strAppend(v_t_2448, ((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str21)))))))));
    return heff_tag_at(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam10(V self, V *args) {
  V v_s_2452 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str22), v_s_2452});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam11(V self, V *args) {
  V v_s_2455 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str23), v_s_2455});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam12(V self, V *args) {
  V v_s_2457 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str24), v_s_2457});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam13(V self, V *args) {
  V v_s_2460 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str25), v_s_2460});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam14(V self, V *args) {
  V v_s_2463 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str26), v_s_2463});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam15(V self, V *args) {
  V v_s_2465 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str27), v_s_2465});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam16(V self, V *args) {
  V v_s_2467 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str28), v_s_2467});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam17(V self, V *args) {
  V v_s_2469 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str29), v_s_2469});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam18(V self, V *args) {
  V v_s_2472 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str30), v_s_2472});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam19(V self, V *args) {
  V v_s_2474 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str31), v_s_2474});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam20(V self, V *args) {
  V v_s_2475 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str32), v_s_2475});
}
V g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_lam21(V self, V *args) {
  V v_s_2478 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s471200110x1984229724_str33), v_s_2478});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 100, 117, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {95, 103, 101, 116, 40, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str13 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 114, 101, 99, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str19 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 103, 101, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str22 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {78, 84, 65, 71, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str28 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str30 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str31 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str33 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 116, 97, 103, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str34 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str35 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str38 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str39 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str42 = {{0x80000000u, K_STR, 0}, 7, 7, {77, 75, 95, 73, 78, 84, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str43 = {{0x80000000u, K_STR, 0}, 3, 3, {76, 76, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str44 = {{0x80000000u, K_STR, 0}, 10, 10, {72, 69, 70, 70, 95, 66, 73, 71, 40, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str45 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str46 = {{0x80000000u, K_STR, 0}, 10, 10, {72, 69, 70, 70, 95, 66, 73, 71, 40, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str47 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str48 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 97, 78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str49 = {{0x80000000u, K_STR, 0}, 13, 13, {104, 101, 102, 102, 95, 102, 108, 116, 40, 78, 65, 78, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str50 = {{0x80000000u, K_STR, 0}, 8, 8, {73, 110, 102, 105, 110, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str51 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 95, 102, 108, 116, 40, 73, 78, 70, 73, 78, 73, 84, 89, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str52 = {{0x80000000u, K_STR, 0}, 9, 9, {45, 73, 110, 102, 105, 110, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str53 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 95, 102, 108, 116, 40, 45, 73, 78, 70, 73, 78, 73, 84, 89, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str54 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 102, 108, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str56 = {{0x80000000u, K_STR, 0}, 16, 16, {104, 101, 102, 102, 95, 102, 51, 50, 40, 40, 102, 108, 111, 97, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2evalF_24s1143988364x1058982433_str58 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 95, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam0(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam1(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam2(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam3(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam4(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam5(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam6(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam7(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam8(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam9(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam10(V self, V *args);
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam11(V self, V *args); static Clo g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam11, 1, 0};
Clo g_heff_2eemitc_2evalF_24s1143988364x1058982433_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evalF_24s1143988364x1058982433_entry, 3, 0};

V g_heff_2eemitc_2evalF_24s1143988364x1058982433(V v_ce_240, V v_live_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_x_244 = ({ V b_0 = heff_get(v_ce_240, LBL_borrowed); V a_1 = v_live_241; V a_2 = v_x_243; V r_ = (g_heff_2eemitc_2evarUse(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_live_241); r_; });
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_EGlobal: {
    V v_g_246 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_x3_247 = ({ V a_0 = heff_dup(v_g_246); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x_2411;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str0), (g_heff_2eemitc_2emangleW(v_g_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str1))));
      v_x_2411 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str2), heff_strAppend(v_t_248, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str3)));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str4), (g_heff_2eemitc_2emangleW(v_g_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str5))));
      v_x_2411 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str7)));
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam1, 1, 1, (V[]){v_x_2411});
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_e_242, 0);
    V v_b_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2415 = (g_heff_2eemitc_2efreeOf(heff_dup(v_xs_2413), heff_dup(v_b_2414)));
    return heff_tail(((V)&g_heff_2eemitc_2elamWith_24s1720691912x77217039_clo), 5, (V[]){v_ce_240, v_live_241, v_xs_2413, v_b_2414, v_t_2415});
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_2422 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2421)));
    V v_m_2423 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_ce_240, v_live_241, v_t_2422));
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam2, 1, 2, (V[]){v_m_2423, v_fs_2421});
  }
  case TAG_EProj: {
    V v_e1_2441 = heff_field(v_e_242, 0);
    V v_l_2442 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2443 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e1_2441));
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam3, 1, 2, (V[]){v_m_2443, v_l_2442});
  }
  case TAG_ETag: {
    V v_t_2450 = heff_field(v_e_242, 0);
    V v_as_2451 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2454;
    switch (heff_tag_of(v_as_2451)) {
    case TAG_Nil: {
      v_t_2454 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_as_2451);
    }
    switch (heff_tag_of(v_t_2454)) {
    case TAG_True: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_as_2451);
      V v_t_2455 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str22), (g_heff_2eemitc_2emangleW(v_t_2450, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str23))));
      V v_x_2456 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str24), heff_strAppend(v_t_2455, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str25)));
      return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam4, 1, 1, (V[]){v_x_2456});
    }
    case TAG_False: {
      V v_m_2458 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_ce_240, v_live_241, heff_dup(v_as_2451)));
      return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam5, 1, 3, (V[]){v_m_2458, v_t_2450, v_as_2451});
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrim: {
    V v_p_2474 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tail(((V)&g_heff_2eemitc_2eprimLit_clo), 1, (V[]){v_p_2474});
  }
  case TAG_EPrimCall: {
    V v_p_2475 = heff_field(v_e_242, 0);
    V v_as_2476 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_p_2475), heff_dup(g_heff_2eemitc_2ereusePrim_get()))) {
      heff_drop(v_p_2475);
      HEFF_LAST return g_heff_2eemitc_2ereuseVal_24s471200110x1984229724(v_ce_240, v_live_241, v_as_2476);
    } else {
      V v_m_2478 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_ce_240, v_live_241, v_as_2476));
      return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam6, 1, 2, (V[]){v_m_2478, v_p_2475});
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EInt: {
    V v_n_2489 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    V v_x_2492;
    if (heff_intLt_c(heff_dup(v_n_2489), HEFF_BIG("4611686018427387904"))) {
      if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_2489))) {
        v_x_2492 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str42), heff_strAppend(heff_intShow(v_n_2489), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str43)));
      } else {
        v_x_2492 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str44), heff_strAppend(heff_intShow(v_n_2489), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str45)));
      }
    } else {
      v_x_2492 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str46), heff_strAppend(heff_intShow(v_n_2489), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str47)));
    }
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam7, 1, 1, (V[]){v_x_2492});
  }
  case TAG_EFloat: {
    V v_x_2494 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    V v_x_2498;
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2494)), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str48))) {
      heff_drop(v_x_2494);
      v_x_2498 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str49);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2494)), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str50))) {
        heff_drop(v_x_2494);
        v_x_2498 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str51);
      } else {
        if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2494)), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str52))) {
          heff_drop(v_x_2494);
          v_x_2498 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str53);
        } else {
          v_x_2498 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str54), heff_strAppend(heff_floatShow(v_x_2494), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str55)));
        }
      }
    }
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam8, 1, 1, (V[]){v_x_2498});
  }
  case TAG_EStr: {
    V v_s_24100 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tail(((V)&g_heff_2eemitc_2estrLit_clo), 1, (V[]){v_s_24100});
  }
  case TAG_EFixed: {
    V v_w_24101 = heff_field(v_e_242, 0);
    V v_n_24102 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    V v_x_24103 = ({ V a_0 = v_w_24101; V a_1 = v_n_24102; V r_ = (g_heff_2eemitc_2efixedLit(a_0, a_1)); heff_drop(v_w_24101); r_; });
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam9, 1, 1, (V[]){v_x_24103});
  }
  case TAG_EFloat32: {
    V v_x_24105 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_clo(g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam10, 1, 1, (V[]){v_x_24105});
  }
  case TAG_EAbandon: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam11_clo);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, v_live_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2evalF_24s1143988364x1058982433(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_s_2412});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_fs_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_apply(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2428 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2421)));
    V v_m_2429 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eshapeLit_clo), 1, (V[]){v_t_2428}));
    V v_x2_2430 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_s_2427}));
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_s_2432 = heff_field(v_x2_2430, 1);
      heff_take_n(v_x2_2430, 3ULL, 2);
      V v_t_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2421; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
      V v_t_2439;
      switch (heff_tag_of(v_x_2426)) {
      case TAG_Nil: {
        v_t_2439 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str8);
        break;
      }
      case TAG_Cons: {
        V v_t_2438;
        switch (heff_tag_of(v_x_2426)) {
        case TAG_Nil: {
          v_t_2438 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str9);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x_2426, 0);
          V v_xs_2437 = heff_field(v_x_2426, 1);
          heff_take_n(v_x_2426, 3ULL, 2);
          v_t_2438 = ({ V a_0 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str10); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x_2426);
        }
        v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str11), heff_strAppend(v_t_2438, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str12)));
        break;
      }
      default: heff_nomatch(v_x_2426);
      }
      V v_x_2440 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str13), heff_strAppend(heff_intShow(v_t_2433), heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str14), heff_strAppend(v_x_2431, heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str15), heff_strAppend(v_t_2439, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str16)))))));
      return heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_2440, v_s_2432});
    }
    default: return heff_nomatch(v_x2_2430);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam3(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_apply(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    V v_t_2448 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str17), (g_heff_2eemitc_2emangleW(v_l_2442, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str18))));
    V v_x_2449 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str19), heff_strAppend(v_x_2446, heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str20), heff_strAppend(v_t_2448, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str21)))));
    return heff_tag_at(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam4(V self, V *args) {
  V v_s_2457 = args[0];
  V v_x_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2456, v_s_2457});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam5(V self, V *args) {
  V v_s_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_t_2450 = heff_env(self)[1];
  V v_as_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_apply(v_m_2458, 1, (V[]){v_s_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_s_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    V v_t_2463 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str26), (g_heff_2eemitc_2emangleW(v_t_2450, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str27))));
    V v_t_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2451; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2451); r_; });
    V v_t_2470;
    switch (heff_tag_of(v_x_2461)) {
    case TAG_Nil: {
      v_t_2470 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str28);
      break;
    }
    case TAG_Cons: {
      V v_t_2469;
      switch (heff_tag_of(v_x_2461)) {
      case TAG_Nil: {
        v_t_2469 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str29);
        break;
      }
      case TAG_Cons: {
        V v_x_2467 = heff_field(v_x_2461, 0);
        V v_xs_2468 = heff_field(v_x_2461, 1);
        heff_take_n(v_x_2461, 3ULL, 2);
        v_t_2469 = ({ V a_0 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str30); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
        break;
      }
      default: heff_nomatch(v_x_2461);
      }
      v_t_2470 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str31), heff_strAppend(v_t_2469, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str32)));
      break;
    }
    default: heff_nomatch(v_x_2461);
    }
    V v_x_2471 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str33), heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str34), heff_strAppend(heff_intShow(v_t_2464), heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str35), heff_strAppend(v_t_2470, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str36)))))));
    return heff_tag_at(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){v_x_2471, v_s_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam6(V self, V *args) {
  V v_s_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  V v_p_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2480 = heff_tr(heff_apply(v_m_2478, 1, (V[]){v_s_2479}));
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkPair: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    V v_s_2482 = heff_field(v_x2_2480, 1);
    V v_ru_24x2_2480_24MkPair = heff_take_reuse_n(v_x2_2480, 3ULL, 2);
    V v_t_2485;
    switch (heff_tag_of(v_x_2481)) {
    case TAG_Nil: {
      v_t_2485 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str37);
      break;
    }
    case TAG_Cons: {
      V v_x_2483 = heff_field(v_x_2481, 0);
      V v_xs_2484 = heff_field(v_x_2481, 1);
      heff_take_n(v_x_2481, 3ULL, 2);
      v_t_2485 = ({ V a_0 = ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str38); V a_1 = v_x_2483; V a_2 = v_xs_2484; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2484); r_; });
      break;
    }
    default: heff_nomatch(v_x_2481);
    }
    V v_x_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str39), v_p_2475), heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str40), heff_strAppend(v_t_2485, ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str41))));
    return heff_tag_at(v_ru_24x2_2480_24MkPair, TAG_MkPair, 2, (V[]){v_x_2486, v_s_2482});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam7(V self, V *args) {
  V v_s_2493 = args[0];
  V v_x_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2492, v_s_2493});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam8(V self, V *args) {
  V v_s_2499 = args[0];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2498, v_s_2499});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam9(V self, V *args) {
  V v_s_24104 = args[0];
  V v_x_24103 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24103, v_s_24104});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam10(V self, V *args) {
  V v_s_24106 = args[0];
  V v_x_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24107 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str56), heff_strAppend(heff_floatShow(v_x_24105), ((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str57)));
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_24107, v_s_24106});
}
V g_heff_2eemitc_2evalF_24s1143988364x1058982433_lam11(V self, V *args) {
  V v_s_24108 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2evalF_24s1143988364x1058982433_str58), v_s_24108});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str10 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str16 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str20 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str22 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str25 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str26 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str28 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str29 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str30 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str31 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str32 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str34 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str35 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str37 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str38 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str40 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str42 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str43 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str44 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str46 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str47 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str48 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str49 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str52 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str53 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str54 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str55 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str56 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str58 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str59 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str60 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str61 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str62 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str64 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str65 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str66 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str67 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str68 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str69 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str70 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str71 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str72 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str73 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str74 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str76 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str77 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str78 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str79 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str80 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str82 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str83 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str84 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str85 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str86 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str87 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str88 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str89 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str90 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str91 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str92 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str93 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str94 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str95 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str96 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str97 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str98 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str99 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str100 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str101 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str102 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str103 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str104 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str105 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str106 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s809384060x928837097_str107 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam0(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam1(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam2(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam3(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam4(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam5(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam6(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam7(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam8(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam9(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam10(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam11(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam12(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam13(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam14(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam15(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam16(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam17(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam18(V self, V *args);
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam19(V self, V *args);
Clo g_heff_2eemitc_2elentOne_24s809384060x928837097_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentOne_24s809384060x928837097_entry, 5, 0};

V g_heff_2eemitc_2elentOne_24s809384060x928837097(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24EVar = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_246 = (g_heff_2eemitc_2eelemI(v_i_243, v_bi_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop_cell(v_ru_24e_244_24EVar, 1);
      V v_x_247 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_x_245; V r_ = (g_heff_2eemitc_2elentVar(a_0, a_1, a_2)); heff_drop(v_live_241); r_; });
      return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam0, 1, 1, (V[]){v_x_247});
    }
    case TAG_False: {
      V v_m_249 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, heff_tag_at(v_ru_24e_244_24EVar, TAG_EVar, 1, (V[]){v_x_245})));
      return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam1, 1, 1, (V[]){v_m_249});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_EGlobal: {
    V v_m_2416 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam2, 1, 3, (V[]){v_m_2416, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ELam: {
    V v_m_2430 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam3, 1, 3, (V[]){v_m_2430, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EApp: {
    V v_m_2444 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam4, 1, 3, (V[]){v_m_2444, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ELet: {
    V v_m_2459 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam5, 1, 3, (V[]){v_m_2459, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ERecord: {
    V v_m_2472 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam6, 1, 3, (V[]){v_m_2472, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EProj: {
    V v_m_2486 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam7, 1, 3, (V[]){v_m_2486, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ETag: {
    V v_m_24100 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam8, 1, 3, (V[]){v_m_24100, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EMatch: {
    V v_m_24114 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam9, 1, 3, (V[]){v_m_24114, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EPrim: {
    V v_m_24127 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam10, 1, 3, (V[]){v_m_24127, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EPrimCall: {
    V v_m_24141 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam11, 1, 3, (V[]){v_m_24141, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ECall: {
    V v_m_24155 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam12, 1, 3, (V[]){v_m_24155, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EInt: {
    V v_m_24168 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam13, 1, 3, (V[]){v_m_24168, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EFloat: {
    V v_m_24181 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam14, 1, 3, (V[]){v_m_24181, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EStr: {
    V v_m_24194 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam15, 1, 3, (V[]){v_m_24194, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EFixed: {
    V v_m_24208 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam16, 1, 3, (V[]){v_m_24208, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EFloat32: {
    V v_m_24221 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam17, 1, 3, (V[]){v_m_24221, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EAbandon: {
    V v_m_24233 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam18, 1, 3, (V[]){v_m_24233, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EFix: {
    V v_m_24247 = heff_tr(g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s809384060x928837097_lam19, 1, 3, (V[]){v_m_24247, v_i_243, heff_dup(v_bi_242)});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentOne_24s809384060x928837097(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2412, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_apply(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2427;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      V v_t_2422 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str0), heff_intShow(heff_dup(v_i_243)));
      V v_t_2423 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str1), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str2), heff_strAppend(v_x_2419, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str3)))));
      V v_t_2424 = heff_tag_at(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
      V v_t_2425 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str4), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str5)));
      V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
      v_x_2427 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_2422, v_t_2424, v_t_2426});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
      v_x_2427 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2427, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam3(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2441;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      V v_t_2436 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str6), heff_intShow(heff_dup(v_i_243)));
      V v_t_2437 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str7), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str8), heff_strAppend(v_x_2433, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str9)))));
      V v_t_2438 = heff_tag_at(v_ru_24x2_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str10), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str11)));
      V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
      v_x_2441 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_2436, v_t_2438, v_t_2440});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2432_24MkPair, 2);
      v_x_2441 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2433, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2441, v_s_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam4(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2446 = heff_tr(heff_apply(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    V v_t_2449 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2455;
    switch (heff_tag_of(v_t_2449)) {
    case TAG_True: {
      V v_t_2450 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str12), heff_intShow(heff_dup(v_i_243)));
      V v_t_2451 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str13), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str14), heff_strAppend(v_x_2447, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str15)))));
      V v_t_2452 = heff_tag_at(v_ru_24x2_2446_24MkPair, TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_t_2453 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str16), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str17)));
      V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
      v_x_2455 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_2450, v_t_2452, v_t_2454});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2446_24MkPair, 2);
      v_x_2455 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2447, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2449);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2455, v_s_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam5(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2461 = heff_tr(heff_apply(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    V v_t_2464 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2470;
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      V v_t_2465 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str18), heff_intShow(heff_dup(v_i_243)));
      V v_t_2466 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str19), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str20), heff_strAppend(v_x_2462, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str21)))));
      V v_t_2467 = heff_tag_at(v_ru_24x2_2461_24MkPair, TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
      V v_t_2468 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str22), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str23)));
      V v_t_2469 = heff_tag(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
      v_x_2470 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_2465, v_t_2467, v_t_2469});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2461_24MkPair, 2);
      v_x_2470 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2462, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2464);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2470, v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam6(V self, V *args) {
  V v_s_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2474 = heff_tr(heff_apply(v_m_2472, 1, (V[]){v_s_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_s_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    V v_t_2477 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2483;
    switch (heff_tag_of(v_t_2477)) {
    case TAG_True: {
      V v_t_2478 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str24), heff_intShow(heff_dup(v_i_243)));
      V v_t_2479 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str25), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str26), heff_strAppend(v_x_2475, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str27)))));
      V v_t_2480 = heff_tag_at(v_ru_24x2_2474_24MkPair, TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
      V v_t_2481 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str28), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str29)));
      V v_t_2482 = heff_tag(TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
      v_x_2483 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_2478, v_t_2480, v_t_2482});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2474_24MkPair, 2);
      v_x_2483 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2475, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2477);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2483, v_s_2476});
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam7(V self, V *args) {
  V v_s_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2488 = heff_tr(heff_apply(v_m_2486, 1, (V[]){v_s_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_s_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    V v_t_2491 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2497;
    switch (heff_tag_of(v_t_2491)) {
    case TAG_True: {
      V v_t_2492 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str30), heff_intShow(heff_dup(v_i_243)));
      V v_t_2493 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str31), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str32), heff_strAppend(v_x_2489, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str33)))));
      V v_t_2494 = heff_tag_at(v_ru_24x2_2488_24MkPair, TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
      V v_t_2495 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str34), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str35)));
      V v_t_2496 = heff_tag(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
      v_x_2497 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_2492, v_t_2494, v_t_2496});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2488_24MkPair, 2);
      v_x_2497 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_2489, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2491);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2497, v_s_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam8(V self, V *args) {
  V v_s_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24102 = heff_tr(heff_apply(v_m_24100, 1, (V[]){v_s_24101}));
  switch (heff_tag_of(v_x2_24102)) {
  case TAG_MkPair: {
    V v_x_24103 = heff_field(v_x2_24102, 0);
    V v_s_24104 = heff_field(v_x2_24102, 1);
    V v_ru_24x2_24102_24MkPair = heff_take_reuse_n(v_x2_24102, 3ULL, 2);
    V v_t_24105 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24111;
    switch (heff_tag_of(v_t_24105)) {
    case TAG_True: {
      V v_t_24106 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str36), heff_intShow(heff_dup(v_i_243)));
      V v_t_24107 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str37), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str38), heff_strAppend(v_x_24103, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str39)))));
      V v_t_24108 = heff_tag_at(v_ru_24x2_24102_24MkPair, TAG_Cons, 2, (V[]){v_t_24107, NTAG(TAG_Nil)});
      V v_t_24109 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str40), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str41)));
      V v_t_24110 = heff_tag(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
      v_x_24111 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24106, v_t_24108, v_t_24110});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24102_24MkPair, 2);
      v_x_24111 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24103, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24105);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24111, v_s_24104});
  }
  default: return heff_nomatch(v_x2_24102);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam9(V self, V *args) {
  V v_s_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24116 = heff_tr(heff_apply(v_m_24114, 1, (V[]){v_s_24115}));
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_MkPair: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    V v_s_24118 = heff_field(v_x2_24116, 1);
    V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
    V v_t_24119 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24125;
    switch (heff_tag_of(v_t_24119)) {
    case TAG_True: {
      V v_t_24120 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str42), heff_intShow(heff_dup(v_i_243)));
      V v_t_24121 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str43), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str44), heff_strAppend(v_x_24117, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str45)))));
      V v_t_24122 = heff_tag_at(v_ru_24x2_24116_24MkPair, TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
      V v_t_24123 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str46), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str47)));
      V v_t_24124 = heff_tag(TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
      v_x_24125 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24120, v_t_24122, v_t_24124});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24116_24MkPair, 2);
      v_x_24125 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24117, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24119);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24125, v_s_24118});
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam10(V self, V *args) {
  V v_s_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24129 = heff_tr(heff_apply(v_m_24127, 1, (V[]){v_s_24128}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_s_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    V v_t_24132 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24138;
    switch (heff_tag_of(v_t_24132)) {
    case TAG_True: {
      V v_t_24133 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str48), heff_intShow(heff_dup(v_i_243)));
      V v_t_24134 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str49), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str50), heff_strAppend(v_x_24130, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str51)))));
      V v_t_24135 = heff_tag_at(v_ru_24x2_24129_24MkPair, TAG_Cons, 2, (V[]){v_t_24134, NTAG(TAG_Nil)});
      V v_t_24136 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str52), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str53)));
      V v_t_24137 = heff_tag(TAG_Cons, 2, (V[]){v_t_24136, NTAG(TAG_Nil)});
      v_x_24138 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24133, v_t_24135, v_t_24137});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24129_24MkPair, 2);
      v_x_24138 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24130, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24132);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24138, v_s_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam11(V self, V *args) {
  V v_s_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24143 = heff_tr(heff_apply(v_m_24141, 1, (V[]){v_s_24142}));
  switch (heff_tag_of(v_x2_24143)) {
  case TAG_MkPair: {
    V v_x_24144 = heff_field(v_x2_24143, 0);
    V v_s_24145 = heff_field(v_x2_24143, 1);
    V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
    V v_t_24146 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24152;
    switch (heff_tag_of(v_t_24146)) {
    case TAG_True: {
      V v_t_24147 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str54), heff_intShow(heff_dup(v_i_243)));
      V v_t_24148 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str55), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str56), heff_strAppend(v_x_24144, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str57)))));
      V v_t_24149 = heff_tag_at(v_ru_24x2_24143_24MkPair, TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
      V v_t_24150 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str58), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str59)));
      V v_t_24151 = heff_tag(TAG_Cons, 2, (V[]){v_t_24150, NTAG(TAG_Nil)});
      v_x_24152 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24147, v_t_24149, v_t_24151});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24143_24MkPair, 2);
      v_x_24152 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24144, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24146);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24152, v_s_24145});
  }
  default: return heff_nomatch(v_x2_24143);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam12(V self, V *args) {
  V v_s_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24157 = heff_tr(heff_apply(v_m_24155, 1, (V[]){v_s_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_MkPair: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    V v_s_24159 = heff_field(v_x2_24157, 1);
    V v_ru_24x2_24157_24MkPair = heff_take_reuse_n(v_x2_24157, 3ULL, 2);
    V v_t_24160 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24166;
    switch (heff_tag_of(v_t_24160)) {
    case TAG_True: {
      V v_t_24161 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str60), heff_intShow(heff_dup(v_i_243)));
      V v_t_24162 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str61), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str62), heff_strAppend(v_x_24158, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str63)))));
      V v_t_24163 = heff_tag_at(v_ru_24x2_24157_24MkPair, TAG_Cons, 2, (V[]){v_t_24162, NTAG(TAG_Nil)});
      V v_t_24164 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str64), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str65)));
      V v_t_24165 = heff_tag(TAG_Cons, 2, (V[]){v_t_24164, NTAG(TAG_Nil)});
      v_x_24166 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24161, v_t_24163, v_t_24165});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24157_24MkPair, 2);
      v_x_24166 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24158, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24160);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24166, v_s_24159});
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam13(V self, V *args) {
  V v_s_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24170 = heff_tr(heff_apply(v_m_24168, 1, (V[]){v_s_24169}));
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_MkPair: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    V v_s_24172 = heff_field(v_x2_24170, 1);
    V v_ru_24x2_24170_24MkPair = heff_take_reuse_n(v_x2_24170, 3ULL, 2);
    V v_t_24173 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24179;
    switch (heff_tag_of(v_t_24173)) {
    case TAG_True: {
      V v_t_24174 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str66), heff_intShow(heff_dup(v_i_243)));
      V v_t_24175 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str67), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str68), heff_strAppend(v_x_24171, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str69)))));
      V v_t_24176 = heff_tag_at(v_ru_24x2_24170_24MkPair, TAG_Cons, 2, (V[]){v_t_24175, NTAG(TAG_Nil)});
      V v_t_24177 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str70), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str71)));
      V v_t_24178 = heff_tag(TAG_Cons, 2, (V[]){v_t_24177, NTAG(TAG_Nil)});
      v_x_24179 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24174, v_t_24176, v_t_24178});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24170_24MkPair, 2);
      v_x_24179 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24171, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24173);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24179, v_s_24172});
  }
  default: return heff_nomatch(v_x2_24170);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam14(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24183 = heff_tr(heff_apply(v_m_24181, 1, (V[]){v_s_24182}));
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    V v_ru_24x2_24183_24MkPair = heff_take_reuse_n(v_x2_24183, 3ULL, 2);
    V v_t_24186 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24192;
    switch (heff_tag_of(v_t_24186)) {
    case TAG_True: {
      V v_t_24187 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str72), heff_intShow(heff_dup(v_i_243)));
      V v_t_24188 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str73), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str74), heff_strAppend(v_x_24184, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str75)))));
      V v_t_24189 = heff_tag_at(v_ru_24x2_24183_24MkPair, TAG_Cons, 2, (V[]){v_t_24188, NTAG(TAG_Nil)});
      V v_t_24190 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str76), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str77)));
      V v_t_24191 = heff_tag(TAG_Cons, 2, (V[]){v_t_24190, NTAG(TAG_Nil)});
      v_x_24192 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24187, v_t_24189, v_t_24191});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24183_24MkPair, 2);
      v_x_24192 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24184, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24186);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24192, v_s_24185});
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam15(V self, V *args) {
  V v_s_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24196 = heff_tr(heff_apply(v_m_24194, 1, (V[]){v_s_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_s_24198 = heff_field(v_x2_24196, 1);
    V v_ru_24x2_24196_24MkPair = heff_take_reuse_n(v_x2_24196, 3ULL, 2);
    V v_t_24199 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24205;
    switch (heff_tag_of(v_t_24199)) {
    case TAG_True: {
      V v_t_24200 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str78), heff_intShow(heff_dup(v_i_243)));
      V v_t_24201 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str79), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str80), heff_strAppend(v_x_24197, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str81)))));
      V v_t_24202 = heff_tag_at(v_ru_24x2_24196_24MkPair, TAG_Cons, 2, (V[]){v_t_24201, NTAG(TAG_Nil)});
      V v_t_24203 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str82), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str83)));
      V v_t_24204 = heff_tag(TAG_Cons, 2, (V[]){v_t_24203, NTAG(TAG_Nil)});
      v_x_24205 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24200, v_t_24202, v_t_24204});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24196_24MkPair, 2);
      v_x_24205 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24197, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24199);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24205, v_s_24198});
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam16(V self, V *args) {
  V v_s_24209 = args[0];
  V v_m_24208 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24210 = heff_tr(heff_apply(v_m_24208, 1, (V[]){v_s_24209}));
  switch (heff_tag_of(v_x2_24210)) {
  case TAG_MkPair: {
    V v_x_24211 = heff_field(v_x2_24210, 0);
    V v_s_24212 = heff_field(v_x2_24210, 1);
    V v_ru_24x2_24210_24MkPair = heff_take_reuse_n(v_x2_24210, 3ULL, 2);
    V v_t_24213 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24219;
    switch (heff_tag_of(v_t_24213)) {
    case TAG_True: {
      V v_t_24214 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str84), heff_intShow(heff_dup(v_i_243)));
      V v_t_24215 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str85), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str86), heff_strAppend(v_x_24211, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str87)))));
      V v_t_24216 = heff_tag_at(v_ru_24x2_24210_24MkPair, TAG_Cons, 2, (V[]){v_t_24215, NTAG(TAG_Nil)});
      V v_t_24217 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str88), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str89)));
      V v_t_24218 = heff_tag(TAG_Cons, 2, (V[]){v_t_24217, NTAG(TAG_Nil)});
      v_x_24219 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24214, v_t_24216, v_t_24218});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24210_24MkPair, 2);
      v_x_24219 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24211, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24213);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24219, v_s_24212});
  }
  default: return heff_nomatch(v_x2_24210);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam17(V self, V *args) {
  V v_s_24222 = args[0];
  V v_m_24221 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24223 = heff_tr(heff_apply(v_m_24221, 1, (V[]){v_s_24222}));
  switch (heff_tag_of(v_x2_24223)) {
  case TAG_MkPair: {
    V v_x_24224 = heff_field(v_x2_24223, 0);
    V v_s_24225 = heff_field(v_x2_24223, 1);
    V v_ru_24x2_24223_24MkPair = heff_take_reuse_n(v_x2_24223, 3ULL, 2);
    V v_t_24226 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24232;
    switch (heff_tag_of(v_t_24226)) {
    case TAG_True: {
      V v_t_24227 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str90), heff_intShow(heff_dup(v_i_243)));
      V v_t_24228 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str91), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str92), heff_strAppend(v_x_24224, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str93)))));
      V v_t_24229 = heff_tag_at(v_ru_24x2_24223_24MkPair, TAG_Cons, 2, (V[]){v_t_24228, NTAG(TAG_Nil)});
      V v_t_24230 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str94), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str95)));
      V v_t_24231 = heff_tag(TAG_Cons, 2, (V[]){v_t_24230, NTAG(TAG_Nil)});
      v_x_24232 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24227, v_t_24229, v_t_24231});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24223_24MkPair, 2);
      v_x_24232 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24224, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24226);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24232, v_s_24225});
  }
  default: return heff_nomatch(v_x2_24223);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam18(V self, V *args) {
  V v_s_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24235 = heff_tr(heff_apply(v_m_24233, 1, (V[]){v_s_24234}));
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_MkPair: {
    V v_x_24236 = heff_field(v_x2_24235, 0);
    V v_s_24237 = heff_field(v_x2_24235, 1);
    V v_ru_24x2_24235_24MkPair = heff_take_reuse_n(v_x2_24235, 3ULL, 2);
    V v_t_24238 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24244;
    switch (heff_tag_of(v_t_24238)) {
    case TAG_True: {
      V v_t_24239 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str96), heff_intShow(heff_dup(v_i_243)));
      V v_t_24240 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str97), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str98), heff_strAppend(v_x_24236, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str99)))));
      V v_t_24241 = heff_tag_at(v_ru_24x2_24235_24MkPair, TAG_Cons, 2, (V[]){v_t_24240, NTAG(TAG_Nil)});
      V v_t_24242 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str100), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str101)));
      V v_t_24243 = heff_tag(TAG_Cons, 2, (V[]){v_t_24242, NTAG(TAG_Nil)});
      v_x_24244 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24239, v_t_24241, v_t_24243});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24235_24MkPair, 2);
      v_x_24244 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24236, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24238);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24244, v_s_24237});
  }
  default: return heff_nomatch(v_x2_24235);
  }
}
V g_heff_2eemitc_2elentOne_24s809384060x928837097_lam19(V self, V *args) {
  V v_s_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24249 = heff_tr(heff_apply(v_m_24247, 1, (V[]){v_s_24248}));
  switch (heff_tag_of(v_x2_24249)) {
  case TAG_MkPair: {
    V v_x_24250 = heff_field(v_x2_24249, 0);
    V v_s_24251 = heff_field(v_x2_24249, 1);
    V v_ru_24x2_24249_24MkPair = heff_take_reuse_n(v_x2_24249, 3ULL, 2);
    V v_t_24252 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24258;
    switch (heff_tag_of(v_t_24252)) {
    case TAG_True: {
      V v_t_24253 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str102), heff_intShow(heff_dup(v_i_243)));
      V v_t_24254 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str103), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str104), heff_strAppend(v_x_24250, ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str105)))));
      V v_t_24255 = heff_tag_at(v_ru_24x2_24249_24MkPair, TAG_Cons, 2, (V[]){v_t_24254, NTAG(TAG_Nil)});
      V v_t_24256 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str106), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s809384060x928837097_str107)));
      V v_t_24257 = heff_tag(TAG_Cons, 2, (V[]){v_t_24256, NTAG(TAG_Nil)});
      v_x_24258 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_24253, v_t_24255, v_t_24257});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24249_24MkPair, 2);
      v_x_24258 = heff_rec(3, shape_arg__pre__post, (V[]){v_x_24250, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24252);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24258, v_s_24251});
  }
  default: return heff_nomatch(v_x2_24249);
  }
}
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam0(V self, V *args); static Clo g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam0, 1, 0};
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam1(V self, V *args);
Clo g_heff_2eemitc_2elentOperands_24s789057135x1152969519_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentOperands_24s789057135x1152969519_entry, 5, 0};

V g_heff_2eemitc_2elentOperands_24s789057135x1152969519(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    return ((V)&g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_246 = heff_field(v_x6_244, 0);
    V v_es_247 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_247)));
    V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1187012699x1099443358(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_dup(v_live_241)));
    V v_m_2411 = (g_heff_2eemitc_2elentOne_24s809384060x928837097(heff_dup(v_ce_240), v_t_2410, v_bi_242, heff_dup(v_i_243), v_e_246));
    return heff_clo(g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam1, 1, 6, (V[]){v_m_2411, v_ce_240, v_live_241, heff_dup(v_bi_242), v_i_243, v_es_247});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentOperands_24s789057135x1152969519(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_245});
}
V g_heff_2eemitc_2elentOperands_24s789057135x1152969519_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_live_241 = heff_env(self)[2];
  V v_bi_242 = heff_env(self)[3];
  V v_i_243 = heff_env(self)[4];
  V v_es_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_m_2416 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_bi_242; V a_3 = heff_intAdd(v_i_243, MK_INT(1LL)); V a_4 = v_es_247; V r_ = (g_heff_2eemitc_2elentOperands_24s789057135x1152969519(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bi_242); r_; });
    V v_x2_2417 = heff_tr(heff_apply(v_m_2416, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_s_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str6 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 95, 116, 114, 40, 104, 101, 102, 102, 95, 97, 112, 112, 108, 121, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s2137331x87770527_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 41}};
V g_heff_2eemitc_2ecompF_24s2137331x87770527_lam0(V self, V *args);
V g_heff_2eemitc_2ecompF_24s2137331x87770527_lam1(V self, V *args);
Clo g_heff_2eemitc_2ecompF_24s2137331x87770527_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ecompF_24s2137331x87770527_entry, 3, 0};

V g_heff_2eemitc_2ecompF_24s2137331x87770527(V v_ce_240, V v_live_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_e_242, 0);
    V v_as_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_m_249 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_ce_240, v_live_241, heff_tag_at(v_ru_24e_242_24EApp, TAG_Cons, 2, (V[]){v_f_247, heff_dup(v_as_248)})));
    return heff_clo(g_heff_2eemitc_2ecompF_24s2137331x87770527_lam0, 1, 2, (V[]){v_m_249, v_as_248});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ECall: {
    V v_g_2441 = heff_field(v_e_242, 0);
    V v_as_2442 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_x2_2443 = ({ V a_0 = heff_dup(v_g_2441); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2445;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nothing: {
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      heff_take_n(v_x2_2443, 1ULL, 1);
      v_t_2445 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    V v_m_2446 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2445; V a_3 = MK_INT(0LL); V a_4 = v_as_2442; V r_ = (g_heff_2eemitc_2elentOperands_24s789057135x1152969519(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2445); r_; });
    return heff_clo(g_heff_2eemitc_2ecompF_24s2137331x87770527_lam1, 1, 3, (V[]){v_m_2446, v_g_2441, v_ce_240});
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, v_live_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2ecompF_24s2137331x87770527_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ecompF_24s2137331x87770527(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ecompF_24s2137331x87770527_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_as_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_x2_2416;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nil: {
      v_x2_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_dup(heff_field(v_x_2412, 0));
      v_x2_2416 = heff_tag(TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_248); r_; });
    V v_vs_2420 = (g_list_2edrop(MK_INT(1LL), v_x_2412));
    V v_t_2426;
    switch (heff_tag_of(v_vs_2420)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str1);
      break;
    }
    case TAG_Cons: {
      V v_t_2425;
      switch (heff_tag_of(v_vs_2420)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_vs_2420, 0);
        V v_xs_2424 = heff_field(v_vs_2420, 1);
        heff_take_n(v_vs_2420, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str3); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2420);
      }
      v_t_2426 = heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str4), heff_strAppend(v_t_2425, ((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str5)));
      break;
    }
    default: heff_nomatch(v_vs_2420);
    }
    V v_x_2427 = heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str6), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str7), heff_strAppend(heff_intShow(v_t_2419), heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str8), heff_strAppend(v_t_2426, ((V)&g_heff_2eemitc_2ecompF_24s2137331x87770527_str9)))))));
    return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2eemitc_2ecompF_24s2137331x87770527_lam1(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_g_2441 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_apply(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_x3_2451 = ({ V a_0 = heff_dup(v_g_2441); V b_1 = heff_get(v_ce_240, LBL_bounce); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2453;
    switch (heff_tag_of(v_x3_2451)) {
    case TAG_Nothing: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2451, 0ULL, 1);
      v_t_2453 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2451);
    }
    V v_x_2454 = ({ V a_0 = v_g_2441; V a_1 = v_t_2453; V a_2 = v_x_2449; V r_ = (g_heff_2eemitc_2ecallText(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
    return heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){v_x_2454, v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str26 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str28 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str33 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str34 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str38 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str39 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str42 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str43 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str44 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str45 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str47 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str48 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str49 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str52 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str54 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str55 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str57 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str58 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str59 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str60 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str62 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str63 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str64 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str65 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str67 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str68 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str69 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str70 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str72 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str73 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str74 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str75 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str77 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str78 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str79 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str80 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str82 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str83 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str84 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str85 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str87 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str88 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str89 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str90 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str91 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str92 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str93 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str94 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str95 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str96 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam0(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam1(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam2(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam3(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam4(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam5(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam6(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam7(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam8(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam9(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam10(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam11(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam12(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam13(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam14(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam15(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam16(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam17(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam18(V self, V *args);
Clo g_heff_2eemitc_2ebindTo_24s468035823x1139231827_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ebindTo_24s468035823x1139231827_entry, 3, 0};

V g_heff_2eemitc_2ebindTo_24s468035823x1139231827(V v_ce_240, V v_x_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam0, 1, 2, (V[]){v_m_244, v_x_241});
  }
  case TAG_EGlobal: {
    V v_m_2413 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam1, 1, 2, (V[]){v_m_2413, v_x_241});
  }
  case TAG_ELam: {
    V v_m_2423 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam2, 1, 2, (V[]){v_m_2423, v_x_241});
  }
  case TAG_EApp: {
    V v_m_2433 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam3, 1, 2, (V[]){v_m_2433, v_x_241});
  }
  case TAG_ELet: {
    V v_y_2441 = heff_field(v_a_242, 0);
    V v_a2_2442 = heff_field(v_a_242, 1);
    V v_b_2443 = heff_field(v_a_242, 2);
    V v_ru_24a_242_24ELet = heff_take_reuse_n(v_a_242, 7ULL, 3);
    V v_t_2444 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str20), (g_heff_2eemitc_2emangleW(heff_dup(v_x_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str21))));
    V v_dest_2445 = heff_tag(TAG_Asg, 1, (V[]){v_t_2444});
    V v_m_2446 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_240, v_dest_2445, heff_tag_at(v_ru_24a_242_24ELet, TAG_ELet, 3, (V[]){v_y_2441, v_a2_2442, v_b_2443})));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam4, 1, 2, (V[]){v_m_2446, v_x_241});
  }
  case TAG_ERecord: {
    V v_m_2455 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam5, 1, 2, (V[]){v_m_2455, v_x_241});
  }
  case TAG_EProj: {
    V v_m_2465 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam6, 1, 2, (V[]){v_m_2465, v_x_241});
  }
  case TAG_ETag: {
    V v_m_2475 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam7, 1, 2, (V[]){v_m_2475, v_x_241});
  }
  case TAG_EMatch: {
    V v_s_2483 = heff_field(v_a_242, 0);
    V v_arms_2484 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EMatch = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_t_2485 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str41), (g_heff_2eemitc_2emangleW(heff_dup(v_x_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str42))));
    V v_dest_2486 = heff_tag(TAG_Asg, 1, (V[]){v_t_2485});
    V v_m_2487 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_240, v_dest_2486, heff_tag_at(v_ru_24a_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2483, v_arms_2484})));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam8, 1, 2, (V[]){v_m_2487, v_x_241});
  }
  case TAG_EPrim: {
    V v_m_2496 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam9, 1, 2, (V[]){v_m_2496, v_x_241});
  }
  case TAG_EPrimCall: {
    V v_m_24106 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam10, 1, 2, (V[]){v_m_24106, v_x_241});
  }
  case TAG_ECall: {
    V v_m_24116 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam11, 1, 2, (V[]){v_m_24116, v_x_241});
  }
  case TAG_EInt: {
    V v_m_24125 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam12, 1, 2, (V[]){v_m_24125, v_x_241});
  }
  case TAG_EFloat: {
    V v_m_24134 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam13, 1, 2, (V[]){v_m_24134, v_x_241});
  }
  case TAG_EStr: {
    V v_m_24143 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam14, 1, 2, (V[]){v_m_24143, v_x_241});
  }
  case TAG_EFixed: {
    V v_m_24153 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam15, 1, 2, (V[]){v_m_24153, v_x_241});
  }
  case TAG_EFloat32: {
    V v_m_24162 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam16, 1, 2, (V[]){v_m_24162, v_x_241});
  }
  case TAG_EAbandon: {
    V v_m_24170 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam17, 1, 2, (V[]){v_m_24170, v_x_241});
  }
  case TAG_EFix: {
    V v_m_24180 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam18, 1, 2, (V[]){v_m_24180, v_x_241});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ebindTo_24s468035823x1139231827(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str0), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str1))));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str3), heff_strAppend(v_x_247, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str4)))));
    V v_x_2411 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str5), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str6))));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str7), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str8), heff_strAppend(v_x_2416, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str9)))));
    V v_x_2420 = heff_tag_at(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_apply(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2428 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str10), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str11))));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str12), heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str13), heff_strAppend(v_x_2426, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str14)))));
    V v_x_2430 = heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2430, v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam3(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2435 = heff_tr(heff_apply(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2438 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str15), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str16))));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str17), heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str18), heff_strAppend(v_x_2436, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str19)))));
    V v_x_2440 = heff_tag_at(v_ru_24x2_2435_24MkPair, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam4(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2448 = heff_tr(heff_apply(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_t_2451 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str22), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str23))));
    V v_t_2452 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str24), heff_strAppend(v_t_2451, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str25)));
    V v_x_2453 = heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_Cons, 2, (V[]){v_t_2452, v_x_2449});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2453, v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam5(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2457 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2460 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str26), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str27))));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str28), heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str29), heff_strAppend(v_x_2458, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str30)))));
    V v_x_2462 = heff_tag_at(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2462, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam6(V self, V *args) {
  V v_s_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2467 = heff_tr(heff_apply(v_m_2465, 1, (V[]){v_s_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_s_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str31), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str32))));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str33), heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str34), heff_strAppend(v_x_2468, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str35)))));
    V v_x_2472 = heff_tag_at(v_ru_24x2_2467_24MkPair, TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2472, v_s_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam7(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2477 = heff_tr(heff_apply(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str36), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str37))));
    V v_t_2481 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str38), heff_strAppend(v_t_2480, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str39), heff_strAppend(v_x_2478, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str40)))));
    V v_x_2482 = heff_tag_at(v_ru_24x2_2477_24MkPair, TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2482, v_s_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam8(V self, V *args) {
  V v_s_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2489 = heff_tr(heff_apply(v_m_2487, 1, (V[]){v_s_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_s_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_t_2492 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str43), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str44))));
    V v_t_2493 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str45), heff_strAppend(v_t_2492, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str46)));
    V v_x_2494 = heff_tag_at(v_ru_24x2_2489_24MkPair, TAG_Cons, 2, (V[]){v_t_2493, v_x_2490});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2494, v_s_2491});
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam9(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_apply(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    V v_t_24101 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str47), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str48))));
    V v_t_24102 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str49), heff_strAppend(v_t_24101, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str50), heff_strAppend(v_x_2499, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str51)))));
    V v_x_24103 = heff_tag_at(v_ru_24x2_2498_24MkPair, TAG_Cons, 2, (V[]){v_t_24102, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24103, v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam10(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24108 = heff_tr(heff_apply(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
    V v_t_24111 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str52), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str53))));
    V v_t_24112 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str54), heff_strAppend(v_t_24111, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str55), heff_strAppend(v_x_24109, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str56)))));
    V v_x_24113 = heff_tag_at(v_ru_24x2_24108_24MkPair, TAG_Cons, 2, (V[]){v_t_24112, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24113, v_s_24110});
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam11(V self, V *args) {
  V v_s_24117 = args[0];
  V v_m_24116 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24118 = heff_tr(heff_apply(v_m_24116, 1, (V[]){v_s_24117}));
  switch (heff_tag_of(v_x2_24118)) {
  case TAG_MkPair: {
    V v_x_24119 = heff_field(v_x2_24118, 0);
    V v_s_24120 = heff_field(v_x2_24118, 1);
    V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
    V v_t_24121 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str57), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str58))));
    V v_t_24122 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str59), heff_strAppend(v_t_24121, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str60), heff_strAppend(v_x_24119, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str61)))));
    V v_x_24123 = heff_tag_at(v_ru_24x2_24118_24MkPair, TAG_Cons, 2, (V[]){v_t_24122, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24123, v_s_24120});
  }
  default: return heff_nomatch(v_x2_24118);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam12(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24127 = heff_tr(heff_apply(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str62), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str63))));
    V v_t_24131 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str64), heff_strAppend(v_t_24130, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str65), heff_strAppend(v_x_24128, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str66)))));
    V v_x_24132 = heff_tag_at(v_ru_24x2_24127_24MkPair, TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24132, v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam13(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24136 = heff_tr(heff_apply(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_t_24139 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str67), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str68))));
    V v_t_24140 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str69), heff_strAppend(v_t_24139, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str70), heff_strAppend(v_x_24137, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str71)))));
    V v_x_24141 = heff_tag_at(v_ru_24x2_24136_24MkPair, TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24138});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam14(V self, V *args) {
  V v_s_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24145 = heff_tr(heff_apply(v_m_24143, 1, (V[]){v_s_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_s_24147 = heff_field(v_x2_24145, 1);
    V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
    V v_t_24148 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str72), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str73))));
    V v_t_24149 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str74), heff_strAppend(v_t_24148, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str75), heff_strAppend(v_x_24146, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str76)))));
    V v_x_24150 = heff_tag_at(v_ru_24x2_24145_24MkPair, TAG_Cons, 2, (V[]){v_t_24149, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24150, v_s_24147});
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam15(V self, V *args) {
  V v_s_24154 = args[0];
  V v_m_24153 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24155 = heff_tr(heff_apply(v_m_24153, 1, (V[]){v_s_24154}));
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_MkPair: {
    V v_x_24156 = heff_field(v_x2_24155, 0);
    V v_s_24157 = heff_field(v_x2_24155, 1);
    V v_ru_24x2_24155_24MkPair = heff_take_reuse_n(v_x2_24155, 3ULL, 2);
    V v_t_24158 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str77), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str78))));
    V v_t_24159 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str79), heff_strAppend(v_t_24158, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str80), heff_strAppend(v_x_24156, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str81)))));
    V v_x_24160 = heff_tag_at(v_ru_24x2_24155_24MkPair, TAG_Cons, 2, (V[]){v_t_24159, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24160, v_s_24157});
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam16(V self, V *args) {
  V v_s_24163 = args[0];
  V v_m_24162 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24164 = heff_tr(heff_apply(v_m_24162, 1, (V[]){v_s_24163}));
  switch (heff_tag_of(v_x2_24164)) {
  case TAG_MkPair: {
    V v_x_24165 = heff_field(v_x2_24164, 0);
    V v_s_24166 = heff_field(v_x2_24164, 1);
    V v_ru_24x2_24164_24MkPair = heff_take_reuse_n(v_x2_24164, 3ULL, 2);
    V v_t_24167 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str82), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str83))));
    V v_t_24168 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str84), heff_strAppend(v_t_24167, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str85), heff_strAppend(v_x_24165, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str86)))));
    V v_x_24169 = heff_tag_at(v_ru_24x2_24164_24MkPair, TAG_Cons, 2, (V[]){v_t_24168, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24169, v_s_24166});
  }
  default: return heff_nomatch(v_x2_24164);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam17(V self, V *args) {
  V v_s_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24172 = heff_tr(heff_apply(v_m_24170, 1, (V[]){v_s_24171}));
  switch (heff_tag_of(v_x2_24172)) {
  case TAG_MkPair: {
    V v_x_24173 = heff_field(v_x2_24172, 0);
    V v_s_24174 = heff_field(v_x2_24172, 1);
    V v_ru_24x2_24172_24MkPair = heff_take_reuse_n(v_x2_24172, 3ULL, 2);
    V v_t_24175 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str87), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str88))));
    V v_t_24176 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str89), heff_strAppend(v_t_24175, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str90), heff_strAppend(v_x_24173, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str91)))));
    V v_x_24177 = heff_tag_at(v_ru_24x2_24172_24MkPair, TAG_Cons, 2, (V[]){v_t_24176, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24177, v_s_24174});
  }
  default: return heff_nomatch(v_x2_24172);
  }
}
V g_heff_2eemitc_2ebindTo_24s468035823x1139231827_lam18(V self, V *args) {
  V v_s_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24182 = heff_tr(heff_apply(v_m_24180, 1, (V[]){v_s_24181}));
  switch (heff_tag_of(v_x2_24182)) {
  case TAG_MkPair: {
    V v_x_24183 = heff_field(v_x2_24182, 0);
    V v_s_24184 = heff_field(v_x2_24182, 1);
    V v_ru_24x2_24182_24MkPair = heff_take_reuse_n(v_x2_24182, 3ULL, 2);
    V v_t_24185 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str92), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str93))));
    V v_t_24186 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str94), heff_strAppend(v_t_24185, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str95), heff_strAppend(v_x_24183, ((V)&g_heff_2eemitc_2ebindTo_24s468035823x1139231827_str96)))));
    V v_x_24187 = heff_tag_at(v_ru_24x2_24182_24MkPair, TAG_Cons, 2, (V[]){v_t_24186, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24187, v_s_24184});
  }
  default: return heff_nomatch(v_x2_24182);
  }
}
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam0(V self, V *args);
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam2(V self, V *args);
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam3(V self, V *args);
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam1(V self, V *args);
Clo g_heff_2eemitc_2eletWith_24s1758357723x678407587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eletWith_24s1758357723x678407587_entry, 7, 0};

V g_heff_2eemitc_2eletWith_24s1758357723x678407587(V v_ce_240, V v_dest_241, V v_x_242, V v_a_243, V v_b_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_wanted_247 = (g_prelude_2e_2b_2b(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_owned_249 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam0, 1, 1, (V[]){v_wanted_247}), heff_get(heff_dup(v_ce_240), LBL_owned)));
  V v_t_2410 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_get(heff_dup(v_ce_240), LBL_self), heff_get(heff_dup(v_ce_240), LBL_lam), v_owned_249, heff_dup(v_wb_246), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
  V v_m_2411 = (g_heff_2eemitc_2ebindTo_24s468035823x1139231827(v_t_2410, heff_dup(v_x_242), heff_dup(v_a_243)));
  return heff_clo(g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam1, 1, 8, (V[]){v_m_2411, v_wb_246, v_ce_240, v_x_242, v_a_243, v_dest_241, v_b_244, v_fa_245});
}
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eletWith_24s1758357723x678407587(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam0(V self, V *args) {
  V v_v_248 = args[0];
  V v_wanted_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_248; V a_1 = v_wanted_247; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_247); r_; });
}
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam2(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wb_246; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam3(V self, V *args) {
  V v_v_2429 = args[0];
  V v_wanted_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2430 = ({ V a_0 = v_v_2429; V a_1 = v_wanted_2428; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2428); r_; });
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_wb_246 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_a_243 = heff_env(self)[4];
  V v_dest_241 = heff_env(self)[5];
  V v_b_244 = heff_env(self)[6];
  V v_fa_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2417 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_get(heff_dup(v_ce_240), LBL_owned)));
    V v_t_2418 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_wb_246));
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_owned_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
    V v_t_2421 = (g_heff_2eemitc_2ebuiltOf(v_a_243));
    V v_ce_2422 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2421; V a_2 = heff_dup(v_ce_240); V r_ = (g_heff_2eemitc_2eknownLet(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
    V v_ce_2423 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_2422), LBL_tags), heff_get(heff_dup(v_ce_2422), LBL_lbls), heff_get(heff_dup(v_ce_2422), LBL_funs), heff_get(heff_dup(v_ce_2422), LBL_bounce), heff_get(heff_dup(v_ce_2422), LBL_self), heff_get(heff_dup(v_ce_2422), LBL_lam), v_owned_2420, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_2422), LBL_borrowed), heff_get(heff_dup(v_ce_2422), LBL_bor), heff_get(v_ce_2422, LBL_known)});
    V v_m_2424 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_2423, v_dest_241, v_b_244));
    V v_x2_2425 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_s_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
      V v_wanted_2428 = (g_prelude_2e_2b_2b(v_fa_245, heff_dup(v_wb_246)));
      V v_t_2431 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eletWith_24s1758357723x678407587_lam3, 1, 1, (V[]){v_wanted_2428}), heff_get(heff_dup(v_ce_240), LBL_owned)));
      V v_t_2432 = (g_heff_2eemitc_2edropsIn(heff_dup(v_ce_240), v_t_2431));
      V v_t_2433 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_wb_246; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
      V v_t_2437;
      switch (heff_tag_of(v_t_2433)) {
      case TAG_True: {
        heff_drop(v_ce_240);
        heff_drop(v_x_242);
        heff_drop(v_a_243);
        heff_drop_cell(v_ru_24x2_2425_24MkPair, 2);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_False: {
        V v_t_2434 = ({ V a_0 = v_a_243; V r_ = (g_heff_2eemitc_2ebuiltOf(a_0)); heff_drop(v_a_243); r_; });
        V v_t_2435 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2434; V a_2 = v_ce_240; V r_ = (g_heff_2eemitc_2eknownLet(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
        V v_t_2436 = heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
        v_t_2437 = (g_heff_2eemitc_2edropsIn(v_t_2435, v_t_2436));
        break;
      }
      default: heff_nomatch(v_t_2433);
      }
      V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2437, v_x_2426));
      V v_t_2439 = (g_prelude_2e_2b_2b(v_x_2414, v_t_2438));
      V v_x_2440 = (g_prelude_2e_2b_2b(v_t_2432, v_t_2439));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2427});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {78, 84, 65, 71, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str4 = {{0x80000000u, K_STR, 0}, 20, 20, {114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str6 = {{0x80000000u, K_STR, 0}, 13, 13, {104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2econdArm_24s142880068x1419285363_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam0(V self, V *args);
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam1(V self, V *args);
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam3(V self, V *args);
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam2(V self, V *args);
Clo g_heff_2eemitc_2econdArm_24s142880068x1419285363_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2econdArm_24s142880068x1419285363_entry, 4, 0};

V g_heff_2eemitc_2econdArm_24s142880068x1419285363(V v_ce_240, V v_dest_241, V v_t_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_ce_240);
    V v_t_244 = heff_strAppend(((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str0), (g_heff_2eemitc_2emangleW(v_t_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str1))));
    V v_sv_245 = heff_strAppend(((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str3)));
    V v_t_247;
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str4), heff_strAppend(v_sv_245, ((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str5)));
      break;
    }
    case TAG_Asg: {
      heff_take_n(v_dest_241, 0ULL, 1);
      v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str6), heff_strAppend(v_sv_245, ((V)&g_heff_2eemitc_2econdArm_24s142880068x1419285363_str7)));
      break;
    }
    default: heff_nomatch(v_dest_241);
    }
    V v_x_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    return heff_clo(g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam0, 1, 1, (V[]){v_x_248});
  }
  case TAG_Just: {
    V v_b_2410 = heff_field(v_x5_243, 0);
    heff_drop(v_t_242);
    V v_t_2411 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_2410)));
    V v_wanted_2412 = (g_prelude_2e_2b_2b(v_t_2411, heff_get(heff_dup(v_ce_240), LBL_after)));
    V v_owned_2414 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam1, 1, 1, (V[]){v_wanted_2412}), heff_get(heff_dup(v_ce_240), LBL_owned)));
    V v_ce_2415 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_get(heff_dup(v_ce_240), LBL_self), heff_get(heff_dup(v_ce_240), LBL_lam), v_owned_2414, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
    V v_m_2416 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_2415, v_dest_241, heff_dup(v_b_2410)));
    return heff_clo(g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam2, 1, 3, (V[]){v_m_2416, heff_dup(v_b_2410), v_ce_240});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2econdArm_24s142880068x1419285363(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_248, v_s_249});
}
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam1(V self, V *args) {
  V v_v_2413 = args[0];
  V v_wanted_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2413; V a_1 = v_wanted_2412; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2412); r_; });
}
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam3(V self, V *args) {
  V v_v_2423 = args[0];
  V v_wanted_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2424 = ({ V a_0 = v_v_2423; V a_1 = v_wanted_2422; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2422); r_; });
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2424);
  }
}
V g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_b_2410 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_apply(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_2410));
    V v_wanted_2422 = (g_prelude_2e_2b_2b(v_t_2421, heff_get(heff_dup(v_ce_240), LBL_after)));
    V v_t_2425 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2econdArm_24s142880068x1419285363_lam3, 1, 1, (V[]){v_wanted_2422}), heff_get(heff_dup(v_ce_240), LBL_owned)));
    V v_t_2426 = (g_heff_2eemitc_2edropsIn(v_ce_240, v_t_2425));
    V v_x_2427 = (g_prelude_2e_2b_2b(v_t_2426, v_x_2419));
    return heff_tag_at(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {95, 99, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2econdWith_24s1979740468x338110168_str13 = {{0x80000000u, K_STR, 0}, 8, 8, {125, 32, 101, 108, 115, 101, 32, 123}};
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam0(V self, V *args);
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam2(V self, V *args);
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam3(V self, V *args);
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam4(V self, V *args);
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam1(V self, V *args);
Clo g_heff_2eemitc_2econdWith_24s1979740468x338110168_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2econdWith_24s1979740468x338110168_entry, 5, 0};

V g_heff_2eemitc_2econdWith_24s1979740468x338110168(V v_ce_240, V v_dest_241, V v_c_242, V v_fa_243, V v_wb_244) {
top: ;
  V v_wanted_245 = (g_prelude_2e_2b_2b(heff_dup(v_fa_243), heff_dup(v_wb_244)));
  V v_owned_247 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam0, 1, 1, (V[]){v_wanted_245}), heff_get(heff_dup(v_ce_240), LBL_owned)));
  V v_t_248 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_get(heff_dup(v_ce_240), LBL_self), heff_get(heff_dup(v_ce_240), LBL_lam), v_owned_247, heff_dup(v_wb_244), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
  V v_m_249 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(v_t_248, heff_dup(v_wb_244), heff_get(heff_dup(v_c_242), LBL_args)));
  return heff_clo(g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam1, 1, 6, (V[]){v_m_249, v_wb_244, v_ce_240, v_c_242, v_dest_241, v_fa_243});
}
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2econdWith_24s1979740468x338110168(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  V v_wb_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2414; V a_1 = v_wb_244; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_244); r_; });
}
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam3(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wb_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wb_244; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_244); r_; });
}
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam4(V self, V *args) {
  V v_v_2431 = args[0];
  V v_wanted_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2432 = ({ V a_0 = v_v_2431; V a_1 = v_wanted_2430; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2430); r_; });
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_wb_244 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_dest_241 = heff_env(self)[4];
  V v_fa_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_owned_2415 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam2, 1, 1, (V[]){heff_dup(v_wb_244)}), heff_get(heff_dup(v_ce_240), LBL_owned)));
    V v_t_2416 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_get(heff_dup(v_ce_240), LBL_self), heff_get(heff_dup(v_ce_240), LBL_lam), v_owned_2415, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
    V v_t_2417 = ({ V a_0 = ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str0); V b_1 = heff_get(heff_dup(v_c_242), LBL_arms); V r_ = (g_heff_2eemitc_2earmFor(a_0, b_1)); heff_drop(b_1); r_; });
    V v_m_2418 = ({ V a_0 = v_t_2416; V a_1 = heff_dup(v_dest_241); V a_2 = ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str1); V a_3 = v_t_2417; V r_ = (g_heff_2eemitc_2econdArm_24s142880068x1419285363(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
    V v_x2_2419 = heff_tr(heff_apply(v_m_2418, 1, (V[]){v_s_2413}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_s_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_owned_2423 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam3, 1, 1, (V[]){heff_dup(v_wb_244)}), heff_get(heff_dup(v_ce_240), LBL_owned)));
      V v_t_2424 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_get(heff_dup(v_ce_240), LBL_self), heff_get(heff_dup(v_ce_240), LBL_lam), v_owned_2423, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
      V v_t_2425 = ({ V a_0 = ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str2); V b_1 = heff_get(heff_dup(v_c_242), LBL_arms); V r_ = (g_heff_2eemitc_2earmFor(a_0, b_1)); heff_drop(b_1); r_; });
      V v_m_2426 = ({ V a_0 = v_t_2424; V a_1 = v_dest_241; V a_2 = ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str3); V a_3 = v_t_2425; V r_ = (g_heff_2eemitc_2econdArm_24s142880068x1419285363(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
      V v_x2_2427 = heff_tr(heff_apply(v_m_2426, 1, (V[]){v_s_2421}));
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_MkPair: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_s_2429 = heff_field(v_x2_2427, 1);
        V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
        V v_wanted_2430 = (g_prelude_2e_2b_2b(v_fa_243, v_wb_244));
        V v_t_2433 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2econdWith_24s1979740468x338110168_lam4, 1, 1, (V[]){v_wanted_2430}), heff_get(heff_dup(v_ce_240), LBL_owned)));
        V v_t_2434 = (g_heff_2eemitc_2edropsIn(v_ce_240, v_t_2433));
        V v_t_2435 = heff_strAppend(((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str4), heff_get(v_c_242, LBL_prim));
        V v_t_2438;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_Nil: {
          v_t_2438 = ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x_2412, 0);
          V v_xs_2437 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 3ULL, 2);
          v_t_2438 = ({ V a_0 = ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str6); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str7), heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str8), heff_strAppend(v_t_2438, ((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str9)))));
        V v_t_2440 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str10), v_x_2420));
        V v_t_2441 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str11), v_x_2428));
        V v_t_2442 = heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str12), NTAG(TAG_Nil)});
        V v_t_2443 = heff_tag_at(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2econdWith_24s1979740468x338110168_str13), (g_prelude_2e_2b_2b(v_t_2441, v_t_2442))});
        V v_t_2444 = heff_tag_at(v_ru_24x2_2427_24MkPair, TAG_Cons, 2, (V[]){v_t_2439, (g_prelude_2e_2b_2b(v_t_2440, v_t_2443))});
        V v_x_2445 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2444));
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2445, v_s_2429});
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
Clo g_heff_2eemitc_2eletOrCond_24s941639003x471531944_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eletOrCond_24s941639003x471531944_entry, 6, 0};

V g_heff_2eemitc_2eletOrCond_24s941639003x471531944(V v_ce_240, V v_dest_241, V v_x_242, V v_a_243, V v_b_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2eemitc_2eisCondCall(v_a_243));
    V v_x7_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_x7_247 = (g_heff_2eemitc_2esunkGo(heff_dup(v_x_242), heff_dup(v_a_243), heff_dup(v_b_244)));
      break;
    }
    case TAG_False: {
      v_x7_247 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_x7_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_a_243)));
      V v_t_249 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_244)));
      V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_get(heff_dup(v_ce_240), LBL_after)));
      return (g_heff_2eemitc_2eletWith_24s1758357723x678407587(v_ce_240, v_dest_241, v_x_242, v_a_243, v_b_244, v_t_248, v_t_2410));
    }
    case TAG_Just: {
      V v_e_2411 = heff_field(v_x7_247, 0);
      heff_take_n(v_x7_247, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_a_243);
      heff_drop(v_b_244);
      return (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_240, v_dest_241, v_e_2411));
    }
    default: return heff_nomatch(v_x7_247);
    }
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_x7_245, 0);
    heff_drop(v_x_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_c_2412), LBL_args)));
    V v_t_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s1187012699x1099443358(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_es_2415 = (g_list_2emap_24s2006210321x387008715(heff_get(heff_dup(v_c_2412), LBL_arms)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2415));
    V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1187012699x1099443358(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2417, heff_get(heff_dup(v_ce_240), LBL_after)));
    return (g_heff_2eemitc_2econdWith_24s1979740468x338110168(v_ce_240, v_dest_241, heff_dup(v_c_2412), v_t_2414, v_t_2418));
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eemitc_2eletOrCond_24s941639003x471531944_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eletOrCond_24s941639003x471531944(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {95, 103, 101, 116, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2escrutF_24s625241799x1100958611_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
V g_heff_2eemitc_2escrutF_24s625241799x1100958611_lam0(V self, V *args);
V g_heff_2eemitc_2escrutF_24s625241799x1100958611_lam1(V self, V *args);
Clo g_heff_2eemitc_2escrutF_24s625241799x1100958611_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2escrutF_24s625241799x1100958611_entry, 2, 0};

V g_heff_2eemitc_2escrutF_24s625241799x1100958611(V v_ce_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop(v_ce_240);
    V v_x_243 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str1))));
    return heff_clo(g_heff_2eemitc_2escrutF_24s625241799x1100958611_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_246 = ({ V a_0 = heff_dup(v_g_245); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x_2410;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str2), (g_heff_2eemitc_2emangleW(v_g_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str3))));
      v_x_2410 = heff_strAppend(v_t_247, ((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str4));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str5), (g_heff_2eemitc_2emangleW(v_g_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str6))));
      v_x_2410 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str7), heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2escrutF_24s625241799x1100958611_str8)));
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    return heff_clo(g_heff_2eemitc_2escrutF_24s625241799x1100958611_lam1, 1, 1, (V[]){v_x_2410});
  }
  case TAG_ELam: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2eemitc_2evalF_24s1143988364x1058982433(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2eemitc_2escrutF_24s625241799x1100958611_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2escrutF_24s625241799x1100958611(a[0], a[1]);
}
V g_heff_2eemitc_2escrutF_24s625241799x1100958611_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_243, v_s_244});
}
V g_heff_2eemitc_2escrutF_24s625241799x1100958611_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_s_2411});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 115, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {58, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 110, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 76, 76, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 98, 114, 101, 97, 107, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam0(V self, V *args);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam1(V self, V *args);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam3(V self, V *args);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam4(V self, V *args);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam5(V self, V *args);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam6(V self, V *args);
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam2(V self, V *args);
Clo g_heff_2eemitc_2earmKept_24s1599190246x1726307436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2earmKept_24s1599190246x1726307436_entry, 10, 0};

V g_heff_2eemitc_2earmKept_24s1599190246x1726307436(V v_ce_240, V v_dest_241, V v_sv_242, V v_taken_243, V v_lent_244, V v_t_245, V v_vs_246, V v_b_247, V v_fb_248, V v_x11_249) {
top: ;
  switch (heff_tag_of(v_x11_249)) {
  case TAG_MkPair: {
    V v_ru_2410 = heff_field(v_x11_249, 0);
    V v_b2_2411 = heff_field(v_x11_249, 1);
    V v_ru_24x11_249_24MkPair = heff_take_reuse_n(v_x11_249, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_t_2413 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2413 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam0, 1, 1, (V[]){heff_dup(v_fb_248)}), heff_dup(v_vs_246)));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x11_249_24MkPair, 2);
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_dup(heff_field(v_ru_2410, 0));
      v_t_2415 = heff_tag_at(v_ru_24x11_249_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
    V v_owned_2417 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_ce_240), LBL_owned), v_t_2416));
    V v_t_2419;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_dup(heff_field(v_ru_2410, 0));
      v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2420 = (g_prelude_2e_2b_2b(heff_dup(v_fb_248), v_t_2419));
    V v_wanted_2421 = (g_prelude_2e_2b_2b(v_t_2420, heff_get(heff_dup(v_ce_240), LBL_after)));
    V v_owned_2423 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam1, 1, 1, (V[]){v_wanted_2421}), v_owned_2417));
    V v_bs_2424;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_bs_2424 = (g_prelude_2e_2b_2b(heff_dup(v_vs_246), heff_get(heff_dup(v_ce_240), LBL_borrowed)));
      break;
    }
    case TAG_False: {
      v_bs_2424 = heff_get(heff_dup(v_ce_240), LBL_borrowed);
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_246));
    V v_ce_2426 = (g_heff_2eemitc_2eknowCell(heff_dup(v_ru_2410), v_t_2425, heff_dup(v_ce_240)));
    V v_ce_2427 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_2426), LBL_tags), heff_get(heff_dup(v_ce_2426), LBL_lbls), heff_get(heff_dup(v_ce_2426), LBL_funs), heff_get(heff_dup(v_ce_2426), LBL_bounce), heff_get(heff_dup(v_ce_2426), LBL_self), heff_get(heff_dup(v_ce_2426), LBL_lam), heff_get(heff_dup(v_ce_2426), LBL_owned), heff_get(heff_dup(v_ce_2426), LBL_after), v_bs_2424, heff_get(heff_dup(v_ce_2426), LBL_bor), heff_get(v_ce_2426, LBL_known)});
    V v_ce_2428 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_2427), LBL_tags), heff_get(heff_dup(v_ce_2427), LBL_lbls), heff_get(heff_dup(v_ce_2427), LBL_funs), heff_get(heff_dup(v_ce_2427), LBL_bounce), heff_get(heff_dup(v_ce_2427), LBL_self), heff_get(heff_dup(v_ce_2427), LBL_lam), v_owned_2423, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_2427), LBL_borrowed), heff_get(heff_dup(v_ce_2427), LBL_bor), heff_get(v_ce_2427, LBL_known)});
    V v_m_2429 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_2428, heff_dup(v_dest_241), v_b2_2411));
    return heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam2, 1, 10, (V[]){v_m_2429, v_t_245, heff_dup(v_lent_244), heff_dup(v_taken_243), v_sv_242, v_fb_248, v_vs_246, v_ru_2410, v_ce_240, v_dest_241});
  }
  default: return heff_nomatch(v_x11_249);
  }
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2earmKept_24s1599190246x1726307436(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[3]); heff_drop(a[4]); heff_drop(a[7]); return r;
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam0(V self, V *args) {
  V v_v_2412 = args[0];
  V v_fb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2412; V a_1 = v_fb_248; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_fb_248); r_; });
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam1(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wanted_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wanted_2421; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2421); r_; });
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam3(V self, V *args) {
  V v_acc_2444 = args[0];
  V v_x_2445 = args[1];
  V v_f_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_apply(v_f_2439, 1, (V[]){v_x_2445}));
  return (g_prelude_2e_2b_2b(v_t_2446, v_acc_2444));
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam4(V self, V *args) {
  V v_v_2454 = args[0];
  V v_fb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2454; V a_1 = v_fb_248; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_fb_248); r_; });
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam5(V self, V *args) {
  V v_v_2458 = args[0];
  V v_wanted_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2459 = ({ V a_0 = v_v_2458; V a_1 = v_wanted_2457; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2457); r_; });
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2459);
  }
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam6(V self, V *args) {
  V v_v_2461 = args[0];
  V v_taken_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463;
  switch (heff_tag_of(v_taken_243)) {
  case TAG_Nothing: {
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2462 = heff_field(v_taken_243, 0);
    heff_take_n(v_taken_243, 1ULL, 1);
    v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_x_2462, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_243);
  }
  V v_x1_2464 = ({ V a_0 = v_v_2461; V a_1 = v_t_2463; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2463); r_; });
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_lent_244 = heff_env(self)[2];
  V v_taken_243 = heff_env(self)[3];
  V v_sv_242 = heff_env(self)[4];
  V v_fb_248 = heff_env(self)[5];
  V v_vs_246 = heff_env(self)[6];
  V v_ru_2410 = heff_env(self)[7];
  V v_ce_240 = heff_env(self)[8];
  V v_dest_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2431 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str0), (g_heff_2eemitc_2emangleW(v_t_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str1))));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str2), heff_strAppend(v_t_2434, ((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str3)));
    V v_t_2436 = heff_tag_at(v_ru_24x2_2431_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
    V v_t_2438;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_taken_243)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_243);
      }
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_f_2439 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2efieldLine_clo), 3, (V[]){heff_dup(v_sv_242), v_t_2438, heff_dup(v_fb_248)}));
    V v_t_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_246));
    V v_t_2441 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2440, MK_INT(1LL))));
    V v_xs_2442 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_246), v_t_2441));
    V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2442));
    V v_t_2447 = ({ V a_0 = heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam3, 2, 1, (V[]){v_f_2439}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2443; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2443); r_; });
    V v_t_2453;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_taken_243)) {
      case TAG_Nothing: {
        heff_drop(v_sv_242);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2449 = (g_heff_2eemitc_2efieldMask(v_fb_248, MK_INT(0LL), v_vs_246));
        V v_t_2450 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_246));
        V v_t_2451 = heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str4), heff_strAppend(v_sv_242, heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str5), heff_strAppend(heff_intShow(v_t_2449), heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str6), heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str7)))))));
        v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_taken_243);
      }
      break;
    }
    case TAG_Just: {
      v_t_2453 = ({ V a_0 = v_sv_242; V a_1 = v_ru_2410; V a_2 = v_vs_246; V a_3 = v_fb_248; V r_ = (g_heff_2eemitc_2etakeKept(a_0, a_1, a_2, a_3)); heff_drop_tag(v_ru_2410, 1); r_; });
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2455;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      heff_drop(v_vs_246);
      v_t_2455 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2455 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam4, 1, 1, (V[]){heff_dup(v_fb_248)}), v_vs_246));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_owned_2456 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_ce_240), LBL_owned), v_t_2455));
    V v_wanted_2457 = (g_prelude_2e_2b_2b(v_fb_248, heff_get(heff_dup(v_ce_240), LBL_after)));
    V v_t_2460 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam5, 1, 1, (V[]){v_wanted_2457}), v_owned_2456));
    V v_t_2465 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s1599190246x1726307436_lam6, 1, 1, (V[]){v_taken_243}), v_t_2460));
    V v_t_2466 = (g_heff_2eemitc_2edropsIn(v_ce_240, v_t_2465));
    V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2453, v_t_2466));
    V v_t_2468 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str8), v_t_2467));
    V v_t_2469 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str9), v_x_2432));
    V v_t_2471;
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      v_t_2471 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Asg: {
      heff_take_n(v_dest_241, 0ULL, 1);
      v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str10), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_dest_241);
    }
    V v_t_2472 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2earmKept_24s1599190246x1726307436_str11), NTAG(TAG_Nil)});
    V v_t_2473 = (g_prelude_2e_2b_2b(v_t_2471, v_t_2472));
    V v_t_2474 = (g_prelude_2e_2b_2b(v_t_2469, v_t_2473));
    V v_t_2475 = (g_prelude_2e_2b_2b(v_t_2468, v_t_2474));
    V v_t_2476 = (g_prelude_2e_2b_2b(v_t_2447, v_t_2475));
    V v_x_2477 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2476));
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
Clo g_heff_2eemitc_2earmLines_24s1383923797x88700679_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2earmLines_24s1383923797x88700679_entry, 6, 0};

V g_heff_2eemitc_2earmLines_24s1383923797x88700679(V v_ce_240, V v_dest_241, V v_sv_242, V v_held_243, V v_lent_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_MkArm: {
    V v_t_246 = heff_field(v_x7_245, 0);
    V v_vs_247 = heff_field(v_x7_245, 1);
    V v_b_248 = heff_field(v_x7_245, 2);
    V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_247));
    V v_ce_2410 = (g_heff_2eemitc_2eknowing(heff_dup(v_held_243), v_t_249, v_ce_240));
    V v_fb_2411 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_248)));
    V v_taken_2412 = (g_heff_2eemitc_2etakenFv(heff_dup(v_ce_2410), v_held_243, v_vs_247, v_fb_2411));
    V v_t_2413 = (g_heff_2eemitc_2ereusing(heff_dup(v_taken_2412), heff_dup(v_t_246), v_vs_247, heff_dup(v_b_248)));
    return ({ V a_0 = v_ce_2410; V a_1 = v_dest_241; V a_2 = v_sv_242; V a_3 = v_taken_2412; V a_4 = v_lent_244; V a_5 = heff_dup(v_t_246); V a_6 = heff_dup(v_vs_247); V a_7 = v_b_248; V a_8 = v_fb_2411; V a_9 = v_t_2413; V r_ = (g_heff_2eemitc_2earmKept_24s1599190246x1726307436(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_taken_2412); r_; });
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eemitc_2earmLines_24s1383923797x88700679_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2earmLines_24s1383923797x88700679(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[4]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str18 = {{0x80000000u, K_STR, 0}, 17, 17, {114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 116, 97, 105, 108, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str22 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str24 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str26 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str30 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str32 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str34 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str36 = {{0x80000000u, K_STR, 0}, 20, 20, {115, 119, 105, 116, 99, 104, 32, 40, 104, 101, 102, 102, 95, 116, 97, 103, 95, 111, 102, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str37 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str38 = {{0x80000000u, K_STR, 0}, 20, 20, {114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str39 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str40 = {{0x80000000u, K_STR, 0}, 13, 13, {104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str43 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 101, 102, 97, 117, 108, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str44 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str46 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str48 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str52 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str54 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str55 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str56 = {{0x80000000u, K_STR, 0}, 17, 17, {72, 69, 70, 70, 95, 76, 65, 83, 84, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str58 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str59 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str61 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str63 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str65 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str67 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str69 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str71 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str73 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str75 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str77 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str79 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str81 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str82 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str83 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str85 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str87 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str88 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str89 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam0(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam1(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam2(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam3(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam4(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam5(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam6(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam7(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam8(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam9(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam10(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam11(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam12(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam13(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam14(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam15(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam16(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam17(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam18(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam19(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam20(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam21(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam22(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam23(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam24(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam25(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam26(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam27(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam28(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam29(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam30(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam31(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam32(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam33(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam34(V self, V *args);
Clo g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_entry, 3, 0};

V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(V v_ce_240, V v_dest_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_244 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam0, 1, 1, (V[]){v_m_244});
    }
    case TAG_Asg: {
      V v_x_2411 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2412 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam1, 1, 2, (V[]){v_m_2412, v_x_2411});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2420 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam2, 1, 1, (V[]){v_m_2420});
    }
    case TAG_Asg: {
      V v_x_2427 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2428 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam3, 1, 2, (V[]){v_m_2428, v_x_2427});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ELam: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2437 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam4, 1, 1, (V[]){v_m_2437});
    }
    case TAG_Asg: {
      V v_x_2444 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2445 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam5, 1, 2, (V[]){v_m_2445, v_x_2444});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EApp: {
    V v_f_2452 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2453 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      heff_drop_tag(v_e_242, 2);
      V v_m_2454 = (g_heff_2eemitc_2eoperandsF_24s483563689x9672247(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_f_2452, heff_dup(v_as_2453)})));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam6, 1, 3, (V[]){v_m_2454, v_as_2453, v_ce_240});
    }
    case TAG_Asg: {
      V v_x_2478 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      heff_drop(v_f_2452);
      heff_drop(v_as_2453);
      V v_m_2479 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam7, 1, 2, (V[]){v_m_2479, v_x_2478});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ELet: {
    V v_x_2486 = heff_field(v_e_242, 0);
    V v_a_2487 = heff_field(v_e_242, 1);
    V v_b_2488 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2489 = (g_heff_2eemitc_2econdLet(heff_dup(v_x_2486), v_a_2487, v_b_2488));
    return ({ V a_0 = v_ce_240; V a_1 = v_dest_241; V a_2 = v_x_2486; V a_3 = v_a_2487; V a_4 = v_b_2488; V a_5 = v_t_2489; V r_ = (g_heff_2eemitc_2eletOrCond_24s941639003x471531944(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2489); r_; });
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2491 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam8, 1, 1, (V[]){v_m_2491});
    }
    case TAG_Asg: {
      V v_x_2498 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2499 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam9, 1, 2, (V[]){v_m_2499, v_x_2498});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24108 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam10, 1, 1, (V[]){v_m_24108});
    }
    case TAG_Asg: {
      V v_x_24115 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24116 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam11, 1, 2, (V[]){v_m_24116, v_x_24115});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24125 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam12, 1, 1, (V[]){v_m_24125});
    }
    case TAG_Asg: {
      V v_x_24132 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24133 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam13, 1, 2, (V[]){v_m_24133, v_x_24132});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EMatch: {
    V v_s_24140 = heff_field(v_e_242, 0);
    V v_arms_24141 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24142 = heff_tr(g_heff_2eemitc_2escrutF_24s625241799x1100958611(heff_dup(v_ce_240), heff_dup(v_s_24140)));
    return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam14, 1, 5, (V[]){v_m_24142, v_ce_240, v_s_24140, v_dest_241, v_arms_24141});
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24194 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam15, 1, 1, (V[]){v_m_24194});
    }
    case TAG_Asg: {
      V v_x_24201 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24202 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam16, 1, 2, (V[]){v_m_24202, v_x_24201});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24211 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam17, 1, 1, (V[]){v_m_24211});
    }
    case TAG_Asg: {
      V v_x_24218 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24219 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam18, 1, 2, (V[]){v_m_24219, v_x_24218});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ECall: {
    V v_g_24226 = heff_dup(heff_field(v_e_242, 0));
    V v_as_24227 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      heff_drop_tag(v_e_242, 2);
      V v_x2_24228 = ({ V a_0 = heff_dup(v_g_24226); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24230;
      switch (heff_tag_of(v_x2_24228)) {
      case TAG_Nothing: {
        v_t_24230 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_24229 = heff_field(v_x2_24228, 0);
        heff_take_n(v_x2_24228, 1ULL, 1);
        v_t_24230 = v_x_24229;
        break;
      }
      default: heff_nomatch(v_x2_24228);
      }
      V v_m_24231 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24230; V a_3 = MK_INT(0LL); V a_4 = heff_dup(v_as_24227); V r_ = (g_heff_2eemitc_2elentOperands_24s789057135x1152969519(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24230); r_; });
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam19, 1, 4, (V[]){v_m_24231, v_ce_240, v_g_24226, v_as_24227});
    }
    case TAG_Asg: {
      V v_x_24255 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      heff_drop(v_g_24226);
      heff_drop(v_as_24227);
      V v_m_24256 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam20, 1, 2, (V[]){v_m_24256, v_x_24255});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24264 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam21, 1, 1, (V[]){v_m_24264});
    }
    case TAG_Asg: {
      V v_x_24271 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24272 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam22, 1, 2, (V[]){v_m_24272, v_x_24271});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24280 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam23, 1, 1, (V[]){v_m_24280});
    }
    case TAG_Asg: {
      V v_x_24287 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24288 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam24, 1, 2, (V[]){v_m_24288, v_x_24287});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24296 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam25, 1, 1, (V[]){v_m_24296});
    }
    case TAG_Asg: {
      V v_x_24303 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24304 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam26, 1, 2, (V[]){v_m_24304, v_x_24303});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24313 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam27, 1, 1, (V[]){v_m_24313});
    }
    case TAG_Asg: {
      V v_x_24320 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24321 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam28, 1, 2, (V[]){v_m_24321, v_x_24320});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24329 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam29, 1, 1, (V[]){v_m_24329});
    }
    case TAG_Asg: {
      V v_x_24336 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24337 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam30, 1, 2, (V[]){v_m_24337, v_x_24336});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24344 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam31, 1, 1, (V[]){v_m_24344});
    }
    case TAG_Asg: {
      V v_x_24351 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24352 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam32, 1, 2, (V[]){v_m_24352, v_x_24351});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24361 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam33, 1, 1, (V[]){v_m_24361});
    }
    case TAG_Asg: {
      V v_x_24368 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24369 = heff_tr(g_heff_2eemitc_2ecompF_24s2137331x87770527(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam34, 1, 2, (V[]){v_m_24369, v_x_24368});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str0), heff_strAppend(v_x_247, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str1)));
    V v_t_2410 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_strAppend(v_x_2411, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str2), heff_strAppend(v_x_2415, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str3))));
    V v_t_2418 = heff_tag_at(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam2(V self, V *args) {
  V v_s_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2422 = heff_tr(heff_apply(v_m_2420, 1, (V[]){v_s_2421}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_s_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str4), heff_strAppend(v_x_2423, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str5)));
    V v_t_2426 = heff_tag_at(v_ru_24x2_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2426, v_s_2424});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam3(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2430 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_strAppend(v_x_2427, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str6), heff_strAppend(v_x_2431, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str7))));
    V v_t_2434 = heff_tag_at(v_ru_24x2_2430_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2434, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam4(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2439 = heff_tr(heff_apply(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str8), heff_strAppend(v_x_2440, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str9)));
    V v_t_2443 = heff_tag_at(v_ru_24x2_2439_24MkPair, TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam5(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_apply(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    V v_t_2450 = heff_strAppend(v_x_2444, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str10), heff_strAppend(v_x_2448, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str11))));
    V v_t_2451 = heff_tag_at(v_ru_24x2_2447_24MkPair, TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam6(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_as_2453 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    V v_t_2459 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2453));
    V v_t_2462;
    if (heff_intLt_c(MK_INT(0LL), v_t_2459)) {
      V v_t_2461 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2453));
      v_t_2462 = heff_intLe(v_t_2461, heff_get(v_ce_240, LBL_lam));
    } else {
      heff_drop(v_ce_240);
      v_t_2462 = NTAG(TAG_False);
    }
    V v_x_2477;
    switch (heff_tag_of(v_t_2462)) {
    case TAG_True: {
      heff_drop(v_as_2453);
      heff_drop_cell(v_ru_24x2_2456_24MkPair, 2);
      v_x_2477 = (g_heff_2eemitc_2einPlace(v_x_2457));
      break;
    }
    case TAG_False: {
      V v_x2_2465;
      switch (heff_tag_of(v_x_2457)) {
      case TAG_Nil: {
        v_x2_2465 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_dup(heff_field(v_x_2457, 0));
        v_x2_2465 = heff_tag(TAG_Just, 1, (V[]){v_x_2463});
        break;
      }
      default: heff_nomatch(v_x_2457);
      }
      V v_t_2467;
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_Nothing: {
        v_t_2467 = ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str12);
        break;
      }
      case TAG_Just: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        heff_take_n(v_x2_2465, 1ULL, 1);
        v_t_2467 = v_x_2466;
        break;
      }
      default: heff_nomatch(v_x2_2465);
      }
      V v_t_2468 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2453; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2453); r_; });
      V v_vs_2469 = (g_list_2edrop(MK_INT(1LL), v_x_2457));
      V v_t_2475;
      switch (heff_tag_of(v_vs_2469)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str13);
        break;
      }
      case TAG_Cons: {
        V v_t_2474;
        switch (heff_tag_of(v_vs_2469)) {
        case TAG_Nil: {
          v_t_2474 = ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str14);
          break;
        }
        case TAG_Cons: {
          V v_x_2472 = heff_field(v_vs_2469, 0);
          V v_xs_2473 = heff_field(v_vs_2469, 1);
          heff_take_n(v_vs_2469, 3ULL, 2);
          v_t_2474 = ({ V a_0 = ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str15); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
          break;
        }
        default: heff_nomatch(v_vs_2469);
        }
        v_t_2475 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str16), heff_strAppend(v_t_2474, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str17)));
        break;
      }
      default: heff_nomatch(v_vs_2469);
      }
      V v_t_2476 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str18), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str19), heff_strAppend(heff_intShow(v_t_2468), heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str20), heff_strAppend(v_t_2475, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str21)))))));
      v_x_2477 = heff_tag_at(v_ru_24x2_2456_24MkPair, TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2462);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam7(V self, V *args) {
  V v_s_2480 = args[0];
  V v_m_2479 = heff_env(self)[0];
  V v_x_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2481 = heff_tr(heff_apply(v_m_2479, 1, (V[]){v_s_2480}));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_s_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    V v_t_2484 = heff_strAppend(v_x_2478, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str22), heff_strAppend(v_x_2482, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str23))));
    V v_t_2485 = heff_tag_at(v_ru_24x2_2481_24MkPair, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2485, v_s_2483});
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam8(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2493 = heff_tr(heff_apply(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_t_2496 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str24), heff_strAppend(v_x_2494, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str25)));
    V v_t_2497 = heff_tag_at(v_ru_24x2_2493_24MkPair, TAG_Cons, 2, (V[]){v_t_2496, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2497, v_s_2495});
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam9(V self, V *args) {
  V v_s_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  V v_x_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24101 = heff_tr(heff_apply(v_m_2499, 1, (V[]){v_s_24100}));
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    V v_s_24103 = heff_field(v_x2_24101, 1);
    V v_ru_24x2_24101_24MkPair = heff_take_reuse_n(v_x2_24101, 3ULL, 2);
    V v_t_24104 = heff_strAppend(v_x_2498, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str26), heff_strAppend(v_x_24102, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str27))));
    V v_t_24105 = heff_tag_at(v_ru_24x2_24101_24MkPair, TAG_Cons, 2, (V[]){v_t_24104, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24105, v_s_24103});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam10(V self, V *args) {
  V v_s_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24110 = heff_tr(heff_apply(v_m_24108, 1, (V[]){v_s_24109}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_MkPair: {
    V v_x_24111 = heff_field(v_x2_24110, 0);
    V v_s_24112 = heff_field(v_x2_24110, 1);
    V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
    V v_t_24113 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str28), heff_strAppend(v_x_24111, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str29)));
    V v_t_24114 = heff_tag_at(v_ru_24x2_24110_24MkPair, TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24114, v_s_24112});
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam11(V self, V *args) {
  V v_s_24117 = args[0];
  V v_m_24116 = heff_env(self)[0];
  V v_x_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24118 = heff_tr(heff_apply(v_m_24116, 1, (V[]){v_s_24117}));
  switch (heff_tag_of(v_x2_24118)) {
  case TAG_MkPair: {
    V v_x_24119 = heff_field(v_x2_24118, 0);
    V v_s_24120 = heff_field(v_x2_24118, 1);
    V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
    V v_t_24121 = heff_strAppend(v_x_24115, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str30), heff_strAppend(v_x_24119, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str31))));
    V v_t_24122 = heff_tag_at(v_ru_24x2_24118_24MkPair, TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24122, v_s_24120});
  }
  default: return heff_nomatch(v_x2_24118);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam12(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_apply(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str32), heff_strAppend(v_x_24128, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str33)));
    V v_t_24131 = heff_tag_at(v_ru_24x2_24127_24MkPair, TAG_Cons, 2, (V[]){v_t_24130, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24131, v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam13(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_x_24132 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24135 = heff_tr(heff_apply(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_t_24138 = heff_strAppend(v_x_24132, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str34), heff_strAppend(v_x_24136, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str35))));
    V v_t_24139 = heff_tag_at(v_ru_24x2_24135_24MkPair, TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24139, v_s_24137});
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam14(V self, V *args) {
  V v_s_24143 = args[0];
  V v_m_24142 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_s_24140 = heff_env(self)[2];
  V v_dest_241 = heff_env(self)[3];
  V v_arms_24141 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24144 = heff_tr(heff_apply(v_m_24142, 1, (V[]){v_s_24143}));
  switch (heff_tag_of(v_x2_24144)) {
  case TAG_MkPair: {
    V v_x_24145 = heff_field(v_x2_24144, 0);
    V v_s_24146 = heff_field(v_x2_24144, 1);
    V v_ru_24x2_24144_24MkPair = heff_take_reuse_n(v_x2_24144, 3ULL, 2);
    V v_t_24147 = (g_heff_2eemitc_2eheldVar(heff_dup(v_ce_240), heff_dup(v_s_24140)));
    V v_t_24177;
    switch (heff_tag_of(v_s_24140)) {
    case TAG_EVar: {
      V v_x_24148 = heff_field(v_s_24140, 0);
      heff_take_n(v_s_24140, 1ULL, 1);
      v_t_24177 = ({ V a_0 = v_x_24148; V b_1 = heff_get(heff_dup(v_ce_240), LBL_borrowed); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_s_24140, 0ULL, 3);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_s_24140, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_s_24140, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_24140);
    }
    V v_t_24178 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2earmLines_24s1383923797x88700679_clo), 5, (V[]){v_ce_240, heff_dup(v_dest_241), heff_dup(v_x_24145), v_t_24147, v_t_24177}));
    V v_m_24179 = (g_heff_2eemitc_2etraverseC(v_t_24178, v_arms_24141));
    V v_x2_24180 = heff_tr(heff_apply(v_m_24179, 1, (V[]){v_s_24146}));
    switch (heff_tag_of(v_x2_24180)) {
    case TAG_MkPair: {
      V v_x_24181 = heff_field(v_x2_24180, 0);
      V v_s_24182 = heff_field(v_x2_24180, 1);
      V v_ru_24x2_24180_24MkPair = heff_take_reuse_n(v_x2_24180, 3ULL, 2);
      V v_t_24183 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str36), heff_strAppend(heff_dup(v_x_24145), ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str37)));
      V v_t_24184 = heff_tag_at(v_ru_24x2_24144_24MkPair, TAG_Cons, 2, (V[]){v_t_24183, NTAG(TAG_Nil)});
      V v_t_24185 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24181));
      V v_t_24186 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24185; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24185); r_; });
      V v_t_24188;
      switch (heff_tag_of(v_dest_241)) {
      case TAG_Ret: {
        v_t_24188 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str38), heff_strAppend(v_x_24145, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str39)));
        break;
      }
      case TAG_Asg: {
        heff_take_n(v_dest_241, 0ULL, 1);
        v_t_24188 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str40), heff_strAppend(v_x_24145, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str41)));
        break;
      }
      default: heff_nomatch(v_dest_241);
      }
      V v_t_24189 = heff_tag_at(v_ru_24x2_24180_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str42), NTAG(TAG_Nil)});
      V v_t_24190 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str43), v_t_24188), v_t_24189});
      V v_t_24191 = (g_prelude_2e_2b_2b(v_t_24186, v_t_24190));
      V v_x_24192 = (g_prelude_2e_2b_2b(v_t_24184, v_t_24191));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_24192, v_s_24182});
    }
    default: return heff_nomatch(v_x2_24180);
    }
  }
  default: return heff_nomatch(v_x2_24144);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam15(V self, V *args) {
  V v_s_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24196 = heff_tr(heff_apply(v_m_24194, 1, (V[]){v_s_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_s_24198 = heff_field(v_x2_24196, 1);
    V v_ru_24x2_24196_24MkPair = heff_take_reuse_n(v_x2_24196, 3ULL, 2);
    V v_t_24199 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str44), heff_strAppend(v_x_24197, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str45)));
    V v_t_24200 = heff_tag_at(v_ru_24x2_24196_24MkPair, TAG_Cons, 2, (V[]){v_t_24199, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24200, v_s_24198});
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam16(V self, V *args) {
  V v_s_24203 = args[0];
  V v_m_24202 = heff_env(self)[0];
  V v_x_24201 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24204 = heff_tr(heff_apply(v_m_24202, 1, (V[]){v_s_24203}));
  switch (heff_tag_of(v_x2_24204)) {
  case TAG_MkPair: {
    V v_x_24205 = heff_field(v_x2_24204, 0);
    V v_s_24206 = heff_field(v_x2_24204, 1);
    V v_ru_24x2_24204_24MkPair = heff_take_reuse_n(v_x2_24204, 3ULL, 2);
    V v_t_24207 = heff_strAppend(v_x_24201, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str46), heff_strAppend(v_x_24205, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str47))));
    V v_t_24208 = heff_tag_at(v_ru_24x2_24204_24MkPair, TAG_Cons, 2, (V[]){v_t_24207, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24208, v_s_24206});
  }
  default: return heff_nomatch(v_x2_24204);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam17(V self, V *args) {
  V v_s_24212 = args[0];
  V v_m_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24213 = heff_tr(heff_apply(v_m_24211, 1, (V[]){v_s_24212}));
  switch (heff_tag_of(v_x2_24213)) {
  case TAG_MkPair: {
    V v_x_24214 = heff_field(v_x2_24213, 0);
    V v_s_24215 = heff_field(v_x2_24213, 1);
    V v_ru_24x2_24213_24MkPair = heff_take_reuse_n(v_x2_24213, 3ULL, 2);
    V v_t_24216 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str48), heff_strAppend(v_x_24214, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str49)));
    V v_t_24217 = heff_tag_at(v_ru_24x2_24213_24MkPair, TAG_Cons, 2, (V[]){v_t_24216, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24217, v_s_24215});
  }
  default: return heff_nomatch(v_x2_24213);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam18(V self, V *args) {
  V v_s_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  V v_x_24218 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24221 = heff_tr(heff_apply(v_m_24219, 1, (V[]){v_s_24220}));
  switch (heff_tag_of(v_x2_24221)) {
  case TAG_MkPair: {
    V v_x_24222 = heff_field(v_x2_24221, 0);
    V v_s_24223 = heff_field(v_x2_24221, 1);
    V v_ru_24x2_24221_24MkPair = heff_take_reuse_n(v_x2_24221, 3ULL, 2);
    V v_t_24224 = heff_strAppend(v_x_24218, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str50), heff_strAppend(v_x_24222, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str51))));
    V v_t_24225 = heff_tag_at(v_ru_24x2_24221_24MkPair, TAG_Cons, 2, (V[]){v_t_24224, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24225, v_s_24223});
  }
  default: return heff_nomatch(v_x2_24221);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam19(V self, V *args) {
  V v_s_24232 = args[0];
  V v_m_24231 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_g_24226 = heff_env(self)[2];
  V v_as_24227 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24233 = heff_tr(heff_apply(v_m_24231, 1, (V[]){v_s_24232}));
  switch (heff_tag_of(v_x2_24233)) {
  case TAG_MkPair: {
    V v_x_24234 = heff_field(v_x2_24233, 0);
    V v_s_24235 = heff_field(v_x2_24233, 1);
    V v_ru_24x2_24233_24MkPair = heff_take_reuse_n(v_x2_24233, 3ULL, 2);
    V v_t_24236 = heff_get(heff_dup(v_ce_240), LBL_self);
    V v_t_24242;
    switch (heff_tag_of(v_t_24236)) {
    case TAG_Nothing: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_s_24237 = heff_field(v_t_24236, 0);
      heff_take_n(v_t_24236, 1ULL, 1);
      if (heff_strEq_c(heff_get(heff_dup(v_s_24237), LBL_key), heff_dup(v_g_24226))) {
        V v_t_24239 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get(v_s_24237, LBL_params); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_24240 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_24227));
        if (heff_intEq_c(v_t_24239, v_t_24240)) {
          v_t_24242 = (g_list_2eall_24s1175244903x419753027(v_x_24234));
        } else {
          v_t_24242 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_s_24237);
        v_t_24242 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_t_24236);
    }
    V v_x_24254;
    switch (heff_tag_of(v_t_24242)) {
    case TAG_True: {
      heff_drop(v_g_24226);
      heff_drop(v_as_24227);
      heff_drop_cell(v_ru_24x2_24233_24MkPair, 2);
      V v_t_24243 = (g_list_2emap_24s1363203549x1204645634(v_x_24234));
      v_x_24254 = (g_heff_2eemitc_2eagain(v_ce_240, v_t_24243));
      break;
    }
    case TAG_False: {
      V v_t_24244 = ({ V a_0 = v_ce_240; V a_1 = heff_dup(v_g_24226); V a_2 = v_as_24227; V r_ = (g_heff_2eemitc_2eagrees(a_0, a_1, a_2)); heff_drop(v_as_24227); r_; });
      V v_t_24245;
      switch (heff_tag_of(v_t_24244)) {
      case TAG_True: {
        v_t_24245 = (g_list_2eall_24s1175244903x419753027(v_x_24234));
        break;
      }
      case TAG_False: {
        v_t_24245 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24244);
      }
      switch (heff_tag_of(v_t_24245)) {
      case TAG_True: {
        V v_t_24246 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str52), (g_heff_2eemitc_2emangleW(v_g_24226, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str53))));
        V v_x2_24247 = (g_list_2emap_24s1363203549x1204645634(v_x_24234));
        V v_t_24250;
        switch (heff_tag_of(v_x2_24247)) {
        case TAG_Nil: {
          v_t_24250 = ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str54);
          break;
        }
        case TAG_Cons: {
          V v_x_24248 = heff_field(v_x2_24247, 0);
          V v_xs_24249 = heff_field(v_x2_24247, 1);
          heff_take_n(v_x2_24247, 3ULL, 2);
          v_t_24250 = ({ V a_0 = ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str55); V a_1 = v_x_24248; V a_2 = v_xs_24249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24249); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24247);
        }
        V v_t_24251 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str56), heff_strAppend(v_t_24246, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str57), heff_strAppend(v_t_24250, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str58)))));
        v_x_24254 = heff_tag_at(v_ru_24x2_24233_24MkPair, TAG_Cons, 2, (V[]){v_t_24251, NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        V v_t_24252 = ({ V a_0 = v_g_24226; V b_1 = NTAG(TAG_False); V a_2 = v_x_24234; V r_ = (g_heff_2eemitc_2ecallText(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        V v_t_24253 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str59), heff_strAppend(v_t_24252, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str60)));
        v_x_24254 = heff_tag_at(v_ru_24x2_24233_24MkPair, TAG_Cons, 2, (V[]){v_t_24253, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_24245);
      }
      break;
    }
    default: heff_nomatch(v_t_24242);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24254, v_s_24235});
  }
  default: return heff_nomatch(v_x2_24233);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam20(V self, V *args) {
  V v_s_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  V v_x_24255 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24258 = heff_tr(heff_apply(v_m_24256, 1, (V[]){v_s_24257}));
  switch (heff_tag_of(v_x2_24258)) {
  case TAG_MkPair: {
    V v_x_24259 = heff_field(v_x2_24258, 0);
    V v_s_24260 = heff_field(v_x2_24258, 1);
    V v_ru_24x2_24258_24MkPair = heff_take_reuse_n(v_x2_24258, 3ULL, 2);
    V v_t_24261 = heff_strAppend(v_x_24255, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str61), heff_strAppend(v_x_24259, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str62))));
    V v_t_24262 = heff_tag_at(v_ru_24x2_24258_24MkPair, TAG_Cons, 2, (V[]){v_t_24261, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24262, v_s_24260});
  }
  default: return heff_nomatch(v_x2_24258);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam21(V self, V *args) {
  V v_s_24265 = args[0];
  V v_m_24264 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24266 = heff_tr(heff_apply(v_m_24264, 1, (V[]){v_s_24265}));
  switch (heff_tag_of(v_x2_24266)) {
  case TAG_MkPair: {
    V v_x_24267 = heff_field(v_x2_24266, 0);
    V v_s_24268 = heff_field(v_x2_24266, 1);
    V v_ru_24x2_24266_24MkPair = heff_take_reuse_n(v_x2_24266, 3ULL, 2);
    V v_t_24269 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str63), heff_strAppend(v_x_24267, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str64)));
    V v_t_24270 = heff_tag_at(v_ru_24x2_24266_24MkPair, TAG_Cons, 2, (V[]){v_t_24269, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24270, v_s_24268});
  }
  default: return heff_nomatch(v_x2_24266);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam22(V self, V *args) {
  V v_s_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_x_24271 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24274 = heff_tr(heff_apply(v_m_24272, 1, (V[]){v_s_24273}));
  switch (heff_tag_of(v_x2_24274)) {
  case TAG_MkPair: {
    V v_x_24275 = heff_field(v_x2_24274, 0);
    V v_s_24276 = heff_field(v_x2_24274, 1);
    V v_ru_24x2_24274_24MkPair = heff_take_reuse_n(v_x2_24274, 3ULL, 2);
    V v_t_24277 = heff_strAppend(v_x_24271, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str65), heff_strAppend(v_x_24275, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str66))));
    V v_t_24278 = heff_tag_at(v_ru_24x2_24274_24MkPair, TAG_Cons, 2, (V[]){v_t_24277, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24278, v_s_24276});
  }
  default: return heff_nomatch(v_x2_24274);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam23(V self, V *args) {
  V v_s_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24282 = heff_tr(heff_apply(v_m_24280, 1, (V[]){v_s_24281}));
  switch (heff_tag_of(v_x2_24282)) {
  case TAG_MkPair: {
    V v_x_24283 = heff_field(v_x2_24282, 0);
    V v_s_24284 = heff_field(v_x2_24282, 1);
    V v_ru_24x2_24282_24MkPair = heff_take_reuse_n(v_x2_24282, 3ULL, 2);
    V v_t_24285 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str67), heff_strAppend(v_x_24283, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str68)));
    V v_t_24286 = heff_tag_at(v_ru_24x2_24282_24MkPair, TAG_Cons, 2, (V[]){v_t_24285, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24286, v_s_24284});
  }
  default: return heff_nomatch(v_x2_24282);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam24(V self, V *args) {
  V v_s_24289 = args[0];
  V v_m_24288 = heff_env(self)[0];
  V v_x_24287 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24290 = heff_tr(heff_apply(v_m_24288, 1, (V[]){v_s_24289}));
  switch (heff_tag_of(v_x2_24290)) {
  case TAG_MkPair: {
    V v_x_24291 = heff_field(v_x2_24290, 0);
    V v_s_24292 = heff_field(v_x2_24290, 1);
    V v_ru_24x2_24290_24MkPair = heff_take_reuse_n(v_x2_24290, 3ULL, 2);
    V v_t_24293 = heff_strAppend(v_x_24287, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str69), heff_strAppend(v_x_24291, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str70))));
    V v_t_24294 = heff_tag_at(v_ru_24x2_24290_24MkPair, TAG_Cons, 2, (V[]){v_t_24293, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24294, v_s_24292});
  }
  default: return heff_nomatch(v_x2_24290);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam25(V self, V *args) {
  V v_s_24297 = args[0];
  V v_m_24296 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24298 = heff_tr(heff_apply(v_m_24296, 1, (V[]){v_s_24297}));
  switch (heff_tag_of(v_x2_24298)) {
  case TAG_MkPair: {
    V v_x_24299 = heff_field(v_x2_24298, 0);
    V v_s_24300 = heff_field(v_x2_24298, 1);
    V v_ru_24x2_24298_24MkPair = heff_take_reuse_n(v_x2_24298, 3ULL, 2);
    V v_t_24301 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str71), heff_strAppend(v_x_24299, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str72)));
    V v_t_24302 = heff_tag_at(v_ru_24x2_24298_24MkPair, TAG_Cons, 2, (V[]){v_t_24301, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24302, v_s_24300});
  }
  default: return heff_nomatch(v_x2_24298);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam26(V self, V *args) {
  V v_s_24305 = args[0];
  V v_m_24304 = heff_env(self)[0];
  V v_x_24303 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24306 = heff_tr(heff_apply(v_m_24304, 1, (V[]){v_s_24305}));
  switch (heff_tag_of(v_x2_24306)) {
  case TAG_MkPair: {
    V v_x_24307 = heff_field(v_x2_24306, 0);
    V v_s_24308 = heff_field(v_x2_24306, 1);
    V v_ru_24x2_24306_24MkPair = heff_take_reuse_n(v_x2_24306, 3ULL, 2);
    V v_t_24309 = heff_strAppend(v_x_24303, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str73), heff_strAppend(v_x_24307, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str74))));
    V v_t_24310 = heff_tag_at(v_ru_24x2_24306_24MkPair, TAG_Cons, 2, (V[]){v_t_24309, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24310, v_s_24308});
  }
  default: return heff_nomatch(v_x2_24306);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam27(V self, V *args) {
  V v_s_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24315 = heff_tr(heff_apply(v_m_24313, 1, (V[]){v_s_24314}));
  switch (heff_tag_of(v_x2_24315)) {
  case TAG_MkPair: {
    V v_x_24316 = heff_field(v_x2_24315, 0);
    V v_s_24317 = heff_field(v_x2_24315, 1);
    V v_ru_24x2_24315_24MkPair = heff_take_reuse_n(v_x2_24315, 3ULL, 2);
    V v_t_24318 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str75), heff_strAppend(v_x_24316, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str76)));
    V v_t_24319 = heff_tag_at(v_ru_24x2_24315_24MkPair, TAG_Cons, 2, (V[]){v_t_24318, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24319, v_s_24317});
  }
  default: return heff_nomatch(v_x2_24315);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam28(V self, V *args) {
  V v_s_24322 = args[0];
  V v_m_24321 = heff_env(self)[0];
  V v_x_24320 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24323 = heff_tr(heff_apply(v_m_24321, 1, (V[]){v_s_24322}));
  switch (heff_tag_of(v_x2_24323)) {
  case TAG_MkPair: {
    V v_x_24324 = heff_field(v_x2_24323, 0);
    V v_s_24325 = heff_field(v_x2_24323, 1);
    V v_ru_24x2_24323_24MkPair = heff_take_reuse_n(v_x2_24323, 3ULL, 2);
    V v_t_24326 = heff_strAppend(v_x_24320, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str77), heff_strAppend(v_x_24324, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str78))));
    V v_t_24327 = heff_tag_at(v_ru_24x2_24323_24MkPair, TAG_Cons, 2, (V[]){v_t_24326, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24327, v_s_24325});
  }
  default: return heff_nomatch(v_x2_24323);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam29(V self, V *args) {
  V v_s_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24331 = heff_tr(heff_apply(v_m_24329, 1, (V[]){v_s_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_s_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_t_24334 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str79), heff_strAppend(v_x_24332, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str80)));
    V v_t_24335 = heff_tag_at(v_ru_24x2_24331_24MkPair, TAG_Cons, 2, (V[]){v_t_24334, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24335, v_s_24333});
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam30(V self, V *args) {
  V v_s_24338 = args[0];
  V v_m_24337 = heff_env(self)[0];
  V v_x_24336 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24339 = heff_tr(heff_apply(v_m_24337, 1, (V[]){v_s_24338}));
  switch (heff_tag_of(v_x2_24339)) {
  case TAG_MkPair: {
    V v_x_24340 = heff_field(v_x2_24339, 0);
    V v_s_24341 = heff_field(v_x2_24339, 1);
    V v_ru_24x2_24339_24MkPair = heff_take_reuse_n(v_x2_24339, 3ULL, 2);
    V v_t_24342 = heff_strAppend(v_x_24336, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str81), heff_strAppend(v_x_24340, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str82))));
    V v_t_24343 = heff_tag_at(v_ru_24x2_24339_24MkPair, TAG_Cons, 2, (V[]){v_t_24342, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24343, v_s_24341});
  }
  default: return heff_nomatch(v_x2_24339);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam31(V self, V *args) {
  V v_s_24345 = args[0];
  V v_m_24344 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24346 = heff_tr(heff_apply(v_m_24344, 1, (V[]){v_s_24345}));
  switch (heff_tag_of(v_x2_24346)) {
  case TAG_MkPair: {
    V v_x_24347 = heff_field(v_x2_24346, 0);
    V v_s_24348 = heff_field(v_x2_24346, 1);
    V v_ru_24x2_24346_24MkPair = heff_take_reuse_n(v_x2_24346, 3ULL, 2);
    V v_t_24349 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str83), heff_strAppend(v_x_24347, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str84)));
    V v_t_24350 = heff_tag_at(v_ru_24x2_24346_24MkPair, TAG_Cons, 2, (V[]){v_t_24349, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24350, v_s_24348});
  }
  default: return heff_nomatch(v_x2_24346);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam32(V self, V *args) {
  V v_s_24353 = args[0];
  V v_m_24352 = heff_env(self)[0];
  V v_x_24351 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24354 = heff_tr(heff_apply(v_m_24352, 1, (V[]){v_s_24353}));
  switch (heff_tag_of(v_x2_24354)) {
  case TAG_MkPair: {
    V v_x_24355 = heff_field(v_x2_24354, 0);
    V v_s_24356 = heff_field(v_x2_24354, 1);
    V v_ru_24x2_24354_24MkPair = heff_take_reuse_n(v_x2_24354, 3ULL, 2);
    V v_t_24357 = heff_strAppend(v_x_24351, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str85), heff_strAppend(v_x_24355, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str86))));
    V v_t_24358 = heff_tag_at(v_ru_24x2_24354_24MkPair, TAG_Cons, 2, (V[]){v_t_24357, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24358, v_s_24356});
  }
  default: return heff_nomatch(v_x2_24354);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam33(V self, V *args) {
  V v_s_24362 = args[0];
  V v_m_24361 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24363 = heff_tr(heff_apply(v_m_24361, 1, (V[]){v_s_24362}));
  switch (heff_tag_of(v_x2_24363)) {
  case TAG_MkPair: {
    V v_x_24364 = heff_field(v_x2_24363, 0);
    V v_s_24365 = heff_field(v_x2_24363, 1);
    V v_ru_24x2_24363_24MkPair = heff_take_reuse_n(v_x2_24363, 3ULL, 2);
    V v_t_24366 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str87), heff_strAppend(v_x_24364, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str88)));
    V v_t_24367 = heff_tag_at(v_ru_24x2_24363_24MkPair, TAG_Cons, 2, (V[]){v_t_24366, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24367, v_s_24365});
  }
  default: return heff_nomatch(v_x2_24363);
  }
}
V g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_lam34(V self, V *args) {
  V v_s_24370 = args[0];
  V v_m_24369 = heff_env(self)[0];
  V v_x_24368 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24371 = heff_tr(heff_apply(v_m_24369, 1, (V[]){v_s_24370}));
  switch (heff_tag_of(v_x2_24371)) {
  case TAG_MkPair: {
    V v_x_24372 = heff_field(v_x2_24371, 0);
    V v_s_24373 = heff_field(v_x2_24371, 1);
    V v_ru_24x2_24371_24MkPair = heff_take_reuse_n(v_x2_24371, 3ULL, 2);
    V v_t_24374 = heff_strAppend(v_x_24368, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str89), heff_strAppend(v_x_24372, ((V)&g_heff_2eemitc_2estmtsF_24s1708163051x1000559381_str90))));
    V v_t_24375 = heff_tag_at(v_ru_24x2_24371_24MkPair, TAG_Cons, 2, (V[]){v_t_24374, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24375, v_s_24373});
  }
  default: return heff_nomatch(v_x2_24371);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2efunDef_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {118, 111, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str13 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2efunDef_str14 = {{0x80000000u, K_STR, 0}, 21, 21, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2efunDef_str19 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2eemitc_2efunDef_str20 = {{0x80000000u, K_STR, 0}, 33, 33, {95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2efunDef_str21 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 101, 110, 116, 114, 121, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2efunDef_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 48, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2efunDef_str25 = {{0x80000000u, K_STR, 0}, 4, 4, {118, 111, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str26 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str27 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str30 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str31 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2efunDef_str33 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2efunDef_str34 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 111, 112, 58, 32, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2efunDef_str36 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str37 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str38 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str39 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str40 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str42 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str44 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2efunDef_str45 = {{0x80000000u, K_STR, 0}, 22, 22, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2efunDef_str47 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 32, 40, 118, 111, 105, 100, 41, 115, 101, 108, 102, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2eemitc_2efunDef_lam0(V self, V *args);
V g_heff_2eemitc_2efunDef_lam1(V self, V *args);
V g_heff_2eemitc_2efunDef_lam3(V self, V *args);
V g_heff_2eemitc_2efunDef_lam2(V self, V *args);
Clo g_heff_2eemitc_2efunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efunDef_entry, 4, 0};

V g_heff_2eemitc_2efunDef(V v_ce_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_owned_247 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_246; V a_2 = heff_dup(v_xs_242); V r_ = (g_heff_2eemitc_2eparamsAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_246); r_; });
  V v_wanted_248 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_243)));
  V v_owned_2410 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2efunDef_lam0, 1, 1, (V[]){v_wanted_248}), v_owned_247));
  V v_x2_2411 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_bi_2413;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    v_bi_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    v_bi_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
  V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2415));
  V v_t_2421 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2efunDef_lam1, 1, 1, (V[]){v_bi_2413}), v_t_2416));
  V v_bs_2422 = (g_list_2emap_24s1937570095x2110149801(v_t_2421));
  V v_t_2423 = heff_rec(2, shape_key__params, (V[]){heff_get(heff_dup(v_d_241), LBL_key), heff_dup(v_xs_242)});
  V v_ce_2424 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_tag(TAG_Just, 1, (V[]){v_t_2423}), MK_INT(0LL), heff_get(heff_dup(v_ce_240), LBL_owned), heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
  V v_ce_2425 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_2424), LBL_tags), heff_get(heff_dup(v_ce_2424), LBL_lbls), heff_get(heff_dup(v_ce_2424), LBL_funs), heff_get(heff_dup(v_ce_2424), LBL_bounce), heff_get(heff_dup(v_ce_2424), LBL_self), heff_get(heff_dup(v_ce_2424), LBL_lam), heff_get(heff_dup(v_ce_2424), LBL_owned), heff_get(heff_dup(v_ce_2424), LBL_after), v_bs_2422, heff_get(heff_dup(v_ce_2424), LBL_bor), heff_get(v_ce_2424, LBL_known)});
  V v_ce_2426 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_2425), LBL_tags), heff_get(heff_dup(v_ce_2425), LBL_lbls), heff_get(heff_dup(v_ce_2425), LBL_funs), heff_get(heff_dup(v_ce_2425), LBL_bounce), heff_get(heff_dup(v_ce_2425), LBL_self), heff_get(heff_dup(v_ce_2425), LBL_lam), v_owned_2410, NTAG(TAG_Nil), heff_get(heff_dup(v_ce_2425), LBL_borrowed), heff_get(heff_dup(v_ce_2425), LBL_bor), heff_get(v_ce_2425, LBL_known)});
  V v_m_2427 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_2426, NTAG(TAG_Ret), heff_dup(v_b_243)));
  return heff_clo(g_heff_2eemitc_2efunDef_lam2, 1, 5, (V[]){v_m_2427, v_d_241, v_xs_242, v_ce_240, v_b_243});
}
V g_heff_2eemitc_2efunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2efunDef(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemitc_2efunDef_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_248); r_; });
}
V g_heff_2eemitc_2efunDef_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_bi_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  return ({ V a_0 = v_t_2420; V a_1 = v_bi_2413; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_2413); r_; });
}
V g_heff_2eemitc_2efunDef_lam3(V self, V *args) {
  V v_v_2463 = args[0];
  V v_wanted_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = ({ V a_0 = v_v_2463; V a_1 = v_wanted_2462; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2462); r_; });
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2eemitc_2efunDef_lam2(V self, V *args) {
  V v_s_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  V v_ce_240 = heff_env(self)[3];
  V v_b_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2429 = heff_tr(heff_apply(v_m_2427, 1, (V[]){v_s_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_s_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str1))));
    V v_t_2438;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2eemitc_2efunDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x2_2435 = (g_list_2emap_24s231476130x1974273190(((V)&g_heff_2eemitc_2efunDef_str3), ((V)&g_heff_2eemitc_2efunDef_str4), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str5), heff_dup(v_xs_242)));
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2eemitc_2efunDef_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2eemitc_2efunDef_str7); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str8), heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str9), heff_strAppend(v_t_2438, ((V)&g_heff_2eemitc_2efunDef_str10)))));
    V v_t_2440 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str11), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str12))));
    V v_t_2441 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str13), heff_strAppend(v_t_2440, ((V)&g_heff_2eemitc_2efunDef_str14)));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str15), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str16))));
    V v_t_2443 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str17), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str18))));
    V v_t_2444 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str19), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str20), heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str21), heff_strAppend(heff_intShow(v_t_2444), ((V)&g_heff_2eemitc_2efunDef_str22)))))));
    V v_t_2446 = heff_tag_at(v_ru_24x2_2429_24MkPair, TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){v_t_2439, heff_tag(TAG_Cons, 2, (V[]){v_t_2441, v_t_2446})});
    V v_t_2448 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str23), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str24))));
    V v_t_2454;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2eemitc_2efunDef_str25);
      break;
    }
    case TAG_Cons: {
      V v_x2_2451 = (g_list_2emap_24s231476130x1974273190(((V)&g_heff_2eemitc_2efunDef_str26), ((V)&g_heff_2eemitc_2efunDef_str27), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str28), heff_dup(v_xs_242)));
      switch (heff_tag_of(v_x2_2451)) {
      case TAG_Nil: {
        v_t_2454 = ((V)&g_heff_2eemitc_2efunDef_str29);
        break;
      }
      case TAG_Cons: {
        V v_x_2452 = heff_field(v_x2_2451, 0);
        V v_xs_2453 = heff_field(v_x2_2451, 1);
        heff_take_n(v_x2_2451, 3ULL, 2);
        v_t_2454 = ({ V a_0 = ((V)&g_heff_2eemitc_2efunDef_str30); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2451);
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    V v_t_2455 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str31), heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str32), heff_strAppend(v_t_2454, ((V)&g_heff_2eemitc_2efunDef_str33)))));
    V v_t_2456 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str34), NTAG(TAG_Nil)});
    V v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str35), heff_tag(TAG_Cons, 2, (V[]){v_t_2455, v_t_2456})});
    V v_x2_2458 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2460;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nothing: {
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      heff_take_n(v_x2_2458, 1ULL, 1);
      v_t_2460 = v_x_2459;
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    V v_owned_2461 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2460; V a_2 = heff_dup(v_xs_242); V r_ = (g_heff_2eemitc_2eparamsAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2460); r_; });
    V v_wanted_2462 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_243));
    V v_xs_2465 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2efunDef_lam3, 1, 1, (V[]){v_wanted_2462}), v_owned_2461));
    V v_t_2466 = (g_list_2emap_24s455042168x142217368(((V)&g_heff_2eemitc_2efunDef_str36), ((V)&g_heff_2eemitc_2efunDef_str37), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str38), ((V)&g_heff_2eemitc_2efunDef_str39), v_xs_2465));
    V v_t_2467 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2efunDef_str40), v_t_2466));
    V v_t_2468 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2efunDef_str41), v_x_2430));
    V v_t_2469 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str42), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str43))));
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str44), heff_strAppend(v_t_2469, ((V)&g_heff_2eemitc_2efunDef_str45)));
    V v_x2_2471 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(v_ce_240, LBL_bor); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2473;
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_Nothing: {
      v_t_2473 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      heff_take_n(v_x2_2471, 1ULL, 1);
      v_t_2473 = v_x_2472;
      break;
    }
    default: heff_nomatch(v_x2_2471);
    }
    V v_t_2474 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
    V v_t_2475 = (g_heff_2eemitc_2eentryCall(heff_get(v_d_241, LBL_key), v_t_2473, v_t_2474));
    V v_t_2476 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str46), NTAG(TAG_Nil)});
    V v_t_2477 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str47), heff_tag(TAG_Cons, 2, (V[]){v_t_2475, v_t_2476})});
    V v_t_2478 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str48), heff_tag(TAG_Cons, 2, (V[]){v_t_2470, v_t_2477})});
    V v_t_2479 = (g_prelude_2e_2b_2b(v_t_2468, v_t_2478));
    V v_t_2480 = (g_prelude_2e_2b_2b(v_t_2467, v_t_2479));
    V v_t_2481 = (g_prelude_2e_2b_2b(v_t_2457, v_t_2480));
    V v_x_2482 = heff_rec(2, shape_protos__code, (V[]){v_t_2447, v_t_2481});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2482, v_s_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2evalDef_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalDef_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2evalDef_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 97, 116, 105, 99, 32, 105, 110, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalDef_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 115, 116, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str14 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2evalDef_str15 = {{0x80000000u, K_STR, 0}, 13, 13, {95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str19 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2evalDef_str20 = {{0x80000000u, K_STR, 0}, 12, 12, {95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalDef_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2evalDef_str26 = {{0x80000000u, K_STR, 0}, 17, 17, {95, 115, 116, 32, 61, 61, 32, 50, 41, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalDef_str27 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str28 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalDef_str30 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eemitc_2evalDef_str31 = {{0x80000000u, K_STR, 0}, 41, 41, {95, 115, 116, 32, 61, 61, 32, 49, 41, 32, 104, 101, 102, 102, 95, 102, 97, 105, 108, 40, 34, 100, 101, 102, 105, 110, 101, 100, 32, 98, 121, 32, 105, 116, 115, 101, 108, 102, 34, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str32 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str34 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2evalDef_str35 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 115, 116, 32, 61, 32, 49, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str38 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str39 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str40 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemitc_2evalDef_str41 = {{0x80000000u, K_STR, 0}, 15, 15, {95, 118, 97, 108, 32, 61, 32, 104, 101, 102, 102, 95, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str42 = {{0x80000000u, K_STR, 0}, 9, 9, {95, 105, 110, 105, 116, 40, 41, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str43 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str44 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str45 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2evalDef_str46 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 115, 116, 32, 61, 32, 50, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str47 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str48 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str49 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalDef_str50 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemitc_2evalDef_lam0(V self, V *args);
Clo g_heff_2eemitc_2evalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evalDef_entry, 2, 0};

V g_heff_2eemitc_2evalDef(V v_ce_240, V v_d_241) {
top: ;
  V v_ce_242 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), NTAG(TAG_Nothing), MK_INT(0LL), heff_get(heff_dup(v_ce_240), LBL_owned), heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(v_ce_240, LBL_known)});
  V v_ce_243 = heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(heff_dup(v_ce_242), LBL_bor), heff_get(v_ce_242, LBL_known)});
  V v_m_244 = (g_heff_2eemitc_2estmtsF_24s1708163051x1000559381(v_ce_243, NTAG(TAG_Ret), heff_get(heff_dup(v_d_241), LBL_body)));
  return heff_clo(g_heff_2eemitc_2evalDef_lam0, 1, 2, (V[]){v_m_244, v_d_241});
}
V g_heff_2eemitc_2evalDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2evalDef(a[0], a[1]);
}
V g_heff_2eemitc_2evalDef_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str1))));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str2), heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2evalDef_str3)));
    V v_t_2411 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str4), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str5))));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2eemitc_2evalDef_str7)));
    V v_t_2414 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str8), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str9))));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str10), heff_strAppend(v_t_2414, ((V)&g_heff_2eemitc_2evalDef_str11)));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str12), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str13))));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str14), heff_strAppend(v_t_2416, ((V)&g_heff_2eemitc_2evalDef_str15)));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_t_2418})});
    V v_t_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2evalDef_str16), v_x_247));
    V v_t_2421 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str17), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str18))));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str19), heff_strAppend(v_t_2421, ((V)&g_heff_2eemitc_2evalDef_str20)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str21), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str22))));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str23), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str24))));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str25), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str26), heff_strAppend(v_t_2424, ((V)&g_heff_2eemitc_2evalDef_str27)))));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str28), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str29))));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str30), heff_strAppend(v_t_2426, ((V)&g_heff_2eemitc_2evalDef_str31)));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str32), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str33))));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str34), heff_strAppend(v_t_2428, ((V)&g_heff_2eemitc_2evalDef_str35)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str36), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str37))));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str38), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str39))));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str40), heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str41), heff_strAppend(v_t_2431, ((V)&g_heff_2eemitc_2evalDef_str42)))));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str43), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str44))));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str45), heff_strAppend(v_t_2433, ((V)&g_heff_2eemitc_2evalDef_str46)));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str47), (g_heff_2eemitc_2emangleW(heff_get(v_d_241, LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str48))));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str49), heff_strAppend(v_t_2435, ((V)&g_heff_2eemitc_2evalDef_str50)));
    V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2evalDef_str51), NTAG(TAG_Nil)});
    V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_t_2434, heff_tag(TAG_Cons, 2, (V[]){v_t_2436, v_t_2437})});
    V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, heff_tag(TAG_Cons, 2, (V[]){v_t_2432, v_t_2438})});
    V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, heff_tag(TAG_Cons, 2, (V[]){v_t_2427, v_t_2439})});
    V v_t_2441 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2evalDef_str52), heff_tag(TAG_Cons, 2, (V[]){v_t_2422, v_t_2440})});
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2evalDef_str53), v_t_2419}), v_t_2442));
    V v_x_2444 = heff_rec(2, shape_protos__code, (V[]){v_t_2411, v_t_2443});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2444, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
Clo g_heff_2eemitc_2edefC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edefC_entry, 2, 0};

V g_heff_2eemitc_2edefC(V v_ce_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    return (g_heff_2eemitc_2efunDef(v_ce_240, v_d_241, v_xs_245, v_b_246));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2edefC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edefC(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eplusDone_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[120]; } g_heff_2eemitc_2eplusDone_str1 = {{0x80000000u, K_STR, 0}, 120, 120, {40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 105, 110, 116, 32, 108, 32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 111, 102, 40, 112, 41, 32, 61, 61, 32, 84, 65, 71, 95, 73, 110, 76, 59, 32, 86, 32, 113, 32, 61, 32, 104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40, 112, 44, 32, 48, 41, 41, 59, 32, 104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 112, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 108, 32, 63, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eplusDone_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {40, 113, 44, 32, 107, 41, 32, 58, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eplusDone_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 113, 44, 32, 107, 41, 59, 32, 125}};
Clo g_heff_2eemitc_2eplusDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eplusDone_entry, 4, 0};

V g_heff_2eemitc_2eplusDone(V v_n_240, V v_la_241, V v_na_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_lb_244 = heff_field(v_x4_243, 0);
    V v_nb_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_intShow(heff_intAdd(heff_dup(v_n_240), MK_INT(1LL)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2eplusDone_str0), heff_strAppend(heff_intShow(v_n_240), heff_strAppend(((V)&g_heff_2eemitc_2eplusDone_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2eplusDone_str2), heff_strAppend(heff_intShow(v_na_242), ((V)&g_heff_2eemitc_2eplusDone_str3)))))));
    V v_t_248 = heff_tag_at(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2e_2b_2b(v_lb_244, v_t_248));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_la_241, v_t_249));
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_nb_245});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eemitc_2eplusDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eplusDone(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eperformNodes_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eperformNodes_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2eemitc_2eperformNodes_str2 = {{0x80000000u, K_STR, 0}, 34, 34, {40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 112, 114, 111, 118, 105, 100, 101, 114, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eperformNodes_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 112, 44, 32, 107, 41, 59, 32, 125}};
Clo g_heff_2eemitc_2eperformNodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eperformNodes_entry, 2, 0};

V g_heff_2eemitc_2eperformNodes(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2eemitc_2eperformNodes_str0), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_243; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2eperformNodes_str1), heff_strAppend(heff_intShow(heff_dup(v_n_241)), heff_strAppend(((V)&g_heff_2eemitc_2eperformNodes_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eemitc_2eperformNodes_str3)))));
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_n_241, MK_INT(1LL))});
  }
  case TAG_Plus: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_x4_249 = (g_heff_2eemitc_2eperformNodes(v_a_247, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    switch (heff_tag_of(v_x4_249)) {
    case TAG_MkPair: {
      V v_la_2410 = heff_field(v_x4_249, 0);
      V v_na_2411 = heff_field(v_x4_249, 1);
      heff_take_n(v_x4_249, 3ULL, 2);
      V v_t_2412 = (g_heff_2eemitc_2eperformNodes(v_b_248, heff_dup(v_na_2411)));
      return (g_heff_2eemitc_2eplusDone(v_n_241, v_la_2410, v_na_2411, v_t_2412));
    }
    default: return heff_nomatch(v_x4_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eperformNodes_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eperformNodes(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eprimCloDef_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprimCloDef_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprimCloDef_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eprimCloDef_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2eprimCloDef_str4 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 116, 97, 116, 105, 99, 32, 86, 32, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2eprimCloDef_str5 = {{0x80000000u, K_STR, 0}, 42, 42, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 32, 123, 32, 40, 118, 111, 105, 100, 41, 115, 101, 108, 102, 59, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eprimCloDef_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprimCloDef_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eprimCloDef_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2eprimCloDef_str9 = {{0x80000000u, K_STR, 0}, 16, 16, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eemitc_2eprimCloDef_str10 = {{0x80000000u, K_STR, 0}, 38, 38, {95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2eprimCloDef_str11 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 101, 110, 116, 114, 121, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eprimCloDef_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 48, 125, 59}};
Clo g_heff_2eemitc_2eprimCloDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprimCloDef_entry, 1, 0};

V g_heff_2eemitc_2eprimCloDef(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2eprims_2eallPrims_get()); V r_ = (g_heff_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_243 = (g_list_2erange(MK_INT(0LL), heff_intSub(heff_dup(v_n_242), MK_INT(1LL))));
    V v_x2_244 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2eemitc_2eprimCloDef_str0), ((V)&g_heff_2eemitc_2eprimCloDef_str1), v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2eemitc_2eprimCloDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2eemitc_2eprimCloDef_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str4), heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str5), heff_strAppend(heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str6), heff_dup(v_p_240)), heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str7), heff_strAppend(v_t_247, ((V)&g_heff_2eemitc_2eprimCloDef_str8)))))));
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str9), heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str10), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str11), heff_strAppend(heff_intShow(v_n_242), ((V)&g_heff_2eemitc_2eprimCloDef_str12)))))));
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2410});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2eprimCloDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprimCloDef(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eshapeDef_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {95, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eshapeDef_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eshapeDef_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eshapeDef_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eshapeDef_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 117, 105, 110, 116, 51, 50, 95, 116, 32, 115, 104, 97, 112, 101, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eshapeDef_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eshapeDef_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
Clo g_heff_2eemitc_2eshapeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eshapeDef_entry, 1, 0};

V g_heff_2eemitc_2eshapeDef(V v_key_240) {
top: ;
  V v_t_241 = (g_prelude_2esplitFrom(((V)&g_heff_2eemitc_2eshapeDef_str0), heff_dup(v_key_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_242 = (g_list_2efilter_24s2056490818x625949248(MK_INT(0LL), v_t_241));
  V v_x2_243 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2eemitc_2eshapeDef_str1), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2eemitc_2eshapeDef_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2eemitc_2eshapeDef_str3); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2eshapeDef_str4), heff_strAppend(v_key_240, heff_strAppend(((V)&g_heff_2eemitc_2eshapeDef_str5), heff_strAppend(v_t_246, ((V)&g_heff_2eemitc_2eshapeDef_str6)))));
}
V g_heff_2eemitc_2eshapeDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eshapeDef(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edefOwn_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edefOwn_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemitc_2edefOwn_lam0(V self, V *args);
V g_heff_2eemitc_2edefOwn_lam1(V self, V *args);
Clo g_heff_2eemitc_2edefOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edefOwn_entry, 2, 0};

V g_heff_2eemitc_2edefOwn(V v_ce_240, V v_d_241) {
top: ;
  V v_o_242 = heff_strAppend(((V)&g_heff_2eemitc_2edefOwn_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edefOwn_str1))));
  V v_m_245 = heff_clo(g_heff_2eemitc_2edefOwn_lam0, 1, 1, (V[]){v_o_242});
  return heff_clo(g_heff_2eemitc_2edefOwn_lam1, 1, 3, (V[]){v_m_245, v_d_241, v_ce_240});
}
V g_heff_2eemitc_2edefOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edefOwn(a[0], a[1]);
}
V g_heff_2eemitc_2edefOwn_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_242, MK_INT(0LL), heff_get(heff_dup(v_s_243), LBL_lams), heff_get(heff_dup(v_s_243), LBL_protos), MK_INT(0LL), heff_get(heff_dup(v_s_243), LBL_strs), heff_get(heff_dup(v_s_243), LBL_shapes), heff_get(v_s_243, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_244});
}
V g_heff_2eemitc_2edefOwn_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_s_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 2ULL, 2);
    V v_x1_2410 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), MK_INT(0LL), heff_get(heff_dup(v_d_241), LBL_body)));
    V v_body_2413;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 2);
      v_body_2413 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    V v_t_2414 = heff_rec(3, shape_key__name__body, (V[]){heff_get(heff_dup(v_d_241), LBL_key), heff_get(v_d_241, LBL_name), v_body_2413});
    V v_t_2415 = (g_heff_2eemitc_2edefC(v_ce_240, v_t_2414));
    V f_ = v_t_2415;
    args[0] = v_s_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eemptyCS_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};

static V g_heff_2eemitc_2eemptyCS_val;
static int g_heff_2eemitc_2eemptyCS_st;
static V g_heff_2eemitc_2eemptyCS_init(void) {
  return heff_rec(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){((V)&g_heff_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eemitc_2eemptyCS_get(void) {
  if (g_heff_2eemitc_2eemptyCS_st == 2) return g_heff_2eemitc_2eemptyCS_val;
  if (g_heff_2eemitc_2eemptyCS_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2eemptyCS_st = 1;
  g_heff_2eemitc_2eemptyCS_val = heff_tr(g_heff_2eemitc_2eemptyCS_init());
  g_heff_2eemitc_2eemptyCS_st = 2;
  return g_heff_2eemitc_2eemptyCS_val;
}
Clo g_heff_2eemitc_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2earityOne_entry, 2, 0};

V g_heff_2eemitc_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_map_2einsert_24s1341440536x470972936(heff_get(v_d_241, LBL_key), v_t_247, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2earityOne(a[0], a[1]);
}
Clo g_heff_2eemitc_2eonceInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eonceInOrder_entry, 2, 0};

V g_heff_2eemitc_2eonceInOrder(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_seen_240));
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eemitc_2eonceInOrder(v_t_245, v_xs_243))});
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eonceInOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eonceInOrder(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enamesTable_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2enamesTable_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {44, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2enamesTable_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enamesTable_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2enamesTable_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2enamesTable_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 48, 44, 32, 78, 85, 76, 76, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enamesTable_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2enamesTable_str7 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 72, 101, 102, 102, 78, 97, 109, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2enamesTable_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2enamesTable_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
Clo g_heff_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s1378753456x1787722089(((V)&g_heff_2eemitc_2enamesTable_str0), ((V)&g_heff_2eemitc_2enamesTable_str1), ((V)&g_heff_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_map_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2eemitc_2enamesTable_str5);
  } else {
    v_t_249 = ((V)&g_heff_2eemitc_2enamesTable_str6);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2enamesTable_str7), heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2eemitc_2enamesTable_str8), heff_strAppend(v_t_246, heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2enamesTable_str9))))));
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
}
V g_heff_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2enamesTable(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[64]; } g_heff_2eemitc_2erunEnd_str0 = {{0x80000000u, K_STR, 0}, 64, 64, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95, 48, 40, 112, 44, 32, 107, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2erunEnd_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2erunEnd_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eemitc_2erunEnd_str3 = {{0x80000000u, K_STR, 0}, 35, 35, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 101, 110, 116, 114, 121, 40, 118, 111, 105, 100, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2erunEnd_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {95, 103, 101, 116, 40, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2erunEnd_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2erunEnd_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  V v_x1_242 = (g_heff_2eemitc_2eperformNodes(v_eff_240, MK_INT(0LL)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2e_2b_2b(v_t_245, v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2erunEnd_str1), (g_heff_2eemitc_2emangleW(heff_dup(g_heff_2elower_2eentryKey_get()), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2erunEnd_str2))));
  V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2erunEnd_str3), heff_strAppend(v_t_248, ((V)&g_heff_2eemitc_2erunEnd_str4)));
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2erunEnd_str5), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2erunEnd_str6), heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2410})});
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_247, v_t_2411);
}
V g_heff_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2erunEnd(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eglobalGet_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eglobalGet_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eglobalGet_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2eglobalGet_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 116, 97, 116, 105, 99, 32, 86, 32, 103, 103, 101, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2eglobalGet_str4 = {{0x80000000u, K_STR, 0}, 20, 20, {40, 118, 111, 105, 100, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2eglobalGet_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {95, 99, 108, 111, 59, 32, 125}};
Clo g_heff_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_x3_244 = ({ V a_0 = heff_dup(v_key_243); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      V v_t_246 = (g_heff_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eglobalGet_str0)));
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2eglobalGet_str1), (g_heff_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eglobalGet_str2))));
      V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2eglobalGet_str3), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2eglobalGet_str4), heff_strAppend(v_t_247, ((V)&g_heff_2eemitc_2eglobalGet_str5)))));
      return heff_tag_at(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eglobalGet(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[76]; } g_heff_2eemitc_2echeckEnd_str0 = {{0x80000000u, K_STR, 0}, 76, 76, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 40, 118, 111, 105, 100, 41, 112, 59, 32, 40, 118, 111, 105, 100, 41, 107, 59, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckEnd_str1 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckEnd_str2 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2echeckEnd_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2echeckEnd_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {103, 103, 101, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2echeckEnd_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {34, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2echeckEnd_str13 = {{0x80000000u, K_STR, 0}, 12, 12, {123, 78, 85, 76, 76, 44, 32, 78, 85, 76, 76, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2echeckEnd_str15 = {{0x80000000u, K_STR, 0}, 42, 42, {115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 71, 108, 111, 98, 97, 108, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 95, 97, 114, 114, 91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckEnd_str17 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 32, 104, 101, 102, 102, 95, 110, 103, 108, 111, 98, 97, 108, 115, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2echeckEnd_str19 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 32, 104, 101, 102, 102, 95, 110, 116, 97, 103, 95, 110, 97, 109, 101, 115, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2echeckEnd_str21 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 32, 104, 101, 102, 102, 95, 110, 108, 98, 108, 95, 110, 97, 109, 101, 115, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eemitc_2echeckEnd_str25 = {{0x80000000u, K_STR, 0}, 38, 38, {32, 32, 104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 32, 61, 32, 104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eemitc_2echeckEnd_str26 = {{0x80000000u, K_STR, 0}, 38, 38, {32, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eemitc_2echeckEnd_str27 = {{0x80000000u, K_STR, 0}, 35, 35, {115, 116, 97, 116, 105, 99, 32, 118, 111, 105, 100, 32, 104, 101, 102, 102, 95, 99, 104, 101, 99, 107, 95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2eemitc_2echeckEnd_str28 = {{0x80000000u, K_STR, 0}, 34, 34, {32, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 32, 61, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 95, 97, 114, 114, 59}};
V g_heff_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam5(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam7(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam6(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam9(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam8(V self, V *args);
Clo g_heff_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_xs_249 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  V v_t_2414 = ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam2, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  V v_t_2415 = ({ V a_0 = ((V)&g_heff_2eemitc_2echeckEnd_str1); V b_1 = heff_get(heff_dup(v_ce_242), LBL_tags); V r_ = (g_heff_2eemitc_2enamesTable(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2416 = ({ V a_0 = ((V)&g_heff_2eemitc_2echeckEnd_str2); V b_1 = heff_get(heff_dup(v_ce_242), LBL_lbls); V r_ = (g_heff_2eemitc_2enamesTable(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2422 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2434 = (g_list_2emap(heff_clo(g_heff_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2422));
  V v_t_2437;
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    v_t_2437 = ((V)&g_heff_2eemitc_2echeckEnd_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_xs_2436 = heff_field(v_x2_2434, 1);
    heff_take_n(v_x2_2434, 3ULL, 2);
    v_t_2437 = ({ V a_0 = ((V)&g_heff_2eemitc_2echeckEnd_str12); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2434);
  }
  V v_x1_2443 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam6, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nil: {
    v_t_2446 = ((V)&g_heff_2eemitc_2echeckEnd_str13);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2443, 0ULL, 2);
    v_t_2446 = ((V)&g_heff_2eemitc_2echeckEnd_str14);
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  V v_t_2447 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str15), heff_strAppend(v_t_2437, heff_strAppend(v_t_2446, ((V)&g_heff_2eemitc_2echeckEnd_str16))));
  V v_xs_2453 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam8, 1, 1, (V[]){heff_dup(v_defs_241)}), v_exports_240));
  V v_t_2454 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2453; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
  V v_t_2455 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str17), heff_strAppend(heff_intShow(v_t_2454), ((V)&g_heff_2eemitc_2echeckEnd_str18)));
  V v_t_2456 = ({ V b_0 = heff_get(heff_dup(v_ce_242), LBL_tags); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2457 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str19), heff_strAppend(heff_intShow(v_t_2456), ((V)&g_heff_2eemitc_2echeckEnd_str20)));
  V v_t_2458 = ({ V b_0 = heff_get(v_ce_242, LBL_lbls); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2459 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str21), heff_strAppend(heff_intShow(v_t_2458), ((V)&g_heff_2eemitc_2echeckEnd_str22)));
  V v_t_2460 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str23), NTAG(TAG_Nil)});
  V v_t_2461 = heff_tag(TAG_Cons, 2, (V[]){v_t_2459, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str24), v_t_2460})});
  V v_t_2462 = heff_tag(TAG_Cons, 2, (V[]){v_t_2457, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str25), v_t_2461})});
  V v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_t_2455, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str26), v_t_2462})});
  V v_t_2464 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str27), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str28), v_t_2463})});
  V v_t_2465 = (g_prelude_2e_2b_2b(v_t_2416, heff_tag(TAG_Cons, 2, (V[]){v_t_2447, v_t_2464})));
  V v_t_2466 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2465));
  V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2466));
  return (g_prelude_2e_2b_2b(v_t_243, v_t_2467));
}
V g_heff_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2echeckEnd(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_d_248 = args[0];
  V v_key_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_248, LBL_key), v_key_247);
}
V g_heff_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_key_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam1, 1, 1, (V[]){v_key_247}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = (g_heff_2eemitc_2eglobalGet(v_ce_242, v_x_2412));
  return (g_prelude_2e_2b_2b(v_t_2413, v_acc_2411));
}
V g_heff_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_d_2421 = args[0];
  V v_key_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_2421, LBL_key), v_key_2420);
}
V g_heff_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2417 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_key_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){v_key_2420}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2423 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_p_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_key_2429;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_key_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_x3_2430 = ({ V a_0 = heff_dup(v_key_2429); V b_1 = heff_get(v_ce_242, LBL_funs); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2433;
  switch (heff_tag_of(v_x3_2430)) {
  case TAG_Nothing: {
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str3), (g_heff_2eemitc_2emangleW(v_key_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2echeckEnd_str4))));
    v_t_2433 = heff_strAppend(v_t_2431, ((V)&g_heff_2eemitc_2echeckEnd_str5));
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2430, 0ULL, 1);
    v_t_2433 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str6), (g_heff_2eemitc_2emangleW(v_key_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2echeckEnd_str7))));
    break;
  }
  default: heff_nomatch(v_x3_2430);
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str8), heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str9), heff_strAppend(v_t_2433, ((V)&g_heff_2eemitc_2echeckEnd_str10)))));
}
V g_heff_2eemitc_2echeckEnd_lam7(V self, V *args) {
  V v_d_2442 = args[0];
  V v_key_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_2442, LBL_key), v_key_2441);
}
V g_heff_2eemitc_2echeckEnd_lam6(V self, V *args) {
  V v_p_2438 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2441;
  switch (heff_tag_of(v_p_2438)) {
  case TAG_MkPair: {
    V v_y_2440 = heff_field(v_p_2438, 1);
    heff_take_n(v_p_2438, 2ULL, 2);
    v_key_2441 = v_y_2440;
    break;
  }
  default: heff_nomatch(v_p_2438);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam7, 1, 1, (V[]){v_key_2441}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2echeckEnd_lam9(V self, V *args) {
  V v_d_2452 = args[0];
  V v_key_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_2452, LBL_key), v_key_2451);
}
V g_heff_2eemitc_2echeckEnd_lam8(V self, V *args) {
  V v_p_2448 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2451;
  switch (heff_tag_of(v_p_2448)) {
  case TAG_MkPair: {
    V v_y_2450 = heff_field(v_p_2448, 1);
    heff_take_n(v_p_2448, 2ULL, 2);
    v_key_2451 = v_y_2450;
    break;
  }
  default: heff_nomatch(v_p_2448);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam9, 1, 1, (V[]){v_key_2451}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2eonlyLent_lam0(V self, V *args);
V g_heff_2eemitc_2eonlyLent_lam1(V self, V *args);
V g_heff_2eemitc_2eonlyLent_lam2(V self, V *args);
V g_heff_2eemitc_2eonlyLent_lam3(V self, V *args);
Clo g_heff_2eemitc_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eonlyLent_entry, 3, 0};

V g_heff_2eemitc_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_bor_240);
    if (heff_strEq_c(v_p_241, v_x_243)) {
      return NTAG(TAG_False);
    } else {
      return NTAG(TAG_True);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_247;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_as_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x3_242, 1);
    V v_b_2413 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_2414 = (g_heff_2eemitc_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2413;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam0, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_fs_2415; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_fs_2415); r_; });
  }
  case TAG_EProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2420;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2423 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2424; V a_1 = v_as_2423; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2423); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x3_242, 0);
    V v_arms_2426 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2456;
    switch (heff_tag_of(v_s_2425)) {
    case TAG_EVar: {
      V v_x_2427 = heff_dup(heff_field(v_s_2425, 0));
      v_t_2456 = heff_strEq(heff_dup(v_p_241), v_x_2427);
      break;
    }
    case TAG_EGlobal: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2456 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2425);
    }
    switch (heff_tag_of(v_t_2456)) {
    case TAG_True: {
      heff_drop(v_s_2425);
      return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam1, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    }
    case TAG_False: {
      V v_t_2462 = (g_heff_2eemitc_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_s_2425));
      switch (heff_tag_of(v_t_2462)) {
      case TAG_True: {
        return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam2, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
      }
      case TAG_False: {
        heff_drop(v_bor_240);
        heff_drop(v_p_241);
        heff_drop(v_arms_2426);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2462);
      }
    }
    default: return heff_nomatch(v_t_2456);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2470 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2471 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2471; V a_1 = v_as_2470; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2470); r_; });
  }
  case TAG_ECall: {
    V v_g_2472 = heff_field(v_x3_242, 0);
    V v_as_2473 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2474 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2473));
    V v_t_2475 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2474, MK_INT(1LL))));
    V v_t_2476 = (g_list_2ezipWith_24s1876717925x1404326288(v_as_2473, v_t_2475));
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam3, 1, 3, (V[]){v_p_241, v_g_2472, v_bor_240}); V a_1 = v_t_2476; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2476); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2eonlyLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eonlyLent(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2eonlyLent_lam0(V self, V *args) {
  V v_f_2416 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  switch (heff_tag_of(v_f_2416)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_f_2416, 1);
    heff_take_n(v_f_2416, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_f_2416);
  }
  return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2419));
}
V g_heff_2eemitc_2eonlyLent_lam1(V self, V *args) {
  V v_a_2457 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461;
  switch (heff_tag_of(v_a_2457)) {
  case TAG_MkArm: {
    V v_b_2460 = heff_field(v_a_2457, 2);
    heff_take_n(v_a_2457, 4ULL, 3);
    v_t_2461 = v_b_2460;
    break;
  }
  default: heff_nomatch(v_a_2457);
  }
  return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2461));
}
V g_heff_2eemitc_2eonlyLent_lam2(V self, V *args) {
  V v_a_2463 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467;
  switch (heff_tag_of(v_a_2463)) {
  case TAG_MkArm: {
    V v_b_2466 = heff_field(v_a_2463, 2);
    heff_take_n(v_a_2463, 4ULL, 3);
    v_t_2467 = v_b_2466;
    break;
  }
  default: heff_nomatch(v_a_2463);
  }
  return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2467));
}
V g_heff_2eemitc_2eonlyLent_lam3(V self, V *args) {
  V v_pr_2477 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_g_2472 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2480;
  switch (heff_tag_of(v_pr_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_dup(heff_field(v_pr_2477, 0));
    v_x2_2480 = v_x_2478;
    break;
  }
  default: heff_nomatch(v_pr_2477);
  }
  V v_t_24110;
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_EVar: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    heff_take_n(v_x2_2480, 1ULL, 1);
    v_t_24110 = heff_strEq(heff_dup(v_p_241), v_x_2481);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_x2_2480, 0ULL, 3);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_2480, 0ULL, 1);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_x2_2480, 0ULL, 2);
    v_t_24110 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x2_2480);
  }
  switch (heff_tag_of(v_t_24110)) {
  case TAG_True: {
    V v_t_24113;
    switch (heff_tag_of(v_pr_2477)) {
    case TAG_MkPair: {
      V v_y_24112 = heff_dup(heff_field(v_pr_2477, 1));
      v_t_24113 = v_y_24112;
      break;
    }
    default: heff_nomatch(v_pr_2477);
    }
    V v_x2_24114 = (g_map_2elookup_24s1546226666x2146984184(v_g_2472, v_bor_240));
    V v_t_24116;
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_Nothing: {
      v_t_24116 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      heff_take_n(v_x2_24114, 1ULL, 1);
      v_t_24116 = v_x_24115;
      break;
    }
    default: heff_nomatch(v_x2_24114);
    }
    V v_t_24117 = ({ V a_0 = v_t_24113; V a_1 = v_t_24116; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_t_24116); r_; });
    switch (heff_tag_of(v_t_24117)) {
    case TAG_True: {
      heff_drop(v_pr_2477);
      heff_drop(v_p_241);
      heff_drop(v_bor_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_24120;
      switch (heff_tag_of(v_pr_2477)) {
      case TAG_MkPair: {
        V v_x_24118 = heff_field(v_pr_2477, 0);
        heff_take_n(v_pr_2477, 1ULL, 2);
        v_t_24120 = v_x_24118;
        break;
      }
      default: heff_nomatch(v_pr_2477);
      }
      return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_24120));
    }
    default: return heff_nomatch(v_t_24117);
    }
  }
  case TAG_False: {
    heff_drop(v_g_2472);
    V v_t_24123;
    switch (heff_tag_of(v_pr_2477)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_pr_2477, 0);
      heff_take_n(v_pr_2477, 1ULL, 2);
      v_t_24123 = v_x_24121;
      break;
    }
    default: heff_nomatch(v_pr_2477);
    }
    return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_24123));
  }
  default: return heff_nomatch(v_t_24110);
  }
}
V g_heff_2eemitc_2ebuildsSize_lam0(V self, V *args);
V g_heff_2eemitc_2ebuildsSize_lam1(V self, V *args);
Clo g_heff_2eemitc_2ebuildsSize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ebuildsSize_entry, 2, 0};

V g_heff_2eemitc_2ebuildsSize(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_b_245;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2eemitc_2ebuildsSize(heff_dup(v_n_240), v_a_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_b_2411);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_n_240;
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2ebuildsSize_lam0, 1, 1, (V[]){v_n_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_e_2418;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2421));
    if (heff_intEq_c(v_t_2422, heff_dup(v_n_240))) {
      heff_drop(v_n_240);
      heff_drop(v_as_2421);
      return NTAG(TAG_True);
    } else {
      V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
      return ({ V a_0 = v_t_2424; V a_1 = v_as_2421; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2421); r_; });
    }
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x2_241, 0);
    V v_arms_2426 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2427 = (g_heff_2eemitc_2ebuildsSize(heff_dup(v_n_240), v_s_2425));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_arms_2426);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      return ({ V a_0 = heff_clo(g_heff_2eemitc_2ebuildsSize_lam1, 1, 1, (V[]){v_n_240}); V a_1 = v_arms_2426; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2435 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2436 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2436; V a_1 = v_as_2435; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2435); r_; });
  }
  case TAG_ECall: {
    V v_as_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2439 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2439; V a_1 = v_as_2438; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2438); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2ebuildsSize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ebuildsSize(a[0], a[1]);
}
V g_heff_2eemitc_2ebuildsSize_lam0(V self, V *args) {
  V v_f_2414 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_f_2414, 1);
    heff_take_n(v_f_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_f_2414);
  }
  return (g_heff_2eemitc_2ebuildsSize(v_n_240, v_t_2417));
}
V g_heff_2eemitc_2ebuildsSize_lam1(V self, V *args) {
  V v_a_2428 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  return (g_heff_2eemitc_2ebuildsSize(v_n_240, v_t_2432));
}
V g_heff_2eemitc_2ereuses_lam0(V self, V *args);
V g_heff_2eemitc_2ereuses_lam1(V self, V *args);
V g_heff_2eemitc_2ereuses_lam2(V self, V *args);
Clo g_heff_2eemitc_2ereuses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuses_entry, 2, 0};

V g_heff_2eemitc_2ereuses(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_b_245;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2eemitc_2ereuses(heff_dup(v_p_240), v_a_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_p_240);
      heff_drop(v_b_2411);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_b_2411;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2ereuses_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_fs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_e_2418;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2422; V a_1 = v_as_2421; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x2_241, 0);
    V v_arms_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2454;
    switch (heff_tag_of(v_s_2423)) {
    case TAG_EVar: {
      V v_x_2425 = heff_dup(heff_field(v_s_2423, 0));
      v_t_2454 = heff_strEq(heff_dup(v_p_240), v_x_2425);
      break;
    }
    case TAG_EGlobal: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2423);
    }
    switch (heff_tag_of(v_t_2454)) {
    case TAG_True: {
      V v_t_2455 = (g_list_2eany_24s1438978125x414501573(v_arms_2424));
      switch (heff_tag_of(v_t_2455)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_s_2423);
        heff_drop(v_arms_2424);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_2456 = (g_heff_2eemitc_2ereuses(heff_dup(v_p_240), v_s_2423));
        switch (heff_tag_of(v_t_2456)) {
        case TAG_True: {
          heff_drop(v_p_240);
          heff_drop(v_arms_2424);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          return ({ V a_0 = heff_clo(g_heff_2eemitc_2ereuses_lam1, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2424); r_; });
        }
        default: return heff_nomatch(v_t_2456);
        }
      }
      default: return heff_nomatch(v_t_2455);
      }
    }
    case TAG_False: {
      V v_t_2462 = (g_heff_2eemitc_2ereuses(heff_dup(v_p_240), v_s_2423));
      switch (heff_tag_of(v_t_2462)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_arms_2424);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return ({ V a_0 = heff_clo(g_heff_2eemitc_2ereuses_lam2, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2424); r_; });
      }
      default: return heff_nomatch(v_t_2462);
      }
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2470 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2471 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2471; V a_1 = v_as_2470; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2470); r_; });
  }
  case TAG_ECall: {
    V v_as_2473 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2474 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2474; V a_1 = v_as_2473; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_as_2473); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2ereuses_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ereuses(a[0], a[1]);
}
V g_heff_2eemitc_2ereuses_lam0(V self, V *args) {
  V v_f_2414 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_f_2414, 1);
    heff_take_n(v_f_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_f_2414);
  }
  return (g_heff_2eemitc_2ereuses(v_p_240, v_t_2417));
}
V g_heff_2eemitc_2ereuses_lam1(V self, V *args) {
  V v_a_2457 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461;
  switch (heff_tag_of(v_a_2457)) {
  case TAG_MkArm: {
    V v_b_2460 = heff_field(v_a_2457, 2);
    heff_take_n(v_a_2457, 4ULL, 3);
    v_t_2461 = v_b_2460;
    break;
  }
  default: heff_nomatch(v_a_2457);
  }
  return (g_heff_2eemitc_2ereuses(v_p_240, v_t_2461));
}
V g_heff_2eemitc_2ereuses_lam2(V self, V *args) {
  V v_a_2463 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2467;
  switch (heff_tag_of(v_a_2463)) {
  case TAG_MkArm: {
    V v_b_2466 = heff_field(v_a_2463, 2);
    heff_take_n(v_a_2463, 4ULL, 3);
    v_t_2467 = v_b_2466;
    break;
  }
  default: heff_nomatch(v_a_2463);
  }
  return (g_heff_2eemitc_2ereuses(v_p_240, v_t_2467));
}
V g_heff_2eemitc_2elentVars_lam0(V self, V *args);
Clo g_heff_2eemitc_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentVars_entry, 2, 0};

V g_heff_2eemitc_2elentVars(V v_ds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2eemitc_2elentVars(heff_dup(v_ds_240), v_a_249));
    V v_t_2412 = (g_heff_2eemitc_2elentVars(v_ds_240, v_b_2410));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_t_2412);
  }
  case TAG_ERecord: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2418 = heff_field(v_x2_241, 0);
    V v_arms_2419 = heff_field(v_x2_241, 1);
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2419)));
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2elentVars_lam0, 2, 2, (V[]){heff_dup(v_s_2418), v_ds_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2elentVars_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentVars(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2elentVars_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_x_2422 = args[1];
  V v_s_2418 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452;
  switch (heff_tag_of(v_s_2418)) {
  case TAG_EVar: {
    V v_x_2423 = heff_field(v_s_2418, 0);
    heff_take_n(v_s_2418, 1ULL, 1);
    v_t_2452 = (g_heff_2eemitc_2eelemS(v_x_2423, v_ds_240));
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2418, 0ULL, 3);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2418);
  }
  V v_t_2471;
  switch (heff_tag_of(v_t_2452)) {
  case TAG_True: {
    V v_t_2456;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_vs_2454 = heff_dup(heff_field(v_x_2422, 1));
      v_t_2456 = v_vs_2454;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    V v_t_2460;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_vs_2458 = heff_dup(heff_field(v_x_2422, 1));
      v_t_2460 = v_vs_2458;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    V v_t_2461 = (g_prelude_2e_2b_2b(v_t_2460, v_ds_240));
    V v_t_2465;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_b_2464 = heff_field(v_x_2422, 2);
      heff_take_n(v_x_2422, 4ULL, 3);
      v_t_2465 = v_b_2464;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    V v_t_2466 = ({ V a_0 = v_t_2461; V a_1 = v_t_2465; V r_ = (g_heff_2eemitc_2elentVars(a_0, a_1)); heff_drop(v_t_2465); r_; });
    v_t_2471 = (g_prelude_2e_2b_2b(v_t_2456, v_t_2466));
    break;
  }
  case TAG_False: {
    V v_t_2470;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_b_2469 = heff_field(v_x_2422, 2);
      heff_take_n(v_x_2422, 4ULL, 3);
      v_t_2470 = v_b_2469;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    v_t_2471 = ({ V a_0 = v_ds_240; V a_1 = v_t_2470; V r_ = (g_heff_2eemitc_2elentVars(a_0, a_1)); heff_drop(v_t_2470); r_; });
    break;
  }
  default: heff_nomatch(v_t_2452);
  }
  return (g_prelude_2e_2b_2b(v_t_2471, v_acc_2421));
}
V g_heff_2eemitc_2eloopLent_lam0(V self, V *args);
V g_heff_2eemitc_2eloopLent_lam2(V self, V *args);
V g_heff_2eemitc_2eloopLent_lam1(V self, V *args);
Clo g_heff_2eemitc_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eloopLent_entry, 4, 0};

V g_heff_2eemitc_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_as_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at(v_ru_24x4_243_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x4_243, 1);
    V v_b_2413 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2414 = (g_heff_2eemitc_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2413;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    V v_as_2419 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    V v_t_2420 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2420; V a_1 = v_as_2419; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2419); r_; });
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_x4_243, 0);
    V v_arms_2422 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2423 = (g_heff_2eemitc_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_s_2421));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      return ({ V a_0 = heff_clo(g_heff_2eemitc_2eloopLent_lam0, 1, 3, (V[]){v_key_240, v_i_241, v_ds_242}); V a_1 = v_arms_2422; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_arms_2422); r_; });
    }
    case TAG_False: {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_arms_2422);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    V v_g_2432 = heff_field(v_x4_243, 0);
    V v_as_2433 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2435;
    if (heff_strEq_c(v_g_2432, heff_dup(v_key_240))) {
      v_t_2435 = NTAG(TAG_False);
    } else {
      v_t_2435 = NTAG(TAG_True);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      V v_t_2436 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
      return ({ V a_0 = v_t_2436; V a_1 = v_as_2433; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2433); r_; });
    }
    case TAG_False: {
      V v_t_2437 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2433));
      V v_t_2438 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2437, MK_INT(1LL))));
      V v_t_2439 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_as_2433), v_t_2438));
      V v_t_2478 = ({ V a_0 = heff_clo(g_heff_2eemitc_2eloopLent_lam1, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2439; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2439); r_; });
      switch (heff_tag_of(v_t_2478)) {
      case TAG_True: {
        V v_t_2479 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
        return ({ V a_0 = v_t_2479; V a_1 = v_as_2433; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_as_2433); r_; });
      }
      case TAG_False: {
        heff_drop(v_key_240);
        heff_drop(v_i_241);
        heff_drop(v_ds_242);
        heff_drop(v_as_2433);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2478);
      }
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eemitc_2eloopLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eloopLent(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemitc_2eloopLent_lam0(V self, V *args) {
  V v_a_2424 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_MkArm: {
    V v_b_2427 = heff_field(v_a_2424, 2);
    heff_take_n(v_a_2424, 4ULL, 3);
    v_t_2428 = v_b_2427;
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  return (g_heff_2eemitc_2eloopLent(v_key_240, v_i_241, v_ds_242, v_t_2428));
}
V g_heff_2eemitc_2eloopLent_lam2(V self, V *args) {
  V v_d_2445 = args[0];
  V v_pr_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2448;
  switch (heff_tag_of(v_pr_2440)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_pr_2440, 0);
    heff_take_n(v_pr_2440, 1ULL, 2);
    v_x2_2448 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_pr_2440);
  }
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_EVar: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    heff_take_n(v_x2_2448, 1ULL, 1);
    return heff_strEq(v_d_2445, v_x_2449);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_2448, 0ULL, 3);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2eemitc_2eloopLent_lam1(V self, V *args) {
  V v_pr_2440 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443;
  switch (heff_tag_of(v_pr_2440)) {
  case TAG_MkPair: {
    V v_y_2442 = heff_dup(heff_field(v_pr_2440, 1));
    v_t_2443 = v_y_2442;
    break;
  }
  default: heff_nomatch(v_pr_2440);
  }
  if (heff_intEq_c(v_t_2443, v_i_241)) {
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2eloopLent_lam2, 1, 1, (V[]){v_pr_2440}); V a_1 = v_ds_242; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ds_242); r_; });
  } else {
    heff_drop(v_pr_2440);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
}
V g_heff_2eemitc_2eborDef_lam0(V self, V *args);
V g_heff_2eemitc_2eborDef_lam1(V self, V *args);
V g_heff_2eemitc_2eborDef_lam2(V self, V *args);
Clo g_heff_2eemitc_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eborDef_entry, 2, 0};

V g_heff_2eemitc_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(heff_get(heff_dup(v_d_241), LBL_key), v_bor_240));
    V v_bi_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_bi_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_bi_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_t_2412 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2411));
    V v_t_2417 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eborDef_lam0, 1, 1, (V[]){v_bi_249}), v_t_2412));
    V v_t_2418 = (g_list_2emap_24s1937570095x2110149801(v_t_2417));
    V v_x2_2419 = (g_map_2elookup_24s1546226666x2146984184(heff_get(heff_dup(v_d_241), LBL_key), v_bor_240));
    V v_bi_2421;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nothing: {
      v_bi_2421 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      heff_take_n(v_x2_2419, 1ULL, 1);
      v_bi_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_2423 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2422, MK_INT(1LL))));
    V v_t_2424 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2423));
    V v_t_2429 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eborDef_lam1, 1, 1, (V[]){v_bi_2421}), v_t_2424));
    V v_t_2430 = (g_list_2emap_24s1937570095x2110149801(v_t_2429));
    V v_t_2431 = (g_heff_2eemitc_2elentVars(v_t_2430, v_b_246));
    V v_ds_2432 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2431));
    V v_x2_2433 = (g_map_2elookup_24s1546226666x2146984184(heff_get(heff_dup(v_d_241), LBL_key), v_bor_240));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nothing: {
      v_t_2435 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      heff_take_n(v_x2_2433, 1ULL, 1);
      v_t_2435 = v_x_2434;
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_t_2442 = (g_list_2efilter(heff_clo(g_heff_2eemitc_2eborDef_lam2, 1, 5, (V[]){v_xs_245, heff_dup(v_bor_240), v_b_246, heff_dup(v_d_241), v_ds_2432}), v_t_2435));
    return (g_map_2einsert_24s1341440536x470972936(heff_get(v_d_241, LBL_key), v_t_2442, v_bor_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eborDef(a[0], a[1]);
}
V g_heff_2eemitc_2eborDef_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_bi_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_p_2413, 1);
    heff_take_n(v_p_2413, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  return ({ V a_0 = v_t_2416; V a_1 = v_bi_249; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_249); r_; });
}
V g_heff_2eemitc_2eborDef_lam1(V self, V *args) {
  V v_p_2425 = args[0];
  V v_bi_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_p_2425, 1);
    heff_take_n(v_p_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_p_2425);
  }
  return ({ V a_0 = v_t_2428; V a_1 = v_bi_2421; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_2421); r_; });
}
V g_heff_2eemitc_2eborDef_lam2(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_b_246 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_ds_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = (g_list_2edrop(heff_dup(v_i_2436), v_xs_245));
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nil: {
    heff_drop(v_i_2436);
    heff_drop(v_bor_240);
    heff_drop(v_b_246);
    heff_drop(v_d_241);
    heff_drop(v_ds_2432);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_2438 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    V v_t_2440 = (g_heff_2eemitc_2eonlyLent(v_bor_240, heff_dup(v_p_2438), heff_dup(v_b_246)));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      V v_x1_2441 = (g_heff_2eemitc_2ereuses(v_p_2438, heff_dup(v_b_246)));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_True: {
        heff_drop(v_i_2436);
        heff_drop(v_b_246);
        heff_drop(v_d_241);
        heff_drop(v_ds_2432);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return (g_heff_2eemitc_2eloopLent(heff_get(v_d_241, LBL_key), v_i_2436, v_ds_2432, v_b_246));
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    case TAG_False: {
      heff_drop(v_i_2436);
      heff_drop(v_b_246);
      heff_drop(v_d_241);
      heff_drop(v_ds_2432);
      heff_drop(v_p_2438);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  default: return heff_nomatch(v_t_2437);
  }
}
Clo g_heff_2eemitc_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eborFix_entry, 3, 0};

V g_heff_2eemitc_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
  V v_xs_244 = (g_list_2emap_24s1573559022x513331157(MK_INT(1LL), MK_INT(0LL), v_t_243));
  V v_t_245 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_244; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_244); r_; });
  if (heff_intEq_c(v_t_245, v_size_241)) {
    return v_bor_242;
  } else {
    V v_t_247 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
    V v_xs_248 = (g_list_2emap_24s1573559022x513331157(MK_INT(1LL), MK_INT(0LL), v_t_247));
    V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_t_2410 = (g_list_2efoldl_24s1537290326x1300290376(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_249;
    V t_2 = v_t_2410;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
}
V g_heff_2eemitc_2eborFix_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eborFix(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2eborAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eborAll_entry, 2, 0};

V g_heff_2eemitc_2eborAll(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    return (g_map_2einsert_24s1341440536x470972936(heff_get(v_d_241, LBL_key), v_t_248, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2eborAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eborAll(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2eprogramCE_str0 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2eprogramCE_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {35, 100, 101, 102, 105, 110, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eprogramCE_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2eprogramCE_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {35, 100, 101, 102, 105, 110, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eprogramCE_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eemitc_2eprogramCE_str9 = {{0x80000000u, K_STR, 0}, 32, 32, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_t_245 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_244)}));
  V v_t_246 = (g_heff_2eemitc_2etraverseC(v_t_245, v_defs_243));
  V v_t_247 = heff_tr(heff_apply(v_t_246, 1, (V[]){heff_dup(g_heff_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_ems_248 = heff_field(v_t_247, 0);
    V v_s_249 = heff_field(v_t_247, 1);
    V v_ru_24t_247_24MkPair = heff_take_reuse_n(v_t_247, 3ULL, 2);
    V v_t_2410 = heff_tag_at(v_ru_24t_247_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eprogramCE_str0), heff_get(heff_dup(v_ending_242), LBL_prefix)});
    V v_t_2411 = ({ V b_0 = heff_get(heff_dup(v_ce_244), LBL_tags); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412 = (g_list_2efilter_24s314366508x59199896(v_t_2411));
    V v_t_2413 = (g_list_2emap_24s1039286686x792451646(((V)&g_heff_2eemitc_2eprogramCE_str1), ((V)&g_heff_2eemitc_2eprogramCE_str2), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eprogramCE_str3), ((V)&g_heff_2eemitc_2eprogramCE_str4), v_t_2412));
    V v_t_2414 = ({ V b_0 = heff_get(heff_dup(v_ce_244), LBL_lbls); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2415 = (g_list_2emap_24s1039286686x792451646(((V)&g_heff_2eemitc_2eprogramCE_str5), ((V)&g_heff_2eemitc_2eprogramCE_str6), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eprogramCE_str7), ((V)&g_heff_2eemitc_2eprogramCE_str8), v_t_2414));
    V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
    V v_t_2417 = (g_list_2emap_24s1711626084x463433445(v_provs_241));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eprogramCE_str9), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_strs)));
    V v_t_2420 = (g_list_2emap_24s1173914895x100384474(v_t_2419));
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_shapes)));
    V v_t_2422 = (g_list_2emap_24s1173914895x100384474(v_t_2421));
    V v_t_2423 = (g_heff_2eemitc_2eonceInOrder(heff_dup(g_map_2eempty_get()), v_t_2422));
    V v_t_2424 = (g_list_2emap_24s1377907145x510226651(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_248)));
    V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1670799345x2002421308(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_protos)));
    V v_t_2428 = (g_list_2emap_24s1173914895x100384474(v_t_2427));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_prims)));
    V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_t_2429));
    V v_xs_2431 = (g_heff_2eemitc_2eonceInOrder(heff_dup(g_map_2eempty_get()), v_t_2430));
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    V v_t_2433 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s122245128x1667515165(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_248));
    V v_t_2435 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2434; V r_ = (g_list_2efoldl_24s1885051946x1524849902(a_0, a_1)); heff_drop(v_t_2434); r_; });
    V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(v_s_249, LBL_lams)));
    V v_t_2437 = (g_list_2emap_24s1173914895x100384474(v_t_2436));
    V v_t_2438 = heff_tr(heff_apply(heff_get(v_ending_242, LBL_end), 1, (V[]){v_ce_244}));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2437, v_t_2438));
    V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2439));
    V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2440));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2448));
    V v_t_2450 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2449));
    V v_x2_2451 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2450));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eemitc_2eprogramCE_str10);
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2eemitc_2eprogramCE_str11); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
    }
    default: return heff_nomatch(v_x2_2451);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eceOf_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eceOf_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
Clo g_heff_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2eemitc_2eceOf(V v_provs_240, V v_defs_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V a_0 = ((V)&g_heff_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24s1112037391x343083959(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_xs_249 = (g_list_2efilter_24s1412390516x2102311772(v_t_248));
  V v_m_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2412; V a_3 = v_t_2413; V a_4 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_names_242, 1);
    v_t_2417 = heff_dup(v_y_2416);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2419 = ({ V a_0 = ((V)&g_heff_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s1112037391x343083959(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
  V v_xs_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2423; V a_3 = heff_dup(g_map_2eempty_get()); V a_4 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  V v_t_2425 = (g_list_2efoldl_24s966961137x2098673946(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2426 = (g_heff_2eemit_2ebounceGo(v_defs_241, heff_dup(g_map_2eempty_get())));
  V v_t_2427 = (g_list_2efoldl_24s1889728774x506508078(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2428 = (g_heff_2eemitc_2eborFix(v_defs_241, MK_INT(-1LL), v_t_2427));
  return heff_rec(11, shape_tags__lbls__funs__bounce__self__lam__owned__after__borrowed__bor__known, (V[]){v_t_2414, v_t_2424, v_t_2425, v_t_2426, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2428, heff_dup(g_map_2eempty_get())});
}
V g_heff_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eceOf(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eemitc_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elastDotGo_entry, 3, 0};

V g_heff_2eemitc_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_k_240)), heff_dup(v_i_241))) {
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_245;
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_k_240), heff_dup(v_i_241)), MK_INT(46LL))) {
      heff_drop(v_at_242);
      v_t_245 = heff_dup(v_i_241);
    } else {
      v_t_245 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2eemitc_2elastDotGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elastDotGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2epubLine_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 97, 116, 105, 99, 32, 86, 32, 103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2epubLine_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2epubLine_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2epubLine_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2epubLine_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2epubLine_str5 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40}};
Clo g_heff_2eemitc_2epubLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epubLine_entry, 1, 0};

V g_heff_2eemitc_2epubLine(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(11LL)), ((V)&g_heff_2eemitc_2epubLine_str0))) {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_l_240)), MK_INT(5LL));
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), v_t_242, heff_strLength(heff_dup(v_l_240)));
    if (heff_strEq_c(v_t_243, ((V)&g_heff_2eemitc_2epubLine_str1))) {
      if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemitc_2epubLine_str2))) {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      } else {
        return v_l_240;
      }
    } else {
      V v_x3_246 = (g_prelude_2eindexFrom(((V)&g_heff_2eemitc_2epubLine_str3), heff_dup(v_l_240), MK_INT(0LL)));
      V v_x1_248;
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_246, 0ULL, 1);
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemitc_2epubLine_str4))) {
          return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
        } else {
          return v_l_240;
        }
      }
      case TAG_False: {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemitc_2epubLine_str5))) {
      return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
    } else {
      return v_l_240;
    }
  }
}
V g_heff_2eemitc_2epubLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epubLine(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2enumbersOf_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enumbersOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2enumbersOf_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {35, 100, 101, 102, 105, 110, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enumbersOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2enumbersOf_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enumbersOf_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2enumbersOf_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {35, 100, 101, 102, 105, 110, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2enumbersOf_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2eemitc_2enumbersOf_lam0(V self, V *args);
V g_heff_2eemitc_2enumbersOf_lam1(V self, V *args);
Clo g_heff_2eemitc_2enumbersOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enumbersOf_entry, 2, 0};

V g_heff_2eemitc_2enumbersOf(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_ts_242 = heff_field(v_x2_241, 0);
    V v_ls_243 = heff_field(v_x2_241, 1);
    V v_m_244 = (g_list_2efoldl_24s657006386x1833506039(heff_dup(g_map_2eempty_get()), v_ts_242));
    V v_t_245 = ({ V a_0 = v_m_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_244); r_; });
    V v_t_246 = (g_list_2emap_24s1937570095x2110149801(v_t_245));
    V v_t_247 = (g_list_2efilter_24s1412390516x2102311772(v_t_246));
    V v_t_2413 = (g_list_2emap(heff_clo(g_heff_2eemitc_2enumbersOf_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), v_t_247));
    V v_m_2414 = (g_list_2efoldl_24s657006386x1833506039(heff_dup(g_map_2eempty_get()), v_ls_243));
    V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2414); r_; });
    V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(v_t_2415));
    V v_t_2422 = (g_list_2emap(heff_clo(g_heff_2eemitc_2enumbersOf_lam1, 1, 1, (V[]){v_ce_240}), v_t_2416));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2413, v_t_2422);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2enumbersOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2enumbersOf(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2enumbersOf_lam0(V self, V *args) {
  V v_t_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2enumbersOf_str0), (g_heff_2eemitc_2emangleW(heff_dup(v_t_248), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2enumbersOf_str1))));
  V v_x2_2410 = ({ V a_0 = v_t_248; V b_1 = heff_get(v_ce_240, LBL_tags); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2enumbersOf_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eemitc_2enumbersOf_str3), heff_intShow(v_t_2412))));
}
V g_heff_2eemitc_2enumbersOf_lam1(V self, V *args) {
  V v_l_2417 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_strAppend(((V)&g_heff_2eemitc_2enumbersOf_str4), (g_heff_2eemitc_2emangleW(heff_dup(v_l_2417), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2enumbersOf_str5))));
  V v_x2_2419 = ({ V a_0 = v_l_2417; V b_1 = heff_get(v_ce_240, LBL_lbls); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    v_t_2421 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2enumbersOf_str6), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eemitc_2enumbersOf_str7), heff_intShow(v_t_2421))));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2edeclOf_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2edeclOf_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {118, 111, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {86}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2edeclOf_str16 = {{0x80000000u, K_STR, 0}, 21, 21, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edeclOf_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edeclOf_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2edeclOf_str19 = {{0x80000000u, K_STR, 0}, 11, 11, {101, 120, 116, 101, 114, 110, 32, 67, 108, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2edeclOf_str20 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 59}};
Clo g_heff_2eemitc_2edeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edeclOf_entry, 2, 0};

V g_heff_2eemitc_2edeclOf(V v_ce_240, V v_k_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_k_241); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str0), (g_heff_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edeclOf_str1))));
    V v_t_244 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str2), heff_strAppend(v_t_243, ((V)&g_heff_2eemitc_2edeclOf_str3)));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str4), (g_heff_2eemitc_2emangleW(heff_dup(v_k_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edeclOf_str5))));
    V v_t_2411;
    if (heff_intEq_c(heff_dup(v_n_245), MK_INT(0LL))) {
      heff_drop(v_n_245);
      v_t_2411 = ((V)&g_heff_2eemitc_2edeclOf_str6);
    } else {
      V v_x2_248 = (g_list_2ereplicate(v_n_245, ((V)&g_heff_2eemitc_2edeclOf_str7)));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2eemitc_2edeclOf_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2eemitc_2edeclOf_str9); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str10), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str11), heff_strAppend(v_t_2411, ((V)&g_heff_2eemitc_2edeclOf_str12)))));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str13), (g_heff_2eemitc_2emangleW(heff_dup(v_k_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edeclOf_str14))));
    V v_t_2414 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str15), heff_strAppend(v_t_2413, ((V)&g_heff_2eemitc_2edeclOf_str16)));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str17), (g_heff_2eemitc_2emangleW(v_k_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edeclOf_str18))));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2edeclOf_str19), heff_strAppend(v_t_2415, ((V)&g_heff_2eemitc_2edeclOf_str20)));
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2edeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edeclOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eownLines_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eownLines_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eownLines_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eownLines_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eownLines_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eownLines_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_o_247 = heff_strAppend(((V)&g_heff_2eemitc_2eownLines_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_245), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eownLines_str1))));
    V v_x2_248 = (g_map_2elookup_24s1546226666x2146984184(v_o_247, v_strs_241));
    V v_t_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      v_t_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_o_2411 = heff_strAppend(((V)&g_heff_2eemitc_2eownLines_str2), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_245), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eownLines_str3))));
    V v_x2_2412 = (g_map_2elookup_24s1546226666x2146984184(v_o_2411, v_protos_242));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take_n(v_x2_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2415 = (g_list_2emap_24s1339179958x587003135(v_t_2414));
    V v_t_2416 = (g_list_2efilter_24s1477606187x944222946(heff_get(heff_dup(v_e_246), LBL_protos)));
    V v_t_2417 = (g_list_2emap_24s1328195927x21044528(MK_INT(7LL), v_t_2416));
    V v_t_2418 = (g_list_2emap_24s1339179958x587003135(heff_get(heff_dup(v_e_246), LBL_code)));
    V v_o_2419 = heff_strAppend(((V)&g_heff_2eemitc_2eownLines_str4), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_245), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eownLines_str5))));
    V v_x2_2420 = (g_map_2elookup_24s1546226666x2146984184(v_o_2419, v_lams_243));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      heff_take_n(v_x2_2420, 1ULL, 1);
      v_t_2422 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2423 = (g_list_2emap_24s1339179958x587003135(v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2424));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2425));
    return (g_prelude_2e_2b_2b(v_t_2410, v_t_2426));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eownLines(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
Clo g_heff_2eemitc_2ezipDE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ezipDE_entry, 2, 0};

V g_heff_2eemitc_2ezipDE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_244 = heff_field(v_x2_241, 0);
      V v_es_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_d_242, v_e_244}), (g_heff_2eemitc_2ezipDE(v_ds_243, v_es_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ezipDE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ezipDE(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eusedBy_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eusedBy_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemitc_2eusedBy_lam0(V self, V *args);
Clo g_heff_2eemitc_2eusedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eusedBy_entry, 2, 0};

V g_heff_2eemitc_2eusedBy(V v_m_240, V v_ps_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_241));
  V v_xs_2412 = ({ V a_0 = heff_clo(g_heff_2eemitc_2eusedBy_lam0, 2, 1, (V[]){heff_dup(v_m_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_m_2413 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2412; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2412); r_; });
  V v_t_2414 = ({ V a_0 = v_m_2413; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2413); r_; });
  return (g_list_2emap_24s1937570095x2110149801(v_t_2414));
}
V g_heff_2eemitc_2eusedBy_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eusedBy(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eemitc_2eusedBy_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_k_247;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_k_247 = heff_get(v_d_245, LBL_key);
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_o_248 = heff_strAppend(((V)&g_heff_2eemitc_2eusedBy_str0), (g_heff_2eemitc_2emangleW(v_k_247, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eusedBy_str1))));
  V v_x2_249 = ({ V a_0 = v_o_248; V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2411;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    heff_take_n(v_x2_249, 1ULL, 1);
    v_t_2411 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_243));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2emodulePart_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2emodulePart_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2emodulePart_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 99}};
V g_heff_2eemitc_2emodulePart_lam0(V self, V *args);
V g_heff_2eemitc_2emodulePart_lam1(V self, V *args);
Clo g_heff_2eemitc_2emodulePart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2emodulePart_entry, 9, 0};

V g_heff_2eemitc_2emodulePart(V v_head_240, V v_ce_241, V v_s_242, V v_shapes_243, V v_prims_244, V v_strs_245, V v_protos_246, V v_lams_247, V v_x9_248) {
top: ;
  switch (heff_tag_of(v_x9_248)) {
  case TAG_MkPair: {
    V v_m_249 = heff_field(v_x9_248, 0);
    V v_ps_2410 = heff_field(v_x9_248, 1);
    V v_ru_24x9_248_24MkPair = heff_take_reuse_n(v_x9_248, 3ULL, 2);
    V v_es_2411 = (g_list_2emap_24s1653859898x762241412(heff_dup(v_ps_2410)));
    V v_t_2412 = heff_tag_at(v_ru_24x9_248_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2411));
    V v_t_2414 = (g_list_2efoldl_24s1127955551x950394381(v_t_2412, v_t_2413));
    V v_t_2415 = ({ V a_0 = heff_dup(v_ce_241); V a_1 = v_t_2414; V r_ = (g_heff_2eemitc_2enumbersOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_heff_2eemitc_2eusedBy(v_shapes_243, heff_dup(v_ps_2410)));
    V v_t_2417 = (g_list_2emap_24s1377907145x510226651(v_t_2416));
    V v_xs_2418 = (g_heff_2eemitc_2eusedBy(v_prims_244, heff_dup(v_ps_2410)));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s122245128x1667515165(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2410)));
    V v_xs_2422 = (g_list_2efoldl_24s1984245835x1989432102(NTAG(TAG_Nil), v_t_2421));
    V v_m_2423 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2422; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2422); r_; });
    V v_t_2424 = ({ V a_0 = v_m_2423; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2423); r_; });
    V v_xs_2425 = (g_list_2emap_24s1937570095x2110149801(v_t_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
    V v_t_2430 = ({ V a_0 = heff_clo(g_heff_2eemitc_2emodulePart_lam0, 2, 1, (V[]){v_ce_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
    V v_t_2435 = ({ V a_0 = heff_clo(g_heff_2eemitc_2emodulePart_lam1, 2, 4, (V[]){heff_dup(v_s_242), heff_dup(v_strs_245), heff_dup(v_protos_246), heff_dup(v_lams_247)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
    V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2435));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2436));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2437));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2438));
    V v_x2_2440 = (g_prelude_2e_2b_2b(v_head_240, v_t_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2eemitc_2emodulePart_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2eemitc_2emodulePart_str1); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_249, ((V)&g_heff_2eemitc_2emodulePart_str2)), v_t_2443});
  }
  default: return heff_nomatch(v_x9_248);
  }
}
V g_heff_2eemitc_2emodulePart_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2emodulePart(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[4]); heff_drop(a[5]); heff_drop(a[6]); heff_drop(a[7]); return r;
}
V g_heff_2eemitc_2emodulePart_lam0(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = (g_heff_2eemitc_2edeclOf(v_ce_241, v_x_2428));
  return (g_prelude_2e_2b_2b(v_t_2429, v_acc_2427));
}
V g_heff_2eemitc_2emodulePart_lam1(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_x_2433 = args[1];
  V v_s_242 = heff_env(self)[0];
  V v_strs_245 = heff_env(self)[1];
  V v_protos_246 = heff_env(self)[2];
  V v_lams_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2434 = ({ V a_0 = v_s_242; V a_1 = v_strs_245; V a_2 = v_protos_246; V a_3 = v_lams_247; V a_4 = v_x_2433; V r_ = (g_heff_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_242); heff_drop(v_strs_245); heff_drop(v_protos_246); heff_drop(v_lams_247); heff_drop(v_x_2433); r_; });
  return (g_prelude_2e_2b_2b(v_t_2434, v_acc_2432));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2eentryPart_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {114, 117, 110, 36, 109, 97, 105, 110, 46, 99}};

static V g_heff_2eemitc_2eentryPart_val;
static int g_heff_2eemitc_2eentryPart_st;
static V g_heff_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2eemitc_2eentryPart_str0);
}
V g_heff_2eemitc_2eentryPart_get(void) {
  if (g_heff_2eemitc_2eentryPart_st == 2) return g_heff_2eemitc_2eentryPart_val;
  if (g_heff_2eemitc_2eentryPart_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2eentryPart_st = 1;
  g_heff_2eemitc_2eentryPart_val = heff_tr(g_heff_2eemitc_2eentryPart_init());
  g_heff_2eemitc_2eentryPart_st = 2;
  return g_heff_2eemitc_2eentryPart_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2epartsWith_str0 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eemitc_2epartsWith_str1 = {{0x80000000u, K_STR, 0}, 25, 25, {86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2epartsWith_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2epartsWith_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2epartsWith_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2epartsWith_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2epartsWith_str6 = {{0x80000000u, K_STR, 0}, 17, 17, {35, 105, 110, 99, 108, 117, 100, 101, 32, 34, 104, 101, 102, 102, 46, 104, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2epartsWith_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2epartsWith_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2epartsWith_str9 = {{0x80000000u, K_STR, 0}, 17, 17, {35, 105, 110, 99, 108, 117, 100, 101, 32, 34, 104, 101, 102, 102, 46, 104, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2epartsWith_str10 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2epartsWith_str11 = {{0x80000000u, K_STR, 0}, 17, 17, {35, 100, 101, 102, 105, 110, 101, 32, 72, 69, 70, 70, 95, 80, 65, 82, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2epartsWith_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 46, 104}};
Clo g_heff_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_246 = heff_field(v_x6_245, 0);
    V v_s_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_248 = heff_tag_at(v_ru_24x6_245_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str0), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str1), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_ending_242), LBL_prefix), heff_tag(TAG_Cons, 2, (V[]){v_runtime_240, v_t_249})));
    V v_x2_2411 = (g_prelude_2e_2b_2b(v_t_248, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2eemitc_2epartsWith_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2eemitc_2epartsWith_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2416 = ({ V a_0 = ((V)&g_heff_2eemitc_2epartsWith_str4); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2415; V r_ = (g_list_2efoldl_24s1112037391x343083959(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2416, ({ V a_0 = ((V)&g_heff_2eemitc_2epartsWith_str5); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2417; V r_ = (g_list_2efoldl_24s1112037391x343083959(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; })});
    V v_t_2419 = ({ V a_0 = heff_dup(v_ce_244); V a_1 = v_t_2418; V r_ = (g_heff_2eemitc_2enumbersOf(a_0, a_1)); heff_drop_tag(v_t_2418, 2); r_; });
    V v_t_2420 = (g_heff_2eemitc_2edeclOf(heff_dup(v_ce_244), heff_dup(g_heff_2elower_2eentryKey_get())));
    V v_t_2421 = (g_list_2emap_24s1711626084x463433445(v_provs_241));
    V v_t_2422 = heff_tr(heff_apply(heff_get(v_ending_242, LBL_end), 1, (V[]){heff_dup(v_ce_244)}));
    V v_t_2423 = (g_list_2emap_24s1339179958x587003135(v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2424));
    V v_x2_2426 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str6), (g_prelude_2e_2b_2b(v_t_2419, v_t_2425))});
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2eemitc_2epartsWith_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2eemitc_2epartsWith_str8); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str9), NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str10), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str11), v_t_2430})});
    V v_t_2432 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_shapes)));
    V v_t_2433 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_prims)));
    V v_t_2434 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_strs)));
    V v_t_2435 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_protos)));
    V v_t_2436 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_lams)));
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2emodulePart_clo), 8, (V[]){v_t_2431, v_ce_244, v_s_247, v_t_2432, v_t_2433, v_t_2434, v_t_2435, v_t_2436}));
    V v_ps_2438 = (g_heff_2eemitc_2ezipDE(v_defs_243, v_ems_246));
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2438));
    V v_m_2440 = (g_list_2efoldl_24s153737048x1104410749(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_map_2eempty_get()), v_t_2439));
    V v_t_2441 = ({ V a_0 = v_m_2440; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2440); r_; });
    V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2eemitc_2eentryPart_get()), v_t_2429}), (g_list_2emap(v_t_2437, v_t_2441))});
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str12), v_t_2414}), v_t_2442});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2eemitc_2eprogramParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprogramParts_entry, 4, 0};

V g_heff_2eemitc_2eprogramParts(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243) {
top: ;
  V v_es_244 = (g_list_2emap_24s242536205x1745537053(heff_dup(v_defs_243)));
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_244));
  V v_t_247 = (g_list_2efoldl_24s1127955551x950394381(v_t_245, v_t_246));
  V v_ce_248 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_defs_243; V a_2 = v_t_247; V r_ = (g_heff_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_248)}));
  V v_t_2410 = (g_heff_2eemitc_2etraverseC(v_t_249, heff_dup(v_defs_243)));
  V v_t_2411 = heff_tr(heff_apply(v_t_2410, 1, (V[]){heff_dup(g_heff_2eemitc_2eemptyCS_get())}));
  return (g_heff_2eemitc_2epartsWith(v_runtime_240, v_provs_241, v_ending_242, v_defs_243, v_ce_248, v_t_2411));
}
V g_heff_2eemitc_2eprogramParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprogramParts(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eemitc_2eoutputOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eoutputOf_entry, 4, 0};

V g_heff_2eemitc_2eoutputOf(V v_runtime_240, V v_provs_241, V v_ending_242, V v_l_243) {
top: ;
  V v_defs_244 = heff_get(heff_dup(v_l_243), LBL_defs);
  V v_es_245 = (g_list_2emap_24s242536205x1745537053(heff_dup(v_defs_244)));
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_245));
  V v_names_248 = (g_list_2efoldl_24s1127955551x950394381(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_defs_244; V a_2 = v_names_248; V r_ = (g_heff_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_248); r_; });
  V v_t_2410 = (g_heff_2eemitc_2eprogramCE(v_runtime_240, v_provs_241, v_ending_242, v_defs_244, v_t_249));
  return heff_rec(2, shape_source__errors, (V[]){v_t_2410, heff_get(v_l_243, LBL_errors)});
}
V g_heff_2eemitc_2eoutputOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eoutputOf(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckOut_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {35, 100, 101, 102, 105, 110, 101, 32, 72, 69, 70, 70, 95, 67, 72, 69, 67, 75}};
Clo g_heff_2eemitc_2echeckOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2echeckOut_entry, 3, 0};

V g_heff_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckOut_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2echeckEnd_clo), 2, (V[]){v_exports_241, heff_get(heff_dup(v_l_242), LBL_defs)}));
  V v_ending_245 = heff_rec(2, shape_prefix__end, (V[]){v_t_243, v_t_244});
  V v_defs_246 = heff_get(heff_dup(v_l_242), LBL_defs);
  V v_es_247 = (g_list_2emap_24s242536205x1745537053(heff_dup(v_defs_246)));
  V v_t_248 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
  V v_names_2410 = (g_list_2efoldl_24s1127955551x950394381(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_defs_246; V a_2 = v_names_2410; V r_ = (g_heff_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_2410); r_; });
  V v_t_2412 = (g_heff_2eemitc_2eprogramCE(v_runtime_240, NTAG(TAG_Nil), v_ending_245, v_defs_246, v_t_2411));
  return heff_rec(2, shape_source__errors, (V[]){v_t_2412, heff_get(v_l_242, LBL_errors)});
}
V g_heff_2eemitc_2echeckOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2echeckOut(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ecatMaybesC_entry, 1, 0};

V g_heff_2eemitc_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eemitc_2ecatMaybesC(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ecatMaybesC(a[0]);
}