// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eemitc_2eisAlnum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eisAlnum_entry, 1, 0};

V g_heff_2eemitc_2eisAlnum(V v_c_240) {
top: ;
  V v_t_241 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_243 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        V v_t_244 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          V v_t_245 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            return heff_intLe(v_c_240, MK_INT(57LL));
          }
          case TAG_False: {
            heff_drop(v_c_240);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      case TAG_False: {
        V v_t_246 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          return heff_intLe(v_c_240, MK_INT(57LL));
        }
        case TAG_False: {
          heff_drop(v_c_240);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_False: {
    V v_t_247 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_249 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          return heff_intLe(v_c_240, MK_INT(57LL));
        }
        case TAG_False: {
          heff_drop(v_c_240);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_False: {
      V v_t_2410 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        return heff_intLe(v_c_240, MK_INT(57LL));
      }
      case TAG_False: {
        heff_drop(v_c_240);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2eisAlnum_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eisAlnum(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2emangleChar_str0 = {{0x80000000u, K_STR, 0}, 16, 16, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2emangleChar_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2emangleChar_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2eemitc_2emangleChar(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2eemitc_2eisAlnum(heff_dup(v_c_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    return heff_strFromCharCode(v_c_240);
  }
  case TAG_False: {
    V v_t_242 = heff_intMod(heff_dup(v_c_240), MK_INT(256LL));
    V v_d_243 = heff_intDiv(v_t_242, MK_INT(16LL));
    V v_t_244 = heff_strSlice(((V)&g_heff_2eemitc_2emangleChar_str0), heff_dup(v_d_243), heff_intAdd(v_d_243, MK_INT(1LL)));
    V v_d_245 = heff_intMod(v_c_240, MK_INT(16LL));
    V v_t_246 = heff_strSlice(((V)&g_heff_2eemitc_2emangleChar_str1), heff_dup(v_d_245), heff_intAdd(v_d_245, MK_INT(1LL)));
    return heff_strAppend(((V)&g_heff_2eemitc_2emangleChar_str2), heff_strAppend(v_t_244, v_t_246));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2emangleChar(a[0]);
}
Clo g_heff_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_intLt(heff_dup(v_j_242), heff_strLength(heff_dup(v_s_240)));
  V v_t_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_t_245 = (g_heff_2eemitc_2eisAlnum(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_242))));
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V t_0 = v_s_240;
    V t_1 = v_i_241;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_acc_243;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  case TAG_False: {
    V v_t_246 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_j_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_strAppend(v_acc_243, heff_strSlice(v_s_240, v_i_241, v_j_242));
    }
    case TAG_False: {
      V v_t_247 = heff_strAppend(v_acc_243, heff_strAppend(heff_strSlice(heff_dup(v_s_240), v_i_241, heff_dup(v_j_242)), (g_heff_2eemitc_2emangleChar(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_242))))));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL));
      V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
      V t_3 = v_t_247;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2emangleW(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eknownTags_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 82}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eknownTags_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {77, 107, 80, 97, 105, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eknownTags_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eknownTags_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {74, 117, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2eknownTags_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {78, 111, 116, 104, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eknownTags_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eknownTags_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {77, 107, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eknownTags_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eknownTags_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eknownTags_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};

static V g_heff_2eemitc_2eknownTags_val;
static int g_heff_2eemitc_2eknownTags_st;
static V g_heff_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2eemitc_2eknownTags_get(void) {
  if (g_heff_2eemitc_2eknownTags_st == 2) return g_heff_2eemitc_2eknownTags_val;
  if (g_heff_2eemitc_2eknownTags_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2eknownTags_st = 1;
  g_heff_2eemitc_2eknownTags_val = heff_tr(g_heff_2eemitc_2eknownTags_init());
  g_heff_2eemitc_2eknownTags_st = 2;
  return g_heff_2eemitc_2eknownTags_val;
}
Clo g_heff_2eemitc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eelemS_entry, 2, 0};

V g_heff_2eemitc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eelemS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eelemS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_prelude_2efoldl_24s619(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_prelude_2efoldl_24s619(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_ls_2416 = (g_prelude_2emap_24s618(heff_dup(v_fs_2415)));
    V v_es_2417 = (g_prelude_2emap_24s513(v_fs_2415));
    V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_es_2417));
    V v_x2_2420 = (g_prelude_2efoldl_24s619(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, (g_prelude_2econcatList(v_ls_2416, v_ls2_2422))});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2423 = heff_field(v_x1_240, 0);
    V v_l_2424 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EProj = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_2425 = (g_heff_2eemitc_2etagsLbls(v_e_2423));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_ts_2426 = heff_field(v_x2_2425, 0);
      V v_ls2_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
      V v_t_2428 = heff_tag_at(v_ru_24x1_240_24EProj, TAG_Cons, 2, (V[]){v_l_2424, NTAG(TAG_Nil)});
      return heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2426, (g_prelude_2econcatList(v_t_2428, v_ls2_2427))});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  case TAG_ETag: {
    V v_t_2429 = heff_field(v_x1_240, 0);
    V v_as_2430 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2431 = heff_tag_at(v_ru_24x1_240_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2432 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_2430));
    V v_x2_2433 = (g_prelude_2efoldl_24s619(v_t_2431, v_t_2432));
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_MkPair: {
      V v_ts2_2434 = heff_field(v_x2_2433, 0);
      V v_ls_2435 = heff_field(v_x2_2433, 1);
      V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
      V v_t_2436 = heff_tag_at(v_ru_24x2_2433_24MkPair, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
      V v_t_2437 = (g_prelude_2econcatList(v_t_2436, v_ts2_2434));
      return heff_tag(TAG_MkPair, 2, (V[]){v_t_2437, v_ls_2435});
    }
    default: return heff_nomatch(v_x2_2433);
    }
  }
  case TAG_EMatch: {
    V v_s_2438 = heff_field(v_x1_240, 0);
    V v_arms_2439 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2440 = (g_prelude_2emap_24s617(heff_dup(v_arms_2439)));
    V v_es_2441 = heff_tag_at(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2438, (g_prelude_2emap_24s515(v_arms_2439))});
    V v_t_2442 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2443 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_es_2441));
    V v_x2_2444 = (g_prelude_2efoldl_24s619(v_t_2442, v_t_2443));
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_MkPair: {
      V v_ts2_2445 = heff_field(v_x2_2444, 0);
      V v_ls_2446 = heff_field(v_x2_2444, 1);
      V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
      V v_t_2447 = (g_prelude_2econcatList(v_ts_2440, v_ts2_2445));
      return heff_tag_at(v_ru_24x2_2444_24MkPair, TAG_MkPair, 2, (V[]){v_t_2447, v_ls_2446});
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2450 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2451 = heff_tag_at(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2452 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_2450));
    return (g_prelude_2efoldl_24s619(v_t_2451, v_t_2452));
  }
  case TAG_ECall: {
    V v_as_2454 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2455 = heff_tag_at(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2456 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_2454));
    return (g_prelude_2efoldl_24s619(v_t_2455, v_t_2456));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  V v_t_243 = heff_intLt(heff_dup(v_i_242), heff_strLength(heff_dup(v_text_240)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_heff_2eemitc_2eisAlnum(heff_strCharCode(heff_dup(v_text_240), heff_dup(v_i_242))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    case TAG_False: {
      V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_text_240), heff_dup(v_i_242)), MK_INT(95LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      }
      case TAG_False: {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_text_241), heff_dup(v_i_242), heff_strLength(heff_dup(v_text_241)));
  V v_t_245 = (g_prelude_2eindexFrom(heff_dup(v_pre_240), v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_pre_240);
    heff_drop(v_text_241);
    heff_drop(v_i_242);
    return v_acc_243;
  }
  case TAG_Just: {
    V v_j_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_248 = heff_intAdd(heff_intAdd(heff_dup(v_i_242), heff_dup(v_j_246)), heff_strLength(heff_dup(v_pre_240)));
    V v_t_249 = heff_intAdd(heff_intAdd(v_i_242, v_j_246), heff_strLength(heff_dup(v_pre_240)));
    V v_t_2410 = (g_heff_2eemitc_2eidentAt(heff_dup(v_text_241), v_t_248, v_t_249));
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_247;
    V t_3 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2enamesInGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_x3_245 = (g_map_2elookup_24s9(heff_dup(v_x_243), v_m_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s7(heff_dup(v_x_243), heff_dup(v_n_240), v_m_242));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_t_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V t_0 = v_n_240;
      V t_1 = v_xs_244;
      V t_2 = v_m_242;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2enumbered(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2etraverseC_lam0(V self, V *args); static Clo g_heff_2eemitc_2etraverseC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etraverseC_lam0, 1, 0};
V g_heff_2eemitc_2etraverseC_lam1(V self, V *args);
Clo g_heff_2eemitc_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etraverseC_entry, 2, 0};

V g_heff_2eemitc_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eemitc_2etraverseC_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo(g_heff_2eemitc_2etraverseC_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2etraverseC(a[0], a[1]);
}
V g_heff_2eemitc_2etraverseC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2eemitc_2etraverseC_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2eemitc_2etraverseC(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_apply(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estrDef_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estrDef_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eemitc_2estrDef_str2 = {{0x80000000u, K_STR, 0}, 60, 60, {115, 116, 97, 116, 105, 99, 32, 115, 116, 114, 117, 99, 116, 32, 123, 32, 79, 98, 106, 32, 104, 59, 32, 105, 110, 116, 54, 52, 95, 116, 32, 108, 101, 110, 59, 32, 105, 110, 116, 54, 52, 95, 116, 32, 99, 97, 112, 59, 32, 117, 105, 110, 116, 49, 54, 95, 116, 32, 115, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2estrDef_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {93, 59, 32, 125, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eemitc_2estrDef_str4 = {{0x80000000u, K_STR, 0}, 29, 29, {32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 83, 84, 82, 44, 32, 48, 125, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estrDef_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estrDef_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {44, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estrDef_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {125, 125, 59}};
V g_heff_2eemitc_2estrDef_lam0(V self, V *args);
Clo g_heff_2eemitc_2estrDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2estrDef_entry, 2, 0};

V g_heff_2eemitc_2estrDef(V v_name_240, V v_str_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strLength(heff_dup(v_str_241)), MK_INT(0LL));
  V v_t_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_t_243 = MK_INT(1LL);
    break;
  }
  case TAG_False: {
    v_t_243 = heff_strLength(heff_dup(v_str_241));
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_244 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
  V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
  V v_t_246 = heff_intEq(heff_strLength(heff_dup(v_str_241)), MK_INT(0LL));
  V v_t_2413;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_str_241);
    v_t_2413 = ((V)&g_heff_2eemitc_2estrDef_str0);
    break;
  }
  case TAG_False: {
    V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_str_241)), MK_INT(1LL));
    V v_t_248 = (g_prelude_2erange(MK_INT(0LL), v_t_247));
    V v_x2_2410 = (g_prelude_2emap(heff_clo(g_heff_2eemitc_2estrDef_lam0, 1, 1, (V[]){v_str_241}), v_t_248));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2eemitc_2estrDef_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str2), heff_strAppend(heff_intShow(v_t_243), heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str3), heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str4), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str5), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemitc_2estrDef_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2eemitc_2estrDef_str7)))))))))));
}
V g_heff_2eemitc_2estrDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2estrDef(a[0], a[1]);
}
V g_heff_2eemitc_2estrDef_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_str_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intShow(heff_strCharCode(v_str_241, v_i_249));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2estrLit_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estrLit_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estrLit_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estrLit_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 115, 116, 114}};
Clo g_heff_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2estrLit_entry, 2, 0};

V g_heff_2eemitc_2estrLit(V v_str_240, V v_s_241) {
top: ;
  V v_t_242 = heff_intShow(heff_get(heff_dup(v_s_241), LBL_nstr));
  V v_t_243 = heff_strAppend(((V)&g_heff_2eemitc_2estrLit_str0), heff_strAppend(heff_get(heff_dup(v_s_241), LBL_owner), heff_strAppend(((V)&g_heff_2eemitc_2estrLit_str1), heff_strAppend(v_t_242, ((V)&g_heff_2eemitc_2estrLit_str2)))));
  V v_t_244 = heff_intAdd(heff_get(heff_dup(v_s_241), LBL_nstr), MK_INT(1LL));
  V v_t_245 = heff_intShow(heff_get(heff_dup(v_s_241), LBL_nstr));
  V v_t_246 = heff_strAppend(heff_get(heff_dup(v_s_241), LBL_owner), heff_strAppend(((V)&g_heff_2eemitc_2estrLit_str3), v_t_245));
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), (g_heff_2eemitc_2estrDef(v_t_246, v_str_240))});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, heff_get(heff_dup(v_s_241), LBL_strs)});
  V v_t_249 = heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), heff_get(heff_dup(v_s_241), LBL_nlam), heff_get(heff_dup(v_s_241), LBL_lams), heff_get(heff_dup(v_s_241), LBL_protos), v_t_244, v_t_248, heff_get(heff_dup(v_s_241), LBL_shapes), heff_get(v_s_241, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_243, v_t_249});
}
V g_heff_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2estrLit(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eshapeLit_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eshapeLit_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eshapeLit_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2eshapeLit_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 104, 97, 112, 101, 95}};
Clo g_heff_2eemitc_2eshapeLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eshapeLit_entry, 2, 0};

V g_heff_2eemitc_2eshapeLit(V v_ids_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_prelude_2emap(heff_dup(g_prelude_2eshowInt_get()), heff_dup(v_ids_240)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2eemitc_2eshapeLit_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_246 = (g_prelude_2emap(heff_dup(g_prelude_2eshowInt_get()), heff_dup(v_ids_240)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2eemitc_2eshapeLit_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = ({ V a_0 = v_t_249; V b_1 = heff_get(heff_dup(v_s_241), LBL_shapes); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_ids_240);
    v_t_2415 = heff_get(heff_dup(v_s_241), LBL_shapes);
    break;
  }
  case TAG_False: {
    V v_x2_2411 = (g_prelude_2emap(heff_dup(g_prelude_2eshowInt_get()), v_ids_240));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2eemitc_2eshapeLit_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = v_x_2412; V a_1 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, heff_get(heff_dup(v_s_241), LBL_shapes)});
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2416 = heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), heff_get(heff_dup(v_s_241), LBL_nlam), heff_get(heff_dup(v_s_241), LBL_lams), heff_get(heff_dup(v_s_241), LBL_protos), heff_get(heff_dup(v_s_241), LBL_nstr), heff_get(heff_dup(v_s_241), LBL_strs), v_t_2415, heff_get(v_s_241, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2eemitc_2eshapeLit_str3), v_t_245), v_t_2416});
}
V g_heff_2eemitc_2eshapeLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eshapeLit(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2eprimLit_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 40, 86, 41, 38, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eprimLit_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
Clo g_heff_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2eemitc_2eprimLit_str0), heff_strAppend(heff_dup(v_p_240), ((V)&g_heff_2eemitc_2eprimLit_str1)));
  V v_t_243 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_get(heff_dup(v_s_241), LBL_prims); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_p_240);
    v_t_244 = heff_get(heff_dup(v_s_241), LBL_prims);
    break;
  }
  case TAG_False: {
    v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_p_240, heff_get(heff_dup(v_s_241), LBL_prims)});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){heff_get(heff_dup(v_s_241), LBL_owner), heff_get(heff_dup(v_s_241), LBL_nlam), heff_get(heff_dup(v_s_241), LBL_lams), heff_get(heff_dup(v_s_241), LBL_protos), heff_get(heff_dup(v_s_241), LBL_nstr), heff_get(heff_dup(v_s_241), LBL_strs), heff_get(v_s_241, LBL_shapes), v_t_244});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_242, v_t_245});
}
V g_heff_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprimLit(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2enewLam_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 108, 97, 109}};
Clo g_heff_2eemitc_2enewLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2enewLam_entry, 1, 0};

V g_heff_2eemitc_2enewLam(V v_s_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get(heff_dup(v_s_240), LBL_nlam));
  V v_t_242 = heff_strAppend(heff_get(heff_dup(v_s_240), LBL_owner), heff_strAppend(((V)&g_heff_2eemitc_2enewLam_str0), v_t_241));
  V v_t_243 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_nlam), MK_INT(1LL));
  V v_t_244 = heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){heff_get(heff_dup(v_s_240), LBL_owner), v_t_243, heff_get(heff_dup(v_s_240), LBL_lams), heff_get(heff_dup(v_s_240), LBL_protos), heff_get(heff_dup(v_s_240), LBL_nstr), heff_get(heff_dup(v_s_240), LBL_strs), heff_get(heff_dup(v_s_240), LBL_shapes), heff_get(v_s_240, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_242, v_t_244});
}
V g_heff_2eemitc_2enewLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2enewLam(a[0]);
}
Clo g_heff_2eemitc_2eaddLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eaddLam_entry, 3, 0};

V g_heff_2eemitc_2eaddLam(V v_proto_240, V v_def_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_s_242), LBL_owner), v_def_241});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_get(heff_dup(v_s_242), LBL_lams)});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_s_242), LBL_owner), v_proto_240});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_get(heff_dup(v_s_242), LBL_protos)});
  V v_t_247 = heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){heff_get(heff_dup(v_s_242), LBL_owner), heff_get(heff_dup(v_s_242), LBL_nlam), v_t_244, v_t_246, heff_get(heff_dup(v_s_242), LBL_nstr), heff_get(heff_dup(v_s_242), LBL_strs), heff_get(heff_dup(v_s_242), LBL_shapes), heff_get(v_s_242, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2eemitc_2eaddLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eaddLam(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2efvW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efvW_entry, 3, 0};

V g_heff_2eemitc_2efvW(V v_bs_240, V v_ms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_bs_240, v_ms_241});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_x_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V t_0 = v_bs_240;
      V t_1 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_ms_241});
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_249 = (g_prelude_2econcatList(v_xs_247, v_bs_240));
      V t_0 = v_t_249;
      V t_1 = v_ms_241;
      V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x31_243, 0);
      V v_as_2411 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2412 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, (g_prelude_2econcatList(v_as_2411, v_rest_244))});
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2412;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2413 = heff_field(v_x31_243, 0);
      V v_a_2414 = heff_field(v_x31_243, 1);
      V v_b_2415 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2416 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
      V t_0 = heff_tag(TAG_Cons, 2, (V[]){v_x_2413, v_bs_240});
      V t_1 = v_ms_241;
      V t_2 = v_t_2416;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2eir_2epushFields(v_fs_2417, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2418;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2422 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2423 = (g_prelude_2econcatList(v_as_2422, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2423;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2424 = heff_field(v_x31_243, 0);
      V v_arms_2425 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2426 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_arms_2425)));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_prelude_2efoldl_24s620(a_0, a_1)); heff_drop(v_t_2426); r_; });
      V v_t_2428 = (g_prelude_2econcatList(v_t_2427, v_bs_240));
      V v_t_2429 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2424, (g_heff_2eir_2epushArms(v_arms_2425, v_rest_244))});
      V t_0 = v_t_2428;
      V t_1 = v_ms_241;
      V t_2 = v_t_2429;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2432 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2433 = (g_prelude_2econcatList(v_as_2432, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2433;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2435 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2436 = (g_prelude_2econcatList(v_as_2435, v_rest_244));
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_t_2436;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_ms_241;
      V t_2 = v_rest_244;
      v_bs_240 = t_0;
      v_ms_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2efvW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2efvW(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efreeGo_entry, 4, 0};

V g_heff_2eemitc_2efreeGo(V v_bs_240, V v_seen_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s9(heff_dup(v_v_244), v_bs_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_x3_247 = (g_map_2elookup_24s9(heff_dup(v_v_244), v_seen_241));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        V v_t_248 = (g_map_2einsert_24s7(heff_dup(v_v_244), NTAG(TAG_MkUnit), v_seen_241));
        V t_0 = v_bs_240;
        V t_1 = v_t_248;
        V t_2 = v_vs_245;
        V t_3 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_v_244, v_acc_243});
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_seen_241;
        V t_2 = v_vs_245;
        V t_3 = v_acc_243;
        v_bs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_seen_241;
      V t_2 = v_vs_245;
      V t_3 = v_acc_243;
      v_bs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2efreeGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efreeGo(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2efreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efreeOf_entry, 2, 0};

V g_heff_2eemitc_2efreeOf(V v_xs_240, V v_b_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){v_b_241, NTAG(TAG_Nil)});
  V v_x2_243 = (g_heff_2eemitc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_bs_244 = heff_field(v_x2_243, 0);
    V v_ms_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_bs_246 = (g_prelude_2econcatList(v_xs_240, v_bs_244));
    V v_ms_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ms_245));
    V v_t_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_246; V r_ = (g_prelude_2efoldl_24s606(a_0, a_1)); heff_drop(v_bs_246); r_; });
    return ({ V a_0 = v_t_248; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_247; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2eemitc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2eemitc_2efreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2efreeOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evarUse_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evarUse_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 100, 117, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evarUse_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evarUse_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 100, 117, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evarUse_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evarUse_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2evarUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evarUse_entry, 3, 0};

V g_heff_2eemitc_2evarUse(V v_lent_240, V v_live_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_live_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evarUse_str1))));
    return heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eemitc_2evarUse_str3)));
  }
  case TAG_False: {
    V v_t_245 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_lent_240));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str4), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evarUse_str5))));
      return heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str6), heff_strAppend(v_t_246, ((V)&g_heff_2eemitc_2evarUse_str7)));
    }
    case TAG_False: {
      return heff_strAppend(((V)&g_heff_2eemitc_2evarUse_str8), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evarUse_str9))));
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2evarUse_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2evarUse(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edropAs_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2edropAs_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 116, 97, 103, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edropAs_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemitc_2edropAs_str7 = {{0x80000000u, K_STR, 0}, 15, 15, {104, 101, 102, 102, 95, 100, 114, 111, 112, 95, 99, 101, 108, 108, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropAs_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemitc_2edropAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edropAs_entry, 2, 0};

V g_heff_2eemitc_2edropAs(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_KnownTag: {
    V v_n_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_intEq(heff_dup(v_n_242), MK_INT(0LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      V v_t_244 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str0), (g_heff_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edropAs_str1))));
      V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str2), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str3), heff_strAppend(heff_intShow(heff_dup(v_n_242)), ((V)&g_heff_2eemitc_2edropAs_str4)))));
      return heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_KnownCell: {
    V v_n_246 = heff_field(v_x2_241, 0);
    V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str5), (g_heff_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edropAs_str6))));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str7), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemitc_2edropAs_str8), heff_strAppend(heff_intShow(heff_dup(v_n_246)), ((V)&g_heff_2eemitc_2edropAs_str9)))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2edropAs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2edropAs(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropsIn_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edropsIn_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2edropsIn_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edropsIn_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
V g_heff_2eemitc_2edropsIn_lam0(V self, V *args);
Clo g_heff_2eemitc_2edropsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edropsIn_entry, 2, 0};

V g_heff_2eemitc_2edropsIn(V v_ce_240, V v_xs_241) {
top: ;
  V v_t_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2edropsIn_lam0, 2, 1, (V[]){v_ce_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eemitc_2edropsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edropsIn(a[0], a[1]);
}
V g_heff_2eemitc_2edropsIn_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_245 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get(v_ce_240, LBL_known); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2edropsIn_str0), (g_heff_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edropsIn_str1))));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2edropsIn_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eemitc_2edropsIn_str3)));
    v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_k_248 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return (g_prelude_2econcatList(v_t_249, v_acc_243));
}
Clo g_heff_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_240), heff_dup(v_j_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eelemI(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentVar_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentVar_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentVar_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentVar_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentVar_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentVar_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2elentVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentVar_entry, 3, 0};

V g_heff_2eemitc_2elentVar(V v_ce_240, V v_live_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_live_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_ce_240);
    V v_v_244 = heff_strAppend(((V)&g_heff_2eemitc_2elentVar_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elentVar_str1))));
    return heff_rec(3, shape_12_251_249, (V[]){v_v_244, NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_False: {
    V v_t_245 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_ce_240), LBL_borrowed); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_ce_240);
      V v_v_246 = heff_strAppend(((V)&g_heff_2eemitc_2elentVar_str2), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elentVar_str3))));
      return heff_rec(3, shape_12_251_249, (V[]){v_v_246, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_False: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2elentVar_str4), (g_heff_2eemitc_2emangleW(heff_dup(v_x_242), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2elentVar_str5))));
      V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2eemitc_2edropsIn(v_ce_240, v_t_248));
      return heff_rec(3, shape_12_251_249, (V[]){v_t_247, NTAG(TAG_Nil), v_t_249});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2elentVar_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentVar(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2ecallText_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 95, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2ecallText_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 95, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecallText_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ecallText_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {40, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2ecallText_str15 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 86, 32, 114, 95, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecallText_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ecallText_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 41, 59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2ecallText_str18 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 114, 95, 59, 32, 125, 41}};
Clo g_heff_2eemitc_2ecallText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ecallText_entry, 3, 0};

V g_heff_2eemitc_2ecallText(V v_g_240, V v_tr_241, V v_ls_242) {
top: ;
  V v_t_243 = (g_prelude_2eall_24s623(v_ls_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244;
    switch (heff_tag_of(v_tr_241)) {
    case TAG_True: {
      v_t_244 = ((V)&g_heff_2eemitc_2ecallText_str0);
      break;
    }
    case TAG_False: {
      v_t_244 = ((V)&g_heff_2eemitc_2ecallText_str1);
      break;
    }
    default: heff_nomatch(v_tr_241);
    }
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str2), (g_heff_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ecallText_str3))));
    V v_x2_246 = (g_prelude_2emap_24s624(v_ls_242));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eemitc_2ecallText_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(v_t_244, heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str5), heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2ecallText_str6)))));
  }
  case TAG_False: {
    V v_t_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ls_242));
    V v_t_2411 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_ordered_2412 = (g_prelude_2ezipWith_24s625(v_ls_242, v_t_2411));
    V v_t_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_ordered_2412)));
    V v_x2_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_prelude_2efoldl_24s626(a_0, a_1)); heff_drop(v_t_2413); r_; });
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2eemitc_2ecallText_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = v_x_2415; V a_1 = v_xs_2416; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2418;
    switch (heff_tag_of(v_tr_241)) {
    case TAG_True: {
      v_t_2418 = ((V)&g_heff_2eemitc_2ecallText_str8);
      break;
    }
    case TAG_False: {
      v_t_2418 = ((V)&g_heff_2eemitc_2ecallText_str9);
      break;
    }
    default: heff_nomatch(v_tr_241);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str10), (g_heff_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ecallText_str11))));
    V v_x2_2420 = (g_prelude_2emap_24s624(heff_dup(v_ordered_2412)));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2eemitc_2ecallText_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = v_x_2421; V a_1 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ordered_2412));
    V v_x2_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_prelude_2efoldl_24s627(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2eemitc_2ecallText_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    return heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str14), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str15), heff_strAppend(v_t_2418, heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str16), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eemitc_2ecallText_str17), heff_strAppend(v_t_2428, ((V)&g_heff_2eemitc_2ecallText_str18))))))))));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2ecallText_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ecallText(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamLines_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2elamLines_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2elamLines_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 32, 104, 101, 102, 102, 95, 99, 108, 111, 95, 116, 97, 107, 101, 40, 115, 101, 108, 102, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamLines_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamLines_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
Clo g_heff_2eemitc_2elamLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elamLines_entry, 5, 0};

V g_heff_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_dead_243, V v_body_244) {
top: ;
  V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2elamLines_str0), heff_strAppend(v_k_240, ((V)&g_heff_2eemitc_2elamLines_str1)));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
  V v_t_248 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
  V v_t_249 = (g_prelude_2ezipWith_24s628(v_xs_241, v_t_248));
  V v_t_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_fv_242));
  V v_t_2411 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
  V v_t_2412 = (g_prelude_2ezipWith_24s629(heff_dup(v_fv_242), v_t_2411));
  V v_t_2417;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = v_fv_242; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2elamLines_str2), heff_strAppend(heff_intShow(v_t_2415), ((V)&g_heff_2eemitc_2elamLines_str3)));
    v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2418 = (g_prelude_2emap_24s622(v_dead_243));
  V v_t_2419 = (g_prelude_2emap_24s177(v_t_2418));
  V v_t_2420 = (g_prelude_2emap_24s177(v_body_244));
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2elamLines_str4), NTAG(TAG_Nil)});
  V v_t_2422 = (g_prelude_2econcatList(v_t_2420, v_t_2421));
  V v_t_2423 = (g_prelude_2econcatList(v_t_2419, v_t_2422));
  V v_t_2424 = (g_prelude_2econcatList(v_t_2417, v_t_2423));
  V v_t_2425 = (g_prelude_2econcatList(v_t_2412, v_t_2424));
  V v_t_2426 = (g_prelude_2econcatList(v_t_249, v_t_2425));
  return (g_prelude_2econcatList(v_t_246, v_t_2426));
}
V g_heff_2eemitc_2elamLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elamLines(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2ereusePrim_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 114, 101, 117, 115, 101}};

static V g_heff_2eemitc_2ereusePrim_val;
static int g_heff_2eemitc_2ereusePrim_st;
static V g_heff_2eemitc_2ereusePrim_init(void) {
  return ((V)&g_heff_2eemitc_2ereusePrim_str0);
}
V g_heff_2eemitc_2ereusePrim_get(void) {
  if (g_heff_2eemitc_2ereusePrim_st == 2) return g_heff_2eemitc_2ereusePrim_val;
  if (g_heff_2eemitc_2ereusePrim_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2ereusePrim_st = 1;
  g_heff_2eemitc_2ereusePrim_val = heff_tr(g_heff_2eemitc_2ereusePrim_init());
  g_heff_2eemitc_2ereusePrim_st = 2;
  return g_heff_2eemitc_2ereusePrim_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eagain_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {103, 111, 116, 111, 32, 116, 111, 112, 59}};
Clo g_heff_2eemitc_2eagain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eagain_entry, 2, 0};

V g_heff_2eemitc_2eagain(V v_ce_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_get(v_ce_240, LBL_self);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_vs_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_241));
    V v_t_245 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
    V v_t_246 = (g_prelude_2ezipWith_24s630(heff_dup(v_vs_241), v_t_245));
    V v_t_247 = ({ V a_0 = MK_INT(0LL); V a_1 = v_vs_241; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_vs_241); r_; });
    V v_t_248 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    V v_t_249 = (g_prelude_2ezipWith_24s631(heff_get(v_s_243, LBL_params), v_t_248));
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eagain_str0), NTAG(TAG_Nil)});
    V v_t_2411 = (g_prelude_2econcatList(v_t_249, v_t_2410));
    HEFF_LAST return g_prelude_2econcatList(v_t_246, v_t_2411);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2eagain_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eagain(a[0], a[1]);
}
Clo g_heff_2eemitc_2eagrees_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eagrees_entry, 3, 0};

V g_heff_2eemitc_2eagrees(V v_ce_240, V v_g_241, V v_as_242) {
top: ;
  V v_m_243 = ({ V a_0 = v_g_241; V b_1 = heff_get(heff_dup(v_ce_240), LBL_funs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_n_244 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_242));
  V v_t_245 = heff_get(v_ce_240, LBL_self);
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_m_243);
    heff_drop(v_n_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_s_246, LBL_params); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_248 = heff_intEq(v_t_247, heff_dup(v_n_244));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      switch (heff_tag_of(v_m_243)) {
      case TAG_Nothing: {
        heff_drop(v_n_244);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_m_249 = heff_field(v_m_243, 0);
        heff_take_n(v_m_243, 1ULL, 1);
        return heff_intEq(v_n_244, v_m_249);
      }
      default: return heff_nomatch(v_m_243);
      }
    }
    case TAG_False: {
      heff_drop(v_m_243);
      heff_drop(v_n_244);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2eagrees_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eagrees(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2einPlace_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2einPlace_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {86, 32, 102, 95, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2einPlace_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2einPlace_str3 = {{0x80000000u, K_STR, 0}, 19, 19, {105, 102, 32, 40, 104, 101, 102, 102, 95, 101, 120, 97, 99, 116, 40, 102, 95, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2eemitc_2einPlace_str4 = {{0x80000000u, K_STR, 0}, 52, 52, {44, 32, 97, 114, 103, 115, 41, 41, 32, 72, 69, 70, 70, 95, 76, 65, 83, 84, 32, 114, 101, 116, 117, 114, 110, 32, 40, 40, 67, 108, 111, 32, 42, 41, 102, 95, 41, 45, 62, 102, 110, 40, 102, 95, 44, 32, 97, 114, 103, 115, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2einPlace_str5 = {{0x80000000u, K_STR, 0}, 21, 21, {114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 116, 97, 105, 108, 40, 102, 95, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2einPlace_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 97, 114, 103, 115, 41, 59}};
Clo g_heff_2eemitc_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2einPlace_entry, 1, 0};

V g_heff_2eemitc_2einPlace(V v_vs_240) {
top: ;
  V v_x2_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_x2_243 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_vs_240, 0));
    v_x2_243 = heff_tag(TAG_Just, 1, (V[]){v_x_241});
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2eemitc_2einPlace_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2einPlace_str1), heff_strAppend(v_t_245, ((V)&g_heff_2eemitc_2einPlace_str2)));
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2edrop(MK_INT(1LL), heff_dup(v_vs_240)));
  V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_240));
  V v_t_2410 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(2LL))));
  V v_t_2411 = (g_prelude_2ezipWith_24s632(v_t_248, v_t_2410));
  V v_t_2412 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_240));
  V v_t_2413 = heff_intShow(heff_intSub(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2eemitc_2einPlace_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2eemitc_2einPlace_str4)));
  V v_t_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = v_vs_240; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_vs_240); r_; });
  V v_t_2416 = heff_intShow(heff_intSub(v_t_2415, MK_INT(1LL)));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2eemitc_2einPlace_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2eemitc_2einPlace_str6)));
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2econcatList(v_t_2411, heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_t_2418})));
  return (g_prelude_2econcatList(v_t_247, v_t_2419));
}
V g_heff_2eemitc_2einPlace_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2einPlace(a[0]);
}
Clo g_heff_2eemitc_2etakenFv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etakenFv_entry, 4, 0};

V g_heff_2eemitc_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_x1_247 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      heff_drop(v_ce_240);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_248 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_242));
      V v_t_249 = heff_intLe(v_t_248, MK_INT(60LL));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        V v_x1_2410 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_244), v_fb_243));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          heff_drop(v_ce_240);
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          V v_x1_2411 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get(v_ce_240, LBL_after); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_x1_2411)) {
          case TAG_True: {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_False: {
            return heff_tag_at(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_244});
          }
          default: return heff_nomatch(v_x1_2411);
          }
        }
        default: return heff_nomatch(v_x1_2410);
        }
      }
      case TAG_False: {
        heff_drop(v_ce_240);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2etakenFv_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2etakenFv(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efieldLine_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2efieldLine_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efieldLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2efieldLine_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efieldLine_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2efieldLine_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2efieldLine_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efieldLine_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemitc_2efieldLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efieldLine_entry, 4, 0};

V g_heff_2eemitc_2efieldLine(V v_sv_240, V v_plain_241, V v_used_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_i_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2eemitc_2eelemS(heff_dup(v_v_244), v_used_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str0), (g_heff_2eemitc_2emangleW(v_v_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efieldLine_str1))));
      V v_t_248;
      switch (heff_tag_of(v_plain_241)) {
      case TAG_True: {
        v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str2), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str3), heff_strAppend(heff_intShow(v_i_245), ((V)&g_heff_2eemitc_2efieldLine_str4)))));
        break;
      }
      case TAG_False: {
        v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str5), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str6), heff_strAppend(heff_intShow(v_i_245), ((V)&g_heff_2eemitc_2efieldLine_str7)))));
        break;
      }
      default: heff_nomatch(v_plain_241);
      }
      V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str8), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemitc_2efieldLine_str9), heff_strAppend(v_t_248, ((V)&g_heff_2eemitc_2efieldLine_str10)))));
      return heff_tag_at(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      heff_drop(v_sv_240);
      heff_drop(v_v_244);
      heff_drop(v_i_245);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eemitc_2efieldLine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efieldLine(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eemitc_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epow2_entry, 1, 0};

V g_heff_2eemitc_2epow2(V v_n_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  }
  case TAG_False: {
    V v_t_242 = (g_heff_2eemitc_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epow2(a[0]);
}
Clo g_heff_2eemitc_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efieldMask_entry, 3, 0};

V g_heff_2eemitc_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eemitc_2eelemS(heff_dup(v_v_243), v_used_240));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_246 = (g_heff_2eemitc_2epow2(heff_dup(v_i_241)));
      break;
    }
    case TAG_False: {
      v_t_246 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = (g_heff_2eemitc_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2efieldMask_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2efieldMask(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2eemitc_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseArgs_entry, 2, 0};

V g_heff_2eemitc_2ereuseArgs(V v_go_240, V v_es_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return (g_prelude_2efoldl(heff_clo(g_heff_2eemitc_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}), v_t_242, v_es_241));
}
V g_heff_2eemitc_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ereuseArgs(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_e_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_go_240);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), (g_prelude_2econcatList(v_t_2410, v_t_2411))});
  }
  case TAG_False: {
    V v_done_2414;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_done_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_x2_2415 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_244}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_b_2416 = heff_field(v_x2_2415, 0);
      V v_e_2417 = heff_field(v_x2_2415, 1);
      V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
      V v_t_2418 = heff_tag_at(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_e_2417, NTAG(TAG_Nil)});
      return heff_tag(TAG_MkPair, 2, (V[]){v_b_2416, (g_prelude_2econcatList(v_done_2414, v_t_2418))});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
Clo g_heff_2eemitc_2eletReuse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eletReuse_entry, 5, 0};

V g_heff_2eemitc_2eletReuse(V v_go_240, V v_x_241, V v_a_242, V v_b_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_a2_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_True: {
      heff_drop(v_go_240);
      heff_drop(v_a_242);
      return heff_tag_at(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a2_246, v_b_243})});
    }
    case TAG_False: {
      heff_drop(v_a2_246);
      V v_x1_247 = heff_tr(heff_apply(v_go_240, 1, (V[]){heff_dup(v_b_243)}));
      V v_x2_2411;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_MkPair: {
        V v_b_248 = heff_field(v_x1_247, 0);
        V v_e_249 = heff_field(v_x1_247, 1);
        V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
        V v_t_2410 = heff_tag_at(v_ru_24x5_244_24MkPair, TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
        v_x2_2411 = heff_tag_at(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_b_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_b_2412 = heff_field(v_x2_2411, 0);
        V v_es_2413 = heff_field(v_x2_2411, 1);
        V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
        V v_x2_2416;
        switch (heff_tag_of(v_es_2413)) {
        case TAG_Nil: {
          v_x2_2416 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_es_2413, 0);
          heff_take_n(v_es_2413, 1ULL, 2);
          v_x2_2416 = heff_tag(TAG_Just, 1, (V[]){v_x_2414});
          break;
        }
        default: heff_nomatch(v_es_2413);
        }
        V v_t_2418;
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_Nothing: {
          v_t_2418 = v_b_243;
          break;
        }
        case TAG_Just: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          heff_take_n(v_x2_2416, 1ULL, 1);
          heff_drop(v_b_243);
          v_t_2418 = v_x_2417;
          break;
        }
        default: heff_nomatch(v_x2_2416);
        }
        return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_b_2412, heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_t_2418})});
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eemitc_2eletReuse_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eletReuse(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eemitc_2ereuseIn_lam0(V self, V *args);
Clo g_heff_2eemitc_2ereuseIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseIn_entry, 3, 0};

V g_heff_2eemitc_2ereuseIn(V v_ru_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EGlobal: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ELam: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EApp: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuseIn_clo), 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}));
    V v_t_2413 = (g_heff_2eemitc_2ereuseIn(v_ru_240, v_n_241, heff_dup(v_a_2410)));
    return (g_heff_2eemitc_2eletReuse(v_t_2412, v_x_249, v_a_2410, v_b_2411, v_t_2413));
  }
  case TAG_ERecord: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EProj: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_242, 0);
    V v_as_2418 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2419 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2418));
    V v_t_2420 = heff_intEq(v_t_2419, heff_dup(v_n_241));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_n_241);
      V v_t_2421 = heff_tag_at(v_ru_24e_242_24ETag, TAG_Cons, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2417, v_as_2418}), NTAG(TAG_Nil)});
      V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_ru_240}), v_t_2421});
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2eemitc_2ereusePrim_get()), v_t_2422})});
    }
    case TAG_False: {
      V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuseIn_clo), 2, (V[]){v_ru_240, v_n_241}));
      V v_x2_2424 = ({ V a_0 = v_t_2423; V a_1 = v_as_2418; V r_ = (g_heff_2eemitc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2418); r_; });
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_MkPair: {
        V v_b_2425 = heff_field(v_x2_2424, 0);
        V v_es_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        return heff_tag_at(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){v_b_2425, heff_tag(TAG_ETag, 2, (V[]){v_t_2417, v_es_2426})});
      }
      default: return heff_nomatch(v_x2_2424);
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_e_242, 0);
    V v_arms_2428 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_ps_2440 = (g_prelude_2emap(heff_clo(g_heff_2eemitc_2ereuseIn_lam0, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_2428));
    V v_t_2441 = (g_prelude_2eany_24s633(v_ps_2440));
    V v_t_2442 = heff_tag_at(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2427, (g_prelude_2emap_24s513(v_ps_2440))});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2441, v_t_2442});
  }
  case TAG_EPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EPrimCall: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_ECall: {
    V v_g_2446 = heff_field(v_e_242, 0);
    V v_as_2447 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2448 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuseIn_clo), 2, (V[]){v_ru_240, v_n_241}));
    V v_x2_2449 = ({ V a_0 = v_t_2448; V a_1 = v_as_2447; V r_ = (g_heff_2eemitc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2447); r_; });
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_b_2450 = heff_field(v_x2_2449, 0);
      V v_es_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){v_b_2450, heff_tag(TAG_ECall, 2, (V[]){v_g_2446, v_es_2451})});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  case TAG_EInt: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2ereuseIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ereuseIn(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ereuseIn_lam0(V self, V *args) {
  V v_a_2429 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433;
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_b_2432 = heff_dup(heff_field(v_a_2429, 2));
    v_t_2433 = v_b_2432;
    break;
  }
  default: heff_nomatch(v_a_2429);
  }
  V v_x2_2434 = (g_heff_2eemitc_2ereuseIn(v_ru_240, v_n_241, v_t_2433));
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_field(v_a_2429, 0);
    V v_vs_2436 = heff_field(v_a_2429, 1);
    V v_ru_24a_2429_24MkArm = heff_take_reuse_n(v_a_2429, 3ULL, 3);
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_r_2438 = heff_field(v_x2_2434, 0);
      V v_b_2439 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_r_2438, heff_tag_at(v_ru_24a_2429_24MkArm, TAG_MkArm, 3, (V[]){v_t_2435, v_vs_2436, v_b_2439})});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  default: return heff_nomatch(v_a_2429);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ereusing_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereusing_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ereusing_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {114, 117, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereusing_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2eemitc_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereusing_entry, 4, 0};

V g_heff_2eemitc_2ereusing(V v_x1_240, V v_t_241, V v_vs_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str0), heff_strAppend(heff_dup(v_x_244), heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str1), heff_dup(v_t_241))));
    V v_t_246 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_242));
    V v_it_247 = (g_heff_2eemitc_2ereuseIn(v_t_245, v_t_246, heff_dup(v_b_243)));
    switch (heff_tag_of(v_it_247)) {
    case TAG_MkPair: {
      V v_it1_248 = heff_field(v_it_247, 0);
      V v_b2_249 = heff_field(v_it_247, 1);
      V v_ru_24it_247_24MkPair = heff_take_reuse_n(v_it_247, 3ULL, 2);
      switch (heff_tag_of(v_it1_248)) {
      case TAG_True: {
        heff_drop(v_b_243);
        V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str2), heff_strAppend(v_x_244, heff_strAppend(((V)&g_heff_2eemitc_2ereusing_str3), v_t_241)));
        return heff_tag_at(v_ru_24it_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_t_2410}), v_b2_249});
      }
      case TAG_False: {
        heff_drop(v_t_241);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        heff_drop(v_b2_249);
        return heff_tag_at(v_ru_24it_247_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
      }
      default: return heff_nomatch(v_it1_248);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ereusing_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ereusing(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2etakeKept_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2etakeKept_str3 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 114, 101, 117, 115, 101, 95, 110, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2etakeKept_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 76, 76, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2etakeKept_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemitc_2etakeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2etakeKept_entry, 4, 0};

V g_heff_2eemitc_2etakeKept(V v_sv_240, V v_x2_241, V v_vs_242, V v_used_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_sv_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_ru_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str0), (g_heff_2eemitc_2emangleW(heff_dup(v_ru_244), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2etakeKept_str1))));
    V v_t_246 = (g_heff_2eemitc_2efieldMask(v_used_243, MK_INT(0LL), v_vs_242));
    V v_t_247 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_242));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str2), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str3), heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str4), heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2eemitc_2etakeKept_str5), heff_strAppend(heff_intShow(v_t_247), ((V)&g_heff_2eemitc_2etakeKept_str6)))))))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2etakeKept_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2etakeKept(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
Clo g_heff_2eemitc_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eknowing_entry, 3, 0};

V g_heff_2eemitc_2eknowing(V v_x1_240, V v_n_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = (g_map_2einsert_24s7(v_x_243, heff_tag_at(v_ru_24x1_240_24Just, TAG_KnownTag, 1, (V[]){v_n_241}), heff_get(heff_dup(v_ce_242), LBL_known)));
    return heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), heff_get(heff_dup(v_ce_242), LBL_owned), heff_get(heff_dup(v_ce_242), LBL_after), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(v_ce_242, LBL_bor), v_t_244});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2eknowCell_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eknowCell_entry, 3, 0};

V g_heff_2eemitc_2eknowCell(V v_x1_240, V v_n_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_ru_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = (g_map_2einsert_24s7(v_ru_243, heff_tag_at(v_ru_24x1_240_24Just, TAG_KnownCell, 1, (V[]){v_n_241}), heff_get(heff_dup(v_ce_242), LBL_known)));
    return heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), heff_get(heff_dup(v_ce_242), LBL_owned), heff_get(heff_dup(v_ce_242), LBL_after), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(v_ce_242, LBL_bor), v_t_244});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eknowCell_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eknowCell(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2ereusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereusedOf_entry, 1, 0};

V g_heff_2eemitc_2ereusedOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_EVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EGlobal: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        V v_as_2418 = heff_field(v_x121_243, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_Nil: {
          V v_t_2419 = heff_tag(TAG_KnownTag, 1, (V[]){(g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2418))});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2419});
        }
        case TAG_Cons: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_EMatch: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ereusedOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ereusedOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ebuiltOf_entry, 1, 0};

V g_heff_2eemitc_2ebuiltOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    V v_as_2414 = heff_field(v_x1_240, 1);
    V v_t_2415 = heff_tag(TAG_KnownTag, 1, (V[]){(g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2414))});
    return heff_tag(TAG_Just, 1, (V[]){v_t_2415});
  }
  case TAG_EMatch: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2419 = heff_field(v_x1_240, 0);
    V v_as_2420 = heff_field(v_x1_240, 1);
    V v_t_2421 = heff_strEq(heff_dup(v_p_2419), heff_dup(g_heff_2eemitc_2ereusePrim_get()));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      HEFF_LAST return g_heff_2eemitc_2ereusedOf(v_as_2420);
    }
    case TAG_False: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2ebuiltOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2eknownLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eknownLet_entry, 3, 0};

V g_heff_2eemitc_2eknownLet(V v_x_240, V v_x2_241, V v_ce_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    return v_ce_242;
  }
  case TAG_Just: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_t_244 = (g_map_2einsert_24s7(v_x_240, heff_dup(v_k_243), heff_get(heff_dup(v_ce_242), LBL_known)));
    return heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), heff_get(heff_dup(v_ce_242), LBL_owned), heff_get(heff_dup(v_ce_242), LBL_after), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(v_ce_242, LBL_bor), v_t_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eknownLet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eknownLet(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2eparamsAt_lam0(V self, V *args);
Clo g_heff_2eemitc_2eparamsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eparamsAt_entry, 3, 0};

V g_heff_2eemitc_2eparamsAt(V v_want_240, V v_bi_241, V v_xs_242) {
top: ;
  V v_t_243 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_242));
  V v_t_244 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_245 = (g_prelude_2ezipWith_24s634(v_xs_242, v_t_244));
  V v_t_2414 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eparamsAt_lam0, 1, 2, (V[]){heff_dup(v_want_240), heff_dup(v_bi_241)}), v_t_245));
  return (g_prelude_2emap_24s618(v_t_2414));
}
V g_heff_2eemitc_2eparamsAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eparamsAt(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2eparamsAt_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_want_240 = heff_env(self)[0];
  V v_bi_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_want_240)) {
  case TAG_True: {
    V v_t_249;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_p_246, 1);
      heff_take_n(v_p_246, 2ULL, 2);
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    return ({ V a_0 = v_t_249; V a_1 = v_bi_241; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  }
  case TAG_False: {
    V v_t_2412;
    switch (heff_tag_of(v_p_246)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_p_246, 1);
      heff_take_n(v_p_246, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_p_246);
    }
    V v_x1_2413 = ({ V a_0 = v_t_2412; V a_1 = v_bi_241; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  default: return heff_nomatch(v_want_240);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eentryCall_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eentryCall_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2eentryCall_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 86, 32, 114, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eentryCall_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2eentryCall_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2eentryCall_str13 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 101, 116, 117, 114, 110, 32, 114, 59}};
Clo g_heff_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_bi_241);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str0), (g_heff_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eentryCall_str1))));
    V v_t_247 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_248 = (g_prelude_2emap_24s637(v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2eemitc_2eentryCall_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str3), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str4), heff_strAppend(v_t_2411, ((V)&g_heff_2eemitc_2eentryCall_str5)))));
  }
  case TAG_False: {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str6), (g_heff_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eentryCall_str7))));
    V v_t_2413 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2414 = (g_prelude_2emap_24s637(v_t_2413));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2eemitc_2eentryCall_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = v_x_2415; V a_1 = v_xs_2416; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_x2_2418 = (g_prelude_2emap_24s638(v_bi_241));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2eemitc_2eentryCall_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = v_x_2419; V a_1 = v_xs_2420; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    return heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str10), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str11), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eemitc_2eentryCall_str12), heff_strAppend(v_t_2421, ((V)&g_heff_2eemitc_2eentryCall_str13)))))));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2elamBody_24s643_lam0(V self, V *args);
Clo g_heff_2eemitc_2elamBody_24s643_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elamBody_24s643_entry, 4, 0};

V g_heff_2eemitc_2elamBody_24s643(V v_ce_240, V v_xs_241, V v_b_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2econcatList(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_242)));
  V v_owned_247 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2elamBody_24s643_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_n_248 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_241; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_241); r_; });
  V v_ce_249 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), NTAG(TAG_Nothing), v_n_248, heff_get(heff_dup(v_ce_240), LBL_owned), heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(v_ce_240, LBL_known)});
  V v_ce_2410 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_249), LBL_tags), heff_get(heff_dup(v_ce_249), LBL_lbls), heff_get(heff_dup(v_ce_249), LBL_funs), heff_get(heff_dup(v_ce_249), LBL_bounce), heff_get(heff_dup(v_ce_249), LBL_self), heff_get(heff_dup(v_ce_249), LBL_lam), heff_get(heff_dup(v_ce_249), LBL_owned), heff_get(heff_dup(v_ce_249), LBL_after), NTAG(TAG_Nil), heff_get(heff_dup(v_ce_249), LBL_bor), heff_get(v_ce_249, LBL_known)});
  V v_ce_2411 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_2410), LBL_tags), heff_get(heff_dup(v_ce_2410), LBL_lbls), heff_get(heff_dup(v_ce_2410), LBL_funs), heff_get(heff_dup(v_ce_2410), LBL_bounce), heff_get(heff_dup(v_ce_2410), LBL_self), heff_get(heff_dup(v_ce_2410), LBL_lam), v_owned_247, NTAG(TAG_Nil), heff_get(heff_dup(v_ce_2410), LBL_borrowed), heff_get(heff_dup(v_ce_2410), LBL_bor), heff_get(v_ce_2410, LBL_known)});
  return (g_heff_2eemitc_2estmtsF_24s639(v_ce_2411, NTAG(TAG_Ret), v_b_242));
}
V g_heff_2eemitc_2elamBody_24s643_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elamBody_24s643(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemitc_2elamBody_24s643_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamWith_24s642_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eemitc_2elamWith_24s642_str1 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 59, 32, 115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2eemitc_2elamWith_24s642_str2 = {{0x80000000u, K_STR, 0}, 33, 33, {95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s642_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2elamWith_24s642_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 48, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamWith_24s642_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2elamWith_24s642_str6 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 114, 103, 115, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s642_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2elamWith_24s642_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2elamWith_24s642_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elamWith_24s642_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s642_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2elamWith_24s642_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s642_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2elamWith_24s642_str14 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 99, 108, 111, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s642_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s642_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elamWith_24s642_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elamWith_24s642_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eemitc_2elamWith_24s642_lam0(V self, V *args);
Clo g_heff_2eemitc_2elamWith_24s642_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elamWith_24s642_entry, 6, 0};

V g_heff_2eemitc_2elamWith_24s642(V v_ce_240, V v_live_241, V v_xs_242, V v_b_243, V v_fv_244, V v_s_245) {
top: ;
  V v_x2_246 = (g_heff_2eemitc_2enewLam(v_s_245));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_heff_2eemitc_2elamBody_24s643(heff_dup(v_ce_240), heff_dup(v_xs_242), heff_dup(v_b_243), heff_dup(v_fv_244)));
    V v_x2_2410 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_n_2413 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_242));
      V v_t_2416;
      switch (heff_tag_of(v_fv_244)) {
      case TAG_Nil: {
        v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str0), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str1), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str2), heff_strAppend(heff_dup(v_x_247), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str3), heff_strAppend(heff_intShow(v_n_2413), ((V)&g_heff_2eemitc_2elamWith_24s642_str4)))))))));
        break;
      }
      case TAG_Cons: {
        heff_drop(v_n_2413);
        v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str5), heff_strAppend(heff_dup(v_x_247), ((V)&g_heff_2eemitc_2elamWith_24s642_str6)));
        break;
      }
      default: heff_nomatch(v_fv_244);
      }
      V v_wanted_2417 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_243));
      V v_t_2420 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2elamWith_24s642_lam0, 1, 1, (V[]){v_wanted_2417}), heff_dup(v_xs_242)));
      V v_x2_2421 = (g_heff_2eemitc_2elamLines(heff_dup(v_x_247), heff_dup(v_xs_242), heff_dup(v_fv_244), v_t_2420, v_x_2411));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2eemitc_2elamWith_24s642_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = v_x_2422; V a_1 = v_xs_2423; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_m_2425 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2416, v_t_2424}));
      V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_s_2428 = heff_field(v_x2_2426, 1);
        heff_take_n(v_x2_2426, 2ULL, 2);
        V v_t_2431;
        switch (heff_tag_of(v_fv_244)) {
        case TAG_Nil: {
          v_t_2431 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          v_t_2431 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_fv_244);
        }
        V v_x_2442;
        switch (heff_tag_of(v_t_2431)) {
        case TAG_True: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          heff_drop(v_xs_242);
          heff_drop(v_fv_244);
          v_x_2442 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str8), heff_strAppend(v_x_247, ((V)&g_heff_2eemitc_2elamWith_24s642_str9)));
          break;
        }
        case TAG_False: {
          V v_t_2432 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_242; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_242); r_; });
          V v_t_2433 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_fv_244));
          V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2evarUse_clo), 2, (V[]){heff_get(v_ce_240, LBL_borrowed), v_live_241}));
          V v_vs_2435 = (g_prelude_2emap(v_t_2434, v_fv_244));
          V v_t_2441;
          switch (heff_tag_of(v_vs_2435)) {
          case TAG_Nil: {
            v_t_2441 = ((V)&g_heff_2eemitc_2elamWith_24s642_str10);
            break;
          }
          case TAG_Cons: {
            V v_t_2440;
            switch (heff_tag_of(v_vs_2435)) {
            case TAG_Nil: {
              v_t_2440 = ((V)&g_heff_2eemitc_2elamWith_24s642_str11);
              break;
            }
            case TAG_Cons: {
              V v_x_2438 = heff_field(v_vs_2435, 0);
              V v_xs_2439 = heff_field(v_vs_2435, 1);
              heff_take_n(v_vs_2435, 3ULL, 2);
              v_t_2440 = ({ V a_0 = v_x_2438; V a_1 = v_xs_2439; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2439); r_; });
              break;
            }
            default: heff_nomatch(v_vs_2435);
            }
            v_t_2441 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str12), heff_strAppend(v_t_2440, ((V)&g_heff_2eemitc_2elamWith_24s642_str13)));
            break;
          }
          default: heff_nomatch(v_vs_2435);
          }
          v_x_2442 = heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str14), heff_strAppend(v_x_247, heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str15), heff_strAppend(heff_intShow(v_t_2432), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str16), heff_strAppend(heff_intShow(v_t_2433), heff_strAppend(((V)&g_heff_2eemitc_2elamWith_24s642_str17), heff_strAppend(v_t_2441, ((V)&g_heff_2eemitc_2elamWith_24s642_str18)))))))));
          break;
        }
        default: heff_nomatch(v_t_2431);
        }
        return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2442, v_s_2428});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eemitc_2elamWith_24s642_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elamWith_24s642(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eemitc_2elamWith_24s642_lam0(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2417); r_; });
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ereuseVal_24s644_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ereuseVal_24s644_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2ereuseVal_24s644_str14 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2ereuseVal_24s644_str16 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 116, 97, 103, 95, 97, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s644_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s644_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ereuseVal_24s644_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ereuseVal_24s644_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
V g_heff_2eemitc_2ereuseVal_24s644_lam0(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam0, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam1(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam1, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam2(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam2, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam3(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam3, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam4(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam4, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam5(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam5, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam6(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam6, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam7(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam7, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam8(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam8, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam9(V self, V *args);
V g_heff_2eemitc_2ereuseVal_24s644_lam10(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam10, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam11(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam11, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam12(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam12, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam13(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam13, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam14(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam14, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam15(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam15, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam16(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam16, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam17(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam17, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam18(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam18, 1, 0};
V g_heff_2eemitc_2ereuseVal_24s644_lam19(V self, V *args); static Clo g_heff_2eemitc_2ereuseVal_24s644_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_lam19, 1, 0};
Clo g_heff_2eemitc_2ereuseVal_24s644_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuseVal_24s644_entry, 3, 0};

V g_heff_2eemitc_2ereuseVal_24s644(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam0_clo);
  }
  case TAG_Cons: {
    V v_ru_244 = heff_field(v_x4_242, 0);
    V v_x42_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_ru_244);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam1_clo);
    }
    case TAG_Cons: {
      V v_x421_247 = heff_field(v_x42_245, 0);
      V v_x422_248 = heff_field(v_x42_245, 1);
      heff_take_n(v_x42_245, 3ULL, 2);
      switch (heff_tag_of(v_x421_247)) {
      case TAG_EVar: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam2_clo);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam3_clo);
      }
      case TAG_ELam: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam4_clo);
      }
      case TAG_EApp: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam5_clo);
      }
      case TAG_ELet: {
        heff_take_n(v_x421_247, 0ULL, 3);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam6_clo);
      }
      case TAG_ERecord: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam7_clo);
      }
      case TAG_EProj: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam8_clo);
      }
      case TAG_ETag: {
        V v_t_2428 = heff_field(v_x421_247, 0);
        V v_as_2429 = heff_field(v_x421_247, 1);
        heff_take_n(v_x421_247, 3ULL, 2);
        switch (heff_tag_of(v_x422_248)) {
        case TAG_Nil: {
          V v_m_2430 = (g_heff_2eemitc_2eoperandsF_24s640(v_ce_240, v_live_241, heff_tag_at(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_ru_244, heff_dup(v_as_2429)})));
          return heff_clo(g_heff_2eemitc_2ereuseVal_24s644_lam9, 1, 3, (V[]){v_m_2430, v_t_2428, v_as_2429});
        }
        case TAG_Cons: {
          heff_take_n(v_x422_248, 0ULL, 2);
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          heff_drop(v_ru_244);
          heff_drop_cell(v_ru_24x4_242_24Cons, 2);
          heff_drop(v_t_2428);
          heff_drop(v_as_2429);
          return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam10_clo);
        }
        default: return heff_nomatch(v_x422_248);
        }
      }
      case TAG_EMatch: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam11_clo);
      }
      case TAG_EPrim: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam12_clo);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam13_clo);
      }
      case TAG_ECall: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam14_clo);
      }
      case TAG_EInt: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam15_clo);
      }
      case TAG_EFloat: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam16_clo);
      }
      case TAG_EStr: {
        heff_take_n(v_x421_247, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam17_clo);
      }
      case TAG_EAbandon: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam18_clo);
      }
      case TAG_EFix: {
        heff_take_n(v_x421_247, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_244);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_248);
        return ((V)&g_heff_2eemitc_2ereuseVal_24s644_lam19_clo);
      }
      default: return heff_nomatch(v_x421_247);
      }
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eemitc_2ereuseVal_24s644_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ereuseVal_24s644(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ereuseVal_24s644_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str0), v_s_243});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam1(V self, V *args) {
  V v_s_246 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str1), v_s_246});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str2), v_s_2410});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str3), v_s_2412});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str4), v_s_2415});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam5(V self, V *args) {
  V v_s_2418 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str5), v_s_2418});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam6(V self, V *args) {
  V v_s_2422 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str6), v_s_2422});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam7(V self, V *args) {
  V v_s_2424 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str7), v_s_2424});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam8(V self, V *args) {
  V v_s_2427 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str8), v_s_2427});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam9(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_as_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_x2_2437;
    switch (heff_tag_of(v_x_2433)) {
    case TAG_Nil: {
      v_x2_2437 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_dup(heff_field(v_x_2433, 0));
      v_x2_2437 = heff_tag(TAG_Just, 1, (V[]){v_x_2435});
      break;
    }
    default: heff_nomatch(v_x_2433);
    }
    V v_t_2439;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nothing: {
      v_t_2439 = ((V)&g_heff_2eemitc_2ereuseVal_24s644_str9);
      break;
    }
    case TAG_Just: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      heff_take_n(v_x2_2437, 1ULL, 1);
      v_t_2439 = v_x_2438;
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    V v_t_2440 = heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s644_str10), (g_heff_2eemitc_2emangleW(v_t_2428, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ereuseVal_24s644_str11))));
    V v_t_2441 = ({ V a_0 = MK_INT(0LL); V a_1 = v_as_2429; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_as_2429); r_; });
    V v_vs_2442 = (g_prelude_2edrop(MK_INT(1LL), v_x_2433));
    V v_t_2448;
    switch (heff_tag_of(v_vs_2442)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2eemitc_2ereuseVal_24s644_str12);
      break;
    }
    case TAG_Cons: {
      V v_t_2447;
      switch (heff_tag_of(v_vs_2442)) {
      case TAG_Nil: {
        v_t_2447 = ((V)&g_heff_2eemitc_2ereuseVal_24s644_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2445 = heff_field(v_vs_2442, 0);
        V v_xs_2446 = heff_field(v_vs_2442, 1);
        heff_take_n(v_vs_2442, 3ULL, 2);
        v_t_2447 = ({ V a_0 = v_x_2445; V a_1 = v_xs_2446; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2446); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2442);
      }
      v_t_2448 = heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s644_str14), heff_strAppend(v_t_2447, ((V)&g_heff_2eemitc_2ereuseVal_24s644_str15)));
      break;
    }
    default: heff_nomatch(v_vs_2442);
    }
    V v_x_2449 = heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s644_str16), heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s644_str17), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s644_str18), heff_strAppend(heff_intShow(v_t_2441), heff_strAppend(((V)&g_heff_2eemitc_2ereuseVal_24s644_str19), heff_strAppend(v_t_2448, ((V)&g_heff_2eemitc_2ereuseVal_24s644_str20)))))))));
    return heff_tag_at(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2eemitc_2ereuseVal_24s644_lam10(V self, V *args) {
  V v_s_2452 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str21), v_s_2452});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam11(V self, V *args) {
  V v_s_2455 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str22), v_s_2455});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam12(V self, V *args) {
  V v_s_2457 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str23), v_s_2457});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam13(V self, V *args) {
  V v_s_2460 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str24), v_s_2460});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam14(V self, V *args) {
  V v_s_2463 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str25), v_s_2463});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam15(V self, V *args) {
  V v_s_2465 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str26), v_s_2465});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam16(V self, V *args) {
  V v_s_2467 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str27), v_s_2467});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam17(V self, V *args) {
  V v_s_2469 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str28), v_s_2469});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam18(V self, V *args) {
  V v_s_2470 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str29), v_s_2470});
}
V g_heff_2eemitc_2ereuseVal_24s644_lam19(V self, V *args) {
  V v_s_2473 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2ereuseVal_24s644_str30), v_s_2473});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str10 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str16 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str20 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str22 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str25 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str26 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str28 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str29 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str30 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str31 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str32 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str34 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str35 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str37 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str38 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str40 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str42 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str43 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str44 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str46 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str47 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str48 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str49 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str52 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str53 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str54 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str55 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str56 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str58 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str59 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str60 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str61 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str62 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str64 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str65 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str66 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str67 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str68 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str69 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str70 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str71 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str72 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str73 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str74 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str76 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str77 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str78 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str79 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str80 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str82 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str83 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str84 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str85 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str86 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str87 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str88 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str89 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str90 = {{0x80000000u, K_STR, 0}, 2, 2, {98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2elentOne_24s647_str91 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2elentOne_24s647_str92 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2elentOne_24s647_str93 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2elentOne_24s647_str94 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 98, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2elentOne_24s647_str95 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
V g_heff_2eemitc_2elentOne_24s647_lam0(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam1(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam2(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam3(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam4(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam5(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam6(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam7(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam8(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam9(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam10(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam11(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam12(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam13(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam14(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam15(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam16(V self, V *args);
V g_heff_2eemitc_2elentOne_24s647_lam17(V self, V *args);
Clo g_heff_2eemitc_2elentOne_24s647_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentOne_24s647_entry, 5, 0};

V g_heff_2eemitc_2elentOne_24s647(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24EVar = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_246 = (g_heff_2eemitc_2eelemI(v_i_243, v_bi_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop_cell(v_ru_24e_244_24EVar, 1);
      V v_x_247 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_x_245; V r_ = (g_heff_2eemitc_2elentVar(a_0, a_1, a_2)); heff_drop(v_live_241); r_; });
      return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam0, 1, 1, (V[]){v_x_247});
    }
    case TAG_False: {
      V v_m_249 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, heff_tag_at(v_ru_24e_244_24EVar, TAG_EVar, 1, (V[]){v_x_245})));
      return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam1, 1, 1, (V[]){v_m_249});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_EGlobal: {
    V v_m_2416 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam2, 1, 3, (V[]){v_m_2416, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ELam: {
    V v_m_2430 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam3, 1, 3, (V[]){v_m_2430, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EApp: {
    V v_m_2444 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam4, 1, 3, (V[]){v_m_2444, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ELet: {
    V v_m_2459 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam5, 1, 3, (V[]){v_m_2459, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ERecord: {
    V v_m_2472 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam6, 1, 3, (V[]){v_m_2472, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EProj: {
    V v_m_2486 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam7, 1, 3, (V[]){v_m_2486, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ETag: {
    V v_m_24100 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam8, 1, 3, (V[]){v_m_24100, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EMatch: {
    V v_m_24114 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam9, 1, 3, (V[]){v_m_24114, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EPrim: {
    V v_m_24127 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam10, 1, 3, (V[]){v_m_24127, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EPrimCall: {
    V v_m_24141 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam11, 1, 3, (V[]){v_m_24141, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_ECall: {
    V v_m_24155 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam12, 1, 3, (V[]){v_m_24155, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EInt: {
    V v_m_24168 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam13, 1, 3, (V[]){v_m_24168, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EFloat: {
    V v_m_24181 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam14, 1, 3, (V[]){v_m_24181, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EStr: {
    V v_m_24194 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam15, 1, 3, (V[]){v_m_24194, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EAbandon: {
    V v_m_24206 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam16, 1, 3, (V[]){v_m_24206, v_i_243, heff_dup(v_bi_242)});
  }
  case TAG_EFix: {
    V v_m_24220 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_244));
    return heff_clo(g_heff_2eemitc_2elentOne_24s647_lam17, 1, 3, (V[]){v_m_24220, v_i_243, heff_dup(v_bi_242)});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2eemitc_2elentOne_24s647_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentOne_24s647(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2elentOne_24s647_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2eemitc_2elentOne_24s647_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = heff_rec(3, shape_12_251_249, (V[]){v_x_2412, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_apply(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2427;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      V v_t_2422 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str0), heff_intShow(heff_dup(v_i_243)));
      V v_t_2423 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str1), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str2), heff_strAppend(v_x_2419, ((V)&g_heff_2eemitc_2elentOne_24s647_str3)))));
      V v_t_2424 = heff_tag_at(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
      V v_t_2425 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str4), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str5)));
      V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
      v_x_2427 = heff_rec(3, shape_12_251_249, (V[]){v_t_2422, v_t_2424, v_t_2426});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
      v_x_2427 = heff_rec(3, shape_12_251_249, (V[]){v_x_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2427, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam3(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2441;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      V v_t_2436 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str6), heff_intShow(heff_dup(v_i_243)));
      V v_t_2437 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str7), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str8), heff_strAppend(v_x_2433, ((V)&g_heff_2eemitc_2elentOne_24s647_str9)))));
      V v_t_2438 = heff_tag_at(v_ru_24x2_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str10), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str11)));
      V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
      v_x_2441 = heff_rec(3, shape_12_251_249, (V[]){v_t_2436, v_t_2438, v_t_2440});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2432_24MkPair, 2);
      v_x_2441 = heff_rec(3, shape_12_251_249, (V[]){v_x_2433, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2441, v_s_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam4(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2446 = heff_tr(heff_apply(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    V v_t_2449 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2455;
    switch (heff_tag_of(v_t_2449)) {
    case TAG_True: {
      V v_t_2450 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str12), heff_intShow(heff_dup(v_i_243)));
      V v_t_2451 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str13), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str14), heff_strAppend(v_x_2447, ((V)&g_heff_2eemitc_2elentOne_24s647_str15)))));
      V v_t_2452 = heff_tag_at(v_ru_24x2_2446_24MkPair, TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_t_2453 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str16), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str17)));
      V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
      v_x_2455 = heff_rec(3, shape_12_251_249, (V[]){v_t_2450, v_t_2452, v_t_2454});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2446_24MkPair, 2);
      v_x_2455 = heff_rec(3, shape_12_251_249, (V[]){v_x_2447, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2449);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2455, v_s_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam5(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2461 = heff_tr(heff_apply(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    V v_t_2464 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2470;
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      V v_t_2465 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str18), heff_intShow(heff_dup(v_i_243)));
      V v_t_2466 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str19), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str20), heff_strAppend(v_x_2462, ((V)&g_heff_2eemitc_2elentOne_24s647_str21)))));
      V v_t_2467 = heff_tag_at(v_ru_24x2_2461_24MkPair, TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
      V v_t_2468 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str22), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str23)));
      V v_t_2469 = heff_tag(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
      v_x_2470 = heff_rec(3, shape_12_251_249, (V[]){v_t_2465, v_t_2467, v_t_2469});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2461_24MkPair, 2);
      v_x_2470 = heff_rec(3, shape_12_251_249, (V[]){v_x_2462, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2464);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2470, v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam6(V self, V *args) {
  V v_s_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2474 = heff_tr(heff_apply(v_m_2472, 1, (V[]){v_s_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_s_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    V v_t_2477 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2483;
    switch (heff_tag_of(v_t_2477)) {
    case TAG_True: {
      V v_t_2478 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str24), heff_intShow(heff_dup(v_i_243)));
      V v_t_2479 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str25), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str26), heff_strAppend(v_x_2475, ((V)&g_heff_2eemitc_2elentOne_24s647_str27)))));
      V v_t_2480 = heff_tag_at(v_ru_24x2_2474_24MkPair, TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
      V v_t_2481 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str28), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str29)));
      V v_t_2482 = heff_tag(TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
      v_x_2483 = heff_rec(3, shape_12_251_249, (V[]){v_t_2478, v_t_2480, v_t_2482});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2474_24MkPair, 2);
      v_x_2483 = heff_rec(3, shape_12_251_249, (V[]){v_x_2475, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2477);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2483, v_s_2476});
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam7(V self, V *args) {
  V v_s_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2488 = heff_tr(heff_apply(v_m_2486, 1, (V[]){v_s_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_s_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    V v_t_2491 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_2497;
    switch (heff_tag_of(v_t_2491)) {
    case TAG_True: {
      V v_t_2492 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str30), heff_intShow(heff_dup(v_i_243)));
      V v_t_2493 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str31), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str32), heff_strAppend(v_x_2489, ((V)&g_heff_2eemitc_2elentOne_24s647_str33)))));
      V v_t_2494 = heff_tag_at(v_ru_24x2_2488_24MkPair, TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
      V v_t_2495 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str34), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str35)));
      V v_t_2496 = heff_tag(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
      v_x_2497 = heff_rec(3, shape_12_251_249, (V[]){v_t_2492, v_t_2494, v_t_2496});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_2488_24MkPair, 2);
      v_x_2497 = heff_rec(3, shape_12_251_249, (V[]){v_x_2489, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2491);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2497, v_s_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam8(V self, V *args) {
  V v_s_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24102 = heff_tr(heff_apply(v_m_24100, 1, (V[]){v_s_24101}));
  switch (heff_tag_of(v_x2_24102)) {
  case TAG_MkPair: {
    V v_x_24103 = heff_field(v_x2_24102, 0);
    V v_s_24104 = heff_field(v_x2_24102, 1);
    V v_ru_24x2_24102_24MkPair = heff_take_reuse_n(v_x2_24102, 3ULL, 2);
    V v_t_24105 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24111;
    switch (heff_tag_of(v_t_24105)) {
    case TAG_True: {
      V v_t_24106 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str36), heff_intShow(heff_dup(v_i_243)));
      V v_t_24107 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str37), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str38), heff_strAppend(v_x_24103, ((V)&g_heff_2eemitc_2elentOne_24s647_str39)))));
      V v_t_24108 = heff_tag_at(v_ru_24x2_24102_24MkPair, TAG_Cons, 2, (V[]){v_t_24107, NTAG(TAG_Nil)});
      V v_t_24109 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str40), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str41)));
      V v_t_24110 = heff_tag(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
      v_x_24111 = heff_rec(3, shape_12_251_249, (V[]){v_t_24106, v_t_24108, v_t_24110});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24102_24MkPair, 2);
      v_x_24111 = heff_rec(3, shape_12_251_249, (V[]){v_x_24103, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24105);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24111, v_s_24104});
  }
  default: return heff_nomatch(v_x2_24102);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam9(V self, V *args) {
  V v_s_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24116 = heff_tr(heff_apply(v_m_24114, 1, (V[]){v_s_24115}));
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_MkPair: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    V v_s_24118 = heff_field(v_x2_24116, 1);
    V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
    V v_t_24119 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24125;
    switch (heff_tag_of(v_t_24119)) {
    case TAG_True: {
      V v_t_24120 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str42), heff_intShow(heff_dup(v_i_243)));
      V v_t_24121 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str43), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str44), heff_strAppend(v_x_24117, ((V)&g_heff_2eemitc_2elentOne_24s647_str45)))));
      V v_t_24122 = heff_tag_at(v_ru_24x2_24116_24MkPair, TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
      V v_t_24123 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str46), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str47)));
      V v_t_24124 = heff_tag(TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
      v_x_24125 = heff_rec(3, shape_12_251_249, (V[]){v_t_24120, v_t_24122, v_t_24124});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24116_24MkPair, 2);
      v_x_24125 = heff_rec(3, shape_12_251_249, (V[]){v_x_24117, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24119);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24125, v_s_24118});
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam10(V self, V *args) {
  V v_s_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24129 = heff_tr(heff_apply(v_m_24127, 1, (V[]){v_s_24128}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_s_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    V v_t_24132 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24138;
    switch (heff_tag_of(v_t_24132)) {
    case TAG_True: {
      V v_t_24133 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str48), heff_intShow(heff_dup(v_i_243)));
      V v_t_24134 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str49), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str50), heff_strAppend(v_x_24130, ((V)&g_heff_2eemitc_2elentOne_24s647_str51)))));
      V v_t_24135 = heff_tag_at(v_ru_24x2_24129_24MkPair, TAG_Cons, 2, (V[]){v_t_24134, NTAG(TAG_Nil)});
      V v_t_24136 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str52), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str53)));
      V v_t_24137 = heff_tag(TAG_Cons, 2, (V[]){v_t_24136, NTAG(TAG_Nil)});
      v_x_24138 = heff_rec(3, shape_12_251_249, (V[]){v_t_24133, v_t_24135, v_t_24137});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24129_24MkPair, 2);
      v_x_24138 = heff_rec(3, shape_12_251_249, (V[]){v_x_24130, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24132);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24138, v_s_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam11(V self, V *args) {
  V v_s_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24143 = heff_tr(heff_apply(v_m_24141, 1, (V[]){v_s_24142}));
  switch (heff_tag_of(v_x2_24143)) {
  case TAG_MkPair: {
    V v_x_24144 = heff_field(v_x2_24143, 0);
    V v_s_24145 = heff_field(v_x2_24143, 1);
    V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
    V v_t_24146 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24152;
    switch (heff_tag_of(v_t_24146)) {
    case TAG_True: {
      V v_t_24147 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str54), heff_intShow(heff_dup(v_i_243)));
      V v_t_24148 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str55), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str56), heff_strAppend(v_x_24144, ((V)&g_heff_2eemitc_2elentOne_24s647_str57)))));
      V v_t_24149 = heff_tag_at(v_ru_24x2_24143_24MkPair, TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
      V v_t_24150 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str58), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str59)));
      V v_t_24151 = heff_tag(TAG_Cons, 2, (V[]){v_t_24150, NTAG(TAG_Nil)});
      v_x_24152 = heff_rec(3, shape_12_251_249, (V[]){v_t_24147, v_t_24149, v_t_24151});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24143_24MkPair, 2);
      v_x_24152 = heff_rec(3, shape_12_251_249, (V[]){v_x_24144, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24146);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24152, v_s_24145});
  }
  default: return heff_nomatch(v_x2_24143);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam12(V self, V *args) {
  V v_s_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24157 = heff_tr(heff_apply(v_m_24155, 1, (V[]){v_s_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_MkPair: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    V v_s_24159 = heff_field(v_x2_24157, 1);
    V v_ru_24x2_24157_24MkPair = heff_take_reuse_n(v_x2_24157, 3ULL, 2);
    V v_t_24160 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24166;
    switch (heff_tag_of(v_t_24160)) {
    case TAG_True: {
      V v_t_24161 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str60), heff_intShow(heff_dup(v_i_243)));
      V v_t_24162 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str61), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str62), heff_strAppend(v_x_24158, ((V)&g_heff_2eemitc_2elentOne_24s647_str63)))));
      V v_t_24163 = heff_tag_at(v_ru_24x2_24157_24MkPair, TAG_Cons, 2, (V[]){v_t_24162, NTAG(TAG_Nil)});
      V v_t_24164 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str64), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str65)));
      V v_t_24165 = heff_tag(TAG_Cons, 2, (V[]){v_t_24164, NTAG(TAG_Nil)});
      v_x_24166 = heff_rec(3, shape_12_251_249, (V[]){v_t_24161, v_t_24163, v_t_24165});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24157_24MkPair, 2);
      v_x_24166 = heff_rec(3, shape_12_251_249, (V[]){v_x_24158, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24160);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24166, v_s_24159});
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam13(V self, V *args) {
  V v_s_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24170 = heff_tr(heff_apply(v_m_24168, 1, (V[]){v_s_24169}));
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_MkPair: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    V v_s_24172 = heff_field(v_x2_24170, 1);
    V v_ru_24x2_24170_24MkPair = heff_take_reuse_n(v_x2_24170, 3ULL, 2);
    V v_t_24173 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24179;
    switch (heff_tag_of(v_t_24173)) {
    case TAG_True: {
      V v_t_24174 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str66), heff_intShow(heff_dup(v_i_243)));
      V v_t_24175 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str67), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str68), heff_strAppend(v_x_24171, ((V)&g_heff_2eemitc_2elentOne_24s647_str69)))));
      V v_t_24176 = heff_tag_at(v_ru_24x2_24170_24MkPair, TAG_Cons, 2, (V[]){v_t_24175, NTAG(TAG_Nil)});
      V v_t_24177 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str70), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str71)));
      V v_t_24178 = heff_tag(TAG_Cons, 2, (V[]){v_t_24177, NTAG(TAG_Nil)});
      v_x_24179 = heff_rec(3, shape_12_251_249, (V[]){v_t_24174, v_t_24176, v_t_24178});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24170_24MkPair, 2);
      v_x_24179 = heff_rec(3, shape_12_251_249, (V[]){v_x_24171, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24173);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24179, v_s_24172});
  }
  default: return heff_nomatch(v_x2_24170);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam14(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24183 = heff_tr(heff_apply(v_m_24181, 1, (V[]){v_s_24182}));
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    V v_ru_24x2_24183_24MkPair = heff_take_reuse_n(v_x2_24183, 3ULL, 2);
    V v_t_24186 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24192;
    switch (heff_tag_of(v_t_24186)) {
    case TAG_True: {
      V v_t_24187 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str72), heff_intShow(heff_dup(v_i_243)));
      V v_t_24188 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str73), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str74), heff_strAppend(v_x_24184, ((V)&g_heff_2eemitc_2elentOne_24s647_str75)))));
      V v_t_24189 = heff_tag_at(v_ru_24x2_24183_24MkPair, TAG_Cons, 2, (V[]){v_t_24188, NTAG(TAG_Nil)});
      V v_t_24190 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str76), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str77)));
      V v_t_24191 = heff_tag(TAG_Cons, 2, (V[]){v_t_24190, NTAG(TAG_Nil)});
      v_x_24192 = heff_rec(3, shape_12_251_249, (V[]){v_t_24187, v_t_24189, v_t_24191});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24183_24MkPair, 2);
      v_x_24192 = heff_rec(3, shape_12_251_249, (V[]){v_x_24184, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24186);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24192, v_s_24185});
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam15(V self, V *args) {
  V v_s_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24196 = heff_tr(heff_apply(v_m_24194, 1, (V[]){v_s_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_s_24198 = heff_field(v_x2_24196, 1);
    V v_ru_24x2_24196_24MkPair = heff_take_reuse_n(v_x2_24196, 3ULL, 2);
    V v_t_24199 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24205;
    switch (heff_tag_of(v_t_24199)) {
    case TAG_True: {
      V v_t_24200 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str78), heff_intShow(heff_dup(v_i_243)));
      V v_t_24201 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str79), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str80), heff_strAppend(v_x_24197, ((V)&g_heff_2eemitc_2elentOne_24s647_str81)))));
      V v_t_24202 = heff_tag_at(v_ru_24x2_24196_24MkPair, TAG_Cons, 2, (V[]){v_t_24201, NTAG(TAG_Nil)});
      V v_t_24203 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str82), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str83)));
      V v_t_24204 = heff_tag(TAG_Cons, 2, (V[]){v_t_24203, NTAG(TAG_Nil)});
      v_x_24205 = heff_rec(3, shape_12_251_249, (V[]){v_t_24200, v_t_24202, v_t_24204});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24196_24MkPair, 2);
      v_x_24205 = heff_rec(3, shape_12_251_249, (V[]){v_x_24197, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24199);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24205, v_s_24198});
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam16(V self, V *args) {
  V v_s_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24208 = heff_tr(heff_apply(v_m_24206, 1, (V[]){v_s_24207}));
  switch (heff_tag_of(v_x2_24208)) {
  case TAG_MkPair: {
    V v_x_24209 = heff_field(v_x2_24208, 0);
    V v_s_24210 = heff_field(v_x2_24208, 1);
    V v_ru_24x2_24208_24MkPair = heff_take_reuse_n(v_x2_24208, 3ULL, 2);
    V v_t_24211 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24217;
    switch (heff_tag_of(v_t_24211)) {
    case TAG_True: {
      V v_t_24212 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str84), heff_intShow(heff_dup(v_i_243)));
      V v_t_24213 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str85), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str86), heff_strAppend(v_x_24209, ((V)&g_heff_2eemitc_2elentOne_24s647_str87)))));
      V v_t_24214 = heff_tag_at(v_ru_24x2_24208_24MkPair, TAG_Cons, 2, (V[]){v_t_24213, NTAG(TAG_Nil)});
      V v_t_24215 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str88), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str89)));
      V v_t_24216 = heff_tag(TAG_Cons, 2, (V[]){v_t_24215, NTAG(TAG_Nil)});
      v_x_24217 = heff_rec(3, shape_12_251_249, (V[]){v_t_24212, v_t_24214, v_t_24216});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24208_24MkPair, 2);
      v_x_24217 = heff_rec(3, shape_12_251_249, (V[]){v_x_24209, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24211);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24217, v_s_24210});
  }
  default: return heff_nomatch(v_x2_24208);
  }
}
V g_heff_2eemitc_2elentOne_24s647_lam17(V self, V *args) {
  V v_s_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_bi_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24222 = heff_tr(heff_apply(v_m_24220, 1, (V[]){v_s_24221}));
  switch (heff_tag_of(v_x2_24222)) {
  case TAG_MkPair: {
    V v_x_24223 = heff_field(v_x2_24222, 0);
    V v_s_24224 = heff_field(v_x2_24222, 1);
    V v_ru_24x2_24222_24MkPair = heff_take_reuse_n(v_x2_24222, 3ULL, 2);
    V v_t_24225 = ({ V a_0 = heff_dup(v_i_243); V a_1 = v_bi_242; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
    V v_x_24231;
    switch (heff_tag_of(v_t_24225)) {
    case TAG_True: {
      V v_t_24226 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str90), heff_intShow(heff_dup(v_i_243)));
      V v_t_24227 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str91), heff_strAppend(heff_intShow(heff_dup(v_i_243)), heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str92), heff_strAppend(v_x_24223, ((V)&g_heff_2eemitc_2elentOne_24s647_str93)))));
      V v_t_24228 = heff_tag_at(v_ru_24x2_24222_24MkPair, TAG_Cons, 2, (V[]){v_t_24227, NTAG(TAG_Nil)});
      V v_t_24229 = heff_strAppend(((V)&g_heff_2eemitc_2elentOne_24s647_str94), heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eemitc_2elentOne_24s647_str95)));
      V v_t_24230 = heff_tag(TAG_Cons, 2, (V[]){v_t_24229, NTAG(TAG_Nil)});
      v_x_24231 = heff_rec(3, shape_12_251_249, (V[]){v_t_24226, v_t_24228, v_t_24230});
      break;
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24x2_24222_24MkPair, 2);
      v_x_24231 = heff_rec(3, shape_12_251_249, (V[]){v_x_24223, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24225);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24231, v_s_24224});
  }
  default: return heff_nomatch(v_x2_24222);
  }
}
V g_heff_2eemitc_2elentOperands_24s646_lam0(V self, V *args); static Clo g_heff_2eemitc_2elentOperands_24s646_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentOperands_24s646_lam0, 1, 0};
V g_heff_2eemitc_2elentOperands_24s646_lam1(V self, V *args);
Clo g_heff_2eemitc_2elentOperands_24s646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentOperands_24s646_entry, 5, 0};

V g_heff_2eemitc_2elentOperands_24s646(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    return ((V)&g_heff_2eemitc_2elentOperands_24s646_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_246 = heff_field(v_x6_244, 0);
    V v_es_247 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_es_247)));
    V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_prelude_2efoldl_24s621(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_prelude_2econcatList(v_t_249, heff_dup(v_live_241)));
    V v_m_2411 = (g_heff_2eemitc_2elentOne_24s647(heff_dup(v_ce_240), v_t_2410, v_bi_242, heff_dup(v_i_243), v_e_246));
    return heff_clo(g_heff_2eemitc_2elentOperands_24s646_lam1, 1, 6, (V[]){v_m_2411, v_ce_240, v_live_241, heff_dup(v_bi_242), v_i_243, v_es_247});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eemitc_2elentOperands_24s646_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentOperands_24s646(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eemitc_2elentOperands_24s646_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_245});
}
V g_heff_2eemitc_2elentOperands_24s646_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_live_241 = heff_env(self)[2];
  V v_bi_242 = heff_env(self)[3];
  V v_i_243 = heff_env(self)[4];
  V v_es_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_m_2416 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_bi_242; V a_3 = heff_intAdd(v_i_243, MK_INT(1LL)); V a_4 = v_es_247; V r_ = (g_heff_2eemitc_2elentOperands_24s646(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bi_242); r_; });
    V v_x2_2417 = heff_tr(heff_apply(v_m_2416, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_s_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecompF_24s645_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2ecompF_24s645_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecompF_24s645_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2ecompF_24s645_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ecompF_24s645_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2ecompF_24s645_str5 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 95, 116, 114, 40, 104, 101, 102, 102, 95, 97, 112, 112, 108, 121, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s645_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s645_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ecompF_24s645_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 41}};
V g_heff_2eemitc_2ecompF_24s645_lam0(V self, V *args);
V g_heff_2eemitc_2ecompF_24s645_lam1(V self, V *args);
Clo g_heff_2eemitc_2ecompF_24s645_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ecompF_24s645_entry, 3, 0};

V g_heff_2eemitc_2ecompF_24s645(V v_ce_240, V v_live_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_e_242, 0);
    V v_as_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_m_249 = (g_heff_2eemitc_2eoperandsF_24s640(v_ce_240, v_live_241, heff_tag_at(v_ru_24e_242_24EApp, TAG_Cons, 2, (V[]){v_f_247, heff_dup(v_as_248)})));
    return heff_clo(g_heff_2eemitc_2ecompF_24s645_lam0, 1, 2, (V[]){v_m_249, v_as_248});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ECall: {
    V v_g_2441 = heff_field(v_e_242, 0);
    V v_as_2442 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_x2_2443 = ({ V a_0 = heff_dup(v_g_2441); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2445;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nothing: {
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      heff_take_n(v_x2_2443, 1ULL, 1);
      v_t_2445 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    V v_m_2446 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_live_241; V a_2 = v_t_2445; V a_3 = MK_INT(0LL); V a_4 = v_as_2442; V r_ = (g_heff_2eemitc_2elentOperands_24s646(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2445); r_; });
    return heff_clo(g_heff_2eemitc_2ecompF_24s645_lam1, 1, 3, (V[]){v_m_2446, v_g_2441, v_ce_240});
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2ecompF_24s645_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ecompF_24s645(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ecompF_24s645_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_as_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_x2_2416;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nil: {
      v_x2_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_dup(heff_field(v_x_2412, 0));
      v_x2_2416 = heff_tag(TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2eemitc_2ecompF_24s645_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = v_as_248; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_as_248); r_; });
    V v_vs_2420 = (g_prelude_2edrop(MK_INT(1LL), v_x_2412));
    V v_t_2426;
    switch (heff_tag_of(v_vs_2420)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2eemitc_2ecompF_24s645_str1);
      break;
    }
    case TAG_Cons: {
      V v_t_2425;
      switch (heff_tag_of(v_vs_2420)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2eemitc_2ecompF_24s645_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_vs_2420, 0);
        V v_xs_2424 = heff_field(v_vs_2420, 1);
        heff_take_n(v_vs_2420, 3ULL, 2);
        v_t_2425 = ({ V a_0 = v_x_2423; V a_1 = v_xs_2424; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2420);
      }
      v_t_2426 = heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s645_str3), heff_strAppend(v_t_2425, ((V)&g_heff_2eemitc_2ecompF_24s645_str4)));
      break;
    }
    default: heff_nomatch(v_vs_2420);
    }
    V v_x_2427 = heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s645_str5), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s645_str6), heff_strAppend(heff_intShow(v_t_2419), heff_strAppend(((V)&g_heff_2eemitc_2ecompF_24s645_str7), heff_strAppend(v_t_2426, ((V)&g_heff_2eemitc_2ecompF_24s645_str8)))))));
    return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2eemitc_2ecompF_24s645_lam1(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_g_2441 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_apply(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_x3_2451 = ({ V a_0 = heff_dup(v_g_2441); V b_1 = heff_get(v_ce_240, LBL_bounce); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2453;
    switch (heff_tag_of(v_x3_2451)) {
    case TAG_Nothing: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2451, 0ULL, 1);
      v_t_2453 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2451);
    }
    V v_x_2454 = ({ V a_0 = v_g_2441; V a_1 = v_t_2453; V a_2 = v_x_2449; V r_ = (g_heff_2eemitc_2ecallText(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
    return heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){v_x_2454, v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s641_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 100, 117, 112, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2evalF_24s641_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {95, 103, 101, 116, 40, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s641_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s641_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s641_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalF_24s641_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s641_str12 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 114, 101, 99, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s641_str16 = {{0x80000000u, K_STR, 0}, 4, 4, {76, 66, 76, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s641_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 103, 101, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s641_str21 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s641_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {78, 84, 65, 71, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s641_str25 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalF_24s641_str27 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalF_24s641_str29 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s641_str31 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 116, 97, 103, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str32 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str33 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalF_24s641_str36 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2evalF_24s641_str39 = {{0x80000000u, K_STR, 0}, 7, 7, {77, 75, 95, 73, 78, 84, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2evalF_24s641_str40 = {{0x80000000u, K_STR, 0}, 3, 3, {76, 76, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2evalF_24s641_str41 = {{0x80000000u, K_STR, 0}, 10, 10, {72, 69, 70, 70, 95, 66, 73, 71, 40, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str42 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2evalF_24s641_str43 = {{0x80000000u, K_STR, 0}, 10, 10, {72, 69, 70, 70, 95, 66, 73, 71, 40, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalF_24s641_str44 = {{0x80000000u, K_STR, 0}, 2, 2, {34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2evalF_24s641_str45 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 97, 78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2evalF_24s641_str46 = {{0x80000000u, K_STR, 0}, 13, 13, {104, 101, 102, 102, 95, 102, 108, 116, 40, 78, 65, 78, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2evalF_24s641_str47 = {{0x80000000u, K_STR, 0}, 8, 8, {73, 110, 102, 105, 110, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2evalF_24s641_str48 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 95, 102, 108, 116, 40, 73, 78, 70, 73, 78, 73, 84, 89, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s641_str49 = {{0x80000000u, K_STR, 0}, 9, 9, {45, 73, 110, 102, 105, 110, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2evalF_24s641_str50 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 95, 102, 108, 116, 40, 45, 73, 78, 70, 73, 78, 73, 84, 89, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalF_24s641_str51 = {{0x80000000u, K_STR, 0}, 9, 9, {104, 101, 102, 102, 95, 102, 108, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalF_24s641_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2evalF_24s641_str53 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 95, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
V g_heff_2eemitc_2evalF_24s641_lam0(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam1(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam3(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam2(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam4(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam5(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam6(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam7(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam8(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam9(V self, V *args);
V g_heff_2eemitc_2evalF_24s641_lam10(V self, V *args); static Clo g_heff_2eemitc_2evalF_24s641_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evalF_24s641_lam10, 1, 0};
Clo g_heff_2eemitc_2evalF_24s641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evalF_24s641_entry, 3, 0};

V g_heff_2eemitc_2evalF_24s641(V v_ce_240, V v_live_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_x_244 = ({ V b_0 = heff_get(v_ce_240, LBL_borrowed); V a_1 = v_live_241; V a_2 = v_x_243; V r_ = (g_heff_2eemitc_2evarUse(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_live_241); r_; });
    return heff_clo(g_heff_2eemitc_2evalF_24s641_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_EGlobal: {
    V v_g_246 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_x3_247 = ({ V a_0 = heff_dup(v_g_246); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x_2411;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str0), (g_heff_2eemitc_2emangleW(v_g_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s641_str1))));
      v_x_2411 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str2), heff_strAppend(v_t_248, ((V)&g_heff_2eemitc_2evalF_24s641_str3)));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str4), (g_heff_2eemitc_2emangleW(v_g_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s641_str5))));
      v_x_2411 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2eemitc_2evalF_24s641_str7)));
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    return heff_clo(g_heff_2eemitc_2evalF_24s641_lam1, 1, 1, (V[]){v_x_2411});
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_e_242, 0);
    V v_b_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2415 = (g_heff_2eemitc_2efreeOf(heff_dup(v_xs_2413), heff_dup(v_b_2414)));
    return heff_tail(((V)&g_heff_2eemitc_2elamWith_24s642_clo), 5, (V[]){v_ce_240, v_live_241, v_xs_2413, v_b_2414, v_t_2415});
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s645(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s645(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_2422 = (g_prelude_2emap_24s513(heff_dup(v_fs_2421)));
    V v_m_2423 = (g_heff_2eemitc_2eoperandsF_24s640(heff_dup(v_ce_240), v_live_241, v_t_2422));
    return heff_clo(g_heff_2eemitc_2evalF_24s641_lam2, 1, 3, (V[]){v_m_2423, v_ce_240, v_fs_2421});
  }
  case TAG_EProj: {
    V v_e1_2447 = heff_field(v_e_242, 0);
    V v_l_2448 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2449 = heff_tr(g_heff_2eemitc_2evalF_24s641(v_ce_240, v_live_241, v_e1_2447));
    return heff_clo(g_heff_2eemitc_2evalF_24s641_lam4, 1, 2, (V[]){v_m_2449, v_l_2448});
  }
  case TAG_ETag: {
    V v_t_2456 = heff_field(v_e_242, 0);
    V v_as_2457 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2460;
    switch (heff_tag_of(v_as_2457)) {
    case TAG_Nil: {
      v_t_2460 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_as_2457);
    }
    switch (heff_tag_of(v_t_2460)) {
    case TAG_True: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_as_2457);
      V v_t_2461 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str21), (g_heff_2eemitc_2emangleW(v_t_2456, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s641_str22))));
      V v_x_2462 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str23), heff_strAppend(v_t_2461, ((V)&g_heff_2eemitc_2evalF_24s641_str24)));
      return heff_clo(g_heff_2eemitc_2evalF_24s641_lam5, 1, 1, (V[]){v_x_2462});
    }
    case TAG_False: {
      V v_m_2464 = (g_heff_2eemitc_2eoperandsF_24s640(v_ce_240, v_live_241, heff_dup(v_as_2457)));
      return heff_clo(g_heff_2eemitc_2evalF_24s641_lam6, 1, 3, (V[]){v_m_2464, v_t_2456, v_as_2457});
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s645(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EPrim: {
    V v_p_2480 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tail(((V)&g_heff_2eemitc_2eprimLit_clo), 1, (V[]){v_p_2480});
  }
  case TAG_EPrimCall: {
    V v_p_2481 = heff_field(v_e_242, 0);
    V v_as_2482 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2483 = heff_strEq(heff_dup(v_p_2481), heff_dup(g_heff_2eemitc_2ereusePrim_get()));
    switch (heff_tag_of(v_t_2483)) {
    case TAG_True: {
      heff_drop(v_p_2481);
      HEFF_LAST return g_heff_2eemitc_2ereuseVal_24s644(v_ce_240, v_live_241, v_as_2482);
    }
    case TAG_False: {
      V v_m_2484 = (g_heff_2eemitc_2eoperandsF_24s640(v_ce_240, v_live_241, v_as_2482));
      return heff_clo(g_heff_2eemitc_2evalF_24s641_lam7, 1, 2, (V[]){v_m_2484, v_p_2481});
    }
    default: return heff_nomatch(v_t_2483);
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s645(v_ce_240, v_live_241, v_e_242);
  }
  case TAG_EInt: {
    V v_n_2495 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    V v_t_2496 = heff_intLt(heff_dup(v_n_2495), HEFF_BIG("2305843009213693952"));
    V v_x_2498;
    switch (heff_tag_of(v_t_2496)) {
    case TAG_True: {
      V v_t_2497 = heff_intLt(HEFF_BIG("-2305843009213693952"), heff_dup(v_n_2495));
      switch (heff_tag_of(v_t_2497)) {
      case TAG_True: {
        v_x_2498 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str39), heff_strAppend(heff_intShow(v_n_2495), ((V)&g_heff_2eemitc_2evalF_24s641_str40)));
        break;
      }
      case TAG_False: {
        v_x_2498 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str41), heff_strAppend(heff_intShow(v_n_2495), ((V)&g_heff_2eemitc_2evalF_24s641_str42)));
        break;
      }
      default: heff_nomatch(v_t_2497);
      }
      break;
    }
    case TAG_False: {
      v_x_2498 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str43), heff_strAppend(heff_intShow(v_n_2495), ((V)&g_heff_2eemitc_2evalF_24s641_str44)));
      break;
    }
    default: heff_nomatch(v_t_2496);
    }
    return heff_clo(g_heff_2eemitc_2evalF_24s641_lam8, 1, 1, (V[]){v_x_2498});
  }
  case TAG_EFloat: {
    V v_x_24100 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    V v_t_24101 = heff_strEq(heff_floatShow(heff_dup(v_x_24100)), ((V)&g_heff_2eemitc_2evalF_24s641_str45));
    V v_x_24104;
    switch (heff_tag_of(v_t_24101)) {
    case TAG_True: {
      heff_drop(v_x_24100);
      v_x_24104 = ((V)&g_heff_2eemitc_2evalF_24s641_str46);
      break;
    }
    case TAG_False: {
      V v_t_24102 = heff_strEq(heff_floatShow(heff_dup(v_x_24100)), ((V)&g_heff_2eemitc_2evalF_24s641_str47));
      switch (heff_tag_of(v_t_24102)) {
      case TAG_True: {
        heff_drop(v_x_24100);
        v_x_24104 = ((V)&g_heff_2eemitc_2evalF_24s641_str48);
        break;
      }
      case TAG_False: {
        V v_t_24103 = heff_strEq(heff_floatShow(heff_dup(v_x_24100)), ((V)&g_heff_2eemitc_2evalF_24s641_str49));
        switch (heff_tag_of(v_t_24103)) {
        case TAG_True: {
          heff_drop(v_x_24100);
          v_x_24104 = ((V)&g_heff_2eemitc_2evalF_24s641_str50);
          break;
        }
        case TAG_False: {
          v_x_24104 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str51), heff_strAppend(heff_floatShow(v_x_24100), ((V)&g_heff_2eemitc_2evalF_24s641_str52)));
          break;
        }
        default: heff_nomatch(v_t_24103);
        }
        break;
      }
      default: heff_nomatch(v_t_24102);
      }
      break;
    }
    default: heff_nomatch(v_t_24101);
    }
    return heff_clo(g_heff_2eemitc_2evalF_24s641_lam9, 1, 1, (V[]){v_x_24104});
  }
  case TAG_EStr: {
    V v_s_24106 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tail(((V)&g_heff_2eemitc_2estrLit_clo), 1, (V[]){v_s_24106});
  }
  case TAG_EAbandon: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2eemitc_2evalF_24s641_lam10_clo);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2eemitc_2ecompF_24s645(v_ce_240, v_live_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2evalF_24s641_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2evalF_24s641(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2evalF_24s641_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2eemitc_2evalF_24s641_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_s_2412});
}
V g_heff_2eemitc_2evalF_24s641_lam3(V self, V *args) {
  V v_p_2428 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_l_2431;
  switch (heff_tag_of(v_p_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_p_2428, 0);
    heff_take_n(v_p_2428, 1ULL, 2);
    v_l_2431 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_p_2428);
  }
  V v_x2_2432 = ({ V a_0 = v_l_2431; V b_1 = heff_get(v_ce_240, LBL_lbls); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    heff_take_n(v_x2_2432, 1ULL, 1);
    return v_x_2433;
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2eemitc_2evalF_24s641_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_fs_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_apply(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2434 = (g_prelude_2emap(heff_clo(g_heff_2eemitc_2evalF_24s641_lam3, 1, 1, (V[]){v_ce_240}), heff_dup(v_fs_2421)));
    V v_m_2435 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eshapeLit_clo), 1, (V[]){v_t_2434}));
    V v_x2_2436 = heff_tr(heff_apply(v_m_2435, 1, (V[]){v_s_2427}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_s_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_t_2439 = ({ V a_0 = MK_INT(0LL); V a_1 = v_fs_2421; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_fs_2421); r_; });
      V v_t_2445;
      switch (heff_tag_of(v_x_2426)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2eemitc_2evalF_24s641_str8);
        break;
      }
      case TAG_Cons: {
        V v_t_2444;
        switch (heff_tag_of(v_x_2426)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2eemitc_2evalF_24s641_str9);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x_2426, 0);
          V v_xs_2443 = heff_field(v_x_2426, 1);
          heff_take_n(v_x_2426, 3ULL, 2);
          v_t_2444 = ({ V a_0 = v_x_2442; V a_1 = v_xs_2443; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x_2426);
        }
        v_t_2445 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str10), heff_strAppend(v_t_2444, ((V)&g_heff_2eemitc_2evalF_24s641_str11)));
        break;
      }
      default: heff_nomatch(v_x_2426);
      }
      V v_x_2446 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str12), heff_strAppend(heff_intShow(v_t_2439), heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str13), heff_strAppend(v_x_2437, heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str14), heff_strAppend(v_t_2445, ((V)&g_heff_2eemitc_2evalF_24s641_str15)))))));
      return heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_2446, v_s_2438});
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eemitc_2evalF_24s641_lam4(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_l_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_apply(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    V v_t_2454 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str16), (g_heff_2eemitc_2emangleW(v_l_2448, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s641_str17))));
    V v_x_2455 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str18), heff_strAppend(v_x_2452, heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str19), heff_strAppend(v_t_2454, ((V)&g_heff_2eemitc_2evalF_24s641_str20)))));
    return heff_tag_at(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){v_x_2455, v_s_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2eemitc_2evalF_24s641_lam5(V self, V *args) {
  V v_s_2463 = args[0];
  V v_x_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2462, v_s_2463});
}
V g_heff_2eemitc_2evalF_24s641_lam6(V self, V *args) {
  V v_s_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_t_2456 = heff_env(self)[1];
  V v_as_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2466 = heff_tr(heff_apply(v_m_2464, 1, (V[]){v_s_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_s_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    V v_t_2469 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str25), (g_heff_2eemitc_2emangleW(v_t_2456, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalF_24s641_str26))));
    V v_t_2470 = ({ V a_0 = MK_INT(0LL); V a_1 = v_as_2457; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_as_2457); r_; });
    V v_t_2476;
    switch (heff_tag_of(v_x_2467)) {
    case TAG_Nil: {
      v_t_2476 = ((V)&g_heff_2eemitc_2evalF_24s641_str27);
      break;
    }
    case TAG_Cons: {
      V v_t_2475;
      switch (heff_tag_of(v_x_2467)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2eemitc_2evalF_24s641_str28);
        break;
      }
      case TAG_Cons: {
        V v_x_2473 = heff_field(v_x_2467, 0);
        V v_xs_2474 = heff_field(v_x_2467, 1);
        heff_take_n(v_x_2467, 3ULL, 2);
        v_t_2475 = ({ V a_0 = v_x_2473; V a_1 = v_xs_2474; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2474); r_; });
        break;
      }
      default: heff_nomatch(v_x_2467);
      }
      v_t_2476 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str29), heff_strAppend(v_t_2475, ((V)&g_heff_2eemitc_2evalF_24s641_str30)));
      break;
    }
    default: heff_nomatch(v_x_2467);
    }
    V v_x_2477 = heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str31), heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str32), heff_strAppend(heff_intShow(v_t_2470), heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str33), heff_strAppend(v_t_2476, ((V)&g_heff_2eemitc_2evalF_24s641_str34)))))));
    return heff_tag_at(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){v_x_2477, v_s_2468});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2eemitc_2evalF_24s641_lam7(V self, V *args) {
  V v_s_2485 = args[0];
  V v_m_2484 = heff_env(self)[0];
  V v_p_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2486 = heff_tr(heff_apply(v_m_2484, 1, (V[]){v_s_2485}));
  switch (heff_tag_of(v_x2_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_field(v_x2_2486, 0);
    V v_s_2488 = heff_field(v_x2_2486, 1);
    V v_ru_24x2_2486_24MkPair = heff_take_reuse_n(v_x2_2486, 3ULL, 2);
    V v_t_2491;
    switch (heff_tag_of(v_x_2487)) {
    case TAG_Nil: {
      v_t_2491 = ((V)&g_heff_2eemitc_2evalF_24s641_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2489 = heff_field(v_x_2487, 0);
      V v_xs_2490 = heff_field(v_x_2487, 1);
      heff_take_n(v_x_2487, 3ULL, 2);
      v_t_2491 = ({ V a_0 = v_x_2489; V a_1 = v_xs_2490; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2490); r_; });
      break;
    }
    default: heff_nomatch(v_x_2487);
    }
    V v_x_2492 = heff_strAppend(heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str36), v_p_2481), heff_strAppend(((V)&g_heff_2eemitc_2evalF_24s641_str37), heff_strAppend(v_t_2491, ((V)&g_heff_2eemitc_2evalF_24s641_str38))));
    return heff_tag_at(v_ru_24x2_2486_24MkPair, TAG_MkPair, 2, (V[]){v_x_2492, v_s_2488});
  }
  default: return heff_nomatch(v_x2_2486);
  }
}
V g_heff_2eemitc_2evalF_24s641_lam8(V self, V *args) {
  V v_s_2499 = args[0];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2498, v_s_2499});
}
V g_heff_2eemitc_2evalF_24s641_lam9(V self, V *args) {
  V v_s_24105 = args[0];
  V v_x_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24104, v_s_24105});
}
V g_heff_2eemitc_2evalF_24s641_lam10(V self, V *args) {
  V v_s_24107 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2evalF_24s641_str53), v_s_24107});
}
V g_heff_2eemitc_2eoperandsF_24s640_lam0(V self, V *args); static Clo g_heff_2eemitc_2eoperandsF_24s640_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eoperandsF_24s640_lam0, 1, 0};
V g_heff_2eemitc_2eoperandsF_24s640_lam1(V self, V *args);
Clo g_heff_2eemitc_2eoperandsF_24s640_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eoperandsF_24s640_entry, 3, 0};

V g_heff_2eemitc_2eoperandsF_24s640(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return ((V)&g_heff_2eemitc_2eoperandsF_24s640_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s621(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_live_248 = (g_prelude_2econcatList(v_t_247, heff_dup(v_live_241)));
    V v_m_249 = heff_tr(g_heff_2eemitc_2evalF_24s641(heff_dup(v_ce_240), v_live_248, v_e_244));
    return heff_clo(g_heff_2eemitc_2eoperandsF_24s640_lam1, 1, 4, (V[]){v_m_249, v_ce_240, v_live_241, v_es_245});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eemitc_2eoperandsF_24s640_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eoperandsF_24s640(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2eoperandsF_24s640_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_243});
}
V g_heff_2eemitc_2eoperandsF_24s640_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_live_241 = heff_env(self)[2];
  V v_es_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_m_2414 = (g_heff_2eemitc_2eoperandsF_24s640(v_ce_240, v_live_241, v_es_245));
    V v_x2_2415 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_s_2413}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_s_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2412, v_x_2416}), v_s_2417});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str26 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str28 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str33 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str34 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str38 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str39 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str42 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str43 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str44 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str45 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str47 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str48 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str49 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str52 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str54 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str55 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str57 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str58 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str59 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str60 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str62 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str63 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str64 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str65 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str67 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str68 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str69 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str70 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str72 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str73 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str74 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str75 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str77 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str78 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str79 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str80 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str82 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str83 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2ebindTo_24s649_str84 = {{0x80000000u, K_STR, 0}, 2, 2, {86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2ebindTo_24s649_str85 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2ebindTo_24s649_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
V g_heff_2eemitc_2ebindTo_24s649_lam0(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam1(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam2(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam3(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam4(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam5(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam6(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam7(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam8(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam9(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam10(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam11(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam12(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam13(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam14(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam15(V self, V *args);
V g_heff_2eemitc_2ebindTo_24s649_lam16(V self, V *args);
Clo g_heff_2eemitc_2ebindTo_24s649_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ebindTo_24s649_entry, 3, 0};

V g_heff_2eemitc_2ebindTo_24s649(V v_ce_240, V v_x_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam0, 1, 2, (V[]){v_m_244, v_x_241});
  }
  case TAG_EGlobal: {
    V v_m_2413 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam1, 1, 2, (V[]){v_m_2413, v_x_241});
  }
  case TAG_ELam: {
    V v_m_2423 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam2, 1, 2, (V[]){v_m_2423, v_x_241});
  }
  case TAG_EApp: {
    V v_m_2433 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam3, 1, 2, (V[]){v_m_2433, v_x_241});
  }
  case TAG_ELet: {
    V v_y_2441 = heff_field(v_a_242, 0);
    V v_a2_2442 = heff_field(v_a_242, 1);
    V v_b_2443 = heff_field(v_a_242, 2);
    V v_ru_24a_242_24ELet = heff_take_reuse_n(v_a_242, 7ULL, 3);
    V v_t_2444 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str20), (g_heff_2eemitc_2emangleW(heff_dup(v_x_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str21))));
    V v_dest_2445 = heff_tag(TAG_Asg, 1, (V[]){v_t_2444});
    V v_m_2446 = (g_heff_2eemitc_2estmtsF_24s639(v_ce_240, v_dest_2445, heff_tag_at(v_ru_24a_242_24ELet, TAG_ELet, 3, (V[]){v_y_2441, v_a2_2442, v_b_2443})));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam4, 1, 2, (V[]){v_m_2446, v_x_241});
  }
  case TAG_ERecord: {
    V v_m_2455 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam5, 1, 2, (V[]){v_m_2455, v_x_241});
  }
  case TAG_EProj: {
    V v_m_2465 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam6, 1, 2, (V[]){v_m_2465, v_x_241});
  }
  case TAG_ETag: {
    V v_m_2475 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam7, 1, 2, (V[]){v_m_2475, v_x_241});
  }
  case TAG_EMatch: {
    V v_s_2483 = heff_field(v_a_242, 0);
    V v_arms_2484 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EMatch = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_t_2485 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str41), (g_heff_2eemitc_2emangleW(heff_dup(v_x_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str42))));
    V v_dest_2486 = heff_tag(TAG_Asg, 1, (V[]){v_t_2485});
    V v_m_2487 = (g_heff_2eemitc_2estmtsF_24s639(v_ce_240, v_dest_2486, heff_tag_at(v_ru_24a_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2483, v_arms_2484})));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam8, 1, 2, (V[]){v_m_2487, v_x_241});
  }
  case TAG_EPrim: {
    V v_m_2496 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam9, 1, 2, (V[]){v_m_2496, v_x_241});
  }
  case TAG_EPrimCall: {
    V v_m_24106 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam10, 1, 2, (V[]){v_m_24106, v_x_241});
  }
  case TAG_ECall: {
    V v_m_24116 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam11, 1, 2, (V[]){v_m_24116, v_x_241});
  }
  case TAG_EInt: {
    V v_m_24125 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam12, 1, 2, (V[]){v_m_24125, v_x_241});
  }
  case TAG_EFloat: {
    V v_m_24134 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam13, 1, 2, (V[]){v_m_24134, v_x_241});
  }
  case TAG_EStr: {
    V v_m_24143 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam14, 1, 2, (V[]){v_m_24143, v_x_241});
  }
  case TAG_EAbandon: {
    V v_m_24151 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam15, 1, 2, (V[]){v_m_24151, v_x_241});
  }
  case TAG_EFix: {
    V v_m_24161 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_a_242));
    return heff_clo(g_heff_2eemitc_2ebindTo_24s649_lam16, 1, 2, (V[]){v_m_24161, v_x_241});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ebindTo_24s649(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2ebindTo_24s649_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str0), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str1))));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str3), heff_strAppend(v_x_247, ((V)&g_heff_2eemitc_2ebindTo_24s649_str4)))));
    V v_x_2411 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str5), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str6))));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str7), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str8), heff_strAppend(v_x_2416, ((V)&g_heff_2eemitc_2ebindTo_24s649_str9)))));
    V v_x_2420 = heff_tag_at(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_apply(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2428 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str10), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str11))));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str12), heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str13), heff_strAppend(v_x_2426, ((V)&g_heff_2eemitc_2ebindTo_24s649_str14)))));
    V v_x_2430 = heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2430, v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam3(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2435 = heff_tr(heff_apply(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2438 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str15), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str16))));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str17), heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str18), heff_strAppend(v_x_2436, ((V)&g_heff_2eemitc_2ebindTo_24s649_str19)))));
    V v_x_2440 = heff_tag_at(v_ru_24x2_2435_24MkPair, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam4(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2448 = heff_tr(heff_apply(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_t_2451 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str22), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str23))));
    V v_t_2452 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str24), heff_strAppend(v_t_2451, ((V)&g_heff_2eemitc_2ebindTo_24s649_str25)));
    V v_x_2453 = heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_Cons, 2, (V[]){v_t_2452, v_x_2449});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2453, v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam5(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2457 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2460 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str26), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str27))));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str28), heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str29), heff_strAppend(v_x_2458, ((V)&g_heff_2eemitc_2ebindTo_24s649_str30)))));
    V v_x_2462 = heff_tag_at(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2462, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam6(V self, V *args) {
  V v_s_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2467 = heff_tr(heff_apply(v_m_2465, 1, (V[]){v_s_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_s_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str31), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str32))));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str33), heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str34), heff_strAppend(v_x_2468, ((V)&g_heff_2eemitc_2ebindTo_24s649_str35)))));
    V v_x_2472 = heff_tag_at(v_ru_24x2_2467_24MkPair, TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2472, v_s_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam7(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2477 = heff_tr(heff_apply(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str36), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str37))));
    V v_t_2481 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str38), heff_strAppend(v_t_2480, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str39), heff_strAppend(v_x_2478, ((V)&g_heff_2eemitc_2ebindTo_24s649_str40)))));
    V v_x_2482 = heff_tag_at(v_ru_24x2_2477_24MkPair, TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2482, v_s_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam8(V self, V *args) {
  V v_s_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2489 = heff_tr(heff_apply(v_m_2487, 1, (V[]){v_s_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_s_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_t_2492 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str43), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str44))));
    V v_t_2493 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str45), heff_strAppend(v_t_2492, ((V)&g_heff_2eemitc_2ebindTo_24s649_str46)));
    V v_x_2494 = heff_tag_at(v_ru_24x2_2489_24MkPair, TAG_Cons, 2, (V[]){v_t_2493, v_x_2490});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2494, v_s_2491});
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam9(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_apply(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    V v_t_24101 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str47), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str48))));
    V v_t_24102 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str49), heff_strAppend(v_t_24101, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str50), heff_strAppend(v_x_2499, ((V)&g_heff_2eemitc_2ebindTo_24s649_str51)))));
    V v_x_24103 = heff_tag_at(v_ru_24x2_2498_24MkPair, TAG_Cons, 2, (V[]){v_t_24102, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24103, v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam10(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24108 = heff_tr(heff_apply(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
    V v_t_24111 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str52), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str53))));
    V v_t_24112 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str54), heff_strAppend(v_t_24111, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str55), heff_strAppend(v_x_24109, ((V)&g_heff_2eemitc_2ebindTo_24s649_str56)))));
    V v_x_24113 = heff_tag_at(v_ru_24x2_24108_24MkPair, TAG_Cons, 2, (V[]){v_t_24112, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24113, v_s_24110});
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam11(V self, V *args) {
  V v_s_24117 = args[0];
  V v_m_24116 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24118 = heff_tr(heff_apply(v_m_24116, 1, (V[]){v_s_24117}));
  switch (heff_tag_of(v_x2_24118)) {
  case TAG_MkPair: {
    V v_x_24119 = heff_field(v_x2_24118, 0);
    V v_s_24120 = heff_field(v_x2_24118, 1);
    V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
    V v_t_24121 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str57), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str58))));
    V v_t_24122 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str59), heff_strAppend(v_t_24121, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str60), heff_strAppend(v_x_24119, ((V)&g_heff_2eemitc_2ebindTo_24s649_str61)))));
    V v_x_24123 = heff_tag_at(v_ru_24x2_24118_24MkPair, TAG_Cons, 2, (V[]){v_t_24122, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24123, v_s_24120});
  }
  default: return heff_nomatch(v_x2_24118);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam12(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24127 = heff_tr(heff_apply(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str62), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str63))));
    V v_t_24131 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str64), heff_strAppend(v_t_24130, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str65), heff_strAppend(v_x_24128, ((V)&g_heff_2eemitc_2ebindTo_24s649_str66)))));
    V v_x_24132 = heff_tag_at(v_ru_24x2_24127_24MkPair, TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24132, v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam13(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24136 = heff_tr(heff_apply(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_t_24139 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str67), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str68))));
    V v_t_24140 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str69), heff_strAppend(v_t_24139, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str70), heff_strAppend(v_x_24137, ((V)&g_heff_2eemitc_2ebindTo_24s649_str71)))));
    V v_x_24141 = heff_tag_at(v_ru_24x2_24136_24MkPair, TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24138});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam14(V self, V *args) {
  V v_s_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24145 = heff_tr(heff_apply(v_m_24143, 1, (V[]){v_s_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_s_24147 = heff_field(v_x2_24145, 1);
    V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
    V v_t_24148 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str72), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str73))));
    V v_t_24149 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str74), heff_strAppend(v_t_24148, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str75), heff_strAppend(v_x_24146, ((V)&g_heff_2eemitc_2ebindTo_24s649_str76)))));
    V v_x_24150 = heff_tag_at(v_ru_24x2_24145_24MkPair, TAG_Cons, 2, (V[]){v_t_24149, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24150, v_s_24147});
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam15(V self, V *args) {
  V v_s_24152 = args[0];
  V v_m_24151 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24153 = heff_tr(heff_apply(v_m_24151, 1, (V[]){v_s_24152}));
  switch (heff_tag_of(v_x2_24153)) {
  case TAG_MkPair: {
    V v_x_24154 = heff_field(v_x2_24153, 0);
    V v_s_24155 = heff_field(v_x2_24153, 1);
    V v_ru_24x2_24153_24MkPair = heff_take_reuse_n(v_x2_24153, 3ULL, 2);
    V v_t_24156 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str77), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str78))));
    V v_t_24157 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str79), heff_strAppend(v_t_24156, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str80), heff_strAppend(v_x_24154, ((V)&g_heff_2eemitc_2ebindTo_24s649_str81)))));
    V v_x_24158 = heff_tag_at(v_ru_24x2_24153_24MkPair, TAG_Cons, 2, (V[]){v_t_24157, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24158, v_s_24155});
  }
  default: return heff_nomatch(v_x2_24153);
  }
}
V g_heff_2eemitc_2ebindTo_24s649_lam16(V self, V *args) {
  V v_s_24162 = args[0];
  V v_m_24161 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24163 = heff_tr(heff_apply(v_m_24161, 1, (V[]){v_s_24162}));
  switch (heff_tag_of(v_x2_24163)) {
  case TAG_MkPair: {
    V v_x_24164 = heff_field(v_x2_24163, 0);
    V v_s_24165 = heff_field(v_x2_24163, 1);
    V v_ru_24x2_24163_24MkPair = heff_take_reuse_n(v_x2_24163, 3ULL, 2);
    V v_t_24166 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str82), (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2ebindTo_24s649_str83))));
    V v_t_24167 = heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str84), heff_strAppend(v_t_24166, heff_strAppend(((V)&g_heff_2eemitc_2ebindTo_24s649_str85), heff_strAppend(v_x_24164, ((V)&g_heff_2eemitc_2ebindTo_24s649_str86)))));
    V v_x_24168 = heff_tag_at(v_ru_24x2_24163_24MkPair, TAG_Cons, 2, (V[]){v_t_24167, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24168, v_s_24165});
  }
  default: return heff_nomatch(v_x2_24163);
  }
}
V g_heff_2eemitc_2eletWith_24s648_lam0(V self, V *args);
V g_heff_2eemitc_2eletWith_24s648_lam2(V self, V *args);
V g_heff_2eemitc_2eletWith_24s648_lam3(V self, V *args);
V g_heff_2eemitc_2eletWith_24s648_lam1(V self, V *args);
Clo g_heff_2eemitc_2eletWith_24s648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eletWith_24s648_entry, 7, 0};

V g_heff_2eemitc_2eletWith_24s648(V v_ce_240, V v_dest_241, V v_x_242, V v_a_243, V v_b_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_wanted_247 = (g_prelude_2econcatList(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_owned_249 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eletWith_24s648_lam0, 1, 1, (V[]){v_wanted_247}), heff_get(heff_dup(v_ce_240), LBL_owned)));
  V v_t_2410 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_get(heff_dup(v_ce_240), LBL_self), heff_get(heff_dup(v_ce_240), LBL_lam), v_owned_249, heff_dup(v_wb_246), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
  V v_m_2411 = (g_heff_2eemitc_2ebindTo_24s649(v_t_2410, heff_dup(v_x_242), heff_dup(v_a_243)));
  return heff_clo(g_heff_2eemitc_2eletWith_24s648_lam1, 1, 8, (V[]){v_m_2411, v_wb_246, v_ce_240, v_x_242, v_a_243, v_dest_241, v_b_244, v_fa_245});
}
V g_heff_2eemitc_2eletWith_24s648_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eletWith_24s648(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eemitc_2eletWith_24s648_lam0(V self, V *args) {
  V v_v_248 = args[0];
  V v_wanted_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_248; V a_1 = v_wanted_247; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_247); r_; });
}
V g_heff_2eemitc_2eletWith_24s648_lam2(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wb_246; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
V g_heff_2eemitc_2eletWith_24s648_lam3(V self, V *args) {
  V v_v_2429 = args[0];
  V v_wanted_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2430 = ({ V a_0 = v_v_2429; V a_1 = v_wanted_2428; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2428); r_; });
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2eemitc_2eletWith_24s648_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_wb_246 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_a_243 = heff_env(self)[4];
  V v_dest_241 = heff_env(self)[5];
  V v_b_244 = heff_env(self)[6];
  V v_fa_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2417 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eletWith_24s648_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_get(heff_dup(v_ce_240), LBL_owned)));
    V v_t_2418 = (g_heff_2eemitc_2eelemS(heff_dup(v_x_242), v_wb_246));
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_owned_2420 = (g_prelude_2econcatList(v_t_2417, v_t_2419));
    V v_t_2421 = (g_heff_2eemitc_2ebuiltOf(v_a_243));
    V v_ce_2422 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2421; V a_2 = heff_dup(v_ce_240); V r_ = (g_heff_2eemitc_2eknownLet(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
    V v_ce_2423 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_2422), LBL_tags), heff_get(heff_dup(v_ce_2422), LBL_lbls), heff_get(heff_dup(v_ce_2422), LBL_funs), heff_get(heff_dup(v_ce_2422), LBL_bounce), heff_get(heff_dup(v_ce_2422), LBL_self), heff_get(heff_dup(v_ce_2422), LBL_lam), v_owned_2420, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_2422), LBL_borrowed), heff_get(heff_dup(v_ce_2422), LBL_bor), heff_get(v_ce_2422, LBL_known)});
    V v_m_2424 = (g_heff_2eemitc_2estmtsF_24s639(v_ce_2423, v_dest_241, v_b_244));
    V v_x2_2425 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_s_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
      V v_wanted_2428 = (g_prelude_2econcatList(v_fa_245, heff_dup(v_wb_246)));
      V v_t_2431 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eletWith_24s648_lam3, 1, 1, (V[]){v_wanted_2428}), heff_get(heff_dup(v_ce_240), LBL_owned)));
      V v_t_2432 = (g_heff_2eemitc_2edropsIn(heff_dup(v_ce_240), v_t_2431));
      V v_t_2433 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_wb_246; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
      V v_t_2437;
      switch (heff_tag_of(v_t_2433)) {
      case TAG_True: {
        heff_drop(v_ce_240);
        heff_drop(v_x_242);
        heff_drop(v_a_243);
        heff_drop_cell(v_ru_24x2_2425_24MkPair, 2);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_False: {
        V v_t_2434 = ({ V a_0 = v_a_243; V r_ = (g_heff_2eemitc_2ebuiltOf(a_0)); heff_drop(v_a_243); r_; });
        V v_t_2435 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2434; V a_2 = v_ce_240; V r_ = (g_heff_2eemitc_2eknownLet(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
        V v_t_2436 = heff_tag_at(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
        v_t_2437 = (g_heff_2eemitc_2edropsIn(v_t_2435, v_t_2436));
        break;
      }
      default: heff_nomatch(v_t_2433);
      }
      V v_t_2438 = (g_prelude_2econcatList(v_t_2437, v_x_2426));
      V v_t_2439 = (g_prelude_2econcatList(v_x_2414, v_t_2438));
      V v_x_2440 = (g_prelude_2econcatList(v_t_2432, v_t_2439));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2427});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2escrutF_24s650_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {118, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2escrutF_24s650_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2escrutF_24s650_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2escrutF_24s650_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2escrutF_24s650_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {95, 103, 101, 116, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2escrutF_24s650_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2escrutF_24s650_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2escrutF_24s650_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2escrutF_24s650_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 99, 108, 111, 41}};
V g_heff_2eemitc_2escrutF_24s650_lam0(V self, V *args);
V g_heff_2eemitc_2escrutF_24s650_lam1(V self, V *args);
Clo g_heff_2eemitc_2escrutF_24s650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2escrutF_24s650_entry, 2, 0};

V g_heff_2eemitc_2escrutF_24s650(V v_ce_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop(v_ce_240);
    V v_x_243 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s650_str0), (g_heff_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2escrutF_24s650_str1))));
    return heff_clo(g_heff_2eemitc_2escrutF_24s650_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_246 = ({ V a_0 = heff_dup(v_g_245); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x_2410;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s650_str2), (g_heff_2eemitc_2emangleW(v_g_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2escrutF_24s650_str3))));
      v_x_2410 = heff_strAppend(v_t_247, ((V)&g_heff_2eemitc_2escrutF_24s650_str4));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s650_str5), (g_heff_2eemitc_2emangleW(v_g_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2escrutF_24s650_str6))));
      v_x_2410 = heff_strAppend(((V)&g_heff_2eemitc_2escrutF_24s650_str7), heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2escrutF_24s650_str8)));
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    return heff_clo(g_heff_2eemitc_2escrutF_24s650_lam1, 1, 1, (V[]){v_x_2410});
  }
  case TAG_ELam: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2eemitc_2evalF_24s641(v_ce_240, NTAG(TAG_Nil), v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2eemitc_2escrutF_24s650_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2escrutF_24s650(a[0], a[1]);
}
V g_heff_2eemitc_2escrutF_24s650_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_243, v_s_244});
}
V g_heff_2eemitc_2escrutF_24s650_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_s_2411});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2earmKept_24s652_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 65, 71, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2earmKept_24s652_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2earmKept_24s652_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 115, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2earmKept_24s652_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {58, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2earmKept_24s652_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {104, 101, 102, 102, 95, 116, 97, 107, 101, 95, 110, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2earmKept_24s652_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2earmKept_24s652_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 76, 76, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2earmKept_24s652_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2earmKept_24s652_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 98, 114, 101, 97, 107, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2earmKept_24s652_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2eemitc_2earmKept_24s652_lam0(V self, V *args);
V g_heff_2eemitc_2earmKept_24s652_lam1(V self, V *args);
V g_heff_2eemitc_2earmKept_24s652_lam3(V self, V *args);
V g_heff_2eemitc_2earmKept_24s652_lam4(V self, V *args);
V g_heff_2eemitc_2earmKept_24s652_lam5(V self, V *args);
V g_heff_2eemitc_2earmKept_24s652_lam6(V self, V *args);
V g_heff_2eemitc_2earmKept_24s652_lam2(V self, V *args);
Clo g_heff_2eemitc_2earmKept_24s652_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2earmKept_24s652_entry, 10, 0};

V g_heff_2eemitc_2earmKept_24s652(V v_ce_240, V v_dest_241, V v_sv_242, V v_taken_243, V v_lent_244, V v_t_245, V v_vs_246, V v_b_247, V v_fb_248, V v_x11_249) {
top: ;
  switch (heff_tag_of(v_x11_249)) {
  case TAG_MkPair: {
    V v_ru_2410 = heff_field(v_x11_249, 0);
    V v_b2_2411 = heff_field(v_x11_249, 1);
    V v_ru_24x11_249_24MkPair = heff_take_reuse_n(v_x11_249, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_t_2413 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2413 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s652_lam0, 1, 1, (V[]){heff_dup(v_fb_248)}), heff_dup(v_vs_246)));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x11_249_24MkPair, 2);
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_dup(heff_field(v_ru_2410, 0));
      v_t_2415 = heff_tag_at(v_ru_24x11_249_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2416 = (g_prelude_2econcatList(v_t_2413, v_t_2415));
    V v_owned_2417 = (g_prelude_2econcatList(heff_get(heff_dup(v_ce_240), LBL_owned), v_t_2416));
    V v_t_2419;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_dup(heff_field(v_ru_2410, 0));
      v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2420 = (g_prelude_2econcatList(heff_dup(v_fb_248), v_t_2419));
    V v_wanted_2421 = (g_prelude_2econcatList(v_t_2420, heff_get(heff_dup(v_ce_240), LBL_after)));
    V v_owned_2423 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s652_lam1, 1, 1, (V[]){v_wanted_2421}), v_owned_2417));
    V v_bs_2424;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_bs_2424 = (g_prelude_2econcatList(heff_dup(v_vs_246), heff_get(heff_dup(v_ce_240), LBL_borrowed)));
      break;
    }
    case TAG_False: {
      v_bs_2424 = heff_get(heff_dup(v_ce_240), LBL_borrowed);
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_t_2425 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_246));
    V v_ce_2426 = (g_heff_2eemitc_2eknowCell(heff_dup(v_ru_2410), v_t_2425, heff_dup(v_ce_240)));
    V v_ce_2427 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_2426), LBL_tags), heff_get(heff_dup(v_ce_2426), LBL_lbls), heff_get(heff_dup(v_ce_2426), LBL_funs), heff_get(heff_dup(v_ce_2426), LBL_bounce), heff_get(heff_dup(v_ce_2426), LBL_self), heff_get(heff_dup(v_ce_2426), LBL_lam), heff_get(heff_dup(v_ce_2426), LBL_owned), heff_get(heff_dup(v_ce_2426), LBL_after), v_bs_2424, heff_get(heff_dup(v_ce_2426), LBL_bor), heff_get(v_ce_2426, LBL_known)});
    V v_ce_2428 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_2427), LBL_tags), heff_get(heff_dup(v_ce_2427), LBL_lbls), heff_get(heff_dup(v_ce_2427), LBL_funs), heff_get(heff_dup(v_ce_2427), LBL_bounce), heff_get(heff_dup(v_ce_2427), LBL_self), heff_get(heff_dup(v_ce_2427), LBL_lam), v_owned_2423, heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_2427), LBL_borrowed), heff_get(heff_dup(v_ce_2427), LBL_bor), heff_get(v_ce_2427, LBL_known)});
    V v_m_2429 = (g_heff_2eemitc_2estmtsF_24s639(v_ce_2428, heff_dup(v_dest_241), v_b2_2411));
    return heff_clo(g_heff_2eemitc_2earmKept_24s652_lam2, 1, 10, (V[]){v_m_2429, v_t_245, heff_dup(v_lent_244), heff_dup(v_taken_243), v_sv_242, v_fb_248, v_vs_246, v_ru_2410, v_ce_240, v_dest_241});
  }
  default: return heff_nomatch(v_x11_249);
  }
}
V g_heff_2eemitc_2earmKept_24s652_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2earmKept_24s652(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[3]); heff_drop(a[4]); heff_drop(a[7]); return r;
}
V g_heff_2eemitc_2earmKept_24s652_lam0(V self, V *args) {
  V v_v_2412 = args[0];
  V v_fb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2412; V a_1 = v_fb_248; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_fb_248); r_; });
}
V g_heff_2eemitc_2earmKept_24s652_lam1(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wanted_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wanted_2421; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2421); r_; });
}
V g_heff_2eemitc_2earmKept_24s652_lam3(V self, V *args) {
  V v_acc_2444 = args[0];
  V v_x_2445 = args[1];
  V v_f_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_apply(v_f_2439, 1, (V[]){v_x_2445}));
  return (g_prelude_2econcatList(v_t_2446, v_acc_2444));
}
V g_heff_2eemitc_2earmKept_24s652_lam4(V self, V *args) {
  V v_v_2454 = args[0];
  V v_fb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2454; V a_1 = v_fb_248; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_fb_248); r_; });
}
V g_heff_2eemitc_2earmKept_24s652_lam5(V self, V *args) {
  V v_v_2458 = args[0];
  V v_wanted_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2459 = ({ V a_0 = v_v_2458; V a_1 = v_wanted_2457; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2457); r_; });
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2459);
  }
}
V g_heff_2eemitc_2earmKept_24s652_lam6(V self, V *args) {
  V v_v_2461 = args[0];
  V v_taken_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463;
  switch (heff_tag_of(v_taken_243)) {
  case TAG_Nothing: {
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2462 = heff_field(v_taken_243, 0);
    heff_take_n(v_taken_243, 1ULL, 1);
    v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_x_2462, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_taken_243);
  }
  V v_x1_2464 = ({ V a_0 = v_v_2461; V a_1 = v_t_2463; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2463); r_; });
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2eemitc_2earmKept_24s652_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_lent_244 = heff_env(self)[2];
  V v_taken_243 = heff_env(self)[3];
  V v_sv_242 = heff_env(self)[4];
  V v_fb_248 = heff_env(self)[5];
  V v_vs_246 = heff_env(self)[6];
  V v_ru_2410 = heff_env(self)[7];
  V v_ce_240 = heff_env(self)[8];
  V v_dest_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2431 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s652_str0), (g_heff_2eemitc_2emangleW(v_t_245, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2earmKept_24s652_str1))));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s652_str2), heff_strAppend(v_t_2434, ((V)&g_heff_2eemitc_2earmKept_24s652_str3)));
    V v_t_2436 = heff_tag_at(v_ru_24x2_2431_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
    V v_t_2438;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_taken_243)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_taken_243);
      }
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_f_2439 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2efieldLine_clo), 3, (V[]){heff_dup(v_sv_242), v_t_2438, heff_dup(v_fb_248)}));
    V v_t_2440 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_246));
    V v_t_2441 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2440, MK_INT(1LL))));
    V v_xs_2442 = (g_prelude_2ezipWith_24s634(heff_dup(v_vs_246), v_t_2441));
    V v_t_2443 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2442));
    V v_t_2447 = ({ V a_0 = heff_clo(g_heff_2eemitc_2earmKept_24s652_lam3, 2, 1, (V[]){v_f_2439}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2443; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2443); r_; });
    V v_t_2453;
    switch (heff_tag_of(v_ru_2410)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_taken_243)) {
      case TAG_Nothing: {
        heff_drop(v_sv_242);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2449 = (g_heff_2eemitc_2efieldMask(v_fb_248, MK_INT(0LL), v_vs_246));
        V v_t_2450 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_246));
        V v_t_2451 = heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s652_str4), heff_strAppend(v_sv_242, heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s652_str5), heff_strAppend(heff_intShow(v_t_2449), heff_strAppend(((V)&g_heff_2eemitc_2earmKept_24s652_str6), heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2eemitc_2earmKept_24s652_str7)))))));
        v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_taken_243);
      }
      break;
    }
    case TAG_Just: {
      v_t_2453 = ({ V a_0 = v_sv_242; V a_1 = v_ru_2410; V a_2 = v_vs_246; V a_3 = v_fb_248; V r_ = (g_heff_2eemitc_2etakeKept(a_0, a_1, a_2, a_3)); heff_drop_tag(v_ru_2410, 1); r_; });
      break;
    }
    default: heff_nomatch(v_ru_2410);
    }
    V v_t_2455;
    switch (heff_tag_of(v_lent_244)) {
    case TAG_True: {
      heff_drop(v_vs_246);
      v_t_2455 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2455 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s652_lam4, 1, 1, (V[]){heff_dup(v_fb_248)}), v_vs_246));
      break;
    }
    default: heff_nomatch(v_lent_244);
    }
    V v_owned_2456 = (g_prelude_2econcatList(heff_get(heff_dup(v_ce_240), LBL_owned), v_t_2455));
    V v_wanted_2457 = (g_prelude_2econcatList(v_fb_248, heff_get(heff_dup(v_ce_240), LBL_after)));
    V v_t_2460 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s652_lam5, 1, 1, (V[]){v_wanted_2457}), v_owned_2456));
    V v_t_2465 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2earmKept_24s652_lam6, 1, 1, (V[]){v_taken_243}), v_t_2460));
    V v_t_2466 = (g_heff_2eemitc_2edropsIn(v_ce_240, v_t_2465));
    V v_t_2467 = (g_prelude_2econcatList(v_t_2453, v_t_2466));
    V v_t_2468 = (g_prelude_2emap_24s177(v_t_2467));
    V v_t_2469 = (g_prelude_2emap_24s177(v_x_2432));
    V v_t_2471;
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      v_t_2471 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Asg: {
      heff_take_n(v_dest_241, 0ULL, 1);
      v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2earmKept_24s652_str8), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_dest_241);
    }
    V v_t_2472 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2earmKept_24s652_str9), NTAG(TAG_Nil)});
    V v_t_2473 = (g_prelude_2econcatList(v_t_2471, v_t_2472));
    V v_t_2474 = (g_prelude_2econcatList(v_t_2469, v_t_2473));
    V v_t_2475 = (g_prelude_2econcatList(v_t_2468, v_t_2474));
    V v_t_2476 = (g_prelude_2econcatList(v_t_2447, v_t_2475));
    V v_x_2477 = (g_prelude_2econcatList(v_t_2436, v_t_2476));
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
Clo g_heff_2eemitc_2earmLines_24s651_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2earmLines_24s651_entry, 6, 0};

V g_heff_2eemitc_2earmLines_24s651(V v_ce_240, V v_dest_241, V v_sv_242, V v_held_243, V v_lent_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_MkArm: {
    V v_t_246 = heff_field(v_x7_245, 0);
    V v_vs_247 = heff_field(v_x7_245, 1);
    V v_b_248 = heff_field(v_x7_245, 2);
    V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_247));
    V v_ce_2410 = (g_heff_2eemitc_2eknowing(heff_dup(v_held_243), v_t_249, v_ce_240));
    V v_fb_2411 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_248)));
    V v_taken_2412 = (g_heff_2eemitc_2etakenFv(heff_dup(v_ce_2410), v_held_243, v_vs_247, v_fb_2411));
    V v_t_2413 = (g_heff_2eemitc_2ereusing(heff_dup(v_taken_2412), heff_dup(v_t_246), v_vs_247, heff_dup(v_b_248)));
    return ({ V a_0 = v_ce_2410; V a_1 = v_dest_241; V a_2 = v_sv_242; V a_3 = v_taken_2412; V a_4 = v_lent_244; V a_5 = heff_dup(v_t_246); V a_6 = heff_dup(v_vs_247); V a_7 = v_b_248; V a_8 = v_fb_2411; V a_9 = v_t_2413; V r_ = (g_heff_2eemitc_2earmKept_24s652(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_taken_2412); r_; });
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eemitc_2earmLines_24s651_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2earmLines_24s651(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[4]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estmtsF_24s639_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {78, 85, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2estmtsF_24s639_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 86, 91, 93, 41, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2estmtsF_24s639_str17 = {{0x80000000u, K_STR, 0}, 17, 17, {114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 116, 97, 105, 108, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str23 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str25 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str27 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str31 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str33 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2estmtsF_24s639_str35 = {{0x80000000u, K_STR, 0}, 20, 20, {115, 119, 105, 116, 99, 104, 32, 40, 104, 101, 102, 102, 95, 116, 97, 103, 95, 111, 102, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2estmtsF_24s639_str36 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eemitc_2estmtsF_24s639_str37 = {{0x80000000u, K_STR, 0}, 29, 29, {100, 101, 102, 97, 117, 108, 116, 58, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str38 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2estmtsF_24s639_str39 = {{0x80000000u, K_STR, 0}, 22, 22, {100, 101, 102, 97, 117, 108, 116, 58, 32, 104, 101, 102, 102, 95, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str40 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str42 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str44 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str46 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str48 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str50 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str51 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str52 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2estmtsF_24s639_str53 = {{0x80000000u, K_STR, 0}, 17, 17, {72, 69, 70, 70, 95, 76, 65, 83, 84, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2estmtsF_24s639_str55 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str56 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str58 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str60 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str62 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str64 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str65 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str66 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str68 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str69 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str70 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str72 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str73 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str74 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2estmtsF_24s639_str76 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str77 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2estmtsF_24s639_str78 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2estmtsF_24s639_str79 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
V g_heff_2eemitc_2estmtsF_24s639_lam0(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam1(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam2(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam3(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam4(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam5(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam6(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam7(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam8(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam9(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam10(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam11(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam12(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam13(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam14(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam15(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam16(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam17(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam18(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam19(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam20(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam21(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam22(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam23(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam24(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam25(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam26(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam27(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam28(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam29(V self, V *args);
V g_heff_2eemitc_2estmtsF_24s639_lam30(V self, V *args);
Clo g_heff_2eemitc_2estmtsF_24s639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2estmtsF_24s639_entry, 3, 0};

V g_heff_2eemitc_2estmtsF_24s639(V v_ce_240, V v_dest_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_244 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam0, 1, 1, (V[]){v_m_244});
    }
    case TAG_Asg: {
      V v_x_2411 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2412 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam1, 1, 2, (V[]){v_m_2412, v_x_2411});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2420 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam2, 1, 1, (V[]){v_m_2420});
    }
    case TAG_Asg: {
      V v_x_2427 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2428 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam3, 1, 2, (V[]){v_m_2428, v_x_2427});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ELam: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2437 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam4, 1, 1, (V[]){v_m_2437});
    }
    case TAG_Asg: {
      V v_x_2444 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_2445 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam5, 1, 2, (V[]){v_m_2445, v_x_2444});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EApp: {
    V v_f_2452 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2453 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      heff_drop_tag(v_e_242, 2);
      V v_m_2454 = (g_heff_2eemitc_2eoperandsF_24s640(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_f_2452, heff_dup(v_as_2453)})));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam6, 1, 3, (V[]){v_m_2454, v_as_2453, v_ce_240});
    }
    case TAG_Asg: {
      V v_x_2478 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      heff_drop(v_f_2452);
      heff_drop(v_as_2453);
      V v_m_2479 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam7, 1, 2, (V[]){v_m_2479, v_x_2478});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ELet: {
    V v_x_2486 = heff_field(v_e_242, 0);
    V v_a_2487 = heff_field(v_e_242, 1);
    V v_b_2488 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2489 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_a_2487)));
    V v_t_2490 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_2488)));
    V v_t_2491 = (g_prelude_2econcatList(v_t_2490, heff_get(heff_dup(v_ce_240), LBL_after)));
    return (g_heff_2eemitc_2eletWith_24s648(v_ce_240, v_dest_241, v_x_2486, v_a_2487, v_b_2488, v_t_2489, v_t_2491));
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_2493 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam8, 1, 1, (V[]){v_m_2493});
    }
    case TAG_Asg: {
      V v_x_24100 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24101 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam9, 1, 2, (V[]){v_m_24101, v_x_24100});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24110 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam10, 1, 1, (V[]){v_m_24110});
    }
    case TAG_Asg: {
      V v_x_24117 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24118 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam11, 1, 2, (V[]){v_m_24118, v_x_24117});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24127 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam12, 1, 1, (V[]){v_m_24127});
    }
    case TAG_Asg: {
      V v_x_24134 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24135 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam13, 1, 2, (V[]){v_m_24135, v_x_24134});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EMatch: {
    V v_s_24142 = heff_field(v_e_242, 0);
    V v_arms_24143 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24144 = heff_tr(g_heff_2eemitc_2escrutF_24s650(heff_dup(v_ce_240), heff_dup(v_s_24142)));
    return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam14, 1, 5, (V[]){v_m_24144, v_s_24142, v_ce_240, v_dest_241, v_arms_24143});
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24219 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam15, 1, 1, (V[]){v_m_24219});
    }
    case TAG_Asg: {
      V v_x_24226 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24227 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam16, 1, 2, (V[]){v_m_24227, v_x_24226});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24236 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam17, 1, 1, (V[]){v_m_24236});
    }
    case TAG_Asg: {
      V v_x_24243 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24244 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam18, 1, 2, (V[]){v_m_24244, v_x_24243});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_ECall: {
    V v_g_24251 = heff_dup(heff_field(v_e_242, 0));
    V v_as_24252 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      heff_drop_tag(v_e_242, 2);
      V v_x2_24253 = ({ V a_0 = heff_dup(v_g_24251); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24255;
      switch (heff_tag_of(v_x2_24253)) {
      case TAG_Nothing: {
        v_t_24255 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_24254 = heff_field(v_x2_24253, 0);
        heff_take_n(v_x2_24253, 1ULL, 1);
        v_t_24255 = v_x_24254;
        break;
      }
      default: heff_nomatch(v_x2_24253);
      }
      V v_m_24256 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24255; V a_3 = MK_INT(0LL); V a_4 = heff_dup(v_as_24252); V r_ = (g_heff_2eemitc_2elentOperands_24s646(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24255); r_; });
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam19, 1, 4, (V[]){v_m_24256, v_ce_240, v_g_24251, v_as_24252});
    }
    case TAG_Asg: {
      V v_x_24280 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      heff_drop(v_g_24251);
      heff_drop(v_as_24252);
      V v_m_24281 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam20, 1, 2, (V[]){v_m_24281, v_x_24280});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24289 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam21, 1, 1, (V[]){v_m_24289});
    }
    case TAG_Asg: {
      V v_x_24296 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24297 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam22, 1, 2, (V[]){v_m_24297, v_x_24296});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24305 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam23, 1, 1, (V[]){v_m_24305});
    }
    case TAG_Asg: {
      V v_x_24312 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24313 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam24, 1, 2, (V[]){v_m_24313, v_x_24312});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24321 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam25, 1, 1, (V[]){v_m_24321});
    }
    case TAG_Asg: {
      V v_x_24328 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24329 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam26, 1, 2, (V[]){v_m_24329, v_x_24328});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24336 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam27, 1, 1, (V[]){v_m_24336});
    }
    case TAG_Asg: {
      V v_x_24343 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24344 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam28, 1, 2, (V[]){v_m_24344, v_x_24343});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_dest_241)) {
    case TAG_Ret: {
      V v_m_24353 = heff_tr(g_heff_2eemitc_2ecompF_24s645(v_ce_240, NTAG(TAG_Nil), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam29, 1, 1, (V[]){v_m_24353});
    }
    case TAG_Asg: {
      V v_x_24360 = heff_field(v_dest_241, 0);
      heff_take_n(v_dest_241, 1ULL, 1);
      V v_m_24361 = heff_tr(g_heff_2eemitc_2ecompF_24s645(heff_dup(v_ce_240), heff_get(v_ce_240, LBL_after), v_e_242));
      return heff_clo(g_heff_2eemitc_2estmtsF_24s639_lam30, 1, 2, (V[]){v_m_24361, v_x_24360});
    }
    default: return heff_nomatch(v_dest_241);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2estmtsF_24s639(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2estmtsF_24s639_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str0), heff_strAppend(v_x_247, ((V)&g_heff_2eemitc_2estmtsF_24s639_str1)));
    V v_t_2410 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_strAppend(v_x_2411, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str2), heff_strAppend(v_x_2415, ((V)&g_heff_2eemitc_2estmtsF_24s639_str3))));
    V v_t_2418 = heff_tag_at(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam2(V self, V *args) {
  V v_s_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2422 = heff_tr(heff_apply(v_m_2420, 1, (V[]){v_s_2421}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_s_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str4), heff_strAppend(v_x_2423, ((V)&g_heff_2eemitc_2estmtsF_24s639_str5)));
    V v_t_2426 = heff_tag_at(v_ru_24x2_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2426, v_s_2424});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam3(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2430 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_strAppend(v_x_2427, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str6), heff_strAppend(v_x_2431, ((V)&g_heff_2eemitc_2estmtsF_24s639_str7))));
    V v_t_2434 = heff_tag_at(v_ru_24x2_2430_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2434, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam4(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2439 = heff_tr(heff_apply(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str8), heff_strAppend(v_x_2440, ((V)&g_heff_2eemitc_2estmtsF_24s639_str9)));
    V v_t_2443 = heff_tag_at(v_ru_24x2_2439_24MkPair, TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam5(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_apply(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    V v_t_2450 = heff_strAppend(v_x_2444, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str10), heff_strAppend(v_x_2448, ((V)&g_heff_2eemitc_2estmtsF_24s639_str11))));
    V v_t_2451 = heff_tag_at(v_ru_24x2_2447_24MkPair, TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam6(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_as_2453 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    V v_t_2459 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2453));
    V v_t_2460 = heff_intLt(MK_INT(0LL), v_t_2459);
    V v_t_2462;
    switch (heff_tag_of(v_t_2460)) {
    case TAG_True: {
      V v_t_2461 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2453));
      v_t_2462 = heff_intLe(v_t_2461, heff_get(v_ce_240, LBL_lam));
      break;
    }
    case TAG_False: {
      heff_drop(v_ce_240);
      v_t_2462 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2460);
    }
    V v_x_2477;
    switch (heff_tag_of(v_t_2462)) {
    case TAG_True: {
      heff_drop(v_as_2453);
      heff_drop_cell(v_ru_24x2_2456_24MkPair, 2);
      v_x_2477 = (g_heff_2eemitc_2einPlace(v_x_2457));
      break;
    }
    case TAG_False: {
      V v_x2_2465;
      switch (heff_tag_of(v_x_2457)) {
      case TAG_Nil: {
        v_x2_2465 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_dup(heff_field(v_x_2457, 0));
        v_x2_2465 = heff_tag(TAG_Just, 1, (V[]){v_x_2463});
        break;
      }
      default: heff_nomatch(v_x_2457);
      }
      V v_t_2467;
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_Nothing: {
        v_t_2467 = ((V)&g_heff_2eemitc_2estmtsF_24s639_str12);
        break;
      }
      case TAG_Just: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        heff_take_n(v_x2_2465, 1ULL, 1);
        v_t_2467 = v_x_2466;
        break;
      }
      default: heff_nomatch(v_x2_2465);
      }
      V v_t_2468 = ({ V a_0 = MK_INT(0LL); V a_1 = v_as_2453; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_as_2453); r_; });
      V v_vs_2469 = (g_prelude_2edrop(MK_INT(1LL), v_x_2457));
      V v_t_2475;
      switch (heff_tag_of(v_vs_2469)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2eemitc_2estmtsF_24s639_str13);
        break;
      }
      case TAG_Cons: {
        V v_t_2474;
        switch (heff_tag_of(v_vs_2469)) {
        case TAG_Nil: {
          v_t_2474 = ((V)&g_heff_2eemitc_2estmtsF_24s639_str14);
          break;
        }
        case TAG_Cons: {
          V v_x_2472 = heff_field(v_vs_2469, 0);
          V v_xs_2473 = heff_field(v_vs_2469, 1);
          heff_take_n(v_vs_2469, 3ULL, 2);
          v_t_2474 = ({ V a_0 = v_x_2472; V a_1 = v_xs_2473; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2473); r_; });
          break;
        }
        default: heff_nomatch(v_vs_2469);
        }
        v_t_2475 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str15), heff_strAppend(v_t_2474, ((V)&g_heff_2eemitc_2estmtsF_24s639_str16)));
        break;
      }
      default: heff_nomatch(v_vs_2469);
      }
      V v_t_2476 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str17), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str18), heff_strAppend(heff_intShow(v_t_2468), heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str19), heff_strAppend(v_t_2475, ((V)&g_heff_2eemitc_2estmtsF_24s639_str20)))))));
      v_x_2477 = heff_tag_at(v_ru_24x2_2456_24MkPair, TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2462);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam7(V self, V *args) {
  V v_s_2480 = args[0];
  V v_m_2479 = heff_env(self)[0];
  V v_x_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2481 = heff_tr(heff_apply(v_m_2479, 1, (V[]){v_s_2480}));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_s_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    V v_t_2484 = heff_strAppend(v_x_2478, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str21), heff_strAppend(v_x_2482, ((V)&g_heff_2eemitc_2estmtsF_24s639_str22))));
    V v_t_2485 = heff_tag_at(v_ru_24x2_2481_24MkPair, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2485, v_s_2483});
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam8(V self, V *args) {
  V v_s_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2495 = heff_tr(heff_apply(v_m_2493, 1, (V[]){v_s_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_s_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    V v_t_2498 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str23), heff_strAppend(v_x_2496, ((V)&g_heff_2eemitc_2estmtsF_24s639_str24)));
    V v_t_2499 = heff_tag_at(v_ru_24x2_2495_24MkPair, TAG_Cons, 2, (V[]){v_t_2498, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2499, v_s_2497});
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam9(V self, V *args) {
  V v_s_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  V v_x_24100 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24103 = heff_tr(heff_apply(v_m_24101, 1, (V[]){v_s_24102}));
  switch (heff_tag_of(v_x2_24103)) {
  case TAG_MkPair: {
    V v_x_24104 = heff_field(v_x2_24103, 0);
    V v_s_24105 = heff_field(v_x2_24103, 1);
    V v_ru_24x2_24103_24MkPair = heff_take_reuse_n(v_x2_24103, 3ULL, 2);
    V v_t_24106 = heff_strAppend(v_x_24100, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str25), heff_strAppend(v_x_24104, ((V)&g_heff_2eemitc_2estmtsF_24s639_str26))));
    V v_t_24107 = heff_tag_at(v_ru_24x2_24103_24MkPair, TAG_Cons, 2, (V[]){v_t_24106, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24107, v_s_24105});
  }
  default: return heff_nomatch(v_x2_24103);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam10(V self, V *args) {
  V v_s_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24112 = heff_tr(heff_apply(v_m_24110, 1, (V[]){v_s_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_s_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_t_24115 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str27), heff_strAppend(v_x_24113, ((V)&g_heff_2eemitc_2estmtsF_24s639_str28)));
    V v_t_24116 = heff_tag_at(v_ru_24x2_24112_24MkPair, TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24116, v_s_24114});
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam11(V self, V *args) {
  V v_s_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_x_24117 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24120 = heff_tr(heff_apply(v_m_24118, 1, (V[]){v_s_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_x2_24120, 0);
    V v_s_24122 = heff_field(v_x2_24120, 1);
    V v_ru_24x2_24120_24MkPair = heff_take_reuse_n(v_x2_24120, 3ULL, 2);
    V v_t_24123 = heff_strAppend(v_x_24117, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str29), heff_strAppend(v_x_24121, ((V)&g_heff_2eemitc_2estmtsF_24s639_str30))));
    V v_t_24124 = heff_tag_at(v_ru_24x2_24120_24MkPair, TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24124, v_s_24122});
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam12(V self, V *args) {
  V v_s_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24129 = heff_tr(heff_apply(v_m_24127, 1, (V[]){v_s_24128}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_s_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    V v_t_24132 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str31), heff_strAppend(v_x_24130, ((V)&g_heff_2eemitc_2estmtsF_24s639_str32)));
    V v_t_24133 = heff_tag_at(v_ru_24x2_24129_24MkPair, TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24133, v_s_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam13(V self, V *args) {
  V v_s_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  V v_x_24134 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24137 = heff_tr(heff_apply(v_m_24135, 1, (V[]){v_s_24136}));
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_MkPair: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    V v_s_24139 = heff_field(v_x2_24137, 1);
    V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
    V v_t_24140 = heff_strAppend(v_x_24134, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str33), heff_strAppend(v_x_24138, ((V)&g_heff_2eemitc_2estmtsF_24s639_str34))));
    V v_t_24141 = heff_tag_at(v_ru_24x2_24137_24MkPair, TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24141, v_s_24139});
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam14(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  V v_s_24142 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  V v_dest_241 = heff_env(self)[3];
  V v_arms_24143 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24146 = heff_tr(heff_apply(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    V v_t_24176;
    switch (heff_tag_of(v_s_24142)) {
    case TAG_EVar: {
      V v_x_24149 = heff_dup(heff_field(v_s_24142, 0));
      V v_t_24150 = ({ V a_0 = heff_dup(v_x_24149); V b_1 = heff_get(heff_dup(v_ce_240), LBL_owned); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_24150)) {
      case TAG_True: {
        v_t_24176 = heff_tag(TAG_Just, 1, (V[]){v_x_24149});
        break;
      }
      case TAG_False: {
        heff_drop(v_x_24149);
        v_t_24176 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_24150);
      }
      break;
    }
    case TAG_EGlobal: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      v_t_24176 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_24142);
    }
    V v_t_24203;
    switch (heff_tag_of(v_s_24142)) {
    case TAG_EVar: {
      V v_x_24177 = heff_field(v_s_24142, 0);
      heff_take_n(v_s_24142, 1ULL, 1);
      v_t_24203 = ({ V a_0 = v_x_24177; V b_1 = heff_get(heff_dup(v_ce_240), LBL_borrowed); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_s_24142, 0ULL, 1);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_s_24142, 0ULL, 3);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_s_24142, 0ULL, 1);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_s_24142, 0ULL, 1);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_s_24142, 0ULL, 1);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_s_24142, 0ULL, 1);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_s_24142, 0ULL, 1);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_s_24142, 0ULL, 2);
      v_t_24203 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_24142);
    }
    V v_t_24204 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2earmLines_24s651_clo), 5, (V[]){v_ce_240, heff_dup(v_dest_241), heff_dup(v_x_24147), v_t_24176, v_t_24203}));
    V v_m_24205 = (g_heff_2eemitc_2etraverseC(v_t_24204, v_arms_24143));
    V v_x2_24206 = heff_tr(heff_apply(v_m_24205, 1, (V[]){v_s_24148}));
    switch (heff_tag_of(v_x2_24206)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_field(v_x2_24206, 0);
      V v_s_24208 = heff_field(v_x2_24206, 1);
      V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
      V v_t_24209 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str35), heff_strAppend(heff_dup(v_x_24147), ((V)&g_heff_2eemitc_2estmtsF_24s639_str36)));
      V v_t_24210 = heff_tag_at(v_ru_24x2_24146_24MkPair, TAG_Cons, 2, (V[]){v_t_24209, NTAG(TAG_Nil)});
      V v_t_24211 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_x_24207));
      V v_t_24212 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24211; V r_ = (g_prelude_2efoldl_24s635(a_0, a_1)); heff_drop(v_t_24211); r_; });
      V v_t_24214;
      switch (heff_tag_of(v_dest_241)) {
      case TAG_Ret: {
        v_t_24214 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str37), heff_strAppend(v_x_24147, ((V)&g_heff_2eemitc_2estmtsF_24s639_str38)));
        break;
      }
      case TAG_Asg: {
        heff_take_n(v_dest_241, 0ULL, 1);
        v_t_24214 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str39), heff_strAppend(v_x_24147, ((V)&g_heff_2eemitc_2estmtsF_24s639_str40)));
        break;
      }
      default: heff_nomatch(v_dest_241);
      }
      V v_t_24215 = heff_tag_at(v_ru_24x2_24206_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2estmtsF_24s639_str41), NTAG(TAG_Nil)});
      V v_t_24216 = (g_prelude_2econcatList(v_t_24212, heff_tag(TAG_Cons, 2, (V[]){v_t_24214, v_t_24215})));
      V v_x_24217 = (g_prelude_2econcatList(v_t_24210, v_t_24216));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_24217, v_s_24208});
    }
    default: return heff_nomatch(v_x2_24206);
    }
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam15(V self, V *args) {
  V v_s_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24221 = heff_tr(heff_apply(v_m_24219, 1, (V[]){v_s_24220}));
  switch (heff_tag_of(v_x2_24221)) {
  case TAG_MkPair: {
    V v_x_24222 = heff_field(v_x2_24221, 0);
    V v_s_24223 = heff_field(v_x2_24221, 1);
    V v_ru_24x2_24221_24MkPair = heff_take_reuse_n(v_x2_24221, 3ULL, 2);
    V v_t_24224 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str42), heff_strAppend(v_x_24222, ((V)&g_heff_2eemitc_2estmtsF_24s639_str43)));
    V v_t_24225 = heff_tag_at(v_ru_24x2_24221_24MkPair, TAG_Cons, 2, (V[]){v_t_24224, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24225, v_s_24223});
  }
  default: return heff_nomatch(v_x2_24221);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam16(V self, V *args) {
  V v_s_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  V v_x_24226 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24229 = heff_tr(heff_apply(v_m_24227, 1, (V[]){v_s_24228}));
  switch (heff_tag_of(v_x2_24229)) {
  case TAG_MkPair: {
    V v_x_24230 = heff_field(v_x2_24229, 0);
    V v_s_24231 = heff_field(v_x2_24229, 1);
    V v_ru_24x2_24229_24MkPair = heff_take_reuse_n(v_x2_24229, 3ULL, 2);
    V v_t_24232 = heff_strAppend(v_x_24226, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str44), heff_strAppend(v_x_24230, ((V)&g_heff_2eemitc_2estmtsF_24s639_str45))));
    V v_t_24233 = heff_tag_at(v_ru_24x2_24229_24MkPair, TAG_Cons, 2, (V[]){v_t_24232, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24233, v_s_24231});
  }
  default: return heff_nomatch(v_x2_24229);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam17(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24238 = heff_tr(heff_apply(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    V v_ru_24x2_24238_24MkPair = heff_take_reuse_n(v_x2_24238, 3ULL, 2);
    V v_t_24241 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str46), heff_strAppend(v_x_24239, ((V)&g_heff_2eemitc_2estmtsF_24s639_str47)));
    V v_t_24242 = heff_tag_at(v_ru_24x2_24238_24MkPair, TAG_Cons, 2, (V[]){v_t_24241, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24242, v_s_24240});
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam18(V self, V *args) {
  V v_s_24245 = args[0];
  V v_m_24244 = heff_env(self)[0];
  V v_x_24243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24246 = heff_tr(heff_apply(v_m_24244, 1, (V[]){v_s_24245}));
  switch (heff_tag_of(v_x2_24246)) {
  case TAG_MkPair: {
    V v_x_24247 = heff_field(v_x2_24246, 0);
    V v_s_24248 = heff_field(v_x2_24246, 1);
    V v_ru_24x2_24246_24MkPair = heff_take_reuse_n(v_x2_24246, 3ULL, 2);
    V v_t_24249 = heff_strAppend(v_x_24243, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str48), heff_strAppend(v_x_24247, ((V)&g_heff_2eemitc_2estmtsF_24s639_str49))));
    V v_t_24250 = heff_tag_at(v_ru_24x2_24246_24MkPair, TAG_Cons, 2, (V[]){v_t_24249, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24250, v_s_24248});
  }
  default: return heff_nomatch(v_x2_24246);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam19(V self, V *args) {
  V v_s_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_g_24251 = heff_env(self)[2];
  V v_as_24252 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24258 = heff_tr(heff_apply(v_m_24256, 1, (V[]){v_s_24257}));
  switch (heff_tag_of(v_x2_24258)) {
  case TAG_MkPair: {
    V v_x_24259 = heff_field(v_x2_24258, 0);
    V v_s_24260 = heff_field(v_x2_24258, 1);
    V v_ru_24x2_24258_24MkPair = heff_take_reuse_n(v_x2_24258, 3ULL, 2);
    V v_t_24261 = heff_get(heff_dup(v_ce_240), LBL_self);
    V v_t_24267;
    switch (heff_tag_of(v_t_24261)) {
    case TAG_Nothing: {
      v_t_24267 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_s_24262 = heff_field(v_t_24261, 0);
      heff_take_n(v_t_24261, 1ULL, 1);
      V v_t_24263 = heff_strEq(heff_get(heff_dup(v_s_24262), LBL_key), heff_dup(v_g_24251));
      switch (heff_tag_of(v_t_24263)) {
      case TAG_True: {
        V v_t_24264 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_s_24262, LBL_params); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_24265 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_24252));
        V v_t_24266 = heff_intEq(v_t_24264, v_t_24265);
        switch (heff_tag_of(v_t_24266)) {
        case TAG_True: {
          v_t_24267 = (g_prelude_2eall_24s623(v_x_24259));
          break;
        }
        case TAG_False: {
          v_t_24267 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_24266);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_s_24262);
        v_t_24267 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24263);
      }
      break;
    }
    default: heff_nomatch(v_t_24261);
    }
    V v_x_24279;
    switch (heff_tag_of(v_t_24267)) {
    case TAG_True: {
      heff_drop(v_g_24251);
      heff_drop(v_as_24252);
      heff_drop_cell(v_ru_24x2_24258_24MkPair, 2);
      V v_t_24268 = (g_prelude_2emap_24s624(v_x_24259));
      v_x_24279 = (g_heff_2eemitc_2eagain(v_ce_240, v_t_24268));
      break;
    }
    case TAG_False: {
      V v_t_24269 = ({ V a_0 = v_ce_240; V a_1 = heff_dup(v_g_24251); V a_2 = v_as_24252; V r_ = (g_heff_2eemitc_2eagrees(a_0, a_1, a_2)); heff_drop(v_as_24252); r_; });
      V v_t_24270;
      switch (heff_tag_of(v_t_24269)) {
      case TAG_True: {
        v_t_24270 = (g_prelude_2eall_24s623(v_x_24259));
        break;
      }
      case TAG_False: {
        v_t_24270 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24269);
      }
      switch (heff_tag_of(v_t_24270)) {
      case TAG_True: {
        V v_t_24271 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str50), (g_heff_2eemitc_2emangleW(v_g_24251, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2estmtsF_24s639_str51))));
        V v_x2_24272 = (g_prelude_2emap_24s624(v_x_24259));
        V v_t_24275;
        switch (heff_tag_of(v_x2_24272)) {
        case TAG_Nil: {
          v_t_24275 = ((V)&g_heff_2eemitc_2estmtsF_24s639_str52);
          break;
        }
        case TAG_Cons: {
          V v_x_24273 = heff_field(v_x2_24272, 0);
          V v_xs_24274 = heff_field(v_x2_24272, 1);
          heff_take_n(v_x2_24272, 3ULL, 2);
          v_t_24275 = ({ V a_0 = v_x_24273; V a_1 = v_xs_24274; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24274); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24272);
        }
        V v_t_24276 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str53), heff_strAppend(v_t_24271, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str54), heff_strAppend(v_t_24275, ((V)&g_heff_2eemitc_2estmtsF_24s639_str55)))));
        v_x_24279 = heff_tag_at(v_ru_24x2_24258_24MkPair, TAG_Cons, 2, (V[]){v_t_24276, NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        V v_t_24277 = ({ V a_0 = v_g_24251; V b_1 = NTAG(TAG_False); V a_2 = v_x_24259; V r_ = (g_heff_2eemitc_2ecallText(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        V v_t_24278 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str56), heff_strAppend(v_t_24277, ((V)&g_heff_2eemitc_2estmtsF_24s639_str57)));
        v_x_24279 = heff_tag_at(v_ru_24x2_24258_24MkPair, TAG_Cons, 2, (V[]){v_t_24278, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_24270);
      }
      break;
    }
    default: heff_nomatch(v_t_24267);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24279, v_s_24260});
  }
  default: return heff_nomatch(v_x2_24258);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam20(V self, V *args) {
  V v_s_24282 = args[0];
  V v_m_24281 = heff_env(self)[0];
  V v_x_24280 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24283 = heff_tr(heff_apply(v_m_24281, 1, (V[]){v_s_24282}));
  switch (heff_tag_of(v_x2_24283)) {
  case TAG_MkPair: {
    V v_x_24284 = heff_field(v_x2_24283, 0);
    V v_s_24285 = heff_field(v_x2_24283, 1);
    V v_ru_24x2_24283_24MkPair = heff_take_reuse_n(v_x2_24283, 3ULL, 2);
    V v_t_24286 = heff_strAppend(v_x_24280, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str58), heff_strAppend(v_x_24284, ((V)&g_heff_2eemitc_2estmtsF_24s639_str59))));
    V v_t_24287 = heff_tag_at(v_ru_24x2_24283_24MkPair, TAG_Cons, 2, (V[]){v_t_24286, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24287, v_s_24285});
  }
  default: return heff_nomatch(v_x2_24283);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam21(V self, V *args) {
  V v_s_24290 = args[0];
  V v_m_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24291 = heff_tr(heff_apply(v_m_24289, 1, (V[]){v_s_24290}));
  switch (heff_tag_of(v_x2_24291)) {
  case TAG_MkPair: {
    V v_x_24292 = heff_field(v_x2_24291, 0);
    V v_s_24293 = heff_field(v_x2_24291, 1);
    V v_ru_24x2_24291_24MkPair = heff_take_reuse_n(v_x2_24291, 3ULL, 2);
    V v_t_24294 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str60), heff_strAppend(v_x_24292, ((V)&g_heff_2eemitc_2estmtsF_24s639_str61)));
    V v_t_24295 = heff_tag_at(v_ru_24x2_24291_24MkPair, TAG_Cons, 2, (V[]){v_t_24294, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24295, v_s_24293});
  }
  default: return heff_nomatch(v_x2_24291);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam22(V self, V *args) {
  V v_s_24298 = args[0];
  V v_m_24297 = heff_env(self)[0];
  V v_x_24296 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24299 = heff_tr(heff_apply(v_m_24297, 1, (V[]){v_s_24298}));
  switch (heff_tag_of(v_x2_24299)) {
  case TAG_MkPair: {
    V v_x_24300 = heff_field(v_x2_24299, 0);
    V v_s_24301 = heff_field(v_x2_24299, 1);
    V v_ru_24x2_24299_24MkPair = heff_take_reuse_n(v_x2_24299, 3ULL, 2);
    V v_t_24302 = heff_strAppend(v_x_24296, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str62), heff_strAppend(v_x_24300, ((V)&g_heff_2eemitc_2estmtsF_24s639_str63))));
    V v_t_24303 = heff_tag_at(v_ru_24x2_24299_24MkPair, TAG_Cons, 2, (V[]){v_t_24302, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24303, v_s_24301});
  }
  default: return heff_nomatch(v_x2_24299);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam23(V self, V *args) {
  V v_s_24306 = args[0];
  V v_m_24305 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24307 = heff_tr(heff_apply(v_m_24305, 1, (V[]){v_s_24306}));
  switch (heff_tag_of(v_x2_24307)) {
  case TAG_MkPair: {
    V v_x_24308 = heff_field(v_x2_24307, 0);
    V v_s_24309 = heff_field(v_x2_24307, 1);
    V v_ru_24x2_24307_24MkPair = heff_take_reuse_n(v_x2_24307, 3ULL, 2);
    V v_t_24310 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str64), heff_strAppend(v_x_24308, ((V)&g_heff_2eemitc_2estmtsF_24s639_str65)));
    V v_t_24311 = heff_tag_at(v_ru_24x2_24307_24MkPair, TAG_Cons, 2, (V[]){v_t_24310, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24311, v_s_24309});
  }
  default: return heff_nomatch(v_x2_24307);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam24(V self, V *args) {
  V v_s_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  V v_x_24312 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24315 = heff_tr(heff_apply(v_m_24313, 1, (V[]){v_s_24314}));
  switch (heff_tag_of(v_x2_24315)) {
  case TAG_MkPair: {
    V v_x_24316 = heff_field(v_x2_24315, 0);
    V v_s_24317 = heff_field(v_x2_24315, 1);
    V v_ru_24x2_24315_24MkPair = heff_take_reuse_n(v_x2_24315, 3ULL, 2);
    V v_t_24318 = heff_strAppend(v_x_24312, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str66), heff_strAppend(v_x_24316, ((V)&g_heff_2eemitc_2estmtsF_24s639_str67))));
    V v_t_24319 = heff_tag_at(v_ru_24x2_24315_24MkPair, TAG_Cons, 2, (V[]){v_t_24318, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24319, v_s_24317});
  }
  default: return heff_nomatch(v_x2_24315);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam25(V self, V *args) {
  V v_s_24322 = args[0];
  V v_m_24321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24323 = heff_tr(heff_apply(v_m_24321, 1, (V[]){v_s_24322}));
  switch (heff_tag_of(v_x2_24323)) {
  case TAG_MkPair: {
    V v_x_24324 = heff_field(v_x2_24323, 0);
    V v_s_24325 = heff_field(v_x2_24323, 1);
    V v_ru_24x2_24323_24MkPair = heff_take_reuse_n(v_x2_24323, 3ULL, 2);
    V v_t_24326 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str68), heff_strAppend(v_x_24324, ((V)&g_heff_2eemitc_2estmtsF_24s639_str69)));
    V v_t_24327 = heff_tag_at(v_ru_24x2_24323_24MkPair, TAG_Cons, 2, (V[]){v_t_24326, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24327, v_s_24325});
  }
  default: return heff_nomatch(v_x2_24323);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam26(V self, V *args) {
  V v_s_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_x_24328 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24331 = heff_tr(heff_apply(v_m_24329, 1, (V[]){v_s_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_s_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_t_24334 = heff_strAppend(v_x_24328, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str70), heff_strAppend(v_x_24332, ((V)&g_heff_2eemitc_2estmtsF_24s639_str71))));
    V v_t_24335 = heff_tag_at(v_ru_24x2_24331_24MkPair, TAG_Cons, 2, (V[]){v_t_24334, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24335, v_s_24333});
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam27(V self, V *args) {
  V v_s_24337 = args[0];
  V v_m_24336 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24338 = heff_tr(heff_apply(v_m_24336, 1, (V[]){v_s_24337}));
  switch (heff_tag_of(v_x2_24338)) {
  case TAG_MkPair: {
    V v_x_24339 = heff_field(v_x2_24338, 0);
    V v_s_24340 = heff_field(v_x2_24338, 1);
    V v_ru_24x2_24338_24MkPair = heff_take_reuse_n(v_x2_24338, 3ULL, 2);
    V v_t_24341 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str72), heff_strAppend(v_x_24339, ((V)&g_heff_2eemitc_2estmtsF_24s639_str73)));
    V v_t_24342 = heff_tag_at(v_ru_24x2_24338_24MkPair, TAG_Cons, 2, (V[]){v_t_24341, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24342, v_s_24340});
  }
  default: return heff_nomatch(v_x2_24338);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam28(V self, V *args) {
  V v_s_24345 = args[0];
  V v_m_24344 = heff_env(self)[0];
  V v_x_24343 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24346 = heff_tr(heff_apply(v_m_24344, 1, (V[]){v_s_24345}));
  switch (heff_tag_of(v_x2_24346)) {
  case TAG_MkPair: {
    V v_x_24347 = heff_field(v_x2_24346, 0);
    V v_s_24348 = heff_field(v_x2_24346, 1);
    V v_ru_24x2_24346_24MkPair = heff_take_reuse_n(v_x2_24346, 3ULL, 2);
    V v_t_24349 = heff_strAppend(v_x_24343, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str74), heff_strAppend(v_x_24347, ((V)&g_heff_2eemitc_2estmtsF_24s639_str75))));
    V v_t_24350 = heff_tag_at(v_ru_24x2_24346_24MkPair, TAG_Cons, 2, (V[]){v_t_24349, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24350, v_s_24348});
  }
  default: return heff_nomatch(v_x2_24346);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam29(V self, V *args) {
  V v_s_24354 = args[0];
  V v_m_24353 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24355 = heff_tr(heff_apply(v_m_24353, 1, (V[]){v_s_24354}));
  switch (heff_tag_of(v_x2_24355)) {
  case TAG_MkPair: {
    V v_x_24356 = heff_field(v_x2_24355, 0);
    V v_s_24357 = heff_field(v_x2_24355, 1);
    V v_ru_24x2_24355_24MkPair = heff_take_reuse_n(v_x2_24355, 3ULL, 2);
    V v_t_24358 = heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str76), heff_strAppend(v_x_24356, ((V)&g_heff_2eemitc_2estmtsF_24s639_str77)));
    V v_t_24359 = heff_tag_at(v_ru_24x2_24355_24MkPair, TAG_Cons, 2, (V[]){v_t_24358, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24359, v_s_24357});
  }
  default: return heff_nomatch(v_x2_24355);
  }
}
V g_heff_2eemitc_2estmtsF_24s639_lam30(V self, V *args) {
  V v_s_24362 = args[0];
  V v_m_24361 = heff_env(self)[0];
  V v_x_24360 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24363 = heff_tr(heff_apply(v_m_24361, 1, (V[]){v_s_24362}));
  switch (heff_tag_of(v_x2_24363)) {
  case TAG_MkPair: {
    V v_x_24364 = heff_field(v_x2_24363, 0);
    V v_s_24365 = heff_field(v_x2_24363, 1);
    V v_ru_24x2_24363_24MkPair = heff_take_reuse_n(v_x2_24363, 3ULL, 2);
    V v_t_24366 = heff_strAppend(v_x_24360, heff_strAppend(((V)&g_heff_2eemitc_2estmtsF_24s639_str78), heff_strAppend(v_x_24364, ((V)&g_heff_2eemitc_2estmtsF_24s639_str79))));
    V v_t_24367 = heff_tag_at(v_ru_24x2_24363_24MkPair, TAG_Cons, 2, (V[]){v_t_24366, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_24367, v_s_24365});
  }
  default: return heff_nomatch(v_x2_24363);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2efunDef_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {118, 111, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str9 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eemitc_2efunDef_str10 = {{0x80000000u, K_STR, 0}, 21, 21, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2efunDef_str15 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2eemitc_2efunDef_str16 = {{0x80000000u, K_STR, 0}, 33, 33, {95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2efunDef_str17 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 101, 110, 116, 114, 121, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2efunDef_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 48, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2efunDef_str21 = {{0x80000000u, K_STR, 0}, 4, 4, {118, 111, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str23 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2efunDef_str25 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2efunDef_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 111, 112, 58, 32, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2efunDef_str28 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2efunDef_str30 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2efunDef_str31 = {{0x80000000u, K_STR, 0}, 22, 22, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2efunDef_str33 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 32, 40, 118, 111, 105, 100, 41, 115, 101, 108, 102, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2efunDef_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2eemitc_2efunDef_lam0(V self, V *args);
V g_heff_2eemitc_2efunDef_lam1(V self, V *args);
V g_heff_2eemitc_2efunDef_lam3(V self, V *args);
V g_heff_2eemitc_2efunDef_lam2(V self, V *args);
Clo g_heff_2eemitc_2efunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2efunDef_entry, 4, 0};

V g_heff_2eemitc_2efunDef(V v_ce_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_owned_247 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_246; V a_2 = heff_dup(v_xs_242); V r_ = (g_heff_2eemitc_2eparamsAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_246); r_; });
  V v_wanted_248 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_b_243)));
  V v_owned_2410 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2efunDef_lam0, 1, 1, (V[]){v_wanted_248}), v_owned_247));
  V v_x2_2411 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_bi_2413;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    v_bi_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    v_bi_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2414 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_242));
  V v_t_2415 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
  V v_t_2416 = (g_prelude_2ezipWith_24s634(heff_dup(v_xs_242), v_t_2415));
  V v_t_2421 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2efunDef_lam1, 1, 1, (V[]){v_bi_2413}), v_t_2416));
  V v_bs_2422 = (g_prelude_2emap_24s618(v_t_2421));
  V v_t_2423 = heff_rec(2, shape_152_232, (V[]){heff_get(heff_dup(v_d_241), LBL_key), heff_dup(v_xs_242)});
  V v_ce_2424 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), heff_tag(TAG_Just, 1, (V[]){v_t_2423}), MK_INT(0LL), heff_get(heff_dup(v_ce_240), LBL_owned), heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(heff_dup(v_ce_240), LBL_known)});
  V v_ce_2425 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_2424), LBL_tags), heff_get(heff_dup(v_ce_2424), LBL_lbls), heff_get(heff_dup(v_ce_2424), LBL_funs), heff_get(heff_dup(v_ce_2424), LBL_bounce), heff_get(heff_dup(v_ce_2424), LBL_self), heff_get(heff_dup(v_ce_2424), LBL_lam), heff_get(heff_dup(v_ce_2424), LBL_owned), heff_get(heff_dup(v_ce_2424), LBL_after), v_bs_2422, heff_get(heff_dup(v_ce_2424), LBL_bor), heff_get(v_ce_2424, LBL_known)});
  V v_ce_2426 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_2425), LBL_tags), heff_get(heff_dup(v_ce_2425), LBL_lbls), heff_get(heff_dup(v_ce_2425), LBL_funs), heff_get(heff_dup(v_ce_2425), LBL_bounce), heff_get(heff_dup(v_ce_2425), LBL_self), heff_get(heff_dup(v_ce_2425), LBL_lam), v_owned_2410, NTAG(TAG_Nil), heff_get(heff_dup(v_ce_2425), LBL_borrowed), heff_get(heff_dup(v_ce_2425), LBL_bor), heff_get(v_ce_2425, LBL_known)});
  V v_m_2427 = (g_heff_2eemitc_2estmtsF_24s639(v_ce_2426, NTAG(TAG_Ret), heff_dup(v_b_243)));
  return heff_clo(g_heff_2eemitc_2efunDef_lam2, 1, 5, (V[]){v_m_2427, v_d_241, v_xs_242, v_ce_240, v_b_243});
}
V g_heff_2eemitc_2efunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2efunDef(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemitc_2efunDef_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_248); r_; });
}
V g_heff_2eemitc_2efunDef_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_bi_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  return ({ V a_0 = v_t_2420; V a_1 = v_bi_2413; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_2413); r_; });
}
V g_heff_2eemitc_2efunDef_lam3(V self, V *args) {
  V v_v_2463 = args[0];
  V v_wanted_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = ({ V a_0 = v_v_2463; V a_1 = v_wanted_2462; V r_ = (g_heff_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2462); r_; });
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2eemitc_2efunDef_lam2(V self, V *args) {
  V v_s_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  V v_ce_240 = heff_env(self)[3];
  V v_b_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2429 = heff_tr(heff_apply(v_m_2427, 1, (V[]){v_s_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_s_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str1))));
    V v_t_2438;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2eemitc_2efunDef_str2);
      break;
    }
    case TAG_Cons: {
      V v_x2_2435 = (g_prelude_2emap_24s636(heff_dup(v_xs_242)));
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2eemitc_2efunDef_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = v_x_2436; V a_1 = v_xs_2437; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    V v_t_2439 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str4), heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str5), heff_strAppend(v_t_2438, ((V)&g_heff_2eemitc_2efunDef_str6)))));
    V v_t_2440 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str7), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str8))));
    V v_t_2441 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str9), heff_strAppend(v_t_2440, ((V)&g_heff_2eemitc_2efunDef_str10)));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str11), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str12))));
    V v_t_2443 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str13), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str14))));
    V v_t_2444 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_242));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str15), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str16), heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str17), heff_strAppend(heff_intShow(v_t_2444), ((V)&g_heff_2eemitc_2efunDef_str18)))))));
    V v_t_2446 = heff_tag_at(v_ru_24x2_2429_24MkPair, TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){v_t_2439, heff_tag(TAG_Cons, 2, (V[]){v_t_2441, v_t_2446})});
    V v_t_2448 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str19), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str20))));
    V v_t_2454;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2eemitc_2efunDef_str21);
      break;
    }
    case TAG_Cons: {
      V v_x2_2451 = (g_prelude_2emap_24s636(heff_dup(v_xs_242)));
      switch (heff_tag_of(v_x2_2451)) {
      case TAG_Nil: {
        v_t_2454 = ((V)&g_heff_2eemitc_2efunDef_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2452 = heff_field(v_x2_2451, 0);
        V v_xs_2453 = heff_field(v_x2_2451, 1);
        heff_take_n(v_x2_2451, 3ULL, 2);
        v_t_2454 = ({ V a_0 = v_x_2452; V a_1 = v_xs_2453; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2453); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2451);
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    V v_t_2455 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str23), heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str24), heff_strAppend(v_t_2454, ((V)&g_heff_2eemitc_2efunDef_str25)))));
    V v_t_2456 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str26), NTAG(TAG_Nil)});
    V v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str27), heff_tag(TAG_Cons, 2, (V[]){v_t_2455, v_t_2456})});
    V v_x2_2458 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(heff_dup(v_ce_240), LBL_bor); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2460;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nothing: {
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      heff_take_n(v_x2_2458, 1ULL, 1);
      v_t_2460 = v_x_2459;
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    V v_owned_2461 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2460; V a_2 = heff_dup(v_xs_242); V r_ = (g_heff_2eemitc_2eparamsAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2460); r_; });
    V v_wanted_2462 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), v_b_243));
    V v_t_2465 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2efunDef_lam3, 1, 1, (V[]){v_wanted_2462}), v_owned_2461));
    V v_t_2466 = (g_prelude_2emap_24s622(v_t_2465));
    V v_t_2467 = (g_prelude_2emap_24s177(v_t_2466));
    V v_t_2468 = (g_prelude_2emap_24s177(v_x_2430));
    V v_t_2469 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str28), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2efunDef_str29))));
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eemitc_2efunDef_str30), heff_strAppend(v_t_2469, ((V)&g_heff_2eemitc_2efunDef_str31)));
    V v_x2_2471 = ({ V a_0 = heff_get(heff_dup(v_d_241), LBL_key); V b_1 = heff_get(v_ce_240, LBL_bor); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2473;
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_Nothing: {
      v_t_2473 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      heff_take_n(v_x2_2471, 1ULL, 1);
      v_t_2473 = v_x_2472;
      break;
    }
    default: heff_nomatch(v_x2_2471);
    }
    V v_t_2474 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_242; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_242); r_; });
    V v_t_2475 = (g_heff_2eemitc_2eentryCall(heff_get(v_d_241, LBL_key), v_t_2473, v_t_2474));
    V v_t_2476 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str32), NTAG(TAG_Nil)});
    V v_t_2477 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str33), heff_tag(TAG_Cons, 2, (V[]){v_t_2475, v_t_2476})});
    V v_t_2478 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2efunDef_str34), heff_tag(TAG_Cons, 2, (V[]){v_t_2470, v_t_2477})});
    V v_t_2479 = (g_prelude_2econcatList(v_t_2468, v_t_2478));
    V v_t_2480 = (g_prelude_2econcatList(v_t_2467, v_t_2479));
    V v_t_2481 = (g_prelude_2econcatList(v_t_2457, v_t_2480));
    V v_x_2482 = heff_rec(2, shape_261_47, (V[]){v_t_2447, v_t_2481});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2482, v_s_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2evalDef_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalDef_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2evalDef_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 97, 116, 105, 99, 32, 105, 110, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2evalDef_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 115, 116, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str14 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemitc_2evalDef_str15 = {{0x80000000u, K_STR, 0}, 13, 13, {95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 97, 116, 105, 99, 32, 86, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2evalDef_str19 = {{0x80000000u, K_STR, 0}, 12, 12, {95, 103, 101, 116, 40, 118, 111, 105, 100, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalDef_str24 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2evalDef_str25 = {{0x80000000u, K_STR, 0}, 17, 17, {95, 115, 116, 32, 61, 61, 32, 50, 41, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalDef_str26 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str27 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2evalDef_str29 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eemitc_2evalDef_str30 = {{0x80000000u, K_STR, 0}, 41, 41, {95, 115, 116, 32, 61, 61, 32, 49, 41, 32, 104, 101, 102, 102, 95, 102, 97, 105, 108, 40, 34, 100, 101, 102, 105, 110, 101, 100, 32, 98, 121, 32, 105, 116, 115, 101, 108, 102, 34, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str33 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2evalDef_str34 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 115, 116, 32, 61, 32, 49, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str35 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str36 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str37 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str38 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str39 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemitc_2evalDef_str40 = {{0x80000000u, K_STR, 0}, 15, 15, {95, 118, 97, 108, 32, 61, 32, 104, 101, 102, 102, 95, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str41 = {{0x80000000u, K_STR, 0}, 9, 9, {95, 105, 110, 105, 116, 40, 41, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str42 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str44 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2evalDef_str45 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 115, 116, 32, 61, 32, 50, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2evalDef_str46 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str47 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2evalDef_str48 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2evalDef_str49 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2evalDef_str52 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemitc_2evalDef_lam0(V self, V *args);
Clo g_heff_2eemitc_2evalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2evalDef_entry, 2, 0};

V g_heff_2eemitc_2evalDef(V v_ce_240, V v_d_241) {
top: ;
  V v_ce_242 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_240), LBL_tags), heff_get(heff_dup(v_ce_240), LBL_lbls), heff_get(heff_dup(v_ce_240), LBL_funs), heff_get(heff_dup(v_ce_240), LBL_bounce), NTAG(TAG_Nothing), MK_INT(0LL), heff_get(heff_dup(v_ce_240), LBL_owned), heff_get(heff_dup(v_ce_240), LBL_after), heff_get(heff_dup(v_ce_240), LBL_borrowed), heff_get(heff_dup(v_ce_240), LBL_bor), heff_get(v_ce_240, LBL_known)});
  V v_ce_243 = heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){heff_get(heff_dup(v_ce_242), LBL_tags), heff_get(heff_dup(v_ce_242), LBL_lbls), heff_get(heff_dup(v_ce_242), LBL_funs), heff_get(heff_dup(v_ce_242), LBL_bounce), heff_get(heff_dup(v_ce_242), LBL_self), heff_get(heff_dup(v_ce_242), LBL_lam), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_get(heff_dup(v_ce_242), LBL_borrowed), heff_get(heff_dup(v_ce_242), LBL_bor), heff_get(v_ce_242, LBL_known)});
  V v_m_244 = (g_heff_2eemitc_2estmtsF_24s639(v_ce_243, NTAG(TAG_Ret), heff_get(heff_dup(v_d_241), LBL_body)));
  return heff_clo(g_heff_2eemitc_2evalDef_lam0, 1, 2, (V[]){v_m_244, v_d_241});
}
V g_heff_2eemitc_2evalDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2evalDef(a[0], a[1]);
}
V g_heff_2eemitc_2evalDef_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str1))));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str2), heff_strAppend(v_t_249, ((V)&g_heff_2eemitc_2evalDef_str3)));
    V v_t_2411 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str4), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str5))));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2eemitc_2evalDef_str7)));
    V v_t_2414 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str8), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str9))));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str10), heff_strAppend(v_t_2414, ((V)&g_heff_2eemitc_2evalDef_str11)));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str12), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str13))));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str14), heff_strAppend(v_t_2416, ((V)&g_heff_2eemitc_2evalDef_str15)));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_t_2418})});
    V v_t_2420 = (g_prelude_2emap_24s177(v_x_247));
    V v_t_2421 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str16), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str17))));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str18), heff_strAppend(v_t_2421, ((V)&g_heff_2eemitc_2evalDef_str19)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str20), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str21))));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str22), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str23))));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str24), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str25), heff_strAppend(v_t_2424, ((V)&g_heff_2eemitc_2evalDef_str26)))));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str27), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str28))));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str29), heff_strAppend(v_t_2426, ((V)&g_heff_2eemitc_2evalDef_str30)));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str31), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str32))));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str33), heff_strAppend(v_t_2428, ((V)&g_heff_2eemitc_2evalDef_str34)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str35), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str36))));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str37), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str38))));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str39), heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str40), heff_strAppend(v_t_2431, ((V)&g_heff_2eemitc_2evalDef_str41)))));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str42), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str43))));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str44), heff_strAppend(v_t_2433, ((V)&g_heff_2eemitc_2evalDef_str45)));
    V v_t_2435 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str46), (g_heff_2eemitc_2emangleW(heff_get(v_d_241, LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2evalDef_str47))));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2eemitc_2evalDef_str48), heff_strAppend(v_t_2435, ((V)&g_heff_2eemitc_2evalDef_str49)));
    V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2evalDef_str50), NTAG(TAG_Nil)});
    V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_t_2434, heff_tag(TAG_Cons, 2, (V[]){v_t_2436, v_t_2437})});
    V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, heff_tag(TAG_Cons, 2, (V[]){v_t_2432, v_t_2438})});
    V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, heff_tag(TAG_Cons, 2, (V[]){v_t_2427, v_t_2439})});
    V v_t_2441 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2evalDef_str51), heff_tag(TAG_Cons, 2, (V[]){v_t_2422, v_t_2440})});
    V v_t_2442 = (g_prelude_2econcatList(v_t_2420, v_t_2441));
    V v_t_2443 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2evalDef_str52), v_t_2419}), v_t_2442));
    V v_x_2444 = heff_rec(2, shape_261_47, (V[]){v_t_2411, v_t_2443});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2444, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
Clo g_heff_2eemitc_2edefC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edefC_entry, 2, 0};

V g_heff_2eemitc_2edefC(V v_ce_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    return (g_heff_2eemitc_2efunDef(v_ce_240, v_d_241, v_xs_245, v_b_246));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    HEFF_LAST return g_heff_2eemitc_2evalDef(v_ce_240, v_d_241);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2edefC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edefC(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eplusDone_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[120]; } g_heff_2eemitc_2eplusDone_str1 = {{0x80000000u, K_STR, 0}, 120, 120, {40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 105, 110, 116, 32, 108, 32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 111, 102, 40, 112, 41, 32, 61, 61, 32, 84, 65, 71, 95, 73, 110, 76, 59, 32, 86, 32, 113, 32, 61, 32, 104, 101, 102, 102, 95, 100, 117, 112, 40, 104, 101, 102, 102, 95, 102, 105, 101, 108, 100, 40, 112, 44, 32, 48, 41, 41, 59, 32, 104, 101, 102, 102, 95, 100, 114, 111, 112, 40, 112, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 108, 32, 63, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eplusDone_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {40, 113, 44, 32, 107, 41, 32, 58, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eplusDone_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 113, 44, 32, 107, 41, 59, 32, 125}};
Clo g_heff_2eemitc_2eplusDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eplusDone_entry, 4, 0};

V g_heff_2eemitc_2eplusDone(V v_n_240, V v_la_241, V v_na_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_lb_244 = heff_field(v_x4_243, 0);
    V v_nb_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_intShow(heff_intAdd(heff_dup(v_n_240), MK_INT(1LL)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2eplusDone_str0), heff_strAppend(heff_intShow(v_n_240), heff_strAppend(((V)&g_heff_2eemitc_2eplusDone_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2eplusDone_str2), heff_strAppend(heff_intShow(v_na_242), ((V)&g_heff_2eemitc_2eplusDone_str3)))))));
    V v_t_248 = heff_tag_at(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2econcatList(v_lb_244, v_t_248));
    V v_t_2410 = (g_prelude_2econcatList(v_la_241, v_t_249));
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_nb_245});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eemitc_2eplusDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eplusDone(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eperformNodes_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2eperformNodes_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2eemitc_2eperformNodes_str2 = {{0x80000000u, K_STR, 0}, 34, 34, {40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 112, 114, 111, 118, 105, 100, 101, 114, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2eperformNodes_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 112, 44, 32, 107, 41, 59, 32, 125}};
Clo g_heff_2eemitc_2eperformNodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eperformNodes_entry, 2, 0};

V g_heff_2eemitc_2eperformNodes(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2eemitc_2eperformNodes_str0), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_243; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemitc_2eperformNodes_str1), heff_strAppend(heff_intShow(heff_dup(v_n_241)), heff_strAppend(((V)&g_heff_2eemitc_2eperformNodes_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eemitc_2eperformNodes_str3)))));
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_n_241, MK_INT(1LL))});
  }
  case TAG_Plus: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_x4_249 = (g_heff_2eemitc_2eperformNodes(v_a_247, heff_intAdd(heff_dup(v_n_241), MK_INT(1LL))));
    switch (heff_tag_of(v_x4_249)) {
    case TAG_MkPair: {
      V v_la_2410 = heff_field(v_x4_249, 0);
      V v_na_2411 = heff_field(v_x4_249, 1);
      heff_take_n(v_x4_249, 3ULL, 2);
      V v_t_2412 = (g_heff_2eemitc_2eperformNodes(v_b_248, heff_dup(v_na_2411)));
      return (g_heff_2eemitc_2eplusDone(v_n_241, v_la_2410, v_na_2411, v_t_2412));
    }
    default: return heff_nomatch(v_x4_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2eperformNodes_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eperformNodes(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprimCloDef_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2eprimCloDef_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 116, 97, 116, 105, 99, 32, 86, 32, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2eprimCloDef_str2 = {{0x80000000u, K_STR, 0}, 42, 42, {95, 101, 110, 116, 114, 121, 40, 86, 32, 115, 101, 108, 102, 44, 32, 86, 32, 42, 97, 41, 32, 123, 32, 40, 118, 111, 105, 100, 41, 115, 101, 108, 102, 59, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eprimCloDef_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprimCloDef_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2eprimCloDef_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemitc_2eprimCloDef_str6 = {{0x80000000u, K_STR, 0}, 16, 16, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eemitc_2eprimCloDef_str7 = {{0x80000000u, K_STR, 0}, 38, 38, {95, 99, 108, 111, 32, 61, 32, 123, 123, 48, 120, 56, 48, 48, 48, 48, 48, 48, 48, 117, 44, 32, 75, 95, 67, 76, 79, 44, 32, 48, 125, 44, 32, 112, 114, 105, 109, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemitc_2eprimCloDef_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {95, 101, 110, 116, 114, 121, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2eprimCloDef_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 48, 125, 59}};
Clo g_heff_2eemitc_2eprimCloDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprimCloDef_entry, 1, 0};

V g_heff_2eemitc_2eprimCloDef(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2eprims_2eallPrims_get()); V r_ = (g_heff_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_243 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(heff_dup(v_n_242), MK_INT(1LL))));
    V v_x2_244 = (g_prelude_2emap_24s637(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2eemitc_2eprimCloDef_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str1), heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str2), heff_strAppend(heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str3), heff_dup(v_p_240)), heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str4), heff_strAppend(v_t_247, ((V)&g_heff_2eemitc_2eprimCloDef_str5)))))));
    V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str6), heff_strAppend(heff_dup(v_p_240), heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str7), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2eemitc_2eprimCloDef_str8), heff_strAppend(heff_intShow(v_n_242), ((V)&g_heff_2eemitc_2eprimCloDef_str9)))))));
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2410});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2eprimCloDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprimCloDef(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2edefOwn_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2edefOwn_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemitc_2edefOwn_lam0(V self, V *args);
V g_heff_2eemitc_2edefOwn_lam1(V self, V *args);
Clo g_heff_2eemitc_2edefOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2edefOwn_entry, 2, 0};

V g_heff_2eemitc_2edefOwn(V v_ce_240, V v_d_241) {
top: ;
  V v_o_242 = heff_strAppend(((V)&g_heff_2eemitc_2edefOwn_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_241), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2edefOwn_str1))));
  V v_m_245 = heff_clo(g_heff_2eemitc_2edefOwn_lam0, 1, 1, (V[]){v_o_242});
  return heff_clo(g_heff_2eemitc_2edefOwn_lam1, 1, 3, (V[]){v_m_245, v_d_241, v_ce_240});
}
V g_heff_2eemitc_2edefOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2edefOwn(a[0], a[1]);
}
V g_heff_2eemitc_2edefOwn_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){v_o_242, MK_INT(0LL), heff_get(heff_dup(v_s_243), LBL_lams), heff_get(heff_dup(v_s_243), LBL_protos), MK_INT(0LL), heff_get(heff_dup(v_s_243), LBL_strs), heff_get(heff_dup(v_s_243), LBL_shapes), heff_get(v_s_243, LBL_prims)});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_244});
}
V g_heff_2eemitc_2edefOwn_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_ce_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_s_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 2ULL, 2);
    V v_x1_2410 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), MK_INT(0LL), heff_get(heff_dup(v_d_241), LBL_body)));
    V v_body_2413;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 2);
      v_body_2413 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    V v_t_2414 = heff_rec(3, shape_152_198_28, (V[]){heff_get(heff_dup(v_d_241), LBL_key), heff_get(v_d_241, LBL_name), v_body_2413});
    V v_t_2415 = (g_heff_2eemitc_2edefC(v_ce_240, v_t_2414));
    V f_ = v_t_2415;
    args[0] = v_s_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eemptyCS_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};

static V g_heff_2eemitc_2eemptyCS_val;
static int g_heff_2eemitc_2eemptyCS_st;
static V g_heff_2eemitc_2eemptyCS_init(void) {
  return heff_rec(8, shape_227_203_161_261_208_325_300_256, (V[]){((V)&g_heff_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eemitc_2eemptyCS_get(void) {
  if (g_heff_2eemitc_2eemptyCS_st == 2) return g_heff_2eemitc_2eemptyCS_val;
  if (g_heff_2eemitc_2eemptyCS_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2eemptyCS_st = 1;
  g_heff_2eemitc_2eemptyCS_val = heff_tr(g_heff_2eemitc_2eemptyCS_init());
  g_heff_2eemitc_2eemptyCS_st = 2;
  return g_heff_2eemitc_2eemptyCS_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[64]; } g_heff_2eemitc_2erunEnd_str0 = {{0x80000000u, K_STR, 0}, 64, 64, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 95, 48, 40, 112, 44, 32, 107, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2erunEnd_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2erunEnd_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eemitc_2erunEnd_str3 = {{0x80000000u, K_STR, 0}, 35, 35, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 101, 110, 116, 114, 121, 40, 118, 111, 105, 100, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemitc_2erunEnd_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {95, 103, 101, 116, 40, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2erunEnd_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2erunEnd_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  V v_x1_242 = (g_heff_2eemitc_2eperformNodes(v_eff_240, MK_INT(0LL)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2econcatList(v_t_245, v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2erunEnd_str1), (g_heff_2eemitc_2emangleW(heff_dup(g_heff_2elower_2eentryKey_get()), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2erunEnd_str2))));
  V v_t_249 = heff_strAppend(((V)&g_heff_2eemitc_2erunEnd_str3), heff_strAppend(v_t_248, ((V)&g_heff_2eemitc_2erunEnd_str4)));
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2erunEnd_str5), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2erunEnd_str6), heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2410})});
  HEFF_LAST return g_prelude_2econcatList(v_t_247, v_t_2411);
}
V g_heff_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2erunEnd(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eglobalGet_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eglobalGet_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eglobalGet_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemitc_2eglobalGet_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 116, 97, 116, 105, 99, 32, 86, 32, 103, 103, 101, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemitc_2eglobalGet_str4 = {{0x80000000u, K_STR, 0}, 20, 20, {40, 118, 111, 105, 100, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 40, 86, 41, 38}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemitc_2eglobalGet_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {95, 99, 108, 111, 59, 32, 125}};
Clo g_heff_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_x3_244 = ({ V a_0 = heff_dup(v_key_243); V b_1 = heff_get(v_ce_240, LBL_funs); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      V v_t_246 = (g_heff_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eglobalGet_str0)));
      V v_t_247 = heff_strAppend(((V)&g_heff_2eemitc_2eglobalGet_str1), (g_heff_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eglobalGet_str2))));
      V v_t_248 = heff_strAppend(((V)&g_heff_2eemitc_2eglobalGet_str3), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemitc_2eglobalGet_str4), heff_strAppend(v_t_247, ((V)&g_heff_2eemitc_2eglobalGet_str5)))));
      return heff_tag_at(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eglobalGet(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[76]; } g_heff_2eemitc_2echeckEnd_str0 = {{0x80000000u, K_STR, 0}, 76, 76, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 32, 123, 32, 40, 118, 111, 105, 100, 41, 112, 59, 32, 40, 118, 111, 105, 100, 41, 107, 59, 32, 114, 101, 116, 117, 114, 110, 32, 104, 101, 102, 102, 95, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2echeckEnd_str2 = {{0x80000000u, K_STR, 0}, 19, 19, {115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 99, 104, 97, 114, 32, 42}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckEnd_str3 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2echeckEnd_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemitc_2echeckEnd_str7 = {{0x80000000u, K_STR, 0}, 19, 19, {115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 99, 104, 97, 114, 32, 42}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckEnd_str8 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2echeckEnd_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemitc_2echeckEnd_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {95, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2echeckEnd_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {103, 103, 101, 116, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemitc_2echeckEnd_str17 = {{0x80000000u, K_STR, 0}, 3, 3, {34, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemitc_2echeckEnd_str20 = {{0x80000000u, K_STR, 0}, 12, 12, {123, 78, 85, 76, 76, 44, 32, 78, 85, 76, 76, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2echeckEnd_str22 = {{0x80000000u, K_STR, 0}, 42, 42, {115, 116, 97, 116, 105, 99, 32, 99, 111, 110, 115, 116, 32, 71, 108, 111, 98, 97, 108, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 95, 97, 114, 114, 91, 93, 32, 61, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2echeckEnd_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckEnd_str24 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 32, 104, 101, 102, 102, 95, 110, 103, 108, 111, 98, 97, 108, 115, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eemitc_2echeckEnd_str27 = {{0x80000000u, K_STR, 0}, 38, 38, {32, 32, 104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 32, 61, 32, 104, 101, 102, 102, 95, 108, 98, 108, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2echeckEnd_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_heff_2eemitc_2echeckEnd_str29 = {{0x80000000u, K_STR, 0}, 38, 38, {32, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 32, 61, 32, 104, 101, 102, 102, 95, 116, 97, 103, 95, 110, 97, 109, 101, 115, 95, 97, 114, 114, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eemitc_2echeckEnd_str30 = {{0x80000000u, K_STR, 0}, 35, 35, {115, 116, 97, 116, 105, 99, 32, 118, 111, 105, 100, 32, 104, 101, 102, 102, 95, 99, 104, 101, 99, 107, 95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2eemitc_2echeckEnd_str31 = {{0x80000000u, K_STR, 0}, 34, 34, {32, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 32, 61, 32, 104, 101, 102, 102, 95, 103, 108, 111, 98, 97, 108, 115, 95, 97, 114, 114, 59}};
V g_heff_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam5(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam7(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam6(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam9(V self, V *args);
V g_heff_2eemitc_2echeckEnd_lam8(V self, V *args);
Clo g_heff_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_xs_249 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2410 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_249));
  V v_t_2414 = ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam2, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  V v_t_2415 = ({ V b_0 = heff_get(heff_dup(v_ce_242), LBL_tags); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2416 = (g_prelude_2esortBy_24s654(v_t_2415));
  V v_x2_2417 = (g_prelude_2emap_24s653(v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2eemitc_2echeckEnd_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_t_2420 = ({ V a_0 = v_x_2418; V a_1 = v_xs_2419; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str2), heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str3), heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str4), heff_strAppend(v_t_2420, ((V)&g_heff_2eemitc_2echeckEnd_str5)))));
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = ({ V b_0 = heff_get(heff_dup(v_ce_242), LBL_lbls); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2424 = (g_prelude_2esortBy_24s654(v_t_2423));
  V v_x2_2425 = (g_prelude_2emap_24s653(v_t_2424));
  V v_t_2428;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nil: {
    v_t_2428 = ((V)&g_heff_2eemitc_2echeckEnd_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_xs_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    v_t_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2427); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  V v_t_2429 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str7), heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str8), heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str9), heff_strAppend(v_t_2428, ((V)&g_heff_2eemitc_2echeckEnd_str10)))));
  V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_t_2436 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2448 = (g_prelude_2emap(heff_clo(g_heff_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){v_ce_242}), v_t_2436));
  V v_t_2451;
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_Nil: {
    v_t_2451 = ((V)&g_heff_2eemitc_2echeckEnd_str19);
    break;
  }
  case TAG_Cons: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_xs_2450 = heff_field(v_x2_2448, 1);
    heff_take_n(v_x2_2448, 3ULL, 2);
    v_t_2451 = ({ V a_0 = v_x_2449; V a_1 = v_xs_2450; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2450); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2448);
  }
  V v_x1_2457 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam6, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2460;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nil: {
    v_t_2460 = ((V)&g_heff_2eemitc_2echeckEnd_str20);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2457, 0ULL, 2);
    v_t_2460 = ((V)&g_heff_2eemitc_2echeckEnd_str21);
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_t_2461 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str22), heff_strAppend(v_t_2451, heff_strAppend(v_t_2460, ((V)&g_heff_2eemitc_2echeckEnd_str23))));
  V v_xs_2467 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2echeckEnd_lam8, 1, 1, (V[]){heff_dup(v_defs_241)}), v_exports_240));
  V v_t_2468 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2467; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2467); r_; });
  V v_t_2469 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str24), heff_strAppend(heff_intShow(v_t_2468), ((V)&g_heff_2eemitc_2echeckEnd_str25)));
  V v_t_2470 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str26), NTAG(TAG_Nil)});
  V v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str27), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str28), v_t_2470})});
  V v_t_2472 = heff_tag(TAG_Cons, 2, (V[]){v_t_2469, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str29), v_t_2471})});
  V v_t_2473 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str30), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckEnd_str31), v_t_2472})});
  V v_t_2474 = (g_prelude_2econcatList(v_t_2430, heff_tag(TAG_Cons, 2, (V[]){v_t_2461, v_t_2473})));
  V v_t_2475 = (g_prelude_2econcatList(v_t_2422, v_t_2474));
  V v_t_2476 = (g_prelude_2econcatList(v_t_2414, v_t_2475));
  return (g_prelude_2econcatList(v_t_243, v_t_2476));
}
V g_heff_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2echeckEnd(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_d_248 = args[0];
  V v_key_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_248, LBL_key), v_key_247);
}
V g_heff_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_key_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam1, 1, 1, (V[]){v_key_247}); V a_1 = v_defs_241; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = (g_heff_2eemitc_2eglobalGet(v_ce_242, v_x_2412));
  return (g_prelude_2econcatList(v_t_2413, v_acc_2411));
}
V g_heff_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_d_2435 = args[0];
  V v_key_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_2435, LBL_key), v_key_2434);
}
V g_heff_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2431 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2434;
  switch (heff_tag_of(v_p_2431)) {
  case TAG_MkPair: {
    V v_y_2433 = heff_field(v_p_2431, 1);
    heff_take_n(v_p_2431, 2ULL, 2);
    v_key_2434 = v_y_2433;
    break;
  }
  default: heff_nomatch(v_p_2431);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){v_key_2434}); V a_1 = v_defs_241; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2437 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  switch (heff_tag_of(v_p_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_dup(heff_field(v_p_2437, 0));
    v_t_2440 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_p_2437);
  }
  V v_key_2443;
  switch (heff_tag_of(v_p_2437)) {
  case TAG_MkPair: {
    V v_y_2442 = heff_field(v_p_2437, 1);
    heff_take_n(v_p_2437, 2ULL, 2);
    v_key_2443 = v_y_2442;
    break;
  }
  default: heff_nomatch(v_p_2437);
  }
  V v_x3_2444 = ({ V a_0 = heff_dup(v_key_2443); V b_1 = heff_get(v_ce_242, LBL_funs); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2447;
  switch (heff_tag_of(v_x3_2444)) {
  case TAG_Nothing: {
    V v_t_2445 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str11), (g_heff_2eemitc_2emangleW(v_key_2443, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2echeckEnd_str12))));
    v_t_2447 = heff_strAppend(v_t_2445, ((V)&g_heff_2eemitc_2echeckEnd_str13));
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2444, 0ULL, 1);
    v_t_2447 = heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str14), (g_heff_2eemitc_2emangleW(v_key_2443, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2echeckEnd_str15))));
    break;
  }
  default: heff_nomatch(v_x3_2444);
  }
  return heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str16), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2eemitc_2echeckEnd_str17), heff_strAppend(v_t_2447, ((V)&g_heff_2eemitc_2echeckEnd_str18)))));
}
V g_heff_2eemitc_2echeckEnd_lam7(V self, V *args) {
  V v_d_2456 = args[0];
  V v_key_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_2456, LBL_key), v_key_2455);
}
V g_heff_2eemitc_2echeckEnd_lam6(V self, V *args) {
  V v_p_2452 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2455;
  switch (heff_tag_of(v_p_2452)) {
  case TAG_MkPair: {
    V v_y_2454 = heff_field(v_p_2452, 1);
    heff_take_n(v_p_2452, 2ULL, 2);
    v_key_2455 = v_y_2454;
    break;
  }
  default: heff_nomatch(v_p_2452);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam7, 1, 1, (V[]){v_key_2455}); V a_1 = v_defs_241; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2echeckEnd_lam9(V self, V *args) {
  V v_d_2466 = args[0];
  V v_key_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_d_2466, LBL_key), v_key_2465);
}
V g_heff_2eemitc_2echeckEnd_lam8(V self, V *args) {
  V v_p_2462 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2465;
  switch (heff_tag_of(v_p_2462)) {
  case TAG_MkPair: {
    V v_y_2464 = heff_field(v_p_2462, 1);
    heff_take_n(v_p_2462, 2ULL, 2);
    v_key_2465 = v_y_2464;
    break;
  }
  default: heff_nomatch(v_p_2462);
  }
  return ({ V a_0 = heff_clo(g_heff_2eemitc_2echeckEnd_lam9, 1, 1, (V[]){v_key_2465}); V a_1 = v_defs_241; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2eemitc_2eonlyLent_lam0(V self, V *args);
V g_heff_2eemitc_2eonlyLent_lam1(V self, V *args);
V g_heff_2eemitc_2eonlyLent_lam2(V self, V *args);
V g_heff_2eemitc_2eonlyLent_lam3(V self, V *args);
Clo g_heff_2eemitc_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eonlyLent_entry, 3, 0};

V g_heff_2eemitc_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_bor_240);
    V v_t_244 = heff_strEq(v_p_241, v_x_243);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_247;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_as_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_prelude_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x3_242, 1);
    V v_b_2413 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_2414 = (g_heff_2eemitc_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2413;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_bor_240);
      heff_drop(v_p_241);
      heff_drop(v_b_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam0, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_fs_2415; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_fs_2415); r_; });
  }
  case TAG_EProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2420;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2423 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2424; V a_1 = v_as_2423; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_as_2423); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x3_242, 0);
    V v_arms_2426 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_s_2425)) {
    case TAG_EVar: {
      V v_x_2427 = heff_dup(heff_field(v_s_2425, 0));
      v_t_2453 = heff_strEq(heff_dup(v_p_241), v_x_2427);
      break;
    }
    case TAG_EGlobal: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2453 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2425);
    }
    switch (heff_tag_of(v_t_2453)) {
    case TAG_True: {
      heff_drop(v_s_2425);
      return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam1, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2426; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    }
    case TAG_False: {
      V v_t_2459 = (g_heff_2eemitc_2eonlyLent(heff_dup(v_bor_240), heff_dup(v_p_241), v_s_2425));
      switch (heff_tag_of(v_t_2459)) {
      case TAG_True: {
        return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam2, 1, 2, (V[]){v_bor_240, v_p_241}); V a_1 = v_arms_2426; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_arms_2426); r_; });
      }
      case TAG_False: {
        heff_drop(v_bor_240);
        heff_drop(v_p_241);
        heff_drop(v_arms_2426);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2459);
      }
    }
    default: return heff_nomatch(v_t_2453);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2467 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_t_2468 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eonlyLent_clo), 2, (V[]){v_bor_240, v_p_241}));
    return ({ V a_0 = v_t_2468; V a_1 = v_as_2467; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_as_2467); r_; });
  }
  case TAG_ECall: {
    V v_g_2469 = heff_field(v_x3_242, 0);
    V v_as_2470 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2471 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2470));
    V v_t_2472 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2471, MK_INT(1LL))));
    V v_t_2473 = (g_prelude_2ezipWith_24s634(v_as_2470, v_t_2472));
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2eonlyLent_lam3, 1, 3, (V[]){v_p_241, v_g_2469, v_bor_240}); V a_1 = v_t_2473; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_t_2473); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_bor_240);
    heff_drop(v_p_241);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemitc_2eonlyLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eonlyLent(a[0], a[1], a[2]);
}
V g_heff_2eemitc_2eonlyLent_lam0(V self, V *args) {
  V v_f_2416 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  switch (heff_tag_of(v_f_2416)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_f_2416, 1);
    heff_take_n(v_f_2416, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_f_2416);
  }
  return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2419));
}
V g_heff_2eemitc_2eonlyLent_lam1(V self, V *args) {
  V v_a_2454 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458;
  switch (heff_tag_of(v_a_2454)) {
  case TAG_MkArm: {
    V v_b_2457 = heff_field(v_a_2454, 2);
    heff_take_n(v_a_2454, 4ULL, 3);
    v_t_2458 = v_b_2457;
    break;
  }
  default: heff_nomatch(v_a_2454);
  }
  return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2458));
}
V g_heff_2eemitc_2eonlyLent_lam2(V self, V *args) {
  V v_a_2460 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464;
  switch (heff_tag_of(v_a_2460)) {
  case TAG_MkArm: {
    V v_b_2463 = heff_field(v_a_2460, 2);
    heff_take_n(v_a_2460, 4ULL, 3);
    v_t_2464 = v_b_2463;
    break;
  }
  default: heff_nomatch(v_a_2460);
  }
  return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_2464));
}
V g_heff_2eemitc_2eonlyLent_lam3(V self, V *args) {
  V v_pr_2474 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_g_2469 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2477;
  switch (heff_tag_of(v_pr_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_dup(heff_field(v_pr_2474, 0));
    v_x2_2477 = v_x_2475;
    break;
  }
  default: heff_nomatch(v_pr_2474);
  }
  V v_t_24104;
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_EVar: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    heff_take_n(v_x2_2477, 1ULL, 1);
    v_t_24104 = heff_strEq(heff_dup(v_p_241), v_x_2478);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_2477, 0ULL, 1);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_x2_2477, 0ULL, 3);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_2477, 0ULL, 1);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_2477, 0ULL, 1);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_x2_2477, 0ULL, 1);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_2477, 0ULL, 1);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_x2_2477, 0ULL, 1);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_x2_2477, 0ULL, 2);
    v_t_24104 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x2_2477);
  }
  switch (heff_tag_of(v_t_24104)) {
  case TAG_True: {
    V v_t_24107;
    switch (heff_tag_of(v_pr_2474)) {
    case TAG_MkPair: {
      V v_y_24106 = heff_dup(heff_field(v_pr_2474, 1));
      v_t_24107 = v_y_24106;
      break;
    }
    default: heff_nomatch(v_pr_2474);
    }
    V v_x2_24108 = (g_map_2elookup_24s8(v_g_2469, v_bor_240));
    V v_t_24110;
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_Nothing: {
      v_t_24110 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      heff_take_n(v_x2_24108, 1ULL, 1);
      v_t_24110 = v_x_24109;
      break;
    }
    default: heff_nomatch(v_x2_24108);
    }
    V v_t_24111 = ({ V a_0 = v_t_24107; V a_1 = v_t_24110; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_t_24110); r_; });
    switch (heff_tag_of(v_t_24111)) {
    case TAG_True: {
      heff_drop(v_pr_2474);
      heff_drop(v_p_241);
      heff_drop(v_bor_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_24114;
      switch (heff_tag_of(v_pr_2474)) {
      case TAG_MkPair: {
        V v_x_24112 = heff_field(v_pr_2474, 0);
        heff_take_n(v_pr_2474, 1ULL, 2);
        v_t_24114 = v_x_24112;
        break;
      }
      default: heff_nomatch(v_pr_2474);
      }
      return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_24114));
    }
    default: return heff_nomatch(v_t_24111);
    }
  }
  case TAG_False: {
    heff_drop(v_g_2469);
    V v_t_24117;
    switch (heff_tag_of(v_pr_2474)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_pr_2474, 0);
      heff_take_n(v_pr_2474, 1ULL, 2);
      v_t_24117 = v_x_24115;
      break;
    }
    default: heff_nomatch(v_pr_2474);
    }
    return (g_heff_2eemitc_2eonlyLent(v_bor_240, v_p_241, v_t_24117));
  }
  default: return heff_nomatch(v_t_24104);
  }
}
V g_heff_2eemitc_2ebuildsSize_lam0(V self, V *args);
V g_heff_2eemitc_2ebuildsSize_lam1(V self, V *args);
Clo g_heff_2eemitc_2ebuildsSize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ebuildsSize_entry, 2, 0};

V g_heff_2eemitc_2ebuildsSize(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_b_245;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2eemitc_2ebuildsSize(heff_dup(v_n_240), v_a_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_b_2411);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_n_240;
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2ebuildsSize_lam0, 1, 1, (V[]){v_n_240}); V a_1 = v_fs_2413; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V t_0 = v_n_240;
    V t_1 = v_e_2418;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2422 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2421));
    V v_t_2423 = heff_intEq(v_t_2422, heff_dup(v_n_240));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_as_2421);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
      return ({ V a_0 = v_t_2424; V a_1 = v_as_2421; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_as_2421); r_; });
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x2_241, 0);
    V v_arms_2426 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2427 = (g_heff_2eemitc_2ebuildsSize(heff_dup(v_n_240), v_s_2425));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_arms_2426);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      return ({ V a_0 = heff_clo(g_heff_2eemitc_2ebuildsSize_lam1, 1, 1, (V[]){v_n_240}); V a_1 = v_arms_2426; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2435 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2436 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2436; V a_1 = v_as_2435; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_as_2435); r_; });
  }
  case TAG_ECall: {
    V v_as_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2439 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ebuildsSize_clo), 1, (V[]){v_n_240}));
    return ({ V a_0 = v_t_2439; V a_1 = v_as_2438; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_as_2438); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2ebuildsSize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ebuildsSize(a[0], a[1]);
}
V g_heff_2eemitc_2ebuildsSize_lam0(V self, V *args) {
  V v_f_2414 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_f_2414, 1);
    heff_take_n(v_f_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_f_2414);
  }
  return (g_heff_2eemitc_2ebuildsSize(v_n_240, v_t_2417));
}
V g_heff_2eemitc_2ebuildsSize_lam1(V self, V *args) {
  V v_a_2428 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  return (g_heff_2eemitc_2ebuildsSize(v_n_240, v_t_2432));
}
V g_heff_2eemitc_2ereuses_lam0(V self, V *args);
V g_heff_2eemitc_2ereuses_lam1(V self, V *args);
V g_heff_2eemitc_2ereuses_lam2(V self, V *args);
Clo g_heff_2eemitc_2ereuses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ereuses_entry, 2, 0};

V g_heff_2eemitc_2ereuses(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_b_245;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_248; V b_1 = heff_tag_at(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_as_247}); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2412 = (g_heff_2eemitc_2ereuses(heff_dup(v_p_240), v_a_2410));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_p_240);
      heff_drop(v_b_2411);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_b_2411;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2ereuses_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_fs_2413; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_fs_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V t_0 = v_p_240;
    V t_1 = v_e_2418;
    v_p_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2422; V a_1 = v_as_2421; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_as_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x2_241, 0);
    V v_arms_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2451;
    switch (heff_tag_of(v_s_2423)) {
    case TAG_EVar: {
      V v_x_2425 = heff_dup(heff_field(v_s_2423, 0));
      v_t_2451 = heff_strEq(heff_dup(v_p_240), v_x_2425);
      break;
    }
    case TAG_EGlobal: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2451 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2423);
    }
    switch (heff_tag_of(v_t_2451)) {
    case TAG_True: {
      V v_t_2452 = (g_prelude_2eany_24s656(v_arms_2424));
      switch (heff_tag_of(v_t_2452)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_s_2423);
        heff_drop(v_arms_2424);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_2453 = (g_heff_2eemitc_2ereuses(heff_dup(v_p_240), v_s_2423));
        switch (heff_tag_of(v_t_2453)) {
        case TAG_True: {
          heff_drop(v_p_240);
          heff_drop(v_arms_2424);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          return ({ V a_0 = heff_clo(g_heff_2eemitc_2ereuses_lam1, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2424; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_arms_2424); r_; });
        }
        default: return heff_nomatch(v_t_2453);
        }
      }
      default: return heff_nomatch(v_t_2452);
      }
    }
    case TAG_False: {
      V v_t_2459 = (g_heff_2eemitc_2ereuses(heff_dup(v_p_240), v_s_2423));
      switch (heff_tag_of(v_t_2459)) {
      case TAG_True: {
        heff_drop(v_p_240);
        heff_drop(v_arms_2424);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return ({ V a_0 = heff_clo(g_heff_2eemitc_2ereuses_lam2, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2424; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_arms_2424); r_; });
      }
      default: return heff_nomatch(v_t_2459);
      }
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_as_2467 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2468 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2468; V a_1 = v_as_2467; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_as_2467); r_; });
  }
  case TAG_ECall: {
    V v_as_2470 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2471 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2ereuses_clo), 1, (V[]){v_p_240}));
    return ({ V a_0 = v_t_2471; V a_1 = v_as_2470; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_as_2470); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2ereuses_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ereuses(a[0], a[1]);
}
V g_heff_2eemitc_2ereuses_lam0(V self, V *args) {
  V v_f_2414 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_f_2414, 1);
    heff_take_n(v_f_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_f_2414);
  }
  return (g_heff_2eemitc_2ereuses(v_p_240, v_t_2417));
}
V g_heff_2eemitc_2ereuses_lam1(V self, V *args) {
  V v_a_2454 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_a_2454)) {
  case TAG_MkArm: {
    V v_b_2457 = heff_field(v_a_2454, 2);
    heff_take_n(v_a_2454, 4ULL, 3);
    v_t_2458 = v_b_2457;
    break;
  }
  default: heff_nomatch(v_a_2454);
  }
  return (g_heff_2eemitc_2ereuses(v_p_240, v_t_2458));
}
V g_heff_2eemitc_2ereuses_lam2(V self, V *args) {
  V v_a_2460 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464;
  switch (heff_tag_of(v_a_2460)) {
  case TAG_MkArm: {
    V v_b_2463 = heff_field(v_a_2460, 2);
    heff_take_n(v_a_2460, 4ULL, 3);
    v_t_2464 = v_b_2463;
    break;
  }
  default: heff_nomatch(v_a_2460);
  }
  return (g_heff_2eemitc_2ereuses(v_p_240, v_t_2464));
}
V g_heff_2eemitc_2elentVars_lam0(V self, V *args);
Clo g_heff_2eemitc_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elentVars_entry, 2, 0};

V g_heff_2eemitc_2elentVars(V v_ds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2eemitc_2elentVars(heff_dup(v_ds_240), v_a_249));
    V v_t_2412 = (g_heff_2eemitc_2elentVars(v_ds_240, v_b_2410));
    HEFF_LAST return g_prelude_2econcatList(v_t_2411, v_t_2412);
  }
  case TAG_ERecord: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2418 = heff_field(v_x2_241, 0);
    V v_arms_2419 = heff_field(v_x2_241, 1);
    V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_arms_2419)));
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2elentVars_lam0, 2, 2, (V[]){heff_dup(v_s_2418), v_ds_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2420; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemitc_2elentVars_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2elentVars(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eemitc_2elentVars_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_x_2422 = args[1];
  V v_s_2418 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449;
  switch (heff_tag_of(v_s_2418)) {
  case TAG_EVar: {
    V v_x_2423 = heff_field(v_s_2418, 0);
    heff_take_n(v_s_2418, 1ULL, 1);
    v_t_2449 = (g_heff_2eemitc_2eelemS(v_x_2423, v_ds_240));
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2418, 0ULL, 3);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2418, 0ULL, 1);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2418, 0ULL, 2);
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2418);
  }
  V v_t_2468;
  switch (heff_tag_of(v_t_2449)) {
  case TAG_True: {
    V v_t_2453;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_vs_2451 = heff_dup(heff_field(v_x_2422, 1));
      v_t_2453 = v_vs_2451;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    V v_t_2457;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_vs_2455 = heff_dup(heff_field(v_x_2422, 1));
      v_t_2457 = v_vs_2455;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    V v_t_2458 = (g_prelude_2econcatList(v_t_2457, v_ds_240));
    V v_t_2462;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_b_2461 = heff_field(v_x_2422, 2);
      heff_take_n(v_x_2422, 4ULL, 3);
      v_t_2462 = v_b_2461;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    V v_t_2463 = ({ V a_0 = v_t_2458; V a_1 = v_t_2462; V r_ = (g_heff_2eemitc_2elentVars(a_0, a_1)); heff_drop(v_t_2462); r_; });
    v_t_2468 = (g_prelude_2econcatList(v_t_2453, v_t_2463));
    break;
  }
  case TAG_False: {
    V v_t_2467;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_MkArm: {
      V v_b_2466 = heff_field(v_x_2422, 2);
      heff_take_n(v_x_2422, 4ULL, 3);
      v_t_2467 = v_b_2466;
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    v_t_2468 = ({ V a_0 = v_ds_240; V a_1 = v_t_2467; V r_ = (g_heff_2eemitc_2elentVars(a_0, a_1)); heff_drop(v_t_2467); r_; });
    break;
  }
  default: heff_nomatch(v_t_2449);
  }
  return (g_prelude_2econcatList(v_t_2468, v_acc_2421));
}
V g_heff_2eemitc_2eloopLent_lam0(V self, V *args);
V g_heff_2eemitc_2eloopLent_lam2(V self, V *args);
V g_heff_2eemitc_2eloopLent_lam1(V self, V *args);
Clo g_heff_2eemitc_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eloopLent_entry, 4, 0};

V g_heff_2eemitc_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_as_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2410; V b_1 = heff_tag_at(v_ru_24x4_243_24EApp, TAG_Cons, 2, (V[]){v_f_248, v_as_249}); V r_ = (g_prelude_2eall(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x4_243, 1);
    V v_b_2413 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 6ULL, 3);
    V v_t_2414 = (g_heff_2eemitc_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2413;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_b_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    V v_as_2419 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    V v_t_2420 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
    return ({ V a_0 = v_t_2420; V a_1 = v_as_2419; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_as_2419); r_; });
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_x4_243, 0);
    V v_arms_2422 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2423 = (g_heff_2eemitc_2eloopLent(heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242), v_s_2421));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      return ({ V a_0 = heff_clo(g_heff_2eemitc_2eloopLent_lam0, 1, 3, (V[]){v_key_240, v_i_241, v_ds_242}); V a_1 = v_arms_2422; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_arms_2422); r_; });
    }
    case TAG_False: {
      heff_drop(v_key_240);
      heff_drop(v_i_241);
      heff_drop(v_ds_242);
      heff_drop(v_arms_2422);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    V v_g_2432 = heff_field(v_x4_243, 0);
    V v_as_2433 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2434 = heff_strEq(v_g_2432, heff_dup(v_key_240));
    V v_t_2435;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      V v_t_2436 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
      return ({ V a_0 = v_t_2436; V a_1 = v_as_2433; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_as_2433); r_; });
    }
    case TAG_False: {
      V v_t_2437 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2433));
      V v_t_2438 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2437, MK_INT(1LL))));
      V v_t_2439 = (g_prelude_2ezipWith_24s634(heff_dup(v_as_2433), v_t_2438));
      V v_t_2475 = ({ V a_0 = heff_clo(g_heff_2eemitc_2eloopLent_lam1, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2439; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_t_2439); r_; });
      switch (heff_tag_of(v_t_2475)) {
      case TAG_True: {
        V v_t_2476 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2eloopLent_clo), 3, (V[]){v_key_240, v_i_241, v_ds_242}));
        return ({ V a_0 = v_t_2476; V a_1 = v_as_2433; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_as_2433); r_; });
      }
      case TAG_False: {
        heff_drop(v_key_240);
        heff_drop(v_i_241);
        heff_drop(v_ds_242);
        heff_drop(v_as_2433);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2475);
      }
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_key_240);
    heff_drop(v_i_241);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eemitc_2eloopLent_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eloopLent(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemitc_2eloopLent_lam0(V self, V *args) {
  V v_a_2424 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_MkArm: {
    V v_b_2427 = heff_field(v_a_2424, 2);
    heff_take_n(v_a_2424, 4ULL, 3);
    v_t_2428 = v_b_2427;
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  return (g_heff_2eemitc_2eloopLent(v_key_240, v_i_241, v_ds_242, v_t_2428));
}
V g_heff_2eemitc_2eloopLent_lam2(V self, V *args) {
  V v_d_2445 = args[0];
  V v_pr_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2448;
  switch (heff_tag_of(v_pr_2440)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_pr_2440, 0);
    heff_take_n(v_pr_2440, 1ULL, 2);
    v_x2_2448 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_pr_2440);
  }
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_EVar: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    heff_take_n(v_x2_2448, 1ULL, 1);
    return heff_strEq(v_d_2445, v_x_2449);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_2448, 0ULL, 3);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_2448, 0ULL, 1);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_2448, 0ULL, 2);
    heff_drop(v_d_2445);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2eemitc_2eloopLent_lam1(V self, V *args) {
  V v_pr_2440 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443;
  switch (heff_tag_of(v_pr_2440)) {
  case TAG_MkPair: {
    V v_y_2442 = heff_dup(heff_field(v_pr_2440, 1));
    v_t_2443 = v_y_2442;
    break;
  }
  default: heff_nomatch(v_pr_2440);
  }
  V v_x1_2444 = heff_intEq(v_t_2443, v_i_241);
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_True: {
    return ({ V a_0 = heff_clo(g_heff_2eemitc_2eloopLent_lam2, 1, 1, (V[]){v_pr_2440}); V a_1 = v_ds_242; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_ds_242); r_; });
  }
  case TAG_False: {
    heff_drop(v_pr_2440);
    heff_drop(v_ds_242);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2444);
  }
}
V g_heff_2eemitc_2eborDef_lam0(V self, V *args);
V g_heff_2eemitc_2eborDef_lam1(V self, V *args);
V g_heff_2eemitc_2eborDef_lam2(V self, V *args);
Clo g_heff_2eemitc_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eborDef_entry, 2, 0};

V g_heff_2eemitc_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    V v_x2_247 = (g_map_2elookup_24s8(heff_get(heff_dup(v_d_241), LBL_key), v_bor_240));
    V v_bi_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_bi_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_bi_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_245));
    V v_t_2411 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
    V v_t_2412 = (g_prelude_2ezipWith_24s634(heff_dup(v_xs_245), v_t_2411));
    V v_t_2417 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eborDef_lam0, 1, 1, (V[]){v_bi_249}), v_t_2412));
    V v_t_2418 = (g_prelude_2emap_24s618(v_t_2417));
    V v_x2_2419 = (g_map_2elookup_24s8(heff_get(heff_dup(v_d_241), LBL_key), v_bor_240));
    V v_bi_2421;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nothing: {
      v_bi_2421 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      heff_take_n(v_x2_2419, 1ULL, 1);
      v_bi_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2422 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_245));
    V v_t_2423 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_2422, MK_INT(1LL))));
    V v_t_2424 = (g_prelude_2ezipWith_24s634(heff_dup(v_xs_245), v_t_2423));
    V v_t_2429 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eborDef_lam1, 1, 1, (V[]){v_bi_2421}), v_t_2424));
    V v_t_2430 = (g_prelude_2emap_24s618(v_t_2429));
    V v_t_2431 = (g_heff_2eemitc_2elentVars(v_t_2430, v_b_246));
    V v_ds_2432 = (g_prelude_2econcatList(v_t_2418, v_t_2431));
    V v_x2_2433 = (g_map_2elookup_24s8(heff_get(heff_dup(v_d_241), LBL_key), v_bor_240));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nothing: {
      v_t_2435 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      heff_take_n(v_x2_2433, 1ULL, 1);
      v_t_2435 = v_x_2434;
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_t_2442 = (g_prelude_2efilter(heff_clo(g_heff_2eemitc_2eborDef_lam2, 1, 5, (V[]){v_xs_245, heff_dup(v_bor_240), v_b_246, heff_dup(v_d_241), v_ds_2432}), v_t_2435));
    return (g_map_2einsert_24s7(heff_get(v_d_241, LBL_key), v_t_2442, v_bor_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_bor_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eborDef(a[0], a[1]);
}
V g_heff_2eemitc_2eborDef_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_bi_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_p_2413, 1);
    heff_take_n(v_p_2413, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  return ({ V a_0 = v_t_2416; V a_1 = v_bi_249; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_249); r_; });
}
V g_heff_2eemitc_2eborDef_lam1(V self, V *args) {
  V v_p_2425 = args[0];
  V v_bi_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_p_2425, 1);
    heff_take_n(v_p_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_p_2425);
  }
  return ({ V a_0 = v_t_2428; V a_1 = v_bi_2421; V r_ = (g_heff_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_2421); r_; });
}
V g_heff_2eemitc_2eborDef_lam2(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_b_246 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_ds_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = (g_prelude_2edrop(heff_dup(v_i_2436), v_xs_245));
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nil: {
    heff_drop(v_i_2436);
    heff_drop(v_bor_240);
    heff_drop(v_b_246);
    heff_drop(v_d_241);
    heff_drop(v_ds_2432);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_2438 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    V v_t_2440 = (g_heff_2eemitc_2eonlyLent(v_bor_240, heff_dup(v_p_2438), heff_dup(v_b_246)));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      V v_x1_2441 = (g_heff_2eemitc_2ereuses(v_p_2438, heff_dup(v_b_246)));
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_True: {
        heff_drop(v_i_2436);
        heff_drop(v_b_246);
        heff_drop(v_d_241);
        heff_drop(v_ds_2432);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return (g_heff_2eemitc_2eloopLent(heff_get(v_d_241, LBL_key), v_i_2436, v_ds_2432, v_b_246));
      }
      default: return heff_nomatch(v_x1_2441);
      }
    }
    case TAG_False: {
      heff_drop(v_i_2436);
      heff_drop(v_b_246);
      heff_drop(v_d_241);
      heff_drop(v_ds_2432);
      heff_drop(v_p_2438);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  default: return heff_nomatch(v_t_2437);
  }
}
Clo g_heff_2eemitc_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eborFix_entry, 3, 0};

V g_heff_2eemitc_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
  V v_xs_244 = (g_prelude_2emap_24s657(v_t_243));
  V v_t_245 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s2(a_0, a_1)); heff_drop(v_xs_244); r_; });
  V v_t_246 = heff_intEq(v_t_245, v_size_241);
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    return v_bor_242;
  }
  case TAG_False: {
    V v_t_247 = (g_map_2etoListOnto(v_bor_242, NTAG(TAG_Nil)));
    V v_xs_248 = (g_prelude_2emap_24s657(v_t_247));
    V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s2(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_t_2410 = (g_prelude_2efoldl_24s658(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_249;
    V t_2 = v_t_2410;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eemitc_2eborFix_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eborFix(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemitc_2eborAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eborAll_entry, 2, 0};

V g_heff_2eemitc_2eborAll(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_245); r_; });
    V v_t_248 = (g_prelude_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    return (g_map_2einsert_24s7(heff_get(v_d_241, LBL_key), v_t_248, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemitc_2eborAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eborAll(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2eprogramCE_str0 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eemitc_2eprogramCE_str1 = {{0x80000000u, K_STR, 0}, 32, 32, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eprogramCE_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_t_245 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_244)}));
  V v_t_246 = (g_heff_2eemitc_2etraverseC(v_t_245, v_defs_243));
  V v_t_247 = heff_tr(heff_apply(v_t_246, 1, (V[]){heff_dup(g_heff_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_ems_248 = heff_field(v_t_247, 0);
    V v_s_249 = heff_field(v_t_247, 1);
    V v_ru_24t_247_24MkPair = heff_take_reuse_n(v_t_247, 3ULL, 2);
    V v_t_2410 = heff_tag_at(v_ru_24t_247_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eprogramCE_str0), heff_get(heff_dup(v_ending_242), LBL_prefix)});
    V v_t_2411 = ({ V b_0 = heff_get(heff_dup(v_ce_244), LBL_tags); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412 = (g_prelude_2efilter_24s661(v_t_2411));
    V v_t_2413 = (g_prelude_2emap_24s660(v_t_2412));
    V v_t_2414 = ({ V b_0 = heff_get(heff_dup(v_ce_244), LBL_lbls); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2415 = (g_prelude_2emap_24s662(v_t_2414));
    V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2emap_24s246(v_provs_241));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2eprogramCE_str1), NTAG(TAG_Nil)});
    V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_strs)));
    V v_t_2420 = (g_prelude_2emap_24s513(v_t_2419));
    V v_t_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_shapes)));
    V v_t_2422 = (g_prelude_2emap_24s663(v_t_2421));
    V v_t_2423 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_ems_248)));
    V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_prelude_2efoldl_24s664(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_protos)));
    V v_t_2426 = (g_prelude_2emap_24s513(v_t_2425));
    V v_xs_2427 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_s_249), LBL_prims)));
    V v_t_2428 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2427));
    V v_t_2429 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2428; V r_ = (g_prelude_2efoldl_24s665(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_t_2430 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ems_248));
    V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_prelude_2efoldl_24s666(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_s_249, LBL_lams)));
    V v_t_2433 = (g_prelude_2emap_24s513(v_t_2432));
    V v_t_2434 = heff_tr(heff_apply(heff_get(v_ending_242, LBL_end), 1, (V[]){v_ce_244}));
    V v_t_2435 = (g_prelude_2econcatList(v_t_2433, v_t_2434));
    V v_t_2436 = (g_prelude_2econcatList(v_t_2431, v_t_2435));
    V v_t_2437 = (g_prelude_2econcatList(v_t_2429, v_t_2436));
    V v_t_2438 = (g_prelude_2econcatList(v_t_2426, v_t_2437));
    V v_t_2439 = (g_prelude_2econcatList(v_t_2424, v_t_2438));
    V v_t_2440 = (g_prelude_2econcatList(v_t_2422, v_t_2439));
    V v_t_2441 = (g_prelude_2econcatList(v_t_2420, v_t_2440));
    V v_t_2442 = (g_prelude_2econcatList(v_t_2418, v_t_2441));
    V v_t_2443 = (g_prelude_2econcatList(v_t_2417, v_t_2442));
    V v_t_2444 = (g_prelude_2econcatList(v_t_2416, v_t_2443));
    V v_t_2445 = (g_prelude_2econcatList(v_t_2415, v_t_2444));
    V v_t_2446 = (g_prelude_2econcatList(v_t_2413, v_t_2445));
    V v_x2_2447 = (g_prelude_2econcatList(v_t_2410, v_t_2446));
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eemitc_2eprogramCE_str2);
    }
    case TAG_Cons: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_xs_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      return ({ V a_0 = v_x_2448; V a_1 = v_xs_2449; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2449); r_; });
    }
    default: return heff_nomatch(v_x2_2447);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2eemitc_2eceOf(V v_provs_240, V v_defs_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s668(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2econcatList(v_t_245, v_t_247));
  V v_t_249 = (g_prelude_2econcatList(heff_dup(g_heff_2eemitc_2eknownTags_get()), v_t_248));
  V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_249; V a_2 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2eemitc_2enumbered(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_field(v_names_242, 1);
    v_t_2413 = heff_dup(v_y_2412);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_provs_240));
  V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_prelude_2efoldl_24s669(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_xs_2416 = (g_prelude_2econcatList(v_t_2413, v_t_2415));
  V v_m_2417 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2416; V r_ = (g_prelude_2efoldl_24s606(a_0, a_1)); heff_drop(v_xs_2416); r_; });
  V v_t_2418 = ({ V a_0 = v_m_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2417); r_; });
  V v_t_2419 = (g_prelude_2emap_24s618(v_t_2418));
  V v_t_2420 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2419; V a_2 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2eemitc_2enumbered(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_prelude_2efoldl_24s667(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2422 = (g_heff_2eemit_2ebounceGo(v_defs_241, heff_dup(g_map_2eempty_get())));
  V v_t_2423 = (g_prelude_2efoldl_24s659(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2424 = (g_heff_2eemitc_2eborFix(v_defs_241, MK_INT(-1LL), v_t_2423));
  return heff_rec(11, shape_331_165_110_31_295_159_226_2_30_29_156, (V[]){v_t_2410, v_t_2420, v_t_2421, v_t_2422, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2424, heff_dup(g_map_2eempty_get())});
}
V g_heff_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eceOf(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eemitc_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2elastDotGo_entry, 3, 0};

V g_heff_2eemitc_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_k_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_at_242;
  }
  case TAG_False: {
    V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_k_240), heff_dup(v_i_241)), MK_INT(46LL));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_at_242);
      v_t_245 = heff_dup(v_i_241);
      break;
    }
    case TAG_False: {
      v_t_245 = v_at_242;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_k_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemitc_2elastDotGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2elastDotGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2epubLine_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 97, 116, 105, 99, 32, 86, 32, 103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemitc_2epubLine_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {95, 118, 97, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2epubLine_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemitc_2epubLine_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {95, 105, 110, 105, 116, 40, 118, 111, 105, 100, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2epubLine_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemitc_2epubLine_str5 = {{0x80000000u, K_STR, 0}, 22, 22, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40}};
Clo g_heff_2eemitc_2epubLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epubLine_entry, 1, 0};

V g_heff_2eemitc_2epubLine(V v_l_240) {
top: ;
  V v_t_241 = heff_strEq(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(11LL)), ((V)&g_heff_2eemitc_2epubLine_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_l_240)), MK_INT(5LL));
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), v_t_242, heff_strLength(heff_dup(v_l_240)));
    V v_t_244 = heff_strEq(v_t_243, ((V)&g_heff_2eemitc_2epubLine_str1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_strEq(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemitc_2epubLine_str2));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      }
      case TAG_False: {
        return v_l_240;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      V v_x3_246 = (g_prelude_2eindexFrom(((V)&g_heff_2eemitc_2epubLine_str3), heff_dup(v_l_240), MK_INT(0LL)));
      V v_x1_248;
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_246, 0ULL, 1);
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        V v_t_249 = heff_strEq(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemitc_2epubLine_str4));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
        }
        case TAG_False: {
          return v_l_240;
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_False: {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    V v_t_2410 = heff_strEq(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemitc_2epubLine_str5));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
    }
    case TAG_False: {
      return v_l_240;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemitc_2epubLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epubLine(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2epartHead_str0 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2eemitc_2epartHead_str1 = {{0x80000000u, K_STR, 0}, 25, 25, {86, 32, 104, 101, 102, 102, 95, 112, 101, 114, 102, 111, 114, 109, 40, 86, 32, 112, 44, 32, 86, 32, 107, 41, 59}};
Clo g_heff_2eemitc_2epartHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epartHead_entry, 5, 0};

V g_heff_2eemitc_2epartHead(V v_runtime_240, V v_ending_241, V v_ce_242, V v_s_243, V v_ems_244) {
top: ;
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartHead_str0), NTAG(TAG_Nil)});
  V v_t_246 = ({ V b_0 = heff_get(heff_dup(v_ce_242), LBL_tags); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247 = (g_prelude_2efilter_24s661(v_t_246));
  V v_t_248 = (g_prelude_2emap_24s660(v_t_247));
  V v_t_249 = ({ V b_0 = heff_get(v_ce_242, LBL_lbls); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2410 = (g_prelude_2emap_24s662(v_t_249));
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartHead_str1), NTAG(TAG_Nil)});
  V v_t_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_s_243), LBL_shapes)));
  V v_t_2414 = (g_prelude_2emap_24s663(v_t_2413));
  V v_xs_2415 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_s_243, LBL_prims)));
  V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2415));
  V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_prelude_2efoldl_24s665(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ems_244));
  V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_prelude_2efoldl_24s664(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_prelude_2emap_24s670(v_t_2419));
  V v_t_2421 = (g_prelude_2econcatList(v_t_2417, v_t_2420));
  V v_t_2422 = (g_prelude_2econcatList(v_t_2414, v_t_2421));
  V v_t_2423 = (g_prelude_2econcatList(v_t_2412, v_t_2422));
  V v_t_2424 = (g_prelude_2econcatList(v_t_2411, v_t_2423));
  V v_t_2425 = (g_prelude_2econcatList(v_t_2410, v_t_2424));
  V v_t_2426 = (g_prelude_2econcatList(v_t_248, v_t_2425));
  V v_t_2427 = (g_prelude_2econcatList(heff_get(v_ending_241, LBL_prefix), v_t_2426));
  return (g_prelude_2econcatList(v_t_245, v_t_2427));
}
V g_heff_2eemitc_2epartHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epartHead(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eownLines_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eownLines_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eownLines_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eownLines_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2eownLines_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2eownLines_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_o_247 = heff_strAppend(((V)&g_heff_2eemitc_2eownLines_str0), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_245), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eownLines_str1))));
    V v_x2_248 = (g_map_2elookup_24s8(v_o_247, v_strs_241));
    V v_t_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      v_t_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_o_2411 = heff_strAppend(((V)&g_heff_2eemitc_2eownLines_str2), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_245), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eownLines_str3))));
    V v_x2_2412 = (g_map_2elookup_24s8(v_o_2411, v_protos_242));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take_n(v_x2_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2415 = (g_prelude_2emap_24s672(v_t_2414));
    V v_t_2416 = (g_prelude_2efilter_24s674(heff_get(heff_dup(v_e_246), LBL_protos)));
    V v_t_2417 = (g_prelude_2emap_24s673(v_t_2416));
    V v_t_2418 = (g_prelude_2emap_24s672(heff_get(heff_dup(v_e_246), LBL_code)));
    V v_o_2419 = heff_strAppend(((V)&g_heff_2eemitc_2eownLines_str4), (g_heff_2eemitc_2emangleW(heff_get(heff_dup(v_d_245), LBL_key), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2eemitc_2eownLines_str5))));
    V v_x2_2420 = (g_map_2elookup_24s8(v_o_2419, v_lams_243));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      heff_take_n(v_x2_2420, 1ULL, 1);
      v_t_2422 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2423 = (g_prelude_2emap_24s672(v_t_2422));
    V v_t_2424 = (g_prelude_2econcatList(v_t_2418, v_t_2423));
    V v_t_2425 = (g_prelude_2econcatList(v_t_2417, v_t_2424));
    V v_t_2426 = (g_prelude_2econcatList(v_t_2415, v_t_2425));
    return (g_prelude_2econcatList(v_t_2410, v_t_2426));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2eownLines(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
Clo g_heff_2eemitc_2ezipDE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ezipDE_entry, 2, 0};

V g_heff_2eemitc_2ezipDE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_244 = heff_field(v_x2_241, 0);
      V v_es_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_d_242, v_e_244}), (g_heff_2eemitc_2ezipDE(v_ds_243, v_es_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ezipDE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ezipDE(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2emodulePart_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemitc_2emodulePart_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 99}};
V g_heff_2eemitc_2emodulePart_lam0(V self, V *args);
Clo g_heff_2eemitc_2emodulePart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2emodulePart_entry, 6, 0};

V g_heff_2eemitc_2emodulePart(V v_head_240, V v_s_241, V v_strs_242, V v_protos_243, V v_lams_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_m_246 = heff_field(v_x6_245, 0);
    V v_ps_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_247));
    V v_t_2412 = ({ V a_0 = heff_clo(g_heff_2eemitc_2emodulePart_lam0, 2, 4, (V[]){heff_dup(v_s_241), heff_dup(v_strs_242), heff_dup(v_protos_243), heff_dup(v_lams_244)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V v_x2_2413 = (g_prelude_2econcatList(v_head_240, v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eemitc_2emodulePart_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = v_x_2414; V a_1 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    return heff_tag_at(v_ru_24x6_245_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_m_246, ((V)&g_heff_2eemitc_2emodulePart_str1)), v_t_2416});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eemitc_2emodulePart_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemitc_2emodulePart(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
V g_heff_2eemitc_2emodulePart_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_s_241 = heff_env(self)[0];
  V v_strs_242 = heff_env(self)[1];
  V v_protos_243 = heff_env(self)[2];
  V v_lams_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_s_241; V a_1 = v_strs_242; V a_2 = v_protos_243; V a_3 = v_lams_244; V a_4 = v_x_2410; V r_ = (g_heff_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241); heff_drop(v_strs_242); heff_drop(v_protos_243); heff_drop(v_lams_244); heff_drop(v_x_2410); r_; });
  return (g_prelude_2econcatList(v_t_2411, v_acc_249));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemitc_2eentryPart_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {114, 117, 110, 36, 109, 97, 105, 110, 46, 99}};

static V g_heff_2eemitc_2eentryPart_val;
static int g_heff_2eemitc_2eentryPart_st;
static V g_heff_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2eemitc_2eentryPart_str0);
}
V g_heff_2eemitc_2eentryPart_get(void) {
  if (g_heff_2eemitc_2eentryPart_st == 2) return g_heff_2eemitc_2eentryPart_val;
  if (g_heff_2eemitc_2eentryPart_st == 1) heff_fail("defined by itself");
  g_heff_2eemitc_2eentryPart_st = 1;
  g_heff_2eemitc_2eentryPart_val = heff_tr(g_heff_2eemitc_2eentryPart_init());
  g_heff_2eemitc_2eentryPart_st = 2;
  return g_heff_2eemitc_2eentryPart_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2epartsWith_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2epartsWith_str1 = {{0x80000000u, K_STR, 0}, 17, 17, {35, 105, 110, 99, 108, 117, 100, 101, 32, 34, 104, 101, 102, 102, 46, 104, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemitc_2epartsWith_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2epartsWith_str3 = {{0x80000000u, K_STR, 0}, 17, 17, {35, 105, 110, 99, 108, 117, 100, 101, 32, 34, 104, 101, 102, 102, 46, 104, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemitc_2epartsWith_str4 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemitc_2epartsWith_str5 = {{0x80000000u, K_STR, 0}, 17, 17, {35, 100, 101, 102, 105, 110, 101, 32, 72, 69, 70, 70, 95, 80, 65, 82, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemitc_2epartsWith_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 46, 104}};
Clo g_heff_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_246 = heff_field(v_x6_245, 0);
    V v_s_247 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_x2_248 = (g_heff_2eemitc_2epartHead(v_runtime_240, heff_dup(v_ending_242), heff_dup(v_ce_244), heff_dup(v_s_247), heff_dup(v_ems_246)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2eemitc_2epartsWith_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = (g_prelude_2emap_24s246(v_provs_241));
    V v_t_2413 = heff_tr(heff_apply(heff_get(v_ending_242, LBL_end), 1, (V[]){v_ce_244}));
    V v_t_2414 = (g_prelude_2emap_24s672(v_t_2413));
    V v_x2_2415 = heff_tag_at(v_ru_24x6_245_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str1), (g_prelude_2econcatList(v_t_2412, v_t_2414))});
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2eemitc_2epartsWith_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = v_x_2416; V a_1 = v_xs_2417; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str3), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str5), v_t_2419})});
    V v_t_2421 = (g_prelude_2efoldl_24s671(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_strs)));
    V v_t_2422 = (g_prelude_2efoldl_24s671(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_protos)));
    V v_t_2423 = (g_prelude_2efoldl_24s671(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_247), LBL_lams)));
    V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2emodulePart_clo), 5, (V[]){v_t_2420, v_s_247, v_t_2421, v_t_2422, v_t_2423}));
    V v_ps_2425 = (g_heff_2eemitc_2ezipDE(v_defs_243, v_ems_246));
    V v_t_2426 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_2425));
    V v_m_2427 = (g_prelude_2efoldl_24s675(heff_dup(g_map_2eempty_get()), v_t_2426));
    V v_t_2428 = ({ V a_0 = v_m_2427; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2427); r_; });
    V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2eemitc_2eentryPart_get()), v_t_2418}), (g_prelude_2emap(v_t_2424, v_t_2428))});
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eemitc_2epartsWith_str6), v_t_2411}), v_t_2429});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2eemitc_2eprogramParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eprogramParts_entry, 4, 0};

V g_heff_2eemitc_2eprogramParts(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243) {
top: ;
  V v_es_244 = (g_prelude_2emap_24s676(heff_dup(v_defs_243)));
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_es_244));
  V v_t_247 = (g_prelude_2efoldl_24s619(v_t_245, v_t_246));
  V v_ce_248 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_defs_243; V a_2 = v_t_247; V r_ = (g_heff_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_249 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_248)}));
  V v_t_2410 = (g_heff_2eemitc_2etraverseC(v_t_249, heff_dup(v_defs_243)));
  V v_t_2411 = heff_tr(heff_apply(v_t_2410, 1, (V[]){heff_dup(g_heff_2eemitc_2eemptyCS_get())}));
  return (g_heff_2eemitc_2epartsWith(v_runtime_240, v_provs_241, v_ending_242, v_defs_243, v_ce_248, v_t_2411));
}
V g_heff_2eemitc_2eprogramParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eprogramParts(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eemitc_2eoutputOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2eoutputOf_entry, 4, 0};

V g_heff_2eemitc_2eoutputOf(V v_runtime_240, V v_provs_241, V v_ending_242, V v_l_243) {
top: ;
  V v_defs_244 = heff_get(heff_dup(v_l_243), LBL_defs);
  V v_es_245 = (g_prelude_2emap_24s676(heff_dup(v_defs_244)));
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_es_245));
  V v_names_248 = (g_prelude_2efoldl_24s619(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = v_defs_244; V a_2 = v_names_248; V r_ = (g_heff_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_248); r_; });
  V v_t_2410 = (g_heff_2eemitc_2eprogramCE(v_runtime_240, v_provs_241, v_ending_242, v_defs_244, v_t_249));
  return heff_rec(2, shape_311_89, (V[]){v_t_2410, heff_get(v_l_243, LBL_errors)});
}
V g_heff_2eemitc_2eoutputOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2eoutputOf(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eemitc_2echeckOut_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {35, 100, 101, 102, 105, 110, 101, 32, 72, 69, 70, 70, 95, 67, 72, 69, 67, 75}};
Clo g_heff_2eemitc_2echeckOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2echeckOut_entry, 3, 0};

V g_heff_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemitc_2echeckOut_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2echeckEnd_clo), 2, (V[]){v_exports_241, heff_get(heff_dup(v_l_242), LBL_defs)}));
  V v_ending_245 = heff_rec(2, shape_253_83, (V[]){v_t_243, v_t_244});
  V v_defs_246 = heff_get(heff_dup(v_l_242), LBL_defs);
  V v_es_247 = (g_prelude_2emap_24s676(heff_dup(v_defs_246)));
  V v_t_248 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_es_247));
  V v_names_2410 = (g_prelude_2efoldl_24s619(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_defs_246; V a_2 = v_names_2410; V r_ = (g_heff_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_2410); r_; });
  V v_t_2412 = (g_heff_2eemitc_2eprogramCE(v_runtime_240, NTAG(TAG_Nil), v_ending_245, v_defs_246, v_t_2411));
  return heff_rec(2, shape_311_89, (V[]){v_t_2412, heff_get(v_l_242, LBL_errors)});
}
V g_heff_2eemitc_2echeckOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2echeckOut(a[0], a[1], a[2]);
}
Clo g_heff_2eemitc_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemitc_2ecatMaybesC_entry, 1, 0};

V g_heff_2eemitc_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eemitc_2ecatMaybesC(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemitc_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemitc_2ecatMaybesC(a[0]);
}