// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_fixed 298804110
#define LBL_global 704121550
#define LBL_local 304503685
#define LBL_op 10312
#define LBL_syntax 1059664654
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_heff_2ecompile_2einterp_2eevalIn(V, V, V);
V g_heff_2ecompile_2einterp_2eevalIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalIn_clo;
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get(void);
V g_heff_2ecompile_2einterp_2ef32V2(V);
V g_heff_2ecompile_2einterp_2ef32V2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ef32V2_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2efixedInt1(V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt1_clo;
V g_heff_2ecompile_2einterp_2efixedInt2(V, V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt2_clo;
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloat32V(V);
V g_heff_2ecompile_2einterp_2efloat32V_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat32V_clo;
V g_heff_2ecompile_2einterp_2eglobalEnvGo(V, V);
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_24dps_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
HEFF_LIT(g_heff_2ecompile_2einterp_2enotARune_str0, 38, "a primitive given what is not a `Rune`");

static V g_heff_2ecompile_2einterp_2enotARune_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotARune_st;
static V g_heff_2ecompile_2einterp_2enotARune_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotARune_str0)});
}
V g_heff_2ecompile_2einterp_2enotARune_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotARune_st)) return g_heff_2ecompile_2einterp_2enotARune_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotARune_val, &g_heff_2ecompile_2einterp_2enotARune_st, g_heff_2ecompile_2einterp_2enotARune_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotBytes_str0, 37, "a primitive given what is not `Bytes`");

static V g_heff_2ecompile_2einterp_2enotBytes_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotBytes_st;
static V g_heff_2ecompile_2einterp_2enotBytes_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotBytes_str0)});
}
V g_heff_2ecompile_2einterp_2enotBytes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotBytes_st)) return g_heff_2ecompile_2einterp_2enotBytes_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotBytes_val, &g_heff_2ecompile_2einterp_2enotBytes_st, g_heff_2ecompile_2einterp_2enotBytes_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat32_str0, 41, "a primitive given what is not a `Float32`");

static V g_heff_2ecompile_2einterp_2enotAFloat32_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat32_st;
static V g_heff_2ecompile_2einterp_2enotAFloat32_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat32_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat32_st)) return g_heff_2ecompile_2einterp_2enotAFloat32_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat32_val, &g_heff_2ecompile_2einterp_2enotAFloat32_st, g_heff_2ecompile_2einterp_2enotAFloat32_init);
}
V g_heff_2ecompile_2einterp_2eint2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eint2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eint2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eint2(a[0]);
}
V g_heff_2ecompile_2einterp_2eint2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2413 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2418 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2413;
          args[1] = v_b_2418;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2eint2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2ecompile_2einterp_2ebytes2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ebytes2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2ebytes2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytes2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2ebytes2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ebytes2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebytes2(a[0]);
}
V g_heff_2ecompile_2einterp_2ebytes2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VBytes: {
        V v_a_2419 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VBytes: {
          V v_b_2430 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2419;
          args[1] = v_b_2430;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2ebytes2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ebytes2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2ecompile_2einterp_2esetAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2esetAt_24dps_entry, 4, 0};

V g_heff_2ecompile_2einterp_2esetAt_24dps(V v_x1_240, V v_i_241, V v_x_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x1_240, 0);
    V v_ys_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      heff_drop(v_y_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_ys_245}));
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_245;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_x_242;
      V t_3 = v_cell_247;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_x_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2esetAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2esetAt_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_val, &g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_st, g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) + heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_val, &g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_st, g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) - heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_val, &g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_st, g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) * heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str0, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str1, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str2, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str3, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str4, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str5, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str6, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str7, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str8, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str9, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str10, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str11, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str12, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str13, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str14, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str15, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str16, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str17, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str18, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str19, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str20, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str21, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str22, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str23, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str24, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str25, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str26, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str27, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str28, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str29, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str30, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str31, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str32, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str33, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str34, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str35, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str36, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str37, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str38, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str39, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str40, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str41, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str42, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str43, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str44, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str45, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str46, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str47, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str48, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str49, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str50, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str51, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str52, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str53, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str54, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str55, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str56, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str57, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str58, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str59, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str60, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str61, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str62, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str63, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str64, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str65, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str66, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str67, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str68, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str69, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str70, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str71, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str72, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str73, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str74, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str75, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str76, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str77, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str78, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str79, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str80, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str81, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str82, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str83, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str84, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str85, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str86, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str87, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str88, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str89, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str90, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str91, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str92, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str93, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str94, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str95, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str96, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str97, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str98, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str99, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str100, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str101, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str102, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str103, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str104, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str105, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str106, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str107, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str108, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str109, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str110, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str111, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str112, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str113, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str114, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str115, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str116, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str117, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str118, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str119, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str120, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str121, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str122, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str123, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str124, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str125, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str126, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str127, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str128, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str129, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str130, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str131, 20, "no primitive float32");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str132, 3, "Add");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str133, 3, "Sub");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str134, 3, "Mul");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str135, 3, "Div");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str136, 3, "Rem");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str137, 2, "Eq");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str138, 2, "Lt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str139, 2, "Le");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str140, 3, "And");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str141, 2, "Or");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str142, 3, "Xor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str143, 3, "Shl");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str144, 3, "Shr");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str145, 4, "Show");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str146, 7, "FromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str147, 5, "ToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str148, 4, "Sqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str149, 9, "FromFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str150, 7, "ToFloat");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str151, 5, "Floor");
HEFF_LIT(g_heff_2ecompile_2einterp_2efloat32V_str152, 20, "no primitive float32");
V g_heff_2ecompile_2einterp_2efloat32V_lam0(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam4(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam5(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam6(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam7(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam8(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam11(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat32V_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2efloat32V_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat32V_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_lam14, 2, 0};
Clo g_heff_2ecompile_2einterp_2efloat32V_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat32V_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efloat32V(V v_op_240) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get());
  }
  case TAG_OpSub: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s527698166x66844294_get());
  }
  case TAG_OpMul: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get());
  }
  case TAG_OpDiv: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get());
  }
  case TAG_OpRem: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam0, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ef32V2(((V)&g_heff_2ecompile_2einterp_2efloat32V_lam1_clo));
  }
  case TAG_OpLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ef32V2(((V)&g_heff_2ecompile_2einterp_2efloat32V_lam2_clo));
  }
  case TAG_OpLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ef32V2(((V)&g_heff_2ecompile_2einterp_2efloat32V_lam3_clo));
  }
  case TAG_OpAnd: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam4, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpOr: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam5, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpXor: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam6, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpShl: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam7, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpShr: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam8, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpShow: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam9_clo)});
  }
  case TAG_OpFromInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam10_clo)});
  }
  case TAG_OpToInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat32V_lam11, 2, 1, (V[]){heff_dup(v_op_240)})});
  }
  case TAG_OpSqrt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam12_clo)});
  }
  case TAG_OpFromFloat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam13_clo)});
  }
  case TAG_OpToFloat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat32V_lam14_clo)});
  }
  case TAG_OpFloor: {
    return heff_dup(g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get());
  }
  default: return heff_nomatch(v_op_240);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2efloat32V(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2efloat32V_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  heff_drop(v_a_242);
  V v_t_243;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str0);
    break;
  }
  case TAG_OpSub: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str1);
    break;
  }
  case TAG_OpMul: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str2);
    break;
  }
  case TAG_OpDiv: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str3);
    break;
  }
  case TAG_OpRem: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str4);
    break;
  }
  case TAG_OpEq: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str5);
    break;
  }
  case TAG_OpLt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str6);
    break;
  }
  case TAG_OpLe: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str7);
    break;
  }
  case TAG_OpAnd: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str8);
    break;
  }
  case TAG_OpOr: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str9);
    break;
  }
  case TAG_OpXor: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str10);
    break;
  }
  case TAG_OpShl: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str11);
    break;
  }
  case TAG_OpShr: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str12);
    break;
  }
  case TAG_OpShow: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str13);
    break;
  }
  case TAG_OpFromInt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str14);
    break;
  }
  case TAG_OpToInt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str15);
    break;
  }
  case TAG_OpSqrt: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str16);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str17);
    break;
  }
  case TAG_OpToFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str18);
    break;
  }
  case TAG_OpFloor: {
    v_t_243 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str19);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str20), v_t_243)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam1(V self, V *args) {
  V v_box_24a_244 = args[0];
  V v_box_24b_245 = args[1];
  float v_a_244 = heff_unbox_f32(v_box_24a_244);
  float v_b_245 = heff_unbox_f32(v_box_24b_245);
  V v_t_247;
  if ((v_a_244 == v_b_245)) {
    v_t_247 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str21);
  } else {
    v_t_247 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str22);
  }
  V v_t_248 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam2(V self, V *args) {
  V v_box_24a_249 = args[0];
  V v_box_24b_2410 = args[1];
  float v_a_249 = heff_unbox_f32(v_box_24a_249);
  float v_b_2410 = heff_unbox_f32(v_box_24b_2410);
  V v_t_2412;
  if ((v_a_249 < v_b_2410)) {
    v_t_2412 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str23);
  } else {
    v_t_2412 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str24);
  }
  V v_t_2413 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam3(V self, V *args) {
  V v_box_24a_2414 = args[0];
  V v_box_24b_2415 = args[1];
  float v_a_2414 = heff_unbox_f32(v_box_24a_2414);
  float v_b_2415 = heff_unbox_f32(v_box_24b_2415);
  V v_t_2417;
  if ((v_a_2414 <= v_b_2415)) {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str25);
  } else {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str26);
  }
  V v_t_2418 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2418});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam4(V self, V *args) {
  V v_d_2419 = args[0];
  V v_a_2420 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2419);
  heff_drop(v_a_2420);
  V v_t_2421;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str27);
    break;
  }
  case TAG_OpSub: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str28);
    break;
  }
  case TAG_OpMul: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str29);
    break;
  }
  case TAG_OpDiv: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str30);
    break;
  }
  case TAG_OpRem: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str31);
    break;
  }
  case TAG_OpEq: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str32);
    break;
  }
  case TAG_OpLt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str33);
    break;
  }
  case TAG_OpLe: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str34);
    break;
  }
  case TAG_OpAnd: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str35);
    break;
  }
  case TAG_OpOr: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str36);
    break;
  }
  case TAG_OpXor: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str37);
    break;
  }
  case TAG_OpShl: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str38);
    break;
  }
  case TAG_OpShr: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str39);
    break;
  }
  case TAG_OpShow: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str40);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str41);
    break;
  }
  case TAG_OpToInt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str42);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str43);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str44);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str45);
    break;
  }
  case TAG_OpFloor: {
    v_t_2421 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str46);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str47), v_t_2421)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam5(V self, V *args) {
  V v_d_2422 = args[0];
  V v_a_2423 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2422);
  heff_drop(v_a_2423);
  V v_t_2424;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str48);
    break;
  }
  case TAG_OpSub: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str49);
    break;
  }
  case TAG_OpMul: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str50);
    break;
  }
  case TAG_OpDiv: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str51);
    break;
  }
  case TAG_OpRem: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str52);
    break;
  }
  case TAG_OpEq: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str53);
    break;
  }
  case TAG_OpLt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str54);
    break;
  }
  case TAG_OpLe: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str55);
    break;
  }
  case TAG_OpAnd: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str56);
    break;
  }
  case TAG_OpOr: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str57);
    break;
  }
  case TAG_OpXor: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str58);
    break;
  }
  case TAG_OpShl: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str59);
    break;
  }
  case TAG_OpShr: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str60);
    break;
  }
  case TAG_OpShow: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str61);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str62);
    break;
  }
  case TAG_OpToInt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str63);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str64);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str65);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str66);
    break;
  }
  case TAG_OpFloor: {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str67);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str68), v_t_2424)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam6(V self, V *args) {
  V v_d_2425 = args[0];
  V v_a_2426 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2425);
  heff_drop(v_a_2426);
  V v_t_2427;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str69);
    break;
  }
  case TAG_OpSub: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str70);
    break;
  }
  case TAG_OpMul: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str71);
    break;
  }
  case TAG_OpDiv: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str72);
    break;
  }
  case TAG_OpRem: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str73);
    break;
  }
  case TAG_OpEq: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str74);
    break;
  }
  case TAG_OpLt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str75);
    break;
  }
  case TAG_OpLe: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str76);
    break;
  }
  case TAG_OpAnd: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str77);
    break;
  }
  case TAG_OpOr: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str78);
    break;
  }
  case TAG_OpXor: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str79);
    break;
  }
  case TAG_OpShl: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str80);
    break;
  }
  case TAG_OpShr: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str81);
    break;
  }
  case TAG_OpShow: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str82);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str83);
    break;
  }
  case TAG_OpToInt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str84);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str85);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str86);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str87);
    break;
  }
  case TAG_OpFloor: {
    v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str88);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str89), v_t_2427)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam7(V self, V *args) {
  V v_d_2428 = args[0];
  V v_a_2429 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2428);
  heff_drop(v_a_2429);
  V v_t_2430;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str90);
    break;
  }
  case TAG_OpSub: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str91);
    break;
  }
  case TAG_OpMul: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str92);
    break;
  }
  case TAG_OpDiv: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str93);
    break;
  }
  case TAG_OpRem: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str94);
    break;
  }
  case TAG_OpEq: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str95);
    break;
  }
  case TAG_OpLt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str96);
    break;
  }
  case TAG_OpLe: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str97);
    break;
  }
  case TAG_OpAnd: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str98);
    break;
  }
  case TAG_OpOr: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str99);
    break;
  }
  case TAG_OpXor: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str100);
    break;
  }
  case TAG_OpShl: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str101);
    break;
  }
  case TAG_OpShr: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str102);
    break;
  }
  case TAG_OpShow: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str103);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str104);
    break;
  }
  case TAG_OpToInt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str105);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str106);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str107);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str108);
    break;
  }
  case TAG_OpFloor: {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str109);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str110), v_t_2430)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam8(V self, V *args) {
  V v_d_2431 = args[0];
  V v_a_2432 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2431);
  heff_drop(v_a_2432);
  V v_t_2433;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str111);
    break;
  }
  case TAG_OpSub: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str112);
    break;
  }
  case TAG_OpMul: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str113);
    break;
  }
  case TAG_OpDiv: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str114);
    break;
  }
  case TAG_OpRem: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str115);
    break;
  }
  case TAG_OpEq: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str116);
    break;
  }
  case TAG_OpLt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str117);
    break;
  }
  case TAG_OpLe: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str118);
    break;
  }
  case TAG_OpAnd: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str119);
    break;
  }
  case TAG_OpOr: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str120);
    break;
  }
  case TAG_OpXor: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str121);
    break;
  }
  case TAG_OpShl: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str122);
    break;
  }
  case TAG_OpShr: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str123);
    break;
  }
  case TAG_OpShow: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str124);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str125);
    break;
  }
  case TAG_OpToInt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str126);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str127);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str128);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str129);
    break;
  }
  case TAG_OpFloor: {
    v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str130);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str131), v_t_2433)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam9(V self, V *args) {
  V v_d_2434 = args[0];
  V v_a_2435 = args[1];
  V v_x1_2436 = heff_tr(heff_call(v_a_2435, 1, (V[]){v_d_2434}));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Ok: {
    V v_v_2437 = heff_field(v_x1_2436, 0);
    V v_ru_24x1_2436_24Ok = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
    switch (heff_tag_of(v_v_2437)) {
    case TAG_VFun: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2437, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_2444 = heff_field(v_v_2437, 0);
      V v_ru_24v_2437_24VFloat32 = heff_take_reuse_n(v_v_2437, 1ULL, 1);
      V v_t_2445 = heff_tag_at_n(v_ru_24x1_2436_24Ok, TAG_VStr, 1, (V[]){heff_float32Show(v_a_2444)});
      return heff_tag_at_n(v_ru_24v_2437_24VFloat32, TAG_Ok, 1, (V[]){v_t_2445});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2437, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_2437);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2450 = heff_field(v_x1_2436, 0);
    V v_ru_24x1_2436_24Bug = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2436_24Bug, TAG_Bug, 1, (V[]){v_what_2450});
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam10(V self, V *args) {
  V v_d_2451 = args[0];
  V v_a_2452 = args[1];
  V v_x1_2453 = heff_tr(heff_call(v_a_2452, 1, (V[]){v_d_2451}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_Ok: {
    V v_v_2454 = heff_field(v_x1_2453, 0);
    V v_ru_24x1_2453_24Ok = heff_take_reuse_n(v_x1_2453, 1ULL, 1);
    switch (heff_tag_of(v_v_2454)) {
    case TAG_VFun: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2454, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2459 = heff_field(v_v_2454, 0);
      V v_ru_24v_2454_24VInt = heff_take_reuse_n(v_v_2454, 1ULL, 1);
      V v_t_2460 = heff_tag_at_n(v_ru_24x1_2453_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(heff_from_int_f32(v_a_2459))});
      return heff_tag_at_n(v_ru_24v_2454_24VInt, TAG_Ok, 1, (V[]){v_t_2460});
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2454, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2453_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2454);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2467 = heff_field(v_x1_2453, 0);
    V v_ru_24x1_2453_24Bug = heff_take_reuse_n(v_x1_2453, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2453_24Bug, TAG_Bug, 1, (V[]){v_what_2467});
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam11(V self, V *args) {
  V v_d_2468 = args[0];
  V v_a_2469 = args[1];
  V v_op_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2468);
  heff_drop(v_a_2469);
  V v_t_2470;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str132);
    break;
  }
  case TAG_OpSub: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str133);
    break;
  }
  case TAG_OpMul: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str134);
    break;
  }
  case TAG_OpDiv: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str135);
    break;
  }
  case TAG_OpRem: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str136);
    break;
  }
  case TAG_OpEq: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str137);
    break;
  }
  case TAG_OpLt: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str138);
    break;
  }
  case TAG_OpLe: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str139);
    break;
  }
  case TAG_OpAnd: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str140);
    break;
  }
  case TAG_OpOr: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str141);
    break;
  }
  case TAG_OpXor: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str142);
    break;
  }
  case TAG_OpShl: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str143);
    break;
  }
  case TAG_OpShr: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str144);
    break;
  }
  case TAG_OpShow: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str145);
    break;
  }
  case TAG_OpFromInt: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str146);
    break;
  }
  case TAG_OpToInt: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str147);
    break;
  }
  case TAG_OpSqrt: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str148);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str149);
    break;
  }
  case TAG_OpToFloat: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str150);
    break;
  }
  case TAG_OpFloor: {
    v_t_2470 = ((V)&g_heff_2ecompile_2einterp_2efloat32V_str151);
    break;
  }
  default: heff_nomatch(v_op_240);
  }
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efloat32V_str152), v_t_2470)});
}
V g_heff_2ecompile_2einterp_2efloat32V_lam12(V self, V *args) {
  V v_d_2471 = args[0];
  V v_a_2472 = args[1];
  V v_x1_2473 = heff_tr(heff_call(v_a_2472, 1, (V[]){v_d_2471}));
  switch (heff_tag_of(v_x1_2473)) {
  case TAG_Ok: {
    V v_v_2474 = heff_field(v_x1_2473, 0);
    V v_ru_24x1_2473_24Ok = heff_take_reuse_n(v_x1_2473, 1ULL, 1);
    switch (heff_tag_of(v_v_2474)) {
    case TAG_VFun: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2474, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_2481 = heff_field(v_v_2474, 0);
      V v_ru_24v_2474_24VFloat32 = heff_take_reuse_n(v_v_2474, 1ULL, 1);
      V v_t_2482 = heff_tag_at_n(v_ru_24x1_2473_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(sqrtf(heff_unbox_f32(v_a_2481)))});
      return heff_tag_at_n(v_ru_24v_2474_24VFloat32, TAG_Ok, 1, (V[]){v_t_2482});
    }
    case TAG_VStr: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2474, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2473_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_2474);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2487 = heff_field(v_x1_2473, 0);
    V v_ru_24x1_2473_24Bug = heff_take_reuse_n(v_x1_2473, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2473_24Bug, TAG_Bug, 1, (V[]){v_what_2487});
  }
  default: return heff_nomatch(v_x1_2473);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam13(V self, V *args) {
  V v_d_2488 = args[0];
  V v_a_2489 = args[1];
  V v_x1_2490 = heff_tr(heff_call(v_a_2489, 1, (V[]){v_d_2488}));
  switch (heff_tag_of(v_x1_2490)) {
  case TAG_Ok: {
    V v_v_2491 = heff_field(v_x1_2490, 0);
    V v_ru_24x1_2490_24Ok = heff_take_reuse_n(v_x1_2490, 1ULL, 1);
    switch (heff_tag_of(v_v_2491)) {
    case TAG_VFun: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2491, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_2497 = heff_field(v_v_2491, 0);
      V v_ru_24v_2491_24VFloat = heff_take_reuse_n(v_v_2491, 1ULL, 1);
      V v_t_2498 = heff_tag_at_n(v_ru_24x1_2490_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)heff_unbox_f64(v_a_2497)))});
      return heff_tag_at_n(v_ru_24v_2491_24VFloat, TAG_Ok, 1, (V[]){v_t_2498});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2491, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_2491);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24104 = heff_field(v_x1_2490, 0);
    V v_ru_24x1_2490_24Bug = heff_take_reuse_n(v_x1_2490, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2490_24Bug, TAG_Bug, 1, (V[]){v_what_24104});
  }
  default: return heff_nomatch(v_x1_2490);
  }
}
V g_heff_2ecompile_2einterp_2efloat32V_lam14(V self, V *args) {
  V v_d_24105 = args[0];
  V v_a_24106 = args[1];
  V v_x1_24107 = heff_tr(heff_call(v_a_24106, 1, (V[]){v_d_24105}));
  switch (heff_tag_of(v_x1_24107)) {
  case TAG_Ok: {
    V v_v_24108 = heff_field(v_x1_24107, 0);
    V v_ru_24x1_24107_24Ok = heff_take_reuse_n(v_x1_24107, 1ULL, 1);
    switch (heff_tag_of(v_v_24108)) {
    case TAG_VFun: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24108, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_24115 = heff_field(v_v_24108, 0);
      V v_ru_24v_24108_24VFloat32 = heff_take_reuse_n(v_v_24108, 1ULL, 1);
      V v_t_24116 = heff_tag_at_n(v_ru_24x1_24107_24Ok, TAG_VFloat, 1, (V[]){heff_box_f64(((double)heff_unbox_f32(v_a_24115)))});
      return heff_tag_at_n(v_ru_24v_24108_24VFloat32, TAG_Ok, 1, (V[]){v_t_24116});
    }
    case TAG_VStr: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_24108);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24121 = heff_field(v_x1_24107, 0);
    V v_ru_24x1_24107_24Bug = heff_take_reuse_n(v_x1_24107, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24107_24Bug, TAG_Bug, 1, (V[]){v_what_24121});
  }
  default: return heff_nomatch(v_x1_24107);
  }
}
V g_heff_2ecompile_2einterp_2efixedPrimV_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixedPrimV_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efixedPrimV(V v_p_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_p_240, 0));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    return ({ V b_0 = heff_get_n(v_p_240, 1, 2); V r_ = (g_heff_2ecompile_2einterp_2efloat32V(b_0)); heff_drop(b_0); r_; });
  } else {
    heff_drop(v_t_242);
    V v_t_243 = heff_dup(heff_rfield(v_p_240, 1));
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpSub: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpMul: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpDiv: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpRem: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpEq: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpLt: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpLe: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpAnd: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpOr: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpXor: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpShl: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpShr: {
      v_t_244 = MK_INT(2LL);
      break;
    }
    case TAG_OpShow: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpFromInt: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpToInt: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpSqrt: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpToFloat: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    case TAG_OpFloor: {
      v_t_244 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    if (heff_intEq_c(v_t_244, MK_INT(2LL))) {
      V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2einterp_2efixedInt2_clo), 2, (V[]){heff_take_field(v_p_240, 0), heff_get_n(v_p_240, 1, 2)}));
      HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(v_t_246);
    } else {
      return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efixedPrimV_lam0, 2, 1, (V[]){v_p_240})});
    }
  }
}
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixedPrimV(a[0]);
}
V g_heff_2ecompile_2einterp_2efixedPrimV_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_a_248 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_a_248, 1, (V[]){v_d_247}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Ok: {
    V v_v_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    switch (heff_tag_of(v_v_2410)) {
    case TAG_VFun: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2410, 0ULL, 2);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2415 = heff_field(v_v_2410, 0);
      heff_take_n(v_v_2410, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efixedInt1(heff_dup(heff_rfield(v_p_240, 0)), heff_get_n(v_p_240, 1, 2), v_a_2415));
    }
    case TAG_VFloat: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2410);
    }
  }
  case TAG_Abn: {
    heff_drop_rec(v_p_240, 2);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop_rec(v_p_240, 2);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2422 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Bug = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    heff_drop_rec(v_p_240, 2);
    return heff_tag_at_n(v_ru_24x1_249_24Bug, TAG_Bug, 1, (V[]){v_what_2422});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_st;
static V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_st)) return g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_val, &g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_st, g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intMul(v_a_2412, v_b_2417)});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_st)) return g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_val, &g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_st, g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_box_f64((heff_unbox_f64(v_a_2413) - heff_unbox_f64(v_b_2419)))});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_st;
static V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_st)) return g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_val;
  return heff_global(&g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_val, &g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_st, g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_init);
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VStr: {
        V v_a_2415 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VStr: {
          V v_b_2423 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2424 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VStr, 1, (V[]){heff_strAppend(v_a_2415, v_b_2423)});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2424});
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str0, 4, "#fun");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str1, 6, "#value");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str2, 6, "#value");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str4, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str5, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str6, 1, "'");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str7, 1, "'");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str8, 6, "#value");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str10, 2, "b\"");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str11, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2einterp_2escalarV_str12, 7, "#erased");
Clo g_heff_2ecompile_2einterp_2escalarV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2escalarV_entry, 1, 0};

V g_heff_2ecompile_2einterp_2escalarV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str0);
  }
  case TAG_VCons: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str1);
  }
  case TAG_VTag: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str2);
  }
  case TAG_VInt: {
    V v_i_245 = heff_field(v_x1_240, 0);
    return heff_intShow(heff_dup(v_i_245));
  }
  case TAG_VFloat: {
    V v_x_246 = heff_field(v_x1_240, 0);
    return heff_floatShow(heff_dup(v_x_246));
  }
  case TAG_VFloat32: {
    V v_x_247 = heff_field(v_x1_240, 0);
    return heff_float32Show(heff_dup(v_x_247));
  }
  case TAG_VStr: {
    V v_s_248 = heff_field(v_x1_240, 0);
    V v_t_249 = (g_heff_2eutil_2erune_2equoteGo(heff_dup(v_s_248), MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2escalarV_str3)));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str4), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2einterp_2escalarV_str5)));
  }
  case TAG_VRune: {
    V v_c_2410 = heff_field(v_x1_240, 0);
    V v_t_2411 = (g_heff_2eutil_2erune_2equoted(heff_dup(v_c_2410)));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str6), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2einterp_2escalarV_str7)));
  }
  case TAG_VArr: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str8);
  }
  case TAG_VBytes: {
    V v_s_2413 = heff_field(v_x1_240, 0);
    V v_t_2414 = (g_heff_2eutil_2erune_2equoteBytesGo(heff_dup(v_s_2413), MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2escalarV_str9)));
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2escalarV_str10), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2einterp_2escalarV_str11)));
  }
  case TAG_VErased: {
    return ((V)&g_heff_2ecompile_2einterp_2escalarV_str12);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2escalarV(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2efixThunk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixThunk_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efixThunk(V v_g_240, V v_t_241, V v_d_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2einterp_2efixThunk_clo), 2, (V[]){heff_dup(v_g_240), heff_dup(v_t_241)}));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  HEFF_LAST return g_heff_2ecompile_2einterp_2eevalIn(heff_intAdd(v_d_242, MK_INT(1LL)), heff_rec_n(2, shape_local__global, (V[]){v_t_244, v_g_240}), v_t_241);
}
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixThunk(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry, 4, 0};

V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V v_wanted_240, V v_ge_241, V v_x3_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_wanted_240);
    heff_drop(v_ge_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_entry_247 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_r_248 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_241), heff_get_n(v_entry_247, 0, 4), MK_INT(0LL)));
      V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_246), heff_clo_n(g_heff_2ecompile_2einterp_2eevalGlobalsGo_lam0, 1, 1, (V[]){heff_dup(v_r_248)}), v_ge_241));
      V v_t_2411 = heff_tr(heff_call(heff_dup(v_wanted_240), 1, (V[]){heff_dup(v_x_246)}));
      V v_t_2415;
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2414;
        switch (heff_tag_of(v_r_248)) {
        case TAG_Ok: {
          V v_v_2412 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Ok = heff_take_reuse_n(v_r_248, 1ULL, 1);
          v_t_2414 = heff_tag_at_n(v_ru_24r_248_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2412});
          break;
        }
        case TAG_Abn: {
          v_t_2414 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2414 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_2413 = heff_field(v_r_248, 0);
          V v_ru_24r_248_24Bug = heff_take_reuse_n(v_r_248, 1ULL, 1);
          v_t_2414 = heff_tag_at_n(v_ru_24r_248_24Bug, TAG_RBug, 1, (V[]){v_what_2413});
          break;
        }
        default: heff_nomatch(v_r_248);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_t_2414}), v_acc_243});
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x_246);
        heff_drop(v_r_248);
        heff_drop(v_t_2411);
        v_t_2415 = v_acc_243;
      }
      V t_0 = v_wanted_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_245;
      V t_3 = v_t_2415;
      v_wanted_240 = t_0;
      v_ge_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalGlobalsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_249);
  return v_r_248;
}
V g_heff_2ecompile_2einterp_2eglobalEnvGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eglobalEnvGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eglobalEnvGo(V v_ge_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ge_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_entry_245 = heff_field(v_x21_242, 1);
      V v_r_246 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_240), heff_dup(heff_rfield(v_entry_245, 0)), MK_INT(0LL)));
      V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_244), heff_clo_n(g_heff_2ecompile_2einterp_2eglobalEnvGo_lam0, 1, 1, (V[]){v_r_246}), v_ge_240));
      V t_0 = v_t_248;
      V t_1 = v_rest_243;
      v_ge_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eglobalEnvGo(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2einterp_2eglobalEnvGo_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_r_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_247);
  return v_r_246;
}