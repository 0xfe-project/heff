// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_fixed 298804110
#define LBL_global 704121550
#define LBL_local 304503685
#define LBL_op 10312
#define LBL_syntax 1059664654
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
V g_heff_2ecompile_2einterp_2ebinaryExponent_w(double, V);
V g_heff_2ecompile_2einterp_2ebinaryExponent(V, V);
V g_heff_2ecompile_2einterp_2ebinaryExponent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebinaryExponent_clo;
V g_heff_2ecompile_2einterp_2ebitsPush(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsPush_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsPush_clo;
V g_heff_2ecompile_2einterp_2ebitsSet(V);
V g_heff_2ecompile_2einterp_2ebitsSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsSet_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_clo;
V g_heff_2ecompile_2einterp_2eevalIn(V, V, V);
V g_heff_2ecompile_2einterp_2eevalIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalIn_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get(void);
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get(void);
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2efixedInt1(V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt1_clo;
V g_heff_2ecompile_2einterp_2efixedInt2(V, V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt2_clo;
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloat32V(V);
V g_heff_2ecompile_2einterp_2efloat32V_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat32V_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_w(V, V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitudeOf(V, V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
double g_heff_2ecompile_2einterp_2escaledF_w(double, V);
V g_heff_2ecompile_2einterp_2escaledF(V, V);
V g_heff_2ecompile_2einterp_2escaledF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escaledF_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2estrTake2(V, V, V);
V g_heff_2ecompile_2einterp_2estrTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estrTake2_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_std_2emap_2einsert_24s1733258119x1737094492(V, V, V);
V g_std_2emap_2einsert_24s1733258119x1737094492_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1733258119x1737094492_clo;
HEFF_LIT(g_heff_2ecompile_2einterp_2enotARune_str0, 38, "a primitive given what is not a `Rune`");

static V g_heff_2ecompile_2einterp_2enotARune_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotARune_st;
static V g_heff_2ecompile_2einterp_2enotARune_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotARune_str0)});
}
V g_heff_2ecompile_2einterp_2enotARune_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotARune_st)) return g_heff_2ecompile_2einterp_2enotARune_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotARune_val, &g_heff_2ecompile_2einterp_2enotARune_st, g_heff_2ecompile_2einterp_2enotARune_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotBytes_str0, 37, "a primitive given what is not `Bytes`");

static V g_heff_2ecompile_2einterp_2enotBytes_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotBytes_st;
static V g_heff_2ecompile_2einterp_2enotBytes_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotBytes_str0)});
}
V g_heff_2ecompile_2einterp_2enotBytes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotBytes_st)) return g_heff_2ecompile_2einterp_2enotBytes_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotBytes_val, &g_heff_2ecompile_2einterp_2enotBytes_st, g_heff_2ecompile_2einterp_2enotBytes_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat32_str0, 41, "a primitive given what is not a `Float32`");

static V g_heff_2ecompile_2einterp_2enotAFloat32_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat32_st;
static V g_heff_2ecompile_2einterp_2enotAFloat32_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat32_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat32_st)) return g_heff_2ecompile_2einterp_2enotAFloat32_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat32_val, &g_heff_2ecompile_2einterp_2enotAFloat32_st, g_heff_2ecompile_2einterp_2enotAFloat32_init);
}
Clo g_heff_2ecompile_2einterp_2estrTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2estrTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2estrTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VFloat: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VStr: {
    V v_a_2410 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_b_2418 = heff_field(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){heff_dup(v_a_2410), heff_dup(v_b_2418)});
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2estrTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2estrTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etwoTo_entry, 1, 0};

V g_heff_2ecompile_2einterp_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etwoTo(a[0]);
}
Clo g_heff_2ecompile_2einterp_2ebitsPush_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsPush_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitsPush(V v_n_240, V v_s_241, V v_w_242, V v_k_243) {
top: ;
  if (heff_intLe_c_lent(v_k_243, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_w_242);
    heff_drop(v_k_243);
    return v_s_241;
  } else {
    if ((heff_unbox_word(heff_intMod(heff_dup(v_n_240), MK_INT(8LL))) == ((int64_t)0ULL))) {
      heff_drop(v_n_240);
      V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((((int64_t)8ULL) - heff_unbox_word(v_k_243)))));
      uint8_t v_t_247 = heff_from_int_u8(heff_intMul(v_w_242, v_t_246));
      return heff_strAppend(v_s_241, heff_strFromByte(heff_box_u8(v_t_247)));
    } else {
      int64_t v_t_248 = (((int64_t)8ULL) - heff_unbox_word(heff_intMod(heff_dup(v_n_240), MK_INT(8LL))));
      if ((heff_peek_word(v_k_243) <= v_t_248)) {
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) - ((int64_t)1ULL));
        int64_t v_t_2411 = (((int64_t)8ULL) - heff_unbox_word(heff_intMod(v_n_240, MK_INT(8LL))));
        V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((v_t_2411 - heff_unbox_word(v_k_243)))));
        V v_b_2413 = heff_intAdd(heff_strByteAt_lent(v_s_241, heff_box_word(v_t_2410), 2), heff_intMul(v_w_242, v_t_2412));
        int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) - ((int64_t)1ULL));
        V v_t_2415 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_b_2413)));
        return heff_strAppend(heff_strSlice(v_s_241, MK_INT(0LL), heff_box_word(v_t_2414)), v_t_2415);
      } else {
        V v_t_2416 = heff_intSub(heff_intAdd(heff_dup(v_n_240), MK_INT(8LL)), heff_intMod(heff_dup(v_n_240), MK_INT(8LL)));
        int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) - ((int64_t)1ULL));
        int64_t v_t_2418 = (((int64_t)8ULL) - heff_unbox_word(heff_intMod(heff_dup(v_n_240), MK_INT(8LL))));
        V v_t_2419 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_k_243) - v_t_2418))));
        V v_b_2420 = heff_intAdd(heff_strByteAt_lent(v_s_241, heff_box_word(v_t_2417), 2), heff_intDiv(heff_dup(v_w_242), v_t_2419));
        int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) - ((int64_t)1ULL));
        V v_t_2422 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_b_2420)));
        V v_t_2423 = heff_strAppend(heff_strSlice(v_s_241, MK_INT(0LL), heff_box_word(v_t_2421)), v_t_2422);
        int64_t v_t_2424 = (((int64_t)8ULL) - heff_unbox_word(heff_intMod(heff_dup(v_n_240), MK_INT(8LL))));
        V v_t_2425 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_k_243) - v_t_2424))));
        int64_t v_t_2426 = (((int64_t)8ULL) - heff_unbox_word(heff_intMod(v_n_240, MK_INT(8LL))));
        V t_0 = v_t_2416;
        V t_1 = v_t_2423;
        V t_2 = heff_intMod(v_w_242, v_t_2425);
        V t_3 = heff_box_word((heff_unbox_word(v_k_243) - v_t_2426));
        v_n_240 = t_0;
        v_s_241 = t_1;
        v_w_242 = t_2;
        v_k_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsPush_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsPush(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2ebinaryExponent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebinaryExponent_entry, 2, 0};

V g_heff_2ecompile_2einterp_2ebinaryExponent_w(double v_a_240, V v_e_241) {
top: ;
  if (((2.0) <= v_a_240)) {
    double t_0 = (v_a_240 * (0.5));
    V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
    v_a_240 = t_0;
    v_e_241 = t_1;
    goto top;
  } else {
    if ((v_a_240 < (1.0))) {
      double t_0 = (v_a_240 * (2.0));
      V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
      v_a_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      return v_e_241;
    }
  }
}
V g_heff_2ecompile_2einterp_2ebinaryExponent(V v_box_24a_240, V v_e_241) {
  double v_a_240 = heff_unbox_f64(v_box_24a_240);
  return (g_heff_2ecompile_2einterp_2ebinaryExponent_w(v_a_240, v_e_241));
}
V g_heff_2ecompile_2einterp_2ebinaryExponent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebinaryExponent(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeMagnitude_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V v_box_24eb_240, V v_fb_241, double v_a_242) {
  int64_t v_eb_240 = heff_unbox_word(v_box_24eb_240);
top: ;
  if ((v_a_242 == (0.0))) {
    heff_drop(v_fb_241);
    return MK_INT(0LL);
  } else {
    V v_t_245 = heff_bool(!((v_a_242 - v_a_242) == (0.0)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_eb_240)));
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(v_fb_241));
      return heff_intMul(heff_intSub(v_t_246, MK_INT(1LL)), v_t_247);
    } else {
      heff_drop(v_t_245);
      V v_x_248 = (g_heff_2ecompile_2einterp_2ebinaryExponent_w(v_a_242, MK_INT(0LL)));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((v_eb_240 - ((int64_t)1ULL)))));
      V v_y_2410 = heff_intSub(MK_INT(2LL), v_t_249);
      if (heff_intLe_c(v_y_2410, v_x_248)) {
        V v_t_2412 = (g_heff_2ecompile_2einterp_2ebinaryExponent_w(v_a_242, MK_INT(0LL)));
        V v_t_2413 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((v_eb_240 - ((int64_t)1ULL)))));
        V v_t_2414 = heff_intSub(heff_intAdd(v_t_2412, v_t_2413), MK_INT(1LL));
        V v_t_2415 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
        V v_t_2416 = (g_heff_2ecompile_2einterp_2ebinaryExponent_w(v_a_242, MK_INT(0LL)));
        double v_t_2417 = (g_heff_2ecompile_2einterp_2escaledF_w(v_a_242, heff_intSub(heff_dup(v_fb_241), v_t_2416)));
        V v_t_2418 = heff_intAdd(heff_intMul(v_t_2414, v_t_2415), heff_floor_f64(v_t_2417));
        V v_t_2419 = (g_heff_2ecompile_2einterp_2etwoTo(v_fb_241));
        return heff_intSub(v_t_2418, v_t_2419);
      } else {
        V v_t_2420 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((v_eb_240 - ((int64_t)1ULL)))));
        V v_t_2421 = heff_intAdd(heff_intSub(v_t_2420, MK_INT(2LL)), v_fb_241);
        double v_t_2422 = (g_heff_2ecompile_2einterp_2escaledF_w(v_a_242, v_t_2421));
        return heff_floor_f64(v_t_2422);
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V v_box_24eb_240, V v_fb_241, V v_box_24a_242) {
  double v_a_242 = heff_unbox_f64(v_box_24a_242);
  return (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_box_24eb_240, v_fb_241, v_a_242));
}
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeMagnitude(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeOf_entry, 3, 0};

double g_heff_2ecompile_2einterp_2eieeeOf_w(V v_eb_240, V v_fb_241, V v_u_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
  V v_t_244 = heff_intMod(heff_intDiv(heff_dup(v_u_242), v_t_243), MK_INT(2LL));
  if ((heff_unbox_word(v_t_244) == ((int64_t)1ULL))) {
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_eb_240)));
    V v_t_248 = heff_intMod(heff_intDiv(heff_dup(v_u_242), v_t_246), v_t_247);
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    double v_t_2410 = (g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_w(v_eb_240, v_fb_241, v_t_248, heff_intMod(v_u_242, v_t_249)));
    return (((0.0) - (1.0)) * v_t_2410);
  } else {
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_eb_240)));
    V v_t_2413 = heff_intMod(heff_intDiv(heff_dup(v_u_242), v_t_2411), v_t_2412);
    V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    return (g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_w(v_eb_240, v_fb_241, v_t_2413, heff_intMod(v_u_242, v_t_2414)));
  }
}
V g_heff_2ecompile_2einterp_2eieeeOf(V v_eb_240, V v_fb_241, V v_u_242) {
  return heff_box_f64((g_heff_2ecompile_2einterp_2eieeeOf_w(v_eb_240, v_fb_241, v_u_242)));
}
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2ebitsSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsSet_entry, 1, 0};

V g_heff_2ecompile_2einterp_2ebitsSet(V v_m_240) {
top: ;
  if (heff_intLe_c_lent(v_m_240, MK_INT(0LL), 2)) {
    heff_drop(v_m_240);
    return MK_INT(0LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2einterp_2ebitsSet(heff_intDiv(heff_dup(v_m_240), MK_INT(2LL))));
    return heff_intAdd(heff_intMod(v_m_240, MK_INT(2LL)), v_t_242);
  }
}
V g_heff_2ecompile_2einterp_2ebitsSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsSet(a[0]);
}
Clo g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(V v_lit_240, V v_box_24n_241, V v_a_242, V v_b_243) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  if ((v_n_241 == ((int64_t)0ULL))) {
    heff_drop(v_lit_240);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return MK_INT(0LL);
  } else {
    int64_t v_t_245 = (heff_unbox_word(heff_intMod(heff_dup(v_a_242), MK_INT(2LL))) + heff_unbox_word(heff_intMod(heff_dup(v_b_243), MK_INT(2LL))));
    V v_t_246 = (g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(heff_dup(v_lit_240), heff_box_word((v_n_241 - ((int64_t)1ULL))), heff_intDiv(v_a_242, MK_INT(2LL)), heff_intDiv(v_b_243, MK_INT(2LL))));
    return heff_intAdd(heff_box_word((v_t_245 % heff_unbox_word(v_lit_240))), heff_intMul(MK_INT(2LL), v_t_246));
  }
}
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_val, &g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_st, g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) + heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s490426709x638839719_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_val, &g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_st, g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) * heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s2095555809x1546243848_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2efixedPrimV_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixedPrimV_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efixedPrimV(V v_p_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_p_240, 0));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    return ({ V b_0 = heff_get_n(v_p_240, 1, 2); V r_ = (g_heff_2ecompile_2einterp_2efloat32V(b_0)); heff_drop(b_0); r_; });
  } else {
    heff_drop(v_t_242);
    V v_t_243 = heff_dup(heff_rfield(v_p_240, 1));
    int64_t v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpSub: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpMul: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpDiv: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpRem: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpEq: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpLt: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpLe: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpAnd: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpOr: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpXor: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpShl: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpShr: {
      v_t_244 = ((int64_t)2ULL);
      break;
    }
    case TAG_OpShow: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    case TAG_OpFromInt: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    case TAG_OpToInt: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    case TAG_OpSqrt: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    case TAG_OpToFloat: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    case TAG_OpFloor: {
      v_t_244 = ((int64_t)1ULL);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    if ((v_t_244 == ((int64_t)2ULL))) {
      V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2einterp_2efixedInt2_clo), 2, (V[]){heff_take_field(v_p_240, 0), heff_get_n(v_p_240, 1, 2)}));
      HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(v_t_246);
    } else {
      return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efixedPrimV_lam0, 2, 1, (V[]){v_p_240})});
    }
  }
}
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixedPrimV(a[0]);
}
V g_heff_2ecompile_2einterp_2efixedPrimV_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_a_248 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_a_248, 1, (V[]){v_d_247}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Ok: {
    V v_v_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    switch (heff_tag_of(v_v_2410)) {
    case TAG_VFun: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2410, 0ULL, 2);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2415 = heff_field(v_v_2410, 0);
      heff_take_n(v_v_2410, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efixedInt1(heff_dup(heff_rfield(v_p_240, 0)), heff_get_n(v_p_240, 1, 2), v_a_2415));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2410, 0ULL, 1);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2410, 0ULL, 2);
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_rec(v_p_240, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2410);
    }
  }
  case TAG_Abn: {
    heff_drop_rec(v_p_240, 2);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop_rec(v_p_240, 2);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2424 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Bug = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    heff_drop_rec(v_p_240, 2);
    return heff_tag_at_n(v_ru_24x1_249_24Bug, TAG_Bug, 1, (V[]){v_what_2424});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_st)) return g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_val, &g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_st, g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64((v_a_2413 - v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_st;
static V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_st)) return g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_val;
  return heff_global(&g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_val, &g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_st, g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_init);
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VStr: {
        V v_a_2415 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VStr: {
          V v_b_2423 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2424 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VStr, 1, (V[]){heff_strAppend(v_a_2415, v_b_2423)});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2424});
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2ecompile_2einterp_2efixThunk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixThunk_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efixThunk(V v_g_240, V v_t_241, V v_d_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2einterp_2efixThunk_clo), 2, (V[]){heff_dup(v_g_240), heff_dup(v_t_241)}));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  HEFF_LAST return g_heff_2ecompile_2einterp_2eevalIn(heff_intAdd(v_d_242, MK_INT(1LL)), heff_rec_n(2, shape_local__global, (V[]){v_t_244, v_g_240}), v_t_241);
}
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixThunk(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_entry, 6, 0};

V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515(V v_lit_240, V v_lit_241, V v_lit_242, V v_ge_243, V v_x3_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_ge_243);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_244, 0);
    V v_rest_247 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_246, 0);
      V v_entry_249 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      V v_r_2410 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_243), heff_get_n(v_entry_249, 0, 4), MK_INT(0LL)));
      V v_t_2411 = (g_std_2emap_2einsert_24s1733258119x1737094492(heff_dup(v_r_2410), v_ge_243, heff_dup(v_x_248)));
      V v_t_2416;
      if (heff_strEq_c(heff_strSlice_lent(v_x_248, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2415;
        switch (heff_tag_of(v_r_2410)) {
        case TAG_Ok: {
          V v_v_2413 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Ok = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2415 = heff_tag_at_n(v_ru_24r_2410_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2413});
          break;
        }
        case TAG_Abn: {
          v_t_2415 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2415 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_2414 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Bug = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2415 = heff_tag_at_n(v_ru_24r_2410_24Bug, TAG_RBug, 1, (V[]){v_what_2414});
          break;
        }
        default: heff_nomatch(v_r_2410);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_t_2415}), v_acc_245});
      } else {
        heff_drop_cell(v_ru_24x3_244_24Cons, 2);
        heff_drop(v_x_248);
        heff_drop(v_r_2410);
        v_t_2416 = v_acc_245;
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_t_2411;
      V t_4 = v_rest_247;
      V t_5 = v_t_2416;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_ge_243 = t_3;
      v_x3_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515(a0, a1, a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}