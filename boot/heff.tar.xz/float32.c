// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
float g_float32_2efromDecimal_w(V, V);
V g_float32_2efromDecimal(V, V);
V g_float32_2efromDecimal_entry(V self, V *a);
extern Clo g_float32_2efromDecimal_clo;
V g_std_2emath_2enearestBits_24s226419449x1689653652(V, V);
V g_std_2emath_2enearestBits_24s226419449x1689653652_entry(V self, V *a);
extern Clo g_std_2emath_2enearestBits_24s226419449x1689653652_clo;
V g_std_2emath_2etenTo(V);
V g_std_2emath_2etenTo_entry(V self, V *a);
extern Clo g_std_2emath_2etenTo_clo;
Clo g_float32_2efromDecimal_clo = {{0x80000000u, K_CLO, 0}, g_float32_2efromDecimal_entry, 2, 0};

float g_float32_2efromDecimal_w(V v_m_240, V v_e_241) {
top: ;
  if (heff_intLt_c_lent(v_m_240, MK_INT(0LL), 2)) {
    float v_x_242 = (g_float32_2efromDecimal_w(heff_intSub(MK_INT(0LL), v_m_240), v_e_241));
    return ((float)(((float)(-1.0)) * v_x_242));
  } else {
    if (heff_intEq_c_lent(v_m_240, MK_INT(0LL), 2)) {
      heff_drop(v_m_240);
      heff_drop(v_e_241);
      return ((float)(0.0));
    } else {
      if ((heff_intLe_c_lent(MK_INT(0LL), v_e_241, 1) && (heff_intLe_c_lent(v_e_241, MK_INT(22LL), 2) && ({ V v_t_243 = (g_std_2emath_2etenTo(heff_dup(v_e_241))); int c_ = ({ V v_t_247 = heff_intMul_lent(v_m_240, v_t_243, 0); int c_ = heff_intLt_c_lent(v_t_247, MK_INT(9007199254740992LL), 2); heff_drop(v_t_247); c_; }); heff_drop(v_t_243); c_; })))) {
        V v_t_244 = (g_std_2emath_2etenTo(v_e_241));
        double v_t_245 = heff_from_int_f64(heff_intMul(v_m_240, v_t_244));
        return ((float)v_t_245);
      } else {
        V v_t_246 = (g_std_2emath_2enearestBits_24s226419449x1689653652(v_m_240, v_e_241));
        return ((float)heff_unbox_f64(heff_floatOfBits(MK_INT(32LL), v_t_246)));
      }
    }
  }
}
V g_float32_2efromDecimal(V v_m_240, V v_e_241) {
  return heff_box_f32((g_float32_2efromDecimal_w(v_m_240, v_e_241)));
}
V g_float32_2efromDecimal_entry(V self, V *a) {
  (void)self;
  return g_float32_2efromDecimal(a[0], a[1]);
}