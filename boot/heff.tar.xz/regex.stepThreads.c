// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_list_2eany_24s2020157007x2085425027(V, V);
V g_list_2eany_24s2020157007x2085425027_entry(V self, V *a);
extern Clo g_list_2eany_24s2020157007x2085425027_clo;
V g_regex_2estepThreads_2einRanges_240_get(void);

static V g_regex_2estepThreads_2einRanges_240_val;
static HEFF_ONCE g_regex_2estepThreads_2einRanges_240_st;
static V g_regex_2estepThreads_2einRanges_240_init(void) {
  return ((V)&g_list_2eany_24s2020157007x2085425027_clo);
}
V g_regex_2estepThreads_2einRanges_240_get(void) {
  if (HEFF_DONE(g_regex_2estepThreads_2einRanges_240_st)) return g_regex_2estepThreads_2einRanges_240_val;
  return heff_global(&g_regex_2estepThreads_2einRanges_240_val, &g_regex_2estepThreads_2einRanges_240_st, g_regex_2estepThreads_2einRanges_240_init);
}