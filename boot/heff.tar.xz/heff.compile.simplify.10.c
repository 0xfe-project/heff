// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyArm(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eask_24cpr(V, V, V, V, V, V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2eboundPushed(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eboundPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eboundPushed_clo;
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaArgs(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerPushed_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efromKept_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2egrew(V, V);
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrew_clo;
V g_heff_2ecompile_2esimplify_2ehandlerPushed(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eintOp_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknowing_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
HeffT2 g_heff_2ecompile_2esimplify_2emarkCopySafe_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN_24tok1(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_clo;
V g_heff_2ecompile_2esimplify_2eprunedAbove(V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedAbove_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedAbove_clo;
V g_heff_2ecompile_2esimplify_2eprunedArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedArm_clo;
V g_heff_2ecompile_2esimplify_2eprunedB(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedB_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor(V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_24dps_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushBound(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esameField(V);
V g_heff_2ecompile_2esimplify_2esameField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esameField_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etoValues(V, V);
V g_heff_2ecompile_2esimplify_2etoValues_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoValues_clo;
HeffT2 g_heff_2ecompile_2esimplify_2etoValues_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2etouch_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1252393826x821382319_24cpr(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebind_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebind(V v_m_240, V v_f_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_s_242}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    return heff_tail(v_f_241, 2, (V[]){v_x_244, v_s_245});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebind(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str6, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str7, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str8, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str9, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_24cpr_str11, 5, "False");

HeffT2 g_heff_2ecompile_2esimplify_2eintOp_24cpr(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str0), 2)) {
    V v_f_243 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str1), 2)) {
      V v_f_244 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str2), 2)) {
        V v_f_245 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str3), 2)) {
          V v_t_246;
          if (heff_intEq_c(v_a_241, v_b_242)) {
            v_t_246 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str4);
          } else {
            v_t_246 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str5);
          }
          V v_f_247 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_246, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str6), 2)) {
            V v_t_248;
            if (heff_intLt_c(v_a_241, v_b_242)) {
              v_t_248 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str7);
            } else {
              v_t_248 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str8);
            }
            V v_f_249 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_248, NTAG(TAG_Nil), NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str9), 2)) {
              V v_t_2410;
              if (heff_intLe_c(v_a_241, v_b_242)) {
                v_t_2410 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str10);
              } else {
                v_t_2410 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_24cpr_str11);
              }
              V v_f_2411 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2410, NTAG(TAG_Nil), NTAG(TAG_Nil)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
            } else {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emkApp(V v_f_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_argv_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      V v_ru_24f_240_24EApp = heff_take_reuse_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24f_240_24EApp, v_bs_249, v_argv_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_argv_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EPrim: {
      V v_p_2425 = heff_field(v_f_240, 0);
      V v_ru_24f_240_24EPrim = heff_take_reuse_n(v_f_240, 1ULL, 1);
      V v_t_2426 = (g_heff_2ecompile_2eprims_2eprimArityGo(v_p_2425, heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get())));
      return (g_heff_2ecompile_2esimplify_2eprimAppN_24tok1(v_ru_24f_240_24EPrim, v_p_2425, v_argv_241, v_t_2426));
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EBool: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_ESet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EValues: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_argv_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_argv_241);
  }
}
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emkApp(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2etoValues_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etoValues_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etoValues(V v_ts_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2etoValues_24cpr(v_ts_240, v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2etoValues_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etoValues(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eparamsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletFloat_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletFloat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletFloat_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletFloat(V v_r_240, V v_x_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EGlobal: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELam: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EApp: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_242, 0);
    V v_a1_2411 = heff_field(v_a_242, 1);
    V v_a2_2412 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_241, v_a2_2412, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_lam0, 1, 3, (V[]){v_m_2413, v_y_2410, v_a1_2411});
  }
  case TAG_ERecord: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EProj: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ETag: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EMatch: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrim: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrimCall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ECall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EInt: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EStr: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EBytes: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFixed: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat32: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EAbandon: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EBool: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ESet: {
    V v_ys_2442 = heff_field(v_a_242, 0);
    V v_a1_2443 = heff_field(v_a_242, 1);
    V v_a2_2444 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 7ULL, 3);
    V v_m_2445 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_241, v_a2_2444, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_lam1, 1, 3, (V[]){v_m_2445, v_ys_2442, v_a1_2443});
  }
  case TAG_EValues: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFix: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletFloat(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_a1_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_a1_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam1(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_ys_2442 = heff_env(self)[1];
  V v_a1_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2442, v_a1_2443, v_x_2448}), v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagsGiven_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etagsGiven(V v_x1_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_m_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_argv_246 = heff_field(v_x2_241, 1);
      V v_t_2446;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ELam: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EApp: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ELet: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EProj: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ETag: {
        v_t_2446 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_dup(v_x_243), heff_dup(v_a_245)));
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ECall: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EInt: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EStr: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EBool: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_ESet: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EValues: {
        v_t_2446 = v_m_242;
        break;
      }
      case TAG_EFix: {
        v_t_2446 = v_m_242;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      V t_0 = v_xs_244;
      V t_1 = v_argv_246;
      V t_2 = v_t_2446;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etagsGiven(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eprunedFor_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprunedFor_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedFor_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eprunedFor(V v_known_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_244, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2esimplify_2eprunedFor_24dps(v_known_240, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_241, 0);
    V v_argv_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_f_248));
    V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_lam0, 1, 1, (V[]){v_known_240}), v_argv_249));
    return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2410, v_t_2412});
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_241, 0);
    V v_a_2414 = heff_field(v_e_241, 1);
    V v_b_2415 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_2414));
    V v_cell_2417 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2413, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2esimplify_2eprunedFor_24dps(v_known_240, v_b_2415, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  case TAG_ERecord: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2428 = heff_field(v_e_241, 0);
    V v_arms_2429 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2471 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2eprunedFor_lam1, 1, 2, (V[]){heff_dup(v_sc_2428), v_known_240}), v_arms_2429));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2428, v_t_2471});
  }
  case TAG_EPrim: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EBool: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_ESet: {
    V v_xs_2485 = heff_field(v_e_241, 0);
    V v_a_2486 = heff_field(v_e_241, 1);
    V v_b_2487 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2488 = (g_heff_2ecompile_2esimplify_2eprunedFor(heff_dup(v_known_240), v_a_2486));
    V v_cell_2489 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2485, v_t_2488, heff_hole()});
    V v_u_2490 = (g_heff_2ecompile_2esimplify_2eprunedFor_24dps(v_known_240, v_b_2487, heff_dup(v_cell_2489), MK_INT(2LL)));
    heff_drop(v_u_2490);
    return v_cell_2489;
  }
  case TAG_EValues: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_known_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprunedFor(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eprunedFor_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_known_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2esimplify_2eprunedFor(v_known_240, v_a_2411));
}
V g_heff_2ecompile_2esimplify_2eprunedFor_lam1(V self, V *args) {
  V v_a_2430 = args[0];
  V v_sc_2428 = heff_env(self)[0];
  V v_known_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470;
  switch (heff_tag_of(v_sc_2428)) {
  case TAG_EVar: {
    V v_x_2431 = heff_field(v_sc_2428, 0);
    V v_ru_24sc_2428_24EVar = heff_take_reuse_n(v_sc_2428, 1ULL, 1);
    v_t_2470 = ({ V a_0 = v_ru_24sc_2428_24EVar; V a_1 = v_known_240; V a_2 = v_x_2431; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(a_0, a_1, a_2)); heff_drop(v_x_2431); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_sc_2428, 0ULL, 3);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_sc_2428, 0ULL, 4);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_sc_2428, 0ULL, 3);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_sc_2428, 0ULL, 3);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_sc_2428, 0ULL, 1);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_sc_2428, 0ULL, 2);
    v_t_2470 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_sc_2428);
  }
  return ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2eprunedFor_clo); V a_1 = v_known_240; V a_2 = v_t_2470; V a_3 = v_a_2430; V r_ = (g_heff_2ecompile_2esimplify_2eprunedArm(a_0, a_1, a_2, a_3)); heff_drop(v_t_2470); r_; });
}
Clo g_heff_2ecompile_2esimplify_2eprunedAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedAbove_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprunedAbove(V v_lim_240, V v_x2_241, V v_argv_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2esimplify_2etagsGiven(v_xs_245, v_argv_242, heff_dup(g_std_2emap_2eempty_get())));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_245, v_b_246}), NTAG(TAG_Nil)});
    V v_x_249 = (g_heff_2ecompile_2esimplify_2eprunedB(heff_dup(v_lim_240), v_t_247, MK_INT(0LL), v_t_248));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_lim_240, v_x_249, 0));
    heff_drop(v_lim_240);
    heff_drop(v_x_249);
    return v_ret_24bool;
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_lim_240);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedAbove_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eprunedAbove(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c_lent(v_x_244, v_y_248, 0)) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2evarsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V v_loop_240, V v_all_241, V v_back_242, V v_argv_243, V v_x5_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_back_242);
    heff_drop(v_argv_243);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_st_247 = heff_field(v_x5_244, 0);
    V v_rest_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2415;
    if ((heff_dup(v_st_247) == NTAG(TAG_True))) {
      heff_drop(v_st_247);
      HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2enthE_24cpr(heff_dup(v_i_245), heff_dup(v_argv_243)));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          V v_t_2413 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_241, heff_dup(v_x_2412)));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_x_2412);
            heff_drop(v_t_2413);
            v_t_2415 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2413);
            if ((heff_dup(v_loop_240) == NTAG(TAG_True))) {
              V v_t_2414 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_2412)));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_x_2412);
                heff_drop(v_t_2414);
                v_t_2415 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2414);
                v_t_2415 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2412}));
              }
            } else {
              v_t_2415 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2412}));
            }
          }
        } else {
          heff_drop(v_field_2411);
          v_t_2415 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_st_247);
      v_t_2415 = NTAG(TAG_False);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_loop_240;
    V t_1 = v_all_241;
    V t_2 = v_back_242;
    V t_3 = v_argv_243;
    V t_4 = v_rest_248;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_cell_2416;
    v_loop_240 = t_0;
    v_all_241 = t_1;
    v_back_242 = t_2;
    v_argv_243 = t_3;
    v_x5_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo_24dps(a0, a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eask_24cpr(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_248, 8)), 0, 5);
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_244), heff_dup(heff_rfield(v_sh_245, 0))));
  V v_t_2411 = ({ V a_0 = v_t_249; V a_1 = heff_dup(v_h_246); V a_2 = heff_dup(v_g_241); V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2ecopyVer(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2etouch_24cpr(heff_dup(v_h_246), v_t_2411, heff_dup(v_s_248)));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x_2415 = v_field_2413;
    heff_drop(v_x_2415);
    V v_s_2416 = v_field_2414;
    V v_t_2417 = heff_get_n(heff_get_n(v_s_248, 7, 9), 2, 7);
    HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_h_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_r_240);
        heff_drop(v_g_241);
        heff_drop(v_xs_242);
        heff_drop(v_b_243);
        heff_drop(v_marks_244);
        heff_drop_rec(v_sh_245, 3);
        heff_drop(v_h_246);
        heff_drop(v_d_247);
        V v_x_2421 = v_field_2420;
        heff_drop(v_x_2421);
        return ((HeffT2){{NTAG(TAG_MkUnit), v_s_2416}});
      } else {
        heff_drop(v_field_2420);
        HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2efromKept_24cpr(heff_dup(v_h_246), v_s_2416));
        {
          V v_field_2423 = v_t_2422.f[0];
          V v_field_2424 = v_t_2422.f[1];
          V v_x_2425 = v_field_2423;
          V v_s_2426 = v_field_2424;
          if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
            heff_drop(v_r_240);
            heff_drop(v_g_241);
            heff_drop(v_xs_242);
            heff_drop(v_b_243);
            heff_drop(v_marks_244);
            heff_drop_rec(v_sh_245, 3);
            heff_drop(v_h_246);
            heff_drop(v_d_247);
            heff_drop(v_x_2425);
            return ((HeffT2){{NTAG(TAG_MkUnit), v_s_2426}});
          } else {
            heff_drop(v_x_2425);
            HeffT2 v_t_2427 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_s_2426));
            {
              V v_field_2428 = v_t_2427.f[0];
              V v_field_2429 = v_t_2427.f[1];
              V v_x_2430 = v_field_2428;
              V v_s_2431 = v_field_2429;
              V v_m_2432 = (g_heff_2ecompile_2esimplify_2especBody(v_g_241, heff_dup(v_h_246), v_marks_244, v_sh_245, v_x_2430));
              V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2431}));
              switch (heff_tag_of(v_x2_2433)) {
              case TAG_MkPair: {
                V v_x_2434 = heff_field(v_x2_2433, 0);
                V v_s_2435 = heff_field(v_x2_2433, 1);
                heff_take_n(v_x2_2433, 3ULL, 2);
                HeffT2 v_t_2436 = (g_heff_2ecompile_2esimplify_2eknowing_24cpr(v_r_240, v_x_2434, v_s_2435));
                {
                  V v_field_2437 = v_t_2436.f[0];
                  V v_field_2438 = v_t_2436.f[1];
                  V v_x_2439 = v_field_2437;
                  V v_s_2440 = v_field_2438;
                  HeffT2 v_t_2441 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_246), heff_dup(v_x_2439), v_d_247, v_s_2440));
                  {
                    V v_field_2442 = v_t_2441.f[0];
                    V v_field_2443 = v_t_2441.f[1];
                    V v_x_2444 = v_field_2442;
                    heff_drop(v_x_2444);
                    V v_s_2445 = v_field_2443;
                    V v_kp_2446 = heff_take_field(v_s_2445, 8);
                    V v_supply_2447 = heff_take_field(v_s_2445, 0);
                    V v_fuel_2448 = heff_take_field(v_s_2445, 1);
                    V v_defs_2449 = heff_take_field(v_s_2445, 2);
                    V v_safe_2450 = heff_take_field(v_s_2445, 3);
                    V v_base_2451 = heff_take_field(v_s_2445, 4);
                    V v_total_2452 = heff_take_field(v_s_2445, 5);
                    V v_plain_2453 = heff_take_field(v_s_2445, 6);
                    V v_sp_2454 = heff_get_n(v_s_2445, 7, 9);
                    V v_k_2455 = v_kp_2446;
                    V v_vers_2456 = heff_take_field(v_k_2455, 0);
                    V v_kept_2457 = heff_take_field(v_k_2455, 1);
                    V v_touched_2458 = heff_take_field(v_k_2455, 2);
                    V v_fresh_2459 = heff_take_field(v_k_2455, 3);
                    V v_madeFresh_2460 = heff_get_n(v_k_2455, 4, 5);
                    V v_t_2461 = (g_std_2emap_2einsert_24s93785294x875597928(v_fresh_2459, heff_dup(v_h_246), NTAG(TAG_MkUnit)));
                    V v_k_2462 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2456, v_kept_2457, v_touched_2458, v_t_2461, v_madeFresh_2460});
                    return ({ V a_0 = v_h_246; V a_1 = v_x_2439; V a_2 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_2447, v_fuel_2448, v_defs_2449, v_safe_2450, v_base_2451, v_total_2452, v_plain_2453, v_sp_2454, v_k_2462}); HeffT2 r_ = (g_heff_2ecompile_2esimplify_2emarkCopySafe_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2439); r_; });
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_2433)}});
              }
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2especNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especNamed_entry, 10, 0};

V g_heff_2ecompile_2esimplify_2especNamed(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248, V v_z_249) {
top: ;
  if (heff_intLt_c_lent(MK_INT(16LL), v_d_248, 1)) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2410 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_z_249});
  } else {
    HeffT2 v_t_2411 = (g_heff_2ecompile_2esimplify_2eask_24cpr(heff_dup(v_r_240), v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_z_249));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_x_2414 = v_field_2412;
      heff_drop(v_x_2414);
      V v_s_2415 = v_field_2413;
      V v_t_2416 = (g_heff_2ecompile_2espec_2edropAt(v_marks_245, v_argv_244));
      V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_246, 2, 3), v_t_2416));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 3, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_247}), v_t_2417, v_s_2415});
    }
  }
}
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especNamed(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaWanted_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaWanted(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_243 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_243, 1));
    heff_drop(v_x_243);
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    V v_x_245 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_245, 1));
    heff_drop(v_x_245);
    return v_ret_24bool;
  }
  case TAG_ELam: {
    V v_x_248 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_248, 1));
    heff_drop(v_x_248);
    return v_ret_24bool;
  }
  case TAG_EApp: {
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2411, 1));
    heff_drop(v_x_2411);
    return v_ret_24bool;
  }
  case TAG_ELet: {
    V v_e_2414 = heff_field(v_x2_241, 2);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(heff_dup(v_e_2414)));
    V v_t_2420;
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_x_2418 = v_field_2416;
      heff_drop(v_x_2418);
      V v_y_2419 = v_field_2417;
      v_t_2420 = v_y_2419;
    }
    V v_t_2421 = (g_heff_2ecompile_2esimplify_2ecapturing(v_t_2420));
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_s_240);
      heff_drop(v_t_2421);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2421);
      HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(heff_dup(v_e_2414)));
      V v_t_2427;
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        heff_drop(v_x_2425);
        V v_y_2426 = v_field_2424;
        v_t_2427 = v_y_2426;
      }
      V v_x_2428 = ({ V a_0 = v_s_240; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2esimplify_2emissingOf(a_0, a_1)); heff_drop(v_t_2427); r_; });
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2428, 1));
      heff_drop(v_x_2428);
      return v_ret_24bool;
    }
  }
  case TAG_ERecord: {
    V v_x_2431 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2431, 1));
    heff_drop(v_x_2431);
    return v_ret_24bool;
  }
  case TAG_EProj: {
    V v_x_2436 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2436, 1));
    heff_drop(v_x_2436);
    return v_ret_24bool;
  }
  case TAG_ETag: {
    V v_x_2440 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2440, 1));
    heff_drop(v_x_2440);
    return v_ret_24bool;
  }
  case TAG_EMatch: {
    V v_x_2443 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2443, 1));
    heff_drop(v_x_2443);
    return v_ret_24bool;
  }
  case TAG_EPrim: {
    V v_x_2445 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2445, 1));
    heff_drop(v_x_2445);
    return v_ret_24bool;
  }
  case TAG_EPrimCall: {
    V v_x_2448 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2448, 1));
    heff_drop(v_x_2448);
    return v_ret_24bool;
  }
  case TAG_ECall: {
    V v_x_2451 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2451, 1));
    heff_drop(v_x_2451);
    return v_ret_24bool;
  }
  case TAG_EInt: {
    V v_x_2453 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2453, 1));
    heff_drop(v_x_2453);
    return v_ret_24bool;
  }
  case TAG_EFloat: {
    V v_x_2455 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2455, 1));
    heff_drop(v_x_2455);
    return v_ret_24bool;
  }
  case TAG_EStr: {
    V v_x_2457 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2457, 1));
    heff_drop(v_x_2457);
    return v_ret_24bool;
  }
  case TAG_EBytes: {
    V v_x_2459 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2459, 1));
    heff_drop(v_x_2459);
    return v_ret_24bool;
  }
  case TAG_EFixed: {
    V v_x_2462 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2462, 1));
    heff_drop(v_x_2462);
    return v_ret_24bool;
  }
  case TAG_EFloat32: {
    V v_x_2464 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2464, 1));
    heff_drop(v_x_2464);
    return v_ret_24bool;
  }
  case TAG_EAbandon: {
    V v_x_2465 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2465, 1));
    heff_drop(v_x_2465);
    return v_ret_24bool;
  }
  case TAG_EBool: {
    V v_x_2467 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2467, 1));
    heff_drop(v_x_2467);
    return v_ret_24bool;
  }
  case TAG_ESet: {
    V v_x_2471 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2471, 1));
    heff_drop(v_x_2471);
    return v_ret_24bool;
  }
  case TAG_EValues: {
    V v_x_2473 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2473, 1));
    heff_drop(v_x_2473);
    return v_ret_24bool;
  }
  case TAG_EFix: {
    V v_x_2476 = (g_heff_2ecompile_2esimplify_2emissingOf(v_s_240, v_x2_241));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2476, 1));
    heff_drop(v_x_2476);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaWanted(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLoop_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2eetaLoop(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_x6_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    V v_t_249 = ({ V a_0 = v_g_241; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ecompile_2espec_2eusesOf(v_g_241, v_b_243));
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_242; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eetaArgs(v_r_240, v_t_2411, v_argv_244));
      return heff_tail(v_t_2412, 1, (V[]){v_z_246});
    } else {
      heff_drop(v_r_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_t_249);
      V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_244});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_z_246});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_244});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_z_246});
  }
}
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2esimplify_2eetaLoop(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eapplyArm_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyArm_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eapplyArm_lam10(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyArm_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyArm(V v_r_240, V v_b_241, V v_argv_242) {
top: ;
  V v_m_2452 = (g_prelude_2etraverse_24s2064368144x1684679122(((V)&g_heff_2ecompile_2esimplify_2eapplyArm_lam0_clo), v_argv_242));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam10, 1, 3, (V[]){v_m_2452, v_r_240, v_b_241});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyArm(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_245});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2433});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2435});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam6(V self, V *args) {
  V v_s_2437 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2437});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam7(V self, V *args) {
  V v_s_2439 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2439});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam8(V self, V *args) {
  V v_s_2442 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2442});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam9(V self, V *args) {
  V v_s_2444 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_s_2444});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam0(V self, V *args) {
  V v_a_243 = args[0];
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam1, 1, 1, (V[]){v_a_243});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam2, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELam: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EApp: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ELet: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ERecord: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EProj: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ETag: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EMatch: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam3, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrimCall: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ECall: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam4, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam5, 1, 1, (V[]){v_a_243});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam6, 1, 1, (V[]){v_a_243});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam7, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam8, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_lam9, 1, 1, (V[]){v_a_243});
  }
  case TAG_EAbandon: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EBool: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ESet: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EValues: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EFix: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyArm_lam10(V self, V *args) {
  V v_s_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2454 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2453}));
  switch (heff_tag_of(v_x2_2454)) {
  case TAG_MkPair: {
    V v_x_2455 = heff_field(v_x2_2454, 0);
    V v_s_2456 = heff_field(v_x2_2454, 1);
    heff_take_n(v_x2_2454, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_b_241;
    heff_room[1] = v_x_2455;
    heff_room[2] = v_s_2456;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2454);
  }
}
Clo g_heff_2ecompile_2esimplify_2eboundPushed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eboundPushed_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2eboundPushed(V v_r_240, V v_orig_241, V v_s_242, V v_arms_243, V v_argv_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_argv_244; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_246); r_; });
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_argv_248 = (g_list_2ekeepIf_24s183165982x1490920686(heff_dup(v_argv_244)));
    V v_t_249 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_248)));
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_249); r_; });
    if (((heff_dup(v_t_2410) == NTAG(TAG_True)) && ({ V v_t_2411 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_248))); int c_ = ({ V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_243)); int c_ = ({ V v_t_2418 = heff_intMul(heff_dup(v_t_2411), heff_intSub(heff_dup(v_t_2412), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2418, MK_INT(120LL), 2); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; }))) {
      heff_drop(v_argv_248);
      heff_drop(v_t_2410);
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2eallPure_24cpr(heff_dup(v_argv_244), v_s_245));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_x_2416 = v_field_2414;
        V v_s_2417 = v_field_2415;
        if ((heff_dup(v_x_2416) == NTAG(TAG_True))) {
          heff_drop(v_orig_241);
          heff_drop(v_x_2416);
          return (g_heff_2ecompile_2esimplify_2epushBound(v_r_240, v_s_242, v_arms_243, v_argv_244, v_s_2417));
        } else {
          heff_drop(v_r_240);
          heff_drop(v_s_242);
          heff_drop(v_arms_243);
          heff_drop(v_argv_244);
          heff_drop(v_x_2416);
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_241, v_s_2417});
        }
      }
    } else {
      heff_drop(v_r_240);
      heff_drop(v_s_242);
      heff_drop(v_arms_243);
      heff_drop(v_argv_244);
      heff_drop(v_argv_248);
      heff_drop(v_t_2410);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_241, v_s_245});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_s_242);
    heff_drop(v_arms_243);
    heff_drop(v_argv_244);
    heff_drop(v_t_247);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_241, v_s_245});
  }
}
V g_heff_2ecompile_2esimplify_2eboundPushed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eboundPushed(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V v_l_240, V v_argv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_argv_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_x312_247 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_247)) {
      case TAG_EVar: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        heff_take_n(v_x312_247, 0ULL, 3);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_x312_247, 0);
        heff_take_n(v_x312_247, 1ULL, 2);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2efieldIn_24cpr(v_l_240, v_fs_2417));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_x_2422 = v_field_2421;
            V v_t_2423 = (g_heff_2ecompile_2esimplify_2ezipL(v_xs_246, v_argv_241));
            V v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = v_x_2422; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2423); r_; });
            return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2424});
          } else {
            heff_drop(v_argv_241);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_xs_246);
            heff_drop(v_field_2421);
            return NTAG(TAG_Nothing);
          }
        }
      }
      case TAG_EProj: {
        heff_take_n(v_x312_247, 0ULL, 4);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        heff_take_n(v_x312_247, 0ULL, 3);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        heff_take_na(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBytes: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        heff_take_na(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBool: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_ESet: {
        heff_take_n(v_x312_247, 0ULL, 3);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EValues: {
        heff_take_n(v_x312_247, 0ULL, 1);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        heff_take_n(v_x312_247, 0ULL, 2);
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_xs_246);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x312_247);
      }
    }
    case TAG_EApp: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBool: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EValues: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ebuiltFieldOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_245, v_l_240, 1)) {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, heff_dup(v_l_240), v_rest_244});
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eothersPure(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_248 = ({ V a_0 = heff_dup(v_s_247); V a_1 = v_f_246; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop(v_f_246); r_; });
  if ((heff_dup(v_x_248) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    V v_t_249 = ({ V a_0 = v_l_240; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2esimplify_2eothersPure(a_0, a_1)); heff_drop(v_l_240); r_; });
    V f_ = v_t_249;
    args[0] = v_s_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_l_240);
    heff_drop(v_rest_244);
    heff_drop(v_x_248);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_247});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esameField_str0, 1, "_");
Clo g_heff_2ecompile_2esimplify_2esameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esameField_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2esameField(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_MkPair: {
    V v_v_241 = heff_field(v_p_240, 0);
    V v_p2_242 = heff_field(v_p_240, 1);
    switch (heff_tag_of(v_p2_242)) {
    case TAG_EVar: {
      V v_y_243 = heff_field(v_p2_242, 0);
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_v_241, v_y_243, 0) && !heff_strEq_c_lent(v_v_241, ((V)&g_heff_2ecompile_2esimplify_2esameField_str0), 2)));
      return v_ret_24bool;
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_p2_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2esimplify_2esameField_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esameField(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = v_key_240; V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_247 = v_s_242;
  } else {
    heff_drop(v_t_245);
    V v_d_246 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 2), heff_dup(v_key_240), heff_dup(v_b_241)));
    v_t_247 = ({ V rv_2 = v_d_246; V rr_ = heff_rec_reuse_nf(v_s_242, 507ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262095u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  V v_f_248 = (g_heff_2ecompile_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247));
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_248}});
}
Clo g_heff_2ecompile_2esimplify_2egrew_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egrew_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2egrew(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_bs_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c_lent(v_a_242, v_b_244, 0)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_argv_243;
        V t_1 = v_bs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2egrew(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())}), v_defs_241));
  V v_safe_243 = heff_take_field(v_sg_242, 0);
  V v_total_244 = heff_get_n(v_sg_242, 1, 2);
  V v_t_245 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  HeffT2 v_t_246 = (g_prelude_2etraverse_24s1252393826x821382319_24cpr(v_defs_241, heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_safe_243), v_safe_243, v_total_244, heff_dup(g_std_2emap_2eempty_get()), v_t_245, heff_dup(g_heff_2ecompile_2esimplify_2enoKeep_get())})));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_out_249 = v_field_247;
    V v_st_2410 = v_field_248;
    V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_249)));
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_249)));
    V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_list_2emap_24s1937570095x2110149801(v_out_249));
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = ({ V a_0 = heff_dup(v_st_2410); V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2412, heff_get_n(v_st_2410, 0, 9), v_t_2414, v_t_2417});
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyProgram(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2(V v_tok_240, V v_r_241, V v_s_242, V v_arms_243, V v_argv_244, V v_z_245) {
top: ;
  V v_t_246 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_244)));
  V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_246); r_; });
  if (((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_244))); int c_ = ({ V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_243)); int c_ = ({ V v_t_2424 = heff_intMul(heff_dup(v_t_248), heff_intSub(heff_dup(v_t_249), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2424, MK_INT(120LL), 2); heff_drop(v_t_2424); c_; }); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; }))) {
    heff_drop(v_t_247);
    V v_m_2419 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_lam0, 1, 2, (V[]){v_r_241, v_argv_244}), v_arms_243));
    V v_x2_2420 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_z_245}));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_s_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_x_2421}), v_s_2422});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_247);
    V v_t_2423 = (g_heff_2ecompile_2esimplify_2ehandlerPushed(v_arms_243, heff_dup(v_argv_244)));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_t_2423);
      return (g_heff_2ecompile_2esimplify_2epushBound(v_r_241, v_s_242, v_arms_243, v_argv_244, v_z_245));
    } else {
      heff_drop(v_t_2423);
      return (g_heff_2ecompile_2esimplify_2efollowerPushed(v_r_241, v_s_242, v_arms_243, v_argv_244, v_z_245));
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchApplied_24tok2(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_t_2411 = heff_env(self)[1];
  V v_vs_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2411, v_vs_2412, v_x_2417}), v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_r_241 = heff_env(self)[0];
  V v_argv_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2410)) {
  case TAG_MkArm: {
    V v_t_2411 = heff_field(v_a_2410, 0);
    V v_vs_2412 = heff_field(v_a_2410, 1);
    V v_b_2413 = heff_field(v_a_2410, 2);
    heff_take_n(v_a_2410, 7ULL, 3);
    V v_m_2414 = (g_heff_2ecompile_2esimplify_2eapplyArm(v_r_241, v_b_2413, v_argv_244));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_24tok2_lam1, 1, 3, (V[]){v_m_2414, v_t_2411, v_vs_2412});
  }
  default: return heff_nomatch(v_a_2410);
  }
}