// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_clo;
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2eserial_2eabsOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eabsOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_lit_240, v_x_243));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_a_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry, 5, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_rest_244;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246, v_rest_244));
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 0);
      V v_a_249 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_2410 = heff_intShow(heff_strLength_lent(v_a_248, 0));
      V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(v_lit_240, v_a_248));
      V v_a_2412 = heff_arrayToList(v_a_249);
      V v_a_2413 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2412));
      V v_t_2414 = ({ V a_0 = v_a_2412; V a_1 = v_a_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a_0, a_1)); heff_drop(v_a_2412); r_; });
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2413), v_t_2414});
      return heff_tag_at_n(v_ru_24x_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2411, v_t_2415});
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SmallU: {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
    }
    case TAG_LargeU: {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_x2_240, 0);
    V v_t_247 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_246), v_rest_241));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4), v_t_247}));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_240, 0);
    V v_dom_249 = heff_field(v_x2_240, 1);
    V v_cod_2410 = heff_field(v_x2_240, 2);
    V v_implicit_2411 = heff_field(v_x2_240, 3);
    V v_dflt_2412 = heff_field(v_x2_240, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2412, 0);
      V v_t_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2415), v_rest_241));
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12), v_t_2416});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
    V v_rest_2426;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_cod_2410, 0);
      V v_e_2420 = heff_field(v_cod_2410, 1);
      V v_t_2421 = heff_intShow(heff_strLength_lent(v_x_2419, 0));
      V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13), heff_dup(v_x_2419)));
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2420, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2424 = heff_field(v_cod_2410, 0);
      V v_t_2425 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2424, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15), v_t_2425});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_t_2427 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_249, v_rest_2426));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2427})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_SRecord: {
    V v_level_2429 = heff_field(v_x2_240, 0);
    V v_fs_2430 = heff_field(v_x2_240, 1);
    V v_ds_2431 = heff_field(v_x2_240, 2);
    V v_t_2432;
    switch (heff_tag_of(v_level_2429)) {
    case TAG_Small: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17);
      break;
    }
    case TAG_Large: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19);
      break;
    }
    default: heff_nomatch(v_level_2429);
    }
    V v_t_2433 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2431, 0)));
    V v_t_2434 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2431, 2)));
    V v_xs_2435 = (g_heff_2eutil_2edict_2ezipKV(v_t_2433, v_t_2434));
    V v_i_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2435));
    V v_t_2437 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20), v_xs_2435, v_rest_241));
    V v_rest_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2436), v_t_2437});
    V v_t_2439 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2430, 0)));
    V v_t_2440 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2430, 2)));
    V v_xs_2441 = (g_heff_2eutil_2edict_2ezipKV(v_t_2439, v_t_2440));
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21), v_xs_2441, v_rest_2438));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2444})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2445);
  }
  case TAG_SSum: {
    V v_vs_2446 = heff_field(v_x2_240, 0);
    V v_t_2447 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2446, 0)));
    V v_t_2448 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2446, 2)));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2449, v_rest_241));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24), v_t_2452}));
  }
  case TAG_SIsTy: {
    V v_t2_2453 = heff_field(v_x2_240, 0);
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25), heff_hole()});
    V v_u_2455 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2454));
    heff_drop(v_u_2455);
    V t_0 = v_t2_2453;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2454;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrimInt: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26), v_rest_241}));
  }
  case TAG_SPrimFloat: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27), v_rest_241}));
  }
  case TAG_SPrimString: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28), v_rest_241}));
  }
  case TAG_SPrimRune: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29), v_rest_241}));
  }
  case TAG_SPrimArray: {
    V v_t2_2456 = heff_field(v_x2_240, 0);
    V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30), heff_hole()});
    V v_u_2458 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2457));
    heff_drop(v_u_2458);
    V t_0 = v_t2_2456;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2457;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFixed: {
    V v_w_2459 = heff_field(v_x2_240, 0);
    V v_t_2460;
    switch (heff_tag_of(v_w_2459)) {
    case TAG_I8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31);
      break;
    }
    case TAG_I16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32);
      break;
    }
    case TAG_I32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33);
      break;
    }
    case TAG_I64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34);
      break;
    }
    case TAG_U8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35);
      break;
    }
    case TAG_U16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36);
      break;
    }
    case TAG_U32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37);
      break;
    }
    case TAG_U64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38);
      break;
    }
    case TAG_F32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39);
      break;
    }
    default: heff_nomatch(v_w_2459);
    }
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2461);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8, 7, "Float32");

HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7), ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8), v_x_247, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_j_248})}});
          } else {
            heff_drop(v_j_248);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_241), v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_x3_2424;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        v_x3_2424 = (g_heff_2ebuild_2edecoder_2etimes(heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0, 2, 1, (V[]){v_d_240}), v_x_248, v_s_241, v_j_249));
        break;
      }
      default: heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_d_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      v_x3_2424 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_2424)) {
    case TAG_Nothing: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2425 = heff_field(v_x3_2424, 0);
      heff_take_n(v_x3_2424, 1ULL, 1);
      switch (heff_tag_of(v_x31_2425)) {
      case TAG_MkPair: {
        V v_x_2426 = heff_field(v_x31_2425, 0);
        V v_j_2427 = heff_field(v_x31_2425, 1);
        V v_ru_24x31_2425_24MkPair = heff_take_reuse_n(v_x31_2425, 3ULL, 2);
        V v_t_2428 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2426)));
        V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2426));
        V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2426));
        V v_x_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_j_2427})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_2424)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_i_2411 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_2410), v_i_2411));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x31_2416 = v_field_2414;
      switch (heff_tag_of(v_x31_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x31_2416, 0);
        V v_j_2418 = heff_field(v_x31_2416, 1);
        V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
        V v_x3_2419 = heff_tr(heff_call(v_d_240, 2, (V[]){v_s_2410, v_j_2418}));
        switch (heff_tag_of(v_x3_2419)) {
        case TAG_Nothing: {
          heff_drop(v_x_2417);
          heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2420 = heff_field(v_x3_2419, 0);
          V v_ru_24x3_2419_24Just = heff_take_reuse_n(v_x3_2419, 1ULL, 1);
          switch (heff_tag_of(v_x31_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x31_2420, 0);
            V v_j_2422 = heff_field(v_x31_2420, 1);
            heff_take_n(v_x31_2420, 3ULL, 2);
            V v_t_2423 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_x_2421}), v_j_2422});
            return heff_tag_at_n(v_ru_24x3_2419_24Just, TAG_Just, 1, (V[]){v_t_2423});
          }
          default: return heff_nomatch(v_x31_2420);
          }
        }
        default: return heff_nomatch(v_x3_2419);
        }
      }
      default: return heff_nomatch(v_x31_2416);
      }
    } else {
      heff_drop(v_s_2410);
      heff_drop(v_d_240);
      heff_drop(v_field_2414);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_241), v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_x3_2410;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        v_x3_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_248, heff_dup(v_s_241), v_j_249));
        break;
      }
      default: heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_field_245);
      v_x3_2410 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_2411 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      switch (heff_tag_of(v_x31_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x31_2411, 0);
        V v_j_2413 = heff_field(v_x31_2411, 1);
        V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
        V v_x3_2414 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_2413}));
        switch (heff_tag_of(v_x3_2414)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_2410_24Just, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2415 = heff_field(v_x3_2414, 0);
          heff_take_n(v_x3_2414, 1ULL, 1);
          switch (heff_tag_of(v_x31_2415)) {
          case TAG_MkPair: {
            V v_x_2416 = heff_field(v_x31_2415, 0);
            V v_j_2417 = heff_field(v_x31_2415, 1);
            heff_take_n(v_x31_2415, 3ULL, 2);
            V v_t_2418 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2412), v_x_2416});
            return heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_j_2417})});
          }
          default: return heff_nomatch(v_x31_2415);
          }
        }
        default: return heff_nomatch(v_x3_2414);
        }
      }
      default: return heff_nomatch(v_x31_2411);
      }
    }
    default: return heff_nomatch(v_x3_2410);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str20, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str23, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str24, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str25, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str26, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str27, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str28, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str29, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str31, 0, "");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_x2_241);
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_2410}), v_j_2411});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_x2_241);
      HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_x31_2418 = v_field_2416;
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2419}), v_j_2420});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2418)}});
          }
        } else {
          heff_drop(v_field_2416);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str2), 2)) {
        heff_drop(v_x2_241);
        V v_x3_2423 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
        switch (heff_tag_of(v_x3_2423)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2424 = heff_field(v_x3_2423, 0);
          V v_ru_24x3_2423_24Just = heff_take_reuse_n(v_x3_2423, 1ULL, 1);
          switch (heff_tag_of(v_x31_2424)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x31_2424, 0);
            V v_j_2426 = heff_field(v_x31_2424, 1);
            V v_ru_24x31_2424_24MkPair = heff_take_reuse_n(v_x31_2424, 3ULL, 2);
            V v_t_2427 = heff_tag_at_n(v_ru_24x31_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2423_24Just, TAG_SCode, 1, (V[]){v_x_2425}), v_j_2426});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2424)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2423)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str3), 2)) {
          heff_drop(v_x2_241);
          V v_x3_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2429)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2430 = heff_field(v_x3_2429, 0);
            heff_take_n(v_x3_2429, 1ULL, 1);
            switch (heff_tag_of(v_x31_2430)) {
            case TAG_MkPair: {
              V v_x_2431 = heff_field(v_x31_2430, 0);
              V v_j_2432 = heff_field(v_x31_2430, 1);
              V v_ru_24x31_2430_24MkPair = heff_take_reuse_n(v_x31_2430, 3ULL, 2);
              V v_x3_2433 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2432}));
              switch (heff_tag_of(v_x3_2433)) {
              case TAG_Nothing: {
                heff_drop(v_x_2431);
                heff_drop_cell(v_ru_24x31_2430_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2434 = heff_field(v_x3_2433, 0);
                heff_take_n(v_x3_2433, 1ULL, 1);
                switch (heff_tag_of(v_x31_2434)) {
                case TAG_MkPair: {
                  V v_x_2435 = heff_field(v_x31_2434, 0);
                  V v_j_2436 = heff_field(v_x31_2434, 1);
                  heff_take_n(v_x31_2434, 3ULL, 2);
                  V v_t_2437 = heff_tag_at_n(v_ru_24x31_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2431, v_x_2435}), v_j_2436});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2437}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2434)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2433)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2430)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2429)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str4), 2)) {
            heff_drop(v_x2_241);
            V v_x3_2439 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
            switch (heff_tag_of(v_x3_2439)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2440 = heff_field(v_x3_2439, 0);
              heff_take_n(v_x3_2439, 1ULL, 1);
              switch (heff_tag_of(v_x31_2440)) {
              case TAG_MkPair: {
                V v_x_2441 = heff_field(v_x31_2440, 0);
                V v_j_2442 = heff_field(v_x31_2440, 1);
                V v_ru_24x31_2440_24MkPair = heff_take_reuse_n(v_x31_2440, 3ULL, 2);
                HeffT2 v_t_2443 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_242), v_j_2442));
                {
                  V v_field_2445 = v_t_2443.f[1];
                  int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
                  V v_x3_2450;
                  if ((v_tag_2444 == ((int64_t)0ULL))) {
                    V v_x31_2447 = v_field_2445;
                    switch (heff_tag_of(v_x31_2447)) {
                    case TAG_MkPair: {
                      V v_x_2448 = heff_field(v_x31_2447, 0);
                      V v_j_2449 = heff_field(v_x31_2447, 1);
                      heff_take_n(v_x31_2447, 3ULL, 2);
                      v_x3_2450 = (g_heff_2ebuild_2eserial_2eabsOf(heff_get_n(v_k_240, 0, 2), v_x_2448, v_z_242, v_j_2449));
                      break;
                    }
                    default: heff_nomatch(v_x31_2447);
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_field_2445);
                    v_x3_2450 = NTAG(TAG_Nothing);
                  }
                  switch (heff_tag_of(v_x3_2450)) {
                  case TAG_Nothing: {
                    heff_drop(v_x_2441);
                    heff_drop_cell(v_ru_24x31_2440_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2451 = heff_field(v_x3_2450, 0);
                    heff_take_n(v_x3_2450, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2451)) {
                    case TAG_MkPair: {
                      V v_x_2452 = heff_field(v_x31_2451, 0);
                      V v_j_2453 = heff_field(v_x31_2451, 1);
                      heff_take_n(v_x31_2451, 3ULL, 2);
                      V v_t_2454 = heff_tag_at_n(v_ru_24x31_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2441, v_x_2452}), v_j_2453});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2454}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2451)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2450)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2440)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_2439)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str5), 2)) {
              heff_drop(v_x2_241);
              HeffT2 v_t_2456 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_z_243));
              {
                V v_field_2458 = v_t_2456.f[1];
                int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                if ((v_tag_2457 == ((int64_t)0ULL))) {
                  V v_x31_2460 = v_field_2458;
                  switch (heff_tag_of(v_x31_2460)) {
                  case TAG_MkPair: {
                    V v_x_2461 = heff_field(v_x31_2460, 0);
                    V v_j_2462 = heff_field(v_x31_2460, 1);
                    V v_ru_24x31_2460_24MkPair = heff_take_reuse_n(v_x31_2460, 3ULL, 2);
                    V v_t_2463 = heff_tag_at_n(v_ru_24x31_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2461}), v_j_2462});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2463}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2460)}});
                  }
                } else {
                  heff_drop(v_field_2458);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str6), 2)) {
                heff_drop(v_x2_241);
                V v_x3_2465 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2465)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2466 = heff_field(v_x3_2465, 0);
                  heff_take_n(v_x3_2465, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2466)) {
                  case TAG_MkPair: {
                    V v_x_2467 = heff_field(v_x31_2466, 0);
                    V v_j_2468 = heff_field(v_x31_2466, 1);
                    V v_ru_24x31_2466_24MkPair = heff_take_reuse_n(v_x31_2466, 3ULL, 2);
                    HeffT2 v_t_2469 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_2468));
                    {
                      V v_field_2471 = v_t_2469.f[1];
                      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                      if ((v_tag_2470 == ((int64_t)0ULL))) {
                        V v_x31_2473 = v_field_2471;
                        switch (heff_tag_of(v_x31_2473)) {
                        case TAG_MkPair: {
                          V v_x_2474 = heff_field(v_x31_2473, 0);
                          V v_j_2475 = heff_field(v_x31_2473, 1);
                          heff_take_n(v_x31_2473, 3ULL, 2);
                          V v_t_2476 = heff_tag_at_n(v_ru_24x31_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2467, v_x_2474}), v_j_2475});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2476}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2473)}});
                        }
                      } else {
                        heff_drop(v_x_2467);
                        heff_drop_cell(v_ru_24x31_2466_24MkPair, 2);
                        heff_drop(v_field_2471);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2466)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2465)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str7), 2)) {
                  heff_drop(v_x2_241);
                  HeffT2 v_t_2478 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                  {
                    V v_field_2480 = v_t_2478.f[1];
                    int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
                    if ((v_tag_2479 == ((int64_t)0ULL))) {
                      V v_x31_2482 = v_field_2480;
                      switch (heff_tag_of(v_x31_2482)) {
                      case TAG_MkPair: {
                        V v_x_2483 = heff_field(v_x31_2482, 0);
                        V v_j_2484 = heff_field(v_x31_2482, 1);
                        V v_ru_24x31_2482_24MkPair = heff_take_reuse_n(v_x31_2482, 3ULL, 2);
                        HeffT2 v_t_2485 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_2484));
                        {
                          V v_field_2487 = v_t_2485.f[1];
                          int64_t v_tag_2486 = ((int64_t)v_t_2485.f[0]);
                          V v_x3_2492;
                          if ((v_tag_2486 == ((int64_t)0ULL))) {
                            V v_x31_2489 = v_field_2487;
                            switch (heff_tag_of(v_x31_2489)) {
                            case TAG_MkPair: {
                              V v_x_2490 = heff_field(v_x31_2489, 0);
                              V v_j_2491 = heff_field(v_x31_2489, 1);
                              heff_take_n(v_x31_2489, 3ULL, 2);
                              v_x3_2492 = (g_heff_2ebuild_2edecoder_2etimes(heff_get_n(v_k_240, 0, 2), v_x_2490, v_z_242, v_j_2491));
                              break;
                            }
                            default: heff_nomatch(v_x31_2489);
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_field_2487);
                            v_x3_2492 = NTAG(TAG_Nothing);
                          }
                          switch (heff_tag_of(v_x3_2492)) {
                          case TAG_Nothing: {
                            heff_drop(v_x_2483);
                            heff_drop_cell(v_ru_24x31_2482_24MkPair, 2);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_2493 = heff_field(v_x3_2492, 0);
                            heff_take_n(v_x3_2492, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2493)) {
                            case TAG_MkPair: {
                              V v_x_2494 = heff_field(v_x31_2493, 0);
                              V v_j_2495 = heff_field(v_x31_2493, 1);
                              V v_ru_24x31_2493_24MkPair = heff_take_reuse_n(v_x31_2493, 3ULL, 2);
                              V v_t_2496 = heff_tag_at_n(v_ru_24x31_2493_24MkPair, TAG_STag, 2, (V[]){v_x_2483, heff_arrayFromList(v_x_2494)});
                              V v_f_2497 = heff_tag_at_n(v_ru_24x31_2482_24MkPair, TAG_MkPair, 2, (V[]){v_t_2496, v_j_2495});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2497}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2493)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x3_2492)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2482)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_field_2480);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str8), 2)) {
                    heff_drop(v_x2_241);
                    V v_x3_2499 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_2499)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_24100 = heff_field(v_x3_2499, 0);
                      heff_take_n(v_x3_2499, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24100)) {
                      case TAG_MkPair: {
                        V v_x_24101 = heff_field(v_x31_24100, 0);
                        V v_j_24102 = heff_field(v_x31_24100, 1);
                        V v_ru_24x31_24100_24MkPair = heff_take_reuse_n(v_x31_24100, 3ULL, 2);
                        V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
                        HeffT2 v_t_24104 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_24103, v_z_242, v_j_24102));
                        {
                          V v_field_24106 = v_t_24104.f[1];
                          int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
                          if ((v_tag_24105 == ((int64_t)0ULL))) {
                            V v_x31_24108 = v_field_24106;
                            switch (heff_tag_of(v_x31_24108)) {
                            case TAG_MkPair: {
                              V v_x_24109 = heff_field(v_x31_24108, 0);
                              V v_j_24110 = heff_field(v_x31_24108, 1);
                              heff_take_n(v_x31_24108, 3ULL, 2);
                              V v_t_24111 = heff_tag_at_n(v_ru_24x31_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24101, v_x_24109}), v_j_24110});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24111}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24108)}});
                            }
                          } else {
                            heff_drop(v_x_24101);
                            heff_drop_cell(v_ru_24x31_24100_24MkPair, 2);
                            heff_drop(v_field_24106);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24100)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2499)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str9), 2)) {
                      heff_drop(v_x2_241);
                      V v_x3_24113 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                      switch (heff_tag_of(v_x3_24113)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_24114 = heff_field(v_x3_24113, 0);
                        heff_take_n(v_x3_24113, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24114)) {
                        case TAG_MkPair: {
                          V v_x_24115 = heff_field(v_x31_24114, 0);
                          V v_j_24116 = heff_field(v_x31_24114, 1);
                          V v_ru_24x31_24114_24MkPair = heff_take_reuse_n(v_x31_24114, 3ULL, 2);
                          HeffT2 v_t_24117 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_j_24116));
                          {
                            V v_field_24119 = v_t_24117.f[1];
                            int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
                            if ((v_tag_24118 == ((int64_t)0ULL))) {
                              V v_x31_24121 = v_field_24119;
                              switch (heff_tag_of(v_x31_24121)) {
                              case TAG_MkPair: {
                                V v_x_24122 = heff_field(v_x31_24121, 0);
                                V v_j_24123 = heff_field(v_x31_24121, 1);
                                heff_take_n(v_x31_24121, 3ULL, 2);
                                V v_x3_24124 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24123}));
                                switch (heff_tag_of(v_x3_24124)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24115);
                                  heff_drop_cell(v_ru_24x31_24114_24MkPair, 2);
                                  heff_drop(v_x_24122);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24125 = heff_field(v_x3_24124, 0);
                                  heff_take_n(v_x3_24124, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24125)) {
                                  case TAG_MkPair: {
                                    V v_x_24126 = heff_field(v_x31_24125, 0);
                                    V v_j_24127 = heff_field(v_x31_24125, 1);
                                    heff_take_n(v_x31_24125, 3ULL, 2);
                                    V v_t_24128 = heff_tag_at_n(v_ru_24x31_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24115, v_x_24122, v_x_24126}), v_j_24127});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24128}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24125)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24124)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24121)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 2);
                              heff_drop(v_z_242);
                              heff_drop(v_x_24115);
                              heff_drop_cell(v_ru_24x31_24114_24MkPair, 2);
                              heff_drop(v_field_24119);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24114)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_24113)}});
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str10), 2)) {
                        heff_drop(v_x2_241);
                        V v_x3_24130 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_24130)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_24131 = heff_field(v_x3_24130, 0);
                          V v_ru_24x3_24130_24Just = heff_take_reuse_n(v_x3_24130, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24131)) {
                          case TAG_MkPair: {
                            V v_x_24132 = heff_field(v_x31_24131, 0);
                            V v_j_24133 = heff_field(v_x31_24131, 1);
                            V v_ru_24x31_24131_24MkPair = heff_take_reuse_n(v_x31_24131, 3ULL, 2);
                            V v_t_24134 = heff_tag_at_n(v_ru_24x31_24131_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24130_24Just, TAG_SIs, 1, (V[]){v_x_24132}), v_j_24133});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24134}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24131)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_24130)}});
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str11), 2)) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_x2_241);
                          heff_drop(v_z_242);
                          V v_t_24136 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_243});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24136}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_x2_241);
                            heff_drop(v_z_242);
                            V v_t_24138 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_243});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24138}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str13), 2)) {
                              heff_drop(v_x2_241);
                              V v_x3_24140 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                              switch (heff_tag_of(v_x3_24140)) {
                              case TAG_Nothing: {
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24141 = heff_field(v_x3_24140, 0);
                                V v_ru_24x3_24140_24Just = heff_take_reuse_n(v_x3_24140, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24141)) {
                                case TAG_MkPair: {
                                  V v_x_24142 = heff_field(v_x31_24141, 0);
                                  V v_j_24143 = heff_field(v_x31_24141, 1);
                                  V v_ru_24x31_24141_24MkPair = heff_take_reuse_n(v_x31_24141, 3ULL, 2);
                                  V v_t_24144 = heff_tag_at_n(v_ru_24x31_24141_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24140_24Just, TAG_SRec, 1, (V[]){v_x_24142}), v_j_24143});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24144}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24141)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24140)}});
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str14), 2)) {
                                heff_drop(v_x2_241);
                                V v_x3_24146 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                                switch (heff_tag_of(v_x3_24146)) {
                                case TAG_Nothing: {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24147 = heff_field(v_x3_24146, 0);
                                  heff_take_n(v_x3_24146, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24147)) {
                                  case TAG_MkPair: {
                                    V v_x_24148 = heff_field(v_x31_24147, 0);
                                    V v_j_24149 = heff_field(v_x31_24147, 1);
                                    V v_ru_24x31_24147_24MkPair = heff_take_reuse_n(v_x31_24147, 3ULL, 2);
                                    HeffT2 v_t_24150 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_242), v_j_24149));
                                    {
                                      V v_field_24152 = v_t_24150.f[1];
                                      int64_t v_tag_24151 = ((int64_t)v_t_24150.f[0]);
                                      V v_x3_24157;
                                      if ((v_tag_24151 == ((int64_t)0ULL))) {
                                        V v_x31_24154 = v_field_24152;
                                        switch (heff_tag_of(v_x31_24154)) {
                                        case TAG_MkPair: {
                                          V v_x_24155 = heff_field(v_x31_24154, 0);
                                          V v_j_24156 = heff_field(v_x31_24154, 1);
                                          heff_take_n(v_x31_24154, 3ULL, 2);
                                          v_x3_24157 = (g_heff_2ebuild_2eserial_2eabsOf(heff_get_n(v_k_240, 0, 2), v_x_24155, v_z_242, v_j_24156));
                                          break;
                                        }
                                        default: heff_nomatch(v_x31_24154);
                                        }
                                      } else {
                                        heff_drop_rec(v_k_240, 2);
                                        heff_drop(v_z_242);
                                        heff_drop(v_field_24152);
                                        v_x3_24157 = NTAG(TAG_Nothing);
                                      }
                                      switch (heff_tag_of(v_x3_24157)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_x_24148);
                                        heff_drop_cell(v_ru_24x31_24147_24MkPair, 2);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                      case TAG_Just: {
                                        V v_x31_24158 = heff_field(v_x3_24157, 0);
                                        heff_take_n(v_x3_24157, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24158)) {
                                        case TAG_MkPair: {
                                          V v_x_24159 = heff_field(v_x31_24158, 0);
                                          V v_j_24160 = heff_field(v_x31_24158, 1);
                                          heff_take_n(v_x31_24158, 3ULL, 2);
                                          V v_t_24161 = heff_tag_at_n(v_ru_24x31_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24148, v_x_24159}), v_j_24160});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24161}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24158)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x3_24157)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24147)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24146)}});
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str15), 2)) {
                                  heff_drop(v_x2_241);
                                  HeffT2 v_t_24163 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                                  {
                                    V v_field_24165 = v_t_24163.f[1];
                                    int64_t v_tag_24164 = ((int64_t)v_t_24163.f[0]);
                                    if ((v_tag_24164 == ((int64_t)0ULL))) {
                                      V v_x31_24167 = v_field_24165;
                                      switch (heff_tag_of(v_x31_24167)) {
                                      case TAG_MkPair: {
                                        V v_x_24168 = heff_field(v_x31_24167, 0);
                                        V v_j_24169 = heff_field(v_x31_24167, 1);
                                        V v_ru_24x31_24167_24MkPair = heff_take_reuse_n(v_x31_24167, 3ULL, 2);
                                        V v_x3_24170 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24169}));
                                        switch (heff_tag_of(v_x3_24170)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24168);
                                          heff_drop_cell(v_ru_24x31_24167_24MkPair, 2);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24171 = heff_field(v_x3_24170, 0);
                                          heff_take_n(v_x3_24170, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24171)) {
                                          case TAG_MkPair: {
                                            V v_x_24172 = heff_field(v_x31_24171, 0);
                                            V v_j_24173 = heff_field(v_x31_24171, 1);
                                            heff_take_n(v_x31_24171, 3ULL, 2);
                                            V v_t_24174 = heff_tag_at_n(v_ru_24x31_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24168, v_x_24172}), v_j_24173});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24174}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24171)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24170)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24167)}});
                                      }
                                    } else {
                                      heff_drop_rec(v_k_240, 2);
                                      heff_drop(v_z_242);
                                      heff_drop(v_field_24165);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str16), 2)) {
                                    heff_drop(v_x2_241);
                                    HeffT2 v_t_24176 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                    {
                                      V v_field_24178 = v_t_24176.f[1];
                                      int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
                                      if ((v_tag_24177 == ((int64_t)0ULL))) {
                                        V v_x31_24180 = v_field_24178;
                                        switch (heff_tag_of(v_x31_24180)) {
                                        case TAG_MkPair: {
                                          V v_x_24181 = heff_field(v_x31_24180, 0);
                                          V v_j_24182 = heff_field(v_x31_24180, 1);
                                          V v_ru_24x31_24180_24MkPair = heff_take_reuse_n(v_x31_24180, 3ULL, 2);
                                          V v_t_24183 = heff_tag_at_n(v_ru_24x31_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24181}), v_j_24182});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24183}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24180)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24178);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str17), 2)) {
                                      heff_drop(v_x2_241);
                                      HeffT2 v_t_24185 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                      {
                                        V v_field_24187 = v_t_24185.f[1];
                                        int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
                                        if ((v_tag_24186 == ((int64_t)0ULL))) {
                                          V v_x31_24189 = v_field_24187;
                                          switch (heff_tag_of(v_x31_24189)) {
                                          case TAG_MkPair: {
                                            V v_x_24190 = heff_field(v_x31_24189, 0);
                                            V v_j_24191 = heff_field(v_x31_24189, 1);
                                            V v_ru_24x31_24189_24MkPair = heff_take_reuse_n(v_x31_24189, 3ULL, 2);
                                            V v_t_24192 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24190));
                                            V v_x_24193 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24192});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24189_24MkPair, TAG_MkPair, 2, (V[]){v_x_24193, v_j_24191})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24189)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24187);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str18), 2)) {
                                        heff_drop(v_x2_241);
                                        HeffT2 v_t_24195 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                        {
                                          V v_field_24197 = v_t_24195.f[1];
                                          int64_t v_tag_24196 = ((int64_t)v_t_24195.f[0]);
                                          if ((v_tag_24196 == ((int64_t)0ULL))) {
                                            V v_x31_24199 = v_field_24197;
                                            switch (heff_tag_of(v_x31_24199)) {
                                            case TAG_MkPair: {
                                              V v_x_24200 = heff_field(v_x31_24199, 0);
                                              V v_j_24201 = heff_field(v_x31_24199, 1);
                                              V v_ru_24x31_24199_24MkPair = heff_take_reuse_n(v_x31_24199, 3ULL, 2);
                                              V v_x2_24202 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str19), heff_dup(v_x_24200), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str20), v_x_24200, MK_INT(0LL)), NTAG(TAG_Nil)));
                                              V v_t_24205;
                                              switch (heff_tag_of(v_x2_24202)) {
                                              case TAG_Nil: {
                                                v_t_24205 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str21);
                                                break;
                                              }
                                              case TAG_Cons: {
                                                V v_x_24203 = heff_field(v_x2_24202, 0);
                                                V v_xs_24204 = heff_field(v_x2_24202, 1);
                                                heff_take_n(v_x2_24202, 3ULL, 2);
                                                v_t_24205 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str22); V a_1 = v_x_24203; V a_2 = v_xs_24204; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24204); r_; });
                                                break;
                                              }
                                              default: heff_nomatch(v_x2_24202);
                                              }
                                              double v_t_24206 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24205));
                                              V v_x_24207 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24206)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24199_24MkPair, TAG_MkPair, 2, (V[]){v_x_24207, v_j_24201})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24199)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24197);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str23), 2)) {
                                          heff_drop(v_x2_241);
                                          HeffT2 v_t_24209 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                          {
                                            V v_field_24211 = v_t_24209.f[1];
                                            int64_t v_tag_24210 = ((int64_t)v_t_24209.f[0]);
                                            if ((v_tag_24210 == ((int64_t)0ULL))) {
                                              V v_x31_24213 = v_field_24211;
                                              switch (heff_tag_of(v_x31_24213)) {
                                              case TAG_MkPair: {
                                                V v_x_24214 = heff_field(v_x31_24213, 0);
                                                V v_j_24215 = heff_field(v_x31_24213, 1);
                                                V v_ru_24x31_24213_24MkPair = heff_take_reuse_n(v_x31_24213, 3ULL, 2);
                                                V v_t_24216 = heff_tag_at_n(v_ru_24x31_24213_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24214}), v_j_24215});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24216}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24213)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24211);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str24), 2)) {
                                            heff_drop(v_x2_241);
                                            HeffT2 v_t_24218 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                            {
                                              V v_field_24220 = v_t_24218.f[1];
                                              int64_t v_tag_24219 = ((int64_t)v_t_24218.f[0]);
                                              if ((v_tag_24219 == ((int64_t)0ULL))) {
                                                V v_x31_24222 = v_field_24220;
                                                switch (heff_tag_of(v_x31_24222)) {
                                                case TAG_MkPair: {
                                                  V v_x_24223 = heff_field(v_x31_24222, 0);
                                                  V v_j_24224 = heff_field(v_x31_24222, 1);
                                                  V v_ru_24x31_24222_24MkPair = heff_take_reuse_n(v_x31_24222, 3ULL, 2);
                                                  V v_t_24225 = heff_tag_at_n(v_ru_24x31_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24223}), v_j_24224});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24225}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24222)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24220);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str25), 2)) {
                                              heff_drop(v_x2_241);
                                              HeffT2 v_t_24227 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                              {
                                                V v_field_24229 = v_t_24227.f[1];
                                                int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
                                                if ((v_tag_24228 == ((int64_t)0ULL))) {
                                                  V v_x31_24231 = v_field_24229;
                                                  switch (heff_tag_of(v_x31_24231)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24232 = heff_field(v_x31_24231, 0);
                                                    V v_j_24233 = heff_field(v_x31_24231, 1);
                                                    V v_ru_24x31_24231_24MkPair = heff_take_reuse_n(v_x31_24231, 3ULL, 2);
                                                    V v_t_24234 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24232));
                                                    V v_x_24235 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24234});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24231_24MkPair, TAG_MkPair, 2, (V[]){v_x_24235, v_j_24233})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24231)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24229);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str26), 2)) {
                                                heff_drop(v_x2_241);
                                                HeffT2 v_t_24237 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(heff_dup(v_z_242), v_z_243));
                                                {
                                                  V v_field_24239 = v_t_24237.f[1];
                                                  int64_t v_tag_24238 = ((int64_t)v_t_24237.f[0]);
                                                  if ((v_tag_24238 == ((int64_t)0ULL))) {
                                                    V v_x31_24241 = v_field_24239;
                                                    switch (heff_tag_of(v_x31_24241)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24242 = heff_field(v_x31_24241, 0);
                                                      V v_j_24243 = heff_field(v_x31_24241, 1);
                                                      V v_ru_24x31_24241_24MkPair = heff_take_reuse_n(v_x31_24241, 3ULL, 2);
                                                      HeffT2 v_t_24244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24243));
                                                      {
                                                        V v_field_24246 = v_t_24244.f[1];
                                                        int64_t v_tag_24245 = ((int64_t)v_t_24244.f[0]);
                                                        if ((v_tag_24245 == ((int64_t)0ULL))) {
                                                          V v_x31_24248 = v_field_24246;
                                                          switch (heff_tag_of(v_x31_24248)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24249 = heff_field(v_x31_24248, 0);
                                                            V v_j_24250 = heff_field(v_x31_24248, 1);
                                                            V v_ru_24x31_24248_24MkPair = heff_take_reuse_n(v_x31_24248, 3ULL, 2);
                                                            V v_t_24251 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24249));
                                                            V v_x_24252 = heff_tag_at_n(v_ru_24x31_24248_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24242, v_t_24251});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24241_24MkPair, TAG_MkPair, 2, (V[]){v_x_24252, v_j_24250})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24248)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24242);
                                                          heff_drop_cell(v_ru_24x31_24241_24MkPair, 2);
                                                          heff_drop(v_field_24246);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24241)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24239);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str27))) {
                                                  HeffT2 v_t_24254 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                                  {
                                                    V v_field_24256 = v_t_24254.f[1];
                                                    int64_t v_tag_24255 = ((int64_t)v_t_24254.f[0]);
                                                    if ((v_tag_24255 == ((int64_t)0ULL))) {
                                                      V v_x31_24258 = v_field_24256;
                                                      switch (heff_tag_of(v_x31_24258)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24259 = heff_field(v_x31_24258, 0);
                                                        V v_j_24260 = heff_field(v_x31_24258, 1);
                                                        V v_ru_24x31_24258_24MkPair = heff_take_reuse_n(v_x31_24258, 3ULL, 2);
                                                        V v_x2_24261 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str28), heff_dup(v_x_24259), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str29), v_x_24259, MK_INT(0LL)), NTAG(TAG_Nil)));
                                                        V v_t_24264;
                                                        switch (heff_tag_of(v_x2_24261)) {
                                                        case TAG_Nil: {
                                                          v_t_24264 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str30);
                                                          break;
                                                        }
                                                        case TAG_Cons: {
                                                          V v_x_24262 = heff_field(v_x2_24261, 0);
                                                          V v_xs_24263 = heff_field(v_x2_24261, 1);
                                                          heff_take_n(v_x2_24261, 3ULL, 2);
                                                          v_t_24264 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str31); V a_1 = v_x_24262; V a_2 = v_xs_24263; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24263); r_; });
                                                          break;
                                                        }
                                                        default: heff_nomatch(v_x2_24261);
                                                        }
                                                        double v_t_24265 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24264));
                                                        V v_x_24266 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24265)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24258_24MkPair, TAG_MkPair, 2, (V[]){v_x_24266, v_j_24260})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24258)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24256);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_x2_241);
    return (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(v_z_242, v_z_243));
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1), 2)) {
      heff_drop(v_x2_241);
      V v_x3_246 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_246_24Just, TAG_SDecode, 1, (V[]){v_x_248}), v_j_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_246)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2), 2)) {
        heff_drop(v_x2_241);
        HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(heff_dup(v_z_242), v_z_243));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x31_2416 = v_field_2414;
            switch (heff_tag_of(v_x31_2416)) {
            case TAG_MkPair: {
              V v_x_2417 = heff_field(v_x31_2416, 0);
              V v_j_2418 = heff_field(v_x31_2416, 1);
              V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
              V v_x3_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_z_242), v_j_2418}));
              switch (heff_tag_of(v_x3_2419)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                heff_drop(v_x_2417);
                heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2420 = heff_field(v_x3_2419, 0);
                heff_take_n(v_x3_2419, 1ULL, 1);
                switch (heff_tag_of(v_x31_2420)) {
                case TAG_MkPair: {
                  V v_x_2421 = heff_field(v_x31_2420, 0);
                  V v_j_2422 = heff_field(v_x31_2420, 1);
                  heff_take_n(v_x31_2420, 3ULL, 2);
                  HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_242), v_j_2422));
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    V v_x3_2430;
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      V v_x31_2427 = v_field_2425;
                      switch (heff_tag_of(v_x31_2427)) {
                      case TAG_MkPair: {
                        V v_x_2428 = heff_field(v_x31_2427, 0);
                        V v_j_2429 = heff_field(v_x31_2427, 1);
                        heff_take_n(v_x31_2427, 3ULL, 2);
                        v_x3_2430 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(v_k_240, 1)), v_x_2428, heff_dup(v_z_242), v_j_2429));
                        break;
                      }
                      default: heff_nomatch(v_x31_2427);
                      }
                    } else {
                      heff_drop(v_field_2425);
                      v_x3_2430 = NTAG(TAG_Nothing);
                    }
                    switch (heff_tag_of(v_x3_2430)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_x_2417);
                      heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                      heff_drop(v_x_2421);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2431 = heff_field(v_x3_2430, 0);
                      heff_take_n(v_x3_2430, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2431)) {
                      case TAG_MkPair: {
                        V v_x_2432 = heff_field(v_x31_2431, 0);
                        V v_j_2433 = heff_field(v_x31_2431, 1);
                        heff_take_n(v_x31_2431, 3ULL, 2);
                        HeffT2 v_t_2434 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(heff_dup(v_z_242), v_j_2433));
                        {
                          V v_field_2436 = v_t_2434.f[1];
                          int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
                          if ((v_tag_2435 == ((int64_t)0ULL))) {
                            V v_x31_2438 = v_field_2436;
                            switch (heff_tag_of(v_x31_2438)) {
                            case TAG_MkPair: {
                              V v_x_2439 = heff_field(v_x31_2438, 0);
                              V v_j_2440 = heff_field(v_x31_2438, 1);
                              heff_take_n(v_x31_2438, 3ULL, 2);
                              V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                              V v_x3_2442 = heff_tr(g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(v_t_2441, v_z_242, v_j_2440));
                              switch (heff_tag_of(v_x3_2442)) {
                              case TAG_Nothing: {
                                heff_drop(v_x_2417);
                                heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                heff_drop(v_x_2421);
                                heff_drop(v_x_2432);
                                heff_drop(v_x_2439);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_2443 = heff_field(v_x3_2442, 0);
                                heff_take_n(v_x3_2442, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2443)) {
                                case TAG_MkPair: {
                                  V v_x_2444 = heff_field(v_x31_2443, 0);
                                  V v_j_2445 = heff_field(v_x31_2443, 1);
                                  heff_take_n(v_x31_2443, 3ULL, 2);
                                  V v_t_2446 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2417, v_x_2421, v_x_2432, v_x_2439, v_x_2444}), v_j_2445});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2446}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_2443)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_2442)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2438)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2417);
                            heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                            heff_drop(v_x_2421);
                            heff_drop(v_x_2432);
                            heff_drop(v_field_2436);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2431)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2430)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2420)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2419)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            heff_drop(v_field_2414);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3), 2)) {
          heff_drop(v_x2_241);
          HeffT2 v_t_2448 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(heff_dup(v_z_242), v_z_243));
          {
            V v_field_2450 = v_t_2448.f[1];
            int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
            if ((v_tag_2449 == ((int64_t)0ULL))) {
              V v_x31_2452 = v_field_2450;
              switch (heff_tag_of(v_x31_2452)) {
              case TAG_MkPair: {
                V v_x_2453 = heff_field(v_x31_2452, 0);
                V v_j_2454 = heff_field(v_x31_2452, 1);
                V v_ru_24x31_2452_24MkPair = heff_take_reuse_n(v_x31_2452, 3ULL, 2);
                HeffT2 v_t_2455 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_take_field(v_k_240, 1), heff_dup(v_z_242), v_j_2454));
                {
                  V v_field_2457 = v_t_2455.f[1];
                  int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
                  if ((v_tag_2456 == ((int64_t)0ULL))) {
                    V v_x31_2459 = v_field_2457;
                    switch (heff_tag_of(v_x31_2459)) {
                    case TAG_MkPair: {
                      V v_x_2460 = heff_field(v_x31_2459, 0);
                      V v_j_2461 = heff_field(v_x31_2459, 1);
                      heff_take_n(v_x31_2459, 3ULL, 2);
                      HeffT2 v_t_2462 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_j_2461));
                      {
                        V v_field_2464 = v_t_2462.f[1];
                        int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                        if ((v_tag_2463 == ((int64_t)0ULL))) {
                          V v_x31_2466 = v_field_2464;
                          switch (heff_tag_of(v_x31_2466)) {
                          case TAG_MkPair: {
                            V v_x_2467 = heff_field(v_x31_2466, 0);
                            V v_j_2468 = heff_field(v_x31_2466, 1);
                            heff_take_n(v_x31_2466, 3ULL, 2);
                            V v_t_2469 = heff_tag_at_n(v_ru_24x31_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2453, v_x_2460, v_x_2467}), v_j_2468});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2469}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2466)}});
                          }
                        } else {
                          heff_drop(v_x_2453);
                          heff_drop_cell(v_ru_24x31_2452_24MkPair, 2);
                          heff_drop(v_x_2460);
                          heff_drop(v_field_2464);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2459)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2453);
                    heff_drop_cell(v_ru_24x31_2452_24MkPair, 2);
                    heff_drop(v_field_2457);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2452)}});
              }
            } else {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop(v_field_2450);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4), 2)) {
            heff_drop(v_x2_241);
            V v_t_2471 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeFields_clo), 1, (V[]){v_k_240}));
            HeffT2 v_t_2472 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_2471, v_z_242, v_z_243));
            {
              V v_field_2474 = v_t_2472.f[1];
              int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
              if ((v_tag_2473 == ((int64_t)0ULL))) {
                V v_x31_2476 = v_field_2474;
                switch (heff_tag_of(v_x31_2476)) {
                case TAG_MkPair: {
                  V v_x_2477 = heff_field(v_x31_2476, 0);
                  V v_j_2478 = heff_field(v_x31_2476, 1);
                  V v_ru_24x31_2476_24MkPair = heff_take_reuse_n(v_x31_2476, 3ULL, 2);
                  V v_t_2479 = heff_tag_at_n(v_ru_24x31_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2477}), v_j_2478});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2479}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2476)}});
                }
              } else {
                heff_drop(v_field_2474);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5), 2)) {
              heff_drop(v_x2_241);
              V v_x3_2481 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
              switch (heff_tag_of(v_x3_2481)) {
              case TAG_Nothing: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2482 = heff_field(v_x3_2481, 0);
                V v_ru_24x3_2481_24Just = heff_take_reuse_n(v_x3_2481, 1ULL, 1);
                switch (heff_tag_of(v_x31_2482)) {
                case TAG_MkPair: {
                  V v_x_2483 = heff_field(v_x31_2482, 0);
                  V v_j_2484 = heff_field(v_x31_2482, 1);
                  V v_ru_24x31_2482_24MkPair = heff_take_reuse_n(v_x31_2482, 3ULL, 2);
                  V v_t_2485 = heff_tag_at_n(v_ru_24x31_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2481_24Just, TAG_SIsTy, 1, (V[]){v_x_2483}), v_j_2484});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2485}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2482)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2481)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6), 2)) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_x2_241);
                heff_drop(v_z_242);
                V v_t_2487 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_243});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2487}});
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7), 2)) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_x2_241);
                  heff_drop(v_z_242);
                  V v_t_2489 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_243});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2489}});
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8), 2)) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_x2_241);
                    heff_drop(v_z_242);
                    V v_t_2491 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_243});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2491}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_x2_241);
                      heff_drop(v_z_242);
                      V v_t_2493 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_243});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2493}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10), 2)) {
                        heff_drop(v_x2_241);
                        V v_x3_2495 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_2495)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_2496 = heff_field(v_x3_2495, 0);
                          V v_ru_24x3_2495_24Just = heff_take_reuse_n(v_x3_2495, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2496)) {
                          case TAG_MkPair: {
                            V v_x_2497 = heff_field(v_x31_2496, 0);
                            V v_j_2498 = heff_field(v_x31_2496, 1);
                            V v_ru_24x31_2496_24MkPair = heff_take_reuse_n(v_x31_2496, 3ULL, 2);
                            V v_t_2499 = heff_tag_at_n(v_ru_24x31_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2495_24Just, TAG_SPrimArray, 1, (V[]){v_x_2497}), v_j_2498});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2499}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2496)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_2495)}});
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11))) {
                          HeffT2 v_t_24101 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_242, v_z_243));
                          {
                            V v_field_24103 = v_t_24101.f[1];
                            int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
                            if ((v_tag_24102 == ((int64_t)0ULL))) {
                              V v_x31_24105 = v_field_24103;
                              switch (heff_tag_of(v_x31_24105)) {
                              case TAG_MkPair: {
                                V v_x_24106 = heff_field(v_x31_24105, 0);
                                V v_j_24107 = heff_field(v_x31_24105, 1);
                                V v_ru_24x31_24105_24MkPair = heff_take_reuse_n(v_x31_24105, 3ULL, 2);
                                V v_t_24108 = heff_tag_at_n(v_ru_24x31_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24106}), v_j_24107});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24108}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24105)}});
                              }
                            } else {
                              heff_drop(v_field_24103);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static HEFF_ONCE g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eserial_2edk_st)) return g_heff_2ebuild_2eserial_2edk_val;
  return heff_global(&g_heff_2ebuild_2eserial_2edk_val, &g_heff_2ebuild_2eserial_2edk_st, g_heff_2ebuild_2eserial_2edk_init);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        return (g_heff_2ebuild_2eserial_2etermOf(v_k_242, v_x_248, v_s_240, v_j_249));
      }
      default: return heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_i_2411 = args[1];
  V v_k_2412 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_s_2410), v_i_2411));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x31_2417 = v_field_2415;
      switch (heff_tag_of(v_x31_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x31_2417, 0);
        V v_j_2419 = heff_field(v_x31_2417, 1);
        heff_take_n(v_x31_2417, 3ULL, 2);
        return (g_heff_2ebuild_2eserial_2etypeOf(v_k_2412, v_x_2418, v_s_2410, v_j_2419));
      }
      default: return heff_nomatch(v_x31_2417);
      }
    } else {
      heff_drop(v_s_2410);
      heff_drop(v_k_2412);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_x3_249;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_247, heff_dup(v_s_240), v_j_248));
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_field_244);
      v_x3_249 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      heff_drop(v_s_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2410 = heff_field(v_x3_249, 0);
      heff_take_n(v_x3_249, 1ULL, 1);
      switch (heff_tag_of(v_x31_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x31_2410, 0);
        V v_j_2412 = heff_field(v_x31_2410, 1);
        V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
        HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_s_240), v_j_2412));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          V v_x3_2420;
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_x31_2417 = v_field_2415;
            switch (heff_tag_of(v_x31_2417)) {
            case TAG_MkPair: {
              V v_x_2418 = heff_field(v_x31_2417, 0);
              V v_j_2419 = heff_field(v_x31_2417, 1);
              heff_take_n(v_x31_2417, 3ULL, 2);
              v_x3_2420 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2418, v_s_240, v_j_2419));
              break;
            }
            default: heff_nomatch(v_x31_2417);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_field_2415);
            v_x3_2420 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_x3_2420)) {
          case TAG_Nothing: {
            heff_drop(v_x_2411);
            heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2421 = heff_field(v_x3_2420, 0);
            heff_take_n(v_x3_2420, 1ULL, 1);
            switch (heff_tag_of(v_x31_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x31_2421, 0);
              V v_j_2423 = heff_field(v_x31_2421, 1);
              V v_ru_24x31_2421_24MkPair = heff_take_reuse_n(v_x31_2421, 3ULL, 2);
              V v_t_2424 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2411), v_x_2422});
              V v_f_2425 = heff_tag_at_n(v_ru_24x31_2421_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_j_2423});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2421)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2420)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_249)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_x3_249;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(v_x_247, v_s_240, v_j_248));
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      v_x3_249 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2410 = heff_field(v_x3_249, 0);
      heff_take_n(v_x3_249, 1ULL, 1);
      switch (heff_tag_of(v_x31_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x31_2410, 0);
        V v_j_2412 = heff_field(v_x31_2410, 1);
        V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2411)));
        V v_t_2414 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2411));
        V v_t_2415 = (g_list_2emap_24s1173914895x100384474(v_x_2411));
        V v_x_2416 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2413), v_t_2414, heff_arrayFromList(v_t_2415)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_j_2412})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_249)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1, 1, "n");

HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_x3_2411;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_248 = v_field_246;
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          v_x3_2411 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_249, v_z_241, v_j_2410));
          break;
        }
        default: heff_nomatch(v_x31_248);
        }
      } else {
        heff_drop(v_z_241);
        heff_drop(v_field_246);
        v_x3_2411 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        V v_ru_24x3_2411_24Just = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2411_24Just, TAG_Just, 1, (V[]){v_x_2413}), v_j_2414});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_2411)}});
      }
    }
  } else {
    if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1))) {
      heff_drop(v_z_241);
      V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}