// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry, 5, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_rest_244;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246, v_rest_244));
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 0);
      V v_a_249 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_2410 = heff_intShow(heff_strLength_lent(v_a_248, 0));
      V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(v_lit_240, v_a_248));
      V v_a_2412 = heff_arrayToList(v_a_249);
      V v_a_2413 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2412));
      V v_t_2414 = ({ V a_0 = v_a_2412; V a_1 = v_a_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a_0, a_1)); heff_drop(v_a_2412); r_; });
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2413), v_t_2414});
      return heff_tag_at_n(v_ru_24x_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2411, v_t_2415});
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8, 7, "Float32");

HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1); V a_2 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2); V a_3 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3); V a_4 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4); V a_5 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5); V a_6 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6); V a_7 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7); V a_8 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8); V a_9 = v_x_246; V a_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_x_246); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2411, v_j_247})}});
          } else {
            heff_drop(v_j_247);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0, 2, 1, (V[]){v_d_240}), v_x_247, v_s_241, v_j_248));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_x31_2425 = v_field_2424;
            switch (heff_tag_of(v_x31_2425)) {
            case TAG_MkPair: {
              V v_x_2426 = heff_field(v_x31_2425, 0);
              V v_j_2427 = heff_field(v_x31_2425, 1);
              V v_ru_24x31_2425_24MkPair = heff_take_reuse_n(v_x31_2425, 3ULL, 2);
              V v_t_2428 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x31_2425_24MkPair, heff_dup(v_x_2426)));
              V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2426));
              V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2426));
              V v_x_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_j_2427})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2424);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_d_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_249, v_i_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2413;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
        V v_x3_2417 = heff_tr(heff_call(v_d_240, 2, (V[]){v_s_249, v_j_2416}));
        switch (heff_tag_of(v_x3_2417)) {
        case TAG_Nothing: {
          heff_drop(v_x_2415);
          heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2418 = heff_field(v_x3_2417, 0);
          V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            heff_take_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_x_2419}), v_j_2420});
            return heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_Just, 1, (V[]){v_t_2421});
          }
          default: return heff_nomatch(v_x31_2418);
          }
        }
        default: return heff_nomatch(v_x3_2417);
        }
      }
      default: return heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop(v_s_249);
      heff_drop(v_d_240);
      heff_drop(v_field_2413);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_247, v_s_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2412 = v_field_2411;
            switch (heff_tag_of(v_x31_2412)) {
            case TAG_MkPair: {
              V v_x_2413 = heff_field(v_x31_2412, 0);
              V v_j_2414 = heff_field(v_x31_2412, 1);
              V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
              V v_x3_2415 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_2414}));
              switch (heff_tag_of(v_x3_2415)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                heff_drop(v_x_2413);
                heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2416 = heff_field(v_x3_2415, 0);
                V v_ru_24x3_2415_24Just = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
                switch (heff_tag_of(v_x31_2416)) {
                case TAG_MkPair: {
                  V v_x_2417 = heff_field(v_x31_2416, 0);
                  V v_j_2418 = heff_field(v_x31_2416, 1);
                  heff_take_n(v_x31_2416, 3ULL, 2);
                  V v_t_2419 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2413), v_x_2417});
                  return heff_tag_at_n(v_ru_24x3_2415_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_j_2418})});
                }
                default: return heff_nomatch(v_x31_2416);
                }
              }
              default: return heff_nomatch(v_x3_2415);
              }
            }
            default: return heff_nomatch(v_x31_2412);
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_s_241);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1), 2)) {
      V v_x3_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_244)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_245 = heff_field(v_x3_244, 0);
        V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
        switch (heff_tag_of(v_x31_245)) {
        case TAG_MkPair: {
          V v_x_246 = heff_field(v_x31_245, 0);
          V v_j_247 = heff_field(v_x31_245, 1);
          V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
          V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_244_24Just, TAG_SDecode, 1, (V[]){v_x_246}), v_j_247});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2), 2)) {
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2412 = v_field_2411;
            switch (heff_tag_of(v_x31_2412)) {
            case TAG_MkPair: {
              V v_x_2413 = heff_field(v_x31_2412, 0);
              V v_j_2414 = heff_field(v_x31_2412, 1);
              V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
              V v_x3_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_z_242), v_j_2414}));
              switch (heff_tag_of(v_x3_2415)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                heff_drop(v_x_2413);
                heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2416 = heff_field(v_x3_2415, 0);
                heff_take_n(v_x3_2415, 1ULL, 1);
                switch (heff_tag_of(v_x31_2416)) {
                case TAG_MkPair: {
                  V v_x_2417 = heff_field(v_x31_2416, 0);
                  V v_j_2418 = heff_field(v_x31_2416, 1);
                  heff_take_n(v_x31_2416, 3ULL, 2);
                  HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2418));
                  {
                    V v_field_2421 = v_t_2419.f[1];
                    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                    if ((v_tag_2420 == ((int64_t)0ULL))) {
                      V v_x31_2422 = v_field_2421;
                      switch (heff_tag_of(v_x31_2422)) {
                      case TAG_MkPair: {
                        V v_x_2423 = heff_field(v_x31_2422, 0);
                        V v_j_2424 = heff_field(v_x31_2422, 1);
                        heff_take_n(v_x31_2422, 3ULL, 2);
                        HeffT2 v_t_2425 = ({ V a_0 = heff_dup(heff_rfield(v_k_240, 1)); V a_1 = v_x_2423; V a_2 = heff_dup(v_z_242); V a_3 = v_j_2424; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2423); r_; });
                        {
                          V v_field_2427 = v_t_2425.f[1];
                          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
                          if ((v_tag_2426 == ((int64_t)0ULL))) {
                            V v_x31_2428 = v_field_2427;
                            switch (heff_tag_of(v_x31_2428)) {
                            case TAG_MkPair: {
                              V v_x_2429 = heff_field(v_x31_2428, 0);
                              V v_j_2430 = heff_field(v_x31_2428, 1);
                              heff_take_n(v_x31_2428, 3ULL, 2);
                              HeffT2 v_t_2431 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_242, v_j_2430));
                              {
                                V v_field_2433 = v_t_2431.f[1];
                                int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                                if ((v_tag_2432 == ((int64_t)0ULL))) {
                                  V v_x31_2434 = v_field_2433;
                                  switch (heff_tag_of(v_x31_2434)) {
                                  case TAG_MkPair: {
                                    V v_x_2435 = heff_field(v_x31_2434, 0);
                                    V v_j_2436 = heff_field(v_x31_2434, 1);
                                    heff_take_n(v_x31_2434, 3ULL, 2);
                                    V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                                    V v_x3_2438 = heff_tr(g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(v_t_2437, v_z_242, v_j_2436));
                                    switch (heff_tag_of(v_x3_2438)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_x_2413);
                                      heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                                      heff_drop(v_x_2417);
                                      heff_drop(v_x_2429);
                                      heff_drop(v_x_2435);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_2439 = heff_field(v_x3_2438, 0);
                                      heff_take_n(v_x3_2438, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_2439)) {
                                      case TAG_MkPair: {
                                        V v_x_2440 = heff_field(v_x31_2439, 0);
                                        V v_j_2441 = heff_field(v_x31_2439, 1);
                                        heff_take_n(v_x31_2439, 3ULL, 2);
                                        V v_t_2442 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2413, v_x_2417, v_x_2429, v_x_2435, v_x_2440}), v_j_2441});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2442}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_2439)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_2438)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2434)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_2413);
                                  heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                                  heff_drop(v_x_2417);
                                  heff_drop(v_x_2429);
                                  heff_drop(v_field_2433);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2428)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2413);
                            heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                            heff_drop(v_x_2417);
                            heff_drop(v_field_2427);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2422)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_x_2413);
                      heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                      heff_drop(v_x_2417);
                      heff_drop(v_field_2421);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2415)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3), 2)) {
          HeffT2 v_t_2443 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
          {
            V v_field_2445 = v_t_2443.f[1];
            int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
            if ((v_tag_2444 == ((int64_t)0ULL))) {
              V v_x31_2446 = v_field_2445;
              switch (heff_tag_of(v_x31_2446)) {
              case TAG_MkPair: {
                V v_x_2447 = heff_field(v_x31_2446, 0);
                V v_j_2448 = heff_field(v_x31_2446, 1);
                V v_ru_24x31_2446_24MkPair = heff_take_reuse_n(v_x31_2446, 3ULL, 2);
                HeffT2 v_t_2449 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_take_field(v_k_240, 1), heff_dup(v_z_242), v_j_2448));
                {
                  V v_field_2451 = v_t_2449.f[1];
                  int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
                  if ((v_tag_2450 == ((int64_t)0ULL))) {
                    V v_x31_2452 = v_field_2451;
                    switch (heff_tag_of(v_x31_2452)) {
                    case TAG_MkPair: {
                      V v_x_2453 = heff_field(v_x31_2452, 0);
                      V v_j_2454 = heff_field(v_x31_2452, 1);
                      heff_take_n(v_x31_2452, 3ULL, 2);
                      HeffT2 v_t_2455 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_j_2454));
                      {
                        V v_field_2457 = v_t_2455.f[1];
                        int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
                        if ((v_tag_2456 == ((int64_t)0ULL))) {
                          V v_x31_2458 = v_field_2457;
                          switch (heff_tag_of(v_x31_2458)) {
                          case TAG_MkPair: {
                            V v_x_2459 = heff_field(v_x31_2458, 0);
                            V v_j_2460 = heff_field(v_x31_2458, 1);
                            heff_take_n(v_x31_2458, 3ULL, 2);
                            V v_t_2461 = heff_tag_at_n(v_ru_24x31_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2447, v_x_2453, v_x_2459}), v_j_2460});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2461}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2458)}});
                          }
                        } else {
                          heff_drop(v_x_2447);
                          heff_drop_cell(v_ru_24x31_2446_24MkPair, 2);
                          heff_drop(v_x_2453);
                          heff_drop(v_field_2457);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2452)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2447);
                    heff_drop_cell(v_ru_24x31_2446_24MkPair, 2);
                    heff_drop(v_field_2451);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2446)}});
              }
            } else {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop(v_field_2445);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4), 2)) {
            V v_t_2462 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeFields_clo), 1, (V[]){v_k_240}));
            HeffT2 v_t_2463 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_2462, v_z_242, v_z_243));
            {
              V v_field_2465 = v_t_2463.f[1];
              int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
              if ((v_tag_2464 == ((int64_t)0ULL))) {
                V v_x31_2466 = v_field_2465;
                switch (heff_tag_of(v_x31_2466)) {
                case TAG_MkPair: {
                  V v_x_2467 = heff_field(v_x31_2466, 0);
                  V v_j_2468 = heff_field(v_x31_2466, 1);
                  V v_ru_24x31_2466_24MkPair = heff_take_reuse_n(v_x31_2466, 3ULL, 2);
                  V v_t_2469 = heff_tag_at_n(v_ru_24x31_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2467}), v_j_2468});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2469}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2466)}});
                }
              } else {
                heff_drop(v_field_2465);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5), 2)) {
              V v_x3_2470 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
              switch (heff_tag_of(v_x3_2470)) {
              case TAG_Nothing: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2471 = heff_field(v_x3_2470, 0);
                V v_ru_24x3_2470_24Just = heff_take_reuse_n(v_x3_2470, 1ULL, 1);
                switch (heff_tag_of(v_x31_2471)) {
                case TAG_MkPair: {
                  V v_x_2472 = heff_field(v_x31_2471, 0);
                  V v_j_2473 = heff_field(v_x31_2471, 1);
                  V v_ru_24x31_2471_24MkPair = heff_take_reuse_n(v_x31_2471, 3ULL, 2);
                  V v_t_2474 = heff_tag_at_n(v_ru_24x31_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2470_24Just, TAG_SIsTy, 1, (V[]){v_x_2472}), v_j_2473});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2474}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2471)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2470)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6), 2)) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_243});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2475}});
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7), 2)) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  V v_t_2476 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_243});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2476}});
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8), 2)) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    V v_t_2477 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_243});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2477}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      V v_t_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_243});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2478}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10), 2)) {
                        V v_x3_2479 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_2479)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_2480 = heff_field(v_x3_2479, 0);
                          V v_ru_24x3_2479_24Just = heff_take_reuse_n(v_x3_2479, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2480)) {
                          case TAG_MkPair: {
                            V v_x_2481 = heff_field(v_x31_2480, 0);
                            V v_j_2482 = heff_field(v_x31_2480, 1);
                            V v_ru_24x31_2480_24MkPair = heff_take_reuse_n(v_x31_2480, 3ULL, 2);
                            V v_t_2483 = heff_tag_at_n(v_ru_24x31_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2479_24Just, TAG_SPrimArray, 1, (V[]){v_x_2481}), v_j_2482});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2483}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2480)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_2479)}});
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11), 2)) {
                          HeffT2 v_t_2484 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                          {
                            V v_field_2486 = v_t_2484.f[1];
                            int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
                            if ((v_tag_2485 == ((int64_t)0ULL))) {
                              V v_x31_2487 = v_field_2486;
                              switch (heff_tag_of(v_x31_2487)) {
                              case TAG_MkPair: {
                                V v_x_2488 = heff_field(v_x31_2487, 0);
                                V v_j_2489 = heff_field(v_x31_2487, 1);
                                V v_ru_24x31_2487_24MkPair = heff_take_reuse_n(v_x31_2487, 3ULL, 2);
                                V v_t_2490 = heff_tag_at_n(v_ru_24x31_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_2488}), v_j_2489});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2490}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2487)}});
                              }
                            } else {
                              heff_drop(v_field_2486);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_246, v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2418, v_s_240, v_j_2419));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          V v_t_2426 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2412), v_x_2424});
                          V v_f_2427 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_j_2425});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                        }
                      } else {
                        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                        heff_drop(v_x_2412);
                        heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                        heff_drop(v_field_2422);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                  heff_drop(v_x_2412);
                  heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                  heff_drop(v_field_2416);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}