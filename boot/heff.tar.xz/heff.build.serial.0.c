// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry, 5, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_rest_244;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246, v_rest_244));
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 0);
      V v_a_249 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_2410 = heff_intShow(heff_strLength_lent(v_a_248, 0));
      V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(v_lit_240, v_a_248));
      V v_a_2412 = heff_arrayToList(v_a_249);
      V v_a_2413 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2412));
      V v_t_2414 = ({ V a_0 = v_a_2412; V a_1 = v_a_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a_0, a_1)); heff_drop(v_a_2412); r_; });
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2413), v_t_2414});
      return heff_tag_at_n(v_ru_24x_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2411, v_t_2415});
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8, 7, "Float32");

HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1); V a_2 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2); V a_3 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3); V a_4 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4); V a_5 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5); V a_6 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6); V a_7 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7); V a_8 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8); V a_9 = v_x_247; V a_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1236173780x2048419812_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_x_247); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_j_248})}});
          } else {
            heff_drop(v_j_248);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        HeffT2 v_t_2424 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0, 2, 1, (V[]){v_d_240}), v_x_248, v_s_241, v_j_249));
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            V v_x31_2428 = v_field_2426;
            switch (heff_tag_of(v_x31_2428)) {
            case TAG_MkPair: {
              V v_x_2429 = heff_field(v_x31_2428, 0);
              V v_j_2430 = heff_field(v_x31_2428, 1);
              heff_take_n(v_x31_2428, 3ULL, 2);
              V v_t_2431 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2429)));
              V v_t_2432 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2429));
              V v_t_2433 = (g_list_2emap_24s1173914895x100384474(v_x_2429));
              V v_x_2434 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2431), v_t_2432, heff_arrayFromList(v_t_2433)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2434, v_j_2430})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2428)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
            heff_drop(v_field_2426);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
      }
    } else {
      heff_drop(v_d_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_i_2411 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_2410, v_i_2411));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x31_2416 = v_field_2414;
      switch (heff_tag_of(v_x31_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x31_2416, 0);
        V v_j_2418 = heff_field(v_x31_2416, 1);
        V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
        V v_x3_2419 = heff_tr(heff_call(v_d_240, 2, (V[]){v_s_2410, v_j_2418}));
        switch (heff_tag_of(v_x3_2419)) {
        case TAG_Nothing: {
          heff_drop(v_x_2417);
          heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2420 = heff_field(v_x3_2419, 0);
          V v_ru_24x3_2419_24Just = heff_take_reuse_n(v_x3_2419, 1ULL, 1);
          switch (heff_tag_of(v_x31_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x31_2420, 0);
            V v_j_2422 = heff_field(v_x31_2420, 1);
            heff_take_n(v_x31_2420, 3ULL, 2);
            V v_t_2423 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_x_2421}), v_j_2422});
            return heff_tag_at_n(v_ru_24x3_2419_24Just, TAG_Just, 1, (V[]){v_t_2423});
          }
          default: return heff_nomatch(v_x31_2420);
          }
        }
        default: return heff_nomatch(v_x3_2419);
        }
      }
      default: return heff_nomatch(v_x31_2416);
      }
    } else {
      heff_drop(v_s_2410);
      heff_drop(v_d_240);
      heff_drop(v_field_2414);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_248, v_s_241, v_j_249));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_x31_2414 = v_field_2412;
            switch (heff_tag_of(v_x31_2414)) {
            case TAG_MkPair: {
              V v_x_2415 = heff_field(v_x31_2414, 0);
              V v_j_2416 = heff_field(v_x31_2414, 1);
              V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
              V v_x3_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_2416}));
              switch (heff_tag_of(v_x3_2417)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                heff_drop(v_x_2415);
                heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2418 = heff_field(v_x3_2417, 0);
                V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
                switch (heff_tag_of(v_x31_2418)) {
                case TAG_MkPair: {
                  V v_x_2419 = heff_field(v_x31_2418, 0);
                  V v_j_2420 = heff_field(v_x31_2418, 1);
                  heff_take_n(v_x31_2418, 3ULL, 2);
                  V v_t_2421 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2415), v_x_2419});
                  return heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, v_j_2420})});
                }
                default: return heff_nomatch(v_x31_2418);
                }
              }
              default: return heff_nomatch(v_x3_2417);
              }
            }
            default: return heff_nomatch(v_x31_2414);
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_s_241);
            heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
            heff_drop(v_field_2412);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1), 2)) {
      V v_x3_246 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_246_24Just, TAG_SDecode, 1, (V[]){v_x_248}), v_j_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_246)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2), 2)) {
        HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x31_2416 = v_field_2414;
            switch (heff_tag_of(v_x31_2416)) {
            case TAG_MkPair: {
              V v_x_2417 = heff_field(v_x31_2416, 0);
              V v_j_2418 = heff_field(v_x31_2416, 1);
              V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
              V v_x3_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_z_242), v_j_2418}));
              switch (heff_tag_of(v_x3_2419)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                heff_drop(v_x_2417);
                heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2420 = heff_field(v_x3_2419, 0);
                heff_take_n(v_x3_2419, 1ULL, 1);
                switch (heff_tag_of(v_x31_2420)) {
                case TAG_MkPair: {
                  V v_x_2421 = heff_field(v_x31_2420, 0);
                  V v_j_2422 = heff_field(v_x31_2420, 1);
                  heff_take_n(v_x31_2420, 3ULL, 2);
                  HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2422));
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      V v_x31_2427 = v_field_2425;
                      switch (heff_tag_of(v_x31_2427)) {
                      case TAG_MkPair: {
                        V v_x_2428 = heff_field(v_x31_2427, 0);
                        V v_j_2429 = heff_field(v_x31_2427, 1);
                        heff_take_n(v_x31_2427, 3ULL, 2);
                        HeffT2 v_t_2430 = ({ V a_0 = heff_dup(heff_rfield(v_k_240, 1)); V a_1 = v_x_2428; V a_2 = heff_dup(v_z_242); V a_3 = v_j_2429; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2428); r_; });
                        {
                          V v_field_2432 = v_t_2430.f[1];
                          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                          if ((v_tag_2431 == ((int64_t)0ULL))) {
                            V v_x31_2434 = v_field_2432;
                            switch (heff_tag_of(v_x31_2434)) {
                            case TAG_MkPair: {
                              V v_x_2435 = heff_field(v_x31_2434, 0);
                              V v_j_2436 = heff_field(v_x31_2434, 1);
                              heff_take_n(v_x31_2434, 3ULL, 2);
                              HeffT2 v_t_2437 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_242, v_j_2436));
                              {
                                V v_field_2439 = v_t_2437.f[1];
                                int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
                                if ((v_tag_2438 == ((int64_t)0ULL))) {
                                  V v_x31_2441 = v_field_2439;
                                  switch (heff_tag_of(v_x31_2441)) {
                                  case TAG_MkPair: {
                                    V v_x_2442 = heff_field(v_x31_2441, 0);
                                    V v_j_2443 = heff_field(v_x31_2441, 1);
                                    heff_take_n(v_x31_2441, 3ULL, 2);
                                    V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                                    V v_x3_2445 = heff_tr(g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(v_t_2444, v_z_242, v_j_2443));
                                    switch (heff_tag_of(v_x3_2445)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_x_2417);
                                      heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                      heff_drop(v_x_2421);
                                      heff_drop(v_x_2435);
                                      heff_drop(v_x_2442);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_2446 = heff_field(v_x3_2445, 0);
                                      heff_take_n(v_x3_2445, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_2446)) {
                                      case TAG_MkPair: {
                                        V v_x_2447 = heff_field(v_x31_2446, 0);
                                        V v_j_2448 = heff_field(v_x31_2446, 1);
                                        heff_take_n(v_x31_2446, 3ULL, 2);
                                        V v_t_2449 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2417, v_x_2421, v_x_2435, v_x_2442, v_x_2447}), v_j_2448});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2449}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_2446)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_2445)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_2417);
                                  heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                  heff_drop(v_x_2421);
                                  heff_drop(v_x_2435);
                                  heff_drop(v_field_2439);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2434)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2417);
                            heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                            heff_drop(v_x_2421);
                            heff_drop(v_field_2432);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2427)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_x_2417);
                      heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                      heff_drop(v_x_2421);
                      heff_drop(v_field_2425);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2420)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2419)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            heff_drop(v_field_2414);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3), 2)) {
          HeffT2 v_t_2451 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
          {
            V v_field_2453 = v_t_2451.f[1];
            int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
            if ((v_tag_2452 == ((int64_t)0ULL))) {
              V v_x31_2455 = v_field_2453;
              switch (heff_tag_of(v_x31_2455)) {
              case TAG_MkPair: {
                V v_x_2456 = heff_field(v_x31_2455, 0);
                V v_j_2457 = heff_field(v_x31_2455, 1);
                V v_ru_24x31_2455_24MkPair = heff_take_reuse_n(v_x31_2455, 3ULL, 2);
                HeffT2 v_t_2458 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_take_field(v_k_240, 1), heff_dup(v_z_242), v_j_2457));
                {
                  V v_field_2460 = v_t_2458.f[1];
                  int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
                  if ((v_tag_2459 == ((int64_t)0ULL))) {
                    V v_x31_2462 = v_field_2460;
                    switch (heff_tag_of(v_x31_2462)) {
                    case TAG_MkPair: {
                      V v_x_2463 = heff_field(v_x31_2462, 0);
                      V v_j_2464 = heff_field(v_x31_2462, 1);
                      heff_take_n(v_x31_2462, 3ULL, 2);
                      HeffT2 v_t_2465 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_j_2464));
                      {
                        V v_field_2467 = v_t_2465.f[1];
                        int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                        if ((v_tag_2466 == ((int64_t)0ULL))) {
                          V v_x31_2469 = v_field_2467;
                          switch (heff_tag_of(v_x31_2469)) {
                          case TAG_MkPair: {
                            V v_x_2470 = heff_field(v_x31_2469, 0);
                            V v_j_2471 = heff_field(v_x31_2469, 1);
                            heff_take_n(v_x31_2469, 3ULL, 2);
                            V v_t_2472 = heff_tag_at_n(v_ru_24x31_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2456, v_x_2463, v_x_2470}), v_j_2471});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2472}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2469)}});
                          }
                        } else {
                          heff_drop(v_x_2456);
                          heff_drop_cell(v_ru_24x31_2455_24MkPair, 2);
                          heff_drop(v_x_2463);
                          heff_drop(v_field_2467);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2462)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2456);
                    heff_drop_cell(v_ru_24x31_2455_24MkPair, 2);
                    heff_drop(v_field_2460);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2455)}});
              }
            } else {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop(v_field_2453);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4), 2)) {
            V v_t_2474 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeFields_clo), 1, (V[]){v_k_240}));
            HeffT2 v_t_2475 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_2474, v_z_242, v_z_243));
            {
              V v_field_2477 = v_t_2475.f[1];
              int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
              if ((v_tag_2476 == ((int64_t)0ULL))) {
                V v_x31_2479 = v_field_2477;
                switch (heff_tag_of(v_x31_2479)) {
                case TAG_MkPair: {
                  V v_x_2480 = heff_field(v_x31_2479, 0);
                  V v_j_2481 = heff_field(v_x31_2479, 1);
                  V v_ru_24x31_2479_24MkPair = heff_take_reuse_n(v_x31_2479, 3ULL, 2);
                  V v_t_2482 = heff_tag_at_n(v_ru_24x31_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2480}), v_j_2481});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2482}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2479)}});
                }
              } else {
                heff_drop(v_field_2477);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5), 2)) {
              V v_x3_2484 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
              switch (heff_tag_of(v_x3_2484)) {
              case TAG_Nothing: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2485 = heff_field(v_x3_2484, 0);
                V v_ru_24x3_2484_24Just = heff_take_reuse_n(v_x3_2484, 1ULL, 1);
                switch (heff_tag_of(v_x31_2485)) {
                case TAG_MkPair: {
                  V v_x_2486 = heff_field(v_x31_2485, 0);
                  V v_j_2487 = heff_field(v_x31_2485, 1);
                  V v_ru_24x31_2485_24MkPair = heff_take_reuse_n(v_x31_2485, 3ULL, 2);
                  V v_t_2488 = heff_tag_at_n(v_ru_24x31_2485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2484_24Just, TAG_SIsTy, 1, (V[]){v_x_2486}), v_j_2487});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2488}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2485)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2484)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6), 2)) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                V v_t_2490 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_243});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2490}});
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7), 2)) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  V v_t_2492 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_243});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2492}});
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8), 2)) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    V v_t_2494 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_243});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2494}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      V v_t_2496 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_243});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2496}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10), 2)) {
                        V v_x3_2498 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_2498)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_2499 = heff_field(v_x3_2498, 0);
                          V v_ru_24x3_2498_24Just = heff_take_reuse_n(v_x3_2498, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2499)) {
                          case TAG_MkPair: {
                            V v_x_24100 = heff_field(v_x31_2499, 0);
                            V v_j_24101 = heff_field(v_x31_2499, 1);
                            V v_ru_24x31_2499_24MkPair = heff_take_reuse_n(v_x31_2499, 3ULL, 2);
                            V v_t_24102 = heff_tag_at_n(v_ru_24x31_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2498_24Just, TAG_SPrimArray, 1, (V[]){v_x_24100}), v_j_24101});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24102}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2499)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_2498)}});
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11), 2)) {
                          HeffT2 v_t_24104 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                          {
                            V v_field_24106 = v_t_24104.f[1];
                            int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
                            if ((v_tag_24105 == ((int64_t)0ULL))) {
                              V v_x31_24108 = v_field_24106;
                              switch (heff_tag_of(v_x31_24108)) {
                              case TAG_MkPair: {
                                V v_x_24109 = heff_field(v_x31_24108, 0);
                                V v_j_24110 = heff_field(v_x31_24108, 1);
                                V v_ru_24x31_24108_24MkPair = heff_take_reuse_n(v_x31_24108, 3ULL, 2);
                                V v_t_24111 = heff_tag_at_n(v_ru_24x31_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24109}), v_j_24110});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24111}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24108)}});
                              }
                            } else {
                              heff_drop(v_field_24106);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_247, v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_j_2415));
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_x31_2420 = v_field_2418;
                  switch (heff_tag_of(v_x31_2420)) {
                  case TAG_MkPair: {
                    V v_x_2421 = heff_field(v_x31_2420, 0);
                    V v_j_2422 = heff_field(v_x31_2420, 1);
                    heff_take_n(v_x31_2420, 3ULL, 2);
                    HeffT2 v_t_2423 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2421, v_s_240, v_j_2422));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        V v_x31_2427 = v_field_2425;
                        switch (heff_tag_of(v_x31_2427)) {
                        case TAG_MkPair: {
                          V v_x_2428 = heff_field(v_x31_2427, 0);
                          V v_j_2429 = heff_field(v_x31_2427, 1);
                          heff_take_n(v_x31_2427, 3ULL, 2);
                          V v_t_2430 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2414), v_x_2428});
                          V v_f_2431 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_j_2429});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2427)}});
                        }
                      } else {
                        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                        heff_drop(v_x_2414);
                        heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                        heff_drop(v_field_2425);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2420)}});
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                  heff_drop(v_x_2414);
                  heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                  heff_drop(v_field_2418);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
            }
          } else {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}