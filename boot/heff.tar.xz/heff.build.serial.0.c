// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_clo;
V g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826(V, V);
V g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_clo;
V g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555(V, V);
V g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_clo;
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    V v_t_246 = heff_intShow(heff_strLength(heff_dup(v_x_243)));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_lit_240, v_x_243));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_a_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SmallU: {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
    }
    case TAG_LargeU: {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_x2_240, 0);
    V v_t_247 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_246), v_rest_241));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4), v_t_247}));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_240, 0);
    V v_dom_249 = heff_field(v_x2_240, 1);
    V v_cod_2410 = heff_field(v_x2_240, 2);
    V v_implicit_2411 = heff_field(v_x2_240, 3);
    V v_dflt_2412 = heff_field(v_x2_240, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2412, 0);
      V v_t_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2415), v_rest_241));
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12), v_t_2416});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
    V v_rest_2426;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_cod_2410, 0);
      V v_e_2420 = heff_field(v_cod_2410, 1);
      V v_t_2421 = heff_intShow(heff_strLength(heff_dup(v_x_2419)));
      V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13), heff_dup(v_x_2419)));
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2420, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2424 = heff_field(v_cod_2410, 0);
      V v_t_2425 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2424, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15), v_t_2425});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_t_2427 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_249, v_rest_2426));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2427})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_SRecord: {
    V v_level_2429 = heff_field(v_x2_240, 0);
    V v_fs_2430 = heff_field(v_x2_240, 1);
    V v_ds_2431 = heff_field(v_x2_240, 2);
    V v_t_2432;
    switch (heff_tag_of(v_level_2429)) {
    case TAG_Small: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17);
      break;
    }
    case TAG_Large: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19);
      break;
    }
    default: heff_nomatch(v_level_2429);
    }
    V v_t_2433 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2431, 0)));
    V v_t_2434 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2431, 2)));
    V v_xs_2435 = (g_heff_2eutil_2edict_2ezipKV(v_t_2433, v_t_2434));
    V v_i_2436 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2435));
    V v_t_2437 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s696045617x445516606(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20), v_xs_2435, v_rest_241));
    V v_rest_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2436), v_t_2437});
    V v_t_2439 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2430, 0)));
    V v_t_2440 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2430, 2)));
    V v_xs_2441 = (g_heff_2eutil_2edict_2ezipKV(v_t_2439, v_t_2440));
    V v_i_2442 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s117135519x904453810(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21), v_xs_2441, v_rest_2438));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2444})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2445);
  }
  case TAG_SSum: {
    V v_vs_2446 = heff_field(v_x2_240, 0);
    V v_t_2447 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2446, 0)));
    V v_t_2448 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2446, 2)));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_i_2450 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1401444394x1332587816(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2449, v_rest_241));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24), v_t_2452}));
  }
  case TAG_SIsTy: {
    V v_t2_2453 = heff_field(v_x2_240, 0);
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25), heff_hole()});
    V v_u_2455 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2454));
    heff_drop(v_u_2455);
    V t_0 = v_t2_2453;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2454;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrimInt: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26), v_rest_241}));
  }
  case TAG_SPrimFloat: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27), v_rest_241}));
  }
  case TAG_SPrimString: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28), v_rest_241}));
  }
  case TAG_SPrimRune: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29), v_rest_241}));
  }
  case TAG_SPrimArray: {
    V v_t2_2456 = heff_field(v_x2_240, 0);
    V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30), heff_hole()});
    V v_u_2458 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2457));
    heff_drop(v_u_2458);
    V t_0 = v_t2_2456;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2457;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFixed: {
    V v_w_2459 = heff_field(v_x2_240, 0);
    V v_t_2460;
    switch (heff_tag_of(v_w_2459)) {
    case TAG_I8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31);
      break;
    }
    case TAG_I16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32);
      break;
    }
    case TAG_I32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33);
      break;
    }
    case TAG_I64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34);
      break;
    }
    case TAG_U8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35);
      break;
    }
    case TAG_U16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36);
      break;
    }
    case TAG_U32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37);
      break;
    }
    case TAG_U64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38);
      break;
    }
    case TAG_F32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39);
      break;
    }
    default: heff_nomatch(v_w_2459);
    }
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2461);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
      V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_lit_240, v_a_249));
      V v_t_2419;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s1116451536x2100070357(v_lit_241, v_lit_242, v_a_2415));
        V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1914760479x1465888403(v_lit_243, v_a_2415, v_a_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), v_t_2418});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2105934144x1917611171(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_i_242));
  V v_x3_247;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      v_x3_247 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_245, heff_dup(v_s_241), v_j_246));
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    V v_ru_24x3_247_24Just = heff_take_reuse_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
      V v_x3_2411 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_2410}));
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_247_24Just, 1);
        heff_drop(v_x_249);
        heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        heff_take_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          heff_take_n(v_x31_2412, 3ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_249), v_x_2413});
          return heff_tag_at_n(v_ru_24x3_247_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_j_2414})});
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2411);
      }
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static HEFF_ONCE g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eserial_2edk_st)) return g_heff_2ebuild_2eserial_2edk_val;
  return heff_global(&g_heff_2ebuild_2eserial_2edk_val, &g_heff_2ebuild_2eserial_2edk_st, g_heff_2ebuild_2eserial_2edk_init);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_k_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      return (g_heff_2ebuild_2eserial_2etermOf(v_k_242, v_x_245, v_s_240, v_j_246));
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_i_248 = args[1];
  V v_k_249 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_247), v_i_248));
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    heff_drop(v_s_247);
    heff_drop(v_k_249);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2411 = heff_field(v_x3_2410, 0);
    heff_take_n(v_x3_2410, 1ULL, 1);
    switch (heff_tag_of(v_x31_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x31_2411, 0);
      V v_j_2413 = heff_field(v_x31_2411, 1);
      heff_take_n(v_x31_2411, 3ULL, 2);
      return (g_heff_2ebuild_2eserial_2etypeOf(v_k_249, v_x_2412, v_s_247, v_j_2413));
    }
    default: return heff_nomatch(v_x31_2411);
    }
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_i_241));
  V v_x3_246;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      v_x3_246 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_244, heff_dup(v_s_240), v_j_245));
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_247 = heff_field(v_x3_246, 0);
    V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_247, 0);
      V v_j_249 = heff_field(v_x31_247, 1);
      V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
      V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_249));
      V v_x3_2414;
      switch (heff_tag_of(v_x3_2410)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        v_x3_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2411 = heff_field(v_x3_2410, 0);
        heff_take_n(v_x3_2410, 1ULL, 1);
        switch (heff_tag_of(v_x31_2411)) {
        case TAG_MkPair: {
          V v_x_2412 = heff_field(v_x31_2411, 0);
          V v_j_2413 = heff_field(v_x31_2411, 1);
          heff_take_n(v_x31_2411, 3ULL, 2);
          v_x3_2414 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2412, v_s_240, v_j_2413));
          break;
        }
        default: heff_nomatch(v_x31_2411);
        }
        break;
      }
      default: heff_nomatch(v_x3_2410);
      }
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_246_24Just, 1);
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2415 = heff_field(v_x3_2414, 0);
        heff_take_n(v_x3_2414, 1ULL, 1);
        switch (heff_tag_of(v_x31_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x31_2415, 0);
          V v_j_2417 = heff_field(v_x31_2415, 1);
          heff_take_n(v_x31_2415, 3ULL, 2);
          V v_t_2418 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_248), v_x_2416});
          return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_j_2417})});
        }
        default: return heff_nomatch(v_x31_2415);
        }
      }
      default: return heff_nomatch(v_x3_2414);
      }
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt_24s380050788x81796853(a[0], a[1]);
}
Clo g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_i_241));
  V v_x3_246;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    v_x3_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      v_x3_246 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890(v_x_244, v_s_240, v_j_245));
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_247 = heff_field(v_x3_246, 0);
    V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_247, 0);
      V v_j_249 = heff_field(v_x31_247, 1);
      heff_take_n(v_x31_247, 3ULL, 2);
      V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_248)));
      V v_t_2411 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_248));
      V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_x_248));
      V v_x_2413 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2410), v_t_2411, heff_arrayFromList(v_t_2412)});
      return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_j_249})});
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str1, 1, "n");
Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry, 3, 0};

V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str0))) {
    heff_drop(v_x2_240);
    V v_x3_244 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
    V v_x3_248;
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_z_241);
      v_x3_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 3ULL, 2);
        v_x3_248 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_246, v_z_241, v_j_247));
        break;
      }
      default: heff_nomatch(v_x31_245);
      }
      break;
    }
    default: heff_nomatch(v_x3_244);
    }
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_249 = heff_field(v_x3_248, 0);
      V v_ru_24x3_248_24Just = heff_take_reuse_n(v_x3_248, 1ULL, 1);
      switch (heff_tag_of(v_x31_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x31_249, 0);
        V v_j_2411 = heff_field(v_x31_249, 1);
        V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
        V v_t_2412 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_248_24Just, TAG_Just, 1, (V[]){v_x_2410}), v_j_2411});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
      }
      default: return heff_nomatch(v_x31_249);
      }
    }
    default: return heff_nomatch(v_x3_248);
    }
  } else {
    if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_str1))) {
      heff_drop(v_z_241);
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_i_241));
  V v_x3_246;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    v_x3_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      v_x3_246 = (g_heff_2ebuild_2edecoder_2etimes(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_244, v_s_240, v_j_245));
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_247 = heff_field(v_x3_246, 0);
    V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_247, 0);
      V v_j_249 = heff_field(v_x31_247, 1);
      V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_248), v_j_249});
      return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){v_t_2410});
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555(a[0], a[1]);
}