// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2eprimitive_2ecompilerTable_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_lit_240), v_a_246);
      V v_t_2410 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_247, v_a_245));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry, 5, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_rest_244;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246, v_rest_244));
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 0);
      V v_a_249 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_2410 = heff_intShow(heff_strLength_lent(v_a_248, 0));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_lit_240), v_a_248);
      V v_a_2412 = heff_arrayToList(v_a_249);
      V v_a_2413 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2412));
      V v_t_2414 = ({ V a_0 = v_a_2412; V a_1 = v_a_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a_0, a_1)); heff_drop(v_a_2412); r_; });
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2413), v_t_2414});
      return heff_tag_at_n(v_ru_24x_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2411, v_t_2415});
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SmallU: {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
    }
    case TAG_LargeU: {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_x2_240, 0);
    V v_t_247 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_246), v_rest_241));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4), v_t_247}));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_240, 0);
    V v_dom_249 = heff_field(v_x2_240, 1);
    V v_cod_2410 = heff_field(v_x2_240, 2);
    V v_implicit_2411 = heff_field(v_x2_240, 3);
    V v_dflt_2412 = heff_field(v_x2_240, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2412, 0);
      V v_t_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2415), v_rest_241));
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12), v_t_2416});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
    V v_rest_2426;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_cod_2410, 0);
      V v_e_2420 = heff_field(v_cod_2410, 1);
      V v_t_2421 = heff_intShow(heff_strLength_lent(v_x_2419, 0));
      V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13)), heff_dup(v_x_2419));
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2420, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2424 = heff_field(v_cod_2410, 0);
      V v_t_2425 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2424, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15), v_t_2425});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_t_2427 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_249, v_rest_2426));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2427})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_SRecord: {
    V v_level_2429 = heff_field(v_x2_240, 0);
    V v_fs_2430 = heff_field(v_x2_240, 1);
    V v_ds_2431 = heff_field(v_x2_240, 2);
    V v_keys_2432 = heff_dup(heff_rfield(v_ds_2431, 0));
    V v_values_2433 = heff_dup(heff_rfield(v_ds_2431, 2));
    V v_keys_2434 = heff_dup(heff_rfield(v_fs_2430, 0));
    V v_values_2435 = heff_dup(heff_rfield(v_fs_2430, 2));
    V v_t_2436;
    switch (heff_tag_of(v_level_2429)) {
    case TAG_Small: {
      v_t_2436 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17);
      break;
    }
    case TAG_Large: {
      v_t_2436 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2436 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19);
      break;
    }
    default: heff_nomatch(v_level_2429);
    }
    V v_xs_2437 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2432), heff_arrayToList(v_values_2433)));
    V v_i_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2437));
    V v_t_2439 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20), v_xs_2437, v_rest_241));
    V v_rest_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), v_t_2439});
    V v_xs_2441 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2434), heff_arrayToList(v_values_2435)));
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21), v_xs_2441, v_rest_2440));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2444})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2445);
  }
  case TAG_SSum: {
    V v_vs_2446 = heff_field(v_x2_240, 0);
    V v_keys_2447 = heff_dup(heff_rfield(v_vs_2446, 0));
    V v_values_2448 = heff_dup(heff_rfield(v_vs_2446, 2));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2447), heff_arrayToList(v_values_2448)));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2449, v_rest_241));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24), v_t_2452}));
  }
  case TAG_SIsTy: {
    V v_t2_2453 = heff_field(v_x2_240, 0);
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25), heff_hole()});
    V v_u_2455 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2454));
    heff_drop(v_u_2455);
    V t_0 = v_t2_2453;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2454;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrimInt: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26), v_rest_241}));
  }
  case TAG_SPrimFloat: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27), v_rest_241}));
  }
  case TAG_SPrimString: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28), v_rest_241}));
  }
  case TAG_SPrimRune: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29), v_rest_241}));
  }
  case TAG_SPrimArray: {
    V v_t2_2456 = heff_field(v_x2_240, 0);
    V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30), heff_hole()});
    V v_u_2458 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2457));
    heff_drop(v_u_2458);
    V t_0 = v_t2_2456;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2457;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFixed: {
    V v_w_2459 = heff_field(v_x2_240, 0);
    V v_t_2460;
    switch (heff_tag_of(v_w_2459)) {
    case TAG_I8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31);
      break;
    }
    case TAG_I16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32);
      break;
    }
    case TAG_I32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33);
      break;
    }
    case TAG_I64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34);
      break;
    }
    case TAG_U8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35);
      break;
    }
    case TAG_U16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36);
      break;
    }
    case TAG_U32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37);
      break;
    }
    case TAG_U64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38);
      break;
    }
    case TAG_F32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39);
      break;
    }
    default: heff_nomatch(v_w_2459);
    }
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2461);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength_lent(v_a_249, 0));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, v_lit_240), v_a_249);
      V v_t_2419;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2415));
        V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(v_lit_243, v_a_2415, v_a_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), v_t_2418});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8, 7, "Float32");

HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1); V a_2 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2); V a_3 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3); V a_4 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4); V a_5 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5); V a_6 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6); V a_7 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7); V a_8 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8); V a_9 = v_x_246; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(v_x_246); heff_drop(b_10); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2411, v_j_247})}});
          } else {
            heff_drop(v_j_247);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0, 2, 1, (V[]){v_d_240}), v_x_247, v_s_241, v_j_248));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_x31_2425 = v_field_2424;
            switch (heff_tag_of(v_x31_2425)) {
            case TAG_MkPair: {
              V v_x_2426 = heff_field(v_x31_2425, 0);
              V v_j_2427 = heff_field(v_x31_2425, 1);
              V v_ru_24x31_2425_24MkPair = heff_take_reuse_n(v_x31_2425, 3ULL, 2);
              V v_t_2428 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x31_2425_24MkPair, heff_dup(v_x_2426)));
              V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2426));
              V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2426));
              V v_x_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_j_2427})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2424);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_d_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_249), v_i_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2413;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
        V v_x3_2417 = heff_tr(heff_call(v_d_240, 2, (V[]){v_s_249, v_j_2416}));
        switch (heff_tag_of(v_x3_2417)) {
        case TAG_Nothing: {
          heff_drop(v_x_2415);
          heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2418 = heff_field(v_x3_2417, 0);
          V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_x_2419}), v_j_2420});
            return heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_Just, 1, (V[]){v_t_2421});
          }
          default: return heff_nomatch(v_x31_2418);
          }
        }
        default: return heff_nomatch(v_x3_2417);
        }
      }
      default: return heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop(v_s_249);
      heff_drop(v_d_240);
      heff_drop(v_field_2413);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_247, heff_dup(v_s_241), v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2412 = v_field_2411;
            switch (heff_tag_of(v_x31_2412)) {
            case TAG_MkPair: {
              V v_x_2413 = heff_field(v_x31_2412, 0);
              V v_j_2414 = heff_field(v_x31_2412, 1);
              V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
              V v_x3_2415 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_2414}));
              switch (heff_tag_of(v_x3_2415)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                heff_drop(v_x_2413);
                heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2416 = heff_field(v_x3_2415, 0);
                V v_ru_24x3_2415_24Just = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
                switch (heff_tag_of(v_x31_2416)) {
                case TAG_MkPair: {
                  V v_x_2417 = heff_field(v_x31_2416, 0);
                  V v_j_2418 = heff_field(v_x31_2416, 1);
                  heff_take_n(v_x31_2416, 3ULL, 2);
                  V v_t_2419 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2413), v_x_2417});
                  return heff_tag_at_n(v_ru_24x3_2415_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_j_2418})});
                }
                default: return heff_nomatch(v_x31_2416);
                }
              }
              default: return heff_nomatch(v_x3_2415);
              }
            }
            default: return heff_nomatch(v_x31_2412);
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_s_241);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str19, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str20, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str21, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str22, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str23, 3, "f32");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_248}), v_j_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 2);
      HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x31_2414 = v_field_2413;
          switch (heff_tag_of(v_x31_2414)) {
          case TAG_MkPair: {
            V v_x_2415 = heff_field(v_x31_2414, 0);
            V v_j_2416 = heff_field(v_x31_2414, 1);
            V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
            V v_t_2417 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2415}), v_j_2416});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2414)}});
          }
        } else {
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str2), 2)) {
        V v_x3_2418 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
        switch (heff_tag_of(v_x3_2418)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2419 = heff_field(v_x3_2418, 0);
          V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
          switch (heff_tag_of(v_x31_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x31_2419, 0);
            V v_j_2421 = heff_field(v_x31_2419, 1);
            V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
            V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_SCode, 1, (V[]){v_x_2420}), v_j_2421});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2422}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2418)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str3), 2)) {
          V v_m_2423 = heff_dup(heff_rfield(v_k_240, 0));
          V v_x3_2424 = heff_tr(heff_call(v_m_2423, 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2424)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2425 = heff_field(v_x3_2424, 0);
            heff_take_n(v_x3_2424, 1ULL, 1);
            switch (heff_tag_of(v_x31_2425)) {
            case TAG_MkPair: {
              V v_x_2426 = heff_field(v_x31_2425, 0);
              V v_j_2427 = heff_field(v_x31_2425, 1);
              V v_ru_24x31_2425_24MkPair = heff_take_reuse_n(v_x31_2425, 3ULL, 2);
              V v_x3_2428 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2427}));
              switch (heff_tag_of(v_x3_2428)) {
              case TAG_Nothing: {
                heff_drop(v_x_2426);
                heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2429 = heff_field(v_x3_2428, 0);
                heff_take_n(v_x3_2428, 1ULL, 1);
                switch (heff_tag_of(v_x31_2429)) {
                case TAG_MkPair: {
                  V v_x_2430 = heff_field(v_x31_2429, 0);
                  V v_j_2431 = heff_field(v_x31_2429, 1);
                  V v_ru_24x31_2429_24MkPair = heff_take_reuse_n(v_x31_2429, 3ULL, 2);
                  V v_t_2432 = heff_tag_at_n(v_ru_24x31_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2429_24MkPair, TAG_SApp, 2, (V[]){v_x_2426, v_x_2430}), v_j_2431});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2432}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2429)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2428)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2424)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str4), 2)) {
            V v_m_2433 = heff_take_field(v_k_240, 1);
            V v_x3_2434 = heff_tr(heff_call(v_m_2433, 2, (V[]){heff_dup(v_z_242), v_z_243}));
            switch (heff_tag_of(v_x3_2434)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2435 = heff_field(v_x3_2434, 0);
              heff_take_n(v_x3_2434, 1ULL, 1);
              switch (heff_tag_of(v_x31_2435)) {
              case TAG_MkPair: {
                V v_x_2436 = heff_field(v_x31_2435, 0);
                V v_j_2437 = heff_field(v_x31_2435, 1);
                V v_ru_24x31_2435_24MkPair = heff_take_reuse_n(v_x31_2435, 3ULL, 2);
                HeffT2 v_t_2438 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2437));
                {
                  V v_field_2440 = v_t_2438.f[1];
                  int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                  if ((v_tag_2439 == ((int64_t)0ULL))) {
                    V v_x31_2441 = v_field_2440;
                    switch (heff_tag_of(v_x31_2441)) {
                    case TAG_MkPair: {
                      V v_x_2442 = heff_field(v_x31_2441, 0);
                      V v_j_2443 = heff_field(v_x31_2441, 1);
                      V v_ru_24x31_2441_24MkPair = heff_take_reuse_n(v_x31_2441, 3ULL, 2);
                      HeffT2 v_t_2444 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_2442; V a_2 = v_z_242; V a_3 = v_j_2443; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2442); r_; });
                      {
                        V v_field_2446 = v_t_2444.f[1];
                        int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                        if ((v_tag_2445 == ((int64_t)0ULL))) {
                          V v_x31_2447 = v_field_2446;
                          switch (heff_tag_of(v_x31_2447)) {
                          case TAG_MkPair: {
                            V v_x_2448 = heff_field(v_x31_2447, 0);
                            V v_j_2449 = heff_field(v_x31_2447, 1);
                            heff_take_n(v_x31_2447, 3ULL, 2);
                            V v_t_2450 = heff_tag_at_n(v_ru_24x31_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2441_24MkPair, TAG_SLam, 2, (V[]){v_x_2436, v_x_2448}), v_j_2449});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2450}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2447)}});
                          }
                        } else {
                          heff_drop(v_x_2436);
                          heff_drop_cell(v_ru_24x31_2435_24MkPair, 2);
                          heff_drop_cell(v_ru_24x31_2441_24MkPair, 2);
                          heff_drop(v_field_2446);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2436);
                    heff_drop_cell(v_ru_24x31_2435_24MkPair, 2);
                    heff_drop(v_field_2440);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2435)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_2434)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str5), 2)) {
              HeffT2 v_t_2451 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_z_243));
              {
                V v_field_2453 = v_t_2451.f[1];
                int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
                if ((v_tag_2452 == ((int64_t)0ULL))) {
                  V v_x31_2454 = v_field_2453;
                  switch (heff_tag_of(v_x31_2454)) {
                  case TAG_MkPair: {
                    V v_x_2455 = heff_field(v_x31_2454, 0);
                    V v_j_2456 = heff_field(v_x31_2454, 1);
                    V v_ru_24x31_2454_24MkPair = heff_take_reuse_n(v_x31_2454, 3ULL, 2);
                    V v_t_2457 = heff_tag_at_n(v_ru_24x31_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2455}), v_j_2456});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2457}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
                  }
                } else {
                  heff_drop(v_field_2453);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str6), 2)) {
                V v_x3_2458 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2458)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2459 = heff_field(v_x3_2458, 0);
                  heff_take_n(v_x3_2458, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2459)) {
                  case TAG_MkPair: {
                    V v_x_2460 = heff_field(v_x31_2459, 0);
                    V v_j_2461 = heff_field(v_x31_2459, 1);
                    V v_ru_24x31_2459_24MkPair = heff_take_reuse_n(v_x31_2459, 3ULL, 2);
                    HeffT2 v_t_2462 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_2461));
                    {
                      V v_field_2464 = v_t_2462.f[1];
                      int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                      if ((v_tag_2463 == ((int64_t)0ULL))) {
                        V v_x31_2465 = v_field_2464;
                        switch (heff_tag_of(v_x31_2465)) {
                        case TAG_MkPair: {
                          V v_x_2466 = heff_field(v_x31_2465, 0);
                          V v_j_2467 = heff_field(v_x31_2465, 1);
                          V v_ru_24x31_2465_24MkPair = heff_take_reuse_n(v_x31_2465, 3ULL, 2);
                          V v_t_2468 = heff_tag_at_n(v_ru_24x31_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2465_24MkPair, TAG_SProj, 2, (V[]){v_x_2460, v_x_2466}), v_j_2467});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2468}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2465)}});
                        }
                      } else {
                        heff_drop(v_x_2460);
                        heff_drop_cell(v_ru_24x31_2459_24MkPair, 2);
                        heff_drop(v_field_2464);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2459)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2458)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str7), 2)) {
                  HeffT2 v_t_2469 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                  {
                    V v_field_2471 = v_t_2469.f[1];
                    int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                    if ((v_tag_2470 == ((int64_t)0ULL))) {
                      V v_x31_2472 = v_field_2471;
                      switch (heff_tag_of(v_x31_2472)) {
                      case TAG_MkPair: {
                        V v_x_2473 = heff_field(v_x31_2472, 0);
                        V v_j_2474 = heff_field(v_x31_2472, 1);
                        V v_ru_24x31_2472_24MkPair = heff_take_reuse_n(v_x31_2472, 3ULL, 2);
                        HeffT2 v_t_2475 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2474));
                        {
                          V v_field_2477 = v_t_2475.f[1];
                          int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                          if ((v_tag_2476 == ((int64_t)0ULL))) {
                            V v_x31_2478 = v_field_2477;
                            switch (heff_tag_of(v_x31_2478)) {
                            case TAG_MkPair: {
                              V v_x_2479 = heff_field(v_x31_2478, 0);
                              V v_j_2480 = heff_field(v_x31_2478, 1);
                              V v_ru_24x31_2478_24MkPair = heff_take_reuse_n(v_x31_2478, 3ULL, 2);
                              HeffT2 v_t_2481 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_get_n(v_k_240, 0, 2), v_x_2479, v_z_242, v_j_2480));
                              {
                                V v_field_2483 = v_t_2481.f[1];
                                int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                                if ((v_tag_2482 == ((int64_t)0ULL))) {
                                  V v_x31_2484 = v_field_2483;
                                  switch (heff_tag_of(v_x31_2484)) {
                                  case TAG_MkPair: {
                                    V v_x_2485 = heff_field(v_x31_2484, 0);
                                    V v_j_2486 = heff_field(v_x31_2484, 1);
                                    heff_take_n(v_x31_2484, 3ULL, 2);
                                    V v_t_2487 = heff_tag_at_n(v_ru_24x31_2478_24MkPair, TAG_STag, 2, (V[]){v_x_2473, heff_arrayFromList(v_x_2485)});
                                    V v_f_2488 = heff_tag_at_n(v_ru_24x31_2472_24MkPair, TAG_MkPair, 2, (V[]){v_t_2487, v_j_2486});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2488}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2484)}});
                                  }
                                } else {
                                  heff_drop(v_x_2473);
                                  heff_drop_cell(v_ru_24x31_2472_24MkPair, 2);
                                  heff_drop_cell(v_ru_24x31_2478_24MkPair, 2);
                                  heff_drop(v_field_2483);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2478)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2473);
                            heff_drop_cell(v_ru_24x31_2472_24MkPair, 2);
                            heff_drop(v_field_2477);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2472)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_field_2471);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str8), 2)) {
                    V v_m_2489 = heff_dup(heff_rfield(v_k_240, 0));
                    V v_x3_2490 = heff_tr(heff_call(v_m_2489, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_2490)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2491 = heff_field(v_x3_2490, 0);
                      heff_take_n(v_x3_2490, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2491)) {
                      case TAG_MkPair: {
                        V v_x_2492 = heff_field(v_x31_2491, 0);
                        V v_j_2493 = heff_field(v_x31_2491, 1);
                        V v_ru_24x31_2491_24MkPair = heff_take_reuse_n(v_x31_2491, 3ULL, 2);
                        V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
                        HeffT2 v_t_2495 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_2494, v_z_242, v_j_2493));
                        {
                          V v_field_2497 = v_t_2495.f[1];
                          int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
                          if ((v_tag_2496 == ((int64_t)0ULL))) {
                            V v_x31_2498 = v_field_2497;
                            switch (heff_tag_of(v_x31_2498)) {
                            case TAG_MkPair: {
                              V v_x_2499 = heff_field(v_x31_2498, 0);
                              V v_j_24100 = heff_field(v_x31_2498, 1);
                              V v_ru_24x31_2498_24MkPair = heff_take_reuse_n(v_x31_2498, 3ULL, 2);
                              V v_t_24101 = heff_tag_at_n(v_ru_24x31_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2498_24MkPair, TAG_SMatch, 2, (V[]){v_x_2492, v_x_2499}), v_j_24100});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24101}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2498)}});
                            }
                          } else {
                            heff_drop(v_x_2492);
                            heff_drop_cell(v_ru_24x31_2491_24MkPair, 2);
                            heff_drop(v_field_2497);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2491)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2490)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str9), 2)) {
                      V v_m_24102 = heff_dup(heff_rfield(v_k_240, 0));
                      V v_x3_24103 = heff_tr(heff_call(v_m_24102, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                      switch (heff_tag_of(v_x3_24103)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_24104 = heff_field(v_x3_24103, 0);
                        heff_take_n(v_x3_24103, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24104)) {
                        case TAG_MkPair: {
                          V v_x_24105 = heff_field(v_x31_24104, 0);
                          V v_j_24106 = heff_field(v_x31_24104, 1);
                          V v_ru_24x31_24104_24MkPair = heff_take_reuse_n(v_x31_24104, 3ULL, 2);
                          HeffT2 v_t_24107 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_j_24106));
                          {
                            V v_field_24109 = v_t_24107.f[1];
                            int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
                            if ((v_tag_24108 == ((int64_t)0ULL))) {
                              V v_x31_24110 = v_field_24109;
                              switch (heff_tag_of(v_x31_24110)) {
                              case TAG_MkPair: {
                                V v_x_24111 = heff_field(v_x31_24110, 0);
                                V v_j_24112 = heff_field(v_x31_24110, 1);
                                heff_take_n(v_x31_24110, 3ULL, 2);
                                V v_x3_24113 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24112}));
                                switch (heff_tag_of(v_x3_24113)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24105);
                                  heff_drop_cell(v_ru_24x31_24104_24MkPair, 2);
                                  heff_drop(v_x_24111);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24114 = heff_field(v_x3_24113, 0);
                                  heff_take_n(v_x3_24113, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24114)) {
                                  case TAG_MkPair: {
                                    V v_x_24115 = heff_field(v_x31_24114, 0);
                                    V v_j_24116 = heff_field(v_x31_24114, 1);
                                    heff_take_n(v_x31_24114, 3ULL, 2);
                                    V v_t_24117 = heff_tag_at_n(v_ru_24x31_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24105, v_x_24111, v_x_24115}), v_j_24116});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24117}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24114)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24113)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24110)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 2);
                              heff_drop(v_z_242);
                              heff_drop(v_x_24105);
                              heff_drop_cell(v_ru_24x31_24104_24MkPair, 2);
                              heff_drop(v_field_24109);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24104)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_24103)}});
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str10), 2)) {
                        V v_x3_24118 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_24118)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_24119 = heff_field(v_x3_24118, 0);
                          V v_ru_24x3_24118_24Just = heff_take_reuse_n(v_x3_24118, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24119)) {
                          case TAG_MkPair: {
                            V v_x_24120 = heff_field(v_x31_24119, 0);
                            V v_j_24121 = heff_field(v_x31_24119, 1);
                            V v_ru_24x31_24119_24MkPair = heff_take_reuse_n(v_x31_24119, 3ULL, 2);
                            V v_t_24122 = heff_tag_at_n(v_ru_24x31_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24118_24Just, TAG_SIs, 1, (V[]){v_x_24120}), v_j_24121});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24122}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24119)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_24118)}});
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str11), 2)) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_z_242);
                          V v_t_24123 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_243});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24123}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            V v_t_24124 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_243});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24124}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str13), 2)) {
                              V v_x3_24125 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                              switch (heff_tag_of(v_x3_24125)) {
                              case TAG_Nothing: {
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24126 = heff_field(v_x3_24125, 0);
                                V v_ru_24x3_24125_24Just = heff_take_reuse_n(v_x3_24125, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24126)) {
                                case TAG_MkPair: {
                                  V v_x_24127 = heff_field(v_x31_24126, 0);
                                  V v_j_24128 = heff_field(v_x31_24126, 1);
                                  V v_ru_24x31_24126_24MkPair = heff_take_reuse_n(v_x31_24126, 3ULL, 2);
                                  V v_t_24129 = heff_tag_at_n(v_ru_24x31_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24125_24Just, TAG_SRec, 1, (V[]){v_x_24127}), v_j_24128});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24129}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24126)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24125)}});
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str14), 2)) {
                                V v_m_24130 = heff_take_field(v_k_240, 1);
                                V v_x3_24131 = heff_tr(heff_call(v_m_24130, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                                switch (heff_tag_of(v_x3_24131)) {
                                case TAG_Nothing: {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24132 = heff_field(v_x3_24131, 0);
                                  heff_take_n(v_x3_24131, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24132)) {
                                  case TAG_MkPair: {
                                    V v_x_24133 = heff_field(v_x31_24132, 0);
                                    V v_j_24134 = heff_field(v_x31_24132, 1);
                                    V v_ru_24x31_24132_24MkPair = heff_take_reuse_n(v_x31_24132, 3ULL, 2);
                                    HeffT2 v_t_24135 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_24134));
                                    {
                                      V v_field_24137 = v_t_24135.f[1];
                                      int64_t v_tag_24136 = ((int64_t)v_t_24135.f[0]);
                                      if ((v_tag_24136 == ((int64_t)0ULL))) {
                                        V v_x31_24138 = v_field_24137;
                                        switch (heff_tag_of(v_x31_24138)) {
                                        case TAG_MkPair: {
                                          V v_x_24139 = heff_field(v_x31_24138, 0);
                                          V v_j_24140 = heff_field(v_x31_24138, 1);
                                          V v_ru_24x31_24138_24MkPair = heff_take_reuse_n(v_x31_24138, 3ULL, 2);
                                          HeffT2 v_t_24141 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_24139; V a_2 = v_z_242; V a_3 = v_j_24140; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24139); r_; });
                                          {
                                            V v_field_24143 = v_t_24141.f[1];
                                            int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
                                            if ((v_tag_24142 == ((int64_t)0ULL))) {
                                              V v_x31_24144 = v_field_24143;
                                              switch (heff_tag_of(v_x31_24144)) {
                                              case TAG_MkPair: {
                                                V v_x_24145 = heff_field(v_x31_24144, 0);
                                                V v_j_24146 = heff_field(v_x31_24144, 1);
                                                heff_take_n(v_x31_24144, 3ULL, 2);
                                                V v_t_24147 = heff_tag_at_n(v_ru_24x31_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24138_24MkPair, TAG_SFix, 2, (V[]){v_x_24133, v_x_24145}), v_j_24146});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24147}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24144)}});
                                              }
                                            } else {
                                              heff_drop(v_x_24133);
                                              heff_drop_cell(v_ru_24x31_24132_24MkPair, 2);
                                              heff_drop_cell(v_ru_24x31_24138_24MkPair, 2);
                                              heff_drop(v_field_24143);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24138)}});
                                        }
                                      } else {
                                        heff_drop_rec(v_k_240, 2);
                                        heff_drop(v_z_242);
                                        heff_drop(v_x_24133);
                                        heff_drop_cell(v_ru_24x31_24132_24MkPair, 2);
                                        heff_drop(v_field_24137);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24132)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24131)}});
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str15), 2)) {
                                  HeffT2 v_t_24148 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                                  {
                                    V v_field_24150 = v_t_24148.f[1];
                                    int64_t v_tag_24149 = ((int64_t)v_t_24148.f[0]);
                                    if ((v_tag_24149 == ((int64_t)0ULL))) {
                                      V v_x31_24151 = v_field_24150;
                                      switch (heff_tag_of(v_x31_24151)) {
                                      case TAG_MkPair: {
                                        V v_x_24152 = heff_field(v_x31_24151, 0);
                                        V v_j_24153 = heff_field(v_x31_24151, 1);
                                        V v_ru_24x31_24151_24MkPair = heff_take_reuse_n(v_x31_24151, 3ULL, 2);
                                        V v_x3_24154 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24153}));
                                        switch (heff_tag_of(v_x3_24154)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24152);
                                          heff_drop_cell(v_ru_24x31_24151_24MkPair, 2);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24155 = heff_field(v_x3_24154, 0);
                                          heff_take_n(v_x3_24154, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24155)) {
                                          case TAG_MkPair: {
                                            V v_x_24156 = heff_field(v_x31_24155, 0);
                                            V v_j_24157 = heff_field(v_x31_24155, 1);
                                            V v_ru_24x31_24155_24MkPair = heff_take_reuse_n(v_x31_24155, 3ULL, 2);
                                            V v_t_24158 = heff_tag_at_n(v_ru_24x31_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24155_24MkPair, TAG_SImplicit, 2, (V[]){v_x_24152, v_x_24156}), v_j_24157});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24158}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24155)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24154)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24151)}});
                                      }
                                    } else {
                                      heff_drop_rec(v_k_240, 2);
                                      heff_drop(v_z_242);
                                      heff_drop(v_field_24150);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str16), 2)) {
                                    HeffT2 v_t_24159 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                    {
                                      V v_field_24161 = v_t_24159.f[1];
                                      int64_t v_tag_24160 = ((int64_t)v_t_24159.f[0]);
                                      if ((v_tag_24160 == ((int64_t)0ULL))) {
                                        V v_x31_24162 = v_field_24161;
                                        switch (heff_tag_of(v_x31_24162)) {
                                        case TAG_MkPair: {
                                          V v_x_24163 = heff_field(v_x31_24162, 0);
                                          V v_j_24164 = heff_field(v_x31_24162, 1);
                                          V v_ru_24x31_24162_24MkPair = heff_take_reuse_n(v_x31_24162, 3ULL, 2);
                                          HeffT2 v_t_24165 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2ecompilerTable_get()); V a_1 = v_x_24163; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
                                          {
                                            V v_field_24167 = v_t_24165.f[1];
                                            int64_t v_tag_24166 = ((int64_t)v_t_24165.f[0]);
                                            HeffT2 v_t_24168 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_x_24163; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_24163); r_; });
                                            {
                                              V v_field_24170 = v_t_24168.f[1];
                                              int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
                                              if ((v_tag_24169 == ((int64_t)0ULL))) {
                                                heff_drop(v_field_24167);
                                                V v_x_24171 = v_field_24170;
                                                V v_t_24172 = heff_tag_at_n(v_ru_24x31_24162_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24171}), v_j_24164});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24172}});
                                              } else {
                                                heff_drop(v_field_24170);
                                                if ((v_tag_24166 == ((int64_t)0ULL))) {
                                                  V v_x_24173 = v_field_24167;
                                                  V v_t_24174 = heff_tag_at_n(v_ru_24x31_24162_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24173}), v_j_24164});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24174}});
                                                } else {
                                                  heff_drop(v_j_24164);
                                                  heff_drop_cell(v_ru_24x31_24162_24MkPair, 2);
                                                  heff_drop(v_field_24167);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24162)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24161);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str17), 2)) {
                                      HeffT2 v_t_24175 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                      {
                                        V v_field_24177 = v_t_24175.f[1];
                                        int64_t v_tag_24176 = ((int64_t)v_t_24175.f[0]);
                                        if ((v_tag_24176 == ((int64_t)0ULL))) {
                                          V v_x31_24178 = v_field_24177;
                                          switch (heff_tag_of(v_x31_24178)) {
                                          case TAG_MkPair: {
                                            V v_x_24179 = heff_field(v_x31_24178, 0);
                                            V v_j_24180 = heff_field(v_x31_24178, 1);
                                            V v_ru_24x31_24178_24MkPair = heff_take_reuse_n(v_x31_24178, 3ULL, 2);
                                            V v_t_24181 = ({ V a_0 = v_x_24179; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24179); r_; });
                                            V v_x_24182 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24181});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24178_24MkPair, TAG_MkPair, 2, (V[]){v_x_24182, v_j_24180})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24178)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24177);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str18), 2)) {
                                        HeffT2 v_t_24183 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                        {
                                          V v_field_24185 = v_t_24183.f[1];
                                          int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
                                          if ((v_tag_24184 == ((int64_t)0ULL))) {
                                            V v_x31_24186 = v_field_24185;
                                            switch (heff_tag_of(v_x31_24186)) {
                                            case TAG_MkPair: {
                                              V v_x_24187 = heff_field(v_x31_24186, 0);
                                              V v_j_24188 = heff_field(v_x31_24186, 1);
                                              V v_ru_24x31_24186_24MkPair = heff_take_reuse_n(v_x31_24186, 3ULL, 2);
                                              double v_t_24189 = ({ V a_0 = v_x_24187; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24187); r_; });
                                              V v_x_24190 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24189)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24186_24MkPair, TAG_MkPair, 2, (V[]){v_x_24190, v_j_24188})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24186)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24185);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str19), 2)) {
                                          HeffT2 v_t_24191 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                          {
                                            V v_field_24193 = v_t_24191.f[1];
                                            int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
                                            if ((v_tag_24192 == ((int64_t)0ULL))) {
                                              V v_x31_24194 = v_field_24193;
                                              switch (heff_tag_of(v_x31_24194)) {
                                              case TAG_MkPair: {
                                                V v_x_24195 = heff_field(v_x31_24194, 0);
                                                V v_j_24196 = heff_field(v_x31_24194, 1);
                                                V v_ru_24x31_24194_24MkPair = heff_take_reuse_n(v_x31_24194, 3ULL, 2);
                                                V v_t_24197 = heff_tag_at_n(v_ru_24x31_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24195}), v_j_24196});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24197}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24194)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24193);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str20), 2)) {
                                            HeffT2 v_t_24198 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                            {
                                              V v_field_24200 = v_t_24198.f[1];
                                              int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
                                              if ((v_tag_24199 == ((int64_t)0ULL))) {
                                                V v_x31_24201 = v_field_24200;
                                                switch (heff_tag_of(v_x31_24201)) {
                                                case TAG_MkPair: {
                                                  V v_x_24202 = heff_field(v_x31_24201, 0);
                                                  V v_j_24203 = heff_field(v_x31_24201, 1);
                                                  V v_ru_24x31_24201_24MkPair = heff_take_reuse_n(v_x31_24201, 3ULL, 2);
                                                  V v_t_24204 = heff_tag_at_n(v_ru_24x31_24201_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24202}), v_j_24203});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24204}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24201)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24200);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str21), 2)) {
                                              HeffT2 v_t_24205 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                              {
                                                V v_field_24207 = v_t_24205.f[1];
                                                int64_t v_tag_24206 = ((int64_t)v_t_24205.f[0]);
                                                if ((v_tag_24206 == ((int64_t)0ULL))) {
                                                  V v_x31_24208 = v_field_24207;
                                                  switch (heff_tag_of(v_x31_24208)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24209 = heff_field(v_x31_24208, 0);
                                                    V v_j_24210 = heff_field(v_x31_24208, 1);
                                                    V v_ru_24x31_24208_24MkPair = heff_take_reuse_n(v_x31_24208, 3ULL, 2);
                                                    V v_t_24211 = ({ V a_0 = v_x_24209; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24209); r_; });
                                                    V v_x_24212 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24211});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24208_24MkPair, TAG_MkPair, 2, (V[]){v_x_24212, v_j_24210})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24208)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24207);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str22), 2)) {
                                                HeffT2 v_t_24213 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_242, v_z_243));
                                                {
                                                  V v_field_24215 = v_t_24213.f[1];
                                                  int64_t v_tag_24214 = ((int64_t)v_t_24213.f[0]);
                                                  if ((v_tag_24214 == ((int64_t)0ULL))) {
                                                    V v_x31_24216 = v_field_24215;
                                                    switch (heff_tag_of(v_x31_24216)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24217 = heff_field(v_x31_24216, 0);
                                                      V v_j_24218 = heff_field(v_x31_24216, 1);
                                                      V v_ru_24x31_24216_24MkPair = heff_take_reuse_n(v_x31_24216, 3ULL, 2);
                                                      HeffT2 v_t_24219 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24218));
                                                      {
                                                        V v_field_24221 = v_t_24219.f[1];
                                                        int64_t v_tag_24220 = ((int64_t)v_t_24219.f[0]);
                                                        if ((v_tag_24220 == ((int64_t)0ULL))) {
                                                          V v_x31_24222 = v_field_24221;
                                                          switch (heff_tag_of(v_x31_24222)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24223 = heff_field(v_x31_24222, 0);
                                                            V v_j_24224 = heff_field(v_x31_24222, 1);
                                                            V v_ru_24x31_24222_24MkPair = heff_take_reuse_n(v_x31_24222, 3ULL, 2);
                                                            V v_t_24225 = ({ V a_0 = v_x_24223; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24223); r_; });
                                                            V v_x_24226 = heff_tag_at_n(v_ru_24x31_24222_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24217, v_t_24225});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24216_24MkPair, TAG_MkPair, 2, (V[]){v_x_24226, v_j_24224})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24222)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24217);
                                                          heff_drop_cell(v_ru_24x31_24216_24MkPair, 2);
                                                          heff_drop(v_field_24221);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24216)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24215);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str23), 2)) {
                                                  HeffT2 v_t_24227 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                                  {
                                                    V v_field_24229 = v_t_24227.f[1];
                                                    int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
                                                    if ((v_tag_24228 == ((int64_t)0ULL))) {
                                                      V v_x31_24230 = v_field_24229;
                                                      switch (heff_tag_of(v_x31_24230)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24231 = heff_field(v_x31_24230, 0);
                                                        V v_j_24232 = heff_field(v_x31_24230, 1);
                                                        V v_ru_24x31_24230_24MkPair = heff_take_reuse_n(v_x31_24230, 3ULL, 2);
                                                        double v_t_24233 = ({ V a_0 = v_x_24231; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24231); r_; });
                                                        V v_x_24234 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24233)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24230_24MkPair, TAG_MkPair, 2, (V[]){v_x_24234, v_j_24232})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24230)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24229);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1), 2)) {
      V v_x3_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_244)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_245 = heff_field(v_x3_244, 0);
        V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
        switch (heff_tag_of(v_x31_245)) {
        case TAG_MkPair: {
          V v_x_246 = heff_field(v_x31_245, 0);
          V v_j_247 = heff_field(v_x31_245, 1);
          V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
          V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_244_24Just, TAG_SDecode, 1, (V[]){v_x_246}), v_j_247});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2), 2)) {
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2412 = v_field_2411;
            switch (heff_tag_of(v_x31_2412)) {
            case TAG_MkPair: {
              V v_x_2413 = heff_field(v_x31_2412, 0);
              V v_j_2414 = heff_field(v_x31_2412, 1);
              V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
              V v_x3_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_z_242), v_j_2414}));
              switch (heff_tag_of(v_x3_2415)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                heff_drop(v_x_2413);
                heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2416 = heff_field(v_x3_2415, 0);
                heff_take_n(v_x3_2415, 1ULL, 1);
                switch (heff_tag_of(v_x31_2416)) {
                case TAG_MkPair: {
                  V v_x_2417 = heff_field(v_x31_2416, 0);
                  V v_j_2418 = heff_field(v_x31_2416, 1);
                  heff_take_n(v_x31_2416, 3ULL, 2);
                  HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2418));
                  {
                    V v_field_2421 = v_t_2419.f[1];
                    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                    if ((v_tag_2420 == ((int64_t)0ULL))) {
                      V v_x31_2422 = v_field_2421;
                      switch (heff_tag_of(v_x31_2422)) {
                      case TAG_MkPair: {
                        V v_x_2423 = heff_field(v_x31_2422, 0);
                        V v_j_2424 = heff_field(v_x31_2422, 1);
                        heff_take_n(v_x31_2422, 3ULL, 2);
                        HeffT2 v_t_2425 = ({ V a_0 = heff_dup(heff_rfield(v_k_240, 1)); V a_1 = v_x_2423; V a_2 = heff_dup(v_z_242); V a_3 = v_j_2424; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2423); r_; });
                        {
                          V v_field_2427 = v_t_2425.f[1];
                          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
                          if ((v_tag_2426 == ((int64_t)0ULL))) {
                            V v_x31_2428 = v_field_2427;
                            switch (heff_tag_of(v_x31_2428)) {
                            case TAG_MkPair: {
                              V v_x_2429 = heff_field(v_x31_2428, 0);
                              V v_j_2430 = heff_field(v_x31_2428, 1);
                              heff_take_n(v_x31_2428, 3ULL, 2);
                              HeffT2 v_t_2431 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_242, v_j_2430));
                              {
                                V v_field_2433 = v_t_2431.f[1];
                                int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                                if ((v_tag_2432 == ((int64_t)0ULL))) {
                                  V v_x31_2434 = v_field_2433;
                                  switch (heff_tag_of(v_x31_2434)) {
                                  case TAG_MkPair: {
                                    V v_x_2435 = heff_field(v_x31_2434, 0);
                                    V v_j_2436 = heff_field(v_x31_2434, 1);
                                    heff_take_n(v_x31_2434, 3ULL, 2);
                                    V v_f_2437 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                                    V v_s_2438 = v_z_242;
                                    V v_i_2439 = v_j_2436;
                                    HeffT2 v_t_2440 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2438, v_i_2439));
                                    V v_x3_2446;
                                    {
                                      V v_field_2442 = v_t_2440.f[1];
                                      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                                      if ((v_tag_2441 == ((int64_t)0ULL))) {
                                        V v_x31_2443 = v_field_2442;
                                        switch (heff_tag_of(v_x31_2443)) {
                                        case TAG_MkPair: {
                                          V v_x_2444 = heff_field(v_x31_2443, 0);
                                          V v_j_2445 = heff_field(v_x31_2443, 1);
                                          heff_take_n(v_x31_2443, 3ULL, 2);
                                          v_x3_2446 = heff_tr(heff_call(v_f_2437, 3, (V[]){v_x_2444, v_s_2438, v_j_2445}));
                                          break;
                                        }
                                        default: heff_nomatch(v_x31_2443);
                                        }
                                      } else {
                                        heff_drop(v_f_2437);
                                        heff_drop(v_s_2438);
                                        heff_drop(v_field_2442);
                                        v_x3_2446 = NTAG(TAG_Nothing);
                                      }
                                    }
                                    switch (heff_tag_of(v_x3_2446)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_x_2413);
                                      heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                                      heff_drop(v_x_2417);
                                      heff_drop(v_x_2429);
                                      heff_drop(v_x_2435);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_2447 = heff_field(v_x3_2446, 0);
                                      heff_take_n(v_x3_2446, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_2447)) {
                                      case TAG_MkPair: {
                                        V v_x_2448 = heff_field(v_x31_2447, 0);
                                        V v_j_2449 = heff_field(v_x31_2447, 1);
                                        heff_take_n(v_x31_2447, 3ULL, 2);
                                        V v_t_2450 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2413, v_x_2417, v_x_2429, v_x_2435, v_x_2448}), v_j_2449});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2450}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_2447)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_2446)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2434)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_2413);
                                  heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                                  heff_drop(v_x_2417);
                                  heff_drop(v_x_2429);
                                  heff_drop(v_field_2433);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2428)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2413);
                            heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                            heff_drop(v_x_2417);
                            heff_drop(v_field_2427);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2422)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_x_2413);
                      heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
                      heff_drop(v_x_2417);
                      heff_drop(v_field_2421);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2415)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3), 2)) {
          HeffT2 v_t_2451 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
          {
            V v_field_2453 = v_t_2451.f[1];
            int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
            if ((v_tag_2452 == ((int64_t)0ULL))) {
              V v_x31_2454 = v_field_2453;
              switch (heff_tag_of(v_x31_2454)) {
              case TAG_MkPair: {
                V v_x_2455 = heff_field(v_x31_2454, 0);
                V v_j_2456 = heff_field(v_x31_2454, 1);
                V v_ru_24x31_2454_24MkPair = heff_take_reuse_n(v_x31_2454, 3ULL, 2);
                HeffT2 v_t_2457 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_take_field(v_k_240, 1), heff_dup(v_z_242), v_j_2456));
                {
                  V v_field_2459 = v_t_2457.f[1];
                  int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
                  if ((v_tag_2458 == ((int64_t)0ULL))) {
                    V v_x31_2460 = v_field_2459;
                    switch (heff_tag_of(v_x31_2460)) {
                    case TAG_MkPair: {
                      V v_x_2461 = heff_field(v_x31_2460, 0);
                      V v_j_2462 = heff_field(v_x31_2460, 1);
                      heff_take_n(v_x31_2460, 3ULL, 2);
                      HeffT2 v_t_2463 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_j_2462));
                      {
                        V v_field_2465 = v_t_2463.f[1];
                        int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                        if ((v_tag_2464 == ((int64_t)0ULL))) {
                          V v_x31_2466 = v_field_2465;
                          switch (heff_tag_of(v_x31_2466)) {
                          case TAG_MkPair: {
                            V v_x_2467 = heff_field(v_x31_2466, 0);
                            V v_j_2468 = heff_field(v_x31_2466, 1);
                            heff_take_n(v_x31_2466, 3ULL, 2);
                            V v_t_2469 = heff_tag_at_n(v_ru_24x31_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2455, v_x_2461, v_x_2467}), v_j_2468});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2469}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2466)}});
                          }
                        } else {
                          heff_drop(v_x_2455);
                          heff_drop_cell(v_ru_24x31_2454_24MkPair, 2);
                          heff_drop(v_x_2461);
                          heff_drop(v_field_2465);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2460)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2455);
                    heff_drop_cell(v_ru_24x31_2454_24MkPair, 2);
                    heff_drop(v_field_2459);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
              }
            } else {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop(v_field_2453);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4), 2)) {
            V v_t_2470 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeFields_clo), 1, (V[]){v_k_240}));
            HeffT2 v_t_2471 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_2470, v_z_242, v_z_243));
            {
              V v_field_2473 = v_t_2471.f[1];
              int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
              if ((v_tag_2472 == ((int64_t)0ULL))) {
                V v_x31_2474 = v_field_2473;
                switch (heff_tag_of(v_x31_2474)) {
                case TAG_MkPair: {
                  V v_x_2475 = heff_field(v_x31_2474, 0);
                  V v_j_2476 = heff_field(v_x31_2474, 1);
                  V v_ru_24x31_2474_24MkPair = heff_take_reuse_n(v_x31_2474, 3ULL, 2);
                  V v_t_2477 = heff_tag_at_n(v_ru_24x31_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2475}), v_j_2476});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2477}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2474)}});
                }
              } else {
                heff_drop(v_field_2473);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5), 2)) {
              V v_x3_2478 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
              switch (heff_tag_of(v_x3_2478)) {
              case TAG_Nothing: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2479 = heff_field(v_x3_2478, 0);
                V v_ru_24x3_2478_24Just = heff_take_reuse_n(v_x3_2478, 1ULL, 1);
                switch (heff_tag_of(v_x31_2479)) {
                case TAG_MkPair: {
                  V v_x_2480 = heff_field(v_x31_2479, 0);
                  V v_j_2481 = heff_field(v_x31_2479, 1);
                  V v_ru_24x31_2479_24MkPair = heff_take_reuse_n(v_x31_2479, 3ULL, 2);
                  V v_t_2482 = heff_tag_at_n(v_ru_24x31_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2478_24Just, TAG_SIsTy, 1, (V[]){v_x_2480}), v_j_2481});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2482}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2479)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2478)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6), 2)) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                V v_t_2483 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_243});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2483}});
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7), 2)) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  V v_t_2484 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_243});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2484}});
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8), 2)) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    V v_t_2485 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_243});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2485}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      V v_t_2486 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_243});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2486}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10), 2)) {
                        V v_x3_2487 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_2487)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_2488 = heff_field(v_x3_2487, 0);
                          V v_ru_24x3_2487_24Just = heff_take_reuse_n(v_x3_2487, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2488)) {
                          case TAG_MkPair: {
                            V v_x_2489 = heff_field(v_x31_2488, 0);
                            V v_j_2490 = heff_field(v_x31_2488, 1);
                            V v_ru_24x31_2488_24MkPair = heff_take_reuse_n(v_x31_2488, 3ULL, 2);
                            V v_t_2491 = heff_tag_at_n(v_ru_24x31_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2487_24Just, TAG_SPrimArray, 1, (V[]){v_x_2489}), v_j_2490});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2491}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2488)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_2487)}});
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11), 2)) {
                          HeffT2 v_t_2492 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                          {
                            V v_field_2494 = v_t_2492.f[1];
                            int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                            if ((v_tag_2493 == ((int64_t)0ULL))) {
                              V v_x31_2495 = v_field_2494;
                              switch (heff_tag_of(v_x31_2495)) {
                              case TAG_MkPair: {
                                V v_x_2496 = heff_field(v_x31_2495, 0);
                                V v_j_2497 = heff_field(v_x31_2495, 1);
                                V v_ru_24x31_2495_24MkPair = heff_take_reuse_n(v_x31_2495, 3ULL, 2);
                                V v_t_2498 = heff_tag_at_n(v_ru_24x31_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_2496}), v_j_2497});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2498}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2495)}});
                              }
                            } else {
                              heff_drop(v_field_2494);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static HEFF_ONCE g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eserial_2edk_st)) return g_heff_2ebuild_2eserial_2edk_val;
  return heff_global(&g_heff_2ebuild_2eserial_2edk_val, &g_heff_2ebuild_2eserial_2edk_st, g_heff_2ebuild_2eserial_2edk_init);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        return ({ V a_0 = v_k_242; V a_1 = v_x_247; V a_2 = v_s_240; V a_3 = v_j_248; V r_ = (g_heff_2ebuild_2eserial_2etermOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  V v_k_2411 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_249, v_i_2410));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x31_2415 = v_field_2414;
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        heff_take_n(v_x31_2415, 3ULL, 2);
        return ({ V a_0 = v_k_2411; V a_1 = v_x_2416; V a_2 = v_s_249; V a_3 = v_j_2417; V r_ = (g_heff_2ebuild_2eserial_2etypeOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_2416); r_; });
      }
      default: return heff_nomatch(v_x31_2415);
      }
    } else {
      heff_drop(v_s_249);
      heff_drop(v_k_2411);
      heff_drop(v_field_2414);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1, 1, "n");

HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0), 2)) {
    HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x31_246 = v_field_245;
        switch (heff_tag_of(v_x31_246)) {
        case TAG_MkPair: {
          V v_x_247 = heff_field(v_x31_246, 0);
          V v_j_248 = heff_field(v_x31_246, 1);
          V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
          HeffT2 v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_247, v_z_241, v_j_248));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_x31_2412 = v_field_2411;
              switch (heff_tag_of(v_x31_2412)) {
              case TAG_MkPair: {
                V v_x_2413 = heff_field(v_x31_2412, 0);
                V v_j_2414 = heff_field(v_x31_2412, 1);
                heff_take_n(v_x31_2412, 3ULL, 2);
                V v_t_2415 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413}), v_j_2414});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
              }
            } else {
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              heff_drop(v_field_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
        }
      } else {
        heff_drop(v_z_241);
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1), 2)) {
      heff_drop(v_z_241);
      V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}
Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry, 3, 0};

V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(v_x2_240, v_z_241, v_z_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(a0, a[1], a[2]); heff_drop(a0); return r;
}