// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_PathStatus 29154
#define TAG_Right 62770
#define TAG_Tip 31527
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2estampD_24cpr(V, V, V);
V g_heff_2ebuild_2ecommands_2estampPath(V, V, V);
V g_heff_2ebuild_2ecommands_2estampPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estampPath_clo;
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s441678840x388650077(V, V);
V g_list_2efoldl_24s441678840x388650077_entry(V self, V *a);
extern Clo g_list_2efoldl_24s441678840x388650077_clo;
V g_list_2ekeepIf_24s478759078x1735003779(V, V);
V g_list_2ekeepIf_24s478759078x1735003779_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478759078x1735003779_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_str2, 0, "");
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0(V v_ps_240, V v_st_241, V v_real_242, V v_hd_243, V v_id_244, V v_k_245, V v_x_246) {
top: ;
  V v_x_249;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    heff_take_n(v_x_246, 0ULL, 1);
    v_x_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_248 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Right = heff_take_reuse_n(v_x_246, 1ULL, 1);
    v_x_249 = heff_tag_at_n(v_ru_24x_246_24Right, TAG_Just, 1, (V[]){v_y_248});
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_s_2410 = (g_heff_2ebuild_2ecommands_2estampPath(v_ps_240, v_st_241, v_real_242));
  V v_path_2411 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2410));
  V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2411; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2411); r_; });
  V v_a_2414 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_2412, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam0_clo)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam1, 1, 3, (V[]){v_x_249, heff_dup(v_id_244), v_k_245})));
}
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0(a[0], a1, a2, a[3], a4, a[5], a[6]); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam0(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_id_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    V v_text_2423;
    heff_clo_take(self, 3);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      v_text_2423 = ((V)&g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2422 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      v_text_2423 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    HeffT3 v_t_2424 = ({ V a_0 = v_id_244; V a_1 = heff_dup(v_text_2423); V a_2 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2estampD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_244); r_; });
    {
      V v_field_2426 = v_t_2424.f[1];
      V v_field_2427 = v_t_2424.f[2];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      V v_t_2430;
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_x_2428 = v_field_2426;
        V v_j_2429 = v_field_2427;
        if (heff_intLe_c(heff_strLength(v_text_2423), v_j_2429)) {
          v_t_2430 = v_x_2428;
        } else {
          heff_drop(v_x_2428);
          v_t_2430 = NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_text_2423);
        heff_drop(v_field_2426);
        heff_drop(v_field_2427);
        v_t_2430 = NTAG(TAG_Nil);
      }
      V v_ms_2431 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s441678840x388650077(a_0, a_1)); heff_drop(v_t_2430); r_; });
      heff_drop(v_ms_2431);
      V f_ = v_k_245;
      args[0] = heff_dup(g_std_2eordmap_2eempty_get());
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    switch (heff_tag_of(v_y_2432)) {
    case TAG_Left: {
      heff_take_n(v_y_2432, 0ULL, 1);
      V v_text_2435;
      heff_clo_take(self, 3);
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        v_text_2435 = ((V)&g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_str1);
        break;
      }
      case TAG_Just: {
        V v_x_2434 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        v_text_2435 = v_x_2434;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      HeffT3 v_t_2436 = ({ V a_0 = v_id_244; V a_1 = heff_dup(v_text_2435); V a_2 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2estampD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_244); r_; });
      {
        V v_field_2438 = v_t_2436.f[1];
        V v_field_2439 = v_t_2436.f[2];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        V v_t_2442;
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          V v_x_2440 = v_field_2438;
          V v_j_2441 = v_field_2439;
          if (heff_intLe_c(heff_strLength(v_text_2435), v_j_2441)) {
            v_t_2442 = v_x_2440;
          } else {
            heff_drop(v_x_2440);
            v_t_2442 = NTAG(TAG_Nil);
          }
        } else {
          heff_drop(v_text_2435);
          heff_drop(v_field_2438);
          heff_drop(v_field_2439);
          v_t_2442 = NTAG(TAG_Nil);
        }
        V v_ms_2443 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2442; V r_ = (g_list_2efoldl_24s441678840x388650077(a_0, a_1)); heff_drop(v_t_2442); r_; });
        heff_drop(v_ms_2443);
        V f_ = v_k_245;
        args[0] = heff_dup(g_std_2eordmap_2eempty_get());
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    case TAG_Right: {
      V v_x_2444 = heff_field(v_y_2432, 0);
      heff_take_n(v_y_2432, 1ULL, 1);
      V v_text_2446;
      heff_clo_take(self, 3);
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        v_text_2446 = ((V)&g_heff_2ebuild_2ecommands_2estampRead_24s1168194430x418743109_2ek_24l0_str2);
        break;
      }
      case TAG_Just: {
        V v_x_2445 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        v_text_2446 = v_x_2445;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      HeffT3 v_t_2447 = ({ V a_0 = v_id_244; V a_1 = heff_dup(v_text_2446); V a_2 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2estampD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_244); r_; });
      {
        V v_field_2449 = v_t_2447.f[1];
        V v_field_2450 = v_t_2447.f[2];
        int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
        V v_t_2453;
        if ((v_tag_2448 == ((int64_t)0ULL))) {
          V v_x_2451 = v_field_2449;
          V v_j_2452 = v_field_2450;
          if (heff_intLe_c(heff_strLength(v_text_2446), v_j_2452)) {
            v_t_2453 = v_x_2451;
          } else {
            heff_drop(v_x_2451);
            v_t_2453 = NTAG(TAG_Nil);
          }
        } else {
          heff_drop(v_text_2446);
          heff_drop(v_field_2449);
          heff_drop(v_field_2450);
          v_t_2453 = NTAG(TAG_Nil);
        }
        V v_ms_2454 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2453; V r_ = (g_list_2efoldl_24s441678840x388650077(a_0, a_1)); heff_drop(v_t_2453); r_; });
        V v_t_2455 = ({ V a_0 = v_ms_2454; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_ms_2454); r_; });
        V v_ps_2456 = ({ V a_0 = v_x_2444; V a_1 = v_t_2455; V r_ = (g_list_2ekeepIf_24s478759078x1735003779(a_0, a_1)); heff_drop(v_x_2444); r_; });
        V v_x_2457 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2456; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2456); r_; });
        V f_ = v_k_245;
        args[0] = v_x_2457;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_y_2432);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}