// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(V v_p_240, V v_rest_241, V v_acc_242, V v_hd_243, V v_k_244, V v_x_245) {
top: ;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    heff_take_n(v_x_245, 0ULL, 1);
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_240, 0)) - ((int64_t)3ULL));
    V v_t_248 = heff_strSlice_lent(v_p_240, heff_box_word(v_t_247), heff_strLength_lent(v_p_240, 0), 6);
    if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_str0))) {
      V v_t_249 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(v_rest_241, heff_tag_n(TAG_Cons, 2, (V[]){v_p_240, v_acc_242})));
      return heff_tail(v_t_249, 2, (V[]){v_hd_243, v_k_244});
    } else {
      heff_drop(v_p_240);
      V v_t_2410 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(v_rest_241, v_acc_242));
      return heff_tail(v_t_2410, 2, (V[]){v_hd_243, v_k_244});
    }
  }
  case TAG_Right: {
    V v_y_2411 = heff_field(v_x_245, 0);
    V v_ru_24x_245_24Right = heff_take_reuse_n(v_x_245, 1ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24x_245_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam0_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    return (g_co_2eop_24s535099379x685970669(v_t_2418, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam1, 1, 6, (V[]){v_y_2411, v_rest_241, v_p_240, v_acc_242, v_hd_243, v_k_244})));
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam2(V self, V *args) {
  V v_n_2422 = args[0];
  V v_st_2420 = heff_env(self)[0];
  V v_p_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2420), v_p_240));
  V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2420), v_n_2422));
  V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
  return ({ V a_0 = v_st_2420; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2425); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_y_2411 = heff_env(self)[0];
  V v_rest_241 = heff_env(self)[1];
  V v_p_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_st_2420;
  if (heff_strEq_c(v_x_2419, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_str1))) {
    v_st_2420 = NTAG(TAG_Windows);
  } else {
    v_st_2420 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 6);
  V v_t_2421 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_str2); V a_3 = v_y_2411; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2426 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_241, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_lam2, 1, 2, (V[]){v_st_2420, v_p_240}), v_t_2421));
  V v_t_2427 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(v_t_2426, v_acc_242));
  V f_ = v_t_2427;
  heff_room[0] = v_hd_243;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}