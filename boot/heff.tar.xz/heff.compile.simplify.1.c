// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_caps 9541544
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_e 319
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_n 328
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_binds__args[] = {LBL_binds, LBL_args};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2esimplify_2eallPure(V, V);
V g_heff_2ecompile_2esimplify_2eallPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallPure_clo;
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eargPure(V, V);
V g_heff_2ecompile_2esimplify_2eargPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eargPure_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopyField(V);
V g_heff_2ecompile_2esimplify_2ecopyField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyField_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2eglobalLiteral(V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eglobalLiteral_clo;
V g_heff_2ecompile_2esimplify_2egrew(V, V);
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrew_clo;
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandedField(V, V);
V g_heff_2ecompile_2esimplify_2ehandedField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedField_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2ehandlerPushed(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo;
V g_heff_2ecompile_2esimplify_2eknownField(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownField_clo;
V g_heff_2ecompile_2esimplify_2emakeAgain(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeAgain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeAgain_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2eprojW(V, V, V);
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojW_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushBound(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordTakenApart_clo;
V g_heff_2ecompile_2esimplify_2eshapeOne(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ewordLiteral(V);
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s756915015x218492736(V);
V g_list_2eany_24s756915015x218492736_entry(V self, V *a);
extern Clo g_list_2eany_24s756915015x218492736_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s688118489x1560799399(V, V, V);
V g_list_2efoldl_24s688118489x1560799399_entry(V self, V *a);
extern Clo g_list_2efoldl_24s688118489x1560799399_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1492759219x1917596721(V, V);
V g_list_2emap_24s1492759219x1917596721_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakeL_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esplitArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esplitArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esplitArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_rec_n(2, shape_binds__args, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_a_243));
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam0, 1, 2, (V[]){v_t_245, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam1, 2, 1, (V[]){v_as_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esplitArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_t_245 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_246});
  } else {
    heff_drop(v_t_245);
    V v_x2_248 = (g_heff_2ecompile_2esimplify_2efreshName(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_str0), v_p_246));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_x_249), v_a_243})});
      V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_tag_n(TAG_EVar, 1, (V[]){v_x_249})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_s_2410});
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args) {
  V v_one_2413 = args[0];
  V v_z_2414 = args[1];
  V v_as_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_clo), 1, (V[]){v_as_244}));
  V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_2414}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_a_2421;
    switch (heff_tag_of(v_one_2413)) {
    case TAG_MkPair: {
      V v_y_2420 = heff_dup(heff_field(v_one_2413, 1));
      v_a_2421 = v_y_2420;
      break;
    }
    default: heff_nomatch(v_one_2413);
    }
    V v_t_2424;
    switch (heff_tag_of(v_one_2413)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_one_2413, 0);
      heff_take_n(v_one_2413, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_one_2413);
    }
    V v_t_2429;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nothing: {
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2421, heff_take_field(v_x_2417, 1)});
      v_t_2429 = ({ V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_x_2417, 1ULL, 2, shape_binds__args, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      break;
    }
    case TAG_Just: {
      V v_bd_2426 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2426, heff_take_field(v_x_2417, 0)});
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2421, heff_get_n(v_x_2417, 1, 2)});
      v_t_2429 = heff_rec_n(2, shape_binds__args, (V[]){v_t_2427, v_t_2428});
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
Clo g_heff_2ecompile_2esimplify_2eprojW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprojW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_as_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_as_2410, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2415;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2416, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2418;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V v_t_2457;
      switch (heff_tag_of(v_e_2419)) {
      case TAG_EVar: {
        V v_y_2423 = heff_dup(heff_field(v_e_2419, 0));
        v_t_2457 = heff_strEq_lent(v_x_240, v_y_2423, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2419);
      }
      if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_e_2419);
        heff_drop(v_t_2457);
        V t_0 = v_x_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2457);
        V t_0 = v_x_240;
        V t_1 = v_n_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
        v_x_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_ETag: {
      V v_as_2459 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2461 = (g_heff_2ecompile_2eir_2eappendI(v_as_2459, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2461;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2462 = heff_field(v_x31_243, 0);
      V v_arms_2463 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2464 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2463, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2462, v_t_2464});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2467 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2468 = (g_heff_2ecompile_2eir_2eappendI(v_as_2467, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2468;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2470 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2471 = (g_heff_2ecompile_2eir_2eappendI(v_as_2470, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2471;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2erecordTakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordTakenApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordTakenApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_a_241, 0);
    heff_take_n(v_a_241, 1ULL, 2);
    V v_t_2414 = (g_list_2emap_24s1044393341x1523302351(v_fs_2412));
    V v_x1_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
    heff_drop(v_x1_2415);
    V v_ret_24bool = heff_bool(((heff_dup(v_t_2416) == NTAG(TAG_True)) && ({ V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2418 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_2417))); int c_ = ({ V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2420 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_240), heff_dup(v_t_2419))); int c_ = ({ V v_x_2421 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2418), heff_dup(v_t_2420)}), 0, 2); int c_ = (heff_intLe_c(MK_INT(2LL), heff_dup(v_x_2421)) && ({ V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2424 = (g_heff_2ecompile_2esimplify_2eprojW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_2423))); int c_ = ({ V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2426 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_2425))); int c_ = ({ V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2428 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_240), heff_dup(v_t_2427))); int c_ = ({ V v_t_2429 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2426), heff_dup(v_t_2428)}), 0, 2); int c_ = heff_intEq_c(heff_dup(v_t_2424), heff_dup(v_t_2429)); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2427); c_; }); heff_drop(v_t_2426); c_; }); heff_drop(v_t_2425); c_; }); heff_drop(v_t_2424); c_; }); heff_drop(v_t_2423); c_; })); heff_drop(v_x_2421); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2419); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2417); c_; })));
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    heff_drop(v_t_2416);
    return v_ret_24bool;
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2erecordTakenApart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordTakenApart(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eglobalLiteral_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eglobalLiteral_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eglobalLiteral(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_240});
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_t_244 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_244);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_244);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EGlobal: {
      V v_h_245 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_h_245});
    }
    case TAG_ELam: {
      V v_t_248 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_248);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_248);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EApp: {
      V v_t_2411 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2411);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ELet: {
      V v_t_2415 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2415);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_t_2415);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ERecord: {
      V v_t_2418 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2418);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2418);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EProj: {
      V v_t_2423 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2423);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 4);
        heff_drop(v_t_2423);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ETag: {
      V v_t_2427 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2427);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 3);
        heff_drop(v_t_2427);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EMatch: {
      V v_t_2430 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2430);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2430);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EPrim: {
      V v_t_2432 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2432);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2432);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EPrimCall: {
      V v_t_2435 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2435);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2435);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_ECall: {
      V v_t_2438 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2438);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2438);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EInt: {
      V v_t_2440 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2440);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2440);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFloat: {
      V v_t_2442 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2442);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2442);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EStr: {
      V v_t_2444 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2444);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2444);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EBytes: {
      V v_t_2446 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2446);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2446);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFixed: {
      V v_t_2449 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2449);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2449);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFloat32: {
      V v_t_2451 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2451);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 1);
        heff_drop(v_t_2451);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EAbandon: {
      V v_t_2452 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2452);
        return v_x21_242;
      } else {
        heff_drop(v_t_2452);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    case TAG_EFix: {
      V v_t_2455 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_x21_242));
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop(v_g_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_t_2455);
        return v_x21_242;
      } else {
        heff_drop_tag(v_x21_242, 2);
        heff_drop(v_t_2455);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_EGlobal, 1, (V[]){v_g_240});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eglobalLiteral_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eglobalLiteral(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartW_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapartW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2444;
      switch (heff_tag_of(v_f_248)) {
      case TAG_EVar: {
        V v_y_2410 = heff_dup(heff_field(v_f_248, 0));
        v_t_2444 = heff_strEq_lent(v_x_240, v_y_2410, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_f_248);
      }
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_f_248);
        heff_drop(v_as_249);
        heff_drop(v_t_2444);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2444);
        V v_t_2445 = (g_heff_2ecompile_2eir_2eappendI(v_as_249, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2445});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ELet: {
      V v_a_2447 = heff_field(v_x21_242, 1);
      V v_b_2448 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2449 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2448, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2449;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2450 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2452 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2450, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2452;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2453 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V v_t_2491;
      switch (heff_tag_of(v_e_2453)) {
      case TAG_EVar: {
        V v_y_2457 = heff_dup(heff_field(v_e_2453, 0));
        v_t_2491 = heff_strEq_lent(v_x_240, v_y_2457, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2453);
      }
      if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2453);
        heff_drop(v_t_2491);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2491);
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2453, v_rest_243});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ETag: {
      V v_as_2493 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2495 = (g_heff_2ecompile_2eir_2eappendI(v_as_2493, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2495;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2496 = heff_field(v_x21_242, 0);
      V v_arms_2497 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24132;
      switch (heff_tag_of(v_sc_2496)) {
      case TAG_EVar: {
        V v_y_2498 = heff_dup(heff_field(v_sc_2496, 0));
        v_t_24132 = heff_strEq_lent(v_x_240, v_y_2498, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_2496);
      }
      if ((heff_dup(v_t_24132) == NTAG(TAG_True))) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_sc_2496);
        heff_drop(v_arms_2497);
        heff_drop(v_t_24132);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_24132);
        V v_t_24133 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2497, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_sc_2496, v_t_24133});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_24136 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_24137 = (g_heff_2ecompile_2eir_2eappendI(v_as_24136, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24137;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_24139 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_24140 = (g_heff_2ecompile_2eir_2eappendI(v_as_24139, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24140;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapartW(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_as_2412 = heff_field(v_x3_242, 1);
        if ((heff_dup(v_m_245) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_248, heff_dup(v_a_2411), v_e_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_as_2412)});
        } else {
          heff_drop(v_m_245);
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_as_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esubstMarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_as_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_as_2412; V a_3 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_as_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapeOne_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapeOne(V v_m_240, V v_a_241, V v_s_242) {
top: ;
  if ((heff_dup(v_m_240) == NTAG(TAG_True))) {
    V v_t_243 = heff_rec_n(5, shape_ren__caps__vars__holes__n, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_s_242, 0)});
    V v_x1_244 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_241, v_t_243));
    V v_x_249;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_st_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 2)));
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 3)));
      v_x_249 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_e_245, v_t_247, v_t_248, heff_get_n(v_st_246, 4, 5)});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_x_249, 3)); V rr_ = heff_rec_reuse_nf(v_s_242, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2410});
  } else {
    V v_t_2411 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_a_241, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 0))});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_s_242});
  }
}
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eshapeOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_246 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_244), v_as_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2414;
    if (heff_intLt_c(v_y_2410, v_x_249)) {
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2412, v_ys_244));
      v_e_2414 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_245});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_245;
    }
    V v_t_2415 = (g_map_2esize(v_m_248));
    if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
      heff_drop(v_m_248);
      return v_e_2414;
    } else {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
  }
  case TAG_EApp: {
    V v_e1_2417 = heff_dup(heff_field(v_e_241, 0));
    V v_as_2418 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_2417)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EGlobal: {
      V v_g_2420 = heff_field(v_e1_2417, 0);
      V v_ru_24e1_2417_24EGlobal = heff_take_reuse_n(v_e1_2417, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2421 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2eappendL(v_as_2418, v_t_2421));
      return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2417_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2420}), v_t_2422});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2417, 0ULL, 4);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    default: return heff_nomatch(v_e1_2417);
    }
  }
  case TAG_ELet: {
    V v_x_2455 = heff_field(v_e_241, 0);
    V v_a_2456 = heff_field(v_e_241, 1);
    V v_b_2457 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2458 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2455, v_a_2456, heff_hole()});
    V v_u_2459 = (g_heff_2ecompile_2esimplify_2estripLams_24dps(v_zs_240, v_b_2457, heff_dup(v_cell_2458)));
    heff_drop(v_u_2459);
    return v_cell_2458;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2469 = heff_field(v_e_241, 0);
    V v_arms_2470 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2471 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2471}), v_arms_2470));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2469, v_t_2477});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2472 = args[0];
  V v_go_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2472)) {
  case TAG_MkArm: {
    V v_t_2473 = heff_field(v_x2_2472, 0);
    V v_vs_2474 = heff_field(v_x2_2472, 1);
    V v_b_2475 = heff_field(v_x2_2472, 2);
    V v_ru_24x2_2472_24MkArm = heff_take_reuse_n(v_x2_2472, 7ULL, 3);
    V v_t_2476 = heff_tr(heff_call(v_go_2471, 1, (V[]){v_b_2475}));
    return heff_tag_at_n(v_ru_24x2_2472_24MkArm, TAG_MkArm, 3, (V[]){v_t_2473, v_vs_2474, v_t_2476});
  }
  default: return heff_nomatch(v_x2_2472);
  }
}
Clo g_heff_2ecompile_2esimplify_2eallPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallPure(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_p_241});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eargPure(v_a_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_245);
        V t_0 = v_as_243;
        V t_1 = v_s_246;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        goto top;
      } else {
        heff_drop(v_as_243);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_246});
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eallPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallPure(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V v_s_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_as_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1742233102x56855645(heff_dup(v_s_240), v_as_244));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_s_240;
      V t_1 = v_as_244;
      V t_2 = v_cell_246;
      v_s_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_243);
      heff_drop(v_as_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2epushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2epushable(V v_a_240) {
top: ;
  V v_t_2435;
  switch (heff_tag_of(v_a_240)) {
  case TAG_EVar: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_a_240);
    heff_drop(v_t_2435);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2435);
    V v_t_2436 = (g_heff_2ecompile_2eir_2eisValue(v_a_240));
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      V v_t_2437 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_240)));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_a_240);
        heff_drop(v_t_2437);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2437);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2ehandlerLike(v_a_240);
      }
    } else {
      heff_drop(v_a_240);
      heff_drop(v_t_2436);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushable(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ecopyField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyField_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecopyField(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    V v_x11_2412 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyField_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyField(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ecompile_2esimplify_2ehandedField(heff_dup(v_lit_240), v_x_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam1, 1, 3, (V[]){v_m_245, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146(v_lit_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam44(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_as_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  } else {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop_rec(v_r_240, 4);
      V v_x_247 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_247});
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_as_242, v_g_249, v_r_240, v_f_241});
    }
    case TAG_ELam: {
      V v_xs_2426 = heff_field(v_f_241, 0);
      V v_it2_2427 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2427)) {
      case TAG_EVar: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EGlobal: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_ELam: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EApp: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_ELet: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_ERecord: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EProj: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_ETag: {
        V v_t_2443 = heff_field(v_it2_2427, 0);
        V v_es_2444 = heff_field(v_it2_2427, 1);
        V v_ts_2445 = heff_field(v_it2_2427, 2);
        V v_ru_24it2_2427_24ETag = heff_take_reuse_n(v_it2_2427, 7ULL, 3);
        V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2426));
        V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
        if (heff_intEq_c(v_t_2446, v_t_2447)) {
          V v_t_2449 = (g_heff_2ecompile_2esimplify_2evarsAre(v_xs_2426, v_es_2444));
          if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_xs_2426);
            heff_drop(v_es_2444);
            heff_drop_cell(v_ru_24it2_2427_24ETag, 3);
            heff_drop(v_t_2449);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam5, 1, 3, (V[]){v_t_2443, v_as_242, v_ts_2445});
          } else {
            heff_drop(v_t_2449);
            return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, heff_tag_at_n(v_ru_24it2_2427_24ETag, TAG_ETag, 3, (V[]){v_t_2443, v_es_2444, v_ts_2445}), v_as_242));
          }
        } else {
          return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, heff_tag_at_n(v_ru_24it2_2427_24ETag, TAG_ETag, 3, (V[]){v_t_2443, v_es_2444, v_ts_2445}), v_as_242));
        }
      }
      case TAG_EMatch: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EPrim: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EPrimCall: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_ECall: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EInt: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EFloat: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EStr: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EBytes: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EFixed: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EFloat32: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EAbandon: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      case TAG_EFix: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2426, v_it2_2427, v_as_242));
      }
      default: return heff_nomatch(v_it2_2427);
      }
    }
    case TAG_EApp: {
      V v_g_2467 = heff_field(v_f_241, 0);
      V v_bs_2468 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      V v_t_2469 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2468, v_as_242));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_g_2467, v_t_2469});
    }
    case TAG_ELet: {
      V v_x_2470 = heff_field(v_f_241, 0);
      V v_a_2471 = heff_field(v_f_241, 1);
      V v_b_2472 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2473 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2472, v_as_242}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam6, 1, 3, (V[]){v_m_2473, v_x_2470, v_a_2471});
    }
    case TAG_ERecord: {
      heff_drop_rec(v_r_240, 4);
      V v_x_2480 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam7, 1, 1, (V[]){v_x_2480});
    }
    case TAG_EProj: {
      V v_it1_2482 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2483 = heff_dup(heff_field(v_f_241, 1));
      V v_sh_2484 = heff_dup(heff_field(v_f_241, 2));
      V v_t_2485 = heff_dup(heff_field(v_f_241, 3));
      switch (heff_tag_of(v_it1_2482)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_2487 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam8, 1, 1, (V[]){v_x_2487});
      }
      case TAG_EGlobal: {
        V v_g_2489 = heff_field(v_it1_2482, 0);
        heff_take_n(v_it1_2482, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam9, 1, 7, (V[]){v_g_2489, v_l_2483, v_f_241, v_as_242, v_r_240, v_sh_2484, v_t_2485});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24113 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_24113});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24117 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24117});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2482, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24122 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam13, 1, 1, (V[]){v_x_24122});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24126 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24126});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2482, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24132 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24132});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2482, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24137 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24137});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24141 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24141});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24144 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24144});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24148 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24148});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24152 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24152});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24155 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24155});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24158 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24158});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24161 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24161});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24164 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24164});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24168 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam25, 1, 1, (V[]){v_x_24168});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_2482, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24171 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam26, 1, 1, (V[]){v_x_24171});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24173 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam27, 1, 1, (V[]){v_x_24173});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2482, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2483);
        heff_drop(v_sh_2484);
        heff_drop(v_t_2485);
        V v_x_24177 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam28, 1, 1, (V[]){v_x_24177});
      }
      default: return heff_nomatch(v_it1_2482);
      }
    }
    case TAG_ETag: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24182 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam29, 1, 1, (V[]){v_x_24182});
    }
    case TAG_EMatch: {
      V v_s_24184 = heff_field(v_f_241, 0);
      V v_arms_24185 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EMatch = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_24186 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_as_242)));
      V v_t_24187 = ({ V a_0 = v_t_24186; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24186); r_; });
      V v_t_24191 = heff_bool(((heff_dup(v_t_24187) == NTAG(TAG_True)) && ({ V v_t_24188 = (g_list_2efoldl_24s688118489x1560799399(MK_INT(0LL), MK_INT(0LL), heff_dup(v_as_242))); int c_ = ({ V v_t_24189 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24185)); int c_ = ({ V v_t_24190 = heff_intMul(heff_dup(v_t_24188), heff_intSub(heff_dup(v_t_24189), MK_INT(1LL))); int c_ = heff_intLe_c(heff_dup(v_t_24190), MK_INT(120LL)); heff_drop(v_t_24190); c_; }); heff_drop(v_t_24189); c_; }); heff_drop(v_t_24188); c_; })));
      heff_drop(v_t_24187);
      if ((heff_dup(v_t_24191) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24f_241_24EMatch, 2);
        heff_drop(v_t_24191);
        V v_m_24203 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam30, 1, 2, (V[]){v_as_242, v_r_240}), v_arms_24185));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam32, 1, 2, (V[]){v_m_24203, v_s_24184});
      } else {
        heff_drop(v_t_24191);
        V v_t_24208 = (g_heff_2ecompile_2esimplify_2ehandlerPushed(v_arms_24185, heff_dup(v_as_242)));
        if ((heff_dup(v_t_24208) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24f_241_24EMatch, 2);
          heff_drop(v_t_24208);
          return (g_heff_2ecompile_2esimplify_2epushBound(v_r_240, v_s_24184, v_arms_24185, v_as_242));
        } else {
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_t_24208);
          V v_x_24209 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24f_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_24184, v_arms_24185}), v_as_242));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24209});
        }
      }
    }
    case TAG_EPrim: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24212 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24212});
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24216 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24216});
    }
    case TAG_ECall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24220 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24220});
    }
    case TAG_EInt: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24223 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam37, 1, 1, (V[]){v_x_24223});
    }
    case TAG_EFloat: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24226 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam38, 1, 1, (V[]){v_x_24226});
    }
    case TAG_EStr: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24229 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam39, 1, 1, (V[]){v_x_24229});
    }
    case TAG_EBytes: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24232 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam40, 1, 1, (V[]){v_x_24232});
    }
    case TAG_EFixed: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24236 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam41, 1, 1, (V[]){v_x_24236});
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24239 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam42, 1, 1, (V[]){v_x_24239});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24241 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam43, 1, 1, (V[]){v_x_24241});
    }
    case TAG_EFix: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24245 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam44, 1, 1, (V[]){v_x_24245});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_as_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_as_242, v_s_2414});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  V v_as_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_as_242, v_s_2415});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_g_249 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = (g_list_2eany_24s756915015x218492736(v_as_242));
  V v_m_2416;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_2410, 7)), 1, 7);
    V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_as_242; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2412); r_; });
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      v_m_2416 = (g_heff_2ecompile_2esimplify_2etraverseS_24s2038785525x734134146(heff_dup(v_s_2410), v_as_242));
    } else {
      heff_drop(v_t_2413);
      v_m_2416 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam3, 1, 1, (V[]){v_as_242});
    }
  } else {
    heff_drop(v_t_2411);
    v_m_2416 = heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam4, 1, 1, (V[]){v_as_242});
  }
  V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){heff_dup(v_s_2410)}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = ({ V a_0 = heff_dup(v_g_249); V b_1 = heff_get_n(v_s_2410, 2, 9); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_m_2421 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_249); V a_3 = heff_dup(v_x_2418); V a_4 = v_t_2420; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2420); r_; });
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      V v_t_2425 = (g_heff_2ecompile_2esimplify_2estillCall(heff_dup(v_g_249), v_x_2423));
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_2417_24MkPair, 2);
        heff_drop(v_x_2423);
        heff_drop(v_t_2425);
        return (g_heff_2ecompile_2esimplify_2etrySpec(v_r_240, v_g_249, v_x_2418, v_s_2424));
      } else {
        heff_drop(v_g_249);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_x_2418);
        heff_drop(v_t_2425);
        return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
      }
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2450 = args[0];
  V v_t_2443 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  V v_ts_2445 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2443, v_as_242, v_ts_2445}), v_s_2450});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  V v_a_2471 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2470, v_a_2471, v_x_2476}), v_s_2477});
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2480, v_s_2481});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2488 = args[0];
  V v_x_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2487, v_s_2488});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    heff_take_n(v_x2_24108, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_24109;
    heff_room[1] = v_as_242;
    heff_room[2] = v_s_24110;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_2490 = args[0];
  V v_g_2489 = heff_env(self)[0];
  V v_l_2483 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  V v_sh_2484 = heff_env(self)[5];
  V v_t_2485 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2491 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2489), heff_rfield(v_s_2490, 2)));
  V v_x2_2492 = (g_heff_2ecompile_2esimplify_2efueled(v_t_2491, v_s_2490));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_s_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    switch (heff_tag_of(v_x_2493)) {
    case TAG_Nothing: {
      heff_drop(v_sh_2484);
      heff_drop(v_t_2485);
      V v_x2_2495 = (g_heff_2ecompile_2esimplify_2eknownField(v_g_2489, v_l_2483, v_s_2494));
      switch (heff_tag_of(v_x2_2495)) {
      case TAG_MkPair: {
        V v_x_2496 = heff_field(v_x2_2495, 0);
        V v_s_2497 = heff_field(v_x2_2495, 1);
        heff_take_n(v_x2_2495, 3ULL, 2);
        switch (heff_tag_of(v_x_2496)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2498 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
          return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){v_x_2498, v_s_2497});
        }
        case TAG_Just: {
          V v_v_2499 = heff_field(v_x_2496, 0);
          heff_take_n(v_x_2496, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2492_24MkPair, 2);
          V v_t_24100 = (g_list_2eany_24s415398368x1824706470(v_as_242));
          V v_t_24101;
          if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
            heff_drop(v_t_24100);
            v_t_24101 = MK_INT(160LL);
          } else {
            heff_drop(v_t_24100);
            v_t_24101 = MK_INT(24LL);
          }
          V v_t_24102 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
          V v_t_24103 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_v_2499, v_as_242}));
          return (g_heff_2ecompile_2esimplify_2eattemptBy(v_t_24101, v_t_24102, v_t_24103, v_s_2497));
        }
        default: return heff_nomatch(v_x_2496);
        }
      }
      default: return heff_nomatch(v_x2_2495);
      }
    }
    case TAG_Just: {
      V v_b_24104 = heff_field(v_x_2493, 0);
      heff_take_n(v_x_2493, 1ULL, 1);
      heff_drop(v_g_2489);
      heff_drop_cell(v_ru_24x2_2492_24MkPair, 2);
      V v_orig_24105 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
      V v_m_24106 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 4, (V[]){v_l_2483, v_sh_2484, v_t_2485, v_b_24104}));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_24105, heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam10, 1, 3, (V[]){v_m_24106, v_r_240, v_as_242}), v_s_2494));
    }
    default: return heff_nomatch(v_x_2493);
    }
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24113, v_s_24114});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24118 = args[0];
  V v_x_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24117, v_s_24118});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24123 = args[0];
  V v_x_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24122, v_s_24123});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24127 = args[0];
  V v_x_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24126, v_s_24127});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24133 = args[0];
  V v_x_24132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24132, v_s_24133});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24137, v_s_24138});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24142 = args[0];
  V v_x_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24142});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24144, v_s_24145});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24149 = args[0];
  V v_x_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24148, v_s_24149});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24153 = args[0];
  V v_x_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24152, v_s_24153});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24156 = args[0];
  V v_x_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24155, v_s_24156});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24159 = args[0];
  V v_x_24158 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24158, v_s_24159});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24162 = args[0];
  V v_x_24161 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24161, v_s_24162});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24165 = args[0];
  V v_x_24164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24164, v_s_24165});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_s_24169 = args[0];
  V v_x_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24168, v_s_24169});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24172 = args[0];
  V v_x_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24171, v_s_24172});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_s_24174 = args[0];
  V v_x_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24173, v_s_24174});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_s_24178 = args[0];
  V v_x_24177 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24177, v_s_24178});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24183 = args[0];
  V v_x_24182 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24182, v_s_24183});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24196 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_24195 = heff_env(self)[2];
  V v_t_24193 = heff_env(self)[3];
  V v_vs_24194 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24197 = (g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(v_as_242, v_s_24196));
  V v_x2_24200;
  switch (heff_tag_of(v_x2_24197)) {
  case TAG_MkPair: {
    V v_x_24198 = heff_field(v_x2_24197, 0);
    V v_s_24199 = heff_field(v_x2_24197, 1);
    heff_take_n(v_x2_24197, 3ULL, 2);
    v_x2_24200 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 3, (V[]){v_b_24195, v_x_24198, v_s_24199}));
    break;
  }
  default: heff_nomatch(v_x2_24197);
  }
  switch (heff_tag_of(v_x2_24200)) {
  case TAG_MkPair: {
    V v_x_24201 = heff_field(v_x2_24200, 0);
    V v_s_24202 = heff_field(v_x2_24200, 1);
    V v_ru_24x2_24200_24MkPair = heff_take_reuse_n(v_x2_24200, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24193, v_vs_24194, v_x_24201}), v_s_24202});
  }
  default: return heff_nomatch(v_x2_24200);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_a_24192 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24192)) {
  case TAG_MkArm: {
    V v_t_24193 = heff_field(v_a_24192, 0);
    V v_vs_24194 = heff_field(v_a_24192, 1);
    V v_b_24195 = heff_field(v_a_24192, 2);
    heff_take_n(v_a_24192, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam31, 1, 5, (V[]){v_as_242, v_r_240, v_b_24195, v_t_24193, v_vs_24194});
  }
  default: return heff_nomatch(v_a_24192);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_s_24184 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_s_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_s_24207 = heff_field(v_x2_24205, 1);
    V v_ru_24x2_24205_24MkPair = heff_take_reuse_n(v_x2_24205, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_24184, v_x_24206}), v_s_24207});
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24210 = args[0];
  V v_x_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24209, v_s_24210});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24213 = args[0];
  V v_x_24212 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24212, v_s_24213});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24217 = args[0];
  V v_x_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24216, v_s_24217});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24221 = args[0];
  V v_x_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24220, v_s_24221});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args) {
  V v_s_24224 = args[0];
  V v_x_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24223, v_s_24224});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args) {
  V v_s_24227 = args[0];
  V v_x_24226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24226, v_s_24227});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args) {
  V v_s_24230 = args[0];
  V v_x_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24229, v_s_24230});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args) {
  V v_s_24233 = args[0];
  V v_x_24232 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24232, v_s_24233});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args) {
  V v_s_24237 = args[0];
  V v_x_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24236, v_s_24237});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args) {
  V v_s_24240 = args[0];
  V v_x_24239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24239, v_s_24240});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam43(V self, V *args) {
  V v_s_24242 = args[0];
  V v_x_24241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24241, v_s_24242});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam44(V self, V *args) {
  V v_s_24246 = args[0];
  V v_x_24245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24245, v_s_24246});
}
Clo g_heff_2ecompile_2esimplify_2egrewIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egrewIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2egrewIn(V v_s0_240, V v_s1_241, V v_b_242) {
top: ;
  if (heff_intEq_c(heff_dup(heff_rfield(v_s1_241, 0)), heff_dup(heff_rfield(v_s0_240, 0)))) {
    heff_drop_rec(v_s0_240, 9);
    heff_drop_rec(v_s1_241, 9);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  } else {
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
    V v_hs_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_246 = heff_get_n(heff_get_n(v_s0_240, 7, 9), 0, 7);
    V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_hs_245; V r_ = (g_list_2emap_24s1492759219x1917596721(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
    V v_hs_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
    V v_t_2410 = heff_get_n(heff_get_n(v_s1_241, 7, 9), 0, 7);
    V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_hs_249; V r_ = (g_list_2emap_24s1492759219x1917596721(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return ({ V a_0 = v_t_247; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2egrew(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_2411); r_; });
  }
}
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2egrewIn(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emakeAgain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeAgain_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeAgain(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 4, 5);
  V v_x2_244 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_k_245 = heff_dup(heff_rfield(v_s_242, 8));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_k_245, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_249 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), heff_take_field(v_s_242, 3), heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 6), heff_take_field(v_s_242, 7), v_t_248});
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eownSt(v_t_249));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_MkPair: {
    V v_s_2412 = heff_field(v_t_2410, 1);
    V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 2ULL, 2);
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b_241));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_s_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2415, v_s_2416));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_s_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        V v_k_2420 = heff_dup(heff_rfield(v_s_2419, 8));
        V v_t_2421 = heff_get_n(heff_get_n(v_s_242, 8, 9), 2, 5);
        V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_2419, 8)), 2, 5);
        V v_t_2423 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_t_2422, heff_take_field(v_k_2420, 4)));
        V v_k_2424 = ({ V rv_2 = v_t_2421; V rv_4 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_k_2420, 11ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 207u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
        V v_t_2425 = ({ V rv_8 = v_k_2424; V rr_ = heff_rec_reuse_nf(v_s_2419, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
        return heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_t_2425});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ecompile_2esimplify_2emakeAgain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeAgain(a[0], a[1], a[2]);
}