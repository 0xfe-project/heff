// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_deeper 611485124
#define LBL_defs 9574869
#define LBL_env 310119
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_self 10021907
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_unrolled 706233391
#define LBL_vers 10111479
static uint32_t shape_binds__args[] = {LBL_binds, LBL_args};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_deeper__env__self__at[] = {LBL_deeper, LBL_env, LBL_self, LBL_at};
static uint32_t shape_key__body__safe__touched[] = {LBL_key, LBL_body, LBL_safe, LBL_touched};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
HeffT2 g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo;
V g_heff_2ecompile_2esimplify_2eatomsGiven(V, V);
V g_heff_2ecompile_2esimplify_2eatomsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eatomsGiven_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_clo;
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo;
V g_heff_2ecompile_2esimplify_2ecallsW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967(V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_clo;
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efindField_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efirstCalled(V, V);
V g_heff_2ecompile_2esimplify_2efirstCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efirstCalled_clo;
V g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(V, V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_clo;
V g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581_clo;
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024(V, V);
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_clo;
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_clo;
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(V, V, V);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2egivenTelling(V, V, V);
V g_heff_2ecompile_2esimplify_2egivenTelling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egivenTelling_clo;
V g_heff_2ecompile_2esimplify_2egivesItBack(V, V);
V g_heff_2ecompile_2esimplify_2egivesItBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egivesItBack_clo;
V g_heff_2ecompile_2esimplify_2egrew(V, V);
V g_heff_2ecompile_2esimplify_2egrew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrew_clo;
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2ehandlerOf(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerOf_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
V g_heff_2ecompile_2esimplify_2elastUseW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2elastUseW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elastUseW_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
V g_heff_2ecompile_2esimplify_2ematchesFirst(V, V);
V g_heff_2ecompile_2esimplify_2ematchesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchesFirst_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2emovesFirst(V, V);
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo;
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2epastLastUse(V, V, V);
V g_heff_2ecompile_2esimplify_2epastLastUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epastLastUse_clo;
V g_heff_2ecompile_2esimplify_2eprojW(V, V, V);
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojW_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor(V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_clo;
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_clo;
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etagGo(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagGo_clo;
V g_heff_2ecompile_2esimplify_2etagGo_24dps(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2etagMatched(V, V, V);
V g_heff_2ecompile_2esimplify_2etagMatched_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagMatched_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etakenW(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etakenW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakenW_clo;
V g_heff_2ecompile_2esimplify_2etestsOf(V, V);
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etestsOf_clo;
V g_heff_2ecompile_2esimplify_2evalueTag(V);
V g_heff_2ecompile_2esimplify_2evalueTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evalueTag_clo;
V g_heff_2ecompile_2esimplify_2evaluesGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2evaluesGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesGiven_clo;
V g_heff_2ecompile_2esimplify_2evarsW(V, V);
V g_heff_2ecompile_2esimplify_2evarsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsW_clo;
V g_list_2eall_24s1447613073x1712348205(V);
V g_list_2eall_24s1447613073x1712348205_entry(V self, V *a);
extern Clo g_list_2eall_24s1447613073x1712348205_clo;
V g_list_2eall_24s1934518973x1420187537(V);
V g_list_2eall_24s1934518973x1420187537_entry(V self, V *a);
extern Clo g_list_2eall_24s1934518973x1420187537_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s392952474x1351014279(V, V);
V g_list_2eany_24s392952474x1351014279_entry(V self, V *a);
extern Clo g_list_2eany_24s392952474x1351014279_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1544308498x936697067(V, V);
V g_list_2efoldl_24s1544308498x936697067_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1544308498x936697067_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1492759219x1917596721(V, V);
V g_list_2emap_24s1492759219x1917596721_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;

HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_241}});
  }
  case TAG_Just: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_p_241, 1)))) {
      V v_t_243 = heff_intSub(heff_take_field(v_p_241, 1), MK_INT(1LL));
      V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_p_241, 1021ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048563u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_242, v_t_244));
      {
        V v_field_246 = v_t_245.f[0];
        V v_field_247 = v_t_245.f[1];
        V v_x_248 = v_field_246;
        V v_s_249 = v_field_247;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249}});
      }
    } else {
      heff_drop(v_b_242);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_241}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallsW_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecallsW(V v_x_240, V v_p_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EApp: {
      V v_f_246 = heff_field(v_x41_244, 0);
      V v_argv_247 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24EApp = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      V v_t_2448;
      switch (heff_tag_of(v_f_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_dup(heff_field(v_f_246, 0));
        if (heff_strEq_c_lent(v_x_240, v_y_248, 2)) {
          V v_t_249 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_argv_247)}));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2448 = heff_intAdd(v_n_242, MK_INT(1LL));
          } else {
            heff_drop(v_t_249);
            v_t_2448 = v_n_242;
          }
        } else {
          v_t_2448 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2448 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2448 = v_n_242;
        break;
      }
      default: heff_nomatch(v_f_246);
      }
      V v_t_2449 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x41_244_24EApp, v_argv_247, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_t_2448;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_246, v_t_2449});
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2450 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_p_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2450;
      v_x_240 = t_0;
      v_p_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecallsW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2epastLastUse_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epastLastUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epastLastUse_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epastLastUse(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_t_244 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_243));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_t_246 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_245));
  V v_t_247 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_244, v_t_246}), 1, 2);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_a_241)) {
    case TAG_EVar: {
      V v_y_248 = heff_field(v_a_241, 0);
      heff_take_n(v_a_241, 1ULL, 1);
      v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_248, NTAG(TAG_Nil)});
      break;
    }
    default: {
      V v_t_249 = (g_heff_2ecompile_2eir_2epartsOnto(v_a_241, NTAG(TAG_Nil)));
      v_t_2410 = (g_heff_2ecompile_2esimplify_2evarsW(NTAG(TAG_Nil), v_t_249));
      break;
    }
    }
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2epastLastUse_lam0, 1, 1, (V[]){v_b_242}); V a_1 = v_t_2410; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2410); r_; });
  } else {
    heff_drop(v_t_247);
    V v_t_2416;
    switch (heff_tag_of(v_a_241)) {
    case TAG_EVar: {
      V v_y_2414 = heff_field(v_a_241, 0);
      heff_take_n(v_a_241, 1ULL, 1);
      v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2414, NTAG(TAG_Nil)});
      break;
    }
    default: {
      V v_t_2415 = (g_heff_2ecompile_2eir_2epartsOnto(v_a_241, NTAG(TAG_Nil)));
      v_t_2416 = (g_heff_2ecompile_2esimplify_2evarsW(NTAG(TAG_Nil), v_t_2415));
      break;
    }
    }
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_242, NTAG(TAG_Nil)});
    return ({ V a_0 = v_t_2416; V a_1 = v_x_240; V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2elastUseW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
  }
}
V g_heff_2ecompile_2esimplify_2epastLastUse_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2epastLastUse(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2epastLastUse_lam0(V self, V *args) {
  V v_y_2411 = args[0];
  V v_b_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_242, NTAG(TAG_Nil)});
  V v_x_2413 = ({ V a_0 = v_y_2411; V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2ecountW(a_0, a_1, a_2)); heff_drop(v_y_2411); r_; });
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2413, 1));
  heff_drop(v_x_2413);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esplitArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esplitArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esplitArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_rec_n(2, shape_binds__args, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), heff_dup(v_a_243)));
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam0, 1, 2, (V[]){v_x_245, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam1, 2, 1, (V[]){v_argv_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esplitArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_246});
  } else {
    heff_drop(v_x_245);
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_str0), v_p_246));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2411), v_a_243})});
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2412});
    }
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args) {
  V v_one_2415 = args[0];
  V v_z_2416 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_clo), 1, (V[]){v_argv_244}));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_2416}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_x1_2423;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_dup(heff_field(v_one_2415, 0));
      v_x1_2423 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    V v_a_2426;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_y_2425 = heff_field(v_one_2415, 1);
      heff_take_n(v_one_2415, 2ULL, 2);
      v_a_2426 = v_y_2425;
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    V v_t_2431;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nothing: {
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2426, heff_take_field(v_x_2419, 1)});
      v_t_2431 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_x_2419, 1ULL, 2, shape_binds__args, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      break;
    }
    case TAG_Just: {
      V v_bd_2428 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2428, heff_take_field(v_x_2419, 0)});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2426, heff_get_n(v_x_2419, 1, 2)});
      v_t_2431 = heff_rec_n(2, shape_binds__args, (V[]){v_t_2429, v_t_2430});
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
Clo g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(V v_lit_240, V v_lit_241, V v_b_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_x1_244 = (g_list_2efoldl_24s1544308498x936697067(v_t_243, heff_dup(v_lit_241)));
  V v_x_248;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_ts_245 = heff_field(v_x1_244, 0);
    V v_n_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 3ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_245); r_; });
    v_x_248 = heff_intAdd(v_t_247, v_n_246);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  if (heff_intLt_c(MK_INT(1LL), v_x_248)) {
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_x1_2410 = (g_list_2efoldl_24s1544308498x936697067(v_t_249, v_lit_241));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_MkPair: {
      V v_ts_2411 = heff_field(v_x1_2410, 0);
      V v_n_2412 = heff_field(v_x1_2410, 1);
      heff_take_n(v_x1_2410, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2411); r_; });
      v_t_2414 = heff_intAdd(v_t_2413, v_n_2412);
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    V v_lim_2415 = heff_intDiv(MK_INT(100LL), heff_intSub(v_t_2414, MK_INT(1LL)));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_242, NTAG(TAG_Nil)});
    V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2415), MK_INT(0LL), v_t_2416));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_lim_2415, v_x_2417, 0));
    heff_drop(v_lim_2415);
    heff_drop(v_x_2417);
    return v_ret_24bool;
  } else {
    heff_drop(v_lit_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprojW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprojW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EProj: {
      V v_e_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V v_t_2448;
      switch (heff_tag_of(v_e_245)) {
      case TAG_EVar: {
        V v_y_249 = heff_dup(heff_field(v_e_245, 0));
        v_t_2448 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_249, 0));
        heff_drop(v_y_249);
        break;
      }
      case TAG_EGlobal: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_245);
      }
      if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_e_245);
        heff_drop(v_t_2448);
        V t_0 = v_x_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2448);
        V t_0 = v_x_240;
        V t_1 = v_n_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_245, v_rest_244});
        v_x_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2449 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2449;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eprojW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedCopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eprunedCopy(V v_x1_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return v_x1_240;
  }
  case TAG_EGlobal: {
    return v_x1_240;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = (g_list_2eany_24s415398368x1824706470(v_argv_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_known_247 = (g_heff_2ecompile_2esimplify_2etagsGiven(v_xs_244, v_argv_241, heff_dup(g_std_2eordmap_2eempty_get())));
      V v_t_248 = (g_heff_2ecompile_2esimplify_2eprunedFor(v_known_247, v_b_245));
      return heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){v_xs_244, v_t_248});
    } else {
      heff_drop(v_t_246);
      return heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){v_xs_244, v_b_245});
    }
  }
  case TAG_EApp: {
    return v_x1_240;
  }
  case TAG_ELet: {
    return v_x1_240;
  }
  case TAG_ERecord: {
    return v_x1_240;
  }
  case TAG_EProj: {
    return v_x1_240;
  }
  case TAG_ETag: {
    return v_x1_240;
  }
  case TAG_EMatch: {
    return v_x1_240;
  }
  case TAG_EPrim: {
    return v_x1_240;
  }
  case TAG_EPrimCall: {
    return v_x1_240;
  }
  case TAG_ECall: {
    return v_x1_240;
  }
  case TAG_EInt: {
    return v_x1_240;
  }
  case TAG_EFloat: {
    return v_x1_240;
  }
  case TAG_EStr: {
    return v_x1_240;
  }
  case TAG_EBytes: {
    return v_x1_240;
  }
  case TAG_EFixed: {
    return v_x1_240;
  }
  case TAG_EFloat32: {
    return v_x1_240;
  }
  case TAG_EAbandon: {
    return v_x1_240;
  }
  case TAG_EBool: {
    return v_x1_240;
  }
  case TAG_ESet: {
    return v_x1_240;
  }
  case TAG_EValues: {
    return v_x1_240;
  }
  case TAG_EFix: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eprunedCopy(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartW_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapartW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EApp: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_argv_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2445;
      switch (heff_tag_of(v_f_244)) {
      case TAG_EVar: {
        V v_y_246 = heff_dup(heff_field(v_f_244, 0));
        v_t_2445 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_246, 0));
        heff_drop(v_y_246);
        break;
      }
      case TAG_EGlobal: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_f_244);
      }
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_f_244);
        heff_drop(v_argv_245);
        heff_drop_cell(v_ru_24x21_242_24EApp, 2);
        heff_drop(v_t_2445);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2445);
        V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_245, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_244, v_t_2446});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EProj: {
      V v_e_2447 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V v_t_2490;
      switch (heff_tag_of(v_e_2447)) {
      case TAG_EVar: {
        V v_y_2451 = heff_dup(heff_field(v_e_2447, 0));
        v_t_2490 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2451, 0));
        heff_drop(v_y_2451);
        break;
      }
      case TAG_EGlobal: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2447);
      }
      if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2447);
        heff_drop(v_t_2490);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2490);
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2447, v_rest_243});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EMatch: {
      V v_sc_2491 = heff_field(v_x21_242, 0);
      V v_arms_2492 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24132;
      switch (heff_tag_of(v_sc_2491)) {
      case TAG_EVar: {
        V v_y_2493 = heff_dup(heff_field(v_sc_2491, 0));
        v_t_24132 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2493, 0));
        heff_drop(v_y_2493);
        break;
      }
      case TAG_EGlobal: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_2491);
      }
      if ((heff_dup(v_t_24132) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_sc_2491);
        heff_drop(v_arms_2492);
        heff_drop(v_t_24132);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_24132);
        V v_t_24133 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2492, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_sc_2491, v_t_24133});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EBool: {
      V v_c_24134 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_x_24135 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_c_24134));
      if (heff_intLt_c(MK_INT(0LL), v_x_24135)) {
        heff_drop(v_rest_243);
        heff_drop(v_c_24134);
        return NTAG(TAG_True);
      } else {
        V v_t_24136 = ({ V a_0 = v_c_24134; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_24134); r_; });
        V t_0 = v_x_240;
        V t_1 = v_t_24136;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_24137 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24137;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eapartW(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2etagMatched_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagMatched_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etagMatched(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x3_242, 0);
      V v_argv_246 = heff_field(v_x3_242, 1);
      V v_t_2446;
      switch (heff_tag_of(v_a_245)) {
      case TAG_EVar: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2446 = (g_heff_2ecompile_2esimplify_2ematchesFirst(v_x_243, v_b_240));
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2446);
        V t_0 = v_b_240;
        V t_1 = v_xs_244;
        V t_2 = v_argv_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etagMatched_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2etagMatched(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_argv_2412 = heff_field(v_x3_242, 1);
        if ((heff_dup(v_m_245) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          V v_m_2413 = ({ V a_0 = v_x_248; V a_1 = heff_dup(v_a_2411); V a_2 = v_e_243; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_argv_2412)});
        } else {
          heff_drop(v_m_245);
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_argv_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esubstMarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_argv_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_argv_2412; V a_3 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_argv_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_argv_246 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_ys_244), v_argv_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2413;
    if (heff_intLt_c(v_y_2410, v_x_249)) {
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_ys_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ys_244); r_; });
      v_e_2413 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2412, v_b_245});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2413 = v_b_245;
    }
    V v_t_2414 = (g_std_2eordmap_2esize(v_m_248));
    if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
      heff_drop(v_m_248);
      return v_e_2413;
    } else {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2413; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
  }
  case TAG_EApp: {
    V v_e1_2415 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_2415)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EGlobal: {
      V v_g_2418 = heff_field(v_e1_2415, 0);
      V v_ru_24e1_2415_24EGlobal = heff_take_reuse_n(v_e1_2415, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EApp: {
        V v_argv_2420 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_2421 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
        V v_t_2422 = (g_prelude_2e_2b_2b(v_argv_2420, v_t_2421));
        return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2415_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2418}), v_t_2422});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2415, 0ULL, 3);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2415, 0ULL, 4);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2415, 0ULL, 3);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2415, 0ULL, 3);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2415, 0ULL, 1);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2415, 0ULL, 2);
      heff_drop(v_zs_240);
      return v_e_241;
    }
    default: return heff_nomatch(v_e1_2415);
    }
  }
  case TAG_ELet: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBool: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ESet: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EValues: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2evalueTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evalueTag_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2evalueTag(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_x1_240, 0);
    V v_argv_2417 = heff_field(v_x1_240, 1);
    V v_ts_2418 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_argv_2417)) {
    case TAG_Nil: {
      heff_drop(v_t_2416);
      heff_drop(v_ts_2418);
      heff_drop_cell(v_ru_24x1_240_24ETag, 3);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_t_2421 = (g_list_2eall_24s1447613073x1712348205(v_argv_2417));
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ETag, TAG_ETag, 3, (V[]){v_t_2416, v_argv_2417, v_ts_2418}), NTAG(TAG_Nil)});
        V v_x_2423 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2422));
        V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(60LL), v_x_2423, 1));
        heff_drop(v_x_2423);
        return v_ret_24bool;
      } else {
        heff_drop(v_t_2416);
        heff_drop_tag(v_argv_2417, 2);
        heff_drop(v_ts_2418);
        heff_drop_cell(v_ru_24x1_240_24ETag, 3);
        heff_drop(v_t_2421);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_argv_2417);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evalueTag_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2evalueTag(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etagGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagGo_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2etagGo(V v_s_240, V v_g_241, V v_env_242, V v_b_243, V v_x5_244, V v_x6_245, V v_x7_246, V v_i_247) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    heff_drop(v_g_241);
    heff_drop(v_env_242);
    heff_drop(v_b_243);
    heff_drop(v_x6_245);
    heff_drop(v_x7_246);
    heff_drop(v_i_247);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_248 = heff_field(v_x5_244, 0);
    V v_sts_249 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x6_245)) {
    case TAG_Nil: {
      heff_drop(v_s_240);
      heff_drop(v_g_241);
      heff_drop(v_env_242);
      heff_drop(v_b_243);
      heff_drop(v_x7_246);
      heff_drop(v_i_247);
      heff_drop(v_st_248);
      heff_drop(v_sts_249);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x6_245, 0);
      V v_xs_2411 = heff_field(v_x6_245, 1);
      V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
      switch (heff_tag_of(v_x7_246)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_g_241);
        heff_drop(v_env_242);
        heff_drop(v_b_243);
        heff_drop(v_i_247);
        heff_drop(v_st_248);
        heff_drop(v_sts_249);
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_x_2410);
        heff_drop(v_xs_2411);
        heff_drop_cell(v_ru_24x6_245_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        V v_a_2412 = heff_field(v_x7_246, 0);
        V v_argv_2413 = heff_field(v_x7_246, 1);
        heff_take_n(v_x7_246, 3ULL, 2);
        V v_t_2417;
        if ((heff_dup(v_st_248) == NTAG(TAG_True))) {
          heff_drop(v_st_248);
          V v_t_2414 = (g_heff_2ecompile_2esimplify_2evalueTag(v_a_2412));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            V v_t_2415 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
            V v_x_2416 = ({ V a_0 = heff_dup(v_s_240); V a_1 = heff_rec_n(4, shape_deeper__env__self__at, (V[]){MK_INT(3LL), heff_dup(v_env_242), heff_dup(v_g_241), heff_dup(v_i_247)}); V a_2 = v_x_2410; V a_3 = MK_INT(0LL); V a_4 = v_t_2415; V r_ = (g_heff_2ecompile_2esimplify_2etakenW(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2410); r_; });
            v_t_2417 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2416, 1));
            heff_drop(v_x_2416);
          } else {
            heff_drop_cell(v_ru_24x5_244_24Cons, 2);
            heff_drop(v_x_2410);
            heff_drop(v_t_2414);
            v_t_2417 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_st_248);
          heff_drop_cell(v_ru_24x5_244_24Cons, 2);
          heff_drop(v_x_2410);
          heff_drop(v_a_2412);
          v_t_2417 = NTAG(TAG_False);
        }
        V v_cell_2418 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
        V v_u_2419 = (g_heff_2ecompile_2esimplify_2etagGo_24dps(v_s_240, v_g_241, v_env_242, v_b_243, v_sts_249, v_xs_2411, v_argv_2413, heff_box_word((heff_unbox_word(v_i_247) + ((int64_t)1ULL))), heff_dup(v_cell_2418)));
        heff_drop(v_u_2419);
        return v_cell_2418;
      }
      default: return heff_nomatch(v_x7_246);
      }
    }
    default: return heff_nomatch(v_x6_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2etagGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etagGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V v_s_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_argv_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emovesFirst_clo), 1, (V[]){heff_dup(v_s_240)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_argv_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_s_240;
      V t_1 = v_argv_244;
      V t_2 = v_cell_247;
      v_s_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_243);
      heff_drop(v_argv_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_246);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_244, v_l_240, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2epushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2epushable(V v_a_240) {
top: ;
  V v_t_2440;
  switch (heff_tag_of(v_a_240)) {
  case TAG_EVar: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_a_240);
    heff_drop(v_t_2440);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2440);
    V v_t_2441 = (g_heff_2ecompile_2eir_2eisValue(v_a_240));
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      V v_t_2442 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_240)));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_a_240);
        heff_drop(v_t_2442);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2442);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2ehandlerLike(v_a_240);
      }
    } else {
      heff_drop(v_a_240);
      heff_drop(v_t_2441);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushable(a[0]);
}

HeffT2 g_heff_2ecompile_2esimplify_2efindField_24cpr(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_244, v_l_240, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2egivesItBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egivesItBack_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2egivesItBack(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_MkArm: {
    V v_t_242 = heff_field(v_a_241, 0);
    V v_vs_243 = heff_field(v_a_241, 1);
    V v_a3_244 = heff_field(v_a_241, 2);
    switch (heff_tag_of(v_a3_244)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_a3_244, 0);
      switch (heff_tag_of(v_s_240)) {
      case TAG_EVar: {
        V v_x_246 = heff_field(v_s_240, 0);
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_246, v_y_245, 0));
        return v_ret_24bool;
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_240);
      }
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_t2_2459 = heff_field(v_a3_244, 0);
      V v_argv_2460 = heff_field(v_a3_244, 1);
      if (heff_strEq_c_lent(v_t_242, v_t2_2459, 0)) {
        V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
        V v_t_2463 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2460));
        if (heff_intEq_c(v_t_2462, v_t_2463)) {
          V v_t_2464 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_243), heff_dup(v_argv_2460)));
          return ({ V a_0 = v_t_2464; V r_ = (g_list_2eall_24s1934518973x1420187537(a_0)); heff_drop(v_t_2464); r_; });
        } else {
          return NTAG(TAG_False);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_a3_244);
    }
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2egivesItBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2egivesItBack(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam0, 1, 1, (V[]){v_x3_241});
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x2_240, 0);
    V v_sts_245 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_st_244);
      heff_drop(v_sts_245);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam1, 1, 1, (V[]){v_x3_241});
    }
    case TAG_Cons: {
      V v_a_248 = heff_field(v_x3_241, 0);
      V v_argv_249 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_m_2410 = (g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967(v_sts_245, v_argv_249));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam2, 1, 3, (V[]){v_m_2410, v_a_248, v_st_244});
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_x3_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x3_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_s_242});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_x3_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x3_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_s_246});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_24s1650044856x263154967_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_st_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2eletsOut(v_a_248));
    return ({ V a_0 = v_st_244; V a_1 = v_t_2415; V a_2 = v_x_2413; V a_3 = v_s_2414; V r_ = (g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865(a_0, a_1, a_2, a_3)); heff_drop(v_st_244); r_; });
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
Clo g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507(V v_lit_240, V v_lit_241, V v_f_242, V v_l_243, V v_argv_244, V v_s_245) {
top: ;
  V v_lit_246 = v_lit_240;
  V v_lit_247 = v_lit_241;
  V v_l_248 = v_l_243;
  V v_p_249 = v_s_245;
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_p_249, 7)), 0, 7);
  V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_lit_246; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_t_2410); heff_drop(v_lit_246); r_; });
  HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2411, v_p_249));
  V v_x2_2418;
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x_2415 = v_field_2413;
    V v_s_2416 = v_field_2414;
    V v_x_2417 = ({ V a_0 = v_l_248; V a_1 = v_lit_247; V a_2 = v_x_2415; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltFieldOf(a_0, a_1, a_2)); heff_drop(v_l_248); r_; });
    v_x2_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_2416});
  }
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      V v_x_2421 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_242, v_argv_244));
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2420});
    }
    case TAG_Just: {
      V v_v_2422 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      heff_drop(v_f_242);
      heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
      V v_m_2423 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_v_2422));
      V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2420}));
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_MkPair: {
        V v_x_2425 = heff_field(v_x2_2424, 0);
        V v_s_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        V v_f_2427 = (g_heff_2ecompile_2esimplify_2eprunedCopy(v_x_2425, v_argv_244));
        V v_t_2428 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_f_2427, v_argv_244));
        return heff_tail(v_t_2428, 1, (V[]){v_s_2426});
      }
      default: return heff_nomatch(v_x2_2424);
      }
    }
    default: return heff_nomatch(v_x_2419);
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebuiltApplied_24s1939890658x607696507(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam10(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(V v_b_240, V v_argv_241) {
top: ;
  V v_m_2451 = (g_prelude_2etraverse_24s2064368144x1684679122(((V)&g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam0_clo), v_argv_241));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam10, 1, 2, (V[]){v_m_2451, v_b_240});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam1(V self, V *args) {
  V v_s_244 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_244});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam2(V self, V *args) {
  V v_s_246 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_246});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2426});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam4(V self, V *args) {
  V v_s_2432 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2432});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2434});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2436});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam7(V self, V *args) {
  V v_s_2438 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2438});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam8(V self, V *args) {
  V v_s_2441 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2441});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam9(V self, V *args) {
  V v_s_2443 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_242, v_s_2443});
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam0(V self, V *args) {
  V v_a_242 = args[0];
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam1, 1, 1, (V[]){v_a_242});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam2, 1, 1, (V[]){v_a_242});
  }
  case TAG_ELam: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EApp: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ELet: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ERecord: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EProj: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ETag: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EMatch: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam3, 1, 1, (V[]){v_a_242});
  }
  case TAG_EPrimCall: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ECall: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam4, 1, 1, (V[]){v_a_242});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam5, 1, 1, (V[]){v_a_242});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam6, 1, 1, (V[]){v_a_242});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam7, 1, 1, (V[]){v_a_242});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam8, 1, 1, (V[]){v_a_242});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam9, 1, 1, (V[]){v_a_242});
  }
  case TAG_EAbandon: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EBool: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_ESet: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EValues: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_EFix: {
    V f_ = ((V)&g_heff_2ecompile_2esimplify_2ecopy_clo);
    args[0] = v_a_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_lam10(V self, V *args) {
  V v_s_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_b_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_s_2452}));
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_MkPair: {
    V v_x_2454 = heff_field(v_x2_2453, 0);
    V v_s_2455 = heff_field(v_x2_2453, 1);
    heff_take_n(v_x2_2453, 3ULL, 2);
    V v_t_2456 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_240, v_x_2454));
    V f_ = v_t_2456;
    args[0] = v_s_2455;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024(V v_f_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_ELam: {
    V v_xs_242 = heff_field(v_f_240, 0);
    V v_b_243 = heff_field(v_f_240, 1);
    V v_ru_24f_240_24ELam = heff_take_reuse_n(v_f_240, 3ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
    V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_241));
    if (heff_intEq_c(v_t_244, v_t_245)) {
      V v_x1_246 = (g_heff_2ecompile_2esimplify_2egivenTelling(heff_dup(v_b_243), heff_dup(v_xs_242), heff_dup(v_vs_241)));
      if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24f_240_24ELam, 2);
        heff_drop(v_x1_246);
        V v_t_247 = (g_heff_2ecompile_2esimplify_2evaluesGiven(heff_dup(v_b_243), heff_dup(v_xs_242), heff_dup(v_vs_241)));
        V v_m_248 = ({ V a_0 = v_xs_242; V a_1 = v_vs_241; V r_ = (g_heff_2ecompile_2esimplify_2eatomsGiven(a_0, a_1)); heff_drop(v_xs_242); heff_drop(v_vs_241); r_; });
        V v_t_249 = (g_std_2eordmap_2esize(v_m_248));
        V v_t_2410;
        if (heff_intEq_c(v_t_249, MK_INT(0LL))) {
          heff_drop(v_m_248);
          v_t_2410 = v_b_243;
        } else {
          v_t_2410 = ({ V a_0 = v_m_248; V a_1 = v_b_243; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
        }
        V v_x_2411 = ({ V a_0 = v_t_247; V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_247); r_; });
        return heff_clo_n(g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_lam0, 1, 1, (V[]){v_x_2411});
      } else {
        heff_drop(v_x1_246);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(heff_tag_at_n(v_ru_24f_240_24ELam, TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_vs_241);
      }
    } else {
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(heff_tag_at_n(v_ru_24f_240_24ELam, TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_vs_241);
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_f_240, v_vs_241);
  }
  }
}
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_2412});
}
Clo g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581(V v_saved_240, V v_orig_241, V v_k_242, V v_f_243, V v_m_244, V v_z_245) {
top: ;
  V v_m_246 = heff_tr(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(v_k_242, v_f_243, v_m_244));
  V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_orig_241), NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2410));
    V v_lim_2412 = heff_intAdd(v_t_2411, MK_INT(160LL));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_248), NTAG(TAG_Nil)});
    V v_x_2414 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2412), MK_INT(0LL), v_t_2413));
    if (!heff_intLt_c_lent(v_lim_2412, v_x_2414, 0)) {
      heff_drop_rec(v_saved_240, 10);
      heff_drop(v_orig_241);
      heff_drop(v_lim_2412);
      heff_drop(v_x_2414);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_s_249});
    } else {
      heff_drop(v_x_248);
      heff_drop(v_lim_2412);
      heff_drop(v_x_2414);
      V v_t_2415 = ({ V rv_2 = heff_take_field(v_saved_240, 2); V rv_5 = heff_get_n(v_saved_240, 5, 10); V rr_ = heff_rec_reuse_nf(v_s_249, 987ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1045455u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_orig_241, v_t_2415});
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_str0, 1, "v");
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056(V v_orig_240, V v_k_241, V v_f_242, V v_s_243, V v_arms_244, V v_argv_245, V v_s_246) {
top: ;
  V v_m_2416 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam0, 1, 1, (V[]){v_argv_245}), v_arms_244));
  V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){heff_dup(v_s_246)}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_n_2426;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Nil: {
      v_n_2426 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_a_2420 = heff_dup(heff_field(v_x_2418, 0));
      V v_t_2425;
      switch (heff_tag_of(v_a_2420)) {
      case TAG_MkArm: {
        V v_b_2424 = heff_field(v_a_2420, 2);
        heff_take_n(v_a_2420, 4ULL, 3);
        v_t_2425 = v_b_2424;
        break;
      }
      default: heff_nomatch(v_a_2420);
      }
      v_n_2426 = (g_heff_2ecompile_2esimplify_2efirstCalled(v_k_241, v_t_2425));
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    HeffT2 v_t_2435 = (g_prelude_2etraverse_24s1760019503x148599044_24cpr(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam2, 1, 2, (V[]){heff_dup(v_k_241), heff_dup(v_n_2426)}), heff_dup(v_x_2418)));
    {
      V v_field_2437 = v_t_2435.f[1];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        V v_x_2438 = v_field_2437;
        if ((heff_intLt_c_lent(MK_INT(0LL), v_n_2426, 1) && ({ V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_243), heff_dup(v_x_2438)}), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2440 = (g_heff_2ecompile_2eir_2ecountW(v_k_241, MK_INT(0LL), heff_dup(v_t_2439))); int c_ = ({ V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_243), heff_dup(v_x_2438)}), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2442 = (g_heff_2ecompile_2eir_2elamW(v_k_241, heff_dup(v_t_2441))); int c_ = ({ V v_t_2454 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2440), heff_dup(v_t_2442)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2454, MK_INT(0LL), 2); heff_drop(v_t_2454); c_; }); heff_drop(v_t_2442); c_; }); heff_drop(v_t_2441); c_; }); heff_drop(v_t_2440); c_; }); heff_drop(v_t_2439); c_; }))) {
          heff_drop(v_orig_240);
          heff_drop(v_s_246);
          heff_drop(v_x_2418);
          HeffT2 v_t_2443 = (g_heff_2ecompile_2esimplify_2efreshNames_24cpr(((V)&g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_str0), v_n_2426, v_s_2419));
          {
            V v_field_2444 = v_t_2443.f[0];
            V v_field_2445 = v_t_2443.f[1];
            V v_x_2446 = v_field_2444;
            V v_s_2447 = v_field_2445;
            V v_t_2448 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2446)));
            V v_m_2449 = (g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024(v_f_242, v_t_2448));
            V v_x2_2450 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_s_2447}));
            switch (heff_tag_of(v_x2_2450)) {
            case TAG_MkPair: {
              V v_x_2451 = heff_field(v_x2_2450, 0);
              V v_s_2452 = heff_field(v_x2_2450, 1);
              V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
              V v_t_2453 = heff_tag_n(TAG_ESet, 3, (V[]){v_x_2446, heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_EMatch, 2, (V[]){v_s_243, v_x_2438}), v_x_2451});
              return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2453, v_s_2452});
            }
            default: return heff_nomatch(v_x2_2450);
            }
          }
        } else {
          heff_drop_cell(v_ru_24x2_2417_24MkPair, 2);
          heff_drop(v_n_2426);
          heff_drop(v_x_2438);
          return (g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581(v_s_246, v_orig_240, v_k_241, v_f_242, heff_tag_n(TAG_EMatch, 2, (V[]){v_s_243, v_x_2418}), v_s_2419));
        }
      } else {
        heff_drop_cell(v_ru_24x2_2417_24MkPair, 2);
        heff_drop(v_n_2426);
        heff_drop(v_field_2437);
        return (g_heff_2ecompile_2esimplify_2efollowerCopied_24s988592528x1521345581(v_s_246, v_orig_240, v_k_241, v_f_242, heff_tag_n(TAG_EMatch, 2, (V[]){v_s_243, v_x_2418}), v_s_2419));
      }
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  V v_vs_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_248, v_vs_249, v_x_2414}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam0(V self, V *args) {
  V v_a_247 = args[0];
  V v_argv_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_247)) {
  case TAG_MkArm: {
    V v_t_248 = heff_field(v_a_247, 0);
    V v_vs_249 = heff_field(v_a_247, 1);
    V v_b_2410 = heff_field(v_a_247, 2);
    heff_take_n(v_a_247, 7ULL, 3);
    V v_m_2411 = (g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(v_b_2410, v_argv_245));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam1, 1, 3, (V[]){v_m_2411, v_t_248, v_vs_249});
  }
  default: return heff_nomatch(v_a_247);
  }
}
V g_heff_2ecompile_2esimplify_2efollowerSet_24s162474189x1020585056_lam2(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_n_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_x2_2427, 0);
    V v_vs_2429 = heff_field(v_x2_2427, 1);
    V v_b_2430 = heff_field(v_x2_2427, 2);
    V v_ru_24x2_2427_24MkArm = heff_take_reuse_n(v_x2_2427, 7ULL, 3);
    HeffT2 v_t_2431 = ({ V a_0 = v_k_241; V a_1 = v_n_2426; V a_2 = v_b_2430; HeffT2 r_ = (g_heff_2ecompile_2eir_2ewaysM_24s597877582x1381741995_24cpr(a_0, a_1, a_2)); heff_drop(v_k_241); r_; });
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2433;
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_2427_24MkArm, TAG_MkArm, 3, (V[]){v_t_2428, v_vs_2429, v_x_2434})});
      } else {
        heff_drop(v_t_2428);
        heff_drop(v_vs_2429);
        heff_drop_cell(v_ru_24x2_2427_24MkArm, 3);
        heff_drop(v_field_2433);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
Clo g_heff_2ecompile_2esimplify_2egrewIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egrewIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2egrewIn(V v_s0_240, V v_s1_241, V v_b_242) {
top: ;
  V v_supply_243 = heff_take_field(v_s1_241, 0);
  V v_sp_244 = heff_get_n(v_s1_241, 7, 10);
  V v_supply_245 = heff_take_field(v_s0_240, 0);
  V v_sp_246 = heff_get_n(v_s0_240, 7, 10);
  if (!heff_intEq_c_lent(v_supply_243, v_supply_245, 0)) {
    heff_drop(v_supply_243);
    heff_drop(v_supply_245);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
    V v_hs_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    V v_t_249 = ({ V b_0 = heff_get_n(v_sp_246, 0, 7); V a_1 = v_hs_248; V r_ = (g_list_2emap_24s1492759219x1917596721(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2410 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
    V v_hs_2411 = (g_heff_2ecompile_2eir_2enubI(v_t_2410));
    V v_t_2412 = ({ V b_0 = heff_get_n(v_sp_244, 0, 7); V a_1 = v_hs_2411; V r_ = (g_list_2emap_24s1492759219x1917596721(b_0, a_1)); heff_drop(b_0); r_; });
    return ({ V a_0 = v_t_249; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2egrew(a_0, a_1)); heff_drop(v_t_249); heff_drop(v_t_2412); r_; });
  } else {
    heff_drop(v_b_242);
    heff_drop(v_supply_243);
    heff_drop_rec(v_sp_244, 7);
    heff_drop(v_supply_245);
    heff_drop_rec(v_sp_246, 7);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2egrewIn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eoneDef_24cpr_str0, 0, "");
V g_heff_2ecompile_2esimplify_2eoneDef_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eoneDef_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V v_d_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_x_245 = v_field_243;
    heff_drop(v_x_245);
    V v_s_246 = v_field_244;
    V v_k_247 = heff_take_field(v_s_246, 8);
    V v_m_248 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(heff_dup(heff_rfield(v_d_240, 2))));
    V v_t_249 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_k_247, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2410 = ({ V rv_8 = v_t_249; V rr_ = heff_rec_reuse_nf(v_s_246, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_x2_2411 = heff_tr(heff_call(v_m_248, 1, (V[]){v_t_2410}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      V v_m_2414 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_2412));
      V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2413}));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_s_2417 = heff_field(v_x2_2415, 1);
        V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
        HeffT2 v_t_2418 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2416, v_s_2417));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_x_2421 = v_field_2419;
          V v_s_2422 = v_field_2420;
          HeffT2 v_t_2423 = (g_heff_2ecompile_2esimplify_2esettleDef_24cpr(MK_INT(5LL), heff_dup(heff_rfield(v_d_240, 0)), v_x_2421, v_s_2422));
          {
            V v_field_2424 = v_t_2423.f[0];
            V v_field_2425 = v_t_2423.f[1];
            V v_x_2426 = v_field_2424;
            V v_s_2427 = v_field_2425;
            V v_b_2430;
            switch (heff_tag_of(v_x_2426)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_dup(heff_field(v_x_2426, 0));
              v_b_2430 = v_x_2428;
              break;
            }
            default: heff_nomatch(v_x_2426);
            }
            V v_s_2431 = v_s_2427;
            V v_t_2432 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2430));
            V v_hs_2433 = (g_heff_2ecompile_2eir_2enubI(v_t_2432));
            V v_t_2434 = heff_get_n(heff_dup(heff_rfield(v_s_2431, 8)), 2, 5);
            V v_t_2442 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2eoneDef_24cpr_lam0, 2, 1, (V[]){heff_dup(v_s_2431)}); V a_1 = v_t_2434; V a_2 = v_hs_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_2433); r_; });
            V v_k_2443 = heff_take_field(v_s_2431, 8);
            V v_t_2444 = ({ V rv_2 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_k_2443, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_t_2445 = ({ V rv_8 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_s_2431, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
            V v_x2_2446 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2445});
            switch (heff_tag_of(v_x2_2446)) {
            case TAG_MkPair: {
              V v_s_2448 = heff_field(v_x2_2446, 1);
              V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 2ULL, 2);
              V v_t_2451;
              switch (heff_tag_of(v_x_2426)) {
              case TAG_MkPair: {
                V v_x_2449 = heff_dup(heff_field(v_x_2426, 0));
                v_t_2451 = v_x_2449;
                break;
              }
              default: heff_nomatch(v_x_2426);
              }
              V v_t_2454;
              switch (heff_tag_of(v_x_2426)) {
              case TAG_MkPair: {
                V v_y_2453 = heff_dup(heff_field(v_x_2426, 1));
                v_t_2454 = v_y_2453;
                break;
              }
              default: heff_nomatch(v_x_2426);
              }
              V v_m_2455 = (g_heff_2ecompile_2esimplify_2einOrder(v_t_2451, v_t_2454));
              V v_x2_2456 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2448}));
              switch (heff_tag_of(v_x2_2456)) {
              case TAG_MkPair: {
                V v_x_2457 = heff_field(v_x2_2456, 0);
                V v_s_2458 = heff_field(v_x2_2456, 1);
                V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
                V v_t_2461;
                switch (heff_tag_of(v_x_2426)) {
                case TAG_MkPair: {
                  V v_x_2459 = heff_dup(heff_field(v_x_2426, 0));
                  v_t_2461 = v_x_2459;
                  break;
                }
                default: heff_nomatch(v_x_2426);
                }
                V v_t_2462 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), v_t_2461});
                V v_t_2463 = heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
                V v_t_2464 = (g_prelude_2e_2b_2b(v_x_2457, v_t_2463));
                V v_s_2465 = heff_dup(v_s_2458);
                V v_safe_2466 = heff_take_field(v_s_2465, 3);
                V v_kp_2467 = heff_get_n(v_s_2465, 8, 10);
                V v_d_2468 = v_d_240;
                V v_b_2471;
                switch (heff_tag_of(v_x_2426)) {
                case TAG_MkPair: {
                  V v_x_2469 = heff_field(v_x_2426, 0);
                  heff_take_n(v_x_2426, 1ULL, 2);
                  v_b_2471 = v_x_2469;
                  break;
                }
                default: heff_nomatch(v_x_2426);
                }
                V v_t_2472 = heff_get_n(heff_dup(heff_rfield(v_s_2458, 8)), 2, 5);
                HeffT2 v_t_2473 = ({ V a_0 = v_safe_2466; V a_1 = heff_rfield(v_d_2468, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_safe_2466); r_; });
                V v_t_2477;
                {
                  V v_field_2475 = v_t_2473.f[1];
                  int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                  v_t_2477 = heff_bool(((v_tag_2474 == ((int64_t)0ULL)) && ({ V v_x_2476 = heff_dup(v_field_2475); int c_ = 1; heff_drop(v_x_2476); c_; })));
                  heff_drop(v_field_2475);
                }
                V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2472));
                V v_t_2479 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2478));
                V v_t_2486 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2eoneDef_24cpr_lam1, 1, 1, (V[]){v_kp_2467}), v_t_2479));
                V v_t_2487 = heff_rec_n(4, shape_key__body__safe__touched, (V[]){heff_get_n(v_d_2468, 0, 3), v_b_2471, v_t_2477, v_t_2486});
                V v_t_2488 = heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_Cons, 2, (V[]){v_t_2487, NTAG(TAG_Nil)});
                V v_x_2489 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2464, v_t_2488});
                return ((HeffT2){{v_x_2489, v_s_2458}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_2456)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x2_2446)}});
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2415)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2411)}});
    }
  }
}
V g_heff_2ecompile_2esimplify_2eoneDef_24cpr_lam0(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_h_2436 = args[1];
  V v_s_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_get_n(heff_get_n(v_s_2431, 7, 10), 2, 7);
  HeffT2 v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = v_h_2436; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2437); r_; });
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_x_2441 = v_field_2440;
      heff_drop(v_x_2441);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2436, v_acc_2435});
    } else {
      heff_drop(v_h_2436);
      heff_drop(v_field_2440);
      return v_acc_2435;
    }
  }
}
V g_heff_2ecompile_2esimplify_2eoneDef_24cpr_lam1(V self, V *args) {
  V v_h_2480 = args[0];
  V v_kp_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2481 = ({ V b_0 = heff_get_n(v_kp_2467, 0, 5); V a_1 = v_h_2480; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2485;
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    if ((v_tag_2482 == ((int64_t)0ULL))) {
      V v_x_2484 = v_field_2483;
      v_t_2485 = v_x_2484;
    } else {
      heff_drop(v_field_2483);
      v_t_2485 = ((V)&g_heff_2ecompile_2esimplify_2eoneDef_24cpr_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2480, v_t_2485});
}
Clo g_heff_2ecompile_2esimplify_2eoneDef_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneDef_24tok2_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eoneDef_24tok2(V v_tok_240, V v_d_241, V v_s_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_d_241, v_s_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2esimplify_2eoneDef_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneDef_24tok2(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2(V v_tok_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_s_245) {
top: ;
  V v_g_246 = heff_dup(v_g_241);
  V v_xs_247 = heff_dup(v_xs_242);
  V v_b_248 = heff_dup(v_b_243);
  V v_argv_249 = heff_dup(v_argv_244);
  V v_s_2410 = v_s_245;
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_s_2410, 7)), 6, 7);
  V v_x2_2423;
  if (((heff_dup(v_t_2411) == NTAG(TAG_True)) || heff_intLe_c(MK_INT(50000LL), heff_get_n(heff_dup(heff_rfield(v_s_2410, 7)), 5, 7)))) {
    heff_drop(v_xs_247);
    heff_drop(v_b_248);
    heff_drop(v_t_2411);
    V v_x_2412 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_246}), v_argv_249));
    v_x2_2423 = heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_x_2412, v_s_2410});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_2411);
    V v_t_2413 = (g_list_2eany_24s392952474x1351014279(heff_dup(v_s_2410), v_argv_249));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2ebeforeMoved(heff_dup(v_s_2410), heff_dup(v_argv_249)));
      HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_s_2410; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eallPure_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
      {
        V v_field_2416 = v_t_2415.f[0];
        V v_field_2417 = v_t_2415.f[1];
        V v_x_2418 = v_field_2416;
        V v_s_2419 = v_field_2417;
        V v_x2_2420 = ({ V a_0 = heff_dup(v_g_246); V a_1 = heff_dup(v_xs_247); V a_2 = heff_dup(v_b_248); V a_3 = heff_dup(v_argv_249); V a_4 = v_x_2418; V a_5 = v_s_2419; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2418); r_; });
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_MkPair: {
          V v_x_2421 = heff_field(v_x2_2420, 0);
          V v_s_2422 = heff_field(v_x2_2420, 1);
          V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
          v_x2_2423 = (g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(v_ru_24x2_2420_24MkPair, v_g_246, v_xs_247, v_b_248, v_argv_249, v_x_2421, v_s_2422));
          break;
        }
        default: heff_nomatch(v_x2_2420);
        }
      }
    } else {
      heff_drop(v_t_2413);
      v_x2_2423 = (g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(heff_dup(v_argv_249), v_g_246, v_xs_247, v_b_248, v_argv_249, v_s_2410));
    }
  }
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2426 = (g_heff_2ecompile_2esimplify_2estillCall(v_g_241, v_x_2424));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_x_2428 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), v_t_2427));
      if (!heff_intLt_c_lent(MK_INT(160LL), v_x_2428, 1)) {
        heff_drop(v_x_2428);
        V v_x_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
        V v_y_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
        if (heff_intLt_c(v_y_2430, v_x_2429)) {
          V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_s_2425, 7)), 0, 7);
          V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ehandlerOf_clo), 1, (V[]){v_t_2431}));
          V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
          V v_t_2434 = (g_list_2edrop(v_t_2433, v_argv_244));
          V v_t_2435 = ({ V a_0 = v_t_2432; V a_1 = v_t_2434; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2434); r_; });
          if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
            heff_drop(v_x_2424);
            heff_drop_cell(v_ru_24x2_2423_24MkPair, 2);
            heff_drop(v_t_2435);
            return (g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(v_g_241, v_xs_242, v_b_243, v_argv_244, v_s_2425));
          } else {
            heff_drop(v_g_241);
            heff_drop(v_xs_242);
            heff_drop(v_b_243);
            heff_drop(v_argv_244);
            heff_drop(v_t_2435);
            return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2425});
          }
        } else {
          heff_drop(v_g_241);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_argv_244);
          return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2425});
        }
      } else {
        heff_drop(v_g_241);
        heff_drop(v_xs_242);
        heff_drop(v_b_243);
        heff_drop(v_argv_244);
        heff_drop(v_x_2428);
        return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2425});
      }
    } else {
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_argv_244);
      heff_drop(v_t_2426);
      return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_s_2425});
    }
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_24tok2(a[0], a[1], a[2], a[3], a[4], a[5]);
}