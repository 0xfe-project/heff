// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_caps 9541544
#define LBL_defs 9574869
#define LBL_e 319
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kp 10188
#define LBL_n 328
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_vars 10107635
static uint32_t shape_binds__args[] = {LBL_binds, LBL_args};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2esimplify_2eallPure(V, V);
V g_heff_2ecompile_2esimplify_2eallPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallPure_clo;
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eargPure(V, V);
V g_heff_2ecompile_2esimplify_2eargPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eargPure_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2eknownField(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownField_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2eshapeOne(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s688118489x1560799399(V, V, V);
V g_list_2efoldl_24s688118489x1560799399_entry(V self, V *a);
extern Clo g_list_2efoldl_24s688118489x1560799399_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakeL_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eisPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eisPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eisPure(V v_e_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_241, 3), heff_rfield(v_s_241, 5), v_e_240));
  V v_t_2437;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    v_t_2437 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_242);
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      V v_f_247 = heff_field(v_e_240, 0);
      V v_as_248 = heff_field(v_e_240, 1);
      v_t_2437 = (g_heff_2ecompile_2esimplify_2epartialHead(heff_dup(v_s_241), heff_dup(v_as_248), v_f_247));
      break;
    }
    case TAG_ELet: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_s_241});
}
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eisPure(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esplitArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esplitArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esplitArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_rec_n(2, shape_binds__args, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2eisPure(v_a_243, v_p_241));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam0, 1, 2, (V[]){v_x_246, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2esplitArgs_lam1, 2, 1, (V[]){v_as_244}), v_s_247));
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esplitArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
    heff_drop(v_x_246);
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_p_248});
  } else {
    heff_drop(v_x_246);
    V v_x2_2410 = (g_heff_2ecompile_2esimplify_2efreshName(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_str0), v_p_248));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_x_2411), v_a_243})});
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_lam1(V self, V *args) {
  V v_one_2415 = args[0];
  V v_z_2416 = args[1];
  V v_as_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_clo), 1, (V[]){v_as_244}));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_2416}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_a_2423;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_y_2422 = heff_dup(heff_field(v_one_2415, 1));
      v_a_2423 = v_y_2422;
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    V v_t_2426;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_one_2415, 0);
      heff_take_n(v_one_2415, 1ULL, 2);
      v_t_2426 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    V v_t_2431;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2423, heff_take_field(v_x_2419, 1)});
      v_t_2431 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_x_2419, 1ULL, 2, shape_binds__args, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      break;
    }
    case TAG_Just: {
      V v_bd_2428 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2428, heff_take_field(v_x_2419, 0)});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2423, heff_get_n(v_x_2419, 1, 2)});
      v_t_2431 = heff_rec_n(2, shape_binds__args, (V[]){v_t_2429, v_t_2430});
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
Clo g_heff_2ecompile_2esimplify_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartW_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapartW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2444;
      switch (heff_tag_of(v_f_248)) {
      case TAG_EVar: {
        V v_y_2410 = heff_dup(heff_field(v_f_248, 0));
        v_t_2444 = heff_strEq_lent(v_x_240, v_y_2410, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_f_248);
      }
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_f_248);
        heff_drop(v_as_249);
        heff_drop(v_t_2444);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2444);
        V v_t_2445 = (g_heff_2ecompile_2eir_2eappendI(v_as_249, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2445});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ELet: {
      V v_a_2447 = heff_field(v_x21_242, 1);
      V v_b_2448 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2449 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2448, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2449;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2450 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2452 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2450, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2452;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2453 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V v_t_2491;
      switch (heff_tag_of(v_e_2453)) {
      case TAG_EVar: {
        V v_y_2457 = heff_dup(heff_field(v_e_2453, 0));
        v_t_2491 = heff_strEq_lent(v_x_240, v_y_2457, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2453);
      }
      if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2453);
        heff_drop(v_t_2491);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2491);
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2453, v_rest_243});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ETag: {
      V v_as_2493 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2495 = (g_heff_2ecompile_2eir_2eappendI(v_as_2493, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2495;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2496 = heff_field(v_x21_242, 0);
      V v_arms_2497 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24132;
      switch (heff_tag_of(v_sc_2496)) {
      case TAG_EVar: {
        V v_y_2498 = heff_dup(heff_field(v_sc_2496, 0));
        v_t_24132 = heff_strEq_lent(v_x_240, v_y_2498, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_24132 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_2496);
      }
      if ((heff_dup(v_t_24132) == NTAG(TAG_True))) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_sc_2496);
        heff_drop(v_arms_2497);
        heff_drop(v_t_24132);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_24132);
        V v_t_24133 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2497, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_sc_2496, v_t_24133});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_24136 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_24137 = (g_heff_2ecompile_2eir_2eappendI(v_as_24136, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24137;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_24139 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_24140 = (g_heff_2ecompile_2eir_2eappendI(v_as_24139, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24140;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapartW(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_as_2412 = heff_field(v_x3_242, 1);
        if ((heff_dup(v_m_245) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_248, heff_dup(v_a_2411), v_e_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_as_2412)});
        } else {
          heff_drop(v_m_245);
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_as_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esubstMarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_as_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_as_2412; V a_3 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_as_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapeOne_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapeOne(V v_m_240, V v_a_241, V v_s_242) {
top: ;
  if ((heff_dup(v_m_240) == NTAG(TAG_True))) {
    V v_t_243 = heff_rec_n(5, shape_ren__caps__vars__holes__n, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_s_242, 0)});
    V v_x1_244 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_241, v_t_243));
    V v_x_249;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_st_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 2)));
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 3)));
      v_x_249 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_e_245, v_t_247, v_t_248, heff_get_n(v_st_246, 4, 5)});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_x_249, 3)); V rr_ = heff_rec_reuse_nf(v_s_242, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2410});
  } else {
    V v_t_2411 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_a_241, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 0))});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_s_242});
  }
}
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eshapeOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_246 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_244), v_as_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2414;
    if (heff_intLt_c(v_y_2410, v_x_249)) {
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2412, v_ys_244));
      v_e_2414 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_245});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_245;
    }
    V v_t_2415 = (g_map_2esize(v_m_248));
    if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
      heff_drop(v_m_248);
      return v_e_2414;
    } else {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
  }
  case TAG_EApp: {
    V v_e1_2417 = heff_dup(heff_field(v_e_241, 0));
    V v_as_2418 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_2417)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EGlobal: {
      V v_g_2420 = heff_field(v_e1_2417, 0);
      V v_ru_24e1_2417_24EGlobal = heff_take_reuse_n(v_e1_2417, 1ULL, 1);
      heff_drop_tag(v_e_241, 2);
      V v_t_2421 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2eappendL(v_as_2418, v_t_2421));
      return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_2417_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2420}), v_t_2422});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2417, 0ULL, 4);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2417, 0ULL, 3);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2417, 0ULL, 1);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2417, 0ULL, 2);
      heff_drop(v_zs_240);
      heff_drop(v_as_2418);
      return v_e_241;
    }
    default: return heff_nomatch(v_e1_2417);
    }
  }
  case TAG_ELet: {
    V v_x_2455 = heff_field(v_e_241, 0);
    V v_a_2456 = heff_field(v_e_241, 1);
    V v_b_2457 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2458 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2455, v_a_2456, heff_hole()});
    V v_u_2459 = (g_heff_2ecompile_2esimplify_2estripLams_24dps(v_zs_240, v_b_2457, heff_dup(v_cell_2458)));
    heff_drop(v_u_2459);
    return v_cell_2458;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2469 = heff_field(v_e_241, 0);
    V v_arms_2470 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2471 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2471}), v_arms_2470));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2469, v_t_2477});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2472 = args[0];
  V v_go_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2472)) {
  case TAG_MkArm: {
    V v_t_2473 = heff_field(v_x2_2472, 0);
    V v_vs_2474 = heff_field(v_x2_2472, 1);
    V v_b_2475 = heff_field(v_x2_2472, 2);
    V v_ru_24x2_2472_24MkArm = heff_take_reuse_n(v_x2_2472, 7ULL, 3);
    V v_t_2476 = heff_tr(heff_call(v_go_2471, 1, (V[]){v_b_2475}));
    return heff_tag_at_n(v_ru_24x2_2472_24MkArm, TAG_MkArm, 3, (V[]){v_t_2473, v_vs_2474, v_t_2476});
  }
  default: return heff_nomatch(v_x2_2472);
  }
}
Clo g_heff_2ecompile_2esimplify_2eallPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallPure(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_p_241});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_244 = ({ V a_0 = v_a_242; V a_1 = v_p_241; V r_ = (g_heff_2ecompile_2esimplify_2eargPure(a_0, a_1)); heff_drop(v_a_242); r_; });
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_245);
        V t_0 = v_as_243;
        V t_1 = v_s_246;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        goto top;
      } else {
        heff_drop(v_as_243);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_246});
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eallPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallPure(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(V v_s_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_as_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1742233102x56855645(heff_dup(v_s_240), v_as_244));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_s_240;
      V t_1 = v_as_244;
      V t_2 = v_cell_246;
      v_s_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_243);
      heff_drop(v_as_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebeforeMoved_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2epushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2epushable(V v_a_240) {
top: ;
  V v_t_2435;
  switch (heff_tag_of(v_a_240)) {
  case TAG_EVar: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_a_240);
    heff_drop(v_t_2435);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2435);
    V v_t_2436 = (g_heff_2ecompile_2eir_2eisValue(v_a_240));
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eclosedKnown(v_a_240);
    } else {
      heff_drop(v_a_240);
      heff_drop(v_t_2436);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushable(a[0]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_as_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  } else {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop_rec(v_r_240, 4);
      V v_x_247 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_247});
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_g_249, v_r_240, v_f_241, v_as_242});
    }
    case TAG_ELam: {
      V v_xs_2417 = heff_field(v_f_241, 0);
      V v_it2_2418 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2418)) {
      case TAG_EVar: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EGlobal: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELam: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EApp: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELet: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ERecord: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EProj: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ETag: {
        V v_t_2434 = heff_field(v_it2_2418, 0);
        V v_es_2435 = heff_field(v_it2_2418, 1);
        V v_ts_2436 = heff_field(v_it2_2418, 2);
        V v_ru_24it2_2418_24ETag = heff_take_reuse_n(v_it2_2418, 7ULL, 3);
        V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
        V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
        if (heff_intEq_c(v_t_2437, v_t_2438)) {
          V v_t_2440 = (g_heff_2ecompile_2esimplify_2evarsAre(v_xs_2417, v_es_2435));
          if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_xs_2417);
            heff_drop(v_es_2435);
            heff_drop_cell(v_ru_24it2_2418_24ETag, 3);
            heff_drop(v_t_2440);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam3, 1, 3, (V[]){v_t_2434, v_as_242, v_ts_2436});
          } else {
            heff_drop(v_t_2440);
            return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at_n(v_ru_24it2_2418_24ETag, TAG_ETag, 3, (V[]){v_t_2434, v_es_2435, v_ts_2436}), v_as_242));
          }
        } else {
          return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at_n(v_ru_24it2_2418_24ETag, TAG_ETag, 3, (V[]){v_t_2434, v_es_2435, v_ts_2436}), v_as_242));
        }
      }
      case TAG_EMatch: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrim: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrimCall: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ECall: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EInt: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EStr: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EBytes: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFixed: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat32: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EAbandon: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFix: {
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      default: return heff_nomatch(v_it2_2418);
      }
    }
    case TAG_EApp: {
      V v_g_2458 = heff_field(v_f_241, 0);
      V v_bs_2459 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      V v_t_2460 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2459, v_as_242));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_g_2458, v_t_2460});
    }
    case TAG_ELet: {
      V v_x_2461 = heff_field(v_f_241, 0);
      V v_a_2462 = heff_field(v_f_241, 1);
      V v_b_2463 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2463, v_as_242}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam4, 1, 3, (V[]){v_m_2464, v_x_2461, v_a_2462});
    }
    case TAG_ERecord: {
      heff_drop_rec(v_r_240, 4);
      V v_x_2471 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam5, 1, 1, (V[]){v_x_2471});
    }
    case TAG_EProj: {
      V v_it1_2473 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2474 = heff_dup(heff_field(v_f_241, 1));
      V v_sh_2475 = heff_dup(heff_field(v_f_241, 2));
      V v_t_2476 = heff_dup(heff_field(v_f_241, 3));
      switch (heff_tag_of(v_it1_2473)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_2478 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam6, 1, 1, (V[]){v_x_2478});
      }
      case TAG_EGlobal: {
        V v_g_2480 = heff_field(v_it1_2473, 0);
        heff_take_n(v_it1_2473, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam7, 1, 7, (V[]){v_g_2480, v_l_2474, v_f_241, v_as_242, v_r_240, v_sh_2475, v_t_2476});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24102 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam9, 1, 1, (V[]){v_x_24102});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24106 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam10, 1, 1, (V[]){v_x_24106});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2473, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24111 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_24111});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24115 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24115});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2473, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24121 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam13, 1, 1, (V[]){v_x_24121});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2473, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24126 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24126});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24130 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24130});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24133 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24133});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24137 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24137});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24141 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24141});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24144 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24144});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24147 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24147});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24150 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24150});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24153 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24153});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24157 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24157});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_2473, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24160 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24160});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24162 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam25, 1, 1, (V[]){v_x_24162});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2473, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2474);
        heff_drop(v_sh_2475);
        heff_drop(v_t_2476);
        V v_x_24166 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam26, 1, 1, (V[]){v_x_24166});
      }
      default: return heff_nomatch(v_it1_2473);
      }
    }
    case TAG_ETag: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24171 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam27, 1, 1, (V[]){v_x_24171});
    }
    case TAG_EMatch: {
      V v_s_24173 = heff_field(v_f_241, 0);
      V v_arms_24174 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EMatch = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_24175 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_as_242)));
      V v_t_24176 = ({ V a_0 = v_t_24175; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24175); r_; });
      V v_t_24180 = heff_bool(((heff_dup(v_t_24176) == NTAG(TAG_True)) && ({ V v_t_24177 = (g_list_2efoldl_24s688118489x1560799399(MK_INT(0LL), MK_INT(0LL), heff_dup(v_as_242))); int c_ = ({ V v_t_24178 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24174)); int c_ = ({ V v_t_24179 = heff_intMul(heff_dup(v_t_24177), heff_intSub(heff_dup(v_t_24178), MK_INT(1LL))); int c_ = heff_intLe_c(heff_dup(v_t_24179), MK_INT(120LL)); heff_drop(v_t_24179); c_; }); heff_drop(v_t_24178); c_; }); heff_drop(v_t_24177); c_; })));
      heff_drop(v_t_24176);
      if ((heff_dup(v_t_24180) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24f_241_24EMatch, 2);
        heff_drop(v_t_24180);
        V v_m_24192 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam28, 1, 2, (V[]){v_as_242, v_r_240}), v_arms_24174));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam30, 1, 2, (V[]){v_m_24192, v_s_24173});
      } else {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_t_24180);
        V v_x_24197 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24f_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_24173, v_arms_24174}), v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam31, 1, 1, (V[]){v_x_24197});
      }
    }
    case TAG_EPrim: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24200 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam32, 1, 1, (V[]){v_x_24200});
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24204 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24204});
    }
    case TAG_ECall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24208 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24208});
    }
    case TAG_EInt: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24211 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24211});
    }
    case TAG_EFloat: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24214 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24214});
    }
    case TAG_EStr: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24217 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam37, 1, 1, (V[]){v_x_24217});
    }
    case TAG_EBytes: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24220 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam38, 1, 1, (V[]){v_x_24220});
    }
    case TAG_EFixed: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24224 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam39, 1, 1, (V[]){v_x_24224});
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24227 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam40, 1, 1, (V[]){v_x_24227});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24229 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam41, 1, 1, (V[]){v_x_24229});
    }
    case TAG_EFix: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24233 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam42, 1, 1, (V[]){v_x_24233});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_249), heff_rfield(v_s_2410, 2)));
  V v_m_2412 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_249); V a_3 = heff_dup(v_as_242); V a_4 = v_t_2411; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2estillCall(heff_dup(v_g_249), v_x_2414));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_x_2414);
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      heff_drop(v_t_2416);
      return (g_heff_2ecompile_2esimplify_2etrySpec(v_r_240, v_g_249, v_as_242, v_s_2415));
    } else {
      heff_drop(v_g_249);
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_as_242);
      heff_drop(v_t_2416);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2441 = args[0];
  V v_t_2434 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  V v_ts_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2434, v_as_242, v_ts_2436}), v_s_2441});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_x_2461 = heff_env(self)[1];
  V v_a_2462 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_s_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_s_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2461, v_a_2462, v_x_2467}), v_s_2468});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2472 = args[0];
  V v_x_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2471, v_s_2472});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2479 = args[0];
  V v_x_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2478, v_s_2479});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    heff_take_n(v_x2_2497, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_2498;
    heff_room[1] = v_as_242;
    heff_room[2] = v_s_2499;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2481 = args[0];
  V v_g_2480 = heff_env(self)[0];
  V v_l_2474 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  V v_sh_2475 = heff_env(self)[5];
  V v_t_2476 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2482 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2480), heff_rfield(v_s_2481, 2)));
  V v_x2_2483 = (g_heff_2ecompile_2esimplify_2efueled(v_t_2482, v_s_2481));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_s_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    switch (heff_tag_of(v_x_2484)) {
    case TAG_Nothing: {
      heff_drop(v_sh_2475);
      heff_drop(v_t_2476);
      V v_x2_2486 = (g_heff_2ecompile_2esimplify_2eknownField(v_g_2480, v_l_2474, v_s_2485));
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_MkPair: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_s_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        switch (heff_tag_of(v_x_2487)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2489 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
          return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){v_x_2489, v_s_2488});
        }
        case TAG_Just: {
          V v_v_2490 = heff_field(v_x_2487, 0);
          heff_take_n(v_x_2487, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2483_24MkPair, 2);
          V v_t_2491 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
          V v_t_2492 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_v_2490, v_as_242}));
          return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2491, v_t_2492, v_s_2488));
        }
        default: return heff_nomatch(v_x_2487);
        }
      }
      default: return heff_nomatch(v_x2_2486);
      }
    }
    case TAG_Just: {
      V v_b_2493 = heff_field(v_x_2484, 0);
      heff_take_n(v_x_2484, 1ULL, 1);
      heff_drop(v_g_2480);
      heff_drop_cell(v_ru_24x2_2483_24MkPair, 2);
      V v_t_2494 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
      V v_m_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 4, (V[]){v_l_2474, v_sh_2475, v_t_2476, v_b_2493}));
      return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2494, heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam8, 1, 3, (V[]){v_m_2495, v_r_240, v_as_242}), v_s_2485));
    }
    default: return heff_nomatch(v_x_2484);
    }
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_24103 = args[0];
  V v_x_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24102, v_s_24103});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_24107 = args[0];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24106, v_s_24107});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24112 = args[0];
  V v_x_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24111, v_s_24112});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24116 = args[0];
  V v_x_24115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24115, v_s_24116});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24121, v_s_24122});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24127 = args[0];
  V v_x_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24126, v_s_24127});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24131 = args[0];
  V v_x_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24130, v_s_24131});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24134 = args[0];
  V v_x_24133 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24133, v_s_24134});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24137, v_s_24138});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24142 = args[0];
  V v_x_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24142});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24144, v_s_24145});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24148 = args[0];
  V v_x_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24147, v_s_24148});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24151 = args[0];
  V v_x_24150 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24150, v_s_24151});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24154 = args[0];
  V v_x_24153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24153, v_s_24154});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24158 = args[0];
  V v_x_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24157, v_s_24158});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24161 = args[0];
  V v_x_24160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24160, v_s_24161});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_s_24163 = args[0];
  V v_x_24162 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24162, v_s_24163});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24167 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24166, v_s_24167});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_s_24172 = args[0];
  V v_x_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24171, v_s_24172});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24185 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_24184 = heff_env(self)[2];
  V v_t_24182 = heff_env(self)[3];
  V v_vs_24183 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24186 = (g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(v_as_242, v_s_24185));
  V v_x2_24189;
  switch (heff_tag_of(v_x2_24186)) {
  case TAG_MkPair: {
    V v_x_24187 = heff_field(v_x2_24186, 0);
    V v_s_24188 = heff_field(v_x2_24186, 1);
    heff_take_n(v_x2_24186, 3ULL, 2);
    v_x2_24189 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 3, (V[]){v_b_24184, v_x_24187, v_s_24188}));
    break;
  }
  default: heff_nomatch(v_x2_24186);
  }
  switch (heff_tag_of(v_x2_24189)) {
  case TAG_MkPair: {
    V v_x_24190 = heff_field(v_x2_24189, 0);
    V v_s_24191 = heff_field(v_x2_24189, 1);
    V v_ru_24x2_24189_24MkPair = heff_take_reuse_n(v_x2_24189, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24182, v_vs_24183, v_x_24190}), v_s_24191});
  }
  default: return heff_nomatch(v_x2_24189);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_a_24181 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24181)) {
  case TAG_MkArm: {
    V v_t_24182 = heff_field(v_a_24181, 0);
    V v_vs_24183 = heff_field(v_a_24181, 1);
    V v_b_24184 = heff_field(v_a_24181, 2);
    heff_take_n(v_a_24181, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam29, 1, 5, (V[]){v_as_242, v_r_240, v_b_24184, v_t_24182, v_vs_24183});
  }
  default: return heff_nomatch(v_a_24181);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_s_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  V v_s_24173 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_s_24193}));
  switch (heff_tag_of(v_x2_24194)) {
  case TAG_MkPair: {
    V v_x_24195 = heff_field(v_x2_24194, 0);
    V v_s_24196 = heff_field(v_x2_24194, 1);
    V v_ru_24x2_24194_24MkPair = heff_take_reuse_n(v_x2_24194, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_24173, v_x_24195}), v_s_24196});
  }
  default: return heff_nomatch(v_x2_24194);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24198 = args[0];
  V v_x_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24197, v_s_24198});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24201 = args[0];
  V v_x_24200 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24200, v_s_24201});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24205 = args[0];
  V v_x_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24204, v_s_24205});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24209 = args[0];
  V v_x_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24208, v_s_24209});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24212 = args[0];
  V v_x_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24211, v_s_24212});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24215 = args[0];
  V v_x_24214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24214, v_s_24215});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args) {
  V v_s_24218 = args[0];
  V v_x_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24217, v_s_24218});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args) {
  V v_s_24221 = args[0];
  V v_x_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24220, v_s_24221});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args) {
  V v_s_24225 = args[0];
  V v_x_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24224, v_s_24225});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args) {
  V v_s_24228 = args[0];
  V v_x_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24227, v_s_24228});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args) {
  V v_s_24230 = args[0];
  V v_x_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24229, v_s_24230});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args) {
  V v_s_24234 = args[0];
  V v_x_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24233, v_s_24234});
}