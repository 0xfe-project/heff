// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_plain 308106724
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vers 10111479
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eafresh_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapartW(V, V);
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartW_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebackTo_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyField(V);
V g_heff_2ecompile_2esimplify_2ecopyField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyField_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efindField_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2egivesItBack(V, V);
V g_heff_2ecompile_2esimplify_2egivesItBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egivesItBack_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknowing_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2eprojW(V, V, V);
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojW_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
V g_heff_2ecompile_2esimplify_2eprunedFor(V, V);
V g_heff_2ecompile_2esimplify_2eprunedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedFor_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordTakenApart_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsTouched_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esetOff_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etagsGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2etagsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagsGiven_clo;
V g_heff_2ecompile_2esimplify_2etestsOf(V, V);
V g_heff_2ecompile_2esimplify_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etestsOf_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_list_2eall_24s1934518973x1420187537(V);
V g_list_2eall_24s1934518973x1420187537_entry(V self, V *a);
extern Clo g_list_2eall_24s1934518973x1420187537_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_std_2emap_2eempty_get(void);
Clo g_heff_2ecompile_2esimplify_2eprojW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojW_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprojW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_argv_2410 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_argv_2410, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2415;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2416, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2418;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V v_t_2462;
      switch (heff_tag_of(v_e_2419)) {
      case TAG_EVar: {
        V v_y_2423 = heff_dup(heff_field(v_e_2419, 0));
        v_t_2462 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2423, 0));
        heff_drop(v_y_2423);
        break;
      }
      case TAG_EGlobal: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2419);
      }
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_e_2419);
        heff_drop(v_t_2462);
        V t_0 = v_x_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_x_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2462);
        V t_0 = v_x_240;
        V t_1 = v_n_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
        v_x_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_ETag: {
      V v_argv_2464 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2466 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2464, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2466;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2467 = heff_field(v_x31_243, 0);
      V v_arms_2468 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2469 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2468, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2467, v_t_2469});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2472 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2473 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2472, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2473;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2475 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2476 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2475, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2476;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2484 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2485 = ({ V a_0 = v_c_2484; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2484); r_; });
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2485;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2487 = heff_field(v_x31_243, 1);
      V v_b_2488 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2489 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2487, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2488, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2489;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2490 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2491 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2490, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2491;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eprojW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2erecordTakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordTakenApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordTakenApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_a_241, 0);
    heff_take_n(v_a_241, 1ULL, 2);
    V v_t_2414 = (g_list_2emap_24s1044393341x1523302351(v_fs_2412));
    V v_x1_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
    heff_drop(v_x1_2415);
    V v_ret_24bool = heff_bool(((heff_dup(v_t_2416) == NTAG(TAG_True)) && ({ V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2418 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_2417))); int c_ = ({ V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2420 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_2419))); int c_ = ({ V v_x_2421 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2418), heff_dup(v_t_2420)}), 0, 2); int c_ = (heff_intLe_c_lent(MK_INT(2LL), v_x_2421, 1) && ({ V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2455 = (g_heff_2ecompile_2esimplify_2eprojW(v_x_240, MK_INT(0LL), heff_dup(v_t_2422))); int c_ = ({ V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2424 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_2423))); int c_ = ({ V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2426 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_2425))); int c_ = ({ V v_t_2456 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2424), heff_dup(v_t_2426)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2455, v_t_2456, 0); heff_drop(v_t_2456); c_; }); heff_drop(v_t_2426); c_; }); heff_drop(v_t_2425); c_; }); heff_drop(v_t_2424); c_; }); heff_drop(v_t_2423); c_; }); heff_drop(v_t_2455); c_; }); heff_drop(v_t_2422); c_; })); heff_drop(v_x_2421); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2419); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2417); c_; })));
    heff_drop(v_b_242);
    heff_drop(v_t_2416);
    return v_ret_24bool;
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2erecordTakenApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2erecordTakenApart(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprunedCopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eprunedCopy(V v_x1_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return v_x1_240;
  }
  case TAG_EGlobal: {
    return v_x1_240;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = (g_list_2eany_24s415398368x1824706470(v_argv_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ecompile_2esimplify_2etagsGiven(v_xs_244, v_argv_241, heff_dup(g_std_2emap_2eempty_get())));
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eprunedFor(v_t_247, heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){v_xs_244, v_b_245}));
    } else {
      heff_drop(v_t_246);
      return heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){v_xs_244, v_b_245});
    }
  }
  case TAG_EApp: {
    return v_x1_240;
  }
  case TAG_ELet: {
    return v_x1_240;
  }
  case TAG_ERecord: {
    return v_x1_240;
  }
  case TAG_EProj: {
    return v_x1_240;
  }
  case TAG_ETag: {
    return v_x1_240;
  }
  case TAG_EMatch: {
    return v_x1_240;
  }
  case TAG_EPrim: {
    return v_x1_240;
  }
  case TAG_EPrimCall: {
    return v_x1_240;
  }
  case TAG_ECall: {
    return v_x1_240;
  }
  case TAG_EInt: {
    return v_x1_240;
  }
  case TAG_EFloat: {
    return v_x1_240;
  }
  case TAG_EStr: {
    return v_x1_240;
  }
  case TAG_EBytes: {
    return v_x1_240;
  }
  case TAG_EFixed: {
    return v_x1_240;
  }
  case TAG_EFloat32: {
    return v_x1_240;
  }
  case TAG_EAbandon: {
    return v_x1_240;
  }
  case TAG_EBool: {
    return v_x1_240;
  }
  case TAG_ESet: {
    return v_x1_240;
  }
  case TAG_EValues: {
    return v_x1_240;
  }
  case TAG_EFix: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eprunedCopy(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartW_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapartW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2449;
      switch (heff_tag_of(v_f_248)) {
      case TAG_EVar: {
        V v_y_2410 = heff_dup(heff_field(v_f_248, 0));
        v_t_2449 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2410, 0));
        heff_drop(v_y_2410);
        break;
      }
      case TAG_EGlobal: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_f_248);
      }
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_f_248);
        heff_drop(v_argv_249);
        heff_drop_cell(v_ru_24x21_242_24EApp, 2);
        heff_drop(v_t_2449);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2449);
        V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_249, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2450});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ELet: {
      V v_a_2452 = heff_field(v_x21_242, 1);
      V v_b_2453 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2454 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2452, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2453, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2454;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2455 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2457 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2455, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2457;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2458 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V v_t_24101;
      switch (heff_tag_of(v_e_2458)) {
      case TAG_EVar: {
        V v_y_2462 = heff_dup(heff_field(v_e_2458, 0));
        v_t_24101 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2462, 0));
        heff_drop(v_y_2462);
        break;
      }
      case TAG_EGlobal: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2458);
      }
      if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2458);
        heff_drop(v_t_24101);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_24101);
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2458, v_rest_243});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ETag: {
      V v_argv_24103 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_24105 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_24103, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24105;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_24106 = heff_field(v_x21_242, 0);
      V v_arms_24107 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24147;
      switch (heff_tag_of(v_sc_24106)) {
      case TAG_EVar: {
        V v_y_24108 = heff_dup(heff_field(v_sc_24106, 0));
        v_t_24147 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24108, 0));
        heff_drop(v_y_24108);
        break;
      }
      case TAG_EGlobal: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_24147 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_24106);
      }
      if ((heff_dup(v_t_24147) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_sc_24106);
        heff_drop(v_arms_24107);
        heff_drop(v_t_24147);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_24147);
        V v_t_24148 = (g_heff_2ecompile_2eir_2epushArms(v_arms_24107, v_rest_243));
        V t_0 = v_x_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_sc_24106, v_t_24148});
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_24151 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_24152 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_24151, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24152;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_24154 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_24155 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_24154, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24155;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_24163 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_x_24164 = (g_heff_2ecompile_2esimplify_2etestsOf(v_x_240, v_c_24163));
      if (heff_intLt_c(MK_INT(0LL), v_x_24164)) {
        heff_drop(v_rest_243);
        heff_drop(v_c_24163);
        return NTAG(TAG_True);
      } else {
        V v_t_24165 = ({ V a_0 = v_c_24163; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_24163); r_; });
        V t_0 = v_x_240;
        V t_1 = v_t_24165;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_ESet: {
      V v_a_24167 = heff_field(v_x21_242, 1);
      V v_b_24168 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_24169 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_24167, heff_tag_n(TAG_Cons, 2, (V[]){v_b_24168, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_24169;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_24170 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24171 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_24170, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_24171;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eapartW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eapartW(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_argv_2412 = heff_field(v_x3_242, 1);
        if ((heff_dup(v_m_245) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          V v_m_2413 = ({ V a_0 = v_x_248; V a_1 = heff_dup(v_a_2411); V a_2 = v_e_243; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_argv_2412)});
        } else {
          heff_drop(v_m_245);
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_argv_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esubstMarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_argv_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_argv_2412; V a_3 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_argv_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eknowing_24cpr(V v_r_240, V v_b0_241, V v_s_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(heff_dup(v_s_242)));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_x_246 = v_field_244;
    heff_drop(v_x_246);
    V v_s_247 = v_field_245;
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2esetOff_24cpr(NTAG(TAG_True), v_s_247));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      heff_drop(v_x_2411);
      V v_s_2412 = v_field_2410;
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b0_241}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_x_2415}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_s_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          HeffT2 v_t_2421 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2419, v_s_2420));
          {
            V v_field_2422 = v_t_2421.f[0];
            V v_field_2423 = v_t_2421.f[1];
            V v_x_2424 = v_field_2422;
            V v_s_2425 = v_field_2423;
            HeffT2 v_t_2426 = (g_heff_2ecompile_2esimplify_2ebackTo_24cpr(v_s_242, v_s_2425));
            {
              V v_field_2427 = v_t_2426.f[0];
              V v_field_2428 = v_t_2426.f[1];
              V v_x_2429 = v_field_2427;
              heff_drop(v_x_2429);
              V v_s_2430 = v_field_2428;
              return ((HeffT2){{v_x_2424, v_s_2430}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2414)}});
      }
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_244, v_l_240, 1)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_v_245}});
      } else {
        heff_drop(v_v_245);
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ecopyField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyField_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecopyField(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    V v_x11_2412 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyField_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyField(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2efindField_24cpr(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_244, v_l_240, 1)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_v_245}});
      } else {
        heff_drop(v_v_245);
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2egivesItBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egivesItBack_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2egivesItBack(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_MkArm: {
    V v_t_242 = heff_field(v_a_241, 0);
    V v_vs_243 = heff_field(v_a_241, 1);
    V v_a3_244 = heff_field(v_a_241, 2);
    switch (heff_tag_of(v_a3_244)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_a3_244, 0);
      switch (heff_tag_of(v_s_240)) {
      case TAG_EVar: {
        V v_x_246 = heff_field(v_s_240, 0);
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_246, v_y_245, 0));
        return v_ret_24bool;
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_240);
      }
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_t2_2459 = heff_field(v_a3_244, 0);
      V v_argv_2460 = heff_field(v_a3_244, 1);
      if (heff_strEq_c_lent(v_t_242, v_t2_2459, 0)) {
        V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
        V v_t_2463 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2460));
        if (heff_intEq_c(v_t_2462, v_t_2463)) {
          V v_t_2464 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_vs_243), heff_dup(v_argv_2460)));
          return ({ V a_0 = v_t_2464; V r_ = (g_list_2eall_24s1934518973x1420187537(a_0)); heff_drop(v_t_2464); r_; });
        } else {
          return NTAG(TAG_False);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_a3_244);
    }
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2egivesItBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2egivesItBack(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V v_d_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_x_245 = v_field_243;
    heff_drop(v_x_245);
    V v_s_246 = v_field_244;
    V v_kp_247 = heff_take_field(v_s_246, 8);
    V v_supply_248 = heff_take_field(v_s_246, 0);
    V v_fuel_249 = heff_take_field(v_s_246, 1);
    V v_defs_2410 = heff_take_field(v_s_246, 2);
    V v_safe_2411 = heff_take_field(v_s_246, 3);
    V v_base_2412 = heff_take_field(v_s_246, 4);
    V v_total_2413 = heff_take_field(v_s_246, 5);
    V v_plain_2414 = heff_take_field(v_s_246, 6);
    V v_sp_2415 = heff_get_n(v_s_246, 7, 9);
    V v_k_2416 = v_kp_247;
    V v_vers_2417 = heff_take_field(v_k_2416, 0);
    V v_kept_2418 = heff_take_field(v_k_2416, 1);
    V v_fresh_2419 = heff_take_field(v_k_2416, 3);
    V v_madeFresh_2420 = heff_get_n(v_k_2416, 4, 5);
    V v_m_2421 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), heff_dup(heff_rfield(v_d_240, 2))));
    V v_t_2422 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2417, v_kept_2418, NTAG(TAG_Nil), v_fresh_2419, v_madeFresh_2420});
    V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_248, v_fuel_249, v_defs_2410, v_safe_2411, v_base_2412, v_total_2413, v_plain_2414, v_sp_2415, v_t_2422})}));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_m_2426 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2424));
      V v_x2_2427 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_s_2425}));
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_MkPair: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_s_2429 = heff_field(v_x2_2427, 1);
        V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
        HeffT2 v_t_2430 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2428, v_s_2429));
        {
          V v_field_2431 = v_t_2430.f[0];
          V v_field_2432 = v_t_2430.f[1];
          V v_x_2433 = v_field_2431;
          V v_s_2434 = v_field_2432;
          HeffT2 v_t_2435 = (g_heff_2ecompile_2esimplify_2esettleDef_24cpr(MK_INT(5LL), heff_dup(heff_rfield(v_d_240, 0)), v_x_2433, v_s_2434));
          {
            V v_field_2436 = v_t_2435.f[0];
            V v_field_2437 = v_t_2435.f[1];
            V v_x_2438 = v_field_2436;
            V v_s_2439 = v_field_2437;
            V v_t_2442;
            switch (heff_tag_of(v_x_2438)) {
            case TAG_MkPair: {
              V v_x_2440 = heff_dup(heff_field(v_x_2438, 0));
              v_t_2442 = v_x_2440;
              break;
            }
            default: heff_nomatch(v_x_2438);
            }
            HeffT2 v_t_2443 = (g_heff_2ecompile_2esimplify_2erefsTouched_24cpr(v_t_2442, v_s_2439));
            {
              V v_field_2444 = v_t_2443.f[0];
              V v_field_2445 = v_t_2443.f[1];
              V v_x_2446 = v_field_2444;
              heff_drop(v_x_2446);
              V v_s_2447 = v_field_2445;
              V v_t_2450;
              switch (heff_tag_of(v_x_2438)) {
              case TAG_MkPair: {
                V v_x_2448 = heff_dup(heff_field(v_x_2438, 0));
                v_t_2450 = v_x_2448;
                break;
              }
              default: heff_nomatch(v_x_2438);
              }
              V v_t_2453;
              switch (heff_tag_of(v_x_2438)) {
              case TAG_MkPair: {
                V v_y_2452 = heff_dup(heff_field(v_x_2438, 1));
                v_t_2453 = v_y_2452;
                break;
              }
              default: heff_nomatch(v_x_2438);
              }
              V v_m_2454 = (g_heff_2ecompile_2esimplify_2einOrder(v_t_2450, v_t_2453));
              V v_x2_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_s_2447}));
              switch (heff_tag_of(v_x2_2455)) {
              case TAG_MkPair: {
                V v_x_2456 = heff_field(v_x2_2455, 0);
                V v_s_2457 = heff_field(v_x2_2455, 1);
                V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
                V v_t_2460;
                switch (heff_tag_of(v_x_2438)) {
                case TAG_MkPair: {
                  V v_x_2458 = heff_dup(heff_field(v_x_2438, 0));
                  v_t_2460 = v_x_2458;
                  break;
                }
                default: heff_nomatch(v_x_2438);
                }
                V v_t_2461 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), v_t_2460});
                V v_t_2462 = heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
                V v_t_2463 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2456, v_t_2462));
                V v_t_2466;
                switch (heff_tag_of(v_x_2438)) {
                case TAG_MkPair: {
                  V v_x_2464 = heff_field(v_x_2438, 0);
                  heff_take_n(v_x_2438, 1ULL, 2);
                  v_t_2466 = v_x_2464;
                  break;
                }
                default: heff_nomatch(v_x_2438);
                }
                V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_s_2457, 8)), 2, 5);
                V v_t_2468 = (g_heff_2ecompile_2esimplify_2edoneOf(heff_dup(v_s_2457), v_d_240, v_t_2466, v_t_2467));
                V v_t_2469 = heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
                V v_x_2470 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_t_2463, v_t_2469});
                return ((HeffT2){{v_x_2470, v_s_2457}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_2455)}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2427)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2423)}});
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eafresh_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_n_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop(v_n_243);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_244, v_p_241}});
    }
    case TAG_Just: {
      V v_d_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24MkPair, 2);
      V v_t_246 = ({ V rv_0 = v_n_243; V rr_ = heff_rec_reuse_nf(v_p_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_d_245, v_t_246);
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_24dps(v_ys_240, v_x12_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24f1929261245x38330200(a[0], a[1]);
}