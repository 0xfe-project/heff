// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_e 319
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_n 328
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipe 1012227257
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_binds__args[] = {LBL_binds, LBL_args};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_name__ver__recipe__depth__safe__made[] = {LBL_name, LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
static uint32_t shape_ren__vars__holes__n[] = {LBL_ren, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2esimplify_2eafresh(V, V);
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eafresh_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebudget_get(void);
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecaseBudget_get(void);
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2eclosedUses_get(void);
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2einlineMax_get(void);
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2eknown(V, V);
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknown_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eknownField(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownField_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eoneItem(V);
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneItem_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epushBudget_get(void);
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2ereplayed(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayed_clo;
V g_heff_2ecompile_2esimplify_2eshapeOne(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
V g_heff_2ecompile_2esimplify_2especArgSize_get(void);
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2especLimit_get(void);
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2estripLams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2estripLams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_24dps_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142(V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s28329515x1288460863(V, V, V);
V g_list_2efoldl_24s28329515x1288460863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s28329515x1288460863_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;

static V g_heff_2ecompile_2esimplify_2enoKeep_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2enoKeep_st;
static V g_heff_2ecompile_2esimplify_2enoKeep_init(void) {
  return heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
}
V g_heff_2ecompile_2esimplify_2enoKeep_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2enoKeep_st)) return g_heff_2ecompile_2esimplify_2enoKeep_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2enoKeep_val, &g_heff_2ecompile_2esimplify_2enoKeep_st, g_heff_2ecompile_2esimplify_2enoKeep_init);
}
Clo g_heff_2ecompile_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eelemStr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakeL_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattempt_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eattempt(V v_orig_240, V v_m_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_241, 1, (V[]){heff_dup(v_s_242)}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_orig_240), NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_lim_248 = heff_intAdd(v_t_247, heff_dup(g_heff_2ecompile_2esimplify_2ebudget_get()));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
    V v_x_2410 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_248), MK_INT(0LL), v_t_249));
    if (heff_intLt_c(v_lim_248, v_x_2410)) {
      heff_drop(v_x_244);
      V v_t_2412 = ({ V rv_2 = heff_take_field(v_s_242, 2); V rv_5 = heff_get_n(v_s_242, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_245, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_240, v_t_2412});
    } else {
      heff_drop(v_orig_240);
      heff_drop_rec(v_s_242, 9);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattempt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eisPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eisPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eisPure(V v_e_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_241, 3), heff_rfield(v_s_241, 5), v_e_240));
  V v_t_2436;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    v_t_2436 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_242);
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      V v_f_247 = heff_field(v_e_240, 0);
      V v_as_248 = heff_field(v_e_240, 1);
      v_t_2436 = (g_heff_2ecompile_2esimplify_2epartialHead(heff_dup(v_s_241), heff_dup(v_as_248), v_f_247));
      break;
    }
    case TAG_ELet: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_s_241});
}
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eisPure(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_241));
    if (heff_intEq_c(v_t_244, heff_dup(v_n_243))) {
      heff_drop(v_n_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      V v_x2_2412;
      switch (heff_tag_of(v_as_241)) {
      case TAG_Nil: {
        v_x2_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_dup(heff_field(v_as_241, 0));
        V v_x22_247 = heff_dup(heff_field(v_as_241, 1));
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          v_x2_2412 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_246));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          heff_take_n(v_x22_247, 3ULL, 2);
          switch (heff_tag_of(v_x222_249)) {
          case TAG_Nil: {
            v_x2_2412 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_246, v_b_248));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x222_249, 0ULL, 2);
            heff_drop(v_a_246);
            heff_drop(v_b_248);
            v_x2_2412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x222_249);
          }
          break;
        }
        default: heff_nomatch(v_x22_247);
        }
        break;
      }
      default: heff_nomatch(v_as_241);
      }
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_241});
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop(v_as_241);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x2_2412);
      }
    } else {
      V v_x_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_241));
      if (heff_intLt_c(heff_dup(v_n_243), v_x_2414)) {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_as_2416 = (g_heff_2ecompile_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_as_241)));
        V v_x2_2423;
        switch (heff_tag_of(v_as_2416)) {
        case TAG_Nil: {
          v_x2_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_a_2417 = heff_dup(heff_field(v_as_2416, 0));
          V v_x22_2418 = heff_dup(heff_field(v_as_2416, 1));
          switch (heff_tag_of(v_x22_2418)) {
          case TAG_Nil: {
            v_x2_2423 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_2417));
            break;
          }
          case TAG_Cons: {
            V v_b_2419 = heff_field(v_x22_2418, 0);
            V v_x222_2420 = heff_field(v_x22_2418, 1);
            heff_take_n(v_x22_2418, 3ULL, 2);
            switch (heff_tag_of(v_x222_2420)) {
            case TAG_Nil: {
              v_x2_2423 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_2417, v_b_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2420, 0ULL, 2);
              heff_drop(v_a_2417);
              heff_drop(v_b_2419);
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x222_2420);
            }
            break;
          }
          default: heff_nomatch(v_x22_2418);
          }
          break;
        }
        default: heff_nomatch(v_as_2416);
        }
        V v_t_2425;
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_2416});
          break;
        }
        case TAG_Just: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          heff_take_n(v_x2_2423, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop(v_as_2416);
          v_t_2425 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_x2_2423);
        }
        V v_t_2426 = (g_heff_2ecompile_2esimplify_2edropL(v_n_243, v_as_241));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2425, v_t_2426});
      } else {
        heff_drop(v_n_243);
        return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eclosedKnown(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), v_x_246)) {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x1_240, 0);
    V v_ts_2414 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2415 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){heff_dup(v_fs_2413), heff_dup(v_ts_2414)}), NTAG(TAG_Nil)});
    V v_x_2416 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_2415));
    if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), v_x_2416)) {
      heff_drop(v_fs_2413);
      heff_drop(v_ts_2414);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2413, v_ts_2414}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eclosedKnown(a[0]);
}

static V g_heff_2ecompile_2esimplify_2eclosedUses_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2eclosedUses_st;
static V g_heff_2ecompile_2esimplify_2eclosedUses_init(void) {
  return MK_INT(4LL);
}
V g_heff_2ecompile_2esimplify_2eclosedUses_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2eclosedUses_st)) return g_heff_2ecompile_2esimplify_2eclosedUses_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2eclosedUses_val, &g_heff_2ecompile_2esimplify_2eclosedUses_st, g_heff_2ecompile_2esimplify_2eclosedUses_init);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_str0, 1, "$");
Clo g_heff_2ecompile_2esimplify_2efreshName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshName_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efreshName(V v_base_240, V v_s_241) {
top: ;
  V v_n_242 = heff_take_field(v_s_241, 0);
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2efreshName_str0), heff_intShow(heff_dup(v_n_242)));
  V v_t_244 = ({ V rv_0 = heff_intAdd(v_n_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_base_240, v_t_243), v_t_244});
}
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esplitArgs_str0, 1, "t");
Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esplitArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esplitArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_rec_n(2, shape_binds__args, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2eisPure(v_a_243, v_p_241));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_x2_2414;
      if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
        heff_drop(v_x_246);
        V v_t_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
        v_x2_2414 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_s_247});
      } else {
        heff_drop(v_x_246);
        V v_x2_249 = (g_heff_2ecompile_2esimplify_2efreshName(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_str0), v_s_247));
        switch (heff_tag_of(v_x2_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x2_249, 0);
          V v_s_2411 = heff_field(v_x2_249, 1);
          V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
          V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_x_2410), v_a_243})});
          V v_t_2413 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2410})});
          v_x2_2414 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_s_2411});
          break;
        }
        default: heff_nomatch(v_x2_249);
        }
      }
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_clo), 1, (V[]){v_as_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_s_2420 = heff_field(v_x2_2418, 1);
          V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
          V v_x1_2423;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_dup(heff_field(v_x_2415, 0));
            v_x1_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          V v_a_2426;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_MkPair: {
            V v_y_2425 = heff_field(v_x_2415, 1);
            heff_take_n(v_x_2415, 2ULL, 2);
            v_a_2426 = v_y_2425;
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          V v_x_2431;
          switch (heff_tag_of(v_x1_2423)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
            V v_t_2427 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_a_2426, heff_dup(heff_rfield(v_x_2419, 1))});
            v_x_2431 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_x_2419, 1ULL, 2, shape_binds__args, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          case TAG_Just: {
            V v_bd_2428 = heff_field(v_x1_2423, 0);
            heff_take_n(v_x1_2423, 1ULL, 1);
            V v_t_2429 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_bd_2428, heff_dup(heff_rfield(v_x_2419, 0))});
            V v_t_2430 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_a_2426, heff_get_n(v_x_2419, 1, 2)});
            v_x_2431 = heff_rec_n(2, shape_binds__args, (V[]){v_t_2429, v_t_2430});
            break;
          }
          default: heff_nomatch(v_x1_2423);
          }
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2431, v_s_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esplitArgs(a[0], a[1]);
}

static V g_heff_2ecompile_2esimplify_2einlineMax_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2einlineMax_st;
static V g_heff_2ecompile_2esimplify_2einlineMax_init(void) {
  return MK_INT(50LL);
}
V g_heff_2ecompile_2esimplify_2einlineMax_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2einlineMax_st)) return g_heff_2ecompile_2esimplify_2einlineMax_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2einlineMax_val, &g_heff_2ecompile_2esimplify_2einlineMax_st, g_heff_2ecompile_2esimplify_2einlineMax_init);
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_as_2412 = heff_field(v_x3_242, 1);
        if ((heff_dup(v_m_245) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_248, heff_dup(v_a_2411), v_e_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_as_2412)});
        } else {
          heff_drop(v_m_245);
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_as_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esubstMarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_as_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_as_2412; V a_3 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_as_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapeOne_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapeOne(V v_m_240, V v_a_241, V v_s_242) {
top: ;
  if ((heff_dup(v_m_240) == NTAG(TAG_True))) {
    V v_t_243 = heff_rec_n(4, shape_ren__vars__holes__n, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_s_242, 0)});
    V v_x1_244 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_241, v_t_243));
    V v_x_249;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_st_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 1)));
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 2)));
      v_x_249 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_e_245, v_t_247, v_t_248, heff_get_n(v_st_246, 3, 4)});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_x_249, 3)); V rr_ = heff_rec_reuse_nf(v_s_242, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2410});
  } else {
    V v_t_2411 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_a_241, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 0))});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_s_242});
  }
}
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eshapeOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapesOf(V v_x1_240, V v_as_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_t_246, v_p_242});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_as_241, 0);
      V v_as2_248 = heff_field(v_as_241, 1);
      V v_ru_24as_241_24Cons = heff_take_reuse_n(v_as_241, 3ULL, 2);
      V v_x2_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; V r_ = (g_heff_2ecompile_2esimplify_2eshapeOne(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_m_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_as2_248}));
        V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_s_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2410, 0)), heff_dup(heff_rfield(v_x_2414, 0))});
          V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(heff_take_field(v_x_2410, 1), heff_take_field(v_x_2414, 1)));
          V v_t_2418 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_x_2410, 2, 4), heff_get_n(v_x_2414, 2, 3)));
          V v_x_2419 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_t_2416, v_t_2417, v_t_2418});
          return heff_tag_at_n(v_ru_24as_241_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2415});
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_246 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_244), v_as_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_x_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_y_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2414;
    if (heff_intLt_c(v_y_2410, v_x_249)) {
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2412, v_ys_244));
      v_e_2414 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_245});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_245;
    }
    V v_t_2415 = (g_map_2esize(v_m_248));
    if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
      heff_drop(v_m_248);
      return v_e_2414;
    } else {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
  }
  case TAG_EApp: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_241, 0);
    V v_a_2420 = heff_field(v_e_241, 1);
    V v_b_2421 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2422 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_a_2420, heff_hole()});
    V v_u_2423 = (g_heff_2ecompile_2esimplify_2estripLams_24dps(v_zs_240, v_b_2421, heff_dup(v_cell_2422)));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2432 = heff_field(v_e_241, 0);
    V v_arms_2433 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2434}), v_arms_2433));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2432, v_t_2440});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2435 = args[0];
  V v_go_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkArm: {
    V v_t_2436 = heff_field(v_x2_2435, 0);
    V v_vs_2437 = heff_field(v_x2_2435, 1);
    V v_b_2438 = heff_field(v_x2_2435, 2);
    V v_ru_24x2_2435_24MkArm = heff_take_reuse_n(v_x2_2435, 7ULL, 3);
    V v_t_2439 = heff_tr(heff_call(v_go_2434, 1, (V[]){v_b_2438}));
    return heff_tag_at_n(v_ru_24x2_2435_24MkArm, TAG_MkArm, 3, (V[]){v_t_2436, v_vs_2437, v_t_2439});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2esimplify_2especLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especLam_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 6, 7);
  V v_t_2412 = heff_bool(((heff_dup(v_t_246) == NTAG(TAG_True)) || ({ V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 5, 7); int c_ = (heff_intLe_c(heff_dup(g_heff_2ecompile_2esimplify_2especLimit_get()), heff_dup(v_t_247)) || ({ V v_x1_2411 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2esimplify_2especLam_lam0, 1, 1, (V[]){heff_dup(v_s_245)}), v_as_244)); int c_ = !(heff_dup(v_x1_2411) == NTAG(TAG_True)); heff_drop(v_x1_2411); c_; })); heff_drop(v_t_247); c_; })));
  heff_drop(v_t_246);
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_t_2412);
    V v_x_2413 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_s_245});
  } else {
    heff_drop(v_t_2412);
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
    V v_t_2415 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2416 = (g_heff_2ecompile_2eir_2enubI(v_t_2415));
    V v_t_2417 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2419;
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      V v_t_2418 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
    } else {
      heff_drop(v_t_2417);
      v_t_2419 = (g_list_2emap_24s73473062x206541869(heff_dup(v_xs_242)));
    }
    V v_t_2420 = ({ V a_0 = v_t_2414; V a_1 = v_as_244; V a_2 = v_t_2419; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2esimplify_2emarkGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    return (g_heff_2ecompile_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_t_2420, v_s_245));
  }
}
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2especLam_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_s_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get_n(heff_get_n(v_s_245, 7, 9), 1, 7);
  return ({ V a_0 = v_t_2410; V a_1 = v_a_249; V r_ = (g_heff_2ecompile_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_2410); r_; });
}
Clo g_heff_2ecompile_2esimplify_2epushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2epushable(V v_a_240) {
top: ;
  V v_t_2434;
  switch (heff_tag_of(v_a_240)) {
  case TAG_EVar: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_a_240);
    heff_drop(v_t_2434);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2434);
    V v_t_2435 = (g_heff_2ecompile_2eir_2eisValue(v_a_240));
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_t_2435);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eclosedKnown(v_a_240);
    } else {
      heff_drop(v_a_240);
      heff_drop(v_t_2435);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushable(a[0]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2437;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_m_2439;
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_t_2437);
      v_m_2439 = heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam1, 1, 1, (V[]){v_x_242});
    } else {
      heff_drop(v_t_2437);
      v_m_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_x_242}));
    }
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam2, 1, 2, (V[]){v_m_2439, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142(a[0]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam1(V self, V *args) {
  V v_a_2438 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_a_2438});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142_lam2(V self, V *args) {
  V v_s_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_s_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_m_2444 = (g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142(v_xs_243));
    V v_x2_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2443}));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_MkPair: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_s_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2442, v_x_2446}), v_s_2447});
    }
    default: return heff_nomatch(v_x2_2445);
    }
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_as_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  } else {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop_rec(v_r_240, 4);
      V v_x_247 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_247});
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_g_249, v_r_240, v_f_241, v_as_242});
    }
    case TAG_ELam: {
      V v_xs_2417 = heff_field(v_f_241, 0);
      V v_it2_2418 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24ELam = heff_take_reuse_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2418)) {
      case TAG_EVar: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EGlobal: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELam: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EApp: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELet: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ERecord: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EProj: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ETag: {
        V v_t_2434 = heff_field(v_it2_2418, 0);
        V v_es_2435 = heff_field(v_it2_2418, 1);
        heff_take_n(v_it2_2418, 3ULL, 2);
        V v_t_2436 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
        V v_t_2437 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
        if (heff_intEq_c(v_t_2436, v_t_2437)) {
          V v_t_2439 = (g_heff_2ecompile_2esimplify_2evarsAre(v_xs_2417, v_es_2435));
          if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_xs_2417);
            heff_drop_cell(v_ru_24f_241_24ELam, 2);
            heff_drop(v_es_2435);
            heff_drop(v_t_2439);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam3, 1, 2, (V[]){v_t_2434, v_as_242});
          } else {
            heff_drop(v_t_2439);
            return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at_n(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2434, v_es_2435}), v_as_242));
          }
        } else {
          return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at_n(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2434, v_es_2435}), v_as_242));
        }
      }
      case TAG_EMatch: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrim: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrimCall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ECall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EInt: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EStr: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EBytes: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFixed: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat32: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFix: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      default: return heff_nomatch(v_it2_2418);
      }
    }
    case TAG_EApp: {
      V v_g_2457 = heff_field(v_f_241, 0);
      V v_bs_2458 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      V v_t_2459 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2458, v_as_242));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_g_2457, v_t_2459});
    }
    case TAG_ELet: {
      V v_x_2460 = heff_field(v_f_241, 0);
      V v_a_2461 = heff_field(v_f_241, 1);
      V v_b_2462 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2462, v_as_242}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam4, 1, 3, (V[]){v_m_2463, v_x_2460, v_a_2461});
    }
    case TAG_ERecord: {
      heff_drop_rec(v_r_240, 4);
      V v_x_2470 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam5, 1, 1, (V[]){v_x_2470});
    }
    case TAG_EProj: {
      V v_it1_2472 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2473 = heff_dup(heff_field(v_f_241, 1));
      V v_sh_2474 = heff_dup(heff_field(v_f_241, 2));
      V v_t_2475 = heff_dup(heff_field(v_f_241, 3));
      switch (heff_tag_of(v_it1_2472)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_2477 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam6, 1, 1, (V[]){v_x_2477});
      }
      case TAG_EGlobal: {
        V v_g_2479 = heff_field(v_it1_2472, 0);
        heff_take_n(v_it1_2472, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam7, 1, 7, (V[]){v_g_2479, v_l_2473, v_f_241, v_as_242, v_r_240, v_sh_2474, v_t_2475});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24100 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam9, 1, 1, (V[]){v_x_24100});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24104 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam10, 1, 1, (V[]){v_x_24104});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2472, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24109 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_24109});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24113 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24113});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2472, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24119 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam13, 1, 1, (V[]){v_x_24119});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24123 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24123});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24127 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24127});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24130 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24130});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24134 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24134});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24138 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24138});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24141 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24141});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24144 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24144});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24147 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24147});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24150 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24150});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24154 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24154});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it1_2472, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24157 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24157});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24159 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam25, 1, 1, (V[]){v_x_24159});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2472, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2473);
        heff_drop(v_sh_2474);
        heff_drop(v_t_2475);
        V v_x_24163 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam26, 1, 1, (V[]){v_x_24163});
      }
      default: return heff_nomatch(v_it1_2472);
      }
    }
    case TAG_ETag: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24167 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam27, 1, 1, (V[]){v_x_24167});
    }
    case TAG_EMatch: {
      V v_s_24169 = heff_field(v_f_241, 0);
      V v_arms_24170 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EMatch = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_24171 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_as_242)));
      V v_t_24172 = ({ V a_0 = v_t_24171; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24171); r_; });
      V v_t_24176 = heff_bool(((heff_dup(v_t_24172) == NTAG(TAG_True)) && ({ V v_t_24173 = (g_list_2efoldl_24s28329515x1288460863(MK_INT(0LL), MK_INT(0LL), heff_dup(v_as_242))); int c_ = ({ V v_t_24174 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_24170)); int c_ = ({ V v_t_24175 = heff_intMul(heff_dup(v_t_24173), heff_intSub(heff_dup(v_t_24174), MK_INT(1LL))); int c_ = heff_intLe_c(heff_dup(v_t_24175), heff_dup(g_heff_2ecompile_2esimplify_2epushBudget_get())); heff_drop(v_t_24175); c_; }); heff_drop(v_t_24174); c_; }); heff_drop(v_t_24173); c_; })));
      heff_drop(v_t_24172);
      if ((heff_dup(v_t_24176) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24f_241_24EMatch, 2);
        heff_drop(v_t_24176);
        V v_m_24189 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam28, 1, 2, (V[]){v_as_242, v_r_240}), v_arms_24170));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam30, 1, 2, (V[]){v_m_24189, v_s_24169});
      } else {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_t_24176);
        V v_x_24194 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24f_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_24169, v_arms_24170}), v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam31, 1, 1, (V[]){v_x_24194});
      }
    }
    case TAG_EPrim: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24197 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam32, 1, 1, (V[]){v_x_24197});
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24201 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24201});
    }
    case TAG_ECall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24205 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24205});
    }
    case TAG_EInt: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24208 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24208});
    }
    case TAG_EFloat: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24211 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24211});
    }
    case TAG_EStr: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24214 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam37, 1, 1, (V[]){v_x_24214});
    }
    case TAG_EBytes: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24217 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam38, 1, 1, (V[]){v_x_24217});
    }
    case TAG_EFixed: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24221 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam39, 1, 1, (V[]){v_x_24221});
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24224 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam40, 1, 1, (V[]){v_x_24224});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24226 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam41, 1, 1, (V[]){v_x_24226});
    }
    case TAG_EFix: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24230 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam42, 1, 1, (V[]){v_x_24230});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_249), heff_rfield(v_s_2410, 2)));
  V v_m_2412 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_249); V a_3 = heff_dup(v_as_242); V a_4 = v_t_2411; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2estillCall(heff_dup(v_g_249), v_x_2414));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_x_2414);
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      heff_drop(v_t_2416);
      return (g_heff_2ecompile_2esimplify_2etrySpec(v_r_240, v_g_249, v_as_242, v_s_2415));
    } else {
      heff_drop(v_g_249);
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_as_242);
      heff_drop(v_t_2416);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2440 = args[0];
  V v_t_2434 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2434, v_as_242}), v_s_2440});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_x_2460 = heff_env(self)[1];
  V v_a_2461 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_s_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2460, v_a_2461, v_x_2466}), v_s_2467});
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2471 = args[0];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2470, v_s_2471});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2478 = args[0];
  V v_x_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2477, v_s_2478});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_s_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_s_2497 = heff_field(v_x2_2495, 1);
    heff_take_n(v_x2_2495, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_2496;
    heff_room[1] = v_as_242;
    heff_room[2] = v_s_2497;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2480 = args[0];
  V v_g_2479 = heff_env(self)[0];
  V v_l_2473 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  V v_sh_2474 = heff_env(self)[5];
  V v_t_2475 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2481 = (g_heff_2ecompile_2esimplify_2eknown(heff_dup(v_g_2479), v_s_2480));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_s_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    switch (heff_tag_of(v_x_2482)) {
    case TAG_Nothing: {
      heff_drop(v_sh_2474);
      heff_drop(v_t_2475);
      V v_x2_2484 = (g_heff_2ecompile_2esimplify_2eknownField(v_g_2479, v_l_2473, v_s_2483));
      switch (heff_tag_of(v_x2_2484)) {
      case TAG_MkPair: {
        V v_x_2485 = heff_field(v_x2_2484, 0);
        V v_s_2486 = heff_field(v_x2_2484, 1);
        heff_take_n(v_x2_2484, 3ULL, 2);
        switch (heff_tag_of(v_x_2485)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2487 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
          return heff_tag_at_n(v_ru_24x2_2481_24MkPair, TAG_MkPair, 2, (V[]){v_x_2487, v_s_2486});
        }
        case TAG_Just: {
          V v_v_2488 = heff_field(v_x_2485, 0);
          heff_take_n(v_x_2485, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2481_24MkPair, 2);
          V v_t_2489 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
          V v_t_2490 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_v_2488, v_as_242}));
          return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2489, v_t_2490, v_s_2486));
        }
        default: return heff_nomatch(v_x_2485);
        }
      }
      default: return heff_nomatch(v_x2_2484);
      }
    }
    case TAG_Just: {
      V v_b_2491 = heff_field(v_x_2482, 0);
      heff_take_n(v_x_2482, 1ULL, 1);
      heff_drop(v_g_2479);
      heff_drop_cell(v_ru_24x2_2481_24MkPair, 2);
      V v_t_2492 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
      V v_m_2493 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 4, (V[]){v_l_2473, v_sh_2474, v_t_2475, v_b_2491}));
      return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2492, heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam8, 1, 3, (V[]){v_m_2493, v_r_240, v_as_242}), v_s_2483));
    }
    default: return heff_nomatch(v_x_2482);
    }
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_24101 = args[0];
  V v_x_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24100, v_s_24101});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_24105 = args[0];
  V v_x_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24104, v_s_24105});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24109, v_s_24110});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24113, v_s_24114});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24120 = args[0];
  V v_x_24119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24119, v_s_24120});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24123, v_s_24124});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24128 = args[0];
  V v_x_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24127, v_s_24128});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24131 = args[0];
  V v_x_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24130, v_s_24131});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24135 = args[0];
  V v_x_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24134, v_s_24135});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24139 = args[0];
  V v_x_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24138, v_s_24139});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24142 = args[0];
  V v_x_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24142});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24144, v_s_24145});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24148 = args[0];
  V v_x_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24147, v_s_24148});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24151 = args[0];
  V v_x_24150 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24150, v_s_24151});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24155 = args[0];
  V v_x_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24154, v_s_24155});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24158 = args[0];
  V v_x_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24157, v_s_24158});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_s_24160 = args[0];
  V v_x_24159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24159, v_s_24160});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24164 = args[0];
  V v_x_24163 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24163, v_s_24164});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_s_24168 = args[0];
  V v_x_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24167, v_s_24168});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_24180 = heff_env(self)[2];
  V v_t_24178 = heff_env(self)[3];
  V v_vs_24179 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_s_24182}));
  V v_x2_24186;
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    heff_take_n(v_x2_24183, 3ULL, 2);
    v_x2_24186 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 3, (V[]){v_b_24180, v_x_24184, v_s_24185}));
    break;
  }
  default: heff_nomatch(v_x2_24183);
  }
  switch (heff_tag_of(v_x2_24186)) {
  case TAG_MkPair: {
    V v_x_24187 = heff_field(v_x2_24186, 0);
    V v_s_24188 = heff_field(v_x2_24186, 1);
    V v_ru_24x2_24186_24MkPair = heff_take_reuse_n(v_x2_24186, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24186_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24178, v_vs_24179, v_x_24187}), v_s_24188});
  }
  default: return heff_nomatch(v_x2_24186);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_a_24177 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24177)) {
  case TAG_MkArm: {
    V v_t_24178 = heff_field(v_a_24177, 0);
    V v_vs_24179 = heff_field(v_a_24177, 1);
    V v_b_24180 = heff_field(v_a_24177, 2);
    heff_take_n(v_a_24177, 7ULL, 3);
    V v_m_24181 = (g_heff_2ecompile_2esimplify_2etraverseS_24s812917450x1587842142(v_as_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam29, 1, 5, (V[]){v_m_24181, v_r_240, v_b_24180, v_t_24178, v_vs_24179});
  }
  default: return heff_nomatch(v_a_24177);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_s_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_s_24169 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24191 = heff_tr(heff_call(v_m_24189, 1, (V[]){v_s_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_s_24193 = heff_field(v_x2_24191, 1);
    V v_ru_24x2_24191_24MkPair = heff_take_reuse_n(v_x2_24191, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24191_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_24169, v_x_24192}), v_s_24193});
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24195 = args[0];
  V v_x_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24194, v_s_24195});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24198 = args[0];
  V v_x_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24197, v_s_24198});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24202 = args[0];
  V v_x_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24201, v_s_24202});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24206 = args[0];
  V v_x_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24205, v_s_24206});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24209 = args[0];
  V v_x_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24208, v_s_24209});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24212 = args[0];
  V v_x_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24211, v_s_24212});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args) {
  V v_s_24215 = args[0];
  V v_x_24214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24214, v_s_24215});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args) {
  V v_s_24218 = args[0];
  V v_x_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24217, v_s_24218});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args) {
  V v_s_24222 = args[0];
  V v_x_24221 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24221, v_s_24222});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args) {
  V v_s_24225 = args[0];
  V v_x_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24224, v_s_24225});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam41(V self, V *args) {
  V v_s_24227 = args[0];
  V v_x_24226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24226, v_s_24227});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam42(V self, V *args) {
  V v_s_24231 = args[0];
  V v_x_24230 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24230, v_s_24231});
}
Clo g_heff_2ecompile_2esimplify_2efindField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindField_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindField(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_l_240))) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindField(a[0], a1); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2esimplify_2ecaseBudget_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2ecaseBudget_st;
static V g_heff_2ecompile_2esimplify_2ecaseBudget_init(void) {
  return MK_INT(40LL);
}
V g_heff_2ecompile_2esimplify_2ecaseBudget_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2ecaseBudget_st)) return g_heff_2ecompile_2esimplify_2ecaseBudget_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2ecaseBudget_val, &g_heff_2ecompile_2esimplify_2ecaseBudget_st, g_heff_2ecompile_2esimplify_2ecaseBudget_init);
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_x_242, NTAG(TAG_MkUnit), v_seen_240));
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eonceEach_24dps(v_t_246, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_247);
      return v_cell_245;
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eoneItem_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eoneItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneItem_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eoneItem(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fresh: {
    V v_d_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eoneDef_clo), 1, (V[]){v_d_241});
  }
  case TAG_Kept: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_redo_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eoneItem_lam0, 1, 2, (V[]){v_k_242, v_redo_243});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneItem(a[0]);
}
V g_heff_2ecompile_2esimplify_2eoneItem_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_redo_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_242, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x2_246 = (g_heff_2ecompile_2esimplify_2ereplayed(v_k_242, v_t_245, heff_dup(v_s_244)));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    switch (heff_tag_of(v_x_247)) {
    case TAG_Nothing: {
      heff_drop(v_s_248);
      heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
      V v_t_249 = heff_tr(heff_call(v_redo_243, 1, (V[]){heff_dup(heff_rfield(v_s_244, 0))}));
      return (g_heff_2ecompile_2esimplify_2eafresh(v_t_249, v_s_244));
    }
    case TAG_Just: {
      V v_ds_2410 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 1);
      heff_drop_rec(v_s_244, 9);
      heff_drop(v_redo_243);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_ds_2410, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_s_248});
    }
    default: return heff_nomatch(v_x_247);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyWith_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyWith_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyWith(V v_st_240, V v_bodies_241, V v_h_242, V v_v_243, V v_r_244) {
top: ;
  if (heff_strEq_c(heff_dup(v_v_243), ((V)&g_heff_2ecompile_2esimplify_2ecopyWith_str0))) {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 3, 7);
    V v_x2_247 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_x3_2410 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_h_242), heff_rfield(v_st_240, 4)));
    V v_t_2412;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2emadeOf(v_st_240, v_bodies_241, heff_dup(v_h_242)));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_name__ver__recipe__depth__safe__made, (V[]){v_h_242, v_v_243, v_r_244, v_t_249, v_t_2412, v_t_2413})});
  }
}
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopyWith(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS(a[0]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2esimplify_2eoneItem(v_x_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(a[0]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}