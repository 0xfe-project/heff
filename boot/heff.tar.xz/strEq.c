// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_strEq_val;
static int g_strEq_st;
static V g_strEq_init(void) {
  return ((V)&prim_strEq_clo);
}
V g_strEq_get(void) {
  if (g_strEq_st == 2) return g_strEq_val;
  if (g_strEq_st == 1) heff_fail("defined by itself");
  g_strEq_st = 1;
  g_strEq_val = heff_tr(g_strEq_init());
  g_strEq_st = 2;
  return g_strEq_val;
}