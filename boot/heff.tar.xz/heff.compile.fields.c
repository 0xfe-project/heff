// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_holds 300818350
#define LBL_l 326
#define LBL_late 9809773
#define LBL_now 318800
#define LBL_r 332
#define LBL_reads 309745079
#define LBL_sh 10428
#define LBL_t 334
#define LBL_x 338
static uint32_t shape_l__sh__t[] = {LBL_l, LBL_sh, LBL_t};
static uint32_t shape_reads__late__holds__now[] = {LBL_reads, LBL_late, LBL_holds, LBL_now};
HeffT2 g_heff_2ecompile_2efields_2eboundAt_24cpr(V, V);
V g_heff_2ecompile_2efields_2eelemS(V, V);
V g_heff_2ecompile_2efields_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eelemS_clo;
V g_heff_2ecompile_2efields_2egoLate(V, V);
V g_heff_2ecompile_2efields_2egoLate_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2egoLate_clo;
V g_heff_2ecompile_2efields_2ekeptOf(V, V, V);
V g_heff_2ecompile_2efields_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ekeptOf_clo;
V g_heff_2ecompile_2efields_2elabelsOnce(V, V);
V g_heff_2ecompile_2efields_2elabelsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2elabelsOnce_clo;
V g_heff_2ecompile_2efields_2elatesAt(V, V, V, V);
V g_heff_2ecompile_2efields_2elatesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2elatesAt_clo;
V g_heff_2ecompile_2efields_2eletsOf(V, V, V);
V g_heff_2ecompile_2efields_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eletsOf_clo;
V g_heff_2ecompile_2efields_2eletsOf_24dps(V, V, V, V);
V g_heff_2ecompile_2efields_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eletsOf_24dps_clo;
V g_heff_2ecompile_2efields_2enumberOf(V, V);
V g_heff_2ecompile_2efields_2enumberOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2enumberOf_clo;
V g_heff_2ecompile_2efields_2enumbersW(V, V);
V g_heff_2ecompile_2efields_2enumbersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2enumbersW_clo;
V g_heff_2ecompile_2efields_2eplaced(V, V, V);
V g_heff_2ecompile_2efields_2eplaced_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eplaced_clo;
V g_heff_2ecompile_2efields_2ereadAt(V, V);
V g_heff_2ecompile_2efields_2ereadAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadAt_clo;
V g_heff_2ecompile_2efields_2ereadIn(V, V, V);
V g_heff_2ecompile_2efields_2ereadIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadIn_clo;
V g_heff_2ecompile_2efields_2ereadsAt(V, V, V);
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadsAt_clo;
HeffT2 g_heff_2ecompile_2efields_2ereadsW_24cpr(V, V, V);
V g_heff_2ecompile_2efields_2esameLabels(V, V);
V g_heff_2ecompile_2efields_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2esameLabels_clo;
V g_heff_2ecompile_2efields_2eusesW(V, V, V);
V g_heff_2ecompile_2efields_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eusesW_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s2116272255x866448265(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s2116272255x866448265_entry(V self, V *a);
extern Clo g_list_2eall_24s2116272255x866448265_clo;
V g_list_2eany_24s1873156379x541659222(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1873156379x541659222_entry(V self, V *a);
extern Clo g_list_2eany_24s1873156379x541659222_clo;
V g_list_2eany_24s1874753421x1382718931(V, V, V);
V g_list_2eany_24s1874753421x1382718931_entry(V self, V *a);
extern Clo g_list_2eany_24s1874753421x1382718931_clo;
V g_list_2eany_24s52192015x78999897(V, V);
V g_list_2eany_24s52192015x78999897_entry(V self, V *a);
extern Clo g_list_2eany_24s52192015x78999897_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1801023533x118610014_24cpr(V, V);
Clo g_heff_2ecompile_2efields_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2efields_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efields_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efields_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2efields_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efields_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efields_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efields_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ekeptOf_entry, 3, 0};

V g_heff_2ecompile_2efields_2ekeptOf(V v_v_240, V v_ls_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_l_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      V v_x321_2416 = heff_field(v_x32_244, 0);
      V v_l2_2417 = heff_field(v_x32_244, 1);
      V v_sh_2418 = heff_field(v_x32_244, 2);
      switch (heff_tag_of(v_x321_2416)) {
      case TAG_EVar: {
        V v_y_2420 = heff_field(v_x321_2416, 0);
        if (heff_strEq_c_lent(v_y_2420, v_v_240, 0)) {
          if (heff_strEq_c_lent(v_l_243, v_l2_2417, 0)) {
            return (g_heff_2ecompile_2efields_2esameLabels(v_ls_241, v_sh_2418));
          } else {
            return NTAG(TAG_False);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x321_2416);
      }
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efields_2ekeptOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2efields_2ekeptOf(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efields_2ereadsW_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2efields_2ereadsW_24cpr(V v_v_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_acc_241}});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      if (heff_strEq_c_lent(v_y_245, v_v_240, 1)) {
        heff_drop(v_acc_241);
        heff_drop(v_rest_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_b_247 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_248 = ({ V a_0 = v_v_240; V a_1 = v_xs_246; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_246); r_; });
      V v_t_249;
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_247);
        heff_drop(v_t_248);
        v_t_249 = v_rest_244;
      } else {
        heff_drop(v_t_248);
        v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_249;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2410 = heff_field(v_x31_243, 0);
      V v_a_2411 = heff_field(v_x31_243, 1);
      V v_b_2412 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2413;
      if (heff_strEq_c_lent(v_x_2410, v_v_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_2412);
        v_t_2413 = v_rest_244;
      } else {
        v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2412, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, v_t_2413});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2414 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ERecord = heff_take_reuse_n(v_x31_243, 1ULL, 2);
      V v_t_2416 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x3_242_24Cons, heff_dup(v_fs_2414)));
      V v_t_2417 = ({ V a_0 = v_v_240; V a_1 = v_t_2416; V a_2 = v_fs_2414; V r_ = (g_list_2eany_24s1874753421x1382718931(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_acc_241);
        heff_drop(v_rest_244);
        heff_drop(v_fs_2414);
        heff_drop_cell(v_ru_24x31_243_24ERecord, 2);
        heff_drop(v_t_2417);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_2417);
        V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x31_243_24ERecord, v_fs_2414, v_rest_244));
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2418;
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_EProj: {
      V v_x311_2419 = heff_dup(heff_field(v_x31_243, 0));
      switch (heff_tag_of(v_x311_2419)) {
      case TAG_EVar: {
        V v_y_2423 = heff_field(v_x311_2419, 0);
        heff_take_n(v_x311_2419, 1ULL, 1);
        switch (heff_tag_of(v_x31_243)) {
        case TAG_EProj: {
          V v_l_2425 = heff_field(v_x31_243, 1);
          V v_sh_2426 = heff_field(v_x31_243, 2);
          V v_t_2427 = heff_field(v_x31_243, 3);
          heff_take_n(v_x31_243, 14ULL, 4);
          if (!heff_strEq_c_lent(v_y_2423, v_v_240, 0)) {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop(v_y_2423);
            heff_drop(v_l_2425);
            heff_drop(v_sh_2426);
            heff_drop(v_t_2427);
            V t_0 = v_v_240;
            V t_1 = v_acc_241;
            V t_2 = v_rest_244;
            v_v_240 = t_0;
            v_acc_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_y_2423);
            switch (heff_tag_of(v_sh_2426)) {
            case TAG_Nil: {
              heff_drop(v_acc_241);
              heff_drop(v_rest_244);
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop(v_l_2425);
              heff_drop(v_t_2427);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_t_2430 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_l__sh__t, (V[]){v_l_2425, v_sh_2426, v_t_2427}), v_acc_241});
              V t_0 = v_v_240;
              V t_1 = v_t_2430;
              V t_2 = v_rest_244;
              v_v_240 = t_0;
              v_acc_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
            default: return ((HeffT2){{heff_nomatch(v_sh_2426)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
        }
      }
      default: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x311_2419);
        V v_t_2431 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2431;
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      }
    }
    case TAG_EMatch: {
      V v_s_2432 = heff_field(v_x31_243, 0);
      V v_arms_2433 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2433));
      V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efields_2ereadsW_24cpr_lam0, 2, 1, (V[]){heff_dup(v_v_240)}); V a_1 = v_rest_244; V a_2 = v_t_2434; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2432, v_t_2441});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_xs_2442 = heff_field(v_x31_243, 0);
      V v_a_2443 = heff_field(v_x31_243, 1);
      V v_b_2444 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2445 = ({ V a_0 = v_v_240; V a_1 = v_xs_2442; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_2442); r_; });
      V v_t_2446;
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_2444);
        heff_drop(v_t_2445);
        v_t_2446 = v_rest_244;
      } else {
        heff_drop(v_t_2445);
        v_t_2446 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2444, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2443, v_t_2446});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2447 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2447;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2efields_2ereadsW_24cpr_lam0(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_x_2436 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkArm: {
    V v_vs_2438 = heff_field(v_x_2436, 1);
    V v_b_2439 = heff_field(v_x_2436, 2);
    heff_take_n(v_x_2436, 6ULL, 3);
    V v_t_2440 = ({ V a_0 = v_v_240; V a_1 = v_vs_2438; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_v_240); heff_drop(v_vs_2438); r_; });
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_b_2439);
      heff_drop(v_t_2440);
      return v_acc_2435;
    } else {
      heff_drop(v_t_2440);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_b_2439, v_acc_2435});
    }
  }
  default: return heff_nomatch(v_x_2436);
  }
}
Clo g_heff_2ecompile_2efields_2elabelsOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2elabelsOnce_entry, 2, 0};

V g_heff_2ecompile_2efields_2elabelsOnce(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s52192015x78999897(heff_dup(v_r_242), v_acc_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_r_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_acc_240;
      V t_1 = v_rs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_r_242, v_acc_240});
      V t_1 = v_rs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2elabelsOnce_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2elabelsOnce(a[0], a[1]);
}
Clo g_heff_2ecompile_2efields_2enumberOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2enumberOf_entry, 2, 0};

V g_heff_2ecompile_2efields_2enumberOf(V v_e_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return v_acc_241;
  }
  case TAG_EGlobal: {
    return v_acc_241;
  }
  case TAG_ELam: {
    return v_acc_241;
  }
  case TAG_EApp: {
    return v_acc_241;
  }
  case TAG_ELet: {
    return v_acc_241;
  }
  case TAG_ERecord: {
    return v_acc_241;
  }
  case TAG_EProj: {
    V v_e1_2413 = heff_field(v_e_240, 0);
    V v_sh_2415 = heff_field(v_e_240, 2);
    V v_t_2416 = heff_field(v_e_240, 3);
    switch (heff_tag_of(v_e1_2413)) {
    case TAG_EVar: {
      V v_y_2417 = heff_field(v_e1_2413, 0);
      switch (heff_tag_of(v_t_2416)) {
      case TAG_FtFloat: {
        switch (heff_tag_of(v_sh_2415)) {
        case TAG_Nil: {
          return v_acc_241;
        }
        case TAG_Cons: {
          V v_x1_2420 = (g_heff_2ecompile_2efields_2eelemS(v_y_2417, v_acc_241));
          if (!(heff_dup(v_x1_2420) == NTAG(TAG_True))) {
            heff_drop(v_x1_2420);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_2417), v_acc_241});
          } else {
            heff_drop(v_x1_2420);
            return v_acc_241;
          }
        }
        default: return heff_nomatch(v_sh_2415);
        }
      }
      case TAG_FtFixed: {
        V v_w_2421 = heff_field(v_t_2416, 0);
        int64_t v_t_2422;
        switch (heff_tag_of(v_w_2421)) {
        case TAG_I8: {
          v_t_2422 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2422 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2422 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2422 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2422 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2422 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2422 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2422 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2422 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2421);
        }
        if ((v_t_2422 == ((int64_t)64ULL))) {
          switch (heff_tag_of(v_sh_2415)) {
          case TAG_Nil: {
            return v_acc_241;
          }
          case TAG_Cons: {
            V v_x1_2425 = (g_heff_2ecompile_2efields_2eelemS(v_y_2417, v_acc_241));
            if (!(heff_dup(v_x1_2425) == NTAG(TAG_True))) {
              heff_drop(v_x1_2425);
              return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_2417), v_acc_241});
            } else {
              heff_drop(v_x1_2425);
              return v_acc_241;
            }
          }
          default: return heff_nomatch(v_sh_2415);
          }
        } else {
          return v_acc_241;
        }
      }
      case TAG_FtOther: {
        return v_acc_241;
      }
      case TAG_FtAny: {
        return v_acc_241;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_EGlobal: {
      return v_acc_241;
    }
    case TAG_ELam: {
      return v_acc_241;
    }
    case TAG_EApp: {
      return v_acc_241;
    }
    case TAG_ELet: {
      return v_acc_241;
    }
    case TAG_ERecord: {
      return v_acc_241;
    }
    case TAG_EProj: {
      return v_acc_241;
    }
    case TAG_ETag: {
      return v_acc_241;
    }
    case TAG_EMatch: {
      return v_acc_241;
    }
    case TAG_EPrim: {
      return v_acc_241;
    }
    case TAG_EPrimCall: {
      return v_acc_241;
    }
    case TAG_ECall: {
      return v_acc_241;
    }
    case TAG_EInt: {
      return v_acc_241;
    }
    case TAG_EFloat: {
      return v_acc_241;
    }
    case TAG_EStr: {
      return v_acc_241;
    }
    case TAG_EBytes: {
      return v_acc_241;
    }
    case TAG_EFixed: {
      return v_acc_241;
    }
    case TAG_EFloat32: {
      return v_acc_241;
    }
    case TAG_EAbandon: {
      return v_acc_241;
    }
    case TAG_EBool: {
      return v_acc_241;
    }
    case TAG_ESet: {
      return v_acc_241;
    }
    case TAG_EValues: {
      return v_acc_241;
    }
    case TAG_EFix: {
      return v_acc_241;
    }
    default: return heff_nomatch(v_e1_2413);
    }
  }
  case TAG_ETag: {
    return v_acc_241;
  }
  case TAG_EMatch: {
    return v_acc_241;
  }
  case TAG_EPrim: {
    return v_acc_241;
  }
  case TAG_EPrimCall: {
    return v_acc_241;
  }
  case TAG_ECall: {
    return v_acc_241;
  }
  case TAG_EInt: {
    return v_acc_241;
  }
  case TAG_EFloat: {
    return v_acc_241;
  }
  case TAG_EStr: {
    return v_acc_241;
  }
  case TAG_EBytes: {
    return v_acc_241;
  }
  case TAG_EFixed: {
    return v_acc_241;
  }
  case TAG_EFloat32: {
    return v_acc_241;
  }
  case TAG_EAbandon: {
    return v_acc_241;
  }
  case TAG_EBool: {
    return v_acc_241;
  }
  case TAG_ESet: {
    return v_acc_241;
  }
  case TAG_EValues: {
    return v_acc_241;
  }
  case TAG_EFix: {
    return v_acc_241;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2efields_2enumberOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efields_2enumberOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efields_2enumbersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2enumbersW_entry, 2, 0};

V g_heff_2ecompile_2efields_2enumbersW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2efields_2enumberOf(v_e_242, v_acc_240));
    V v_t_245 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, v_rest_243));
    V t_0 = v_t_244;
    V t_1 = v_t_245;
    v_acc_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2enumbersW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2enumbersW(a[0], a[1]);
}
V g_heff_2ecompile_2efields_2eusesW_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2eusesW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efields_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eusesW_entry, 3, 0};

V g_heff_2ecompile_2efields_2eusesW(V v_v_240, V v_u_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_u_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_247;
      if (heff_strEq_c_lent(v_y_245, v_v_240, 1)) {
        V v_t_246 = heff_intAdd(heff_take_field(v_u_241, 2), MK_INT(1LL));
        v_t_247 = ({ V rv_2 = v_t_246; V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_u_241, 3ULL, 4, shape_reads__late__holds__now, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_247 = v_u_241;
      }
      V t_0 = v_v_240;
      V t_1 = v_t_247;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_u_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x31_243, 0);
      V v_b_249 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2410 = ({ V a_0 = v_v_240; V a_1 = v_xs_248; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_248); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_249);
        heff_drop(v_t_2410);
        V t_0 = v_v_240;
        V t_1 = v_u_241;
        V t_2 = v_rest_244;
        v_v_240 = t_0;
        v_u_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_rec_n(4, shape_reads__late__holds__now, (V[]){heff_take_field(v_u_241, 0), heff_take_field(v_u_241, 1), heff_dup(heff_rfield(v_u_241, 2)), NTAG(TAG_True)});
        V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_249, NTAG(TAG_Nil)});
        V v_r_2413 = (g_heff_2ecompile_2efields_2eusesW(v_v_240, v_t_2411, v_t_2412));
        V v_b_2414 = heff_bool(((heff_dup(heff_rfield(v_u_241, 3)) == NTAG(TAG_True)) || heff_intLt_c(heff_dup(heff_rfield(v_u_241, 2)), heff_dup(heff_rfield(v_r_2413, 2)))));
        heff_drop_rec(v_u_241, 4);
        V v_t_2415 = ({ V rv_3 = v_b_2414; V rr_ = heff_rec_reuse_nf(v_r_2413, 7ULL, 4, shape_reads__late__holds__now, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        V t_0 = v_v_240;
        V t_1 = v_t_2415;
        V t_2 = v_rest_244;
        v_v_240 = t_0;
        v_u_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_ELet: {
      V v_x_2416 = heff_field(v_x31_243, 0);
      V v_a_2417 = heff_field(v_x31_243, 1);
      V v_b_2418 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2419;
      if (heff_strEq_c_lent(v_x_2416, v_v_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_2418);
        v_t_2419 = v_rest_244;
      } else {
        v_t_2419 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2418, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_u_241;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2417, v_t_2419});
      v_v_240 = t_0;
      v_u_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2420 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ERecord = heff_take_reuse_n(v_x31_243, 1ULL, 2);
      V v_ls_2422 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x3_242_24Cons, heff_dup(v_fs_2420)));
      V v_t_2423 = (g_list_2eany_24s1874753421x1382718931(v_v_240, v_ls_2422, v_fs_2420));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_t_2423);
        V v_t_2426 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efields_2eusesW_lam0, 1, 2, (V[]){heff_dup(v_v_240), v_ls_2422}), v_fs_2420));
        V v_t_2427 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x31_243_24ERecord, v_t_2426));
        V v_u_2428 = (g_heff_2ecompile_2efields_2eusesW(v_v_240, v_u_241, v_t_2427));
        V v_t_2429 = heff_intAdd(heff_take_field(v_u_2428, 2), MK_INT(1LL));
        V v_t_2430 = ({ V rv_2 = v_t_2429; V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_u_2428, 3ULL, 4, shape_reads__late__holds__now, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
        V t_0 = v_v_240;
        V t_1 = v_t_2430;
        V t_2 = v_rest_244;
        v_v_240 = t_0;
        v_u_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_ls_2422);
        heff_drop(v_t_2423);
        V v_t_2431 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x31_243_24ERecord, v_fs_2420, v_rest_244));
        V t_0 = v_v_240;
        V t_1 = v_u_241;
        V t_2 = v_t_2431;
        v_v_240 = t_0;
        v_u_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_EProj: {
      V v_x311_2432 = heff_dup(heff_field(v_x31_243, 0));
      switch (heff_tag_of(v_x311_2432)) {
      case TAG_EVar: {
        V v_y_2436 = heff_field(v_x311_2432, 0);
        heff_take_n(v_x311_2432, 1ULL, 1);
        switch (heff_tag_of(v_x31_243)) {
        case TAG_EProj: {
          V v_l_2438 = heff_field(v_x31_243, 1);
          V v_sh_2439 = heff_field(v_x31_243, 2);
          V v_t_2440 = heff_field(v_x31_243, 3);
          heff_take_n(v_x31_243, 14ULL, 4);
          if (!heff_strEq_c_lent(v_y_2436, v_v_240, 0)) {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop(v_y_2436);
            heff_drop(v_l_2438);
            heff_drop(v_sh_2439);
            heff_drop(v_t_2440);
            V t_0 = v_v_240;
            V t_1 = v_u_241;
            V t_2 = v_rest_244;
            v_v_240 = t_0;
            v_u_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_y_2436);
            switch (heff_tag_of(v_sh_2439)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop(v_l_2438);
              heff_drop(v_t_2440);
              V v_t_2441 = heff_intAdd(heff_take_field(v_u_241, 2), MK_INT(1LL));
              V v_t_2442 = ({ V rv_2 = v_t_2441; V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_u_241, 3ULL, 4, shape_reads__late__holds__now, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
              V t_0 = v_v_240;
              V t_1 = v_t_2442;
              V t_2 = v_rest_244;
              v_v_240 = t_0;
              v_u_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
            case TAG_Cons: {
              V v_t_2445 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_l__sh__t, (V[]){heff_dup(v_l_2438), heff_dup(v_sh_2439), heff_dup(v_t_2440)}), heff_dup(heff_rfield(v_u_241, 0))});
              V v_t_2446 = heff_dup(heff_rfield(v_u_241, 3));
              V v_t_2447;
              if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
                heff_drop(v_t_2446);
                v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_l__sh__t, (V[]){v_l_2438, v_sh_2439, v_t_2440}), heff_dup(heff_rfield(v_u_241, 1))});
              } else {
                heff_drop(v_l_2438);
                heff_drop_tag(v_sh_2439, 2);
                heff_drop(v_t_2440);
                heff_drop(v_t_2446);
                v_t_2447 = heff_dup(heff_rfield(v_u_241, 1));
              }
              V v_t_2448 = ({ V rv_0 = v_t_2445; V rv_1 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_u_241, 12ULL, 4, shape_reads__late__holds__now, 240u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
              V t_0 = v_v_240;
              V t_1 = v_t_2448;
              V t_2 = v_rest_244;
              v_v_240 = t_0;
              v_u_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
            default: return heff_nomatch(v_sh_2439);
            }
          }
        }
        default: return heff_nomatch(v_x31_243);
        }
      }
      default: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x311_2432);
        V v_t_2449 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
        V t_0 = v_v_240;
        V t_1 = v_u_241;
        V t_2 = v_t_2449;
        v_v_240 = t_0;
        v_u_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      }
    }
    case TAG_EMatch: {
      V v_s_2450 = heff_field(v_x31_243, 0);
      V v_arms_2451 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2452 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2450, NTAG(TAG_Nil)});
      V v_at_2453 = (g_heff_2ecompile_2efields_2eusesW(v_v_240, v_u_241, v_t_2452));
      V v_t_2454 = heff_rec_n(4, shape_reads__late__holds__now, (V[]){heff_dup(heff_rfield(v_at_2453, 0)), heff_dup(heff_rfield(v_at_2453, 1)), heff_dup(heff_rfield(v_at_2453, 2)), NTAG(TAG_False)});
      V v_after_2466 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efields_2eusesW_lam1, 2, 2, (V[]){v_at_2453, heff_dup(v_v_240)}); V a_1 = v_t_2454; V a_2 = v_arms_2451; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2451); r_; });
      V t_0 = v_v_240;
      V t_1 = v_after_2466;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_u_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_xs_2467 = heff_field(v_x31_243, 0);
      V v_a_2468 = heff_field(v_x31_243, 1);
      V v_b_2469 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2470 = ({ V a_0 = v_v_240; V a_1 = v_xs_2467; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_2467); r_; });
      V v_t_2471;
      if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_2469);
        heff_drop(v_t_2470);
        v_t_2471 = v_rest_244;
      } else {
        heff_drop(v_t_2470);
        v_t_2471 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2469, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_u_241;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2468, v_t_2471});
      v_v_240 = t_0;
      v_u_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2472 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_u_241;
      V t_2 = v_t_2472;
      v_v_240 = t_0;
      v_u_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efields_2eusesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efields_2eusesW(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efields_2eusesW_lam0(V self, V *args) {
  V v_f_2424 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_ls_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2425 = ({ V a_0 = v_v_240; V a_1 = v_ls_2422; V a_2 = v_f_2424; V r_ = (g_heff_2ecompile_2efields_2ekeptOf(a_0, a_1, a_2)); heff_drop(v_v_240); heff_drop(v_ls_2422); heff_drop(v_f_2424); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2425) == NTAG(TAG_True)));
  heff_drop(v_x1_2425);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efields_2eusesW_lam1(V self, V *args) {
  V v_acc_2455 = args[0];
  V v_arm_2456 = args[1];
  V v_at_2453 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = ({ V rv_0 = heff_take_field(v_acc_2455, 0); V rv_1 = heff_take_field(v_acc_2455, 1); V rv_2 = heff_take_field(v_acc_2455, 2); V rr_ = heff_rec_reuse_nf(v_at_2453, 8ULL, 4, shape_reads__late__holds__now, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2462;
  switch (heff_tag_of(v_arm_2456)) {
  case TAG_MkArm: {
    V v_vs_2459 = heff_field(v_arm_2456, 1);
    V v_b_2460 = heff_field(v_arm_2456, 2);
    heff_take_n(v_arm_2456, 6ULL, 3);
    V v_t_2461 = ({ V a_0 = v_v_240; V a_1 = v_vs_2459; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_vs_2459); r_; });
    if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
      heff_drop(v_b_2460);
      heff_drop(v_t_2461);
      v_t_2462 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2461);
      v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2460, NTAG(TAG_Nil)});
    }
    break;
  }
  default: heff_nomatch(v_arm_2456);
  }
  V v_r_2463 = ({ V a_0 = v_v_240; V a_1 = v_t_2457; V a_2 = v_t_2462; V r_ = (g_heff_2ecompile_2efields_2eusesW(a_0, a_1, a_2)); heff_drop(v_v_240); r_; });
  V v_t_2464 = heff_get_n(v_acc_2455, 3, 4);
  V v_b_2465;
  if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
    heff_drop(v_t_2464);
    v_b_2465 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2464);
    v_b_2465 = heff_dup(heff_rfield(v_r_2463, 3));
  }
  return ({ V rv_3 = v_b_2465; V rr_ = heff_rec_reuse_nf(v_r_2463, 7ULL, 4, shape_reads__late__holds__now, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}

HeffT2 g_heff_2ecompile_2efields_2eboundAt_24cpr(V v_x1_240, V v_l_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_bs_243 = heff_field(v_x1_240, 1);
    V v_r_244 = heff_dup(heff_rfield(v_b_242, 0));
    V v_x_245 = heff_dup(heff_rfield(v_b_242, 1));
    if (heff_strEq_c(heff_get_n(v_r_244, 0, 3), heff_dup(v_l_241))) {
      V v_f_246 = v_x_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_x_245);
      V t_0 = v_bs_243;
      V t_1 = v_l_241;
      v_x1_240 = t_0;
      v_l_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2efields_2ereadIn_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ereadIn_lam1(V self, V *args);
V g_heff_2ecompile_2efields_2ereadIn_lam2(V self, V *args);
Clo g_heff_2ecompile_2efields_2ereadIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadIn_entry, 3, 0};

V g_heff_2ecompile_2efields_2ereadIn(V v_v_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ERecord: {
    V v_fs_243 = heff_field(v_e_242, 0);
    V v_ts_244 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_ls_245 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_243)));
    V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_lam0, 1, 3, (V[]){heff_dup(v_v_240), v_ls_245, heff_dup(v_bs_241)}), v_fs_243));
    return heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2415, v_ts_244});
  }
  case TAG_EProj: {
    V v_e1_2416 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_2416)) {
    case TAG_EVar: {
      V v_y_2420 = heff_field(v_e1_2416, 0);
      V v_ru_24e1_2416_24EVar = heff_take_reuse_n(v_e1_2416, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_EProj: {
        V v_l_2422 = heff_field(v_e_242, 1);
        V v_sh_2423 = heff_field(v_e_242, 2);
        V v_t_2424 = heff_field(v_e_242, 3);
        V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 14ULL, 4);
        if (heff_strEq_c_lent(v_y_2420, v_v_240, 0)) {
          HeffT2 v_t_2425 = (g_heff_2ecompile_2efields_2eboundAt_24cpr(v_bs_241, v_l_2422));
          {
            V v_field_2427 = v_t_2425.f[1];
            int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
            if ((v_tag_2426 == ((int64_t)0ULL))) {
              heff_drop(v_y_2420);
              heff_drop(v_l_2422);
              heff_drop(v_sh_2423);
              heff_drop(v_t_2424);
              heff_drop_cell(v_ru_24e_242_24EProj, 4);
              V v_x_2428 = v_field_2427;
              return heff_tag_at_n(v_ru_24e1_2416_24EVar, TAG_EVar, 1, (V[]){v_x_2428});
            } else {
              heff_drop(v_field_2427);
              return heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24e1_2416_24EVar, TAG_EVar, 1, (V[]){v_y_2420}), v_l_2422, v_sh_2423, v_t_2424});
            }
          }
        } else {
          return heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24e1_2416_24EVar, TAG_EVar, 1, (V[]){v_y_2420}), v_l_2422, v_sh_2423, v_t_2424});
        }
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    default: {
      heff_drop(v_e1_2416);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_lam1, 2, 2, (V[]){heff_dup(v_v_240), heff_dup(v_bs_241)}), v_e_242));
    }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_lam2, 2, 2, (V[]){heff_dup(v_v_240), heff_dup(v_bs_241)}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2efields_2ereadIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efields_2ereadIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efields_2ereadIn_lam0(V self, V *args) {
  V v_f_246 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_ls_245 = heff_env(self)[1];
  V v_bs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = ({ V a_0 = v_v_240; V a_1 = v_ls_245; V a_2 = v_f_246; V r_ = (g_heff_2ecompile_2efields_2ekeptOf(a_0, a_1, a_2)); heff_drop(v_ls_245); r_; });
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    heff_drop(v_t_247);
    return v_f_246;
  } else {
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_f_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_dup(heff_field(v_f_246, 0));
      v_t_2410 = v_x_248;
      break;
    }
    default: heff_nomatch(v_f_246);
    }
    V v_t_2413;
    switch (heff_tag_of(v_f_246)) {
    case TAG_MkPair: {
      V v_y_2412 = heff_field(v_f_246, 1);
      heff_take_n(v_f_246, 2ULL, 2);
      v_t_2413 = v_y_2412;
      break;
    }
    default: heff_nomatch(v_f_246);
    }
    V v_t_2414 = ({ V a_0 = v_v_240; V a_1 = v_bs_241; V a_2 = v_t_2413; V r_ = (g_heff_2ecompile_2efields_2ereadIn(a_0, a_1, a_2)); heff_drop(v_v_240); heff_drop(v_bs_241); r_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2414});
  }
}
V g_heff_2ecompile_2efields_2ereadIn_lam1(V self, V *args) {
  V v_xs_2429 = args[0];
  V v_p_2430 = args[1];
  V v_v_240 = heff_env(self)[0];
  V v_bs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = ({ V a_0 = v_v_240; V a_1 = v_xs_2429; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_2429); r_; });
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    heff_drop(v_t_2431);
    return v_p_2430;
  } else {
    heff_drop(v_t_2431);
    return ({ V a_0 = v_v_240; V a_1 = v_bs_241; V a_2 = v_p_2430; V r_ = (g_heff_2ecompile_2efields_2ereadIn(a_0, a_1, a_2)); heff_drop(v_v_240); heff_drop(v_bs_241); r_; });
  }
}
V g_heff_2ecompile_2efields_2ereadIn_lam2(V self, V *args) {
  V v_xs_2432 = args[0];
  V v_p_2433 = args[1];
  V v_v_240 = heff_env(self)[0];
  V v_bs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = ({ V a_0 = v_v_240; V a_1 = v_xs_2432; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_2432); r_; });
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    heff_drop(v_t_2434);
    return v_p_2433;
  } else {
    heff_drop(v_t_2434);
    return ({ V a_0 = v_v_240; V a_1 = v_bs_241; V a_2 = v_p_2433; V r_ = (g_heff_2ecompile_2efields_2ereadIn(a_0, a_1, a_2)); heff_drop(v_v_240); heff_drop(v_bs_241); r_; });
  }
}
Clo g_heff_2ecompile_2efields_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eletsOf_entry, 3, 0};

V g_heff_2ecompile_2efields_2eletsOf(V v_v_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_v_240);
    return v_e_242;
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_bs_244 = heff_field(v_x2_241, 1);
    V v_x_245 = heff_dup(heff_rfield(v_b_243, 1));
    V v_r_246 = heff_dup(heff_rfield(v_b_243, 0));
    V v_t_247 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_v_240)}), heff_take_field(v_r_246, 0), heff_take_field(v_r_246, 1), heff_get_n(v_r_246, 2, 3)});
    V v_cell_248 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_245, v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2efields_2eletsOf_24dps(v_v_240, v_bs_244, v_e_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efields_2eletsOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efields_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eletsOf_24dps_entry, 4, 0};

V g_heff_2ecompile_2efields_2eletsOf_24dps(V v_v_240, V v_x2_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_v_240);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_Cons: {
    V v_b_244 = heff_field(v_x2_241, 0);
    V v_bs_245 = heff_field(v_x2_241, 1);
    V v_x_246 = heff_dup(heff_rfield(v_b_244, 1));
    V v_r_247 = heff_dup(heff_rfield(v_b_244, 0));
    V v_t_248 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_v_240)}), heff_take_field(v_r_247, 0), heff_take_field(v_r_247, 1), heff_get_n(v_r_247, 2, 3)});
    V v_cell_249 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_246, v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_v_240;
    V t_1 = v_bs_245;
    V t_2 = v_e_242;
    V t_3 = v_cell_249;
    v_v_240 = t_0;
    v_x2_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efields_2eletsOf_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efields_2eplaced_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2eplaced_lam2(V self, V *args);
V g_heff_2ecompile_2efields_2eplaced_lam1(V self, V *args);
Clo g_heff_2ecompile_2efields_2eplaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eplaced_entry, 3, 0};

V g_heff_2ecompile_2efields_2eplaced(V v_v_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EMatch: {
    V v_s_243 = heff_field(v_e_242, 0);
    V v_arms_244 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_s_243), NTAG(TAG_Nil)});
    V v_t_246 = (g_heff_2ecompile_2eir_2ecountW(v_v_240, MK_INT(0LL), v_t_245));
    if (heff_intEq_c(v_t_246, MK_INT(0LL))) {
      V v_x1_2410 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efields_2eplaced_lam0, 1, 1, (V[]){heff_dup(v_s_243)}), heff_dup(v_bs_241)));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_Nil: {
        V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efields_2eplaced_lam1, 1, 2, (V[]){v_bs_241, v_v_240}), v_arms_244));
        return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_243, v_t_2420});
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2410, 0ULL, 2);
        return ({ V a_0 = v_v_240; V a_1 = v_bs_241; V a_2 = heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_243, v_arms_244}); V r_ = (g_heff_2ecompile_2efields_2eletsOf(a_0, a_1, a_2)); heff_drop(v_bs_241); r_; });
      }
      default: return heff_nomatch(v_x1_2410);
      }
    } else {
      return ({ V a_0 = v_v_240; V a_1 = v_bs_241; V a_2 = heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_243, v_arms_244}); V r_ = (g_heff_2ecompile_2efields_2eletsOf(a_0, a_1, a_2)); heff_drop(v_bs_241); r_; });
    }
  }
  default: {
    return ({ V a_0 = v_v_240; V a_1 = v_bs_241; V a_2 = v_e_242; V r_ = (g_heff_2ecompile_2efields_2eletsOf(a_0, a_1, a_2)); heff_drop(v_bs_241); r_; });
  }
  }
}
V g_heff_2ecompile_2efields_2eplaced_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2eplaced(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efields_2eplaced_lam0(V self, V *args) {
  V v_b_247 = args[0];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_243, NTAG(TAG_Nil)});
  V v_x_249 = ({ V b_0 = heff_get_n(v_b_247, 1, 2); V a_1 = MK_INT(0LL); V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eir_2ecountW(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_249, 1));
  heff_drop(v_x_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efields_2eplaced_lam2(V self, V *args) {
  V v_b_2415 = args[0];
  V v_b_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, NTAG(TAG_Nil)});
  V v_x_2417 = ({ V b_0 = heff_get_n(v_b_2415, 1, 2); V a_1 = MK_INT(0LL); V a_2 = v_t_2416; V r_ = (g_heff_2ecompile_2eir_2ecountW(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2417, 1));
  heff_drop(v_x_2417);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efields_2eplaced_lam1(V self, V *args) {
  V v_x2_2411 = args[0];
  V v_bs_241 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_x2_2411, 0);
    V v_vs_2413 = heff_field(v_x2_2411, 1);
    V v_b_2414 = heff_field(v_x2_2411, 2);
    V v_ru_24x2_2411_24MkArm = heff_take_reuse_n(v_x2_2411, 7ULL, 3);
    V v_t_2418 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efields_2eplaced_lam2, 1, 1, (V[]){heff_dup(v_b_2414)}), v_bs_241));
    V v_t_2419 = (g_heff_2ecompile_2efields_2eplaced(v_v_240, v_t_2418, v_b_2414));
    return heff_tag_at_n(v_ru_24x2_2411_24MkArm, TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_t_2419});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2efields_2ereadAt_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ereadAt_lam1(V self, V *args);
V g_heff_2ecompile_2efields_2ereadAt_lam2(V self, V *args);
Clo g_heff_2ecompile_2efields_2ereadAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadAt_entry, 2, 0};

V g_heff_2ecompile_2efields_2ereadAt(V v_b_240, V v_v_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_heff_2ecompile_2efields_2ereadsW_24cpr(v_v_241, NTAG(TAG_Nil), v_t_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_rs_246 = v_field_245;
      V v_rs_247 = v_rs_246;
      V v_once_2413;
      switch (heff_tag_of(v_rs_247)) {
      case TAG_Nil: {
        v_once_2413 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_r_248 = heff_field(v_rs_247, 0);
        V v_rs_249 = heff_field(v_rs_247, 1);
        V v_ru_24rs_247_24Cons = heff_take_reuse_n(v_rs_247, 3ULL, 2);
        V v_t_2411 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2efields_2ereadAt_lam0, 1, 1, (V[]){heff_dup(v_r_248)}), v_rs_249));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24rs_247_24Cons, TAG_Cons, 2, (V[]){v_r_248, v_rs_249})));
          v_once_2413 = (g_heff_2ecompile_2efields_2elabelsOnce(NTAG(TAG_Nil), v_t_2412));
        } else {
          heff_drop_rec(v_r_248, 3);
          heff_drop(v_rs_249);
          heff_drop_cell(v_ru_24rs_247_24Cons, 2);
          heff_drop(v_t_2411);
          v_once_2413 = NTAG(TAG_Nil);
        }
        break;
      }
      default: heff_nomatch(v_rs_247);
      }
      V v_x_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_once_2413));
      V v_rs_2416;
      if (heff_intLe_c(MK_INT(2LL), v_x_2414)) {
        V v_t_2415 = (g_list_2eany_24s1873156379x541659222(MK_INT(8LL), MK_INT(16LL), MK_INT(32LL), MK_INT(64LL), MK_INT(8LL), MK_INT(16LL), MK_INT(32LL), MK_INT(64LL), MK_INT(32LL), MK_INT(64LL), v_once_2413));
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          v_rs_2416 = v_once_2413;
        } else {
          heff_drop(v_once_2413);
          heff_drop(v_t_2415);
          v_rs_2416 = NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_once_2413);
        v_rs_2416 = NTAG(TAG_Nil);
      }
      return heff_clo_n(g_heff_2ecompile_2efields_2ereadAt_lam1, 1, 3, (V[]){v_rs_2416, v_b_240, v_v_241});
    } else {
      heff_drop(v_v_241);
      heff_drop(v_field_245);
      return heff_clo_n(g_heff_2ecompile_2efields_2ereadAt_lam2, 1, 1, (V[]){v_b_240});
    }
  }
}
V g_heff_2ecompile_2efields_2ereadAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2ereadAt(a[0], a[1]);
}
V g_heff_2ecompile_2efields_2ereadAt_lam0(V self, V *args) {
  V v_q_2410 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_q_2410, 1, 3); V b_1 = heff_get_n(v_r_248, 1, 3); V r_ = (g_heff_2ecompile_2efields_2esameLabels(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2efields_2ereadAt_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_rs_2416 = heff_env(self)[0];
  V v_b_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_rs_2416)) {
  case TAG_Nil: {
    heff_drop(v_v_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_p_2417});
  }
  case TAG_Cons: {
    HeffT2 v_t_2420 = (g_prelude_2etraverse_24s1801023533x118610014_24cpr(v_rs_2416, v_p_2417));
    {
      V v_field_2421 = v_t_2420.f[0];
      V v_field_2422 = v_t_2420.f[1];
      V v_x_2423 = v_field_2421;
      V v_n_2424 = v_field_2422;
      V v_t_2425 = (g_heff_2ecompile_2efields_2ereadIn(v_v_241, v_x_2423, v_b_240));
      V v_x_2426 = ({ V a_0 = v_v_241; V a_1 = v_x_2423; V a_2 = v_t_2425; V r_ = (g_heff_2ecompile_2efields_2eletsOf(a_0, a_1, a_2)); heff_drop(v_x_2423); r_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_n_2424});
    }
  }
  default: return heff_nomatch(v_rs_2416);
  }
}
V g_heff_2ecompile_2efields_2ereadAt_lam2(V self, V *args) {
  V v_n_2427 = args[0];
  V v_b_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_n_2427});
}
Clo g_heff_2ecompile_2efields_2ereadsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadsAt_entry, 3, 0};

V g_heff_2ecompile_2efields_2ereadsAt(V v_x1_240, V v_b_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_241, v_z_242});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_m_245 = (g_heff_2ecompile_2efields_2ereadAt(v_b_241, heff_dup(v_x_243)));
    V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_n_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V t_0 = v_xs_244;
      V t_1 = v_x_247;
      V t_2 = v_n_248;
      v_x1_240 = t_0;
      v_b_241 = t_1;
      v_z_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efields_2ereadsAt(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efields_2elatesAt_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2elatesAt_lam1(V self, V *args);
V g_heff_2ecompile_2efields_2elatesAt_lam2(V self, V *args);
V g_heff_2ecompile_2efields_2elatesAt_lam3(V self, V *args);
Clo g_heff_2ecompile_2efields_2elatesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2elatesAt_entry, 4, 0};

V g_heff_2ecompile_2efields_2elatesAt(V v_ns_240, V v_x2_241, V v_b_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ns_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_242, v_z_243});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_ns_246 = heff_dup(v_ns_240);
    V v_b_247 = v_b_242;
    V v_v_248 = v_x_244;
    V v_t_249 = ({ V a_0 = v_v_248; V a_1 = v_ns_246; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_ns_246); r_; });
    V v_m_2437;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = heff_rec_n(4, shape_reads__late__holds__now, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_False)});
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
      V v_u_2412 = (g_heff_2ecompile_2efields_2eusesW(v_v_248, v_t_2410, v_t_2411));
      V v_late_2413 = heff_take_field(v_u_2412, 1);
      V v_reads_2414 = heff_get_n(v_u_2412, 0, 4);
      V v_rs_2425;
      switch (heff_tag_of(v_late_2413)) {
      case TAG_Nil: {
        heff_drop(v_reads_2414);
        v_rs_2425 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_t_2422;
        switch (heff_tag_of(v_reads_2414)) {
        case TAG_Nil: {
          v_t_2422 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_r_2417 = heff_dup(heff_field(v_reads_2414, 0));
          V v_rs_2418 = heff_dup(heff_field(v_reads_2414, 1));
          V v_t_2420 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2efields_2elatesAt_lam0, 1, 1, (V[]){heff_dup(v_r_2417)}), v_rs_2418));
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop(v_t_2420);
            V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_r_2417, v_rs_2418})));
            v_t_2422 = (g_heff_2ecompile_2efields_2elabelsOnce(NTAG(TAG_Nil), v_t_2421));
          } else {
            heff_drop_rec(v_r_2417, 3);
            heff_drop(v_rs_2418);
            heff_drop(v_t_2420);
            v_t_2422 = NTAG(TAG_Nil);
          }
          break;
        }
        default: heff_nomatch(v_reads_2414);
        }
        v_rs_2425 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efields_2elatesAt_lam1, 1, 2, (V[]){v_reads_2414, v_late_2413}), v_t_2422));
        break;
      }
      default: heff_nomatch(v_late_2413);
      }
      v_m_2437 = heff_clo_n(g_heff_2ecompile_2efields_2elatesAt_lam2, 1, 3, (V[]){v_rs_2425, v_b_247, v_v_248});
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_v_248);
      heff_drop(v_t_249);
      v_m_2437 = heff_clo_n(g_heff_2ecompile_2efields_2elatesAt_lam3, 1, 1, (V[]){v_b_247});
    }
    V v_x2_2438 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_z_243}));
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_MkPair: {
      V v_x_2439 = heff_field(v_x2_2438, 0);
      V v_n_2440 = heff_field(v_x2_2438, 1);
      heff_take_n(v_x2_2438, 3ULL, 2);
      V t_0 = v_ns_240;
      V t_1 = v_xs_245;
      V t_2 = v_x_2439;
      V t_3 = v_n_2440;
      v_ns_240 = t_0;
      v_x2_241 = t_1;
      v_b_242 = t_2;
      v_z_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x2_2438);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2elatesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2elatesAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efields_2elatesAt_lam0(V self, V *args) {
  V v_q_2419 = args[0];
  V v_r_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_q_2419, 1, 3); V b_1 = heff_get_n(v_r_2417, 1, 3); V r_ = (g_heff_2ecompile_2efields_2esameLabels(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2efields_2elatesAt_lam1(V self, V *args) {
  V v_q_2423 = args[0];
  V v_reads_2414 = heff_env(self)[0];
  V v_late_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = ({ V a_0 = heff_dup(v_q_2423); V a_1 = MK_INT(8LL); V a_2 = MK_INT(16LL); V a_3 = MK_INT(32LL); V a_4 = MK_INT(64LL); V a_5 = MK_INT(8LL); V a_6 = MK_INT(16LL); V a_7 = MK_INT(32LL); V a_8 = MK_INT(64LL); V a_9 = MK_INT(32LL); V a_10 = MK_INT(64LL); V a_11 = v_reads_2414; V r_ = (g_list_2eall_24s2116272255x866448265(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_reads_2414); r_; });
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_t_2424);
    return ({ V a_0 = v_q_2423; V a_1 = v_late_2413; V r_ = (g_list_2eany_24s52192015x78999897(a_0, a_1)); heff_drop_tag(v_late_2413, 2); r_; });
  } else {
    heff_drop(v_q_2423);
    heff_drop_tag(v_late_2413, 2);
    heff_drop(v_t_2424);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efields_2elatesAt_lam2(V self, V *args) {
  V v_p_2426 = args[0];
  V v_rs_2425 = heff_env(self)[0];
  V v_b_247 = heff_env(self)[1];
  V v_v_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_rs_2425)) {
  case TAG_Nil: {
    heff_drop(v_v_248);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_247, v_p_2426});
  }
  case TAG_Cons: {
    HeffT2 v_t_2429 = (g_prelude_2etraverse_24s1801023533x118610014_24cpr(v_rs_2425, v_p_2426));
    {
      V v_field_2430 = v_t_2429.f[0];
      V v_field_2431 = v_t_2429.f[1];
      V v_x_2432 = v_field_2430;
      V v_n_2433 = v_field_2431;
      V v_t_2434 = (g_heff_2ecompile_2efields_2ereadIn(v_v_248, v_x_2432, v_b_247));
      V v_x_2435 = (g_heff_2ecompile_2efields_2eplaced(v_v_248, v_x_2432, v_t_2434));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2435, v_n_2433});
    }
  }
  default: return heff_nomatch(v_rs_2425);
  }
}
V g_heff_2ecompile_2efields_2elatesAt_lam3(V self, V *args) {
  V v_n_2436 = args[0];
  V v_b_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_247, v_n_2436});
}
V g_heff_2ecompile_2efields_2egoLate_lam1(V self, V *args);
V g_heff_2ecompile_2efields_2egoLate_lam0(V self, V *args);
Clo g_heff_2ecompile_2efields_2egoLate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2egoLate_entry, 2, 0};

V g_heff_2ecompile_2efields_2egoLate(V v_ns_240, V v_e_241) {
top: ;
  HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2efields_2egoLate_lam0, 2, 1, (V[]){v_ns_240}), v_e_241);
}
V g_heff_2ecompile_2efields_2egoLate_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2egoLate(a[0], a[1]);
}
V g_heff_2ecompile_2efields_2egoLate_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_ns_240 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    return (g_heff_2ecompile_2efields_2elatesAt(v_ns_240, v_xs_242, v_x_247, v_n_248));
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2efields_2egoLate_lam0(V self, V *args) {
  V v_xs_242 = args[0];
  V v_p_243 = args[1];
  V v_ns_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_244 = (g_heff_2ecompile_2efields_2egoLate(heff_dup(v_ns_240), v_p_243));
  return heff_clo_n(g_heff_2ecompile_2efields_2egoLate_lam1, 1, 3, (V[]){v_m_244, v_ns_240, v_xs_242});
}