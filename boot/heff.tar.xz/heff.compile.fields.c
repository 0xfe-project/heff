// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_l 326
#define LBL_r 332
#define LBL_sh 10428
#define LBL_t 334
#define LBL_x 338
static uint32_t shape_l__sh__t[] = {LBL_l, LBL_sh, LBL_t};
HeffT2 g_heff_2ecompile_2efields_2eboundAt_24cpr(V, V);
V g_heff_2ecompile_2efields_2eelemS(V, V);
V g_heff_2ecompile_2efields_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eelemS_clo;
V g_heff_2ecompile_2efields_2ego(V);
V g_heff_2ecompile_2efields_2ego_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ego_clo;
V g_heff_2ecompile_2efields_2elabelsOnce(V, V);
V g_heff_2ecompile_2efields_2elabelsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2elabelsOnce_clo;
V g_heff_2ecompile_2efields_2eletsOf(V, V, V);
V g_heff_2ecompile_2efields_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eletsOf_clo;
V g_heff_2ecompile_2efields_2eletsOf_24dps(V, V, V, V);
V g_heff_2ecompile_2efields_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2eletsOf_24dps_clo;
V g_heff_2ecompile_2efields_2ereadAt(V, V);
V g_heff_2ecompile_2efields_2ereadAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadAt_clo;
V g_heff_2ecompile_2efields_2ereadIn(V, V, V);
V g_heff_2ecompile_2efields_2ereadIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadIn_clo;
V g_heff_2ecompile_2efields_2ereadIn_24dps(V, V, V, V);
V g_heff_2ecompile_2efields_2ereadIn_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadIn_24dps_clo;
V g_heff_2ecompile_2efields_2ereadsAt(V, V);
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadsAt_clo;
HeffT2 g_heff_2ecompile_2efields_2ereadsW_24cpr(V, V, V);
V g_heff_2ecompile_2efields_2esameLabels(V, V);
V g_heff_2ecompile_2efields_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2esameLabels_clo;
V g_heff_2ecompile_2efields_2etoRead(V);
V g_heff_2ecompile_2efields_2etoRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2etoRead_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1366522804x1636005216(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eany_24s1366522804x1636005216_entry(V self, V *a);
extern Clo g_list_2eany_24s1366522804x1636005216_clo;
V g_list_2eany_24s52192015x78999897(V, V);
V g_list_2eany_24s52192015x78999897_entry(V self, V *a);
extern Clo g_list_2eany_24s52192015x78999897_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2etraverse_24s1131246512x340210411(V, V);
V g_prelude_2etraverse_24s1131246512x340210411_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1131246512x340210411_clo;
HeffT2 g_prelude_2etraverse_24s625231350x1446463710_24cpr(V, V);
V g_prelude_2etraverse_24s842360874x216655417(V);
V g_prelude_2etraverse_24s842360874x216655417_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s842360874x216655417_clo;
Clo g_heff_2ecompile_2efields_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2efields_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efields_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efields_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2efields_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efields_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efields_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efields_2ereadsW_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2efields_2ereadsW_24cpr(V v_v_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_acc_241}});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      if (heff_strEq_c_lent(v_y_245, v_v_240, 1)) {
        heff_drop(v_acc_241);
        heff_drop(v_rest_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_249 = ({ V a_0 = v_v_240; V a_1 = v_xs_247; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_247); r_; });
      V v_t_2410;
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_248);
        heff_drop(v_t_249);
        v_t_2410 = v_rest_244;
      } else {
        heff_drop(v_t_249);
        v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2410;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x31_243, 0);
      V v_argv_2412 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_argv_2412, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2411, v_t_2413});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2414 = heff_field(v_x31_243, 0);
      V v_a_2415 = heff_field(v_x31_243, 1);
      V v_b_2416 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2417;
      if (heff_strEq_c_lent(v_x_2414, v_v_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_2416);
        v_t_2417 = v_rest_244;
      } else {
        v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2416, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2415, v_t_2417});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2420 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2418, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2420;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_x311_2421 = heff_field(v_x31_243, 0);
      V v_l_2422 = heff_field(v_x31_243, 1);
      V v_sh_2423 = heff_field(v_x31_243, 2);
      V v_t_2424 = heff_field(v_x31_243, 3);
      heff_take_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x311_2421)) {
      case TAG_EVar: {
        V v_y_2425 = heff_field(v_x311_2421, 0);
        heff_take_n(v_x311_2421, 1ULL, 1);
        if (!heff_strEq_c_lent(v_y_2425, v_v_240, 0)) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_l_2422);
          heff_drop(v_sh_2423);
          heff_drop(v_t_2424);
          heff_drop(v_y_2425);
          V t_0 = v_v_240;
          V t_1 = v_acc_241;
          V t_2 = v_rest_244;
          v_v_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_y_2425);
          switch (heff_tag_of(v_sh_2423)) {
          case TAG_Nil: {
            heff_drop(v_acc_241);
            heff_drop(v_rest_244);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop(v_l_2422);
            heff_drop(v_t_2424);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_t_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_l__sh__t, (V[]){v_l_2422, v_sh_2423, v_t_2424}), v_acc_241});
            V t_0 = v_v_240;
            V t_1 = v_t_2428;
            V t_2 = v_rest_244;
            v_v_240 = t_0;
            v_acc_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
          default: return ((HeffT2){{heff_nomatch(v_sh_2423)}});
          }
        }
      }
      case TAG_EGlobal: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELam: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELet: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ERecord: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EProj: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ETag: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EMatch: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrim: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrimCall: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EInt: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EStr: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EBytes: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFixed: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat32: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EAbandon: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EBool: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ESet: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EValues: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFix: {
        heff_drop(v_l_2422);
        heff_drop(v_sh_2423);
        heff_drop(v_t_2424);
        V t_0 = v_v_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x311_2421, v_rest_244});
        v_v_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2421)}});
      }
    }
    case TAG_ETag: {
      V v_argv_2468 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2470 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2468, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2470;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2471 = heff_field(v_x31_243, 0);
      V v_arms_2472 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2472));
      V v_t_2480 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efields_2ereadsW_24cpr_lam0, 2, 1, (V[]){heff_dup(v_v_240)}); V a_1 = v_rest_244; V a_2 = v_t_2473; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2473); r_; });
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2471, v_t_2480});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2483 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2484 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2483, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2484;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2486 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2487 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2486, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2487;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2495 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2496 = ({ V a_0 = v_c_2495; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2495); r_; });
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2496;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_xs_2497 = heff_field(v_x31_243, 0);
      V v_a_2498 = heff_field(v_x31_243, 1);
      V v_b_2499 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_24100 = ({ V a_0 = v_v_240; V a_1 = v_xs_2497; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_xs_2497); r_; });
      V v_t_24101;
      if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_b_2499);
        heff_drop(v_t_24100);
        v_t_24101 = v_rest_244;
      } else {
        heff_drop(v_t_24100);
        v_t_24101 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2499, v_rest_244});
      }
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2498, v_t_24101});
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_24102 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_24103 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_24102, v_rest_244));
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_24103;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_v_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2efields_2ereadsW_24cpr_lam0(V self, V *args) {
  V v_acc_2474 = args[0];
  V v_x_2475 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkArm: {
    V v_vs_2477 = heff_field(v_x_2475, 1);
    V v_b_2478 = heff_field(v_x_2475, 2);
    heff_take_n(v_x_2475, 6ULL, 3);
    V v_t_2479 = ({ V a_0 = v_v_240; V a_1 = v_vs_2477; V r_ = (g_heff_2ecompile_2efields_2eelemS(a_0, a_1)); heff_drop(v_v_240); heff_drop(v_vs_2477); r_; });
    if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
      heff_drop(v_b_2478);
      heff_drop(v_t_2479);
      return v_acc_2474;
    } else {
      heff_drop(v_t_2479);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_b_2478, v_acc_2474});
    }
  }
  default: return heff_nomatch(v_x_2475);
  }
}
Clo g_heff_2ecompile_2efields_2elabelsOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2elabelsOnce_entry, 2, 0};

V g_heff_2ecompile_2efields_2elabelsOnce(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s52192015x78999897(heff_dup(v_r_242), v_acc_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_r_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_acc_240;
      V t_1 = v_rs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_r_242, v_acc_240});
      V t_1 = v_rs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2elabelsOnce_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2elabelsOnce(a[0], a[1]);
}
V g_heff_2ecompile_2efields_2etoRead_lam0(V self, V *args);
Clo g_heff_2ecompile_2efields_2etoRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2etoRead_entry, 1, 0};

V g_heff_2ecompile_2efields_2etoRead(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_dup(v_rs_242)})));
    V v_once_244 = (g_heff_2ecompile_2efields_2elabelsOnce(NTAG(TAG_Nil), v_t_243));
    V v_t_246 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efields_2etoRead_lam0, 1, 1, (V[]){v_r_241}); V a_1 = v_rs_242; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_rs_242); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_once_244));
      if (heff_intLe_c(MK_INT(2LL), v_x_247)) {
        V v_t_248 = (g_list_2eany_24s1366522804x1636005216(MK_INT(8LL), MK_INT(16LL), MK_INT(32LL), MK_INT(64LL), MK_INT(8LL), MK_INT(16LL), MK_INT(32LL), MK_INT(64LL), MK_INT(32LL), MK_INT(64LL), v_once_244));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          return v_once_244;
        } else {
          heff_drop(v_once_244);
          heff_drop(v_t_248);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_once_244);
        return NTAG(TAG_Nil);
      }
    } else {
      heff_drop(v_once_244);
      heff_drop(v_t_246);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efields_2etoRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2etoRead(a[0]);
}
V g_heff_2ecompile_2efields_2etoRead_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_r_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_q_245, 1, 3); V b_1 = heff_get_n(v_r_241, 1, 3); V r_ = (g_heff_2ecompile_2efields_2esameLabels(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}

HeffT2 g_heff_2ecompile_2efields_2eboundAt_24cpr(V v_x1_240, V v_l_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_bs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_r_244 = heff_take_field(v_b_242, 0);
    V v_x_245 = heff_get_n(v_b_242, 1, 2);
    if (heff_strEq_c(heff_get_n(v_r_244, 0, 3), heff_dup(v_l_241))) {
      heff_drop(v_bs_243);
      V v_f_246 = v_x_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_x_245);
      V t_0 = v_bs_243;
      V t_1 = v_l_241;
      v_x1_240 = t_0;
      v_l_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2efields_2ereadIn_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ereadIn_lam1(V self, V *args);
Clo g_heff_2ecompile_2efields_2ereadIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadIn_entry, 3, 0};

V g_heff_2ecompile_2efields_2ereadIn(V v_v_240, V v_bs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EGlobal: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x3_242, 0);
    V v_b_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ELam = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2efields_2eelemS(v_v_240, v_xs_245));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      heff_drop(v_t_247);
      return heff_tag_at_n(v_ru_24x3_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, v_b_246});
    } else {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, heff_hole()});
      V v_u_249 = (g_heff_2ecompile_2efields_2ereadIn_24dps(v_v_240, v_bs_241, v_b_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_x3_242, 0);
    V v_argv_2411 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_f_2410));
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_2414 = (g_list_2emap(v_t_2413, v_argv_2411));
    return heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_EApp, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_x3_242, 0);
    V v_a_2416 = heff_field(v_x3_242, 1);
    V v_b_2417 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24ELet = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_a_2416));
    V v_t_2419;
    if (heff_strEq_c_lent(v_x_2415, v_v_240, 0)) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      v_t_2419 = v_b_2417;
    } else {
      v_t_2419 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_b_2417));
    }
    return heff_tag_at_n(v_ru_24x3_242_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, v_t_2419});
  }
  case TAG_ERecord: {
    V v_fs_2420 = heff_field(v_x3_242, 0);
    V v_ts_2421 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ERecord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_lam0, 1, 2, (V[]){v_v_240, v_bs_241}), v_fs_2420));
    return heff_tag_at_n(v_ru_24x3_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2430, v_ts_2421});
  }
  case TAG_EProj: {
    V v_x31_2431 = heff_field(v_x3_242, 0);
    V v_l_2432 = heff_field(v_x3_242, 1);
    V v_sh_2433 = heff_field(v_x3_242, 2);
    V v_t_2434 = heff_field(v_x3_242, 3);
    V v_ru_24x3_242_24EProj = heff_take_reuse_n(v_x3_242, 15ULL, 4);
    switch (heff_tag_of(v_x31_2431)) {
    case TAG_EVar: {
      V v_y_2435 = heff_field(v_x31_2431, 0);
      V v_ru_24x31_2431_24EVar = heff_take_reuse_n(v_x31_2431, 1ULL, 1);
      if (heff_strEq_c_lent(v_y_2435, v_v_240, 2)) {
        HeffT2 v_t_2436 = (g_heff_2ecompile_2efields_2eboundAt_24cpr(v_bs_241, v_l_2432));
        {
          V v_field_2438 = v_t_2436.f[1];
          int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
          if ((v_tag_2437 == ((int64_t)0ULL))) {
            heff_drop(v_l_2432);
            heff_drop(v_sh_2433);
            heff_drop(v_t_2434);
            heff_drop_cell(v_ru_24x3_242_24EProj, 4);
            heff_drop(v_y_2435);
            V v_x_2439 = v_field_2438;
            return heff_tag_at_n(v_ru_24x31_2431_24EVar, TAG_EVar, 1, (V[]){v_x_2439});
          } else {
            heff_drop_cell(v_ru_24x31_2431_24EVar, 1);
            heff_drop(v_field_2438);
            return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_2435}), v_l_2432, v_sh_2433, v_t_2434});
          }
        }
      } else {
        heff_drop(v_bs_241);
        heff_drop_cell(v_ru_24x31_2431_24EVar, 1);
        return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_2435}), v_l_2432, v_sh_2433, v_t_2434});
      }
    }
    case TAG_EGlobal: {
      V v_t_2441 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2441, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_ELam: {
      V v_t_2444 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2444, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EApp: {
      V v_t_2447 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2447, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_ELet: {
      V v_t_2451 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2451, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_ERecord: {
      V v_t_2454 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2454, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EProj: {
      V v_t_2459 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2459, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_ETag: {
      V v_t_2463 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2463, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EMatch: {
      V v_t_2466 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2466, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EPrim: {
      V v_t_2468 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2468, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EPrimCall: {
      V v_t_2471 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2471, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_ECall: {
      V v_t_2474 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2474, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EInt: {
      V v_t_2476 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2476, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EFloat: {
      V v_t_2478 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2478, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EStr: {
      V v_t_2480 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2480, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EBytes: {
      V v_t_2482 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2482, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EFixed: {
      V v_t_2485 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2485, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EFloat32: {
      V v_t_2487 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2487, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EAbandon: {
      V v_t_2488 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2488, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EBool: {
      V v_t_2490 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2490, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_ESet: {
      V v_t_2494 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2494, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EValues: {
      V v_t_2496 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2496, v_l_2432, v_sh_2433, v_t_2434});
    }
    case TAG_EFix: {
      V v_t_2499 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2431));
      return heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){v_t_2499, v_l_2432, v_sh_2433, v_t_2434});
    }
    default: return heff_nomatch(v_x31_2431);
    }
  }
  case TAG_ETag: {
    V v_t_24100 = heff_field(v_x3_242, 0);
    V v_argv_24101 = heff_field(v_x3_242, 1);
    V v_ts_24102 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24ETag = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24104 = (g_list_2emap(v_t_24103, v_argv_24101));
    return heff_tag_at_n(v_ru_24x3_242_24ETag, TAG_ETag, 3, (V[]){v_t_24100, v_t_24104, v_ts_24102});
  }
  case TAG_EMatch: {
    V v_s_24105 = heff_field(v_x3_242, 0);
    V v_arms_24106 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EMatch = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24107 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_s_24105));
    V v_t_24114 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_lam1, 1, 2, (V[]){v_v_240, v_bs_241}), v_arms_24106));
    return heff_tag_at_n(v_ru_24x3_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_24107, v_t_24114});
  }
  case TAG_EPrim: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EPrimCall: {
    V v_p_24116 = heff_field(v_x3_242, 0);
    V v_argv_24117 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EPrimCall = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24118 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24119 = (g_list_2emap(v_t_24118, v_argv_24117));
    return heff_tag_at_n(v_ru_24x3_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_24116, v_t_24119});
  }
  case TAG_ECall: {
    V v_g_24120 = heff_field(v_x3_242, 0);
    V v_argv_24121 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ECall = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24122 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24123 = (g_list_2emap(v_t_24122, v_argv_24121));
    return heff_tag_at_n(v_ru_24x3_242_24ECall, TAG_ECall, 2, (V[]){v_g_24120, v_t_24123});
  }
  case TAG_EInt: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EFloat: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EStr: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EBytes: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EFixed: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EFloat32: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  case TAG_EBool: {
    V v_c_24131 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24EBool = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_24132 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24133 = (g_heff_2ecompile_2eir_2econdMap(v_t_24132, v_c_24131));
    return heff_tag_at_n(v_ru_24x3_242_24EBool, TAG_EBool, 1, (V[]){v_t_24133});
  }
  case TAG_ESet: {
    V v_xs_24134 = heff_field(v_x3_242, 0);
    V v_a_24135 = heff_field(v_x3_242, 1);
    V v_b_24136 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24ESet = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_24137 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_a_24135));
    V v_t_24138 = (g_heff_2ecompile_2efields_2eelemS(v_v_240, v_xs_24134));
    V v_t_24139;
    if ((heff_dup(v_t_24138) == NTAG(TAG_True))) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      heff_drop(v_t_24138);
      v_t_24139 = v_b_24136;
    } else {
      heff_drop(v_t_24138);
      v_t_24139 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_b_24136));
    }
    return heff_tag_at_n(v_ru_24x3_242_24ESet, TAG_ESet, 3, (V[]){v_xs_24134, v_t_24137, v_t_24139});
  }
  case TAG_EValues: {
    V v_es_24140 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24EValues = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_24141 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24142 = (g_list_2emap(v_t_24141, v_es_24140));
    return heff_tag_at_n(v_ru_24x3_242_24EValues, TAG_EValues, 1, (V[]){v_t_24142});
  }
  case TAG_EFix: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return v_x3_242;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efields_2ereadIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2ereadIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efields_2ereadIn_lam0(V self, V *args) {
  V v_p_2422 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_bs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425;
  switch (heff_tag_of(v_p_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_dup(heff_field(v_p_2422, 0));
    v_t_2425 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_p_2422);
  }
  V v_t_2428;
  switch (heff_tag_of(v_p_2422)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_p_2422, 1);
    heff_take_n(v_p_2422, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_p_2422);
  }
  V v_t_2429 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_t_2428));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_t_2429});
}
V g_heff_2ecompile_2efields_2ereadIn_lam1(V self, V *args) {
  V v_a_24108 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_bs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24108)) {
  case TAG_MkArm: {
    V v_t_24109 = heff_dup(heff_field(v_a_24108, 0));
    V v_vs_24110 = heff_dup(heff_field(v_a_24108, 1));
    V v_b_24111 = heff_dup(heff_field(v_a_24108, 2));
    V v_t_24112 = (g_heff_2ecompile_2efields_2eelemS(v_v_240, v_vs_24110));
    if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      heff_drop(v_t_24109);
      heff_drop(v_vs_24110);
      heff_drop(v_b_24111);
      heff_drop(v_t_24112);
      return v_a_24108;
    } else {
      heff_drop_tag(v_a_24108, 3);
      heff_drop(v_t_24112);
      V v_t_24113 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_b_24111));
      return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24109, v_vs_24110, v_t_24113});
    }
  }
  default: return heff_nomatch(v_a_24108);
  }
}
V g_heff_2ecompile_2efields_2ereadIn_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ereadIn_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2efields_2ereadIn_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadIn_24dps_entry, 4, 0};

V g_heff_2ecompile_2efields_2ereadIn_24dps(V v_v_240, V v_bs_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EGlobal: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x3_242, 0);
    V v_b_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ELam = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2efields_2eelemS(v_v_240, v_xs_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      heff_drop_cell(v_ru_24x3_242_24ELam, 2);
      heff_drop(v_t_248);
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_b_247}));
    } else {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_v_240;
      V t_1 = v_bs_241;
      V t_2 = v_b_247;
      V t_3 = v_cell_249;
      v_v_240 = t_0;
      v_bs_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_x3_242, 0);
    V v_argv_2412 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_f_2411));
    V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_2415 = (g_list_2emap_24tok2(v_ru_24x3_242_24EApp, v_t_2414, v_argv_2412));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EApp, 2, (V[]){v_t_2413, v_t_2415}));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_x3_242, 0);
    V v_a_2417 = heff_field(v_x3_242, 1);
    V v_b_2418 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_2419 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_a_2417));
    V v_t_2420;
    if (heff_strEq_c_lent(v_x_2416, v_v_240, 0)) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      v_t_2420 = v_b_2418;
    } else {
      v_t_2420 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_b_2418));
    }
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_2416, v_t_2419, v_t_2420}));
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_x3_242, 0);
    V v_ts_2422 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ERecord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2431 = (g_list_2emap_24tok2(v_ru_24x3_242_24ERecord, heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_24dps_lam0, 1, 2, (V[]){v_v_240, v_bs_241}), v_fs_2421));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2422}));
  }
  case TAG_EProj: {
    V v_x31_2432 = heff_field(v_x3_242, 0);
    V v_l_2433 = heff_field(v_x3_242, 1);
    V v_sh_2434 = heff_field(v_x3_242, 2);
    V v_t_2435 = heff_field(v_x3_242, 3);
    V v_ru_24x3_242_24EProj = heff_take_reuse_n(v_x3_242, 15ULL, 4);
    switch (heff_tag_of(v_x31_2432)) {
    case TAG_EVar: {
      V v_y_2436 = heff_field(v_x31_2432, 0);
      heff_take_n(v_x31_2432, 1ULL, 1);
      if (heff_strEq_c_lent(v_y_2436, v_v_240, 2)) {
        HeffT2 v_t_2437 = (g_heff_2ecompile_2efields_2eboundAt_24cpr(v_bs_241, v_l_2433));
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            heff_drop(v_l_2433);
            heff_drop(v_sh_2434);
            heff_drop(v_t_2435);
            heff_drop_cell(v_ru_24x3_242_24EProj, 4);
            heff_drop(v_y_2436);
            V v_x_2440 = v_field_2439;
            return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EVar, 1, (V[]){v_x_2440}));
          } else {
            heff_drop(v_field_2439);
            V v_t_2441 = heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_2436}), v_l_2433, v_sh_2434, v_t_2435});
            return heff_setField(v_d_243, MK_INT(1LL), v_t_2441);
          }
        }
      } else {
        heff_drop(v_bs_241);
        V v_t_2442 = heff_tag_at_n(v_ru_24x3_242_24EProj, TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_2436}), v_l_2433, v_sh_2434, v_t_2435});
        return heff_setField(v_d_243, MK_INT(1LL), v_t_2442);
      }
    }
    case TAG_EGlobal: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2444 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2444, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_ELam: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2447 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2447, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EApp: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2450 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2450, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_ELet: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2454 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2454, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_ERecord: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2457 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2457, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EProj: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2462 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2462, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_ETag: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2466 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2466, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EMatch: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2469 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2469, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EPrim: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2471 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2471, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2474 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2474, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_ECall: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2477 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2477, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EInt: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2479 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2479, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EFloat: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2481 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2481, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EStr: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2483 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2483, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EBytes: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2485 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2485, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EFixed: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2488 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2488, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EFloat32: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2490 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2490, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2491 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2491, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EBool: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2493 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2493, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_ESet: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2497 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2497, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EValues: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_2499 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2499, v_l_2433, v_sh_2434, v_t_2435}));
    }
    case TAG_EFix: {
      heff_drop_cell(v_ru_24x3_242_24EProj, 4);
      V v_t_24102 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_x31_2432));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EProj, 4, (V[]){v_t_24102, v_l_2433, v_sh_2434, v_t_2435}));
    }
    default: return heff_nomatch(v_x31_2432);
    }
  }
  case TAG_ETag: {
    V v_t_24103 = heff_field(v_x3_242, 0);
    V v_argv_24104 = heff_field(v_x3_242, 1);
    V v_ts_24105 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24107 = (g_list_2emap(v_t_24106, v_argv_24104));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_ETag, 3, (V[]){v_t_24103, v_t_24107, v_ts_24105}));
  }
  case TAG_EMatch: {
    V v_s_24108 = heff_field(v_x3_242, 0);
    V v_arms_24109 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EMatch = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24110 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_s_24108));
    V v_t_24117 = (g_list_2emap_24tok2(v_ru_24x3_242_24EMatch, heff_clo_n(g_heff_2ecompile_2efields_2ereadIn_24dps_lam1, 1, 2, (V[]){v_v_240, v_bs_241}), v_arms_24109));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_t_24110, v_t_24117}));
  }
  case TAG_EPrim: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EPrimCall: {
    V v_p_24119 = heff_field(v_x3_242, 0);
    V v_argv_24120 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EPrimCall = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24121 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24122 = (g_list_2emap_24tok2(v_ru_24x3_242_24EPrimCall, v_t_24121, v_argv_24120));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24119, v_t_24122}));
  }
  case TAG_ECall: {
    V v_g_24123 = heff_field(v_x3_242, 0);
    V v_argv_24124 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ECall = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24125 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24126 = (g_list_2emap_24tok2(v_ru_24x3_242_24ECall, v_t_24125, v_argv_24124));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_ECall, 2, (V[]){v_g_24123, v_t_24126}));
  }
  case TAG_EInt: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EFloat: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EStr: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EBytes: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EFixed: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EFloat32: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EAbandon: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_EBool: {
    V v_c_24134 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24135 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24136 = (g_heff_2ecompile_2eir_2econdMap(v_t_24135, v_c_24134));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EBool, 1, (V[]){v_t_24136}));
  }
  case TAG_ESet: {
    V v_xs_24137 = heff_field(v_x3_242, 0);
    V v_a_24138 = heff_field(v_x3_242, 1);
    V v_b_24139 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_24140 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_240), heff_dup(v_bs_241), v_a_24138));
    V v_t_24141 = (g_heff_2ecompile_2efields_2eelemS(v_v_240, v_xs_24137));
    V v_t_24142;
    if ((heff_dup(v_t_24141) == NTAG(TAG_True))) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      heff_drop(v_t_24141);
      v_t_24142 = v_b_24139;
    } else {
      heff_drop(v_t_24141);
      v_t_24142 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_b_24139));
    }
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24137, v_t_24140, v_t_24142}));
  }
  case TAG_EValues: {
    V v_es_24143 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24144 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efields_2ereadIn_clo), 2, (V[]){v_v_240, v_bs_241}));
    V v_t_24145 = (g_list_2emap(v_t_24144, v_es_24143));
    return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_EValues, 1, (V[]){v_t_24145}));
  }
  case TAG_EFix: {
    heff_drop(v_v_240);
    heff_drop(v_bs_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efields_2ereadIn_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2ereadIn_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efields_2ereadIn_24dps_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_bs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_p_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2429;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2430 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_t_2429));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2430});
}
V g_heff_2ecompile_2efields_2ereadIn_24dps_lam1(V self, V *args) {
  V v_a_24111 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_bs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24111)) {
  case TAG_MkArm: {
    V v_t_24112 = heff_dup(heff_field(v_a_24111, 0));
    V v_vs_24113 = heff_dup(heff_field(v_a_24111, 1));
    V v_b_24114 = heff_dup(heff_field(v_a_24111, 2));
    V v_t_24115 = (g_heff_2ecompile_2efields_2eelemS(v_v_240, v_vs_24113));
    if ((heff_dup(v_t_24115) == NTAG(TAG_True))) {
      heff_drop(v_v_240);
      heff_drop(v_bs_241);
      heff_drop(v_t_24112);
      heff_drop(v_vs_24113);
      heff_drop(v_b_24114);
      heff_drop(v_t_24115);
      return v_a_24111;
    } else {
      heff_drop_tag(v_a_24111, 3);
      heff_drop(v_t_24115);
      V v_t_24116 = (g_heff_2ecompile_2efields_2ereadIn(v_v_240, v_bs_241, v_b_24114));
      return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24112, v_vs_24113, v_t_24116});
    }
  }
  default: return heff_nomatch(v_a_24111);
  }
}
Clo g_heff_2ecompile_2efields_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eletsOf_entry, 3, 0};

V g_heff_2ecompile_2efields_2eletsOf(V v_v_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_v_240);
    return v_e_242;
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_bs_244 = heff_field(v_x2_241, 1);
    V v_x_245 = heff_dup(heff_rfield(v_b_243, 1));
    V v_r_246 = heff_dup(heff_rfield(v_b_243, 0));
    V v_t_247 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_v_240)}), heff_take_field(v_r_246, 0), heff_take_field(v_r_246, 1), heff_get_n(v_r_246, 2, 3)});
    V v_cell_248 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_245, v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2efields_2eletsOf_24dps(v_v_240, v_bs_244, v_e_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efields_2eletsOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efields_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2eletsOf_24dps_entry, 4, 0};

V g_heff_2ecompile_2efields_2eletsOf_24dps(V v_v_240, V v_x2_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_v_240);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_Cons: {
    V v_b_244 = heff_field(v_x2_241, 0);
    V v_bs_245 = heff_field(v_x2_241, 1);
    V v_x_246 = heff_dup(heff_rfield(v_b_244, 1));
    V v_r_247 = heff_dup(heff_rfield(v_b_244, 0));
    V v_t_248 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_v_240)}), heff_take_field(v_r_247, 0), heff_take_field(v_r_247, 1), heff_get_n(v_r_247, 2, 3)});
    V v_cell_249 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_246, v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_v_240;
    V t_1 = v_bs_245;
    V t_2 = v_e_242;
    V t_3 = v_cell_249;
    v_v_240 = t_0;
    v_x2_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efields_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efields_2eletsOf_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efields_2ereadAt_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ereadAt_lam1(V self, V *args);
V g_heff_2ecompile_2efields_2ereadAt_lam2(V self, V *args);
Clo g_heff_2ecompile_2efields_2ereadAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadAt_entry, 2, 0};

V g_heff_2ecompile_2efields_2ereadAt(V v_b_240, V v_v_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_heff_2ecompile_2efields_2ereadsW_24cpr(v_v_241, NTAG(TAG_Nil), v_t_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_rs_246 = v_field_245;
      V v_it_247 = (g_heff_2ecompile_2efields_2etoRead(v_rs_246));
      switch (heff_tag_of(v_it_247)) {
      case TAG_Nil: {
        heff_drop(v_v_241);
        return heff_clo_n(g_heff_2ecompile_2efields_2ereadAt_lam0, 1, 1, (V[]){v_b_240});
      }
      case TAG_Cons: {
        return heff_clo_n(g_heff_2ecompile_2efields_2ereadAt_lam1, 1, 3, (V[]){v_it_247, v_v_241, v_b_240});
      }
      default: return heff_nomatch(v_it_247);
      }
    } else {
      heff_drop(v_v_241);
      heff_drop(v_field_245);
      return heff_clo_n(g_heff_2ecompile_2efields_2ereadAt_lam2, 1, 1, (V[]){v_b_240});
    }
  }
}
V g_heff_2ecompile_2efields_2ereadAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2ereadAt(a[0], a[1]);
}
V g_heff_2ecompile_2efields_2ereadAt_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_b_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_n_248});
}
V g_heff_2ecompile_2efields_2ereadAt_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_it_247 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_b_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2412 = (g_prelude_2etraverse_24s625231350x1446463710_24cpr(v_it_247, v_n_2411));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x_2415 = v_field_2413;
    V v_n_2416 = v_field_2414;
    V v_t_2417 = (g_heff_2ecompile_2efields_2ereadIn(heff_dup(v_v_241), heff_dup(v_x_2415), v_b_240));
    V v_x_2418 = ({ V a_0 = v_v_241; V a_1 = v_x_2415; V a_2 = v_t_2417; V r_ = (g_heff_2ecompile_2efields_2eletsOf(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_n_2416});
  }
}
V g_heff_2ecompile_2efields_2ereadAt_lam2(V self, V *args) {
  V v_n_2419 = args[0];
  V v_b_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_n_2419});
}
V g_heff_2ecompile_2efields_2ereadsAt_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ereadsAt_lam1(V self, V *args);
Clo g_heff_2ecompile_2efields_2ereadsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ereadsAt_entry, 2, 0};

V g_heff_2ecompile_2efields_2ereadsAt(V v_x1_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ereadsAt_lam0, 1, 1, (V[]){v_b_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_m_245 = (g_heff_2ecompile_2efields_2ereadAt(v_b_241, heff_dup(v_x_243)));
    return heff_clo_n(g_heff_2ecompile_2efields_2ereadsAt_lam1, 1, 2, (V[]){v_m_245, heff_dup(v_xs_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efields_2ereadsAt(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efields_2ereadsAt_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_b_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_241, v_n_242});
}
V g_heff_2ecompile_2efields_2ereadsAt_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_xs_244; V a_1 = v_x_248; V r_ = (g_heff_2ecompile_2efields_2ereadsAt(a_0, a_1)); heff_drop(v_xs_244); r_; });
    V f_ = v_t_2410;
    args[0] = v_n_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2efields_2ego_lam0(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam1(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam2(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam3(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam4(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam5(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam6(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam7(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam8(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam9(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam10(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam11(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam12(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam13(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam14(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam15(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam16(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam17(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam18(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam19(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam20(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam21(V self, V *args);
V g_heff_2ecompile_2efields_2ego_lam22(V self, V *args);
Clo g_heff_2ecompile_2efields_2ego_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efields_2ego_entry, 1, 0};

V g_heff_2ecompile_2efields_2ego(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam0, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam1, 1, 1, (V[]){v_x1_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x1_240, 0);
    V v_b_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2efields_2ego(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_f_2416 = heff_field(v_x1_240, 0);
    V v_argv_2417 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2efields_2ego(v_f_2416));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam3, 1, 2, (V[]){v_m_2418, v_argv_2417});
  }
  case TAG_ELet: {
    V v_x_2427 = heff_field(v_x1_240, 0);
    V v_a_2428 = heff_field(v_x1_240, 1);
    V v_b_2429 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2efields_2ego(v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam4, 1, 3, (V[]){v_m_2430, v_b_2429, v_x_2427});
  }
  case TAG_ERecord: {
    V v_fs_2443 = heff_field(v_x1_240, 0);
    V v_ts_2444 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2445 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x1_240_24ERecord, heff_dup(v_fs_2443)));
    V v_m_2446 = (g_prelude_2etraverse_24s1131246512x340210411(((V)&g_heff_2ecompile_2efields_2ego_clo), v_t_2445));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam5, 1, 3, (V[]){v_m_2446, v_fs_2443, v_ts_2444});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x1_240, 0);
    V v_l_2454 = heff_field(v_x1_240, 1);
    V v_sh_2455 = heff_field(v_x1_240, 2);
    V v_t_2456 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_m_2457 = (g_heff_2ecompile_2efields_2ego(v_e_2453));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam6, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x1_240, 0);
    V v_argv_2463 = heff_field(v_x1_240, 1);
    V v_ts_2464 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2465 = (g_prelude_2etraverse_24s1131246512x340210411(((V)&g_heff_2ecompile_2efields_2ego_clo), v_argv_2463));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam7, 1, 3, (V[]){v_m_2465, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2470 = heff_field(v_x1_240, 0);
    V v_arms_2471 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2472 = (g_heff_2ecompile_2efields_2ego(v_s_2470));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam8, 1, 2, (V[]){v_m_2472, v_arms_2471});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam9, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EPrimCall: {
    V v_p_2483 = heff_field(v_x1_240, 0);
    V v_argv_2484 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2485 = (g_prelude_2etraverse_24s1131246512x340210411(((V)&g_heff_2ecompile_2efields_2ego_clo), v_argv_2484));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam10, 1, 2, (V[]){v_m_2485, v_p_2483});
  }
  case TAG_ECall: {
    V v_g_2490 = heff_field(v_x1_240, 0);
    V v_argv_2491 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2492 = (g_prelude_2etraverse_24s1131246512x340210411(((V)&g_heff_2ecompile_2efields_2ego_clo), v_argv_2491));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam11, 1, 2, (V[]){v_m_2492, v_g_2490});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam12, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam13, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam14, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam15, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam16, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam17, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam18, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBool: {
    V v_c_24111 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_m_24112 = (g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(((V)&g_heff_2ecompile_2efields_2ego_clo), v_c_24111));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam19, 1, 1, (V[]){v_m_24112});
  }
  case TAG_ESet: {
    V v_xs_24117 = heff_field(v_x1_240, 0);
    V v_a_24118 = heff_field(v_x1_240, 1);
    V v_b_24119 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_24120 = (g_heff_2ecompile_2efields_2ego(v_a_24118));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam20, 1, 3, (V[]){v_m_24120, v_b_24119, v_xs_24117});
  }
  case TAG_EValues: {
    V v_es_24133 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_m_24134 = (g_prelude_2etraverse_24s1131246512x340210411(((V)&g_heff_2ecompile_2efields_2ego_clo), v_es_24133));
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam21, 1, 1, (V[]){v_m_24134});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2efields_2ego_lam22, 1, 1, (V[]){v_x1_240});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efields_2ego_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efields_2ego(a[0]);
}
V g_heff_2ecompile_2efields_2ego_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_242});
}
V g_heff_2ecompile_2efields_2ego_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_244});
}
V g_heff_2ecompile_2efields_2ego_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = (g_heff_2ecompile_2efields_2ereadsAt(v_xs_245, v_x_2410));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2efields_2ego_lam3(V self, V *args) {
  V v_n_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_argv_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_n_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_m_2423 = (g_prelude_2etraverse_24s1131246512x340210411(((V)&g_heff_2ecompile_2efields_2ego_clo), v_argv_2417));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2422}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_n_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2421, v_x_2425}), v_n_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2efields_2ego_lam4(V self, V *args) {
  V v_n_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2429 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_n_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_n_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_m_2435 = (g_heff_2ecompile_2efields_2ego(v_b_2429));
    V v_x2_2436 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_n_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_n_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_m_2439 = (g_heff_2ecompile_2efields_2ereadAt(v_x_2437, heff_dup(v_x_2427)));
      V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2427, v_x_2433, v_x_2441}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2efields_2ego_lam5(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_fs_2443 = heff_env(self)[1];
  V v_ts_2444 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_t_2451 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2443, v_x_2449));
    V v_x_2452 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2451, v_ts_2444});
    return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){v_x_2452, v_n_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2efields_2ego_lam6(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2efields_2ego_lam7(V self, V *args) {
  V v_n_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_n_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_n_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2468, v_ts_2464}), v_n_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2efields_2ego_lam8(V self, V *args) {
  V v_n_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_arms_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2474 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_n_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_n_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    V v_m_2477 = (g_prelude_2etraverse_24s842360874x216655417(v_arms_2471));
    V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_n_2476}));
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_n_2480 = heff_field(v_x2_2478, 1);
      heff_take_n(v_x2_2478, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2475, v_x_2479}), v_n_2480});
    }
    default: return heff_nomatch(v_x2_2478);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2ecompile_2efields_2ego_lam9(V self, V *args) {
  V v_n_2482 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2482});
}
V g_heff_2ecompile_2efields_2ego_lam10(V self, V *args) {
  V v_n_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  V v_p_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2487 = heff_tr(heff_call(v_m_2485, 1, (V[]){v_n_2486}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_n_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2483, v_x_2488}), v_n_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2ecompile_2efields_2ego_lam11(V self, V *args) {
  V v_n_2493 = args[0];
  V v_m_2492 = heff_env(self)[0];
  V v_g_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2494 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_n_2493}));
  switch (heff_tag_of(v_x2_2494)) {
  case TAG_MkPair: {
    V v_x_2495 = heff_field(v_x2_2494, 0);
    V v_n_2496 = heff_field(v_x2_2494, 1);
    V v_ru_24x2_2494_24MkPair = heff_take_reuse_n(v_x2_2494, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2490, v_x_2495}), v_n_2496});
  }
  default: return heff_nomatch(v_x2_2494);
  }
}
V g_heff_2ecompile_2efields_2ego_lam12(V self, V *args) {
  V v_n_2498 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_2498});
}
V g_heff_2ecompile_2efields_2ego_lam13(V self, V *args) {
  V v_n_24100 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24100});
}
V g_heff_2ecompile_2efields_2ego_lam14(V self, V *args) {
  V v_n_24102 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24102});
}
V g_heff_2ecompile_2efields_2ego_lam15(V self, V *args) {
  V v_n_24104 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24104});
}
V g_heff_2ecompile_2efields_2ego_lam16(V self, V *args) {
  V v_n_24107 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24107});
}
V g_heff_2ecompile_2efields_2ego_lam17(V self, V *args) {
  V v_n_24109 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24109});
}
V g_heff_2ecompile_2efields_2ego_lam18(V self, V *args) {
  V v_n_24110 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24110});
}
V g_heff_2ecompile_2efields_2ego_lam19(V self, V *args) {
  V v_n_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_n_24113}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_n_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24115}), v_n_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2efields_2ego_lam20(V self, V *args) {
  V v_n_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_b_24119 = heff_env(self)[1];
  V v_xs_24117 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_n_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_n_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    V v_m_24125 = (g_heff_2ecompile_2efields_2ego(v_b_24119));
    V v_x2_24126 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24124}));
    switch (heff_tag_of(v_x2_24126)) {
    case TAG_MkPair: {
      V v_x_24127 = heff_field(v_x2_24126, 0);
      V v_n_24128 = heff_field(v_x2_24126, 1);
      heff_take_n(v_x2_24126, 3ULL, 2);
      V v_m_24129 = (g_heff_2ecompile_2efields_2ereadsAt(v_xs_24117, v_x_24127));
      V v_x2_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_n_24128}));
      switch (heff_tag_of(v_x2_24130)) {
      case TAG_MkPair: {
        V v_x_24131 = heff_field(v_x2_24130, 0);
        V v_n_24132 = heff_field(v_x2_24130, 1);
        heff_take_n(v_x2_24130, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24117, v_x_24123, v_x_24131}), v_n_24132});
      }
      default: return heff_nomatch(v_x2_24130);
      }
    }
    default: return heff_nomatch(v_x2_24126);
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2efields_2ego_lam21(V self, V *args) {
  V v_n_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_n_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_n_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24137}), v_n_24138});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2efields_2ego_lam22(V self, V *args) {
  V v_n_24141 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24141});
}