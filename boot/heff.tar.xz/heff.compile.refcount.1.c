// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_CLet 49341
#define TAG_F32 16337
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ISts 38700
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkCode 2932
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RFixU 5362
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RPeek 36757
#define TAG_RStr 44714
#define TAG_RUnbox 59387
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_after 294093302
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_n 328
#define LBL_owned 307523263
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
V g_heff_2ecompile_2erefcount_2earmFound(V, V, V);
V g_heff_2ecompile_2erefcount_2earmFound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmFound_clo;
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_clo;
V g_heff_2ecompile_2erefcount_2eboolName_get(void);
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvSts_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvTl_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvTl_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_24tok1_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo;
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo;
V g_heff_2ecompile_2erefcount_2enthValue(V, V);
V g_heff_2ecompile_2erefcount_2enthValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enthValue_clo;
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereusedAny_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereusing(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusing_clo;
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estrAs_24tok1(V, V, V);
V g_heff_2ecompile_2erefcount_2estrAs_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estrAs_24tok1_clo;
V g_heff_2ecompile_2erefcount_2etakeOne(V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOne_clo;
V g_heff_2ecompile_2erefcount_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeVar_clo;
V g_heff_2ecompile_2erefcount_2etakenFv(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakenFv_clo;
V g_heff_2ecompile_2erefcount_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakesAt_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenArm_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewrapArg(V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapArg_clo;
V g_heff_2ecompile_2erefcount_2ewrapUnbox(V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapUnbox_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapUnbox_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s1982386833x551161312(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1982386833x551161312_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithFrame_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithFrame(V v_s_240, V v_n_241, V v_ce_242) {
top: ;
  V v_funs_243 = heff_take_field(v_ce_242, 0);
  V v_bounce_244 = heff_take_field(v_ce_242, 1);
  V v_owned_245 = heff_take_field(v_ce_242, 4);
  V v_after_246 = heff_take_field(v_ce_242, 5);
  V v_borrowed_247 = heff_take_field(v_ce_242, 6);
  V v_bor_248 = heff_take_field(v_ce_242, 7);
  V v_known_249 = heff_take_field(v_ce_242, 8);
  V v_reprs_2410 = heff_take_field(v_ce_242, 10);
  V v_sigs_2411 = heff_take_field(v_ce_242, 11);
  V v_flat_2412 = heff_take_field(v_ce_242, 12);
  V v_sure_2413 = heff_take_field(v_ce_242, 13);
  V v_sureRecs_2414 = heff_take_field(v_ce_242, 14);
  V v_tokens_2415 = heff_get_n(v_ce_242, 15, 17);
  V v_t_2421;
  switch (heff_tag_of(v_s_240)) {
  case TAG_Nothing: {
    v_t_2421 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_s_2416 = heff_dup(heff_field(v_s_240, 0));
    HeffT2 v_t_2417 = ({ V a_0 = v_sigs_2411; V b_1 = heff_get_n(v_s_2416, 0, 2); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_s_2420 = v_field_2419;
        v_t_2421 = heff_get_n(v_s_2420, 1, 2);
      } else {
        heff_drop(v_field_2419);
        v_t_2421 = NTAG(TAG_RepV);
      }
    }
    break;
  }
  default: heff_nomatch(v_s_240);
  }
  return heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_funs_243, v_bounce_244, v_s_240, v_n_241, v_owned_245, v_after_246, v_borrowed_247, v_bor_248, v_known_249, NTAG(TAG_Nil), v_reprs_2410, v_sigs_2411, v_flat_2412, v_sure_2413, v_sureRecs_2414, v_tokens_2415, v_t_2421});
}
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithFrame(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 2)) {
      heff_drop(v_ks_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2eslotBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eslotBits_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2eslotBits(V v_rps_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rps_240));
  V v_t_242 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_241, MK_INT(1LL))));
  V v_ps_243 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_242, v_rps_240));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = MK_INT(0LL); V a_13 = v_ps_243; V r_ = (g_list_2efoldl_24s1982386833x551161312(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_ps_243); r_; });
}
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eslotBits(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2etakenFv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakenFv_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
      if (heff_intLe_c(v_t_247, MK_INT(60LL))) {
        V v_x1_248 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_244, v_fb_243));
        if (!(heff_dup(v_x1_248) == NTAG(TAG_True))) {
          heff_drop(v_x1_248);
          V v_x1_249 = ({ V a_0 = v_x_244; V b_1 = heff_get_n(v_ce_240, 5, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
            heff_drop(v_x1_249);
            return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_244});
          } else {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            heff_drop(v_x1_249);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          heff_drop(v_x1_248);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_vs_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2etakenFv_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2etakenFv(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2earmFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmFound_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2earmFound(V v_t_240, V v_vs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_b_243 = heff_field(v_x3_242, 0);
    V v_x_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_b_243, heff_tag_n(TAG_MkArm, 3, (V[]){v_t_240, v_vs_241, v_x_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2earmFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2earmFound(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str1, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str4, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str5, 3, "ru$");
Clo g_heff_2ecompile_2erefcount_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereusing_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ereusing(V v_tk_240, V v_x2_241, V v_t_242, V v_vs_243, V v_b_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_tk_240);
    heff_drop(v_t_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_244});
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_242, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_242, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      heff_drop(v_tk_240);
      heff_drop(v_t_242);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_244});
    } else {
      V v_t_246 = heff_strAppend(heff_dup(v_x_245), heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str0), heff_dup(v_t_242)));
      V v_ru_247 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str1), v_t_246);
      V v_n_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
      V v_t_249 = heff_strAppend(heff_dup(v_x_245), heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str2), heff_dup(v_t_242)));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
      V v_t_2411 = heff_strAppend(v_x_245, heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str3), heff_dup(v_t_242)));
      V v_ru_2412 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str4), v_t_2411);
      V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
      V v_n_2414 = heff_rec_n(2, shape_n__tag, (V[]){v_t_2413, v_t_242});
      V v_t_2427;
      switch (heff_tag_of(v_b_244)) {
      case TAG_ATail: {
        V v_t_2415 = heff_dup(heff_field(v_b_244, 0));
        HeffT2 v_t_2416 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_2412, v_n_2414, v_t_2415));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_b_2419 = v_field_2417;
          V v_t2_2420 = v_field_2418;
          v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2419, heff_tag_n(TAG_ATail, 1, (V[]){v_t2_2420})});
        }
        break;
      }
      case TAG_ASts: {
        V v_ss_2421 = heff_dup(heff_field(v_b_244, 0));
        HeffT2 v_t_2422 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_2412, v_n_2414, v_ss_2421));
        {
          V v_field_2423 = v_t_2422.f[0];
          V v_field_2424 = v_t_2422.f[1];
          V v_b_2425 = v_field_2423;
          V v_ss2_2426 = v_field_2424;
          v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2425, heff_tag_n(TAG_ASts, 1, (V[]){v_ss2_2426})});
        }
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      HeffT2 v_t_2428 = (g_heff_2ecompile_2erefcount_2ereusedAny_24cpr(heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str5), v_t_249), v_t_2410, v_b_244, v_t_2427));
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_m_2431 = v_field_2429;
        V v_b_2432 = v_field_2430;
        HeffT2 v_t_2433 = (g_heff_2ecompile_2erefcount_2etokenArm_24cpr(v_tk_240, heff_dup(v_ru_247), v_n_248, heff_dup(v_b_2432)));
        {
          V v_field_2434 = v_t_2433.f[0];
          V v_field_2435 = v_t_2433.f[1];
          V v_it1_2436 = v_field_2434;
          V v_b2_2437 = v_field_2435;
          if ((heff_dup(v_it1_2436) == NTAG(TAG_True))) {
            heff_drop(v_m_2431);
            heff_drop(v_b_2432);
            heff_drop(v_it1_2436);
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_ru_247}), v_b2_2437});
          } else {
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            heff_drop(v_ru_247);
            heff_drop(v_it1_2436);
            heff_drop(v_b2_2437);
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2431, v_b_2432});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2ereusing(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeOne_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2etakeOne(V v_ce_240, V v_rest_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SVar: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SGlobal: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SInt: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFloat: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SStr: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SBytes: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFixed: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFloat32: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SPrimFn: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SLam: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_STag: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SRec: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    V v_l_2421 = heff_field(v_x3_242, 1);
    V v_sh_2422 = heff_field(v_x3_242, 2);
    V v_t_2423 = heff_field(v_x3_242, 3);
    V v_t_2424 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_2423));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_ce_240);
      heff_drop(v_rest_241);
      heff_drop(v_t_2424);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2424);
      V v_t_2448;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_SVar: {
        V v_x_2425 = heff_field(v_e_2420, 0);
        v_t_2448 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2425)});
        break;
      }
      case TAG_SGlobal: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      return ({ V a_0 = v_ce_240; V a_1 = v_rest_241; V a_2 = v_t_2448; V a_3 = heff_dup(v_l_2421); V a_4 = heff_dup(v_sh_2422); V r_ = (g_heff_2ecompile_2erefcount_2etakeVar(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2448); r_; });
    }
  }
  case TAG_SPrim: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeOne_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2etakeOne(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakesAt_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etakesAt(V v_ce_240, V v_before_241, V v_after_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_before_241);
    heff_drop(v_after_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_rest_247 = (g_list_2efoldl_24s1203202837x1639358108(heff_dup(v_after_242), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_before_241)));
    V v_t_249 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_247, v_t_248));
    V v_t_2410 = (g_heff_2ecompile_2erefcount_2etakeOne(heff_dup(v_ce_240), v_t_249, v_e_244));
    V v_t_2411 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_before_241, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2etakesAt(v_ce_240, v_t_2412, v_after_242, v_es_245));
    return (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etakesAt(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eboolName_str0, 8, "ret$bool");

static V g_heff_2ecompile_2erefcount_2eboolName_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2eboolName_st;
static V g_heff_2ecompile_2erefcount_2eboolName_init(void) {
  return ((V)&g_heff_2ecompile_2erefcount_2eboolName_str0);
}
V g_heff_2ecompile_2erefcount_2eboolName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2eboolName_st)) return g_heff_2ecompile_2erefcount_2eboolName_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2eboolName_val, &g_heff_2ecompile_2erefcount_2eboolName_st, g_heff_2ecompile_2erefcount_2eboolName_init);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapUnbox_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapUnbox_str1, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapUnbox_str2, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2ewrapUnbox_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewrapUnbox_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewrapUnbox(V v_lent_240, V v_rp_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_rp_241)) {
  case TAG_RepV: {
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_RepFix: {
    V v_v_244 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapUnbox_str0), heff_dup(v_x_242))});
    V v_t_245;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_245 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_244});
    } else {
      v_t_245 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_244});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_245}), NTAG(TAG_Nil)});
  }
  case TAG_RepF64: {
    V v_v_246 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapUnbox_str1), heff_dup(v_x_242))});
    V v_t_247;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_247 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_246});
    } else {
      v_t_247 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_246});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_247}), NTAG(TAG_Nil)});
  }
  case TAG_RepInt: {
    V v_v_248 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapUnbox_str2), heff_dup(v_x_242))});
    V v_t_249;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_249 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_248});
    } else {
      v_t_249 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_248});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_249}), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_rp_241);
  }
}
V g_heff_2ecompile_2erefcount_2ewrapUnbox_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2ewrapUnbox(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapArg_str0, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2ewrapArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewrapArg_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewrapArg(V v_ce_240, V v_rp_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_rp_241)) {
  case TAG_RepV: {
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_247;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        heff_drop(v_x_246);
        v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapArg_str0), v_x_242);
      } else {
        heff_drop(v_field_245);
        v_t_247 = v_x_242;
      }
    }
    return heff_tag_n(TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_t_247})});
  }
  case TAG_RepFix: {
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_241, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242})});
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_241, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242})});
  }
  case TAG_RepInt: {
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_241, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242})});
  }
  default: return heff_nomatch(v_rp_241);
  }
}
V g_heff_2ecompile_2erefcount_2ewrapArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewrapArg(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2enthValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2enthValue_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2enthValue(V v_i_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2enthValue_24cpr(v_i_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erefcount_2enthValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2enthValue(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str1, 4, "box$");
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V v_ce_240, V v_live_241, V v_xs_242, V v_t_243, V v_fv_244) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_xs_242)));
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_fv_244)));
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2, 1, 2, (V[]){heff_dup(v_ce_240), v_live_241}), heff_dup(v_fv_244)));
  V v_t_2419 = (g_list_2efoldl_24f1419248316x13095286(NTAG(TAG_Nil), heff_dup(v_xs_242), heff_dup(v_fv_244)));
  V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3, 2, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  V v_wanted_2424 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_243)));
  V v_xs_2427 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4, 1, 1, (V[]){v_wanted_2424}), heff_dup(v_xs_242)));
  V v_t_2433 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2427));
  V v_t_2434 = (g_list_2emap_24s1901363476x1479927424(v_t_2433));
  V v_t_2435 = (g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(v_ce_240, v_xs_242, v_t_243, v_fv_244));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2435));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2436));
  return heff_tag_n(TAG_RLam, 4, (V[]){v_t_2410, v_t_2416, v_t_2418, heff_tag_n(TAG_MkCode, 1, (V[]){v_t_2437})});
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str0), v_x_245);
    } else {
      heff_drop(v_field_248);
      return v_x_245;
    }
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2414;
      heff_drop(v_x_2415);
      return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str1), v_x_2411);
    } else {
      heff_drop(v_field_2414);
      return v_x_2411;
    }
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), heff_tag_n(TAG_SVar, 1, (V[]){v_x_2417})));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_x_2421 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = ({ V a_0 = v_ce_240; V b_1 = NTAG(TAG_False); V a_2 = v_x_2421; V r_ = (g_heff_2ecompile_2erefcount_2eunboxParam(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return (g_prelude_2e_2b_2b(v_t_2422, v_acc_2420));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4(V self, V *args) {
  V v_v_2425 = args[0];
  V v_wanted_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2426 = ({ V a_0 = v_v_2425; V a_1 = v_wanted_2424; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2425); heff_drop(v_wanted_2424); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
  heff_drop(v_x1_2426);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2429 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2428; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2428); r_; });
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2430 == ((int64_t)0ULL)) ? ({ V v_x_2432 = heff_dup(v_field_2431); int c_ = 0; heff_drop(v_x_2432); c_; }) : 1));
    heff_drop(v_field_2431);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_rp_245, V v_e_246, V v_es_247) {
top: ;
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    return (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(v_ce_240, v_live_241, v_before_242, v_bi_243, v_i_244, v_e_246, v_es_247));
  }
  case TAG_RepFix: {
    heff_drop(v_i_244);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_live_241));
    V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2412, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2413});
  }
  case TAG_RepF64: {
    heff_drop(v_i_244);
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, v_live_241));
    V v_live_2417 = (g_prelude_2e_2b_2b(v_before_242, v_t_2416));
    V v_t_2418 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2417, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2418});
  }
  case TAG_RepInt: {
    heff_drop(v_i_244);
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2420, v_live_241));
    V v_live_2422 = (g_prelude_2e_2b_2b(v_before_242, v_t_2421));
    V v_t_2423 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2422, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2423});
  }
  default: return heff_nomatch(v_rp_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_248 = heff_field(v_x7_245, 0);
    V v_rps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_rp_248);
      heff_drop(v_rps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), v_rp_248, heff_dup(v_e_2410), heff_dup(v_es_2411)));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V v_t_2415 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2415;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_rps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2413;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(V v_ce0_240, V v_held_241, V v_lent_242, V v_t_243, V v_vs_244, V v_b_245) {
top: ;
  V v_n_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_ce_248;
  switch (heff_tag_of(v_held_241)) {
  case TAG_Nothing: {
    heff_drop(v_n_246);
    v_ce_248 = v_ce0_240;
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_dup(heff_field(v_held_241, 0));
    v_ce_248 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_x_247, heff_tag_n(TAG_KnownTag, 1, (V[]){v_n_246}), v_ce0_240));
    break;
  }
  default: heff_nomatch(v_held_241);
  }
  V v_fb_2411;
  switch (heff_tag_of(v_b_245)) {
  case TAG_ATail: {
    V v_t_249 = heff_dup(heff_field(v_b_245, 0));
    v_fb_2411 = (g_heff_2ecompile_2erefcount_2efvTl(v_t_249));
    break;
  }
  case TAG_ASts: {
    V v_ss_2410 = heff_dup(heff_field(v_b_245, 0));
    v_fb_2411 = (g_heff_2ecompile_2erefcount_2efvSts(v_ss_2410));
    break;
  }
  default: heff_nomatch(v_b_245);
  }
  V v_taken_2412 = (g_heff_2ecompile_2erefcount_2etakenFv(heff_dup(v_ce_248), v_held_241, v_vs_244, v_fb_2411));
  V v_t_2415;
  switch (heff_tag_of(v_b_245)) {
  case TAG_ATail: {
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  case TAG_ASts: {
    v_t_2415 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_b_245);
  }
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2ereusing(heff_dup(heff_rfield(v_ce_248, 15)), heff_dup(v_taken_2412), heff_dup(v_t_243), v_vs_244, v_b_245));
  return ({ V a_0 = v_ce_248; V a_1 = v_taken_2412; V a_2 = v_lent_242; V a_3 = v_t_243; V a_4 = v_vs_244; V a_5 = v_fb_2411; V a_6 = v_t_2415; V a_7 = v_t_2416; V r_ = (g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_taken_2412); r_; });
}
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V v_ce_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_st_241)) {
  case TAG_SLet: {
    V v_ru_24st_241_24SLet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24st_241_24SLet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SDecl: {
    heff_take_n(v_st_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SSet: {
    V v_ru_24st_241_24SSet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24st_241_24SSet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SIf: {
    V v_st1_247 = heff_field(v_st_241, 0);
    V v_ts_248 = heff_field(v_st_241, 1);
    V v_fs_249 = heff_field(v_st_241, 2);
    V v_ru_24st_241_24SIf = heff_take_reuse_n(v_st_241, 7ULL, 3);
    switch (heff_tag_of(v_st1_247)) {
    case TAG_PTrue: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PFalse: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PRel: {
      V v_p_2410 = heff_field(v_st1_247, 0);
      V v_a_2411 = heff_field(v_st1_247, 1);
      V v_b_2412 = heff_field(v_st1_247, 2);
      heff_take_n(v_st1_247, 7ULL, 3);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2412), NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2412, NTAG(TAG_Nil)});
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2411), v_t_2414})));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ts_248)));
      V v_t_2418 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_fs_249)));
      V v_t_2419 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2417, v_t_2418));
      return ({ V a_0 = v_ru_24st_241_24SIf; V a_1 = v_ce_240; V a_2 = v_p_2410; V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, v_t_2413}); V b_4 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_5 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V a_6 = v_t_2416; V a_7 = v_t_2419; V r_ = (g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(a_0, a_1, a_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_4); heff_drop(b_5); r_; });
    }
    case TAG_PBool: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PNot: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PIf: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PLet: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_st1_247);
    }
  }
  case TAG_SCase: {
    V v_v_2428 = heff_field(v_st_241, 0);
    V v_arms_2429 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SCase = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24s471405029x78128406(v_arms_2429));
    V v_t_2431 = (g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(v_ce_240, NTAG(TAG_False), v_v_2428, v_t_2430));
    return heff_tag_at_n(v_ru_24st_241_24SCase, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_st_241);
  }
}
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1(V v_tok_240, V v_ce_241, V v_live_242, V v_e_243, V v_i_244, V v_n_245, V v_may_246) {
top: ;
  V v_t_2430;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SVar: {
    V v_x_247 = heff_dup(heff_field(v_e_243, 0));
    v_t_2430 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_x_247});
    break;
  }
  case TAG_SGlobal: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SInt: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_243);
  }
  V v_t_2454;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SVar: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SGlobal: {
    V v_g_2432 = heff_dup(heff_field(v_e_243, 0));
    v_t_2454 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2432});
    break;
  }
  case TAG_SInt: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2454 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_243);
  }
  return (g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(v_ce_241, v_live_242, v_e_243, v_i_244, v_n_245, v_may_246, v_t_2430, v_t_2454));
}
V g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ecompile_2erefcount_2efieldAt_24s991913401x1677214928_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
Clo g_heff_2ecompile_2erefcount_2efvSts_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2efvSts_24tok1(V v_tok_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_ISts, 1, (V[]){v_ss_241}), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_bs_246 = v_field_244;
    V v_ms_247 = v_field_245;
    V v_bs_248 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_246));
    V v_ms_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
    V v_t_2410 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_248); r_; });
    return ({ V a_0 = v_t_2410; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_249; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvSts_24tok1(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_str1, 4, "box$");
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1(V v_tok_240, V v_ce_241, V v_live_242, V v_xs_243, V v_t_244, V v_fv_245) {
top: ;
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam0, 1, 1, (V[]){heff_dup(v_ce_241)}), heff_dup(v_xs_243)));
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam1, 1, 1, (V[]){heff_dup(v_ce_241)}), heff_dup(v_fv_245)));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam2, 1, 2, (V[]){heff_dup(v_ce_241), v_live_242}), heff_dup(v_fv_245)));
  V v_t_2420 = (g_list_2efoldl_24f1419248316x13095286(NTAG(TAG_Nil), heff_dup(v_xs_243), heff_dup(v_fv_245)));
  V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam3, 2, 1, (V[]){heff_dup(v_ce_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  V v_wanted_2425 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_244)));
  V v_xs_2428 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam4, 1, 1, (V[]){v_wanted_2425}), heff_dup(v_xs_243)));
  V v_t_2434 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam5, 1, 1, (V[]){heff_dup(v_ce_241)}), v_xs_2428));
  V v_t_2435 = (g_list_2emap_24s1901363476x1479927424(v_t_2434));
  V v_t_2436 = (g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(v_ce_241, v_xs_243, v_t_244, v_fv_245));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2436));
  V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2437));
  return heff_tag_n(TAG_RLam, 4, (V[]){v_t_2411, v_t_2417, v_t_2419, heff_tag_at_n(v_tok_240, TAG_MkCode, 1, (V[]){v_t_2438})});
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_ce_241, 10, 17); V a_1 = v_x_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      heff_drop(v_x_2410);
      return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_str0), v_x_246);
    } else {
      heff_drop(v_field_249);
      return v_x_246;
    }
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2413 = ({ V b_0 = heff_get_n(v_ce_241, 10, 17); V a_1 = v_x_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2415;
      heff_drop(v_x_2416);
      return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_str1), v_x_2412);
    } else {
      heff_drop(v_field_2415);
      return v_x_2412;
    }
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ce_241 = heff_env(self)[0];
  V v_live_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_241, v_live_242, NTAG(TAG_RepV), heff_tag_n(TAG_SVar, 1, (V[]){v_x_2418})));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam3(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_x_2422 = args[1];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = ({ V a_0 = v_ce_241; V b_1 = NTAG(TAG_False); V a_2 = v_x_2422; V r_ = (g_heff_2ecompile_2erefcount_2eunboxParam(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return (g_prelude_2e_2b_2b(v_t_2423, v_acc_2421));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam4(V self, V *args) {
  V v_v_2426 = args[0];
  V v_wanted_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2427 = ({ V a_0 = v_v_2426; V a_1 = v_wanted_2425; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2426); heff_drop(v_wanted_2425); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2427) == NTAG(TAG_True)));
  heff_drop(v_x1_2427);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_24tok1_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2430 = ({ V b_0 = heff_get_n(v_ce_241, 10, 17); V a_1 = v_x_2429; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2429); r_; });
  {
    V v_field_2432 = v_t_2430.f[1];
    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2431 == ((int64_t)0ULL)) ? ({ V v_x_2433 = heff_dup(v_field_2432); int c_ = 0; heff_drop(v_x_2433); c_; }) : 1));
    heff_drop(v_field_2432);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2erefcount_2estrAs_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estrAs_24tok1_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2estrAs_24tok1(V v_tok_240, V v_x1_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_RepV: {
    return heff_tag_at_n(v_tok_240, TAG_RStr, 1, (V[]){v_s_242});
  }
  case TAG_RepFix: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    heff_drop(v_s_242);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_I8: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_I16: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_I32: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_I64: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_U8: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_U16: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_U32: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_U64: {
      heff_drop_cell(v_tok_240, 1);
      return heff_tag_n(TAG_RFixU, 2, (V[]){v_x11_243, MK_INT(0LL)});
    }
    case TAG_F32: {
      return heff_tag_at_nf(v_tok_240, TAG_RF32U, 1, 1u, (V[]){heff_word_f64((0.0))});
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  case TAG_RepF64: {
    heff_drop(v_s_242);
    return heff_tag_at_nf(v_tok_240, TAG_RF64U, 1, 1u, (V[]){heff_word_f64((0.0))});
  }
  case TAG_RepInt: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_s_242);
    return heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), MK_INT(0LL)});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2erefcount_2estrAs_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2estrAs_24tok1(a[0], a[1], a[2]);
}