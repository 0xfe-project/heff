// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_MkCode 2932
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RApply 9191
#define TAG_RBox 28228
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RGet 32719
#define TAG_RGetRaw 14078
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RPeek 36757
#define TAG_RUnbox 59387
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_after 294093302
#define LBL_body 9524841
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_n 328
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sts 323756
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
V g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646(V, V);
V g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_clo;
V g_heff_2ecompile_2erefcount_2eboolName_get(void);
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvArm(V);
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvArm_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintAt(V, V);
V g_heff_2ecompile_2erefcount_2eintAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintAt_clo;
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2ematchAt(V, V);
V g_heff_2ecompile_2erefcount_2ematchAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchAt_clo;
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo;
V g_heff_2ecompile_2erefcount_2enotFlatAt(V, V, V);
V g_heff_2ecompile_2erefcount_2enotFlatAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enotFlatAt_clo;
V g_heff_2ecompile_2erefcount_2enthValue(V, V);
V g_heff_2ecompile_2erefcount_2enthValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enthValue_clo;
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eothersW(V, V, V);
V g_heff_2ecompile_2erefcount_2eothersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eothersW_clo;
V g_heff_2ecompile_2erefcount_2epartsThen(V, V);
V g_heff_2ecompile_2erefcount_2epartsThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epartsThen_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereusing(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusing_clo;
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2etaggedArg(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etaggedArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etaggedArg_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakesAt_clo;
V g_heff_2ecompile_2erefcount_2etokenK(V, V, V);
V g_heff_2ecompile_2erefcount_2etokenK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenK_clo;
V g_heff_2ecompile_2erefcount_2etokenRound(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenRound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenRound_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewrapArg(V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapArg_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1982386833x551161312(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1982386833x551161312_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithFrame_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithFrame(V v_s_240, V v_n_241, V v_ce_242) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_s_240)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_s_243 = heff_dup(heff_field(v_s_240, 0));
    HeffT2 v_t_244 = ({ V a_0 = heff_rfield(v_ce_242, 11); V b_1 = heff_get_n(v_s_243, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_s_247 = v_field_246;
        v_t_248 = heff_get_n(v_s_247, 1, 2);
      } else {
        heff_drop(v_field_246);
        v_t_248 = NTAG(TAG_RepV);
      }
    }
    break;
  }
  default: heff_nomatch(v_s_240);
  }
  return ({ V rv_2 = v_s_240; V rv_3 = v_n_241; V rv_9 = NTAG(TAG_Nil); V rv_16 = v_t_248; V rr_ = heff_rec_reuse_nf(v_ce_242, 65011ULL, 17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, 4294180623u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 16) = rv_16; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithFrame(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2eslotBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eslotBits_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2eslotBits(V v_rps_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rps_240));
  V v_t_242 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_241, MK_INT(1LL))));
  V v_ps_243 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_242, v_rps_240));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = MK_INT(0LL); V a_13 = v_ps_243; V r_ = (g_list_2efoldl_24s1982386833x551161312(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_ps_243); r_; });
}
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eslotBits(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str0, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str2, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str4, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str5, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str7, 0, "");
Clo g_heff_2ecompile_2erefcount_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereusing_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ereusing(V v_tk_240, V v_x2_241, V v_t_242, V v_vs_243, V v_b_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_tk_240);
    heff_drop(v_t_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_244});
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_242, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_242, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      heff_drop(v_tk_240);
      heff_drop(v_t_242);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_244});
    } else {
      V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str0), heff_dup(v_x_245)), ((V)&g_heff_2ecompile_2erefcount_2ereusing_str1));
      V v_ru_247 = heff_strAppend(v_t_246, heff_dup(v_t_242));
      V v_n_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str2), heff_dup(v_x_245)), ((V)&g_heff_2ecompile_2erefcount_2ereusing_str3));
      V v_ru_2410 = heff_strAppend(v_t_249, heff_dup(v_t_242));
      V v_n_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
      V v_b_2412 = heff_dup(v_b_244);
      V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str4), v_x_245), ((V)&g_heff_2ecompile_2erefcount_2ereusing_str5));
      V v_ru_2414 = heff_strAppend(v_t_2413, heff_dup(v_t_242));
      V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
      V v_n_2416 = heff_rec_n(2, shape_n__tag, (V[]){v_t_2415, v_t_242});
      V v_x4_2429;
      switch (heff_tag_of(v_b_244)) {
      case TAG_ATail: {
        V v_t_2417 = heff_field(v_b_244, 0);
        V v_ru_24b_244_24ATail = heff_take_reuse_n(v_b_244, 1ULL, 1);
        HeffT2 v_t_2418 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_2414, v_n_2416, v_t_2417));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_b_2421 = v_field_2419;
          V v_t2_2422 = v_field_2420;
          v_x4_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2421, heff_tag_at_n(v_ru_24b_244_24ATail, TAG_ATail, 1, (V[]){v_t2_2422})});
        }
        break;
      }
      case TAG_ASts: {
        V v_ss_2423 = heff_field(v_b_244, 0);
        V v_ru_24b_244_24ASts = heff_take_reuse_n(v_b_244, 1ULL, 1);
        HeffT2 v_t_2424 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_2414, v_n_2416, v_ss_2423));
        {
          V v_field_2425 = v_t_2424.f[0];
          V v_field_2426 = v_t_2424.f[1];
          V v_b_2427 = v_field_2425;
          V v_ss2_2428 = v_field_2426;
          v_x4_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2427, heff_tag_at_n(v_ru_24b_244_24ASts, TAG_ASts, 1, (V[]){v_ss2_2428})});
        }
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      V v_x4_2444;
      switch (heff_tag_of(v_x4_2429)) {
      case TAG_MkPair: {
        V v_x41_2430 = heff_field(v_x4_2429, 0);
        V v_b1_2431 = heff_field(v_x4_2429, 1);
        V v_ru_24x4_2429_24MkPair = heff_take_reuse_n(v_x4_2429, 3ULL, 2);
        if ((heff_dup(v_x41_2430) == NTAG(TAG_True))) {
          heff_drop(v_n_2411);
          heff_drop(v_b_2412);
          heff_drop(v_x41_2430);
          v_x4_2444 = heff_tag_at_n(v_ru_24x4_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_ru_2410}), v_b1_2431});
        } else {
          heff_drop(v_x41_2430);
          heff_drop(v_b1_2431);
          switch (heff_tag_of(v_b_2412)) {
          case TAG_ATail: {
            V v_t_2432 = heff_dup(heff_field(v_b_2412, 0));
            HeffT2 v_t_2433 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_ru_2410), heff_rec_n(2, shape_n__tag, (V[]){v_n_2411, ((V)&g_heff_2ecompile_2erefcount_2ereusing_str6)}), v_t_2432));
            {
              V v_field_2434 = v_t_2433.f[0];
              V v_field_2435 = v_t_2433.f[1];
              V v_b_2436 = v_field_2434;
              V v_t2_2437 = v_field_2435;
              if ((heff_dup(v_b_2436) == NTAG(TAG_True))) {
                heff_drop_tag(v_b_2412, 1);
                heff_drop(v_b_2436);
                v_x4_2444 = heff_tag_at_n(v_ru_24x4_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_ru_2410}), heff_tag_n(TAG_ATail, 1, (V[]){v_t2_2437})});
              } else {
                heff_drop_cell(v_ru_24x2_241_24Just, 1);
                heff_drop(v_ru_2410);
                heff_drop(v_b_2436);
                heff_drop(v_t2_2437);
                v_x4_2444 = heff_tag_at_n(v_ru_24x4_2429_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_2412});
              }
            }
            break;
          }
          case TAG_ASts: {
            V v_ss_2438 = heff_dup(heff_field(v_b_2412, 0));
            HeffT2 v_t_2439 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(heff_dup(v_ru_2410), heff_rec_n(2, shape_n__tag, (V[]){v_n_2411, ((V)&g_heff_2ecompile_2erefcount_2ereusing_str7)}), v_ss_2438));
            {
              V v_field_2440 = v_t_2439.f[0];
              V v_field_2441 = v_t_2439.f[1];
              V v_b_2442 = v_field_2440;
              V v_ss2_2443 = v_field_2441;
              if ((heff_dup(v_b_2442) == NTAG(TAG_True))) {
                heff_drop_tag(v_b_2412, 1);
                heff_drop(v_b_2442);
                v_x4_2444 = heff_tag_at_n(v_ru_24x4_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_ru_2410}), heff_tag_n(TAG_ASts, 1, (V[]){v_ss2_2443})});
              } else {
                heff_drop_cell(v_ru_24x2_241_24Just, 1);
                heff_drop(v_ru_2410);
                heff_drop(v_b_2442);
                heff_drop(v_ss2_2443);
                v_x4_2444 = heff_tag_at_n(v_ru_24x4_2429_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_2412});
              }
            }
            break;
          }
          default: heff_nomatch(v_b_2412);
          }
        }
        break;
      }
      default: heff_nomatch(v_x4_2429);
      }
      switch (heff_tag_of(v_x4_2444)) {
      case TAG_MkPair: {
        V v_m_2445 = heff_field(v_x4_2444, 0);
        V v_b_2446 = heff_field(v_x4_2444, 1);
        V v_ru_24x4_2444_24MkPair = heff_take_reuse_n(v_x4_2444, 3ULL, 2);
        V v_tk_2447 = v_tk_240;
        V v_ru_2448 = heff_dup(v_ru_247);
        V v_n_2449 = v_n_248;
        V v_x4_2450 = heff_dup(v_b_2446);
        V v_it_2463;
        switch (heff_tag_of(v_x4_2450)) {
        case TAG_ATail: {
          V v_t_2451 = heff_field(v_x4_2450, 0);
          V v_ru_24x4_2450_24ATail = heff_take_reuse_n(v_x4_2450, 1ULL, 1);
          V v_t_2452 = heff_tr(g_heff_2ecompile_2erefcount_2etokenRound(v_tk_2447, v_ru_2448, v_n_2449, v_t_2451));
          switch (heff_tag_of(v_t_2452)) {
          case TAG_MkPair: {
            V v_b_2453 = heff_field(v_t_2452, 0);
            V v_t2_2454 = heff_field(v_t_2452, 1);
            heff_take_n(v_t_2452, 3ULL, 2);
            v_it_2463 = heff_tag_at_n(v_ru_24x4_2444_24MkPair, TAG_MkPair, 2, (V[]){v_b_2453, heff_tag_at_n(v_ru_24x4_2450_24ATail, TAG_ATail, 1, (V[]){v_t2_2454})});
            break;
          }
          default: heff_nomatch(v_t_2452);
          }
          break;
        }
        case TAG_ASts: {
          V v_ss_2455 = heff_field(v_x4_2450, 0);
          V v_ru_24x4_2450_24ASts = heff_take_reuse_n(v_x4_2450, 1ULL, 1);
          V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_2455)));
          V v_t_2457 = (g_list_2efoldl_24s2003609603x1707519208(NTAG(TAG_Nil), v_t_2456));
          V v_t_2458 = ({ V a_0 = v_ru_2448; V a_1 = v_t_2457; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_t_2457); r_; });
          if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
            heff_drop(v_tk_2447);
            heff_drop(v_ru_2448);
            heff_drop(v_n_2449);
            heff_drop(v_t_2458);
            v_it_2463 = heff_tag_at_n(v_ru_24x4_2444_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), heff_tag_at_n(v_ru_24x4_2450_24ASts, TAG_ASts, 1, (V[]){v_ss_2455})});
          } else {
            heff_drop(v_t_2458);
            V v_t_2459 = (g_heff_2ecompile_2erefcount_2etokenK(v_tk_2447, v_ru_2448, v_n_2449));
            V v_t_2460 = heff_tr(heff_call(heff_get_n(v_t_2459, 0, 2), 1, (V[]){v_ss_2455}));
            switch (heff_tag_of(v_t_2460)) {
            case TAG_MkPair: {
              V v_b_2461 = heff_field(v_t_2460, 0);
              V v_ss2_2462 = heff_field(v_t_2460, 1);
              heff_take_n(v_t_2460, 3ULL, 2);
              v_it_2463 = heff_tag_at_n(v_ru_24x4_2444_24MkPair, TAG_MkPair, 2, (V[]){v_b_2461, heff_tag_at_n(v_ru_24x4_2450_24ASts, TAG_ASts, 1, (V[]){v_ss2_2462})});
              break;
            }
            default: heff_nomatch(v_t_2460);
            }
          }
          break;
        }
        default: heff_nomatch(v_x4_2450);
        }
        switch (heff_tag_of(v_it_2463)) {
        case TAG_MkPair: {
          V v_it1_2464 = heff_field(v_it_2463, 0);
          V v_b2_2465 = heff_field(v_it_2463, 1);
          V v_ru_24it_2463_24MkPair = heff_take_reuse_n(v_it_2463, 3ULL, 2);
          if ((heff_dup(v_it1_2464) == NTAG(TAG_True))) {
            heff_drop(v_m_2445);
            heff_drop(v_b_2446);
            heff_drop(v_it1_2464);
            return heff_tag_at_n(v_ru_24it_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_ru_247}), v_b2_2465});
          } else {
            heff_drop(v_ru_247);
            heff_drop(v_it1_2464);
            heff_drop(v_b2_2465);
            return heff_tag_at_n(v_ru_24it_2463_24MkPair, TAG_MkPair, 2, (V[]){v_m_2445, v_b_2446});
          }
        }
        default: return heff_nomatch(v_it_2463);
        }
      }
      default: return heff_nomatch(v_x4_2444);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2ereusing(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakesAt_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etakesAt(V v_ce_240, V v_before_241, V v_after_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_before_241);
    heff_drop(v_after_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_ce_246 = heff_dup(v_ce_240);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_rest_248 = (g_list_2efoldl_24s1203202837x1639358108(heff_dup(v_after_242), v_t_247));
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_before_241)));
    V v_rest_2410 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_248, v_t_249));
    V v_x3_2411 = heff_dup(v_e_244);
    V v_t_2474;
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_SVar: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SInt: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SFloat: {
      heff_take_na(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SStr: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SBytes: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SFixed: {
      heff_take_n(v_x3_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SFloat32: {
      heff_take_na(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_x3_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_x3_2411, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_x3_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    case TAG_SProj: {
      V v_e_2429 = heff_field(v_x3_2411, 0);
      V v_l_2430 = heff_field(v_x3_2411, 1);
      V v_sh_2431 = heff_field(v_x3_2411, 2);
      V v_t_2432 = heff_field(v_x3_2411, 3);
      heff_take_n(v_x3_2411, 15ULL, 4);
      V v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2ecompile_2erepr_2emayBeFlat(a_0)); heff_drop(v_t_2432); r_; });
      if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_ce_246);
        heff_drop(v_rest_2410);
        heff_drop(v_e_2429);
        heff_drop(v_l_2430);
        heff_drop(v_sh_2431);
        heff_drop(v_t_2433);
        v_t_2474 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2433);
        V v_ce_2434 = v_ce_246;
        V v_owned_2435 = heff_take_field(v_ce_2434, 4);
        V v_borrowed_2436 = heff_take_field(v_ce_2434, 6);
        V v_after_2437 = heff_get_n(v_ce_2434, 5, 17);
        V v_rest_2438 = v_rest_2410;
        V v_x3_2462;
        switch (heff_tag_of(v_e_2429)) {
        case TAG_SVar: {
          V v_x_2439 = heff_field(v_e_2429, 0);
          V v_ru_24e_2429_24SVar = heff_take_reuse_n(v_e_2429, 1ULL, 1);
          v_x3_2462 = heff_tag_at_n(v_ru_24e_2429_24SVar, TAG_Just, 1, (V[]){v_x_2439});
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SInt: {
          heff_take_n(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SFloat: {
          heff_take_na(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SStr: {
          heff_take_n(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SBytes: {
          heff_take_n(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SFixed: {
          heff_take_n(v_e_2429, 0ULL, 2);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SFloat32: {
          heff_take_na(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SPrimFn: {
          heff_take_n(v_e_2429, 0ULL, 1);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SLam: {
          heff_take_n(v_e_2429, 0ULL, 2);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_STag: {
          heff_take_n(v_e_2429, 0ULL, 3);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SRec: {
          heff_take_n(v_e_2429, 0ULL, 2);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SProj: {
          heff_take_n(v_e_2429, 0ULL, 4);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SPrim: {
          heff_take_n(v_e_2429, 0ULL, 2);
          v_x3_2462 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_e_2429);
        }
        V v_l_2463 = v_l_2430;
        V v_sh_2464 = v_sh_2431;
        switch (heff_tag_of(v_x3_2462)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_owned_2435);
          heff_drop(v_borrowed_2436);
          heff_drop(v_after_2437);
          heff_drop(v_rest_2438);
          heff_drop(v_l_2463);
          heff_drop(v_sh_2464);
          v_t_2474 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2465 = heff_field(v_x3_2462, 0);
          heff_take_n(v_x3_2462, 1ULL, 1);
          switch (heff_tag_of(v_sh_2464)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            heff_drop(v_owned_2435);
            heff_drop(v_borrowed_2436);
            heff_drop(v_after_2437);
            heff_drop(v_rest_2438);
            heff_drop(v_l_2463);
            heff_drop(v_x_2465);
            v_t_2474 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_ru_24sh_2464_24Cons = heff_take_reuse_n(v_sh_2464, 0ULL, 2);
            V v_t_2468 = ({ V a_0 = v_x_2465; V a_1 = v_owned_2435; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_owned_2435); r_; });
            if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
              heff_drop(v_t_2468);
              V v_x1_2469 = ({ V a_0 = v_x_2465; V a_1 = v_borrowed_2436; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_2436); r_; });
              if (!(heff_dup(v_x1_2469) == NTAG(TAG_True))) {
                heff_drop(v_x1_2469);
                V v_x1_2470 = ({ V a_0 = v_x_2465; V a_1 = v_after_2437; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_after_2437); r_; });
                if (!(heff_dup(v_x1_2470) == NTAG(TAG_True))) {
                  heff_drop(v_x1_2470);
                  V v_t_2471 = (g_heff_2ecompile_2erefcount_2eothersW(v_x_2465, v_l_2463, v_rest_2438));
                  if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
                    heff_drop(v_t_2471);
                    v_t_2474 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24sh_2464_24Cons, TAG_MkPair, 2, (V[]){v_x_2465, v_l_2463}), NTAG(TAG_Nil)});
                  } else {
                    heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                    heff_drop(v_l_2463);
                    heff_drop(v_x_2465);
                    heff_drop_cell(v_ru_24sh_2464_24Cons, 2);
                    heff_drop(v_t_2471);
                    v_t_2474 = NTAG(TAG_Nil);
                  }
                } else {
                  heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                  heff_drop(v_rest_2438);
                  heff_drop(v_l_2463);
                  heff_drop(v_x_2465);
                  heff_drop_cell(v_ru_24sh_2464_24Cons, 2);
                  heff_drop(v_x1_2470);
                  v_t_2474 = NTAG(TAG_Nil);
                }
              } else {
                heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                heff_drop(v_after_2437);
                heff_drop(v_rest_2438);
                heff_drop(v_l_2463);
                heff_drop(v_x_2465);
                heff_drop_cell(v_ru_24sh_2464_24Cons, 2);
                heff_drop(v_x1_2469);
                v_t_2474 = NTAG(TAG_Nil);
              }
            } else {
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              heff_drop(v_borrowed_2436);
              heff_drop(v_after_2437);
              heff_drop(v_rest_2438);
              heff_drop(v_l_2463);
              heff_drop(v_x_2465);
              heff_drop_cell(v_ru_24sh_2464_24Cons, 2);
              heff_drop(v_t_2468);
              v_t_2474 = NTAG(TAG_Nil);
            }
            break;
          }
          default: heff_nomatch(v_sh_2464);
          }
          break;
        }
        default: heff_nomatch(v_x3_2462);
        }
      }
      break;
    }
    case TAG_SPrim: {
      heff_take_n(v_x3_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_ce_246);
      heff_drop(v_rest_2410);
      v_t_2474 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x3_2411);
    }
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    V v_t_2476 = (g_prelude_2e_2b_2b(v_before_241, v_t_2475));
    V v_t_2477 = (g_heff_2ecompile_2erefcount_2etakesAt(v_ce_240, v_t_2476, v_after_242, v_es_245));
    return (g_prelude_2e_2b_2b(v_t_2474, v_t_2477));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etakesAt(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_it_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2erefcount_2ematchAt(v_lit_240, v_it_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_it_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2erefcount_2epartsThen(v_it_242, v_rest_243));
      V t_0 = v_lit_240;
      V t_1 = v_t_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2enotFlatAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2enotFlatAt_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2enotFlatAt(V v_x1_240, V v_x_241, V v_it_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_243 = (g_heff_2ecompile_2erefcount_2eintAt(heff_dup(v_x_241), v_it_242));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop(v_it_242);
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      return ({ V a_0 = v_x_241; V a_1 = v_it_242; V r_ = (g_heff_2ecompile_2erefcount_2ematchAt(a_0, a_1)); heff_drop(v_x_241); heff_drop(v_it_242); r_; });
    }
  }
  case TAG_Just: {
    V v_s_244 = heff_field(v_x1_240, 0);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2eintAt(heff_dup(v_x_241), v_it_242));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop(v_it_242);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecompile_2erefcount_2ematchAt(v_x_241, v_it_242));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_x_241);
        heff_drop(v_it_242);
        heff_drop(v_t_246);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_246);
        V v_s_247 = heff_dup(v_s_244);
        V v_key_248 = heff_take_field(v_s_247, 0);
        V v_body_249 = heff_take_field(v_s_247, 2);
        V v_params_2410 = heff_get_n(v_s_247, 1, 3);
        V v_x_2411 = v_x_241;
        V v_x3_2412 = v_it_242;
        switch (heff_tag_of(v_x3_2412)) {
        case TAG_IVal: {
          heff_take_n(v_x3_2412, 0ULL, 1);
          heff_drop(v_key_248);
          heff_drop(v_body_249);
          heff_drop(v_params_2410);
          heff_drop(v_x_2411);
          return NTAG(TAG_False);
        }
        case TAG_IOp: {
          V v_x31_2414 = heff_field(v_x3_2412, 0);
          heff_take_n(v_x3_2412, 1ULL, 1);
          switch (heff_tag_of(v_x31_2414)) {
          case TAG_OSimple: {
            heff_take_n(v_x31_2414, 0ULL, 1);
            heff_drop(v_key_248);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_OCall: {
            V v_g_2416 = heff_field(v_x31_2414, 0);
            V v_argv_2417 = heff_field(v_x31_2414, 1);
            heff_take_n(v_x31_2414, 3ULL, 2);
            if (heff_strEq_c(v_g_2416, v_key_248)) {
              return ({ V a_0 = v_body_249; V a_1 = v_x_2411; V a_2 = v_params_2410; V a_3 = v_argv_2417; V r_ = (g_heff_2ecompile_2erefcount_2etaggedArg(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
            } else {
              heff_drop(v_body_249);
              heff_drop(v_params_2410);
              heff_drop(v_x_2411);
              heff_drop(v_argv_2417);
              return NTAG(TAG_False);
            }
          }
          case TAG_OApply: {
            heff_take_n(v_x31_2414, 0ULL, 2);
            heff_drop(v_key_248);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_OPrim: {
            heff_take_n(v_x31_2414, 0ULL, 2);
            heff_drop(v_key_248);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_OAbandon: {
            heff_drop(v_key_248);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_OBool: {
            heff_take_n(v_x31_2414, 0ULL, 1);
            heff_drop(v_key_248);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x31_2414);
          }
        }
        case TAG_ICond: {
          heff_take_n(v_x3_2412, 0ULL, 1);
          heff_drop(v_key_248);
          heff_drop(v_body_249);
          heff_drop(v_params_2410);
          heff_drop(v_x_2411);
          return NTAG(TAG_False);
        }
        case TAG_ISts: {
          heff_take_n(v_x3_2412, 0ULL, 1);
          heff_drop(v_key_248);
          heff_drop(v_body_249);
          heff_drop(v_params_2410);
          heff_drop(v_x_2411);
          return NTAG(TAG_False);
        }
        case TAG_ITl: {
          V v_x31_2425 = heff_field(v_x3_2412, 0);
          heff_take_n(v_x3_2412, 1ULL, 1);
          heff_drop(v_key_248);
          switch (heff_tag_of(v_x31_2425)) {
          case TAG_TSeq: {
            heff_take_n(v_x31_2425, 0ULL, 2);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_TReturn: {
            heff_take_n(v_x31_2425, 0ULL, 1);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_TLoop: {
            V v_vs_2429 = heff_field(v_x31_2425, 0);
            heff_take_n(v_x31_2425, 1ULL, 1);
            return ({ V a_0 = v_body_249; V a_1 = v_x_2411; V a_2 = v_params_2410; V a_3 = v_vs_2429; V r_ = (g_heff_2ecompile_2erefcount_2etaggedArg(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
          }
          case TAG_TIf: {
            heff_take_n(v_x31_2425, 0ULL, 3);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          case TAG_TCase: {
            heff_take_n(v_x31_2425, 0ULL, 2);
            heff_drop(v_body_249);
            heff_drop(v_params_2410);
            heff_drop(v_x_2411);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x31_2425);
          }
        }
        default: return heff_nomatch(v_x3_2412);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2enotFlatAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2enotFlatAt(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eboolName_str0, 8, "ret$bool");

static V g_heff_2ecompile_2erefcount_2eboolName_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2eboolName_st;
static V g_heff_2ecompile_2erefcount_2eboolName_init(void) {
  return ((V)&g_heff_2ecompile_2erefcount_2eboolName_str0);
}
V g_heff_2ecompile_2erefcount_2eboolName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2eboolName_st)) return g_heff_2ecompile_2erefcount_2eboolName_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2eboolName_val, &g_heff_2ecompile_2erefcount_2eboolName_st, g_heff_2ecompile_2erefcount_2eboolName_init);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapArg_str0, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2ewrapArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewrapArg_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewrapArg(V v_ce_240, V v_rp_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_rp_241)) {
  case TAG_RepV: {
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_247;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        heff_drop(v_x_246);
        v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapArg_str0), v_x_242);
      } else {
        heff_drop(v_field_245);
        v_t_247 = v_x_242;
      }
    }
    return heff_tag_n(TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_t_247})});
  }
  case TAG_RepFix: {
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_241, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242})});
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_241, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242})});
  }
  case TAG_RepInt: {
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_241, heff_tag_n(TAG_RLocal, 1, (V[]){v_x_242})});
  }
  default: return heff_nomatch(v_rp_241);
  }
}
V g_heff_2ecompile_2erefcount_2ewrapArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewrapArg(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2enthValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2enthValue_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2enthValue(V v_i_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2enthValue_24cpr(v_i_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erefcount_2enthValue_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2enthValue(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str1, 4, "box$");
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam6(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam7(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V v_ce_240, V v_live_241, V v_xs_242, V v_t_243, V v_fv_244) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_xs_242)));
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_fv_244)));
  V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2, 1, 2, (V[]){heff_dup(v_ce_240), v_live_241}), heff_dup(v_fv_244)));
  V v_t_2440 = (g_list_2efoldl_24f1419248316x13095286(NTAG(TAG_Nil), heff_dup(v_xs_242), heff_dup(v_fv_244)));
  V v_t_2444 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3, 2, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2440; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){heff_dup(v_t_243)}), NTAG(TAG_Nil)});
  HeffT2 v_t_2446 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2445));
  V v_t_2462;
  {
    V v_field_2447 = v_t_2446.f[0];
    V v_field_2448 = v_t_2446.f[1];
    V v_bs_2449 = v_field_2447;
    V v_ms_2450 = v_field_2448;
    V v_ms_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2450));
    V v_t_2452 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2449; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2449); r_; });
    V v_wanted_2453 = ({ V a_0 = v_t_2452; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2451; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2452); r_; });
    V v_xs_2456 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4, 1, 1, (V[]){v_wanted_2453}), heff_dup(v_xs_242)));
    v_t_2462 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2456));
  }
  V v_t_2463 = (g_list_2emap_24s1901363476x1479927424(v_t_2462));
  V v_ce_2464 = v_ce_240;
  V v_xs_2465 = v_xs_242;
  V v_t_2466 = v_t_243;
  V v_fv_2467 = v_fv_244;
  V v_owned_2468 = (g_prelude_2e_2b_2b(heff_dup(v_xs_2465), v_fv_2467));
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){heff_dup(v_t_2466)}), NTAG(TAG_Nil)});
  HeffT2 v_t_2470 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2469));
  V v_t_2485;
  {
    V v_field_2471 = v_t_2470.f[0];
    V v_field_2472 = v_t_2470.f[1];
    V v_bs_2473 = v_field_2471;
    V v_ms_2474 = v_field_2472;
    V v_ms_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2474));
    V v_t_2476 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2473; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2473); r_; });
    V v_wanted_2477 = ({ V a_0 = v_t_2476; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2475; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2476); r_; });
    V v_xs_2479 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam6, 1, 1, (V[]){v_wanted_2477}), v_owned_2468));
    v_t_2485 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam7, 1, 1, (V[]){heff_dup(v_ce_2464)}), v_xs_2479));
  }
  V v_t_2486 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2465; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
  V v_t_2487 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), v_t_2486, v_ce_2464));
  V v_t_2488 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(NTAG(TAG_Nil), v_t_2487));
  V v_ce_2489 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2485, NTAG(TAG_Nil), v_t_2488));
  V v_t_2490 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2489, v_t_2466));
  V v_t_2491 = (g_prelude_2e_2b_2b(v_t_2463, v_t_2490));
  V v_t_2492 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2491));
  return heff_tag_n(TAG_RLam, 4, (V[]){v_t_2410, v_t_2416, v_t_2439, heff_tag_n(TAG_MkCode, 1, (V[]){v_t_2492})});
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str0), v_x_245);
    } else {
      heff_drop(v_field_248);
      return v_x_245;
    }
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2414;
      heff_drop(v_x_2415);
      return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str1), v_x_2411);
    } else {
      heff_drop(v_field_2414);
      return v_x_2411;
    }
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_lit_2418 = v_x_2417;
  V v_ce_2419 = v_ce_240;
  V v_live_2420 = v_live_241;
  V v_want_2421 = NTAG(TAG_RepV);
  HeffT2 v_t_2422 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_2419, 10), v_lit_2418));
  V v_t_2426;
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x_2425 = v_field_2424;
      v_t_2426 = v_x_2425;
    } else {
      heff_drop(v_field_2424);
      v_t_2426 = NTAG(TAG_RepV);
    }
  }
  V v_lit_2427 = v_lit_2418;
  V v_ce_2428 = v_ce_2419;
  V v_reprs_2429 = heff_take_field(v_ce_2428, 10);
  V v_borrowed_2430 = heff_get_n(v_ce_2428, 6, 17);
  V v_live_2431 = v_live_2420;
  HeffT2 v_t_2432 = ({ V a_0 = v_reprs_2429; V a_1 = v_lit_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_reprs_2429); r_; });
  V v_t_2438;
  {
    V v_field_2434 = v_t_2432.f[1];
    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
    if ((v_tag_2433 == ((int64_t)0ULL))) {
      heff_drop(v_borrowed_2430);
      heff_drop(v_live_2431);
      V v_x_2435 = v_field_2434;
      heff_drop(v_x_2435);
      v_t_2438 = heff_tag_n(TAG_RLocal, 1, (V[]){v_lit_2427});
    } else {
      heff_drop(v_field_2434);
      V v_t_2436 = ({ V a_0 = v_lit_2427; V a_1 = v_live_2431; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_2431); r_; });
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_borrowed_2430);
        heff_drop(v_t_2436);
        v_t_2438 = heff_tag_n(TAG_RDup, 1, (V[]){v_lit_2427});
      } else {
        heff_drop(v_t_2436);
        V v_t_2437 = ({ V a_0 = v_lit_2427; V a_1 = v_borrowed_2430; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_2430); r_; });
        if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
          heff_drop(v_t_2437);
          v_t_2438 = heff_tag_n(TAG_RDup, 1, (V[]){v_lit_2427});
        } else {
          heff_drop(v_t_2437);
          v_t_2438 = heff_tag_n(TAG_RLocal, 1, (V[]){v_lit_2427});
        }
      }
    }
  }
  return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2426, v_want_2421, v_t_2438));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3(V self, V *args) {
  V v_acc_2441 = args[0];
  V v_x_2442 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = ({ V a_0 = v_ce_240; V b_1 = NTAG(TAG_False); V a_2 = v_x_2442; V r_ = (g_heff_2ecompile_2erefcount_2eunboxParam(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return (g_prelude_2e_2b_2b(v_t_2443, v_acc_2441));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4(V self, V *args) {
  V v_v_2454 = args[0];
  V v_wanted_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2455 = ({ V a_0 = v_v_2454; V a_1 = v_wanted_2453; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2454); heff_drop(v_wanted_2453); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2455) == NTAG(TAG_True)));
  heff_drop(v_x1_2455);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2458 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2457; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2457); r_; });
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) ? ({ V v_x_2461 = heff_dup(v_field_2460); int c_ = 0; heff_drop(v_x_2461); c_; }) : 1));
    heff_drop(v_field_2460);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam6(V self, V *args) {
  V v_v_2478 = args[0];
  V v_wanted_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2478; V a_1 = v_wanted_2477; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2478); heff_drop(v_wanted_2477); r_; });
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam7(V self, V *args) {
  V v_x_2480 = args[0];
  V v_ce_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2481 = ({ V b_0 = heff_get_n(v_ce_2464, 10, 17); V a_1 = v_x_2480; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2480); r_; });
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2482 == ((int64_t)0ULL)) ? ({ V v_x_2484 = heff_dup(v_field_2483); int c_ = 0; heff_drop(v_x_2484); c_; }) : 1));
    heff_drop(v_field_2483);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_rp_245, V v_e_246, V v_es_247) {
top: ;
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    return (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(v_ce_240, v_live_241, v_before_242, v_bi_243, v_i_244, v_e_246, v_es_247));
  }
  case TAG_RepFix: {
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2410 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_249));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_live_241));
    V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2412, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2413});
  }
  case TAG_RepF64: {
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2415 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2414));
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, v_live_241));
    V v_live_2417 = (g_prelude_2e_2b_2b(v_before_242, v_t_2416));
    V v_t_2418 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2417, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2418});
  }
  case TAG_RepInt: {
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2420 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2419));
    V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2420, v_live_241));
    V v_live_2422 = (g_prelude_2e_2b_2b(v_before_242, v_t_2421));
    V v_t_2423 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2422, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2423});
  }
  default: return heff_nomatch(v_rp_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_248 = heff_field(v_x7_245, 0);
    V v_rps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_bi_243);
      heff_drop(v_i_244);
      heff_drop(v_rp_248);
      heff_drop(v_rps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), heff_dup(v_bi_243), heff_dup(v_i_244), v_rp_248, heff_dup(v_e_2410), heff_dup(v_es_2411)));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V v_t_2415 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2415;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_rps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2413;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V v_ce_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_st_241)) {
  case TAG_SLet: {
    V v_ru_24st_241_24SLet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24st_241_24SLet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SOnce: {
    V v_ru_24st_241_24SOnce = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24st_241_24SOnce, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SDecl: {
    heff_take_n(v_st_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SSet: {
    V v_ru_24st_241_24SSet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    return heff_tag_at_n(v_ru_24st_241_24SSet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SIf: {
    V v_st1_249 = heff_field(v_st_241, 0);
    V v_ts_2410 = heff_field(v_st_241, 1);
    V v_fs_2411 = heff_field(v_st_241, 2);
    V v_ru_24st_241_24SIf = heff_take_reuse_n(v_st_241, 7ULL, 3);
    switch (heff_tag_of(v_st1_249)) {
    case TAG_PTrue: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return (g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(v_fs_2411, v_ts_2410, v_ce_240, v_st1_249));
    }
    case TAG_PFalse: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return (g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(v_fs_2411, v_ts_2410, v_ce_240, v_st1_249));
    }
    case TAG_PRel: {
      V v_p_2412 = heff_field(v_st1_249, 0);
      V v_a_2413 = heff_field(v_st1_249, 1);
      V v_b_2414 = heff_field(v_st1_249, 2);
      heff_take_n(v_st1_249, 7ULL, 3);
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2413), NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2414), v_t_2415})));
      V v_t_2417 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ASts, 1, (V[]){heff_dup(v_ts_2410)})));
      V v_t_2418 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ASts, 1, (V[]){heff_dup(v_fs_2411)})));
      V v_t_2419 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2417, v_t_2418));
      return (g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3(v_ru_24st_241_24SIf, v_fs_2411, v_ts_2410, v_a_2413, v_b_2414, v_ce_240, v_p_2412, v_t_2416, v_t_2419));
    }
    case TAG_PBool: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return (g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(v_fs_2411, v_ts_2410, v_ce_240, v_st1_249));
    }
    case TAG_PNot: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return (g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(v_fs_2411, v_ts_2410, v_ce_240, v_st1_249));
    }
    case TAG_PIf: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return (g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(v_fs_2411, v_ts_2410, v_ce_240, v_st1_249));
    }
    case TAG_PLet: {
      heff_drop_cell(v_ru_24st_241_24SIf, 3);
      return (g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(v_fs_2411, v_ts_2410, v_ce_240, v_st1_249));
    }
    default: return heff_nomatch(v_st1_249);
    }
  }
  case TAG_SCase: {
    V v_v_2428 = heff_field(v_st_241, 0);
    V v_arms_2429 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SCase = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24s471405029x78128406(v_arms_2429));
    V v_t_2431 = (g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(v_ce_240, NTAG(TAG_False), v_v_2428, v_t_2430));
    return heff_tag_at_n(v_ru_24st_241_24SCase, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_st_241);
  }
}
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(V v_lit_240, V v_lit_241, V v_ce_242, V v_live_243, V v_want_244) {
top: ;
  V v_lit_245 = v_lit_240;
  V v_lit_246 = v_lit_241;
  V v_ce_247 = v_ce_242;
  V v_live_248 = v_live_243;
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_lit_246)));
  V v_t_2410 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_249));
  V v_live_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_248)));
  V v_fv_2412 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_247), v_live_2411, NTAG(TAG_RepV), v_lit_245));
  V v_vs_2413 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_247, v_live_248, v_lit_246));
  return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_244, heff_tag_n(TAG_RApply, 2, (V[]){v_fv_2412, v_vs_2413})));
}
V g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecoerce_24tok1_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ecoerce_24tok1(V v_tok_240, V v_from_241, V v_to_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_from_241, v_to_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_from_241);
    heff_drop(v_to_242);
    heff_drop(v_t_244);
    return v_v_243;
  } else {
    heff_drop(v_t_244);
    V v_t_246;
    switch (heff_tag_of(v_to_242)) {
    case TAG_RepV: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_to_242);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_to_242);
      heff_drop(v_t_246);
      return heff_tag_n(TAG_RBox, 2, (V[]){v_from_241, v_v_243});
    } else {
      heff_drop(v_t_246);
      switch (heff_tag_of(v_from_241)) {
      case TAG_RepV: {
        switch (heff_tag_of(v_v_243)) {
        case TAG_RDup: {
          V v_x_247 = heff_field(v_v_243, 0);
          heff_take_n(v_v_243, 1ULL, 1);
          return heff_tag_n(TAG_RPeek, 2, (V[]){v_to_242, heff_tag_at_n(v_tok_240, TAG_RLocal, 1, (V[]){v_x_247})});
        }
        case TAG_RGet: {
          V v_g_248 = heff_field(v_v_243, 0);
          heff_take_n(v_v_243, 1ULL, 1);
          return heff_tag_n(TAG_RPeek, 2, (V[]){v_to_242, heff_tag_at_n(v_tok_240, TAG_RGetRaw, 1, (V[]){v_g_248})});
        }
        case TAG_RDupE: {
          V v_e_249 = heff_field(v_v_243, 0);
          heff_take_n(v_v_243, 1ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          return heff_tag_n(TAG_RPeek, 2, (V[]){v_to_242, v_e_249});
        }
        default: {
          heff_drop_cell(v_tok_240, 1);
          return heff_tag_n(TAG_RUnbox, 2, (V[]){v_to_242, v_v_243});
        }
        }
      }
      case TAG_RepFix: {
        heff_drop_cell(v_tok_240, 1);
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_n(TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      case TAG_RepF64: {
        heff_drop_cell(v_tok_240, 1);
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_n(TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      case TAG_RepInt: {
        heff_drop_cell(v_tok_240, 1);
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_242, heff_tag_n(TAG_RBox, 2, (V[]){v_from_241, v_v_243})));
      }
      default: return heff_nomatch(v_from_241);
      }
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecoerce_24tok1(a[0], a[1], a[2], a[3]);
}