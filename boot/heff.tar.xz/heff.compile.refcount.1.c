// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CLet 49341
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DVal 23084
#define TAG_FlatAll 51900
#define TAG_FlatNone 33150
#define TAG_FlatSome 51022
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkCode 2932
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RCall 39004
#define TAG_RField 17425
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RUnbox 59387
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_fixed 298804110
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_n 328
#define LBL_op 10312
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_tag 324116
#define LBL_takes 311482598
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_ret};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2eboolDone(V, V);
V g_heff_2ecompile_2erefcount_2eboolDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eboolDone_clo;
V g_heff_2ecompile_2erefcount_2eboolName_get(void);
V g_heff_2ecompile_2erefcount_2ebuiltOf(V);
V g_heff_2ecompile_2erefcount_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebuiltOf_clo;
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V, V, V);
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2eflatOnes(V, V, V);
V g_heff_2ecompile_2erefcount_2eflatOnes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatOnes_clo;
V g_heff_2ecompile_2erefcount_2eflatnessOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvOp(V);
V g_heff_2ecompile_2erefcount_2efvOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvOp_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvW(V, V, V);
V g_heff_2ecompile_2erefcount_2efvW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvW_clo;
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754_clo;
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentField(V, V, V);
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentField_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2eoperandsOf(V);
V g_heff_2ecompile_2erefcount_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsOf_clo;
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674(V, V, V, V);
V g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
V g_heff_2ecompile_2erefcount_2ereuseOp(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseOp_clo;
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_clo;
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_clo;
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
V g_heff_2ecompile_2erefcount_2ereusedAny(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereusedAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusedAny_clo;
V g_heff_2ecompile_2erefcount_2ereusing(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusing_clo;
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2etakeOne(V, V, V);
V g_heff_2ecompile_2erefcount_2etakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeOne_clo;
V g_heff_2ecompile_2erefcount_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakeVar_clo;
V g_heff_2ecompile_2erefcount_2etakenFv(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakenFv_clo;
V g_heff_2ecompile_2erefcount_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etakesAt_clo;
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868(V, V, V);
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_clo;
V g_heff_2ecompile_2erefcount_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParam_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalRc(V, V, V);
V g_heff_2ecompile_2erefcount_2evalRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalRc_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erefcount_2ewrapUnbox(V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapUnbox_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapUnbox_clo;
V g_heff_2ecompile_2erepr_2efloatShape(V);
V g_heff_2ecompile_2erepr_2efloatShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efloatShape_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2eopShape(V, V);
V g_heff_2ecompile_2erepr_2eopShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eopShape_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s235792946x1211312979(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s235792946x1211312979_entry(V self, V *a);
extern Clo g_list_2efoldl_24s235792946x1211312979_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1548644028x2098102081(V, V);
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithFrame_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithFrame(V v_s_240, V v_n_241, V v_ce_242) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_s_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_s_243 = heff_dup(heff_field(v_s_240, 0));
    V v_x1_244 = (g_map_2elookup_24s1546226666x2146984184(heff_get_n(v_s_243, 0, 2), heff_rfield(v_ce_242, 11)));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_s_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      v_t_246 = heff_get_n(v_s_245, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    break;
  }
  default: heff_nomatch(v_s_240);
  }
  return ({ V rv_2 = v_s_240; V rv_3 = v_n_241; V rv_9 = NTAG(TAG_Nil); V rv_14 = v_t_246; V rr_ = heff_rec_reuse_nf(v_ce_242, 15859ULL, 15, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret, 267648783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 14) = rv_14; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithFrame(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2efvSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvSts_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvSts(V v_ss_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erefcount_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvSts(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), heff_dup(v_j_242))) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eelemI(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2elentField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentField_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2elentField(V v_ce_240, V v_after_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SVar: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SInt: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFloat: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SStr: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SBytes: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFixed: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    V v_l_2421 = heff_field(v_x3_242, 1);
    V v_sh_2422 = heff_field(v_x3_242, 2);
    V v_t_2423 = heff_field(v_x3_242, 3);
    V v_t_2424 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_2423));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_t_2424);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2424);
      V v_i_2425 = (g_heff_2ecompile_2erefcount_2eindexIn(heff_dup(v_l_2421), MK_INT(0LL), v_sh_2422));
      V v_t_2449;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_SVar: {
        V v_x_2426 = heff_field(v_e_2420, 0);
        v_t_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2426)});
        break;
      }
      case TAG_SGlobal: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2449 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      switch (heff_tag_of(v_t_2449)) {
      case TAG_Nothing: {
        heff_drop_rec(v_ce_240, 15);
        heff_drop(v_i_2425);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_2450 = heff_field(v_t_2449, 0);
        V v_ru_24t_2449_24Just = heff_take_reuse_n(v_t_2449, 1ULL, 1);
        switch (heff_tag_of(v_i_2425)) {
        case TAG_Nothing: {
          heff_drop_rec(v_ce_240, 15);
          heff_drop(v_x_2450);
          heff_drop_cell(v_ru_24t_2449_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_i_2451 = heff_field(v_i_2425, 0);
          V v_ru_24i_2425_24Just = heff_take_reuse_n(v_i_2425, 1ULL, 1);
          V v_t_2452 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_2450), v_after_241));
          if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
            heff_drop_rec(v_ce_240, 15);
            heff_drop(v_t_2452);
            V v_t_2453 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24i_2425_24Just, TAG_RLocal, 1, (V[]){v_x_2450}), v_i_2451});
            return heff_tag_at_n(v_ru_24t_2449_24Just, TAG_Just, 1, (V[]){v_t_2453});
          } else {
            heff_drop(v_t_2452);
            V v_t_2454 = ({ V a_0 = heff_dup(v_x_2450); V b_1 = heff_get_n(v_ce_240, 6, 15); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
            if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
              heff_drop(v_t_2454);
              V v_t_2455 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24i_2425_24Just, TAG_RLocal, 1, (V[]){v_x_2450}), v_i_2451});
              return heff_tag_at_n(v_ru_24t_2449_24Just, TAG_Just, 1, (V[]){v_t_2455});
            } else {
              heff_drop(v_x_2450);
              heff_drop_cell(v_ru_24t_2449_24Just, 1);
              heff_drop(v_i_2451);
              heff_drop_cell(v_ru_24i_2425_24Just, 1);
              heff_drop(v_t_2454);
              return NTAG(TAG_Nothing);
            }
          }
        }
        default: return heff_nomatch(v_i_2425);
        }
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
  }
  case TAG_SPrim: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2elentField(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ejustsOf_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2eslotBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eslotBits_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2eslotBits(V v_rps_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rps_240));
  V v_t_242 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_241, MK_INT(1LL))));
  V v_ps_243 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_242, v_rps_240));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = v_ps_243; V r_ = (g_list_2efoldl_24s235792946x1211312979(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_ps_243); r_; });
}
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eslotBits(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2etakenFv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakenFv_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
      if (heff_intLe_c(v_t_247, MK_INT(60LL))) {
        V v_x1_249 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_244), v_fb_243));
        if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 15);
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          heff_drop(v_x1_249);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_249);
          V v_x1_2410 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get_n(v_ce_240, 5, 15); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            heff_drop(v_x1_2410);
            return NTAG(TAG_Nothing);
          } else {
            heff_drop(v_x1_2410);
            return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_244});
          }
        }
      } else {
        heff_drop_rec(v_ce_240, 15);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_vs_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2etakenFv_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2etakenFv(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epow2_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2epow2(V v_n_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2erefcount_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epow2(a[0]);
}
V g_heff_2ecompile_2erefcount_2eflatOnes_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2eflatOnes_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eflatOnes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eflatOnes_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eflatOnes(V v_ce_240, V v_ps_241, V v_ws_242) {
top: ;
  V v_t_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2eflatOnes_lam0, 1, 1, (V[]){heff_dup(v_ps_241)}), v_ws_242));
  return (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2eflatOnes_lam1, 1, 1, (V[]){v_ce_240}), v_t_247));
}
V g_heff_2ecompile_2erefcount_2eflatOnes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eflatOnes(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eflatOnes_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_ps_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_245 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_t_246 = v_y_245;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  return ({ V a_0 = v_t_246; V a_1 = v_ps_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_ps_241); r_; });
}
V g_heff_2ecompile_2erefcount_2eflatOnes_lam1(V self, V *args) {
  V v_p_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_dup(heff_field(v_p_248, 0));
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_dup(heff_field(v_p_248, 1));
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2417;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_x2_2418 = ({ V a_0 = v_t_2417; V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    heff_take_n(v_x2_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2420})});
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eflatnessOf_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eflatnessOf(V v_x1_240, V v_su_241, V v_mask_242, V v_n_243) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_243, MK_INT(1LL))));
    V v_t_249 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2eflatnessOf_lam0, 1, 2, (V[]){v_mask_242, heff_dup(v_su_241)}); V a_1 = v_t_244; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      return NTAG(TAG_FlatAll);
    } else {
      heff_drop(v_t_249);
      return NTAG(TAG_FlatSome);
    }
  } else {
    heff_drop(v_mask_242);
    heff_drop(v_n_243);
    return NTAG(TAG_FlatNone);
  }
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eflatnessOf(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_mask_242 = heff_env(self)[0];
  V v_su_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_245)));
  V v_t_247 = heff_intMod(heff_intDiv(v_mask_242, v_t_246), MK_INT(2LL));
  if (heff_intEq_c(v_t_247, MK_INT(1LL))) {
    heff_drop(v_i_245);
    heff_drop(v_su_241);
    return NTAG(TAG_True);
  } else {
    return ({ V a_0 = v_i_245; V a_1 = v_su_241; V r_ = (g_list_2eany_24s120814613x1439363162(a_0, a_1)); heff_drop(v_su_241); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2ereuseOp_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseOp_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseOp(V v_ru_240, V v_n_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 1ULL, 1);
    V v_t_244 = (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_243));
    switch (heff_tag_of(v_t_244)) {
    case TAG_MkPair: {
      V v_b_245 = heff_field(v_t_244, 0);
      V v_v2_246 = heff_field(v_t_244, 1);
      V v_ru_24t_244_24MkPair = heff_take_reuse_n(v_t_244, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_244_24MkPair, TAG_MkPair, 2, (V[]){v_b_245, heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_OSimple, 1, (V[]){v_v2_246})});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_OCall: {
    V v_g_247 = heff_field(v_o_242, 0);
    V v_as_248 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseOp_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_as_248; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_as_248); r_; });
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_b_2411 = heff_field(v_t_2410, 0);
      V v_as2_2412 = heff_field(v_t_2410, 1);
      V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_b_2411, heff_tag_at_n(v_ru_24o_242_24OCall, TAG_OCall, 2, (V[]){v_g_247, v_as2_2412})});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_OApply: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  case TAG_OPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  case TAG_OAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  case TAG_OBool: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereuseOp(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ereuseOp_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_249));
}
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868(V v_ru_240, V v_n_241, V v_arms_242) {
top: ;
  V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_242));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_242));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2419});
}
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_t_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 4ULL, 3);
    V v_x1_247 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(v_ru_240, v_n_241, v_t_246));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      return v_x_248;
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_arm_243);
  }
}
V g_heff_2ecompile_2erefcount_2etlArms_24s1836986857x29361868_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_b_2414 = heff_field(v_arm_2411, 2);
    V v_ru_24arm_2411_24MkArm = heff_take_reuse_n(v_arm_2411, 7ULL, 3);
    V v_x1_2415 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(v_ru_240, v_n_241, v_b_2414));
    V v_t_2418;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_y_2417 = heff_field(v_x1_2415, 1);
      heff_take_n(v_x1_2415, 2ULL, 2);
      v_t_2418 = v_y_2417;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return heff_tag_at_n(v_ru_24arm_2411_24MkArm, TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_t_2418});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusedAny_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusedAny_str1, 0, "");
Clo g_heff_2ecompile_2erefcount_2ereusedAny_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereusedAny_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ereusedAny(V v_ru_240, V v_n_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_b1_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    if ((heff_dup(v_x41_244) == NTAG(TAG_True))) {
      heff_drop(v_n_241);
      heff_drop(v_b_242);
      heff_drop(v_x41_244);
      return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_ru_240}), v_b1_245});
    } else {
      heff_drop(v_x41_244);
      heff_drop(v_b1_245);
      switch (heff_tag_of(v_b_242)) {
      case TAG_ATail: {
        V v_t_246 = heff_dup(heff_field(v_b_242, 0));
        V v_t_247 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(heff_dup(v_ru_240), heff_rec_n(2, shape_n__tag, (V[]){v_n_241, ((V)&g_heff_2ecompile_2erefcount_2ereusedAny_str0)}), v_t_246));
        switch (heff_tag_of(v_t_247)) {
        case TAG_MkPair: {
          V v_b_248 = heff_field(v_t_247, 0);
          V v_t2_249 = heff_field(v_t_247, 1);
          heff_take_n(v_t_247, 3ULL, 2);
          if ((heff_dup(v_b_248) == NTAG(TAG_True))) {
            heff_drop_tag(v_b_242, 1);
            heff_drop(v_b_248);
            return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_ru_240}), heff_tag_n(TAG_ATail, 1, (V[]){v_t2_249})});
          } else {
            heff_drop(v_ru_240);
            heff_drop(v_b_248);
            heff_drop(v_t2_249);
            return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_242});
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      case TAG_ASts: {
        V v_ss_2410 = heff_dup(heff_field(v_b_242, 0));
        V v_t_2411 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(heff_dup(v_ru_240), heff_rec_n(2, shape_n__tag, (V[]){v_n_241, ((V)&g_heff_2ecompile_2erefcount_2ereusedAny_str1)}), v_ss_2410));
        switch (heff_tag_of(v_t_2411)) {
        case TAG_MkPair: {
          V v_b_2412 = heff_field(v_t_2411, 0);
          V v_ss2_2413 = heff_field(v_t_2411, 1);
          heff_take_n(v_t_2411, 3ULL, 2);
          if ((heff_dup(v_b_2412) == NTAG(TAG_True))) {
            heff_drop_tag(v_b_242, 1);
            heff_drop(v_b_2412);
            return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_ru_240}), heff_tag_n(TAG_ASts, 1, (V[]){v_ss2_2413})});
          } else {
            heff_drop(v_ru_240);
            heff_drop(v_b_2412);
            heff_drop(v_ss2_2413);
            return heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_242});
          }
        }
        default: return heff_nomatch(v_t_2411);
        }
      }
      default: return heff_nomatch(v_b_242);
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2ereusedAny_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ereusedAny(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str2, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusing_str3, 3, "ru$");
Clo g_heff_2ecompile_2erefcount_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereusing_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ereusing(V v_x1_240, V v_t_241, V v_vs_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_strAppend(heff_dup(v_x_244), heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str0), heff_dup(v_t_241)));
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_t_247 = heff_strAppend(v_x_244, heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str1), heff_dup(v_t_241)));
    V v_ru_248 = heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str2), v_t_247);
    V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_n_2410 = heff_rec_n(2, shape_n__tag, (V[]){v_t_249, v_t_241});
    V v_t_2419;
    switch (heff_tag_of(v_b_243)) {
    case TAG_ATail: {
      V v_t_2411 = heff_dup(heff_field(v_b_243, 0));
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938(v_ru_248, v_n_2410, v_t_2411));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_MkPair: {
        V v_b_2413 = heff_field(v_t_2412, 0);
        V v_t2_2414 = heff_field(v_t_2412, 1);
        V v_ru_24t_2412_24MkPair = heff_take_reuse_n(v_t_2412, 3ULL, 2);
        v_t_2419 = heff_tag_at_n(v_ru_24t_2412_24MkPair, TAG_MkPair, 2, (V[]){v_b_2413, heff_tag_at_n(v_ru_24x1_240_24Just, TAG_ATail, 1, (V[]){v_t2_2414})});
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    case TAG_ASts: {
      V v_ss_2415 = heff_dup(heff_field(v_b_243, 0));
      V v_t_2416 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108(v_ru_248, v_n_2410, v_ss_2415));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_MkPair: {
        V v_b_2417 = heff_field(v_t_2416, 0);
        V v_ss2_2418 = heff_field(v_t_2416, 1);
        V v_ru_24t_2416_24MkPair = heff_take_reuse_n(v_t_2416, 3ULL, 2);
        v_t_2419 = heff_tag_at_n(v_ru_24t_2416_24MkPair, TAG_MkPair, 2, (V[]){v_b_2417, heff_tag_at_n(v_ru_24x1_240_24Just, TAG_ASts, 1, (V[]){v_ss2_2418})});
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    HEFF_LAST return g_heff_2ecompile_2erefcount_2ereusedAny(heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ereusing_str3), v_t_245), v_t_246, v_b_243, v_t_2419);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ereusing(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakeOne_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2etakeOne(V v_ce_240, V v_rest_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SGlobal: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SInt: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFloat: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SStr: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SBytes: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFixed: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFloat32: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SPrimFn: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SLam: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_STag: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SRec: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SProj: {
    V v_e1_2420 = heff_field(v_e_242, 0);
    V v_l_2421 = heff_field(v_e_242, 1);
    V v_sh_2422 = heff_field(v_e_242, 2);
    V v_t_2423 = heff_field(v_e_242, 3);
    V v_t_2424 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_2423));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_ce_240);
      heff_drop(v_rest_241);
      heff_drop(v_t_2424);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2424);
      V v_t_2448;
      switch (heff_tag_of(v_e1_2420)) {
      case TAG_SVar: {
        V v_x_2425 = heff_field(v_e1_2420, 0);
        v_t_2448 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2425)});
        break;
      }
      case TAG_SGlobal: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2448 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e1_2420);
      }
      return ({ V a_0 = v_ce_240; V a_1 = v_rest_241; V a_2 = v_t_2448; V a_3 = heff_dup(v_l_2421); V a_4 = heff_dup(v_sh_2422); V r_ = (g_heff_2ecompile_2erefcount_2etakeVar(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2448); r_; });
    }
  }
  case TAG_SPrim: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2erefcount_2etakeOne_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2etakeOne(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2etakesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etakesAt_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etakesAt(V v_ce_240, V v_before_241, V v_after_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_before_241);
    heff_drop(v_after_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_rest_247 = (g_list_2efoldl_24s1203202837x1639358108(heff_dup(v_after_242), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_before_241)));
    V v_t_249 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_247, v_t_248));
    V v_t_2410 = (g_heff_2ecompile_2erefcount_2etakeOne(heff_dup(v_ce_240), v_t_249, v_e_244));
    V v_t_2411 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_before_241, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2etakesAt(v_ce_240, v_t_2412, v_after_242, v_es_245));
    return (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erefcount_2etakesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etakesAt(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eboolName_str0, 8, "ret$bool");

static V g_heff_2ecompile_2erefcount_2eboolName_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2eboolName_st;
static V g_heff_2ecompile_2erefcount_2eboolName_init(void) {
  return ((V)&g_heff_2ecompile_2erefcount_2eboolName_str0);
}
V g_heff_2ecompile_2erefcount_2eboolName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2eboolName_st)) return g_heff_2ecompile_2erefcount_2eboolName_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2eboolName_val, &g_heff_2ecompile_2erefcount_2eboolName_st, g_heff_2ecompile_2erefcount_2eboolName_init);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapUnbox_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapUnbox_str1, 4, "box$");
Clo g_heff_2ecompile_2erefcount_2ewrapUnbox_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewrapUnbox_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewrapUnbox(V v_lent_240, V v_rp_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_rp_241)) {
  case TAG_RepV: {
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_RepFix: {
    V v_v_244 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapUnbox_str0), heff_dup(v_x_242))});
    V v_t_245;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_245 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_244});
    } else {
      v_t_245 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_244});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_245}), NTAG(TAG_Nil)});
  }
  case TAG_RepF64: {
    V v_v_246 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapUnbox_str1), heff_dup(v_x_242))});
    V v_t_247;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_247 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_246});
    } else {
      v_t_247 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_246});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_247}), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_rp_241);
  }
}
V g_heff_2ecompile_2erefcount_2ewrapUnbox_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2ewrapUnbox(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str1, 4, "box$");
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(V v_ce_240, V v_live_241, V v_xs_242, V v_t_243, V v_fv_244) {
top: ;
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_xs_242)));
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_fv_244)));
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2, 1, 2, (V[]){heff_dup(v_ce_240), v_live_241}), heff_dup(v_fv_244)));
  V v_t_2415 = (g_list_2efoldl_24f1419248316x13095286(NTAG(TAG_Nil), heff_dup(v_xs_242), heff_dup(v_fv_244)));
  V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3, 2, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  V v_wanted_2420 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_243)));
  V v_xs_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4, 1, 1, (V[]){v_wanted_2420}), heff_dup(v_xs_242)));
  V v_t_2427 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2423));
  V v_t_2428 = (g_list_2emap_24s1901363476x1479927424(v_t_2427));
  V v_t_2429 = (g_heff_2ecompile_2erefcount_2elamBody_24s1264190293x171174754(v_ce_240, v_xs_242, v_t_243, v_fv_244));
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2429));
  V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2430));
  return heff_tag_n(TAG_RLam, 4, (V[]){v_t_248, v_t_2412, v_t_2414, heff_tag_n(TAG_MkCode, 1, (V[]){v_t_2431})});
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_246 = ({ V a_0 = heff_dup(v_x_245); V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return v_x_245;
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str0), v_x_245);
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2410 = ({ V a_0 = heff_dup(v_x_249); V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return v_x_249;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_str1), v_x_249);
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), heff_tag_n(TAG_SVar, 1, (V[]){v_x_2413})));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam3(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = ({ V a_0 = v_ce_240; V b_1 = NTAG(TAG_False); V a_2 = v_x_2417; V r_ = (g_heff_2ecompile_2erefcount_2eunboxParam(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_2416));
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam4(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2422 = ({ V a_0 = v_v_2421; V a_1 = v_wanted_2420; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wanted_2420); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2422) == NTAG(TAG_True)));
  heff_drop(v_x1_2422);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2elamWith_24s825008942x389296479_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2425 = ({ V a_0 = v_x_2424; V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Nothing: {
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2425, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_2425);
  }
}
Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_x5_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_245 = heff_field(v_x4_242, 0);
    V v_rps_246 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x5_243)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_rp_245);
      heff_drop(v_rps_246);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_247 = heff_field(v_x5_243, 0);
      V v_es_248 = heff_field(v_x5_243, 1);
      heff_take_n(v_x5_243, 3ULL, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_248)));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
      V v_live_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_dup(v_live_241)));
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2411, v_rp_245, v_e_247));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_rps_246;
      V t_3 = v_es_248;
      V t_4 = v_cell_2413;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_x4_242 = t_2;
      v_x5_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x5_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_rp_245, V v_e_246, V v_es_247) {
top: ;
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    return (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(v_ce_240, v_live_241, v_before_242, v_bi_243, v_i_244, v_e_246, v_es_247));
  }
  case TAG_RepFix: {
    heff_drop(v_i_244);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_live_241));
    V v_live_2412 = (g_prelude_2e_2b_2b(v_before_242, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2412, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2413});
  }
  case TAG_RepF64: {
    heff_drop(v_i_244);
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_247));
    V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, v_live_241));
    V v_live_2417 = (g_prelude_2e_2b_2b(v_before_242, v_t_2416));
    V v_t_2418 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_2417, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2418});
  }
  default: return heff_nomatch(v_rp_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_248 = heff_field(v_x7_245, 0);
    V v_rps_249 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_rp_248);
      heff_drop(v_rps_249);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_2410 = heff_field(v_x8_246, 0);
      V v_es_2411 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2esigOne_24s160010367x647593920(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), v_rp_248, heff_dup(v_e_2410), heff_dup(v_es_2411)));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V v_t_2415 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_2410; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_2410); r_; });
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_t_2415;
      V t_3 = v_bi_243;
      V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
      V t_5 = v_rps_249;
      V t_6 = v_es_2411;
      V t_7 = v_cell_2413;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_before_242 = t_2;
      v_bi_243 = t_3;
      v_i_244 = t_4;
      v_x7_245 = t_5;
      v_x8_246 = t_6;
      v_d_247 = t_7;
      goto top;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_24dps(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674(V v_ce_240, V v_live_241, V v_p_242, V v_args_243) {
top: ;
  V v_x2_244 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_242)));
  V v_x6_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_x6_247 = (g_heff_2ecompile_2erepr_2efloatShape(heff_dup(v_p_242)));
    break;
  }
  case TAG_Just: {
    V v_fp_245 = heff_field(v_x2_244, 0);
    V v_ru_24x2_244_24Just = heff_take_reuse_n(v_x2_244, 1ULL, 1);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_244_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_245, 0))});
    v_x6_247 = ({ V a_0 = v_t_246; V b_1 = heff_get_n(v_fp_245, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  switch (heff_tag_of(v_x6_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_args_243));
    return heff_tag_n(TAG_CondRel, 2, (V[]){v_p_242, v_t_248});
  }
  case TAG_Just: {
    V v_sh_249 = heff_field(v_x6_247, 0);
    heff_take_n(v_x6_247, 1ULL, 1);
    V v_t_2410 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, heff_get_n(v_sh_249, 0, 2), v_args_243));
    return heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_242, v_t_2410});
  }
  default: return heff_nomatch(v_x6_247);
  }
}
V g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V v_ce_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_CondTrue);
  }
  case TAG_PFalse: {
    heff_drop_rec(v_ce_240, 15);
    return NTAG(TAG_CondFalse);
  }
  case TAG_PRel: {
    V v_p_242 = heff_field(v_x3_241, 0);
    V v_a_243 = heff_field(v_x3_241, 1);
    V v_b_244 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
    return (g_heff_2ecompile_2erefcount_2erelTest_24s1551809647x1570729674(v_ce_240, NTAG(TAG_Nil), v_p_242, heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_t_245})));
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PBool = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_246));
    return heff_tag_at_n(v_ru_24x3_241_24PBool, TAG_CondBool, 1, (V[]){v_t_247});
  }
  case TAG_PNot: {
    V v_c_248 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(v_ce_240, v_c_248, heff_dup(v_cell_249), MK_INT(0LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_PIf: {
    V v_a_2411 = heff_field(v_x3_241, 0);
    V v_b_2412 = heff_field(v_x3_241, 1);
    V v_c_2413 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2414 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_a_2411));
    V v_t_2415 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_b_2412));
    V v_cell_2416 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2414, v_t_2415, heff_hole()});
    V v_u_2417 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(v_ce_240, v_c_2413, heff_dup(v_cell_2416), MK_INT(2LL)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  case TAG_PLet: {
    V v_x_2418 = heff_field(v_x3_241, 0);
    V v_o_2419 = heff_field(v_x3_241, 1);
    V v_c_2420 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    V v_x2_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2418), heff_rfield(v_ce_240, 10)));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nothing: {
      v_t_2423 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      heff_take_n(v_x2_2421, 1ULL, 1);
      v_t_2423 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2424 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2423, v_o_2419));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2418), heff_dup(heff_rfield(v_ce_240, 6))});
    V v_t_2426 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2425, heff_dup(v_ce_240)));
    V v_t_2427 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2426, v_c_2420));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2418), NTAG(TAG_Nil)});
    V v_t_2432 = (g_list_2emap_24f1548644028x2098102081(heff_clo_n(g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_lam0, 1, 1, (V[]){v_ce_240}), v_t_2428));
    return heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2418, v_t_2424, v_t_2427, v_t_2432});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2430 = ({ V a_0 = v_x_2429; V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2430)) {
  case TAG_Nothing: {
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2430, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_2430);
  }
}
Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_v_243));
  }
  case TAG_OCall: {
    V v_g_244 = heff_field(v_x4_242, 0);
    V v_as_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_244), heff_rfield(v_ce_240, 1)));
    V v_t_248;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    V v_x3_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_ce_240, 11)));
    V v_t_2411;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x3_249, 0);
      V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V v_x2_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_ce_240, 7)));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take_n(v_x2_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_x2_2415 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_ce_240, 11)));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nothing: {
      v_t_2417 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_245)));
      break;
    }
    case TAG_Just: {
      V v_s_2416 = heff_field(v_x2_2415, 0);
      heff_take_n(v_x2_2415, 1ULL, 1);
      v_t_2417 = heff_get_n(v_s_2416, 0, 2);
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2418 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2414; V a_4 = MK_INT(0LL); V a_5 = v_t_2417; V a_6 = v_as_245; V r_ = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_RCall, 4, (V[]){v_g_244, v_t_248, v_t_2411, v_t_2418});
  }
  case TAG_OApply: {
    V v_f_2419 = heff_field(v_x4_242, 0);
    V v_as_2420 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OApply = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2421 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24x4_242_24OApply, TAG_Cons, 2, (V[]){v_f_2419, v_as_2420})));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nil: {
      return NTAG(TAG_RAbandon);
    }
    case TAG_Cons: {
      V v_fv_2422 = heff_field(v_t_2421, 0);
      V v_vs_2423 = heff_field(v_t_2421, 1);
      V v_ru_24t_2421_24Cons = heff_take_reuse_n(v_t_2421, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2421_24Cons, TAG_RApply, 2, (V[]){v_fv_2422, v_vs_2423});
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_OPrim: {
    V v_p_2424 = heff_field(v_x4_242, 0);
    V v_as_2425 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2426 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_as_2425));
    return heff_tag_at_n(v_ru_24x4_242_24OPrim, TAG_RPrim, 2, (V[]){v_p_2424, v_t_2426});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_live_241);
    return NTAG(TAG_RAbandon);
  }
  case TAG_OBool: {
    V v_c_2427 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24OBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_t_2428 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_t_2429 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2428, v_ce_240));
    V v_t_2430 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2429));
    V v_t_2431 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2430, v_c_2427));
    return heff_tag_at_n(v_ru_24x4_242_24OBool, TAG_RBool, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(V v_ce0_240, V v_held_241, V v_lent_242, V v_t_243, V v_vs_244, V v_b_245) {
top: ;
  V v_n_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
  V v_ce_248;
  switch (heff_tag_of(v_held_241)) {
  case TAG_Nothing: {
    heff_drop(v_n_246);
    v_ce_248 = v_ce0_240;
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_dup(heff_field(v_held_241, 0));
    v_ce_248 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_x_247, heff_tag_n(TAG_KnownTag, 1, (V[]){v_n_246}), v_ce0_240));
    break;
  }
  default: heff_nomatch(v_held_241);
  }
  V v_fb_2411;
  switch (heff_tag_of(v_b_245)) {
  case TAG_ATail: {
    V v_t_249 = heff_dup(heff_field(v_b_245, 0));
    v_fb_2411 = (g_heff_2ecompile_2erefcount_2efvTl(v_t_249));
    break;
  }
  case TAG_ASts: {
    V v_ss_2410 = heff_dup(heff_field(v_b_245, 0));
    v_fb_2411 = (g_heff_2ecompile_2erefcount_2efvSts(v_ss_2410));
    break;
  }
  default: heff_nomatch(v_b_245);
  }
  V v_taken_2412 = (g_heff_2ecompile_2erefcount_2etakenFv(heff_dup(v_ce_248), v_held_241, v_vs_244, v_fb_2411));
  V v_t_2415;
  switch (heff_tag_of(v_b_245)) {
  case TAG_ATail: {
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  case TAG_ASts: {
    v_t_2415 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_b_245);
  }
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2ereusing(heff_dup(v_taken_2412), heff_dup(v_t_243), v_vs_244, v_b_245));
  return ({ V a_0 = v_ce_248; V a_1 = v_taken_2412; V a_2 = v_lent_242; V a_3 = v_t_243; V a_4 = v_vs_244; V a_5 = v_fb_2411; V a_6 = v_t_2415; V a_7 = v_t_2416; V r_ = (g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_taken_2412); r_; });
}
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V v_ce_240, V v_returns_241, V v_v_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(heff_dup(v_ce_240), heff_dup(v_v_242)));
  V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0, 1, 2, (V[]){v_v_242, v_ce_240}), v_arms_243));
  return heff_tag_n(TAG_CSwitch, 3, (V[]){v_t_244, v_t_2459, v_returns_241});
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_v_242 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_it1_246 = heff_field(v_p_245, 0);
    V v_b_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_t_248 = heff_field(v_it1_246, 0);
      V v_vs_249 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      V v_t_2434;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2410 = heff_dup(heff_field(v_v_242, 0));
        V v_t_2411 = (g_heff_2ecompile_2erefcount_2eelemS(heff_dup(v_x_2410), heff_rfield(v_ce_240, 4)));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
        } else {
          heff_drop(v_x_2410);
          heff_drop(v_t_2411);
          v_t_2434 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_SGlobal: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      V v_t_2458;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2435 = heff_field(v_v_242, 0);
        heff_take_n(v_v_242, 1ULL, 1);
        v_t_2458 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2435, heff_rfield(v_ce_240, 6)));
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_v_242, 0ULL, 3);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_v_242, 0ULL, 4);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      return ({ V a_0 = v_ce_240; V a_1 = v_t_2434; V a_2 = v_t_2458; V a_3 = v_t_248; V a_4 = v_vs_249; V a_5 = v_b_247; V r_ = (g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2458); r_; });
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_p_245);
  }
}
Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V v_ce_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_st_241)) {
  case TAG_SLet: {
    V v_ru_24st_241_24SLet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 15);
    return heff_tag_at_n(v_ru_24st_241_24SLet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SDecl: {
    heff_take_n(v_st_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 15);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SSet: {
    V v_ru_24st_241_24SSet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 15);
    return heff_tag_at_n(v_ru_24st_241_24SSet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SIf: {
    V v_st1_247 = heff_field(v_st_241, 0);
    V v_ts_248 = heff_field(v_st_241, 1);
    V v_fs_249 = heff_field(v_st_241, 2);
    heff_take_n(v_st_241, 7ULL, 3);
    switch (heff_tag_of(v_st1_247)) {
    case TAG_PTrue: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PFalse: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PRel: {
      V v_p_2410 = heff_field(v_st1_247, 0);
      V v_a_2411 = heff_field(v_st1_247, 1);
      V v_b_2412 = heff_field(v_st1_247, 2);
      heff_take_n(v_st1_247, 7ULL, 3);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2412), NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2412, NTAG(TAG_Nil)});
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2411), v_t_2414})));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ts_248)));
      V v_t_2418 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_fs_249)));
      V v_t_2419 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2417, v_t_2418));
      return ({ V a_0 = v_ce_240; V a_1 = v_p_2410; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, v_t_2413}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_4 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V a_5 = v_t_2416; V a_6 = v_t_2419; V r_ = (g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(a_0, a_1, a_2, b_3, b_4, a_5, a_6)); heff_drop(b_3); heff_drop(b_4); r_; });
    }
    case TAG_PBool: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PNot: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PIf: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PLet: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_st1_247);
    }
  }
  case TAG_SCase: {
    V v_v_2428 = heff_field(v_st_241, 0);
    V v_arms_2429 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SCase = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24s471405029x78128406(v_arms_2429));
    V v_t_2431 = (g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(v_ce_240, NTAG(TAG_False), v_v_2428, v_t_2430));
    return heff_tag_at_n(v_ru_24st_241_24SCase, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_st_241);
  }
}
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V v_ce_240, V v_x3_241, V v_after_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_after_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ce_240, 15);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_t_243 = heff_field(v_after_242, 0);
      heff_take_n(v_after_242, 1ULL, 1);
      return (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_240, v_t_243));
    }
    default: return heff_nomatch(v_after_242);
    }
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_rest_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_SLet: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_o_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24SLet = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_fa_248 = (g_heff_2ecompile_2erefcount_2efvOp(heff_dup(v_o_247)));
      V v_known_249 = (g_heff_2ecompile_2erefcount_2ebuiltOf(heff_dup(v_o_247)));
      V v_t_2412;
      switch (heff_tag_of(v_after_242)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x31_244_24SLet, 2);
        v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_245)}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_Just: {
        V v_t_2410 = heff_dup(heff_field(v_after_242, 0));
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2410}), NTAG(TAG_Nil)});
        v_t_2412 = heff_tag_at_n(v_ru_24x31_244_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_245)}), v_t_2411});
        break;
      }
      default: heff_nomatch(v_after_242);
      }
      V v_t_2413 = (g_heff_2ecompile_2erefcount_2eoperandsOf(heff_dup(v_o_247)));
      V v_takes_2414 = (g_heff_2ecompile_2erefcount_2etakesAt(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2412, v_t_2413));
      V v_t_2415 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_245), heff_dup(v_after_242)));
      V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(heff_rfield(v_ce_240, 5))));
      return ({ V a_0 = heff_dup(v_ce_240); V a_1 = heff_dup(v_x_246); V a_2 = v_fa_248; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_lam0, 1, 3, (V[]){v_x_246, v_ce_240, v_o_247}); V a_4 = v_known_249; V a_5 = v_takes_2414; V a_6 = v_rest_245; V a_7 = v_after_242; V a_8 = v_t_2416; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_known_249); r_; });
    }
    case TAG_SDecl: {
      V v_x_2423 = heff_dup(heff_field(v_x31_244, 0));
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_x_2423);
        V v_t_2424 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_240), v_x31_244));
        V v_t_2425 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_240, v_rest_245, v_after_242));
        return (g_prelude_2e_2b_2b(v_t_2424, v_t_2425));
      }
      case TAG_Cons: {
        V v_st_2426 = heff_field(v_rest_245, 0);
        V v_rest2_2427 = heff_field(v_rest_245, 1);
        heff_take_n(v_rest_245, 3ULL, 2);
        heff_drop_tag(v_x31_244, 1);
        V v_t_2428 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_st_2426), NTAG(TAG_Nil)});
        V v_fa_2429 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2428));
        V v_t_2430 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest2_2427), heff_dup(v_after_242)));
        V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2430, heff_dup(heff_rfield(v_ce_240, 5))));
        return ({ V a_0 = v_ce_240; V a_1 = heff_dup(v_x_2423); V a_2 = v_fa_2429; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_lam1, 1, 2, (V[]){v_st_2426, v_x_2423}); V b_4 = NTAG(TAG_Nothing); V a_5 = NTAG(TAG_Nil); V a_6 = v_rest2_2427; V a_7 = v_after_242; V a_8 = v_t_2431; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7, a_8)); heff_drop(b_4); r_; });
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    case TAG_SSet: {
      V v_x_2434 = heff_field(v_x31_244, 0);
      V v_o_2435 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_x2_2436 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2434), heff_rfield(v_ce_240, 10)));
      V v_t_2438;
      switch (heff_tag_of(v_x2_2436)) {
      case TAG_Nothing: {
        v_t_2438 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Just: {
        V v_x_2437 = heff_field(v_x2_2436, 0);
        heff_take_n(v_x2_2436, 1ULL, 1);
        v_t_2438 = v_x_2437;
        break;
      }
      default: heff_nomatch(v_x2_2436);
      }
      V v_t_2439 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), heff_dup(heff_rfield(v_ce_240, 5)), v_t_2438, heff_dup(v_o_2435)));
      V v_t_2440 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_o_2435; V r_ = (g_heff_2ecompile_2erefcount_2eboolDone(a_0, a_1)); heff_drop(v_o_2435); r_; });
      V v_t_2441 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_240, v_rest_245, v_after_242));
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
      return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CSet, 2, (V[]){v_x_2434, v_t_2439}), v_t_2442});
    }
    case TAG_SIf: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2446 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_240), v_x31_244));
      V v_t_2447 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_240, v_rest_245, v_after_242));
      return (g_prelude_2e_2b_2b(v_t_2446, v_t_2447));
    }
    case TAG_SCase: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2450 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_240), v_x31_244));
      V v_t_2451 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_240, v_rest_245, v_after_242));
      return (g_prelude_2e_2b_2b(v_t_2450, v_t_2451));
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_lam0(V self, V *args) {
  V v_ce2_2417 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_o_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = ({ V a_0 = heff_dup(v_x_246); V b_1 = heff_get_n(v_ce_240, 10, 15); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    heff_take_n(v_x2_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce2_2417), heff_dup(heff_rfield(v_ce2_2417, 5)), v_t_2420, heff_dup(v_o_247)));
  V v_t_2422 = ({ V a_0 = v_ce2_2417; V a_1 = v_o_247; V r_ = (g_heff_2ecompile_2erefcount_2eboolDone(a_0, a_1)); heff_drop(v_o_247); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_246, v_t_2421}), v_t_2422});
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_lam1(V self, V *args) {
  V v_ce2_2432 = args[0];
  V v_st_2426 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_ce2_2432, v_st_2426));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2423}), v_t_2433});
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 15);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_247 = heff_field(v_x7_245, 0);
    V v_ps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 15);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_p_247);
      heff_drop(v_ps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      heff_take_n(v_x8_246, 3ULL, 2);
      V v_x3_2411 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_p_247), heff_rfield(v_ce_240, 10)));
      V v_t_2413;
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2411, 0ULL, 1);
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2411);
      }
      V v_t_2422;
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2410)));
        V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2414); r_; });
        V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(v_live_241)));
        V v_live_2417 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2416));
        V v_x2_2418 = (g_map_2elookup_24s1546226666x2146984184(v_p_247, heff_rfield(v_ce_240, 10)));
        V v_t_2420;
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_Nothing: {
          v_t_2420 = NTAG(TAG_RepV);
          break;
        }
        case TAG_Just: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          heff_take_n(v_x2_2418, 1ULL, 1);
          v_t_2420 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x2_2418);
        }
        V v_t_2421 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2417, v_t_2420, heff_dup(v_e_249)));
        v_t_2422 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2421});
      } else {
        heff_drop(v_p_247);
        heff_drop(v_t_2413);
        v_t_2422 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), heff_dup(v_e_249), heff_dup(v_es_2410)));
      }
      V v_cell_2423 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
      V v_t_2424 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
      V v_u_2425 = (g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(v_ce_240, v_live_241, v_t_2424, v_bi_243, heff_intAdd(v_i_244, MK_INT(1LL)), v_ps_248, v_es_2410, heff_dup(v_cell_2423)));
      heff_drop(v_u_2425);
      return v_cell_2423;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V v_ce_240, V v_g_241, V v_as_242) {
top: ;
  V v_x2_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 7)));
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_s_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_248 = heff_get_n(v_s_247, 1, 2);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_249 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_245; V a_4 = MK_INT(0LL); V a_5 = v_t_248; V a_6 = heff_dup(v_as_242); V r_ = (g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_245); r_; });
  V v_x2_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 7)));
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_x2_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 11)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_242)));
    break;
  }
  case TAG_Just: {
    V v_s_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = heff_get_n(v_s_2414, 0, 2);
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2416 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2412; V a_4 = MK_INT(0LL); V a_5 = v_t_2415; V a_6 = heff_dup(v_as_242); V r_ = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2412); r_; });
  return ({ V a_0 = v_ce_240; V a_1 = v_g_241; V a_2 = v_as_242; V a_3 = v_t_249; V a_4 = v_t_2416; V r_ = (g_heff_2ecompile_2erefcount_2ecallAs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_as_242); r_; });
}
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2evalRc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalRc_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2evalRc(V v_ce_240, V v_key_241, V v_t_242) {
top: ;
  V v_t_243 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_242, NTAG(TAG_Nil)));
  V v_t_244 = (g_list_2efoldl_24s976906006x1321876394(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
  V v_ce_245 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1548442597x958354846(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = ({ V rv_2 = NTAG(TAG_Nothing); V rv_3 = MK_INT(0LL); V rv_9 = NTAG(TAG_Nil); V rv_14 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_ce_245, 15859ULL, 15, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__ret, 267648783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 14) = rv_14; rr_; });
  V v_ce_247 = (g_heff_2ecompile_2erefcount_2ewithPath(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_246));
  V v_t_248 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_247, v_t_242));
  return heff_tag_n(TAG_DVal, 3, (V[]){v_key_241, v_t_248, heff_get_n(v_ce_240, 10, 15)});
}
V g_heff_2ecompile_2erefcount_2evalRc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalRc(a[0], a[1], a[2]);
}