// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bin 307073
#define LBL_code 9554612
#define LBL_dir 308999
#define LBL_hash 9690581
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_text 10052084
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s131934541x153143574(V, V, V, V, V, V);
V g_list_2emap_24s131934541x153143574_entry(V self, V *a);
extern Clo g_list_2emap_24s131934541x153143574_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_text_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str0, 89, "` is the system's (lib/std/), for C: it imports an effect with no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str1, 2, "` ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str2, 19, "` is that effect: `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str4, 1, "`");
Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereachingRefused_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereachingRefused(V v_host_240, V v_s_241, V v_path_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str0), v_host_240));
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_242)));
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    v_t_247 = heff_dup(heff_rfield(v_s_241, 0));
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eimportsOn(v_path_242));
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str1), v_t_248));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str2), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str3), v_t_2410)});
  return heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_241, 0, 7), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str4), v_t_243), v_t_2411});
}
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereachingRefused(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efirstErrorOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efirstErrorOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efirstErrorOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_text_2412 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6); V a_1 = v_text_2412; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2412); r_; });
      V v_t_2414 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9); V b_3 = MK_INT(23LL); V a_4 = MK_INT(23LL); V a_5 = v_t_2413; V r_ = (g_list_2emap_24s131934541x153143574(b_0, b_1, b_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2415 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str0, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str1, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str2, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str4, 17, "package : Package");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str6, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str10, 6, ".heff/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str11, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str12, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str13, 18, "-- `heff test src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str14, 14, "/greeting.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str16, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str17, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str18, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str19, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str21, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str22, 59, "-- checks them all, and this one's doc tests are checked by");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str24, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str25, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str26, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str27, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str28, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str29, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str30, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str32, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str33, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str35, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str36, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str37, 66, "-- of type `Test` (lib/check.hf), after the watches and doc tests.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str39, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str40, 69, "-- `heff test` runs the tests of every file of test/: the definitions");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str41, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str42, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str43, 10, "package.hf");
Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str0), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str2), heff_strAppend(heff_dup(v_name_240), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str5); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str7), v_t_245}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str8), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str10); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str11), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str12)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str14)));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str15), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str17), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str19), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str21), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2414})});
  V v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str23); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str24); V a_2 = v_t_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2415, 2); r_; });
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str25), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str26)));
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2eprogramText(heff_dup(v_name_240)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str27), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str28)));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str29), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str30)));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str31), NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str33), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str35), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str38), v_t_2424})});
  V v_t_2426 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str39); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str40); V a_2 = v_t_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2425, 2); r_; });
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str41), v_t_2426}), NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, heff_dup(g_heff_2ebuild_2ecommands_2ebuildText_get())}), v_t_2427});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_t_2418}), v_t_2428});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2416}), v_t_2429});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str42), v_t_248}), v_t_2430});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str43), v_t_246}), v_t_2431});
}
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprojectFiles(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam0, 2, 2, (V[]){v_path_246, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Just = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    v_t_2423 = heff_tag_at_n(v_ru_24x_2421_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2422})});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_248;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
  V v_t_2410 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_249), heff_strLength_lent(v_path_246, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_str0))) {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
    v_t_2413 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2412));
  } else {
    v_t_2413 = v_path_246;
  }
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_str1)), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam1_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(v_t_2420, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam2, 1, 2, (V[]){v_m_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})));
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2418);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2419 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2421, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2419; V a_3 = v_t_2422; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_str1));
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam2, 1, 1, (V[]){v_k_243})));
  }
  case TAG_Just: {
    V v_src_2419 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_c_2420 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_f_241)));
    V f_ = v_c_2420;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s424479942x311270232_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2419, v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str2, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str3, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str4, 24, ": its tag has been moved");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str5, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str6, 1, " ");
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055(V v_prog_240, V v_ps_241, V v_root_242, V v_sums_243, V v_by_244, V v_path_245, V v_v_246) {
top: ;
  V v_t_247 = (g_list_2efilter_24s2128134357x1680551385(v_path_245, heff_take_field(v_root_242, 2)));
  V v_t_2413;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_242, 4);
    v_t_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2410 = (g_list_2efilter_24s50027113x1989932102(v_r_248, heff_get_n(v_root_242, 3, 4)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2411, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    V v_c_2414 = (g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(v_prog_240, heff_dup(v_ps_241), heff_dup(v_path_245), heff_dup(v_v_246)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_lam0, 2, 6, (V[]){v_c_2414, v_v_246, v_path_245, v_by_244, v_sums_243, v_ps_241});
  }
  case TAG_Just: {
    V v_d_2437 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_sums_243);
    heff_drop(v_by_244);
    heff_drop(v_v_246);
    V v_t_2438 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), heff_dup(heff_rfield(v_ps_241, 0)), v_d_2437));
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(v_ps_241, v_t_2438, v_path_245));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_v_246 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_by_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_why_2418 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_sums_243);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_hd_2415);
    V v_t_2419 = heff_strAppend(v_v_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str0), v_why_2418));
    V v_t_2420 = heff_strAppend(v_path_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str1), v_t_2419));
    V v_t_2421 = heff_strAppend(v_by_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str2), v_t_2420));
    V f_ = v_k_2416;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2422 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_drop(v_by_244);
    V v_t_2423 = (g_list_2efilter_24s639151216x1214259357(v_path_245, v_v_246, v_sums_243));
    V v_t_2426;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2424 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 2);
      v_t_2426 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Just, 1, (V[]){heff_get_n(v_s_2424, 2, 3)});
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      heff_drop(v_h_2422);
      V v_t_2427 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
      V v_t_2428 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(v_ps_241, v_t_2427, v_path_245));
      V f_ = v_t_2428;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_want_2429 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
      if (heff_strEq_c_lent(v_h_2422, v_want_2429, 0)) {
        heff_drop(v_h_2422);
        heff_drop(v_want_2429);
        heff_drop_cell(v_ru_24t_2426_24Just, 1);
        V v_t_2431 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
        V v_t_2432 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(v_ps_241, v_t_2431, v_path_245));
        V f_ = v_t_2432;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_hd_2415);
        V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str3), heff_strAppend(v_want_2429, ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str4)));
        V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str5), heff_strAppend(v_h_2422, v_t_2433));
        V v_t_2435 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_str6), heff_strAppend(v_v_246, v_t_2434));
        V v_t_2436 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_path_245, v_t_2435)});
        V f_ = v_k_2416;
        args[0] = v_t_2436;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  V v_by_244 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_lam1, 1, 7, (V[]){v_v_246, v_path_245, v_by_244, v_k_2416, v_sums_243, v_ps_241, v_hd_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str3, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str6, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str7, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str8, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str9, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str10, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam10, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813(V v_prog_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_x_245);
    V v_t_247 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_243, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_247}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam0, 2, 2, (V[]){v_t_248, v_next_244});
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_x6_246, 0);
    heff_take_n(v_x6_246, 1ULL, 1);
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_243, heff_dup(v_n_2412), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam2_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam3, 2, 7, (V[]){v_t_2414, v_n_2412, heff_dup(v_st_241), v_t_242, v_x_245, v_prog_240, v_next_244});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  V f_ = v_next_244;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam1, 1, 3, (V[]){v_next_244, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam5(V self, V *args) {
  V v_ok_2420 = args[0];
  return v_ok_2420;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam9(V self, V *args) {
  V v_ok_2439 = args[0];
  return v_ok_2439;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam10(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam13(V self, V *args) {
  V v_x_2460 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2460);
  V f_ = v_next_244;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam12(V self, V *args) {
  V v_x_2459 = args[0];
  V v_t_2451 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_next_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2459);
  return (g_co_2eop_24s94900133x232571340(v_t_2451, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam13, 1, 3, (V[]){v_next_244, v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam14(V self, V *args) {
  V v_ok_2461 = args[0];
  return v_ok_2461;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam16(V self, V *args) {
  V v_x_2482 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam15(V self, V *args) {
  V v_x_2467 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2467);
  V v_t_2468 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str6), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str7)));
  V v_p_2469 = (g_std_2epath_2ejoin(v_st_241, v_t_2468, v_x_245));
  V v_t_2470 = (g_std_2epath_2ejoin(v_st_241, heff_take_field(v_t_242, 0), v_p_2469));
  V v_t_2471 = (g_std_2epath_2ejoin(v_st_241, v_t_2470, heff_dup(v_n_2412)));
  V v_t_2472 = ({ V a_0 = v_st_241; V a_1 = heff_get_n(v_t_242, 1, 6); V a_2 = v_n_2412; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
  V v_t_2473 = heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str8), v_t_2472));
  V v_why_2474 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str9), v_t_2473);
  V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str10), v_why_2474), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str11));
  V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2475, NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam16, 1, 2, (V[]){v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam11(V self, V *args) {
  V v_x_2448 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  V v_x_2419 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_dup(v_x_2448) == NTAG(TAG_True))) {
    heff_drop(v_x_2448);
    heff_drop(v_x_2419);
    heff_drop(v_x_245);
    V v_path_2449 = ({ V a_0 = v_st_241; V a_1 = heff_take_field(v_t_242, 1); V a_2 = v_n_2412; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
    V v_t_2450 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
    V v_t_2451 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2450}));
    V v_t_2452 = heff_strAppend(heff_get_n(v_t_242, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str4), v_path_2449));
    V v_t_2453 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str5)), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam12, 1, 4, (V[]){v_t_2451, v_hd_2415, v_next_244, v_k_2416})));
  } else {
    heff_drop(v_x_2448);
    heff_drop(v_x_2417);
    heff_drop(v_prog_240);
    heff_drop(v_next_244);
    V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_2419, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam14_clo)})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam15, 1, 6, (V[]){v_st_241, v_x_245, v_t_242, v_n_2412, v_hd_2415, v_k_2416})));
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2447;
  if ((heff_dup(v_x_2437) == NTAG(TAG_True))) {
    heff_drop(v_x_2437);
    V v_to_2438 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 1)), heff_dup(v_n_2412)));
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Replace, 3, (V[]){heff_dup(v_x_2419), v_to_2438, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam9_clo)})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    v_c_2447 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
  } else {
    heff_drop(v_x_2437);
    v_c_2447 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam10_clo);
  }
  V f_ = v_c_2447;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam11, 1, 10, (V[]){v_st_241, v_t_242, v_n_2412, v_x_2417, v_prog_240, v_hd_2415, v_next_244, v_k_2416, v_x_2419, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_x_2417 = heff_env(self)[6];
  V v_prog_240 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_2416 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2426);
  V v_t_2427 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str2), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str3)));
  V v_p_2428 = (g_std_2epath_2ejoin(v_st_241, v_t_2427, heff_dup(v_x_245)));
  V v_t_2429 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_2428));
  V v_path_2430 = (g_std_2epath_2ejoin(v_st_241, v_t_2429, heff_dup(v_n_2412)));
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2430, heff_dup(v_x_2419), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam7_clo)})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam8, 1, 10, (V[]){v_st_241, v_t_242, v_n_2412, v_x_2419, v_hd_2415, v_x_2417, v_prog_240, v_next_244, v_k_2416, v_x_245})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_n_2412 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str0), heff_strAppend(heff_dup(v_n_2412), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_str1)));
  V v_x_2419 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 1)), v_t_2418));
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2419), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam5_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam6, 1, 10, (V[]){v_st_241, v_x_245, v_t_242, v_n_2412, v_x_2419, v_hd_2415, v_x_2417, v_prog_240, v_next_244, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_n_2412 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_lam4, 1, 8, (V[]){v_n_2412, v_st_241, v_t_242, v_hd_2415, v_x_245, v_prog_240, v_next_244, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_str0, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2410 = (g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(v_x_242, v_x_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_why_2414 = v_field_2412;
      V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_str0), v_why_2414), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_str1));
      V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
    } else {
      V v_line_2429 = v_field_2412;
      V v_t_2430 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2429, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_str2)), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_240, v_k_241));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_x_242), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s609105089x1973603620_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}