// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_seed 10021688
#define LBL_segments 1801007612
#define LBL_ships 310766033
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_version 583465758
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2emoduleText(V);
V g_heff_2ebuild_2ecommands_2emoduleText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emoduleText_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_clo;
V g_heff_2ebuild_2ecommands_2etestText(V);
V g_heff_2ebuild_2ecommands_2etestText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestText_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eany_24s1875112453x1656618700(V, V);
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a);
extern Clo g_list_2eany_24s1875112453x1656618700_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s332527547x6651279(V, V);
V g_list_2eany_24s332527547x6651279_entry(V self, V *a);
extern Clo g_list_2eany_24s332527547x6651279_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2eany_24s529567056x880977707(V, V, V);
V g_list_2eany_24s529567056x880977707_entry(V self, V *a);
extern Clo g_list_2eany_24s529567056x880977707_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s794048906x2073543501(V, V);
V g_list_2efilter_24s794048906x2073543501_entry(V self, V *a);
extern Clo g_list_2efilter_24s794048906x2073543501_clo;
HeffT2 g_list_2efind_24s1973550603x1701528639_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1942081783x251284947(V, V, V, V);
V g_list_2emap_24f1942081783x251284947_entry(V self, V *a);
extern Clo g_list_2emap_24f1942081783x251284947_clo;
V g_list_2emap_24s131934541x153143574(V, V, V, V, V, V);
V g_list_2emap_24s131934541x153143574_entry(V self, V *a);
extern Clo g_list_2emap_24s131934541x153143574_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1814289659x520383890(V, V, V);
V g_list_2emap_24s1814289659x520383890_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_text_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str0, 89, "` is the system's (lib/std/), for C: it imports an effect with no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str1, 2, "` ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str2, 19, "` is that effect: `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str4, 1, "`");
Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereachingRefused_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereachingRefused(V v_host_240, V v_s_241, V v_path_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str0), v_host_240));
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_242)));
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    v_t_247 = heff_dup(heff_rfield(v_s_241, 0));
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eimportsOn(v_path_242));
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str1), v_t_248));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str2), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str3), v_t_2410)});
  return heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_241, 0, 8), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str4), v_t_243), v_t_2411});
}
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereachingRefused(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efirstErrorOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efirstErrorOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efirstErrorOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_text_2412 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6); V a_1 = v_text_2412; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2412); r_; });
      V v_t_2414 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9); V b_3 = MK_INT(23LL); V a_4 = MK_INT(23LL); V a_5 = v_t_2413; V r_ = (g_list_2emap_24s131934541x153143574(b_0, b_1, b_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2415 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str0, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str1, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str2, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str4, 17, "package : Package");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str6, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str10, 6, ".heff/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str11, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str12, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str13, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str14, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str15, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str16, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str17, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str18, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str19, 10, "package.hf");
Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str0), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str2), heff_strAppend(heff_dup(v_name_240), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str5); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str7), v_t_245}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str8), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str10); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str11), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str12)));
  V v_t_2410 = (g_heff_2ebuild_2ecommands_2emoduleText(heff_dup(v_name_240)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str14)));
  V v_t_2412 = (g_heff_2ebuild_2ecommands_2eprogramText(heff_dup(v_name_240)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str15), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str16)));
  V v_t_2414 = (g_heff_2ebuild_2ecommands_2etestText(v_name_240));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str17), v_t_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_dup(g_heff_2ebuild_2ecommands_2ebuildText_get())}), v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_t_2412}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2410}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str18), v_t_248}), v_t_2418});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str19), v_t_246}), v_t_2419});
}
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprojectFiles(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str21, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(V v_lit_240, V v_prog_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248, V v_hd_249, V v_k_2410) {
top: ;
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_dir_246), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam1, 1, 11, (V[]){heff_dup(v_st_243), v_dir_246, v_prog_241, v_p_245, v_hd_249, v_flags_244, v_out_247, v_next_248, v_k_2410, v_who_242, v_lit_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam0(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam2(V self, V *args) {
  V v_n_2422 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2422; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam3(V self, V *args) {
  V v_n_2427 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2427; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam4(V self, V *args) {
  V v_t_2432 = args[0];
  return v_t_2432;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam7(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V v_t_2444 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str14)});
  V f_ = v_k_2443;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam8(V self, V *args) {
  V v_r_2452 = args[0];
  return v_r_2452;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam12(V self, V *args) {
  V v_x_2479 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  return (g_co_2eop_24s22628809x1035315751(heff_tag_n(TAG_InR, 1, (V[]){v_t_2486}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2470);
  V v_t_2471 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str20), v_out_247));
  V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str21)), NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam12, 1, 3, (V[]){v_lit_240, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2458);
  V v_t_2459 = heff_take_field(v_x_2455, 0);
  V v_t_2462;
  switch (heff_tag_of(v_t_2459)) {
  case TAG_Exited: {
    V v_n_2460 = heff_field(v_t_2459, 0);
    heff_take_n(v_t_2459, 1ULL, 1);
    v_t_2462 = heff_intEq(v_n_2460, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2459, 0ULL, 1);
    v_t_2462 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2462 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2462 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2459);
  }
  if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2455, 3);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_lit_240);
    heff_drop(v_t_2462);
    V f_ = v_next_248;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2462);
    V v_t_2463 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2455, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam11, 1, 5, (V[]){v_who_242, v_out_247, v_hd_249, v_lit_240, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam9(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2456 = heff_tag_n(TAG_End, 2, (V[]){v_x_2434, NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2456}));
  return (g_co_2eop_24s495635622x733177935(v_t_2457, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam10, 1, 7, (V[]){v_x_2455, v_next_248, v_hd_249, v_k_2410, v_who_242, v_out_247, v_lit_240})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2454;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    heff_drop(v_x_2423);
    heff_drop(v_flags_244);
    v_c_2454 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam7_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2445 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str15), NTAG(TAG_Nil)});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2446})});
    V v_t_2448 = (g_prelude_2e_2b_2b(v_os_2445, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_x_2423, v_t_2448));
    V v_t_2450 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str17), v_t_2449})));
    V v_argv_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str18), v_t_2450});
    V v_t_2453 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2434), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str19), v_argv_2451, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam8_clo)})}));
    v_c_2454 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2453}));
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam9, 1, 8, (V[]){v_x_2434, v_prog_241, v_hd_249, v_next_248, v_k_2410, v_who_242, v_out_247, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2423 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2435 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2439;
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_t_2435);
    v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str4);
  } else {
    heff_drop(v_t_2435);
    V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str6);
    } else {
      heff_drop(v_t_2436);
      V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str8);
      } else {
        heff_drop(v_t_2437);
        V v_t_2438 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s529567056x880977707(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
          heff_drop(v_t_2438);
          v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str11);
        } else {
          heff_drop(v_t_2438);
          v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str12);
        }
      }
    }
  }
  V v_c_2440 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(heff_dup(v_prog_241), heff_dup(v_x_2434), v_t_2439, v_x_2428, NTAG(TAG_Nil)));
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam6, 1, 10, (V[]){v_out_247, v_x_2423, v_flags_244, v_prog_241, v_x_2434, v_hd_249, v_next_248, v_k_2410, v_who_242, v_lit_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_lit_240 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_dup(heff_field(v_x_2418, 0));
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2421 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str0); V a_1 = v_t_2420; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2423 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam2, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2421));
  V v_t_2425;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str1); V a_1 = v_t_2425; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2428 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam3, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2426));
  V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2423));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2428));
  V v_total_2431 = heff_intAdd(heff_intAdd(v_t_2429, v_t_2430), MK_INT(1LL));
  V v_t_2433 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_str2), v_total_2431, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2433, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_lam5, 1, 10, (V[]){v_flags_244, v_prog_241, v_x_2428, v_hd_249, v_out_247, v_x_2423, v_next_248, v_k_2410, v_who_242, v_lit_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str1, 21, "  errors, as expected");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str4, 28, "  checks, but expects errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str6, 43, ": checks, but its first line expects errors");
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043(V v_f_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str0), heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str1)));
    V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str2)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_lam0, 1, 1, (V[]){v_p_243})));
  } else {
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str3), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str4)));
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str5)), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_lam1, 1, 2, (V[]){v_f_240, v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  V f_ = v_p_243;
  args[0] = heff_dup(g_heff_2ebuild_2ecommands_2eexpectedRes_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s141028914x884187043_str6)), NTAG(TAG_Nil)});
  V f_ = v_p_243;
  args[0] = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2422, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(V v_rep_240, V v_failed_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam0, 1, 9, (V[]){v_l_242, v_hd_247, v_rep_240, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_sources_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2415 = (g_list_2efind_24s1973550603x1701528639_24cpr(heff_dup(v_c_2414), v_sources_2412));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2413, v_s_2419));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2414, v_t_2420));
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2417);
      return v_c_2414;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_file_245 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_l_242 = heff_env(self)[7];
  V v_name_243 = heff_env(self)[8];
  V v_outPath_244 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2423);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop_rec(v_x_2411, 2);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    HeffT2 v_t_2425 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x_2421));
    V v_t_2430;
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        heff_drop(v_file_245);
        V v_x_2429 = v_field_2427;
        v_t_2430 = v_x_2429;
      } else {
        heff_drop(v_field_2427);
        v_t_2430 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str3));
      }
    }
    V f_ = v_failed_241;
    heff_room[0] = v_t_2430;
    heff_room[1] = v_hd_247;
    heff_room[2] = v_k_248;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2431 = (g_list_2eany_24s469495312x865582084(v_x_2421));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2411, 2);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2431);
      HeffT2 v_t_2432 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x_2421));
      V v_t_2437;
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop(v_file_245);
          V v_x_2436 = v_field_2434;
          v_t_2437 = v_x_2436;
        } else {
          heff_drop(v_field_2434);
          v_t_2437 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str4));
        }
      }
      V f_ = v_failed_241;
      heff_room[0] = v_t_2437;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2431);
      V v_t_2438 = (g_list_2emap_24s1698496827x1884878103(heff_take_field(v_x_2411, 0)));
      V v_t_2439 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), heff_get_n(v_x_2411, 1, 2), v_t_2438});
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154(v_t_2439, heff_get_n(v_l_242, 0, 5), v_file_245, v_name_243, v_outPath_244, v_failed_241, v_done_246, v_x_2421, v_hd_247, v_k_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_file_245 = heff_env(self)[4];
  V v_failed_241 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_sources_2412 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2413 = (g_list_2emap_24f1942081783x251284947(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_str2), heff_dup(v_sources_2412)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam2, 1, 2, (V[]){v_sources_2412, v_x_2413}), heff_dup(heff_rfield(v_x_2411, 0))));
  V v_c_2422 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_x_2421)));
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam3, 1, 11, (V[]){v_x_249, v_x_2421, v_file_245, v_failed_241, v_hd_247, v_k_248, v_x_2411, v_l_242, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_245 = heff_env(self)[3];
  V v_failed_241 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_l_242)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_lam1, 1, 10, (V[]){v_l_242, v_rep_240, v_hd_247, v_x_249, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_str1, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855(V v_rep_240, V v_bi_241, V v_sources_242, V v_file_243, V v_name_244, V v_outPath_245, V v_done_246, V v_badL_247, V v_checked_248, V v_z_249, V v_z_2410) {
top: ;
  V v_c_2411 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_str0); V a_1 = heff_dup(v_sources_242); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1487255689x1895806076(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam0, 1, 11, (V[]){v_sources_242, v_checked_248, v_rep_240, v_z_249, heff_dup(v_badL_247), v_z_2410, v_bi_241, v_file_243, heff_dup(v_name_244), v_outPath_245, v_done_246})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855(a[0], a[1], a[2], a[3], a4, a[5], a[6], a7, a[8], a[9], a[10]); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam1(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = (g_list_2efind_24s1973550603x1701528639_24cpr(heff_dup(v_c_2415), v_sources_242));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2414, v_s_2420));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2421));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_badL_247 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_bi_241 = heff_env(self)[4];
  V v_sources_242 = heff_env(self)[5];
  V v_file_243 = heff_env(self)[6];
  V v_name_244 = heff_env(self)[7];
  V v_outPath_245 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2424);
  if ((heff_dup(v_badL_247) == NTAG(TAG_True))) {
    heff_drop(v_badL_247);
    heff_drop(v_x_2422);
    heff_drop(v_bi_241);
    heff_drop(v_sources_242);
    heff_drop(v_file_243);
    heff_drop(v_name_244);
    heff_drop(v_outPath_245);
    heff_drop(v_done_246);
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_z_249, v_z_2410));
  } else {
    heff_drop(v_badL_247);
    V v_t_2432 = (g_list_2eany_24s469495312x865582084(v_x_2422));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_x_2422);
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_name_244);
      heff_drop(v_outPath_245);
      heff_drop(v_done_246);
      heff_drop(v_t_2432);
      V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_z_249, v_z_2410));
    } else {
      heff_drop(v_t_2432);
      return ({ V a_0 = v_bi_241; V a_1 = v_sources_242; V a_2 = v_file_243; V a_3 = v_name_244; V a_4 = v_outPath_245; V a_5 = v_done_246; V a_6 = v_x_2422; V a_7 = v_z_249; V a_8 = v_z_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_244); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_checked_248 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_badL_247 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  V v_bi_241 = heff_env(self)[6];
  V v_file_243 = heff_env(self)[7];
  V v_name_244 = heff_env(self)[8];
  V v_outPath_245 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_str1); V a_1 = heff_dup(v_sources_242); V a_2 = v_x_2412; V a_3 = heff_dup(v_sources_242); V r_ = (g_list_2emap_24s159228909x554161698(a_0, a_1, a_2, a_3)); heff_drop(v_x_2412); r_; });
  V v_x_2414 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2413));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam1, 1, 2, (V[]){heff_dup(v_sources_242), v_x_2414}), v_checked_248));
  V v_c_2423 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_x_2422)));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1548031962x1098154855_lam2, 1, 10, (V[]){v_badL_247, v_z_249, v_z_2410, v_x_2422, v_bi_241, v_sources_242, v_file_243, v_name_244, v_outPath_245, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str2, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str4, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str5, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str6, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str8, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str9, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str10, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str11, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str12, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str14, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str15, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str16, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str17, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str18, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str19, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str20, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str21, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str22, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str23, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str24, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str25, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str27, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str28, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str30, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str31, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str32, 12, "cannot keep ");
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam16(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam16, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam18(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam18, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416(V v_prog_240, V v_ps_241, V v_path_242, V v_v_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), heff_dup(v_v_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_path_242, v_v_243, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam1(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam3(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam5(V self, V *args) {
  V v_ok_2434 = args[0];
  return v_ok_2434;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam7(V self, V *args) {
  V v_t_2443 = args[0];
  return v_t_2443;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam9(V self, V *args) {
  V v_r_2455 = args[0];
  return v_r_2455;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam12(V self, V *args) {
  V v_ok_2472 = args[0];
  return v_ok_2472;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam13(V self, V *args) {
  V v_x_2479 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_2463 = heff_env(self)[1];
  V v_v_243 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2479);
  V v_t_2480 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_s_2481 = heff_get_n(v_x_2463, 2, 3);
  V v_t_2482 = (g_prelude_2eskipSpaces(v_s_2481, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2483 = (heff_unbox_word(heff_strLength_lent(v_s_2481, 0)) - ((int64_t)1ULL));
  V v_t_2484 = (g_prelude_2eskipSpaces(v_s_2481, heff_box_word(v_t_2483), MK_INT(-1LL)));
  V v_t_2485 = heff_strSlice(v_s_2481, v_t_2482, heff_intAdd(v_t_2484, MK_INT(1LL)));
  V v_t_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str14), v_t_2480), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str15), v_t_2485));
  V v_t_2487 = heff_strAppend(heff_dup(v_v_243), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str16), v_t_2486));
  V v_t_2488 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str17), v_t_2487));
  V v_t_2489 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str18), v_t_2488));
  V v_x_2490 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str19), v_t_2489)});
  V f_ = v_k_246;
  args[0] = v_x_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam14(V self, V *args) {
  V v_r_2493 = args[0];
  return v_r_2493;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam16(V self, V *args) {
  V v_ok_24103 = args[0];
  return v_ok_24103;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam18(V self, V *args) {
  V v_ok_24111 = args[0];
  return v_ok_24111;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam20(V self, V *args) {
  V v_ok_24125 = args[0];
  return v_ok_24125;
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam22(V self, V *args) {
  V v_x_24148 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24148);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24124});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam21(V self, V *args) {
  V v_x_24133 = args[0];
  V v_x_24101 = heff_env(self)[0];
  V v_x_24118 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_x_24124 = heff_env(self)[6];
  V v_x_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24134 = heff_get_n(v_x_24101, 0, 3);
  V v_t_24138;
  switch (heff_tag_of(v_t_24134)) {
  case TAG_Exited: {
    V v_n_24135 = heff_field(v_t_24134, 0);
    heff_take_n(v_t_24134, 1ULL, 1);
    if (heff_intEq_c(v_n_24135, MK_INT(0LL))) {
      if ((heff_dup(v_x_24118) == NTAG(TAG_True))) {
        heff_drop(v_x_24118);
        v_t_24138 = v_x_24133;
      } else {
        heff_drop(v_x_24133);
        heff_drop(v_x_24118);
        v_t_24138 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_24133);
      heff_drop(v_x_24118);
      v_t_24138 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_24134, 0ULL, 1);
    heff_drop(v_x_24133);
    heff_drop(v_x_24118);
    v_t_24138 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_x_24133);
    heff_drop(v_x_24118);
    v_t_24138 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_drop(v_x_24133);
    heff_drop(v_x_24118);
    v_t_24138 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24134);
  }
  if ((heff_dup(v_t_24138) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    heff_drop(v_t_24138);
    V v_t_24139 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str27), v_v_243));
    V v_t_24140 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str28), v_t_24139), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str29));
    V v_t_24141 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24140, NTAG(TAG_MkUnit)});
    V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24147}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam22, 1, 2, (V[]){v_k_246, v_x_24124})));
  } else {
    heff_drop(v_hd_245);
    heff_drop(v_x_24124);
    heff_drop(v_t_24138);
    V v_t_24149 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str30), v_x_244));
    V v_t_24150 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str31), v_t_24149));
    V v_t_24151 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str32), v_t_24150)});
    V f_ = v_k_246;
    args[0] = v_t_24151;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam19(V self, V *args) {
  V v_x_24118 = args[0];
  V v_x_24101 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_24119 = heff_dup(heff_rfield(v_x_24101, 1));
  V v_t_24120 = (g_prelude_2eskipSpaces(v_s_24119, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_24121 = (heff_unbox_word(heff_strLength_lent(v_s_24119, 0)) - ((int64_t)1ULL));
  V v_t_24122 = (g_prelude_2eskipSpaces(v_s_24119, heff_box_word(v_t_24121), MK_INT(-1LL)));
  V v_t_24123 = heff_strSlice(v_s_24119, v_t_24120, heff_intAdd(v_t_24122, MK_INT(1LL)));
  V v_x_24124 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str24), v_t_24123);
  V v_t_24126 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str25)), heff_strAppend(heff_dup(v_x_24124), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str26)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam20_clo)});
  V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})});
  V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  V v_t_24131 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24131})});
  return (g_co_2eop_24s495635622x733177935(v_t_24132, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam21, 1, 8, (V[]){v_x_24101, v_x_24118, v_path_242, v_v_243, v_hd_245, v_k_246, v_x_24124, v_x_244})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam17(V self, V *args) {
  V v_x_24110 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_24101 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24110);
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam18_clo)})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
  V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24117}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam19, 1, 6, (V[]){v_x_24101, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam15(V self, V *args) {
  V v_x_24101 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_24102 = ({ V b_0 = heff_get_n(v_ps_241, 5, 6); V a_1 = heff_dup(v_x_244); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str23); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_24102, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam16_clo)})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam17, 1, 6, (V[]){v_x_244, v_hd_245, v_x_24101, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam11(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_2463 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_dup(heff_rfield(v_x_2463, 0));
  V v_t_2471;
  switch (heff_tag_of(v_t_2467)) {
  case TAG_Exited: {
    V v_n_2468 = heff_field(v_t_2467, 0);
    heff_take_n(v_t_2467, 1ULL, 1);
    v_t_2471 = heff_bool(!heff_intEq_c_lent(v_n_2468, MK_INT(0LL), 2));
    heff_drop(v_n_2468);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2467, 0ULL, 1);
    v_t_2471 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2471 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2471 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2467);
  }
  if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_t_2471);
    V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_244, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam12_clo)})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam13, 1, 4, (V[]){v_path_242, v_x_2463, v_v_243, v_k_246})));
  } else {
    heff_drop_rec(v_x_2463, 3);
    heff_drop(v_t_2471);
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str20), NTAG(TAG_Nil)});
    V v_t_2492 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str22), v_t_2491}), heff_dup(v_x_244), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2492, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam14_clo)})});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})});
    return (g_co_2eop_24s495635622x733177935(v_t_24100, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam15, 1, 6, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2464 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_2465 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2464}));
  return (g_co_2eop_24s495635622x733177935(v_t_2465, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam11, 1, 7, (V[]){v_x_2463, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_v_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2447 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str3), v_t_2447), v_t_2448});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str4), heff_dup(v_v_243)), v_t_2449});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str6), v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str8), v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str10), v_t_2452})});
  V v_c_2454 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str12), v_t_2453}), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str13), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_c_2454, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam9_clo)})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  return (g_co_2eop_24s495635622x733177935(v_t_2462, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam10, 1, 8, (V[]){v_x_2446, v_prog_240, v_hd_245, v_x_244, v_path_242, v_v_243, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_strAppend(heff_dup(v_path_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str1), heff_dup(v_v_243)));
  V v_t_2444 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str2), v_t_2442), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam7_clo)});
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2444}));
  return (g_co_2eop_24s495635622x733177935(v_t_2445, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam8, 1, 7, (V[]){v_path_242, v_x_244, v_v_243, v_hd_245, v_prog_240, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  V v_st_2424 = heff_dup(heff_rfield(v_ps_241, 5));
  HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(v_st_2424, heff_dup(v_x_244)));
  V v_t_2432;
  {
    V v_field_2426 = v_t_2425.f[0];
    V v_field_2427 = v_t_2425.f[1];
    V v_field_2428 = v_t_2425.f[2];
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2428));
    V v_xs_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2429; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
    v_t_2432 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2426, v_field_2427, v_t_2431});
  }
  V v_path_2433 = ({ V a_0 = v_st_2424; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); r_; });
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2433, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam5_clo)})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam6, 1, 7, (V[]){v_path_242, v_v_243, v_prog_240, v_hd_245, v_x_244, v_k_246, v_ps_241})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam3_clo)})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam4, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_prog_240, v_k_246})));
  }
  case TAG_Just: {
    V v_h_24152 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_drop(v_x_244);
    heff_drop(v_hd_245);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    heff_drop(v_prog_240);
    V v_t_24153 = (g_prelude_2eskipSpaces(v_h_24152, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24154 = (heff_unbox_word(heff_strLength_lent(v_h_24152, 0)) - ((int64_t)1ULL));
    V v_t_24155 = (g_prelude_2eskipSpaces(v_h_24152, heff_box_word(v_t_24154), MK_INT(-1LL)));
    V v_t_24156 = heff_strSlice(v_h_24152, v_t_24153, heff_intAdd(v_t_24155, MK_INT(1LL)));
    V v_x_24157 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Right, 1, (V[]){v_t_24156});
    V f_ = v_k_246;
    args[0] = v_x_24157;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_str0)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam1_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_lam2, 1, 7, (V[]){v_x_244, v_hd_245, v_ps_241, v_path_242, v_v_243, v_prog_240, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str1, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str5, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str6, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str8, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str9, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str10, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str11, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str13, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str14, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str15, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str17, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str19, 34, "heff get: cannot write package.hf\012");
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837(V v_prog_240, V v_ps_241, V v_text_242, V v_pk_243, V v_path_244, V v_v_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_244), heff_dup(v_v_245)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_prog_240);
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_text_242);
      heff_drop_rec(v_pk_243, 4);
      heff_drop(v_v_245);
      V v_why_2410 = v_field_248;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam0, 2, 2, (V[]){v_path_244, v_why_2410});
    } else {
      heff_drop(v_field_248);
      V v_c_2431 = (g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416(v_prog_240, heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam3, 2, 6, (V[]){v_c_2431, v_ps_241, v_path_244, v_v_245, v_pk_243, v_text_242});
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam2, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_244 = heff_env(self)[0];
  V v_why_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str0), v_why_2410));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str1), v_t_2413), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str2));
  V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam1, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2452);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam6, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2474);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam8(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam9, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam11(V self, V *args) {
  V v_x_2496 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2496);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam10(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2488);
  V v_t_2489 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam11, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam12(V self, V *args) {
  V v_ok_24110 = args[0];
  return v_ok_24110;
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam14(V self, V *args) {
  V v_x_24127 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24127);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam16(V self, V *args) {
  V v_x_24143 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24143);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam15(V self, V *args) {
  V v_x_24135 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24135);
  V v_t_24136 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24136})});
  V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
  V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
  V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
  V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
  V v_t_24142 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24141})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24142}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam16, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam13(V self, V *args) {
  V v_x_24117 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_hd_2432 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24117) == NTAG(TAG_True))) {
    heff_drop(v_x_24117);
    V v_t_24118 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str16), v_v_245));
    V v_t_24119 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str17), v_t_24118), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str18));
    V v_t_24120 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24119, NTAG(TAG_MkUnit)});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24125})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24126}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam14, 1, 1, (V[]){v_k_2433})));
  } else {
    heff_drop(v_x_24117);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    V v_t_24128 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str19), NTAG(TAG_MkUnit)});
    V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
    V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24134}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam15, 1, 2, (V[]){v_hd_2432, v_k_2433})));
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_pk_243 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  V v_text_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Left: {
    V v_why_2457 = heff_field(v_x_2456, 0);
    V v_ru_24x_2456_24Left = heff_take_reuse_n(v_x_2456, 1ULL, 1);
    heff_drop(v_path_244);
    heff_drop_rec(v_pk_243, 4);
    heff_drop(v_v_245);
    heff_drop(v_text_242);
    V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str6), v_why_2457), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str7));
    V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2458, NTAG(TAG_MkUnit)});
    V v_t_2460 = heff_tag_at_n(v_ru_24x_2456_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam8, 1, 2, (V[]){v_hd_2432, v_k_2433})));
  }
  case TAG_Right: {
    V v_name_2475 = heff_field(v_x_2456, 0);
    V v_ru_24x_2456_24Right = heff_take_reuse_n(v_x_2456, 1ULL, 1);
    V v_x1_2476 = (g_list_2eany_24s1875112453x1656618700(v_path_244, heff_rfield(v_pk_243, 2)));
    V v_t_2477;
    if ((heff_dup(v_x1_2476) == NTAG(TAG_True))) {
      heff_drop(v_x1_2476);
      v_t_2477 = NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2476);
      v_t_2477 = (g_list_2eany_24s332527547x6651279(v_name_2475, heff_rfield(v_pk_243, 2)));
    }
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop_rec(v_pk_243, 4);
      heff_drop(v_v_245);
      heff_drop(v_text_242);
      heff_drop(v_t_2477);
      V v_t_2478 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str8), heff_strAppend(v_path_244, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str9)));
      V v_t_2479 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str10), heff_strAppend(v_name_2475, v_t_2478));
      V v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str11), v_t_2479), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str12));
      V v_t_2481 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2480, NTAG(TAG_MkUnit)});
      V v_t_2482 = heff_tag_at_n(v_ru_24x_2456_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
      V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
      V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam10, 1, 2, (V[]){v_hd_2432, v_k_2433})));
    } else {
      heff_drop(v_t_2477);
      V v_t_2497 = (g_list_2eany_24s1875112453x1656618700(v_path_244, heff_rfield(v_pk_243, 2)));
      V v_t_2499;
      if ((heff_dup(v_t_2497) == NTAG(TAG_True))) {
        heff_drop(v_name_2475);
        heff_drop(v_t_2497);
        v_t_2499 = (g_list_2emap_24s1814289659x520383890(heff_dup(v_path_244), heff_dup(v_v_245), heff_dup(heff_rfield(v_pk_243, 2))));
      } else {
        heff_drop(v_t_2497);
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_2475, heff_dup(v_path_244), heff_dup(v_v_245)}), NTAG(TAG_Nil)});
        v_t_2499 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_243, 2)), v_t_2498));
      }
      V v_t_24100 = ({ V rv_2 = v_t_2499; V rr_ = heff_rec_reuse_nf(v_pk_243, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_text_24101 = (g_heff_2ebuild_2eproject_2ewithPackage(v_text_242, v_t_24100));
      V v_str_24109;
      if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str13), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str14))) {
        HeffT2 v_t_24103 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_24101)));
        {
          V v_field_24105 = v_t_24103.f[1];
          int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
          if ((v_tag_24104 == ((int64_t)0ULL))) {
            V v_x_24107 = v_field_24105;
            heff_drop(v_x_24107);
            v_str_24109 = v_text_24101;
          } else {
            heff_drop(v_text_24101);
            V v_out_24108 = v_field_24105;
            v_str_24109 = v_out_24108;
          }
        }
      } else {
        v_str_24109 = v_text_24101;
      }
      V v_t_24111 = heff_tag_at_n(v_ru_24x_2456_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str15), v_str_24109, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam12_clo)})});
      V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
      V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
      V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
      V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
      V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24115})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24116}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam13, 1, 4, (V[]){v_path_244, v_v_245, v_hd_2432, v_k_2433})));
    }
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    V v_why_2435 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Left = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    heff_drop_rec(v_pk_243, 4);
    heff_drop(v_text_242);
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str3), v_why_2435), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str4));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2436, NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_at_n(v_ru_24x_2434_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam5, 1, 2, (V[]){v_hd_2432, v_k_2433})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2434, 0ULL, 1);
    V v_t_2454 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_t_2455 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), v_t_2454, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_str5)));
    return (g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510(v_ps_241, v_t_2455, heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam7, 1, 6, (V[]){v_hd_2432, v_k_2433, v_path_244, v_pk_243, v_v_245, v_text_242})));
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam3(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_pk_243 = heff_env(self)[4];
  V v_text_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_lam4, 1, 7, (V[]){v_hd_2432, v_k_2433, v_ps_241, v_path_244, v_v_245, v_pk_243, v_text_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_str1, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_243);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    HeffT2 v_t_248 = (g_heff_2ebuild_2eproject_2ereadBuild_24cpr(v_text_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2410;
        V v_t_2413 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_str0), v_x_243));
        V v_p_2414 = (g_std_2epath_2ejoin(v_st_240, v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_str1)));
        V v_t_2415 = (g_std_2epath_2ejoin(v_st_240, heff_get_n(v_t_241, 0, 6), v_p_2414));
        V v_str_2416 = ({ V a_0 = v_t_2415; V a_1 = v_text_247; V a_2 = v_p_2412; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_text_247); r_; });
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam1, 2, 2, (V[]){v_str_2416, v_acc_242});
      } else {
        heff_drop(v_text_247);
        V v_a_2429 = v_field_2410;
        V v_c_2430 = (g_heff_2ebuild_2ecommands_2enotInProject_24s1347055887x980760495(v_st_240, heff_dup(v_t_241), heff_dup(heff_rfield(v_a_2429, 2))));
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam3, 2, 6, (V[]){v_c_2430, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2429});
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2428 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2418;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_str_2416 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2416, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_str2)), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_2417, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam2, 1, 2, (V[]){v_acc_242, v_k_2418})));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2429 = heff_env(self)[4];
  V v_hd_2431 = heff_env(self)[5];
  V v_k_2432 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2429; V a_5 = v_x_2433; V a_6 = v_hd_2431; V a_7 = v_k_2432; V r_ = (g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2429 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_lam4, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2429, v_hd_2431, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713(V v_lit_240, V v_lit_241, V v_lit_242, V v_rep_243, V v_f_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_244), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam1, 1, 7, (V[]){v_f_244, v_hd_245, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_rep_243), v_k_246})));
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_rep_243 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_src_2419;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_src_2419 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_src_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_j_2420 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_str1), v_src_2419, MK_INT(0LL), 5);
  V v_t_2422;
  if (heff_intLt_c_lent(v_j_2420, MK_INT(0LL), 2)) {
    heff_drop(v_j_2420);
    v_t_2422 = heff_strLength_lent(v_src_2419, 0);
  } else {
    v_t_2422 = v_j_2420;
  }
  V v_t_2423 = heff_strEq(heff_strSlice(v_src_2419, MK_INT(0LL), v_t_2422), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_rep_243; V a_1 = v_t_2417; V a_2 = v_f_244; V a_3 = v_t_2423; V a_4 = v_x_2416; V a_5 = v_hd_245; V a_6 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_243); heff_drop(v_t_2423); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_rep_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2415 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_f_244)));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1349594130x2018951713_lam2, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_x_2414, v_rep_243, v_f_244, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}