// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_code 9554612
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_paths 307797256
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_text 10052084
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2emoduleText(V);
V g_heff_2ebuild_2ecommands_2emoduleText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emoduleText_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124(V, V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2etestText(V);
V g_heff_2ebuild_2ecommands_2etestText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestText_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s131934541x153143574(V, V, V, V, V, V);
V g_list_2emap_24s131934541x153143574_entry(V self, V *a);
extern Clo g_list_2emap_24s131934541x153143574_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2ecopy_24s1339645142x382698313(V, V);
V g_std_2efilesystem_2ecopy_24s1339645142x382698313_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ecopy_24s1339645142x382698313_clo;
V g_std_2efilesystem_2emove_24s488840905x1115766714(V, V);
V g_std_2efilesystem_2emove_24s488840905x1115766714_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emove_24s488840905x1115766714_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_text_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str0, 89, "` is the system's (lib/std/), for C: it imports an effect with no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str1, 2, "` ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str2, 19, "` is that effect: `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str4, 1, "`");
Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereachingRefused_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereachingRefused(V v_host_240, V v_s_241, V v_path_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str0), v_host_240));
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_242)));
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    v_t_247 = heff_dup(heff_rfield(v_s_241, 0));
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eimportsOn(v_path_242));
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str1), v_t_248));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str2), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str3), v_t_2410)});
  return heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_241, 0, 8), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str4), v_t_243), v_t_2411});
}
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereachingRefused(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efirstErrorOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efirstErrorOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efirstErrorOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_text_2412 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6); V a_1 = v_text_2412; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2412); r_; });
      V v_t_2414 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9); V b_3 = MK_INT(23LL); V a_4 = MK_INT(23LL); V a_5 = v_t_2413; V r_ = (g_list_2emap_24s131934541x153143574(b_0, b_1, b_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2415 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str0, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str1, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str2, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str4, 17, "package : Package");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str6, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str10, 6, ".heff/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str11, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str12, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str13, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str14, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str15, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str16, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str17, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str18, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str19, 10, "package.hf");
Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str0), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str2), heff_strAppend(heff_dup(v_name_240), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str5); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str7), v_t_245}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str8), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str10); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str11), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str12)));
  V v_t_2410 = (g_heff_2ebuild_2ecommands_2emoduleText(heff_dup(v_name_240)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str14)));
  V v_t_2412 = (g_heff_2ebuild_2ecommands_2eprogramText(heff_dup(v_name_240)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str15), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str16)));
  V v_t_2414 = (g_heff_2ebuild_2ecommands_2etestText(v_name_240));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str17), v_t_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_dup(g_heff_2ebuild_2ecommands_2ebuildText_get())}), v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_t_2412}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2410}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str18), v_t_248}), v_t_2418});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str19), v_t_246}), v_t_2419});
}
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprojectFiles(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s615738393x1686646143(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2(V self, V *args) {
  V v_v_2411 = args[0];
  return v_v_2411;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  return v_v_2420;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2439;
  if (heff_strEq_c(v_x_2437, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str3))) {
    v_st_2439 = NTAG(TAG_Windows);
  } else {
    v_st_2439 = NTAG(TAG_Posix);
  }
  V v_x_2447;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2442;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2428)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2428, 0);
        heff_take_n(v_x_2428, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2428);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      heff_drop(v_x_2428);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_t_2443 = (g_std_2epath_2eparse(v_st_2439, v_t_2442));
    V v_t_2444 = (g_std_2epath_2eparse(v_st_2439, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str5)));
    V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
    v_x_2447 = ({ V a_0 = v_st_2439; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2446 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_2419);
    heff_drop(v_x_2428);
    heff_drop(v_st_2439);
    v_x_2447 = v_d_2446;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_241;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam7, 1, 4, (V[]){v_x_2410, v_x_2419, v_x_2428, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam5, 1, 4, (V[]){v_hd_240, v_x_2410, v_x_2419, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam3, 1, 3, (V[]){v_hd_240, v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str3, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str5, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V v_name_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam0, 1, 3, (V[]){v_hd_241, v_name_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_242;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam5, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    V v_t_2426 = (g_std_2epath_2eparse(v_st_2414, v_x_243));
    V v_t_2427 = (g_std_2epath_2eparse(v_st_2414, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str2)));
    V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
    V v_a_2429 = ({ V a_0 = v_st_2414; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_t_2430 = (g_std_2epath_2eparse(v_st_2414, v_a_2429));
    V v_t_2431 = (g_std_2epath_2eparse(v_st_2414, v_name_240));
    V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
    V v_t_2433 = ({ V a_0 = v_st_2414; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2432); r_; });
    V v_str_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str3), v_t_2433);
    V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2434, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str4)), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2451 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    heff_drop(v_st_2414);
    heff_drop(v_x_243);
    heff_drop(v_name_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_t_2451;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(v_st_2414, heff_dup(v_x_243)));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_2414, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_a_2418 = ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2414, v_a_2418));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2414, heff_dup(v_name_240)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2414; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2423); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3, 1, 5, (V[]){v_st_2414, v_x_243, v_name_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam2, 1, 4, (V[]){v_x_243, v_name_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s615738393x1686646143(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam1, 1, 6, (V[]){v_dir_240, heff_dup(v_name_246), v_p_242, heff_dup(v_text_247), heff_dup(v_rest_245), v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2437) == NTAG(TAG_True))) {
    heff_drop(v_x_2437);
    return ({ V a_0 = v_dir_240; V a_1 = v_rest_245; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
  } else {
    heff_drop(v_x_2437);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_2418, v_name_246));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  V v_path_2429 = ({ V a_0 = v_st_2418; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2428); r_; });
  V v_c_2436;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    V v_t_2430 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2429; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    v_c_2436 = ({ V a_0 = v_t_2430; V a_1 = v_text_247; V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2430); r_; });
    break;
  }
  case TAG_Just: {
    V v_was_2431 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    if (heff_strEq_c_lent(v_was_2431, v_text_247, 1)) {
      heff_drop(v_text_247);
      heff_drop(v_path_2429);
      v_c_2436 = ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3_clo);
    } else {
      V v_t_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2429; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      v_c_2436 = ({ V a_0 = v_t_2435; V a_1 = v_text_247; V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2435); r_; });
    }
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam4, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_name_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2423); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2, 1, 7, (V[]){v_st_2418, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_249, v_x_2415));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_rt_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2415; V a_9 = v_t_2416; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124(V v_rep_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam0, 2, 3, (V[]){v_c_242, v_rep_240, v_file_241});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_rep_240; V a_1 = v_file_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam3, 1, 5, (V[]){v_rep_240, v_file_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_rep_240, v_file_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1437894198x1274248124_lam1, 1, 4, (V[]){v_hd_243, v_rep_240, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str4, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str5, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_n_246) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_244, heff_dup(v_n_246), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam0_clo)})}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam1, 2, 7, (V[]){v_t_248, heff_dup(v_st_241), v_home_243, v_n_246, v_t_242, v_prog_240, v_next_245});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2440);
  V v_t_2441 = (g_std_2epath_2eparse(v_st_241, heff_get_n(v_t_242, 0, 6)));
  V v_t_2442 = (g_std_2epath_2eparse(v_st_241, v_n_246));
  V v_t_2443 = (g_std_2epath_2ejoin(v_t_2441, v_t_2442));
  V v_t_2444 = ({ V a_0 = v_st_241; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2443); r_; });
  V v_t_2445 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str4), v_x_2416));
  V v_why_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str5), v_t_2445);
  V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str6), v_why_2446), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str7));
  V v_t_2448 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam7, 1, 2, (V[]){v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam11(V self, V *args) {
  V v_x_2493 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2491 = heff_env(self)[1];
  V v_k_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2493);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2491;
  heff_room[1] = v_k_2492;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam10(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_t_2487 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2487, heff_dup(v_hd_2491), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam11, 1, 3, (V[]){v_next_245, v_hd_2491, v_k_2492})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam9(V self, V *args) {
  V v_x_2481 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_x_2416 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_next_245 = heff_env(self)[8];
  V v_hd_249 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2482 = (g_std_2epath_2eparse(v_st_241, v_home_243));
  V v_t_2483 = (g_std_2epath_2eparse(v_st_241, v_n_246));
  V v_t_2484 = (g_std_2epath_2ejoin(v_t_2482, v_t_2483));
  V v_t_2485 = ({ V a_0 = v_st_241; V a_1 = v_t_2484; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2484); r_; });
  V v_t_2486 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2487 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2486}));
  V v_t_2490;
  switch (heff_tag_of(v_x_2481)) {
  case TAG_Left: {
    heff_take_n(v_x_2481, 0ULL, 1);
    v_t_2490 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2481, 0ULL, 1);
    v_t_2490 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2481);
  }
  return ({ V a_0 = v_t_242; V a_1 = v_x_2416; V a_2 = v_x_2421; V a_3 = v_t_2485; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam10, 2, 2, (V[]){v_t_2487, v_next_245}); V a_5 = v_t_2490; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2490); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam8(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_n_246 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_t_242 = heff_env(self)[7];
  V v_x_2421 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2472);
  V v_path_2473 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2474 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
  V v_t_2475 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_246)));
  V v_t_2476 = (g_std_2epath_2ejoin(v_t_2474, v_t_2475));
  V v_s_2477 = ({ V a_0 = v_st_241; V a_1 = v_t_2476; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2476); r_; });
  V v_to_2478 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2477; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2479 = ({ V a_0 = v_path_2473; V a_1 = v_to_2478; V r_ = (g_std_2efilesystem_2emove_24s488840905x1115766714(a_0, a_1)); heff_drop(v_path_2473); heff_drop(v_to_2478); r_; });
  V v_c_2480 = heff_tr(heff_call(v_c_2479, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0))}));
  V f_ = v_c_2480;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam9, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_x_2411, v_prog_240, v_t_242, v_x_2416, v_x_2421, v_next_245, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_n_246 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_home_243 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_x_2411 = heff_env(self)[8];
  V v_prog_240 = heff_env(self)[9];
  V v_next_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    heff_take_n(v_x_2436, 0ULL, 1);
    heff_drop(v_home_243);
    heff_drop(v_x_2421);
    heff_drop(v_x_2411);
    heff_drop(v_prog_240);
    heff_drop(v_next_245);
    V v_t_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2439 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2438); r_; });
    V f_ = v_c_2439;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam6, 1, 6, (V[]){v_st_241, v_t_242, v_n_246, v_x_2416, v_hd_249, v_k_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2436, 0ULL, 1);
    V v_t_2464 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
    V v_t_2465 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_246)));
    V v_t_2466 = (g_std_2epath_2ejoin(v_t_2464, v_t_2465));
    V v_s_2467 = ({ V a_0 = v_st_241; V a_1 = v_t_2466; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2466); r_; });
    V v_path_2468 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2467; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_to_2469 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2421); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2470 = ({ V a_0 = v_path_2468; V a_1 = v_to_2469; V r_ = (g_std_2efilesystem_2emove_24s488840905x1115766714(a_0, a_1)); heff_drop(v_path_2468); heff_drop(v_to_2469); r_; });
    V v_c_2471 = heff_tr(heff_call(v_c_2470, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0))}));
    V f_ = v_c_2471;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam8, 1, 11, (V[]){v_x_2416, v_st_241, v_home_243, v_n_246, v_hd_249, v_x_2411, v_prog_240, v_t_242, v_x_2421, v_next_245, v_k_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_home_243 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_x_2411 = heff_env(self)[8];
  V v_prog_240 = heff_env(self)[9];
  V v_next_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2427);
  V v_t_2428 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2429 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_246)));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  V v_s_2431 = ({ V a_0 = v_st_241; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2430); r_; });
  V v_path_2432 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2431; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_to_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2434 = ({ V a_0 = v_path_2432; V a_1 = v_to_2433; V r_ = (g_std_2efilesystem_2ecopy_24s1339645142x382698313(a_0, a_1)); heff_drop(v_path_2432); heff_drop(v_to_2433); r_; });
  V v_c_2435 = heff_tr(heff_call(v_c_2434, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0))}));
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam5, 1, 11, (V[]){v_x_2416, v_hd_249, v_st_241, v_t_242, v_n_246, v_k_2410, v_home_243, v_x_2421, v_x_2411, v_prog_240, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_n_246 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  V v_home_243 = heff_env(self)[7];
  V v_x_2411 = heff_env(self)[8];
  V v_prog_240 = heff_env(self)[9];
  V v_next_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2424);
  V v_t_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2421); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2425); r_; });
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam4, 1, 11, (V[]){v_st_241, v_t_242, v_n_246, v_x_2416, v_hd_249, v_k_2410, v_home_243, v_x_2421, v_x_2411, v_prog_240, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_next_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str0), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str1)));
  V v_t_2414 = (g_std_2epath_2eparse(v_st_241, v_t_2413));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2412, v_t_2414));
  V v_x_2416 = ({ V a_0 = v_st_241; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_home_243)));
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str2), heff_strAppend(heff_dup(v_n_246), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_str3)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_241, v_t_2418));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2417, v_t_2419));
  V v_x_2421 = ({ V a_0 = v_st_241; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2416); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2422); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam3, 1, 11, (V[]){v_x_2421, v_hd_249, v_st_241, v_t_242, v_n_246, v_x_2416, v_k_2410, v_home_243, v_x_2411, v_prog_240, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_n_246 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1074884574x1666611532_lam2, 1, 8, (V[]){v_st_241, v_home_243, v_n_246, v_hd_249, v_t_242, v_k_2410, v_prog_240, v_next_245})));
}