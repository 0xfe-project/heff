// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Value 50841
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_discarded 1490202606
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_source 1050636102
#define LBL_top 324559
#define LBL_watches 1357821955
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2eranLine(V);
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranLine_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2ecommands_2ezigOf(V);
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
HeffT2 g_json_2eat_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_list_2esortBy_24s390982605x1732870695(V);
V g_list_2esortBy_24s390982605x1732870695_entry(V self, V *a);
extern Clo g_list_2esortBy_24s390982605x1732870695_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_245 = v_deps_243;
    } else {
      v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
    }
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eheffErrors(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_wanted_249 = heff_take_field(v_x_248, 5);
  V v_t_2420;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_248, 7);
    heff_drop(v_wanted_249);
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2410 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 3)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
      heff_drop_rec(v_x_248, 7);
      v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), heff_get_n(v_x_248, 0, 7));
    }
    V v_t_2413 = (g_heff_2ebuild_2eproject_2eversion(v_wanted_249));
    V v_t_2414 = (g_heff_2ebuild_2eproject_2eversion(v_running_2410));
    HeffT2 v_t_2415 = ({ V a_0 = v_t_2412; V a_1 = v_wanted_249; V a_2 = v_running_2410; V a_3 = v_t_2413; V a_4 = v_t_2414; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); heff_drop(v_t_2414); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_why_2419 = v_field_2417;
        v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_2417);
        v_t_2420 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_247));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str2, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str5, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str7, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str8, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str9, 6, " times");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str10, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str11, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str12, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str13, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str14, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str15, 16, "  (failed after ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str16, 0, "");
Clo g_heff_2ebuild_2ecommands_2eranLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranLine_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eranLine(V v_o_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_242;
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str0);
  } else {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str1);
  }
  V v_t_243 = heff_dup(heff_rfield(v_o_240, 3));
  V v_t_2419;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_dup(heff_rfield(v_o_240, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ebuild_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str3)));
    } else {
      heff_drop(v_t_244);
      V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
      V v_t_249;
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
        V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str4), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str5)));
      } else {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str6);
      }
      V v_n_2410 = heff_dup(heff_rfield(v_o_240, 6));
      V v_t_2414;
      if (heff_intEq_c_lent(v_n_2410, MK_INT(0LL), 2)) {
        heff_drop(v_n_2410);
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str7);
      } else {
        if (heff_intEq_c_lent(v_n_2410, MK_INT(1LL), 2)) {
          heff_drop(v_n_2410);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str8);
        } else {
          V v_t_2413 = heff_strAppend(heff_intShow(v_n_2410), ((V)&g_heff_2ebuild_2ecommands_2eranLine_str9));
          v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str10), v_t_2413);
        }
      }
      V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_o_240, 10)));
      V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str11), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str12)));
      V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str13), heff_strAppend(v_t_2414, v_t_2416));
      V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str14), heff_strAppend(v_t_249, v_t_2417));
      v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str15), heff_strAppend(v_t_246, v_t_2418));
    }
  } else {
    heff_drop(v_t_243);
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str16);
  }
  V v_t_2420 = heff_strAppend(heff_get_n(v_o_240, 0, 12), v_t_2419);
  return heff_strAppend(v_t_242, v_t_2420);
}
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranSubtests_str0, 8, "subtests");
Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranSubtests_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eranSubtests(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    HeffT2 v_t_243 = (g_json_2esteps_24cpr(v_text_241, v_t_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_why_247 = v_field_245;
        heff_drop(v_why_247);
        return NTAG(TAG_Nil);
      } else {
        V v_j_248 = v_field_245;
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranSubtests_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2410 = (g_json_2eat_24cpr(v_t_249, v_j_248));
        V v_t_2421;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_it1_2414 = v_field_2412;
            switch (heff_tag_of(v_it1_2414)) {
            case TAG_JNull: {
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JArray: {
              V v_xs_2419 = heff_field(v_it1_2414, 0);
              heff_take_n(v_it1_2414, 1ULL, 1);
              v_t_2421 = v_xs_2419;
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            default: heff_nomatch(v_it1_2414);
            }
          } else {
            heff_drop(v_field_2412);
            v_t_2421 = NTAG(TAG_Nil);
          }
        }
        HEFF_LAST return g_list_2emap_24s1618539892x552009225(v_t_2421);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eranSubtests(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esubtestJobs_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esubtestJobs(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_244), NTAG(TAG_Nil)});
    V v_s_247 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_str0); V a_1 = v_s_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_str1), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_247); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_246, v_t_248, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2410 = ({ V a_0 = v_sel_240; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2ecommands_2elevelsSelected(a_0, a_1)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_244, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2413));
      V v_t_2415 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2412, heff_dup(heff_rfield(v_j_241, 3)), v_t_2414, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(v_sel_240, v_j_241, heff_intAdd(v_k_242, MK_INT(1LL)), v_rest_245, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop(v_n_244);
      heff_drop(v_t_2410);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_245;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esubtestJobs(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    V v_s_248 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str0); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str1), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_247, v_t_249, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2411 = ({ V a_0 = v_sel_240; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2ecommands_2elevelsSelected(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, NTAG(TAG_Nil)});
      V v_t_2415 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2414));
      V v_t_2416 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2413, heff_dup(heff_rfield(v_j_241, 3)), v_t_2415, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_cell_2417;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_d_244;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_249) == NTAG(TAG_True))) {
    heff_drop(v_x_249);
    heff_drop(v_outPath_240);
    V f_ = v_done_241;
    heff_room[0] = v_hd_243;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_249);
    heff_drop(v_done_241);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str1));
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_take_field(v_o_242, 1);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_outPath_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_248 = ({ V a_0 = v_t_247; V a_1 = heff_get_n(v_o_242, 0, 2); V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_247); r_; });
    V f_ = v_c_248;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24t_246_24Cons = heff_take_reuse_n(v_t_246, 0ULL, 2);
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    V v_t_2428 = heff_tag_at_n(v_ru_24t_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025(V v_rep_240, V v_file_241, V v_badL_242, V v_cs_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_243)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_lam0, 1, 5, (V[]){v_cs_243, heff_dup(v_badL_242), v_z_244, v_z_245, v_file_241})});
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_lam1(V self, V *args) {
  V v_x_2434 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_2434) == NTAG(TAG_True))) {
    heff_drop(v_x_2434);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2434);
    V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_z_244, v_z_245));
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_badL_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_file_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_247);
  HeffT2 v_t_248 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_243)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_c_2412 = v_field_2410;
      if ((heff_dup(v_badL_242) == NTAG(TAG_True))) {
        heff_drop(v_cs_243);
        heff_drop(v_badL_242);
        heff_drop(v_file_241);
        heff_drop_rec(v_c_2412, 14);
        V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
        V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
        return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_z_244, v_z_245));
      } else {
        heff_drop(v_badL_242);
        V v_t_2420 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_243); r_; });
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_file_241);
          heff_drop_rec(v_c_2412, 14);
          heff_drop(v_t_2420);
          V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
          V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
          return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_244, v_z_245));
        } else {
          heff_drop(v_t_2420);
          V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_file_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 4, 9);
          V v_t_2430 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2412), v_t_2429));
          V v_t_2431 = (g_list_2esortBy_24s390982605x1732870695(v_t_2430));
          V v_t_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str1); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str2); V a_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_str3); V b_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_2412, 3, 14); V a_7 = v_t_2431; V r_ = (g_list_2efoldl_24s1149369025x804005338(a_0, a_1, b_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(v_t_2431); r_; });
          V v_c_2433 = ({ V a_0 = v_t_2428; V a_1 = v_t_2432; V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2428); r_; });
          V f_ = v_c_2433;
          heff_room[0] = heff_dup(v_z_244);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1063366330x1732579025_lam1, 1, 2, (V[]){v_z_245, v_z_244});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    } else {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      heff_drop(v_file_241);
      heff_drop(v_field_2410);
      V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_244, v_z_245));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str1, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str2, 39, " -femit-bin=runtime.o` and `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str3, 26, " runtime.o -o PROGRAM -lm`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str4, 46, ": build it with `zig build-obj -O ReleaseFast ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str5, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597(V v_rep_240, V v_name_241, V v_outPath_242, V v_file_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2ecommands_2ezigOf(heff_dup(v_outPath_242)));
  int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_outPath_242, 0)) - ((int64_t)1ULL));
  V v_t_246 = heff_strSlice(heff_dup(v_outPath_242), heff_box_word(v_t_245), heff_strLength_lent(v_outPath_242, 0));
  V v_t_248;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str0))) {
    v_t_248 = heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str1));
  } else {
    v_t_248 = heff_dup(v_outPath_242);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str2), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str3)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str4), heff_strAppend(v_t_244, v_t_249));
  V v_str_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str5), heff_strAppend(heff_dup(v_outPath_242), v_t_2410));
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_lam0, 2, 6, (V[]){v_c_2412, v_str_2411, v_rep_240, v_name_241, v_outPath_242, v_file_243});
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_str_2411 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2411, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_str6)), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(MK_INT(1LL), v_rep_240, v_x_2415, v_name_241, v_outPath_242, v_file_243, v_t_2423, v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_str_2411 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_file_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_lam1, 1, 7, (V[]){v_str_2411, v_rep_240, v_name_241, v_outPath_242, v_file_243, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str5, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str6, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str7, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam0, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_dir_243, v_hd_245, v_t_241, v_next_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  V f_ = v_next_244;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam3(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_next_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2419) == NTAG(TAG_True))) {
    heff_drop(v_x_2419);
    V v_t_2420 = (g_std_2epath_2eparse(v_st_240, v_home_242));
    V v_t_2421 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str2)));
    V v_t_2422 = (g_std_2epath_2ejoin(v_t_2420, v_t_2421));
    V v_path_2423 = ({ V a_0 = v_st_240; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2422); r_; });
    V v_t_2424 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str3), v_path_2423));
    V v_t_2425 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str4)), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2, 1, 3, (V[]){v_next_244, v_hd_245, v_k_246})));
  } else {
    heff_drop(v_x_2419);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_244);
    V v_t_2433 = (g_std_2epath_2eparse(v_st_240, v_home_242));
    V v_t_2434 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str5)));
    V v_t_2435 = (g_std_2epath_2ejoin(v_t_2433, v_t_2434));
    V v_t_2436 = ({ V a_0 = v_st_240; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2435); r_; });
    V v_why_2437 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str6), v_t_2436);
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str7), v_why_2437), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str8));
    V v_t_2439 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2438, NTAG(TAG_MkUnit)});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam3, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str0)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_s_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2411; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, v_x_247));
  V v_t_2414 = (g_std_2epath_2eparse(v_st_240, v_dir_243));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  V v_t_2416 = ({ V a_0 = v_st_240; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2eutil_2ehostpath_2enormalize(v_st_240, v_t_2416));
  V v_c_2418 = ({ V a_0 = v_t_2412; V a_1 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str1)); V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1, 1, 6, (V[]){v_st_240, v_home_242, v_t_241, v_hd_245, v_next_244, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}