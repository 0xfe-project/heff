// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_Inherited 58190
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Processors 11008
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bin 307073
#define LBL_checked 974171621
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_loaded 849622832
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_shipTo 1043811586
#define LBL_shrinks 154032591
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_watches 1357821955
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_file__wrong__reports__outcomes__integrations__loaded__checked[] = {LBL_file, LBL_wrong, LBL_reports, LBL_outcomes, LBL_integrations, LBL_loaded, LBL_checked};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_clo;
V g_heff_2ebuild_2ecommands_2eranLine(V);
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranLine_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
HeffT2 g_heff_2ebuild_2edriver_2erunTests_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
HeffT2 g_json_2eat_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprocess_2ewithProcess_24s461807610x1567722616(V, V, V, V);
V g_std_2eprocess_2ewithProcess_24s461807610x1567722616_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s461807610x1567722616_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_245 = v_deps_243;
    } else {
      v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
    }
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eheffErrors(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_wanted_249 = heff_take_field(v_x_248, 5);
  V v_t_2420;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_248, 7);
    heff_drop(v_wanted_249);
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2410 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 3)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
      heff_drop_rec(v_x_248, 7);
      v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), heff_get_n(v_x_248, 0, 7));
    }
    V v_t_2413 = (g_heff_2ebuild_2eproject_2eversion(v_wanted_249));
    V v_t_2414 = (g_heff_2ebuild_2eproject_2eversion(v_running_2410));
    HeffT2 v_t_2415 = ({ V a_0 = v_t_2412; V a_1 = v_wanted_249; V a_2 = v_running_2410; V a_3 = v_t_2413; V a_4 = v_t_2414; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); heff_drop(v_t_2414); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_why_2419 = v_field_2417;
        v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_2417);
        v_t_2420 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_247));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str2, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str5, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str7, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str8, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str9, 6, " times");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str10, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str11, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str12, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str13, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str14, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str15, 16, "  (failed after ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str16, 0, "");
Clo g_heff_2ebuild_2ecommands_2eranLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranLine_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eranLine(V v_o_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_242;
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str0);
  } else {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str1);
  }
  V v_t_243 = heff_dup(heff_rfield(v_o_240, 3));
  V v_t_2419;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_dup(heff_rfield(v_o_240, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ebuild_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str3)));
    } else {
      heff_drop(v_t_244);
      V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
      V v_t_249;
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
        V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str4), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str5)));
      } else {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str6);
      }
      V v_n_2410 = heff_dup(heff_rfield(v_o_240, 6));
      V v_t_2414;
      if (heff_intEq_c_lent(v_n_2410, MK_INT(0LL), 2)) {
        heff_drop(v_n_2410);
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str7);
      } else {
        if (heff_intEq_c_lent(v_n_2410, MK_INT(1LL), 2)) {
          heff_drop(v_n_2410);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str8);
        } else {
          V v_t_2413 = heff_strAppend(heff_intShow(v_n_2410), ((V)&g_heff_2ebuild_2ecommands_2eranLine_str9));
          v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str10), v_t_2413);
        }
      }
      V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_o_240, 10)));
      V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str11), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str12)));
      V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str13), heff_strAppend(v_t_2414, v_t_2416));
      V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str14), heff_strAppend(v_t_249, v_t_2417));
      v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str15), heff_strAppend(v_t_246, v_t_2418));
    }
  } else {
    heff_drop(v_t_243);
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str16);
  }
  V v_t_2420 = heff_strAppend(heff_get_n(v_o_240, 0, 12), v_t_2419);
  return heff_strAppend(v_t_242, v_t_2420);
}
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranSubtests_str0, 8, "subtests");
Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranSubtests_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eranSubtests(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    HeffT2 v_t_243 = (g_json_2esteps_24cpr(v_text_241, v_t_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_why_247 = v_field_245;
        heff_drop(v_why_247);
        return NTAG(TAG_Nil);
      } else {
        V v_j_248 = v_field_245;
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranSubtests_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2410 = (g_json_2eat_24cpr(v_t_249, v_j_248));
        V v_t_2421;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_it1_2414 = v_field_2412;
            switch (heff_tag_of(v_it1_2414)) {
            case TAG_JNull: {
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JArray: {
              V v_xs_2419 = heff_field(v_it1_2414, 0);
              heff_take_n(v_it1_2414, 1ULL, 1);
              v_t_2421 = v_xs_2419;
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            default: heff_nomatch(v_it1_2414);
            }
          } else {
            heff_drop(v_field_2412);
            v_t_2421 = NTAG(TAG_Nil);
          }
        }
        HEFF_LAST return g_list_2emap_24s1618539892x552009225(v_t_2421);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eranSubtests(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esubtestJobs_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esubtestJobs(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_244), NTAG(TAG_Nil)});
    V v_s_247 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_str0); V a_1 = v_s_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_str1), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_247); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_246, v_t_248, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2410 = ({ V a_0 = v_sel_240; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2ecommands_2elevelsSelected(a_0, a_1)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_244, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2413));
      V v_t_2415 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2412, heff_dup(heff_rfield(v_j_241, 3)), v_t_2414, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(v_sel_240, v_j_241, heff_intAdd(v_k_242, MK_INT(1LL)), v_rest_245, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop(v_n_244);
      heff_drop(v_t_2410);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_245;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esubtestJobs(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    V v_s_248 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str0); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str1), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_247, v_t_249, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2411 = ({ V a_0 = v_sel_240; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2ecommands_2elevelsSelected(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, NTAG(TAG_Nil)});
      V v_t_2415 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2414));
      V v_t_2416 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2413, heff_dup(heff_rfield(v_j_241, 3)), v_t_2415, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_cell_2417;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_d_244;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str3, 17, "heff test: --run ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str5, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str6, 0, "");
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_update_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_pattern_241, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
  HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
  V v_c_2437;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_why_2412 = v_field_2410;
      v_c_2437 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam0, 2, 2, (V[]){heff_dup(v_pattern_241), v_why_2412});
    } else {
      V v_x_2434 = v_field_2410;
      heff_drop(v_x_2434);
      v_c_2437 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam3, 2, 5, (V[]){v_c_2437, heff_dup(v_seed_240), heff_dup(v_pattern_241), heff_dup(v_jobs_242), v_update_243});
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_pattern_241 = heff_env(self)[0];
  V v_why_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str2), v_why_2412));
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str3), v_t_2417), ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str4));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam1, 1, 2, (V[]){v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam5(V self, V *args) {
  V v_n_2441 = args[0];
  return v_n_2441;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam7(V self, V *args) {
  V v_v_2450 = args[0];
  return v_v_2450;
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_pattern_241 = heff_env(self)[1];
  V v_x_2449 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2465;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_2465 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2459 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    HeffT2 v_t_2460 = ({ V a_0 = v_s_2459; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2459); r_; });
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_x_2464 = v_field_2462;
        v_t_2465 = v_x_2464;
      } else {
        heff_drop(v_field_2462);
        v_t_2465 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2467;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2467 = ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2466 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2467 = v_x_2466;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_fallback_2469;
  if (heff_intLt_c(heff_intDiv(heff_dup(v_x_2449), MK_INT(2LL)), MK_INT(1LL))) {
    heff_drop(v_x_2449);
    v_fallback_2469 = MK_INT(1LL);
  } else {
    v_fallback_2469 = heff_intDiv(v_x_2449, MK_INT(2LL));
  }
  V v_fallback_2477;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_fallback_2477 = v_fallback_2469;
    break;
  }
  case TAG_Just: {
    V v_n_2470 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    HeffT2 v_t_2471 = ({ V a_0 = v_n_2470; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2470); r_; });
    {
      V v_field_2473 = v_t_2471.f[1];
      int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
      if ((v_tag_2472 == ((int64_t)0ULL))) {
        V v_k_2475 = v_field_2473;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2475, 1)) {
          heff_drop(v_fallback_2469);
          v_fallback_2477 = v_k_2475;
        } else {
          heff_drop(v_k_2475);
          v_fallback_2477 = v_fallback_2469;
        }
      } else {
        heff_drop(v_field_2473);
        v_fallback_2477 = v_fallback_2469;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_t_2485;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2485 = v_fallback_2477;
    break;
  }
  case TAG_Just: {
    V v_n_2478 = heff_field(v_jobs_242, 0);
    heff_take_n(v_jobs_242, 1ULL, 1);
    HeffT2 v_t_2479 = ({ V a_0 = v_n_2478; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2478); r_; });
    {
      V v_field_2481 = v_t_2479.f[1];
      int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
      if ((v_tag_2480 == ((int64_t)0ULL))) {
        V v_k_2483 = v_field_2481;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2483, 1)) {
          heff_drop(v_fallback_2477);
          v_t_2485 = v_k_2483;
        } else {
          heff_drop(v_k_2483);
          v_t_2485 = v_fallback_2477;
        }
      } else {
        heff_drop(v_field_2481);
        v_t_2485 = v_fallback_2477;
      }
    }
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_x_2486 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_t_2465, v_t_2467, v_t_2485, v_update_243});
  V f_ = v_k_2439;
  args[0] = v_x_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam6(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_str5), ((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam7_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s495635622x733177935(v_t_2457, v_hd_2438, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam8, 1, 6, (V[]){v_seed_240, v_pattern_241, v_x_2449, v_jobs_242, v_update_243, v_k_2439})));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2440);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Processors, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam5_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s495635622x733177935(v_t_2448, heff_dup(v_hd_2438), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam6, 1, 6, (V[]){v_hd_2438, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2439})));
}
V g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam3(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOptions_24s220388156x1028983384_lam4, 1, 6, (V[]){v_hd_2438, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str2, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str7, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str9, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str11, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837(V v_ex_240, V v_argv_241, V v_n_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2415;
  if (heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam0_clo);
  } else {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str0), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    v_t_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
  }
  return heff_tail(v_t_2415, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam1, 1, 5, (V[]){v_hd_243, v_ex_240, v_argv_241, v_n_242, v_k_244})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam7(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2447 = args[1];
  V v_k_2448 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2446);
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_intAdd(v_n_242, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2427 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V f_ = v_k_2427;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam7, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_intShow(heff_intAdd(heff_dup(v_n_242), MK_INT(1LL)));
  V v_t_2431 = heff_get_n(v_x_2429, 0, 3);
  V v_t_2435;
  switch (heff_tag_of(v_t_2431)) {
  case TAG_Exited: {
    V v_n_2432 = heff_field(v_t_2431, 0);
    heff_take_n(v_t_2431, 1ULL, 1);
    if (heff_intEq_c(v_n_2432, MK_INT(0LL))) {
      v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str2);
    } else {
      v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str3);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2431, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str4);
    break;
  }
  case TAG_TimedOut: {
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str5);
    break;
  }
  case TAG_NotRun: {
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str6);
    break;
  }
  default: heff_nomatch(v_t_2431);
  }
  V v_t_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str7), heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str8)));
  V v_t_2437 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str9), heff_strAppend(v_t_2430, v_t_2436));
  V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str10)), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2426, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam6, 1, 2, (V[]){v_k_2427, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2425, v_argv_241, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str1), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  return (g_std_2eprocess_2ewithProcess_24s461807610x1567722616(v_ex_240, v_t_2428, heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam5, 1, 3, (V[]){v_n_242, v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2461 = args[1];
  V v_k_2462 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2460);
  heff_drop(v_hd_2461);
  V f_ = v_k_2462;
  args[0] = heff_intAdd(v_n_242, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam9(V self, V *args) {
  V v_x_2459 = args[0];
  V v_k_2451 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2459);
  V f_ = v_k_2451;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam10, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam8(V self, V *args) {
  V v_err_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_err_2449);
  V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_str11), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_2450, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam9, 1, 2, (V[]){v_k_2451, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2464;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2463 = heff_tr(heff_call(heff_dup(v_ex_240), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam4, 2, 4, (V[]){v_x_2425, v_argv_241, v_ex_240, heff_dup(v_n_242)}), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam8, 3, 1, (V[]){v_n_242})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2463, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam11, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_argv_241 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam2_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s495635622x733177935(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s452216513x1587860837_lam3, 1, 5, (V[]){v_ex_240, v_argv_241, v_n_242, v_hd_243, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str2, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str4, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str6, 13, ": not checked");
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969(V v_rep_240, V v_opts_241, V v_f_242, V v_l_243, V v_cs_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_247 = (g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(v_cs_244));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam0, 1, 6, (V[]){v_cs_244, v_l_243, v_opts_241, v_f_242, v_z_246, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam1(V self, V *args) {
  V v_w_2421 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2413, v_w_2421));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam2(V self, V *args) {
  V v_w_2444 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2413, v_w_2444));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam3(V self, V *args) {
  V v_w_2462 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2413, v_w_2462));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam4(V self, V *args) {
  V v_x_2475 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_cs_244 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_get_n(v_l_243, 1, 5);
  V v_why_2484;
  switch (heff_tag_of(v_t_2476)) {
  case TAG_Nil: {
    HeffT2 v_t_2477 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_244));
    {
      V v_field_2479 = v_t_2477.f[1];
      int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
      if ((v_tag_2478 == ((int64_t)0ULL))) {
        heff_drop(v_f_242);
        V v_x_2481 = v_field_2479;
        v_why_2484 = v_x_2481;
      } else {
        heff_drop(v_field_2479);
        v_why_2484 = heff_strAppend(v_f_242, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str6));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2482 = heff_field(v_t_2476, 0);
    heff_take_n(v_t_2476, 1ULL, 2);
    heff_drop(v_cs_244);
    heff_drop(v_f_242);
    v_why_2484 = v_why_2482;
    break;
  }
  default: heff_nomatch(v_t_2476);
  }
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2484, NTAG(TAG_Nil)});
  V v_x_2486 = heff_tag_n(TAG_Settled, 1, (V[]){heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2485, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)})});
  V f_ = v_z_246;
  args[0] = v_x_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_cs_244 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_244)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_z_245);
      V v_c_2413 = v_field_2411;
      V v_t_2414 = heff_dup(heff_rfield(v_l_243, 1));
      V v_x_2466;
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nil: {
        if (heff_intEq_c(v_x_248, MK_INT(0LL))) {
          heff_drop(v_cs_244);
          HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2erunTests_24cpr(heff_dup(heff_rfield(v_opts_241, 1)), heff_take_field(v_opts_241, 0), heff_dup(v_c_2413)));
          {
            V v_field_2417 = v_t_2416.f[0];
            V v_field_2418 = v_t_2416.f[1];
            V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 4, 9);
            V v_t_2420 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2413), v_t_2419));
            V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam1, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2420));
            V v_t_2423 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2422));
            V v_p_2424 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, NTAG(TAG_Nil), v_t_2423, v_field_2417, v_field_2418, v_l_243, v_c_2413});
            if (heff_strEq_c(heff_get_n(v_opts_241, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str0))) {
              v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2424});
            } else {
              V v_t_2426 = heff_dup(heff_rfield(v_p_2424, 3));
              switch (heff_tag_of(v_t_2426)) {
              case TAG_Nil: {
                V v_t_2427 = heff_dup(heff_rfield(v_p_2424, 4));
                switch (heff_tag_of(v_t_2427)) {
                case TAG_Nil: {
                  heff_drop_rec(v_p_2424, 7);
                  v_x_2466 = heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_t_2427, 0ULL, 2);
                  v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2424});
                  break;
                }
                default: heff_nomatch(v_t_2427);
                }
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2426, 0ULL, 2);
                v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2424});
                break;
              }
              default: heff_nomatch(v_t_2426);
              }
            }
          }
        } else {
          heff_drop_rec(v_opts_241, 4);
          V v_t_2432 = heff_dup(heff_rfield(v_l_243, 1));
          V v_t_2440;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_Nil: {
            HeffT2 v_t_2433 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_244));
            {
              V v_field_2435 = v_t_2433.f[1];
              int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
              if ((v_tag_2434 == ((int64_t)0ULL))) {
                V v_x_2437 = v_field_2435;
                v_t_2440 = v_x_2437;
              } else {
                heff_drop(v_field_2435);
                v_t_2440 = heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str1));
              }
            }
            break;
          }
          case TAG_Cons: {
            V v_why_2438 = heff_field(v_t_2432, 0);
            heff_take_n(v_t_2432, 1ULL, 2);
            heff_drop(v_cs_244);
            v_t_2440 = v_why_2438;
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_wrong_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
          V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 4, 9);
          V v_t_2443 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2413), v_t_2442));
          V v_t_2445 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam2, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2443));
          V v_t_2446 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2445));
          V v_t_2447 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, v_wrong_2441, v_t_2446, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_243, v_c_2413});
          v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2447});
        }
        break;
      }
      case TAG_Cons: {
        V v_ru_24t_2414_24Cons = heff_take_reuse_n(v_t_2414, 0ULL, 2);
        heff_drop(v_x_248);
        heff_drop_rec(v_opts_241, 4);
        V v_t_2450 = heff_dup(heff_rfield(v_l_243, 1));
        V v_t_2458;
        switch (heff_tag_of(v_t_2450)) {
        case TAG_Nil: {
          HeffT2 v_t_2451 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_244));
          {
            V v_field_2453 = v_t_2451.f[1];
            int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
            if ((v_tag_2452 == ((int64_t)0ULL))) {
              V v_x_2455 = v_field_2453;
              v_t_2458 = v_x_2455;
            } else {
              heff_drop(v_field_2453);
              v_t_2458 = heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str2));
            }
          }
          break;
        }
        case TAG_Cons: {
          V v_why_2456 = heff_field(v_t_2450, 0);
          heff_take_n(v_t_2450, 1ULL, 2);
          heff_drop(v_cs_244);
          v_t_2458 = v_why_2456;
          break;
        }
        default: heff_nomatch(v_t_2450);
        }
        V v_wrong_2459 = heff_tag_at_n(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
        V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 4, 9);
        V v_t_2461 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2413), v_t_2460));
        V v_t_2463 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam3, 1, 1, (V[]){heff_dup(v_c_2413)}), v_t_2461));
        V v_t_2464 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2463));
        V v_t_2465 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_242, v_wrong_2459, v_t_2464, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_243, v_c_2413});
        v_x_2466 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2465});
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      V f_ = v_z_246;
      args[0] = v_x_2466;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x_248);
      heff_drop_rec(v_opts_241, 4);
      heff_drop(v_field_2411);
      V v_t_2467 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str3), heff_strAppend(heff_dup(v_f_242), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str4)));
      V v_t_2468 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_str5)), NTAG(TAG_MkUnit)});
      V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s927898923x411427969_lam4, 1, 4, (V[]){v_l_243, v_cs_244, v_f_242, v_z_246})));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str2, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str4, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str7, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str8, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str9, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506(V v_rep_240, V v_prog_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam1, 1, 4, (V[]){v_hd_242, v_k_243, v_rep_240, v_prog_241})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2422;
  if (heff_strEq_c(v_x_2420, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str1))) {
    v_st_2422 = NTAG(TAG_Windows);
  } else {
    v_st_2422 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_2422);
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str2), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam4, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2411, 0ULL, 1);
    V v_t_2439 = (g_std_2epath_2ejoin(v_st_2422, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str3), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str4)));
    V v_t_2440 = (g_std_2epath_2ejoin(v_st_2422, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str5), v_t_2439));
    V v_t_2441 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str6), v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str7), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str8)});
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1157715821x796893989(v_rep_240, v_prog_241, v_st_2422, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_str9), v_t_2441, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1701547932x883959506_lam3, 1, 5, (V[]){v_x_2411, v_hd_242, v_k_243, v_rep_240, v_prog_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str0, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str1, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str2, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669(V v_v_240, V v_pk_241, V v_r_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_2410;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 3)))) {
    v_t_2410 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 6)))) {
      v_t_2410 = NTAG(TAG_True);
    } else {
      V v_t_247 = heff_dup(heff_rfield(v_r_242, 4));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_247, 0ULL, 2);
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
    }
  }
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_intShow(heff_take_field(v_r_242, 3));
    V v_t_2412 = heff_intShow(heff_take_field(v_r_242, 2));
    V v_t_2413 = heff_intShow(heff_take_field(v_r_242, 6));
    V v_t_2414 = heff_intShow(heff_get_n(v_r_242, 5, 8));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str0), heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str1)));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str2), heff_strAppend(v_t_2413, v_t_2415));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str3), heff_strAppend(v_t_2412, v_t_2416));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str4), heff_strAppend(v_t_2411, v_t_2417));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_str5)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_lam0, 1, 2, (V[]){v_p_243, v_p_244})));
  } else {
    heff_drop_rec(v_r_242, 8);
    heff_drop(v_t_2410);
    return (g_heff_2ebuild_2ecommands_2epublishTag_24s621893899x1430447442(v_v_240, v_pk_241, v_p_243, v_p_244));
  }
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_p_243, v_p_244));
}