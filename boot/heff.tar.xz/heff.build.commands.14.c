// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_discarded 1490202606
#define LBL_heff 9694020
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_shipTo 1043811586
#define LBL_shrinks 154032591
#define LBL_top 324559
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657(V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_clo;
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_clo;
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_clo;
V g_heff_2ebuild_2ecommands_2elevelsSelected(V, V);
V g_heff_2ebuild_2ecommands_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elevelsSelected_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847(V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2eranLine(V);
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranLine_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_clo;
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_clo;
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_json_2eat_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1618539892x552009225(V);
V g_list_2emap_24s1618539892x552009225_entry(V self, V *a);
extern Clo g_list_2emap_24s1618539892x552009225_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_245 = v_deps_243;
    } else {
      v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
    }
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eheffErrors(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_wanted_249 = heff_take_field(v_x_248, 5);
  V v_t_2420;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_248, 7);
    heff_drop(v_wanted_249);
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2410 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 3)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
      heff_drop_rec(v_x_248, 7);
      v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), heff_get_n(v_x_248, 0, 7));
    }
    V v_t_2413 = (g_heff_2ebuild_2eproject_2eversion(v_wanted_249));
    V v_t_2414 = (g_heff_2ebuild_2eproject_2eversion(v_running_2410));
    HeffT2 v_t_2415 = ({ V a_0 = v_t_2412; V a_1 = v_wanted_249; V a_2 = v_running_2410; V a_3 = v_t_2413; V a_4 = v_t_2414; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); heff_drop(v_t_2414); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_why_2419 = v_field_2417;
        v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_2417);
        v_t_2420 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_247));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str2, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str5, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str7, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str8, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str9, 6, " times");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str10, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str11, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str12, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str13, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str14, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str15, 16, "  (failed after ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranLine_str16, 0, "");
Clo g_heff_2ebuild_2ecommands_2eranLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranLine_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eranLine(V v_o_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_242;
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str0);
  } else {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str1);
  }
  V v_t_243 = heff_dup(heff_rfield(v_o_240, 3));
  V v_t_2419;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_dup(heff_rfield(v_o_240, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ebuild_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str3)));
    } else {
      heff_drop(v_t_244);
      V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
      V v_t_249;
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 5)))) {
        V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_o_240, 5)));
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str4), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str5)));
      } else {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str6);
      }
      V v_n_2410 = heff_dup(heff_rfield(v_o_240, 6));
      V v_t_2414;
      if (heff_intEq_c_lent(v_n_2410, MK_INT(0LL), 2)) {
        heff_drop(v_n_2410);
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str7);
      } else {
        if (heff_intEq_c_lent(v_n_2410, MK_INT(1LL), 2)) {
          heff_drop(v_n_2410);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str8);
        } else {
          V v_t_2413 = heff_strAppend(heff_intShow(v_n_2410), ((V)&g_heff_2ebuild_2ecommands_2eranLine_str9));
          v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str10), v_t_2413);
        }
      }
      V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_o_240, 10)));
      V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str11), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eranLine_str12)));
      V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str13), heff_strAppend(v_t_2414, v_t_2416));
      V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str14), heff_strAppend(v_t_249, v_t_2417));
      v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranLine_str15), heff_strAppend(v_t_246, v_t_2418));
    }
  } else {
    heff_drop(v_t_243);
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2eranLine_str16);
  }
  V v_t_2420 = heff_strAppend(heff_get_n(v_o_240, 0, 12), v_t_2419);
  return heff_strAppend(v_t_242, v_t_2420);
}
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranSubtests_str0, 8, "subtests");
Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranSubtests_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eranSubtests(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    HeffT2 v_t_243 = (g_json_2esteps_24cpr(v_text_241, v_t_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_why_247 = v_field_245;
        heff_drop(v_why_247);
        return NTAG(TAG_Nil);
      } else {
        V v_j_248 = v_field_245;
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranSubtests_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2410 = (g_json_2eat_24cpr(v_t_249, v_j_248));
        V v_t_2421;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_it1_2414 = v_field_2412;
            switch (heff_tag_of(v_it1_2414)) {
            case TAG_JNull: {
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            case TAG_JArray: {
              V v_xs_2419 = heff_field(v_it1_2414, 0);
              heff_take_n(v_it1_2414, 1ULL, 1);
              v_t_2421 = v_xs_2419;
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2414, 0ULL, 1);
              v_t_2421 = NTAG(TAG_Nil);
              break;
            }
            default: heff_nomatch(v_it1_2414);
            }
          } else {
            heff_drop(v_field_2412);
            v_t_2421 = NTAG(TAG_Nil);
          }
        }
        HEFF_LAST return g_list_2emap_24s1618539892x552009225(v_t_2421);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eranSubtests(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esubtestJobs_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esubtestJobs(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_244), NTAG(TAG_Nil)});
    V v_s_247 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_str0); V a_1 = v_s_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_str1), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_247); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_246, v_t_248, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2410 = ({ V a_0 = v_sel_240; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2ecommands_2elevelsSelected(a_0, a_1)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_244, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2413));
      V v_t_2415 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2412, heff_dup(heff_rfield(v_j_241, 3)), v_t_2414, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(v_sel_240, v_j_241, heff_intAdd(v_k_242, MK_INT(1LL)), v_rest_245, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop(v_n_244);
      heff_drop(v_t_2410);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_245;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esubtestJobs(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_j_241, 6);
    heff_drop(v_k_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    V v_s_248 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str0); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_str1), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_247, v_t_249, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2411 = ({ V a_0 = v_sel_240; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2ecommands_2elevelsSelected(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, NTAG(TAG_Nil)});
      V v_t_2415 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2414));
      V v_t_2416 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2413, heff_dup(heff_rfield(v_j_241, 3)), v_t_2415, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_cell_2417;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_d_244;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2esubtestJobs_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esubtestJobs_24dps(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam1(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam3(V self, V *args) {
  V v_ns_2415 = args[0];
  return v_ns_2415;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2425);
    heff_drop(v_done_241);
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_str1));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam7, 1, 2, (V[]){v_p_243, v_p_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2424);
  return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam6, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_t_2423; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam5, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam3_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam1_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2442 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656(V v_opts_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_opts_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_src_2414;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_src_2414 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_src_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_str1), v_src_2414, MK_INT(0LL), 5);
  V v_t_2417;
  if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
    heff_drop(v_j_2415);
    v_t_2417 = heff_strLength_lent(v_src_2414, 0);
  } else {
    v_t_2417 = v_j_2415;
  }
  V v_t_2418 = heff_strEq(heff_strSlice(v_src_2414, MK_INT(0LL), v_t_2417), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_t_2418; V a_3 = v_x_2412; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2418); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_f_241)));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1584382260x1783258656_lam2, 1, 5, (V[]){v_x_2410, v_opts_240, v_f_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str3, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str7, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str9, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str10, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str11, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709(V v_prog_240, V v_spec_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str0), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam1, 1, 4, (V[]){v_hd_242, v_k_243, v_spec_241, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam4(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2461}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam5(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2478);
  V v_t_2479 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2484}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam8(V self, V *args) {
  V v_hd_24101 = args[0];
  V v_k_24102 = args[1];
  V v_v_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24101);
  V f_ = v_k_24102;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_24100});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam10(V self, V *args) {
  V v_x_24113 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24113);
  V v_t_24114 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24119}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam11(V self, V *args) {
  V v_x_24133 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24133) == NTAG(TAG_True))) {
    heff_drop(v_x_24133);
    return (g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113(v_prog_240, v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_24133);
    heff_drop(v_prog_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam12(V self, V *args) {
  V v_x_24142 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24142);
  V v_t_24143 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
  V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24148}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam9(V self, V *args) {
  V v_x_24104 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_s_2463 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2488 = heff_env(self)[4];
  V v_t_2424 = heff_env(self)[5];
  V v_pk_2462 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_24104)) {
  case TAG_Left: {
    V v_why_24105 = heff_field(v_x_24104, 0);
    V v_ru_24x_24104_24Left = heff_take_reuse_n(v_x_24104, 1ULL, 1);
    heff_drop(v_s_2463);
    heff_drop(v_prog_240);
    heff_drop(v_x_2488);
    heff_drop(v_t_2424);
    heff_drop(v_pk_2462);
    V v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str7), v_why_24105), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str8));
    V v_t_24107 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24106, NTAG(TAG_MkUnit)});
    V v_t_24108 = heff_tag_at_n(v_ru_24x_24104_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24112}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam10, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  case TAG_Right: {
    V v_ver_24120 = heff_field(v_x_24104, 0);
    V v_ru_24x_24104_24Right = heff_take_reuse_n(v_x_24104, 1ULL, 1);
    HeffT2 v_t_24121 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_ver_24120));
    {
      V v_field_24123 = v_t_24121.f[1];
      int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
      if ((v_tag_24122 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_24104_24Right, 1);
        V v_x_24125 = v_field_24123;
        heff_drop(v_x_24125);
        HeffT2 v_t_24126 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(v_s_2463));
        V v_t_24131;
        {
          V v_field_24127 = v_t_24126.f[0];
          V v_field_24128 = v_t_24126.f[1];
          V v_x_24129 = v_field_24127;
          V v_y_24130 = v_field_24128;
          heff_drop(v_y_24130);
          v_t_24131 = v_x_24129;
        }
        V v_c_24132 = (g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247(heff_dup(v_prog_240), v_x_2488, v_t_2424, v_pk_2462, v_t_24131, v_ver_24120));
        V f_ = v_c_24132;
        heff_room[0] = heff_dup(v_hd_242);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam11, 1, 3, (V[]){v_prog_240, v_hd_242, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_s_2463);
        heff_drop(v_prog_240);
        heff_drop(v_x_2488);
        heff_drop(v_t_2424);
        heff_drop(v_pk_2462);
        heff_drop(v_field_24123);
        V v_t_24134 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str9), heff_strAppend(v_ver_24120, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str10)));
        V v_t_24135 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str11), v_t_24134), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str12));
        V v_t_24136 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24135, NTAG(TAG_MkUnit)});
        V v_t_24137 = heff_tag_at_n(v_ru_24x_24104_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
        V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
        V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
        V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
        V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24141}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam12, 1, 2, (V[]){v_hd_242, v_k_243})));
      }
    }
  }
  default: return heff_nomatch(v_x_24104);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam7(V self, V *args) {
  V v_x_2488 = args[0];
  V v_s_2463 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2424 = heff_env(self)[4];
  V v_pk_2462 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2489 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2463)));
  {
    V v_field_2490 = v_t_2489.f[0];
    V v_field_2491 = v_t_2489.f[1];
    V v_x_2492 = v_field_2490;
    heff_drop(v_x_2492);
    V v_y_2493 = v_field_2491;
    V v_c_24103;
    switch (heff_tag_of(v_y_2493)) {
    case TAG_Nothing: {
      HeffT2 v_t_2494 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2463)));
      V v_t_2499;
      {
        V v_field_2495 = v_t_2494.f[0];
        V v_field_2496 = v_t_2494.f[1];
        V v_x_2497 = v_field_2495;
        V v_y_2498 = v_field_2496;
        heff_drop(v_y_2498);
        v_t_2499 = v_x_2497;
      }
      v_c_24103 = (g_heff_2ebuild_2ecommands_2enewestTag_24s1378926159x1290331847(heff_dup(v_prog_240), v_t_2499));
      break;
    }
    case TAG_Just: {
      V v_v_24100 = heff_field(v_y_2493, 0);
      heff_take_n(v_y_2493, 1ULL, 1);
      v_c_24103 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam8, 2, 1, (V[]){v_v_24100});
      break;
    }
    default: heff_nomatch(v_y_2493);
    }
    V f_ = v_c_24103;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam9, 1, 7, (V[]){v_hd_242, v_k_243, v_s_2463, v_prog_240, v_x_2488, v_t_2424, v_pk_2462});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam6(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_s_2463 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2424 = heff_env(self)[4];
  V v_pk_2462 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2487 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(v_x_2486, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str6)));
  V f_ = v_c_2487;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam7, 1, 6, (V[]){v_s_2463, v_prog_240, v_hd_242, v_k_243, v_t_2424, v_pk_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_spec_241 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_spec_241);
    heff_drop(v_prog_240);
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str1), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_t_2424 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    HeffT2 v_t_2425 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_t_2424));
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        heff_drop(v_spec_241);
        heff_drop(v_prog_240);
        heff_drop(v_t_2424);
        V v_p_2429 = v_field_2427;
        heff_drop(v_p_2429);
        V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str2), NTAG(TAG_MkUnit)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
        V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
      } else {
        V v_x_2443 = v_field_2427;
        HeffT2 v_t_2444 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2443));
        {
          V v_field_2446 = v_t_2444.f[1];
          int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
          if ((v_tag_2445 == ((int64_t)0ULL))) {
            heff_drop(v_spec_241);
            heff_drop(v_prog_240);
            heff_drop(v_t_2424);
            V v_x_2448 = v_field_2446;
            heff_drop(v_x_2448);
            V v_t_2449 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str3), NTAG(TAG_MkUnit)});
            V v_t_2450 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
            V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
            V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
            V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
            V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
            return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam4, 1, 2, (V[]){v_hd_242, v_k_243})));
          } else {
            V v_pk_2462 = v_field_2446;
            switch (heff_tag_of(v_spec_241)) {
            case TAG_Nothing: {
              heff_drop(v_t_2424);
              heff_drop_cell(v_ru_24x_2410_24Just, 1);
              heff_drop(v_pk_2462);
              return (g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113(v_prog_240, v_hd_242, v_k_243));
            }
            case TAG_Just: {
              V v_s_2463 = heff_field(v_spec_241, 0);
              V v_ru_24spec_241_24Just = heff_take_reuse_n(v_spec_241, 1ULL, 1);
              HeffT2 v_t_2464 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2463)));
              V v_t_2469;
              {
                V v_field_2465 = v_t_2464.f[0];
                V v_field_2466 = v_t_2464.f[1];
                V v_x_2467 = v_field_2465;
                V v_y_2468 = v_field_2466;
                heff_drop(v_y_2468);
                v_t_2469 = v_x_2467;
              }
              if (heff_strEq_c(v_t_2469, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                heff_drop(v_prog_240);
                heff_drop(v_t_2424);
                heff_drop(v_pk_2462);
                heff_drop(v_s_2463);
                V v_t_2471 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_str5));
                V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2471, NTAG(TAG_MkUnit)});
                V v_t_2473 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
                V v_t_2474 = heff_tag_at_n(v_ru_24spec_241_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
                V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
                V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
                V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
                return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam5, 1, 2, (V[]){v_hd_242, v_k_243})));
              } else {
                heff_drop_cell(v_ru_24x_2410_24Just, 1);
                heff_drop_cell(v_ru_24spec_241_24Just, 1);
                V v_c_2485 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo);
                V f_ = v_c_2485;
                heff_room[0] = heff_dup(v_hd_242);
                heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1483279274x1910788709_lam6, 1, 6, (V[]){v_hd_242, v_s_2463, v_prog_240, v_k_243, v_t_2424, v_pk_2462});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
            default: return heff_nomatch(v_spec_241);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_str2, 5, "win32");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam6(V self, V *args) {
  V v_n_2431 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433;
  if (heff_strEq_c(v_x_2429, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_str2))) {
    v_t_2433 = NTAG(TAG_Windows);
  } else {
    v_t_2433 = NTAG(TAG_Posix);
  }
  return ({ V a_0 = v_t_2433; V a_1 = v_p_245; V a_2 = v_n_2431; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2433); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_ns_2421 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_str1); V a_3 = v_ns_2421; V r_ = (g_list_2efilter_24s2101000672x961294372(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2434 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam6, 1, 2, (V[]){v_x_2429, v_p_245}), v_t_2430));
  V v_t_2435 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(v_t_2434, v_acc_241));
  V f_ = v_t_2435;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_245, 0)) - ((int64_t)3ULL));
    V v_t_2417 = heff_strSlice(heff_dup(v_p_245), heff_box_word(v_t_2416), heff_strLength_lent(v_p_245, 0));
    if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_str0))) {
      V v_t_2419 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2419;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2420 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(v_rest_246, v_acc_241));
      V f_ = v_t_2420;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2421 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam4_clo)})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s94900133x232571340(v_t_2428, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam5, 1, 6, (V[]){v_ns_2421, v_rest_246, v_p_245, v_acc_241, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam2(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2416, 0ULL, 1);
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_242;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam2_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s1179205187x732052096_lam3, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_249, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(V v_prog_240, V v_st_241, V v_t_242, V v_bp_243, V v_done_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_bp_243);
    return v_done_244;
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    V v_t_248 = (g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(heff_dup(v_prog_240), heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_bp_243), v_done_244, v_rest_247));
    return (g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225(v_prog_240, v_st_241, v_t_242, v_bp_243, heff_dup(heff_rfield(v_a_246, 0)), heff_dup(heff_rfield(v_a_246, 1)), v_t_248));
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str2, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str4, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str7, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str8, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str9, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657(V v_prog_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_prog_240}));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2419;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str1))) {
    v_st_2419 = NTAG(TAG_Windows);
  } else {
    v_st_2419 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_st_2419);
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str2), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam4, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_t_2434 = (g_std_2epath_2ejoin(v_st_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str3), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str4)));
    V v_t_2435 = (g_std_2epath_2ejoin(v_st_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str5), v_t_2434));
    V v_t_2436 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str6), v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str7), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str8)});
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1247333332x885074848(v_prog_240, v_st_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_str9), v_t_2436, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(v_t_2416, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s804781220x390827657_lam3, 1, 4, (V[]){v_x_249, v_hd_241, v_k_242, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518(V v_badL_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, heff_dup(v_badL_240), v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_badL_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_badL_240) == NTAG(TAG_True))) {
    heff_drop(v_x_2411);
    heff_drop(v_badL_240);
    heff_drop(v_cs_241);
    V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_badL_240);
    V v_t_2418 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_241); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_x_2411);
      heff_drop(v_t_2418);
      V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_242, v_k_243));
    } else {
      heff_drop(v_t_2418);
      if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
        heff_drop(v_x_2411);
        V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_hd_242, v_k_243));
      } else {
        heff_drop(v_x_2411);
        heff_drop(v_hd_242);
        V f_ = v_k_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_badL_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  HeffT2 v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_241)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_247;
      V v_t_2410 = (g_heff_2ebuild_2edriver_2eevaluate(v_c_249));
      return (g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1275826491x2049419518_lam1, 1, 4, (V[]){v_badL_240, v_hd_242, v_k_243, v_cs_241})));
    } else {
      heff_drop(v_cs_241);
      heff_drop(v_badL_240);
      heff_drop(v_field_247);
      V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_242, v_k_243));
    }
  }
}