// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_Tip 31527
#define LBL_count 296209705
#define LBL_underLam 296337946
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2erematch_2eagain(V, V, V, V, V);
V g_heff_2ecompile_2erematch_2eagain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2eagain_clo;
V g_heff_2ecompile_2erematch_2earmOf(V, V);
V g_heff_2ecompile_2erematch_2earmOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2earmOf_clo;
V g_heff_2ecompile_2erematch_2ego(V);
V g_heff_2ecompile_2erematch_2ego_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ego_clo;
V g_heff_2ecompile_2erematch_2ekeepsWhole(V, V, V, V);
V g_heff_2ecompile_2erematch_2ekeepsWhole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ekeepsWhole_clo;
V g_heff_2ecompile_2erematch_2eparts(V, V);
V g_heff_2ecompile_2erematch_2eparts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2eparts_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_prelude_2etraverse_24s1647811072x440991208(V, V);
V g_prelude_2etraverse_24s1647811072x440991208_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1647811072x440991208_clo;
V g_prelude_2etraverse_24s1974648397x981197981(V, V, V, V, V);
V g_prelude_2etraverse_24s1974648397x981197981_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1974648397x981197981_clo;
V g_prelude_2etraverse_24s215652646x966846125(V, V);
V g_prelude_2etraverse_24s215652646x966846125_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s215652646x966846125_clo;
V g_prelude_2etraverse_24s291737553x1457561185(V);
V g_prelude_2etraverse_24s291737553x1457561185_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s291737553x1457561185_clo;
HeffT2 g_prelude_2etraverse_24s558107581x1903329699_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
HEFF_LIT(g_heff_2ecompile_2erematch_2ekeepsWhole_str0, 1, "_");
V g_heff_2ecompile_2erematch_2ekeepsWhole_lam0(V self, V *args);
Clo g_heff_2ecompile_2erematch_2ekeepsWhole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2ekeepsWhole_entry, 4, 0};

V g_heff_2ecompile_2erematch_2ekeepsWhole(V v_x_240, V v_vs_241, V v_f_242, V v_c_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_243), NTAG(TAG_Nil)});
  V v_t_245 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_244));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_243), NTAG(TAG_Nil)});
  V v_t_247 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_246));
  V v_x_248 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_245, v_t_247}), 0, 2);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    V v_x1_2415 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erematch_2ekeepsWhole_lam0, 1, 2, (V[]){heff_dup(v_f_242), v_c_243}), v_vs_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
    heff_drop(v_x1_2415);
    return v_ret_24bool;
  } else {
    heff_drop(v_c_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erematch_2ekeepsWhole_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erematch_2ekeepsWhole(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erematch_2ekeepsWhole_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_v_249, v_f_242, 0)) {
    heff_drop(v_f_242);
    if (!heff_strEq_c_lent(v_v_249, ((V)&g_heff_2ecompile_2erematch_2ekeepsWhole_str0), 2)) {
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_243), NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2ecompile_2eir_2ecountW(v_v_249, MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_243, NTAG(TAG_Nil)});
      V v_t_2413 = ({ V a_0 = v_v_249; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_v_249); r_; });
      V v_x_2414 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2411, v_t_2413}), 0, 2);
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2414, 1));
      heff_drop(v_x_2414);
      return v_ret_24bool;
    } else {
      heff_drop(v_v_249);
      heff_drop(v_c_243);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_v_249);
    heff_drop(v_f_242);
    heff_drop(v_c_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erematch_2eagain_lam0(V self, V *args);
V g_heff_2ecompile_2erematch_2eagain_lam1(V self, V *args);
Clo g_heff_2ecompile_2erematch_2eagain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2eagain_entry, 5, 0};

V g_heff_2ecompile_2erematch_2eagain(V v_x_240, V v_t_241, V v_vs_242, V v_f_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkArm: {
    V v_t2_245 = heff_field(v_x5_244, 0);
    V v_ws_246 = heff_field(v_x5_244, 1);
    V v_c_247 = heff_field(v_x5_244, 2);
    heff_take_n(v_x5_244, 7ULL, 3);
    V v_t_248 = (g_heff_2ecompile_2erematch_2ekeepsWhole(v_x_240, v_vs_242, v_f_243, heff_dup(v_c_247)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_x_240);
      heff_drop(v_t_241);
      heff_drop(v_vs_242);
      heff_drop(v_t_248);
      return heff_clo_n(g_heff_2ecompile_2erematch_2eagain_lam0, 1, 3, (V[]){v_t2_245, v_ws_246, v_c_247});
    } else {
      heff_drop(v_t_248);
      return heff_clo_n(g_heff_2ecompile_2erematch_2eagain_lam1, 1, 6, (V[]){v_vs_242, v_c_247, v_t_241, v_x_240, v_t2_245, v_ws_246});
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2erematch_2eagain_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erematch_2eagain(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erematch_2eagain_lam0(V self, V *args) {
  V v_n_249 = args[0];
  V v_t2_245 = heff_env(self)[0];
  V v_ws_246 = heff_env(self)[1];
  V v_c_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t2_245, v_ws_246, v_c_247}), v_n_249});
}
V g_heff_2ecompile_2erematch_2eagain_lam1(V self, V *args) {
  V v_n_2410 = args[0];
  V v_vs_242 = heff_env(self)[0];
  V v_c_247 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_t2_245 = heff_env(self)[4];
  V v_ws_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2411 = (g_prelude_2etraverse_24s558107581x1903329699_24cpr(heff_dup(v_vs_242), v_n_2410));
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_x_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_ps_2416 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_242, heff_dup(v_x_2414)));
    V v_m_2417 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2416; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2416); r_; });
    V v_t_2418 = (g_std_2emap_2esize(v_m_2417));
    V v_t_2419;
    if (heff_intEq_c(v_t_2418, MK_INT(0LL))) {
      heff_drop(v_m_2417);
      v_t_2419 = v_c_247;
    } else {
      v_t_2419 = ({ V a_0 = v_m_2417; V a_1 = v_c_247; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2417); r_; });
    }
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_241, v_x_2414, v_t_2419}), NTAG(TAG_Nil)});
    V v_t_2421 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_240}), v_t_2420});
    V v_x_2422 = heff_tag_n(TAG_MkArm, 3, (V[]){v_t2_245, v_ws_246, v_t_2421});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, v_n_2415});
  }
}
V g_heff_2ecompile_2erematch_2eparts_lam0(V self, V *args);
V g_heff_2ecompile_2erematch_2eparts_lam1(V self, V *args);
Clo g_heff_2ecompile_2erematch_2eparts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2eparts_entry, 2, 0};

V g_heff_2ecompile_2erematch_2eparts(V v_x_240, V v_inner_241) {
top: ;
  V v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erematch_2eparts_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), v_inner_241));
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    HEFF_LAST return g_list_2eany(heff_clo_n(g_heff_2ecompile_2erematch_2eparts_lam1, 1, 1, (V[]){heff_dup(v_x_240)}), v_inner_241);
  } else {
    heff_drop(v_t_2412);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2erematch_2eparts_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erematch_2eparts(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erematch_2eparts_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_246;
  switch (heff_tag_of(v_a_242)) {
  case TAG_MkArm: {
    V v_b_245 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 4ULL, 3);
    v_e_246 = v_b_245;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_246), NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_246, NTAG(TAG_Nil)});
  V v_t_2410 = ({ V a_0 = v_x_240; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_240); r_; });
  V v_x_2411 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_248, v_t_2410}), 0, 2);
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2411, 1));
  heff_drop(v_x_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erematch_2eparts_lam1(V self, V *args) {
  V v_a_2413 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2417;
  switch (heff_tag_of(v_a_2413)) {
  case TAG_MkArm: {
    V v_b_2416 = heff_field(v_a_2413, 2);
    heff_take_n(v_a_2413, 4ULL, 3);
    v_e_2417 = v_b_2416;
    break;
  }
  default: heff_nomatch(v_a_2413);
  }
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2417), NTAG(TAG_Nil)});
  V v_t_2419 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_2418));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2417, NTAG(TAG_Nil)});
  V v_t_2421 = ({ V a_0 = v_x_240; V a_1 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_240); r_; });
  V v_x_2422 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2419, v_t_2421}), 0, 2);
  V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(0LL), v_x_2422, 1));
  heff_drop(v_x_2422);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erematch_2earmOf_lam0(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam1(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam2(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam3(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam4(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam5(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam6(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam7(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam8(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam9(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam10(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam11(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam12(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam13(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam14(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam15(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam16(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam17(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam18(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam19(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam20(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam21(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam22(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam23(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam24(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam25(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam26(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam27(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam28(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam29(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam30(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam31(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam32(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam33(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam34(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam35(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam36(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam37(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam38(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam39(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam40(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam41(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam42(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam43(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam44(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam45(V self, V *args);
V g_heff_2ecompile_2erematch_2earmOf_lam46(V self, V *args);
Clo g_heff_2ecompile_2erematch_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2earmOf_entry, 2, 0};

V g_heff_2ecompile_2erematch_2earmOf(V v_x_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_MkArm: {
    V v_t_242 = heff_dup(heff_field(v_a_241, 0));
    V v_vs_243 = heff_dup(heff_field(v_a_241, 1));
    V v_a3_244 = heff_dup(heff_field(v_a_241, 2));
    switch (heff_tag_of(v_a3_244)) {
    case TAG_EVar: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam0, 1, 1, (V[]){v_a_241});
    }
    case TAG_EGlobal: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam1, 1, 1, (V[]){v_a_241});
    }
    case TAG_ELam: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam2, 1, 1, (V[]){v_a_241});
    }
    case TAG_EApp: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam3, 1, 1, (V[]){v_a_241});
    }
    case TAG_ELet: {
      heff_take_n(v_a3_244, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam4, 1, 1, (V[]){v_a_241});
    }
    case TAG_ERecord: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam5, 1, 1, (V[]){v_a_241});
    }
    case TAG_EProj: {
      heff_take_n(v_a3_244, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam6, 1, 1, (V[]){v_a_241});
    }
    case TAG_ETag: {
      heff_take_n(v_a3_244, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam7, 1, 1, (V[]){v_a_241});
    }
    case TAG_EMatch: {
      V v_a31_2431 = heff_field(v_a3_244, 0);
      V v_inner_2432 = heff_field(v_a3_244, 1);
      heff_take_n(v_a3_244, 3ULL, 2);
      switch (heff_tag_of(v_a31_2431)) {
      case TAG_EVar: {
        V v_f_2433 = heff_field(v_a31_2431, 0);
        heff_take_n(v_a31_2431, 1ULL, 1);
        heff_drop_tag(v_a_241, 3);
        V v_t_2434 = (g_list_2eany_24s1477604419x1568736711(v_f_2433, v_vs_243));
        if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
          heff_drop(v_t_2434);
          V v_t_2435 = (g_heff_2ecompile_2erematch_2eparts(v_x_240, v_inner_2432));
          if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
            heff_drop(v_t_2435);
            V v_m_2436 = (g_prelude_2etraverse_24s1974648397x981197981(v_x_240, heff_dup(v_t_242), heff_dup(v_vs_243), v_f_2433, v_inner_2432));
            return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam8, 1, 4, (V[]){v_m_2436, v_f_2433, v_t_242, v_vs_243});
          } else {
            heff_drop(v_x_240);
            heff_drop(v_t_2435);
            return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam9, 1, 4, (V[]){v_f_2433, v_inner_2432, v_t_242, v_vs_243});
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_t_2434);
          return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam10, 1, 4, (V[]){v_f_2433, v_inner_2432, v_t_242, v_vs_243});
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam11, 1, 1, (V[]){v_a_241});
      }
      case TAG_ELam: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam12, 1, 1, (V[]){v_a_241});
      }
      case TAG_EApp: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam13, 1, 1, (V[]){v_a_241});
      }
      case TAG_ELet: {
        heff_take_n(v_a31_2431, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam14, 1, 1, (V[]){v_a_241});
      }
      case TAG_ERecord: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam15, 1, 1, (V[]){v_a_241});
      }
      case TAG_EProj: {
        heff_take_n(v_a31_2431, 0ULL, 4);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam16, 1, 1, (V[]){v_a_241});
      }
      case TAG_ETag: {
        heff_take_n(v_a31_2431, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam17, 1, 1, (V[]){v_a_241});
      }
      case TAG_EMatch: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam18, 1, 1, (V[]){v_a_241});
      }
      case TAG_EPrim: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam19, 1, 1, (V[]){v_a_241});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam20, 1, 1, (V[]){v_a_241});
      }
      case TAG_ECall: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam21, 1, 1, (V[]){v_a_241});
      }
      case TAG_EInt: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam22, 1, 1, (V[]){v_a_241});
      }
      case TAG_EFloat: {
        heff_take_na(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam23, 1, 1, (V[]){v_a_241});
      }
      case TAG_EStr: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam24, 1, 1, (V[]){v_a_241});
      }
      case TAG_EBytes: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam25, 1, 1, (V[]){v_a_241});
      }
      case TAG_EFixed: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam26, 1, 1, (V[]){v_a_241});
      }
      case TAG_EFloat32: {
        heff_take_na(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam27, 1, 1, (V[]){v_a_241});
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam28, 1, 1, (V[]){v_a_241});
      }
      case TAG_EBool: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam29, 1, 1, (V[]){v_a_241});
      }
      case TAG_ESet: {
        heff_take_n(v_a31_2431, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam30, 1, 1, (V[]){v_a_241});
      }
      case TAG_EValues: {
        heff_take_n(v_a31_2431, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam31, 1, 1, (V[]){v_a_241});
      }
      case TAG_EFix: {
        heff_take_n(v_a31_2431, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_t_242);
        heff_drop(v_vs_243);
        heff_drop(v_inner_2432);
        return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam32, 1, 1, (V[]){v_a_241});
      }
      default: return heff_nomatch(v_a31_2431);
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam33, 1, 1, (V[]){v_a_241});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam34, 1, 1, (V[]){v_a_241});
    }
    case TAG_ECall: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam35, 1, 1, (V[]){v_a_241});
    }
    case TAG_EInt: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam36, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFloat: {
      heff_take_na(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam37, 1, 1, (V[]){v_a_241});
    }
    case TAG_EStr: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam38, 1, 1, (V[]){v_a_241});
    }
    case TAG_EBytes: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam39, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFixed: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam40, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFloat32: {
      heff_take_na(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam41, 1, 1, (V[]){v_a_241});
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam42, 1, 1, (V[]){v_a_241});
    }
    case TAG_EBool: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam43, 1, 1, (V[]){v_a_241});
    }
    case TAG_ESet: {
      heff_take_n(v_a3_244, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam44, 1, 1, (V[]){v_a_241});
    }
    case TAG_EValues: {
      heff_take_n(v_a3_244, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam45, 1, 1, (V[]){v_a_241});
    }
    case TAG_EFix: {
      heff_take_n(v_a3_244, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_t_242);
      heff_drop(v_vs_243);
      return heff_clo_n(g_heff_2ecompile_2erematch_2earmOf_lam46, 1, 1, (V[]){v_a_241});
    }
    default: return heff_nomatch(v_a3_244);
    }
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2erematch_2earmOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erematch_2earmOf(a[0], a[1]);
}
V g_heff_2ecompile_2erematch_2earmOf_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_246});
}
V g_heff_2ecompile_2erematch_2earmOf_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_248});
}
V g_heff_2ecompile_2erematch_2earmOf_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2411});
}
V g_heff_2ecompile_2erematch_2earmOf_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2414});
}
V g_heff_2ecompile_2erematch_2earmOf_lam4(V self, V *args) {
  V v_n_2418 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2418});
}
V g_heff_2ecompile_2erematch_2earmOf_lam5(V self, V *args) {
  V v_n_2421 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2421});
}
V g_heff_2ecompile_2erematch_2earmOf_lam6(V self, V *args) {
  V v_n_2426 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2426});
}
V g_heff_2ecompile_2erematch_2earmOf_lam7(V self, V *args) {
  V v_n_2430 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2430});
}
V g_heff_2ecompile_2erematch_2earmOf_lam8(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_f_2433 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    V v_t_2441 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2433}), v_x_2439});
    return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_242, v_vs_243, v_t_2441}), v_n_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2erematch_2earmOf_lam9(V self, V *args) {
  V v_n_2442 = args[0];
  V v_f_2433 = heff_env(self)[0];
  V v_inner_2432 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2443 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2433}), v_inner_2432});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_242, v_vs_243, v_t_2443}), v_n_2442});
}
V g_heff_2ecompile_2erematch_2earmOf_lam10(V self, V *args) {
  V v_n_2444 = args[0];
  V v_f_2433 = heff_env(self)[0];
  V v_inner_2432 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2445 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_f_2433}), v_inner_2432});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_242, v_vs_243, v_t_2445}), v_n_2444});
}
V g_heff_2ecompile_2erematch_2earmOf_lam11(V self, V *args) {
  V v_n_2447 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2447});
}
V g_heff_2ecompile_2erematch_2earmOf_lam12(V self, V *args) {
  V v_n_2450 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2450});
}
V g_heff_2ecompile_2erematch_2earmOf_lam13(V self, V *args) {
  V v_n_2453 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2453});
}
V g_heff_2ecompile_2erematch_2earmOf_lam14(V self, V *args) {
  V v_n_2457 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2457});
}
V g_heff_2ecompile_2erematch_2earmOf_lam15(V self, V *args) {
  V v_n_2460 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2460});
}
V g_heff_2ecompile_2erematch_2earmOf_lam16(V self, V *args) {
  V v_n_2465 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2465});
}
V g_heff_2ecompile_2erematch_2earmOf_lam17(V self, V *args) {
  V v_n_2469 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2469});
}
V g_heff_2ecompile_2erematch_2earmOf_lam18(V self, V *args) {
  V v_n_2472 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2472});
}
V g_heff_2ecompile_2erematch_2earmOf_lam19(V self, V *args) {
  V v_n_2474 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2474});
}
V g_heff_2ecompile_2erematch_2earmOf_lam20(V self, V *args) {
  V v_n_2477 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2477});
}
V g_heff_2ecompile_2erematch_2earmOf_lam21(V self, V *args) {
  V v_n_2480 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2480});
}
V g_heff_2ecompile_2erematch_2earmOf_lam22(V self, V *args) {
  V v_n_2482 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2482});
}
V g_heff_2ecompile_2erematch_2earmOf_lam23(V self, V *args) {
  V v_n_2484 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2484});
}
V g_heff_2ecompile_2erematch_2earmOf_lam24(V self, V *args) {
  V v_n_2486 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2486});
}
V g_heff_2ecompile_2erematch_2earmOf_lam25(V self, V *args) {
  V v_n_2488 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2488});
}
V g_heff_2ecompile_2erematch_2earmOf_lam26(V self, V *args) {
  V v_n_2491 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2491});
}
V g_heff_2ecompile_2erematch_2earmOf_lam27(V self, V *args) {
  V v_n_2493 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2493});
}
V g_heff_2ecompile_2erematch_2earmOf_lam28(V self, V *args) {
  V v_n_2494 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2494});
}
V g_heff_2ecompile_2erematch_2earmOf_lam29(V self, V *args) {
  V v_n_2496 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_2496});
}
V g_heff_2ecompile_2erematch_2earmOf_lam30(V self, V *args) {
  V v_n_24100 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24100});
}
V g_heff_2ecompile_2erematch_2earmOf_lam31(V self, V *args) {
  V v_n_24102 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24102});
}
V g_heff_2ecompile_2erematch_2earmOf_lam32(V self, V *args) {
  V v_n_24105 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24105});
}
V g_heff_2ecompile_2erematch_2earmOf_lam33(V self, V *args) {
  V v_n_24107 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24107});
}
V g_heff_2ecompile_2erematch_2earmOf_lam34(V self, V *args) {
  V v_n_24110 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24110});
}
V g_heff_2ecompile_2erematch_2earmOf_lam35(V self, V *args) {
  V v_n_24113 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24113});
}
V g_heff_2ecompile_2erematch_2earmOf_lam36(V self, V *args) {
  V v_n_24115 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24115});
}
V g_heff_2ecompile_2erematch_2earmOf_lam37(V self, V *args) {
  V v_n_24117 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24117});
}
V g_heff_2ecompile_2erematch_2earmOf_lam38(V self, V *args) {
  V v_n_24119 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24119});
}
V g_heff_2ecompile_2erematch_2earmOf_lam39(V self, V *args) {
  V v_n_24121 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24121});
}
V g_heff_2ecompile_2erematch_2earmOf_lam40(V self, V *args) {
  V v_n_24124 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24124});
}
V g_heff_2ecompile_2erematch_2earmOf_lam41(V self, V *args) {
  V v_n_24126 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24126});
}
V g_heff_2ecompile_2erematch_2earmOf_lam42(V self, V *args) {
  V v_n_24127 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24127});
}
V g_heff_2ecompile_2erematch_2earmOf_lam43(V self, V *args) {
  V v_n_24129 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24129});
}
V g_heff_2ecompile_2erematch_2earmOf_lam44(V self, V *args) {
  V v_n_24133 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24133});
}
V g_heff_2ecompile_2erematch_2earmOf_lam45(V self, V *args) {
  V v_n_24135 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24135});
}
V g_heff_2ecompile_2erematch_2earmOf_lam46(V self, V *args) {
  V v_n_24138 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_241, v_n_24138});
}
V g_heff_2ecompile_2erematch_2ego_lam0(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam1(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam2(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam3(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam4(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam5(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam6(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam7(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam8(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam9(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam10(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam11(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam12(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam13(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam14(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam15(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam16(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam17(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam18(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam19(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam20(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam21(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam22(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam23(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam24(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam25(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam26(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam27(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam28(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam29(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam30(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam31(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam32(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam33(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam34(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam35(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam36(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam37(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam38(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam39(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam40(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam41(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam42(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam43(V self, V *args);
V g_heff_2ecompile_2erematch_2ego_lam44(V self, V *args);
Clo g_heff_2ecompile_2erematch_2ego_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2ego_entry, 1, 0};

V g_heff_2ecompile_2erematch_2ego(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam0, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam1, 1, 1, (V[]){v_x1_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x1_240, 0);
    V v_b_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2erematch_2ego(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_argv_2413 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2414 = (g_heff_2ecompile_2erematch_2ego(v_f_2412));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam3, 1, 2, (V[]){v_m_2414, v_argv_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x1_240, 0);
    V v_a_2424 = heff_field(v_x1_240, 1);
    V v_b_2425 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2426 = (g_heff_2ecompile_2erematch_2ego(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam4, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2435 = heff_field(v_x1_240, 0);
    V v_ts_2436 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2437 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x1_240_24ERecord, heff_dup(v_fs_2435)));
    V v_m_2438 = (g_prelude_2etraverse_24s215652646x966846125(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_t_2437));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam5, 1, 3, (V[]){v_m_2438, v_fs_2435, v_ts_2436});
  }
  case TAG_EProj: {
    V v_e_2445 = heff_field(v_x1_240, 0);
    V v_l_2446 = heff_field(v_x1_240, 1);
    V v_sh_2447 = heff_field(v_x1_240, 2);
    V v_t_2448 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_m_2449 = (g_heff_2ecompile_2erematch_2ego(v_e_2445));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam6, 1, 4, (V[]){v_m_2449, v_l_2446, v_sh_2447, v_t_2448});
  }
  case TAG_ETag: {
    V v_t_2454 = heff_field(v_x1_240, 0);
    V v_argv_2455 = heff_field(v_x1_240, 1);
    V v_ts_2456 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2457 = (g_prelude_2etraverse_24s215652646x966846125(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_argv_2455));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam7, 1, 3, (V[]){v_m_2457, v_t_2454, v_ts_2456});
  }
  case TAG_EMatch: {
    V v_x11_2462 = heff_field(v_x1_240, 0);
    V v_as0_2463 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_2462)) {
    case TAG_EVar: {
      V v_x_2464 = heff_field(v_x11_2462, 0);
      heff_take_n(v_x11_2462, 1ULL, 1);
      V v_m_2465 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam8, 1, 2, (V[]){v_m_2465, v_x_2464});
    }
    case TAG_EGlobal: {
      V v_m_2476 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam9, 1, 2, (V[]){v_m_2476, v_as0_2463});
    }
    case TAG_ELam: {
      V v_m_2487 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam10, 1, 2, (V[]){v_m_2487, v_as0_2463});
    }
    case TAG_EApp: {
      V v_m_2498 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam11, 1, 2, (V[]){v_m_2498, v_as0_2463});
    }
    case TAG_ELet: {
      V v_m_24110 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam12, 1, 2, (V[]){v_m_24110, v_as0_2463});
    }
    case TAG_ERecord: {
      V v_m_24121 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam13, 1, 2, (V[]){v_m_24121, v_as0_2463});
    }
    case TAG_EProj: {
      V v_m_24134 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam14, 1, 2, (V[]){v_m_24134, v_as0_2463});
    }
    case TAG_ETag: {
      V v_m_24146 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam15, 1, 2, (V[]){v_m_24146, v_as0_2463});
    }
    case TAG_EMatch: {
      V v_m_24157 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam16, 1, 2, (V[]){v_m_24157, v_as0_2463});
    }
    case TAG_EPrim: {
      V v_m_24167 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam17, 1, 2, (V[]){v_m_24167, v_as0_2463});
    }
    case TAG_EPrimCall: {
      V v_m_24178 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam18, 1, 2, (V[]){v_m_24178, v_as0_2463});
    }
    case TAG_ECall: {
      V v_m_24189 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam19, 1, 2, (V[]){v_m_24189, v_as0_2463});
    }
    case TAG_EInt: {
      V v_m_24199 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam20, 1, 2, (V[]){v_m_24199, v_as0_2463});
    }
    case TAG_EFloat: {
      V v_m_24209 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam21, 1, 2, (V[]){v_m_24209, v_as0_2463});
    }
    case TAG_EStr: {
      V v_m_24219 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam22, 1, 2, (V[]){v_m_24219, v_as0_2463});
    }
    case TAG_EBytes: {
      V v_m_24229 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam23, 1, 2, (V[]){v_m_24229, v_as0_2463});
    }
    case TAG_EFixed: {
      V v_m_24240 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam24, 1, 2, (V[]){v_m_24240, v_as0_2463});
    }
    case TAG_EFloat32: {
      V v_m_24250 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam25, 1, 2, (V[]){v_m_24250, v_as0_2463});
    }
    case TAG_EAbandon: {
      V v_m_24259 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam26, 1, 2, (V[]){v_m_24259, v_as0_2463});
    }
    case TAG_EBool: {
      V v_m_24269 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam27, 1, 2, (V[]){v_m_24269, v_as0_2463});
    }
    case TAG_ESet: {
      V v_m_24281 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam28, 1, 2, (V[]){v_m_24281, v_as0_2463});
    }
    case TAG_EValues: {
      V v_m_24291 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam29, 1, 2, (V[]){v_m_24291, v_as0_2463});
    }
    case TAG_EFix: {
      V v_m_24302 = (g_heff_2ecompile_2erematch_2ego(v_x11_2462));
      return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam30, 1, 2, (V[]){v_m_24302, v_as0_2463});
    }
    default: return heff_nomatch(v_x11_2462);
    }
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam31, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EPrimCall: {
    V v_p_24313 = heff_field(v_x1_240, 0);
    V v_argv_24314 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_24315 = (g_prelude_2etraverse_24s215652646x966846125(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_argv_24314));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam32, 1, 2, (V[]){v_m_24315, v_p_24313});
  }
  case TAG_ECall: {
    V v_g_24320 = heff_field(v_x1_240, 0);
    V v_argv_24321 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_24322 = (g_prelude_2etraverse_24s215652646x966846125(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_argv_24321));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam33, 1, 2, (V[]){v_m_24322, v_g_24320});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam34, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam35, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam36, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam37, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam38, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam39, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam40, 1, 1, (V[]){v_x1_240});
  }
  case TAG_EBool: {
    V v_c_24341 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_m_24342 = (g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_c_24341));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam41, 1, 1, (V[]){v_m_24342});
  }
  case TAG_ESet: {
    V v_xs_24347 = heff_field(v_x1_240, 0);
    V v_a_24348 = heff_field(v_x1_240, 1);
    V v_b_24349 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_24350 = (g_heff_2ecompile_2erematch_2ego(v_a_24348));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam42, 1, 3, (V[]){v_m_24350, v_b_24349, v_xs_24347});
  }
  case TAG_EValues: {
    V v_es_24359 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_m_24360 = (g_prelude_2etraverse_24s215652646x966846125(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_es_24359));
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam43, 1, 1, (V[]){v_m_24360});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2erematch_2ego_lam44, 1, 1, (V[]){v_x1_240});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erematch_2ego_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erematch_2ego(a[0]);
}
V g_heff_2ecompile_2erematch_2ego_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_242});
}
V g_heff_2ecompile_2erematch_2ego_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_244});
}
V g_heff_2ecompile_2erematch_2ego_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_argv_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_m_2419 = (g_prelude_2etraverse_24s215652646x966846125(((V)&g_heff_2ecompile_2erematch_2ego_clo), v_argv_2413));
    V v_x2_2420 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2418}));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_n_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2417, v_x_2421}), v_n_2422});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam4(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = (g_heff_2ecompile_2erematch_2ego(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, v_x_2429, v_x_2433}), v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam5(V self, V *args) {
  V v_n_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  V v_fs_2435 = heff_env(self)[1];
  V v_ts_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_n_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_n_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    V v_t_2443 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2435, v_x_2441));
    V v_x_2444 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2443, v_ts_2436});
    return heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, (V[]){v_x_2444, v_n_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam6(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_l_2446 = heff_env(self)[1];
  V v_sh_2447 = heff_env(self)[2];
  V v_t_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2452, v_l_2446, v_sh_2447, v_t_2448}), v_n_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam7(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_t_2454 = heff_env(self)[1];
  V v_ts_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2454, v_x_2460, v_ts_2456}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam8(V self, V *args) {
  V v_n_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_x_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_n_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_n_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_m_2470 = (g_prelude_2etraverse_24s1647811072x440991208(heff_dup(v_x_2464), v_x_2468));
    V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_n_2469}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_n_2473 = heff_field(v_x2_2471, 1);
      V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
      V v_t_2474 = heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2464}), v_x_2472});
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){v_t_2474, v_n_2473});
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam9(V self, V *args) {
  V v_n_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_n_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_n_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_m_2481 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_n_2480}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_n_2484 = heff_field(v_x2_2482, 1);
      heff_take_n(v_x2_2482, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2479, v_x_2483}), v_n_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam10(V self, V *args) {
  V v_n_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_n_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_n_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_m_2492 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_n_2491}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_n_2495 = heff_field(v_x2_2493, 1);
      heff_take_n(v_x2_2493, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2490, v_x_2494}), v_n_2495});
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam11(V self, V *args) {
  V v_n_2499 = args[0];
  V v_m_2498 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24100 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_n_2499}));
  switch (heff_tag_of(v_x2_24100)) {
  case TAG_MkPair: {
    V v_x_24101 = heff_field(v_x2_24100, 0);
    V v_n_24102 = heff_field(v_x2_24100, 1);
    V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
    V v_m_24103 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24104 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_n_24102}));
    switch (heff_tag_of(v_x2_24104)) {
    case TAG_MkPair: {
      V v_x_24105 = heff_field(v_x2_24104, 0);
      V v_n_24106 = heff_field(v_x2_24104, 1);
      heff_take_n(v_x2_24104, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24101, v_x_24105}), v_n_24106});
    }
    default: return heff_nomatch(v_x2_24104);
    }
  }
  default: return heff_nomatch(v_x2_24100);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam12(V self, V *args) {
  V v_n_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_n_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_n_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_m_24115 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24116 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_n_24114}));
    switch (heff_tag_of(v_x2_24116)) {
    case TAG_MkPair: {
      V v_x_24117 = heff_field(v_x2_24116, 0);
      V v_n_24118 = heff_field(v_x2_24116, 1);
      heff_take_n(v_x2_24116, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24113, v_x_24117}), v_n_24118});
    }
    default: return heff_nomatch(v_x2_24116);
    }
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam13(V self, V *args) {
  V v_n_24122 = args[0];
  V v_m_24121 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24123 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_n_24122}));
  switch (heff_tag_of(v_x2_24123)) {
  case TAG_MkPair: {
    V v_x_24124 = heff_field(v_x2_24123, 0);
    V v_n_24125 = heff_field(v_x2_24123, 1);
    V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 3ULL, 2);
    V v_m_24126 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24127 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_n_24125}));
    switch (heff_tag_of(v_x2_24127)) {
    case TAG_MkPair: {
      V v_x_24128 = heff_field(v_x2_24127, 0);
      V v_n_24129 = heff_field(v_x2_24127, 1);
      heff_take_n(v_x2_24127, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24124, v_x_24128}), v_n_24129});
    }
    default: return heff_nomatch(v_x2_24127);
    }
  }
  default: return heff_nomatch(v_x2_24123);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam14(V self, V *args) {
  V v_n_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_n_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_n_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_m_24139 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24140 = heff_tr(heff_call(v_m_24139, 1, (V[]){v_n_24138}));
    switch (heff_tag_of(v_x2_24140)) {
    case TAG_MkPair: {
      V v_x_24141 = heff_field(v_x2_24140, 0);
      V v_n_24142 = heff_field(v_x2_24140, 1);
      heff_take_n(v_x2_24140, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24137, v_x_24141}), v_n_24142});
    }
    default: return heff_nomatch(v_x2_24140);
    }
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam15(V self, V *args) {
  V v_n_24147 = args[0];
  V v_m_24146 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24148 = heff_tr(heff_call(v_m_24146, 1, (V[]){v_n_24147}));
  switch (heff_tag_of(v_x2_24148)) {
  case TAG_MkPair: {
    V v_x_24149 = heff_field(v_x2_24148, 0);
    V v_n_24150 = heff_field(v_x2_24148, 1);
    V v_ru_24x2_24148_24MkPair = heff_take_reuse_n(v_x2_24148, 3ULL, 2);
    V v_m_24151 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24152 = heff_tr(heff_call(v_m_24151, 1, (V[]){v_n_24150}));
    switch (heff_tag_of(v_x2_24152)) {
    case TAG_MkPair: {
      V v_x_24153 = heff_field(v_x2_24152, 0);
      V v_n_24154 = heff_field(v_x2_24152, 1);
      heff_take_n(v_x2_24152, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24148_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24149, v_x_24153}), v_n_24154});
    }
    default: return heff_nomatch(v_x2_24152);
    }
  }
  default: return heff_nomatch(v_x2_24148);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam16(V self, V *args) {
  V v_n_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_n_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_n_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_m_24162 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24163 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_n_24161}));
    switch (heff_tag_of(v_x2_24163)) {
    case TAG_MkPair: {
      V v_x_24164 = heff_field(v_x2_24163, 0);
      V v_n_24165 = heff_field(v_x2_24163, 1);
      heff_take_n(v_x2_24163, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24160, v_x_24164}), v_n_24165});
    }
    default: return heff_nomatch(v_x2_24163);
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam17(V self, V *args) {
  V v_n_24168 = args[0];
  V v_m_24167 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24169 = heff_tr(heff_call(v_m_24167, 1, (V[]){v_n_24168}));
  switch (heff_tag_of(v_x2_24169)) {
  case TAG_MkPair: {
    V v_x_24170 = heff_field(v_x2_24169, 0);
    V v_n_24171 = heff_field(v_x2_24169, 1);
    V v_ru_24x2_24169_24MkPair = heff_take_reuse_n(v_x2_24169, 3ULL, 2);
    V v_m_24172 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24173 = heff_tr(heff_call(v_m_24172, 1, (V[]){v_n_24171}));
    switch (heff_tag_of(v_x2_24173)) {
    case TAG_MkPair: {
      V v_x_24174 = heff_field(v_x2_24173, 0);
      V v_n_24175 = heff_field(v_x2_24173, 1);
      heff_take_n(v_x2_24173, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24170, v_x_24174}), v_n_24175});
    }
    default: return heff_nomatch(v_x2_24173);
    }
  }
  default: return heff_nomatch(v_x2_24169);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam18(V self, V *args) {
  V v_n_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_n_24179}));
  switch (heff_tag_of(v_x2_24180)) {
  case TAG_MkPair: {
    V v_x_24181 = heff_field(v_x2_24180, 0);
    V v_n_24182 = heff_field(v_x2_24180, 1);
    V v_ru_24x2_24180_24MkPair = heff_take_reuse_n(v_x2_24180, 3ULL, 2);
    V v_m_24183 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_n_24182}));
    switch (heff_tag_of(v_x2_24184)) {
    case TAG_MkPair: {
      V v_x_24185 = heff_field(v_x2_24184, 0);
      V v_n_24186 = heff_field(v_x2_24184, 1);
      heff_take_n(v_x2_24184, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24181, v_x_24185}), v_n_24186});
    }
    default: return heff_nomatch(v_x2_24184);
    }
  }
  default: return heff_nomatch(v_x2_24180);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam19(V self, V *args) {
  V v_n_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24191 = heff_tr(heff_call(v_m_24189, 1, (V[]){v_n_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_n_24193 = heff_field(v_x2_24191, 1);
    V v_ru_24x2_24191_24MkPair = heff_take_reuse_n(v_x2_24191, 3ULL, 2);
    V v_m_24194 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24195 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_n_24193}));
    switch (heff_tag_of(v_x2_24195)) {
    case TAG_MkPair: {
      V v_x_24196 = heff_field(v_x2_24195, 0);
      V v_n_24197 = heff_field(v_x2_24195, 1);
      heff_take_n(v_x2_24195, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24191_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24192, v_x_24196}), v_n_24197});
    }
    default: return heff_nomatch(v_x2_24195);
    }
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam20(V self, V *args) {
  V v_n_24200 = args[0];
  V v_m_24199 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24201 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_n_24200}));
  switch (heff_tag_of(v_x2_24201)) {
  case TAG_MkPair: {
    V v_x_24202 = heff_field(v_x2_24201, 0);
    V v_n_24203 = heff_field(v_x2_24201, 1);
    V v_ru_24x2_24201_24MkPair = heff_take_reuse_n(v_x2_24201, 3ULL, 2);
    V v_m_24204 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24205 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_n_24203}));
    switch (heff_tag_of(v_x2_24205)) {
    case TAG_MkPair: {
      V v_x_24206 = heff_field(v_x2_24205, 0);
      V v_n_24207 = heff_field(v_x2_24205, 1);
      heff_take_n(v_x2_24205, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24201_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24202, v_x_24206}), v_n_24207});
    }
    default: return heff_nomatch(v_x2_24205);
    }
  }
  default: return heff_nomatch(v_x2_24201);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam21(V self, V *args) {
  V v_n_24210 = args[0];
  V v_m_24209 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24211 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_n_24210}));
  switch (heff_tag_of(v_x2_24211)) {
  case TAG_MkPair: {
    V v_x_24212 = heff_field(v_x2_24211, 0);
    V v_n_24213 = heff_field(v_x2_24211, 1);
    V v_ru_24x2_24211_24MkPair = heff_take_reuse_n(v_x2_24211, 3ULL, 2);
    V v_m_24214 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24215 = heff_tr(heff_call(v_m_24214, 1, (V[]){v_n_24213}));
    switch (heff_tag_of(v_x2_24215)) {
    case TAG_MkPair: {
      V v_x_24216 = heff_field(v_x2_24215, 0);
      V v_n_24217 = heff_field(v_x2_24215, 1);
      heff_take_n(v_x2_24215, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24211_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24212, v_x_24216}), v_n_24217});
    }
    default: return heff_nomatch(v_x2_24215);
    }
  }
  default: return heff_nomatch(v_x2_24211);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam22(V self, V *args) {
  V v_n_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24221 = heff_tr(heff_call(v_m_24219, 1, (V[]){v_n_24220}));
  switch (heff_tag_of(v_x2_24221)) {
  case TAG_MkPair: {
    V v_x_24222 = heff_field(v_x2_24221, 0);
    V v_n_24223 = heff_field(v_x2_24221, 1);
    V v_ru_24x2_24221_24MkPair = heff_take_reuse_n(v_x2_24221, 3ULL, 2);
    V v_m_24224 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24225 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_n_24223}));
    switch (heff_tag_of(v_x2_24225)) {
    case TAG_MkPair: {
      V v_x_24226 = heff_field(v_x2_24225, 0);
      V v_n_24227 = heff_field(v_x2_24225, 1);
      heff_take_n(v_x2_24225, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24221_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24222, v_x_24226}), v_n_24227});
    }
    default: return heff_nomatch(v_x2_24225);
    }
  }
  default: return heff_nomatch(v_x2_24221);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam23(V self, V *args) {
  V v_n_24230 = args[0];
  V v_m_24229 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24231 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_n_24230}));
  switch (heff_tag_of(v_x2_24231)) {
  case TAG_MkPair: {
    V v_x_24232 = heff_field(v_x2_24231, 0);
    V v_n_24233 = heff_field(v_x2_24231, 1);
    V v_ru_24x2_24231_24MkPair = heff_take_reuse_n(v_x2_24231, 3ULL, 2);
    V v_m_24234 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24235 = heff_tr(heff_call(v_m_24234, 1, (V[]){v_n_24233}));
    switch (heff_tag_of(v_x2_24235)) {
    case TAG_MkPair: {
      V v_x_24236 = heff_field(v_x2_24235, 0);
      V v_n_24237 = heff_field(v_x2_24235, 1);
      heff_take_n(v_x2_24235, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24232, v_x_24236}), v_n_24237});
    }
    default: return heff_nomatch(v_x2_24235);
    }
  }
  default: return heff_nomatch(v_x2_24231);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam24(V self, V *args) {
  V v_n_24241 = args[0];
  V v_m_24240 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24242 = heff_tr(heff_call(v_m_24240, 1, (V[]){v_n_24241}));
  switch (heff_tag_of(v_x2_24242)) {
  case TAG_MkPair: {
    V v_x_24243 = heff_field(v_x2_24242, 0);
    V v_n_24244 = heff_field(v_x2_24242, 1);
    V v_ru_24x2_24242_24MkPair = heff_take_reuse_n(v_x2_24242, 3ULL, 2);
    V v_m_24245 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24246 = heff_tr(heff_call(v_m_24245, 1, (V[]){v_n_24244}));
    switch (heff_tag_of(v_x2_24246)) {
    case TAG_MkPair: {
      V v_x_24247 = heff_field(v_x2_24246, 0);
      V v_n_24248 = heff_field(v_x2_24246, 1);
      heff_take_n(v_x2_24246, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24243, v_x_24247}), v_n_24248});
    }
    default: return heff_nomatch(v_x2_24246);
    }
  }
  default: return heff_nomatch(v_x2_24242);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam25(V self, V *args) {
  V v_n_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_n_24251}));
  switch (heff_tag_of(v_x2_24252)) {
  case TAG_MkPair: {
    V v_x_24253 = heff_field(v_x2_24252, 0);
    V v_n_24254 = heff_field(v_x2_24252, 1);
    V v_ru_24x2_24252_24MkPair = heff_take_reuse_n(v_x2_24252, 3ULL, 2);
    V v_m_24255 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24256 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_n_24254}));
    switch (heff_tag_of(v_x2_24256)) {
    case TAG_MkPair: {
      V v_x_24257 = heff_field(v_x2_24256, 0);
      V v_n_24258 = heff_field(v_x2_24256, 1);
      heff_take_n(v_x2_24256, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24253, v_x_24257}), v_n_24258});
    }
    default: return heff_nomatch(v_x2_24256);
    }
  }
  default: return heff_nomatch(v_x2_24252);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam26(V self, V *args) {
  V v_n_24260 = args[0];
  V v_m_24259 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24261 = heff_tr(heff_call(v_m_24259, 1, (V[]){v_n_24260}));
  switch (heff_tag_of(v_x2_24261)) {
  case TAG_MkPair: {
    V v_x_24262 = heff_field(v_x2_24261, 0);
    V v_n_24263 = heff_field(v_x2_24261, 1);
    V v_ru_24x2_24261_24MkPair = heff_take_reuse_n(v_x2_24261, 3ULL, 2);
    V v_m_24264 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24265 = heff_tr(heff_call(v_m_24264, 1, (V[]){v_n_24263}));
    switch (heff_tag_of(v_x2_24265)) {
    case TAG_MkPair: {
      V v_x_24266 = heff_field(v_x2_24265, 0);
      V v_n_24267 = heff_field(v_x2_24265, 1);
      heff_take_n(v_x2_24265, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24261_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24262, v_x_24266}), v_n_24267});
    }
    default: return heff_nomatch(v_x2_24265);
    }
  }
  default: return heff_nomatch(v_x2_24261);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam27(V self, V *args) {
  V v_n_24270 = args[0];
  V v_m_24269 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24271 = heff_tr(heff_call(v_m_24269, 1, (V[]){v_n_24270}));
  switch (heff_tag_of(v_x2_24271)) {
  case TAG_MkPair: {
    V v_x_24272 = heff_field(v_x2_24271, 0);
    V v_n_24273 = heff_field(v_x2_24271, 1);
    V v_ru_24x2_24271_24MkPair = heff_take_reuse_n(v_x2_24271, 3ULL, 2);
    V v_m_24274 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24275 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_n_24273}));
    switch (heff_tag_of(v_x2_24275)) {
    case TAG_MkPair: {
      V v_x_24276 = heff_field(v_x2_24275, 0);
      V v_n_24277 = heff_field(v_x2_24275, 1);
      heff_take_n(v_x2_24275, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24271_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24272, v_x_24276}), v_n_24277});
    }
    default: return heff_nomatch(v_x2_24275);
    }
  }
  default: return heff_nomatch(v_x2_24271);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam28(V self, V *args) {
  V v_n_24282 = args[0];
  V v_m_24281 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24283 = heff_tr(heff_call(v_m_24281, 1, (V[]){v_n_24282}));
  switch (heff_tag_of(v_x2_24283)) {
  case TAG_MkPair: {
    V v_x_24284 = heff_field(v_x2_24283, 0);
    V v_n_24285 = heff_field(v_x2_24283, 1);
    V v_ru_24x2_24283_24MkPair = heff_take_reuse_n(v_x2_24283, 3ULL, 2);
    V v_m_24286 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24287 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_n_24285}));
    switch (heff_tag_of(v_x2_24287)) {
    case TAG_MkPair: {
      V v_x_24288 = heff_field(v_x2_24287, 0);
      V v_n_24289 = heff_field(v_x2_24287, 1);
      heff_take_n(v_x2_24287, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24284, v_x_24288}), v_n_24289});
    }
    default: return heff_nomatch(v_x2_24287);
    }
  }
  default: return heff_nomatch(v_x2_24283);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam29(V self, V *args) {
  V v_n_24292 = args[0];
  V v_m_24291 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24293 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_n_24292}));
  switch (heff_tag_of(v_x2_24293)) {
  case TAG_MkPair: {
    V v_x_24294 = heff_field(v_x2_24293, 0);
    V v_n_24295 = heff_field(v_x2_24293, 1);
    V v_ru_24x2_24293_24MkPair = heff_take_reuse_n(v_x2_24293, 3ULL, 2);
    V v_m_24296 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24297 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_n_24295}));
    switch (heff_tag_of(v_x2_24297)) {
    case TAG_MkPair: {
      V v_x_24298 = heff_field(v_x2_24297, 0);
      V v_n_24299 = heff_field(v_x2_24297, 1);
      heff_take_n(v_x2_24297, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24293_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24294, v_x_24298}), v_n_24299});
    }
    default: return heff_nomatch(v_x2_24297);
    }
  }
  default: return heff_nomatch(v_x2_24293);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam30(V self, V *args) {
  V v_n_24303 = args[0];
  V v_m_24302 = heff_env(self)[0];
  V v_as0_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24304 = heff_tr(heff_call(v_m_24302, 1, (V[]){v_n_24303}));
  switch (heff_tag_of(v_x2_24304)) {
  case TAG_MkPair: {
    V v_x_24305 = heff_field(v_x2_24304, 0);
    V v_n_24306 = heff_field(v_x2_24304, 1);
    V v_ru_24x2_24304_24MkPair = heff_take_reuse_n(v_x2_24304, 3ULL, 2);
    V v_m_24307 = (g_prelude_2etraverse_24s291737553x1457561185(v_as0_2463));
    V v_x2_24308 = heff_tr(heff_call(v_m_24307, 1, (V[]){v_n_24306}));
    switch (heff_tag_of(v_x2_24308)) {
    case TAG_MkPair: {
      V v_x_24309 = heff_field(v_x2_24308, 0);
      V v_n_24310 = heff_field(v_x2_24308, 1);
      heff_take_n(v_x2_24308, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24304_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24305, v_x_24309}), v_n_24310});
    }
    default: return heff_nomatch(v_x2_24308);
    }
  }
  default: return heff_nomatch(v_x2_24304);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam31(V self, V *args) {
  V v_n_24312 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24312});
}
V g_heff_2ecompile_2erematch_2ego_lam32(V self, V *args) {
  V v_n_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  V v_p_24313 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24317 = heff_tr(heff_call(v_m_24315, 1, (V[]){v_n_24316}));
  switch (heff_tag_of(v_x2_24317)) {
  case TAG_MkPair: {
    V v_x_24318 = heff_field(v_x2_24317, 0);
    V v_n_24319 = heff_field(v_x2_24317, 1);
    V v_ru_24x2_24317_24MkPair = heff_take_reuse_n(v_x2_24317, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24317_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24313, v_x_24318}), v_n_24319});
  }
  default: return heff_nomatch(v_x2_24317);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam33(V self, V *args) {
  V v_n_24323 = args[0];
  V v_m_24322 = heff_env(self)[0];
  V v_g_24320 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24324 = heff_tr(heff_call(v_m_24322, 1, (V[]){v_n_24323}));
  switch (heff_tag_of(v_x2_24324)) {
  case TAG_MkPair: {
    V v_x_24325 = heff_field(v_x2_24324, 0);
    V v_n_24326 = heff_field(v_x2_24324, 1);
    V v_ru_24x2_24324_24MkPair = heff_take_reuse_n(v_x2_24324, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24324_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24320, v_x_24325}), v_n_24326});
  }
  default: return heff_nomatch(v_x2_24324);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam34(V self, V *args) {
  V v_n_24328 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24328});
}
V g_heff_2ecompile_2erematch_2ego_lam35(V self, V *args) {
  V v_n_24330 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24330});
}
V g_heff_2ecompile_2erematch_2ego_lam36(V self, V *args) {
  V v_n_24332 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24332});
}
V g_heff_2ecompile_2erematch_2ego_lam37(V self, V *args) {
  V v_n_24334 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24334});
}
V g_heff_2ecompile_2erematch_2ego_lam38(V self, V *args) {
  V v_n_24337 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24337});
}
V g_heff_2ecompile_2erematch_2ego_lam39(V self, V *args) {
  V v_n_24339 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24339});
}
V g_heff_2ecompile_2erematch_2ego_lam40(V self, V *args) {
  V v_n_24340 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24340});
}
V g_heff_2ecompile_2erematch_2ego_lam41(V self, V *args) {
  V v_n_24343 = args[0];
  V v_m_24342 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24344 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_n_24343}));
  switch (heff_tag_of(v_x2_24344)) {
  case TAG_MkPair: {
    V v_x_24345 = heff_field(v_x2_24344, 0);
    V v_n_24346 = heff_field(v_x2_24344, 1);
    V v_ru_24x2_24344_24MkPair = heff_take_reuse_n(v_x2_24344, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24344_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24345}), v_n_24346});
  }
  default: return heff_nomatch(v_x2_24344);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam42(V self, V *args) {
  V v_n_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  V v_b_24349 = heff_env(self)[1];
  V v_xs_24347 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24352 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_n_24351}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_MkPair: {
    V v_x_24353 = heff_field(v_x2_24352, 0);
    V v_n_24354 = heff_field(v_x2_24352, 1);
    V v_ru_24x2_24352_24MkPair = heff_take_reuse_n(v_x2_24352, 3ULL, 2);
    V v_m_24355 = (g_heff_2ecompile_2erematch_2ego(v_b_24349));
    V v_x2_24356 = heff_tr(heff_call(v_m_24355, 1, (V[]){v_n_24354}));
    switch (heff_tag_of(v_x2_24356)) {
    case TAG_MkPair: {
      V v_x_24357 = heff_field(v_x2_24356, 0);
      V v_n_24358 = heff_field(v_x2_24356, 1);
      heff_take_n(v_x2_24356, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24352_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24347, v_x_24353, v_x_24357}), v_n_24358});
    }
    default: return heff_nomatch(v_x2_24356);
    }
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam43(V self, V *args) {
  V v_n_24361 = args[0];
  V v_m_24360 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24362 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_n_24361}));
  switch (heff_tag_of(v_x2_24362)) {
  case TAG_MkPair: {
    V v_x_24363 = heff_field(v_x2_24362, 0);
    V v_n_24364 = heff_field(v_x2_24362, 1);
    V v_ru_24x2_24362_24MkPair = heff_take_reuse_n(v_x2_24362, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24363}), v_n_24364});
  }
  default: return heff_nomatch(v_x2_24362);
  }
}
V g_heff_2ecompile_2erematch_2ego_lam44(V self, V *args) {
  V v_n_24367 = args[0];
  V v_x1_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x1_240, v_n_24367});
}