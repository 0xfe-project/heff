// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_WriteErr 37283
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_path 9928940
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1618601348x76371918(V, V, V);
V g_prelude_2e_2b_2b_24f1618601348x76371918_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1618601348x76371918_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str3, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str4, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str6, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str7, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str8, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str13, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str15, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str16, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0(V v_x_240, V v_out_241, V v_lit_242, V v_x_243, V v_hd_244, V v_next_245, V v_k_246, V v_who_247, V v_lit_248, V v_x_249) {
top: ;
  V v_s_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    v_s_2412 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str0);
    break;
  }
  case TAG_Right: {
    V v_y_2411 = heff_field(v_x_249, 0);
    v_s_2412 = heff_dup(v_y_2411);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2413 = ({ V a_0 = v_s_2412; V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str2), v_s_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_2412); r_; });
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str3), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str4), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_241), v_t_2414})});
  V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str5); V a_2 = v_t_2413; V r_ = (g_prelude_2e_2b_2b_24f1618601348x76371918(a_0, a_1, a_2)); heff_drop_tag(v_t_2415, 2); r_; });
  V v_t_2417 = (g_prelude_2e_2b_2b(v_x_240, v_t_2416));
  V v_ys_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str6), v_t_2417});
  V v_argv_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_ys_2418})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str8), v_argv_2419, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam0_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s535099379x685970669(v_t_2422, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam1, 1, 7, (V[]){v_x_243, v_hd_244, v_next_245, v_k_246, v_who_247, v_out_241, v_lit_248})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a9 = a[9]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a9); heff_drop(a9); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam0(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam4(V self, V *args) {
  V v_x_2458 = args[0];
  V v_lit_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_drop(v_x_2458);
  heff_clo_take(self, 3);
  V v_t_2459 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_248, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), v_hd_244, v_k_246));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam3(V self, V *args) {
  V v_x_2450 = args[0];
  V v_who_247 = heff_env(self)[0];
  V v_out_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_lit_248 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_drop(v_x_2450);
  heff_clo_take(self, 5);
  V v_t_2451 = heff_strAppend(heff_strAppend(v_who_247, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str15)), v_out_241);
  V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2451, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str16)), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam4, 1, 3, (V[]){v_lit_248, v_hd_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_ended_2424 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_err_2425 = heff_env(self)[4];
  V v_who_247 = heff_env(self)[5];
  V v_out_241 = heff_env(self)[6];
  V v_lit_248 = heff_env(self)[7];
  heff_drop(v_x_2428);
  V v_t_2429 = heff_dup(v_ended_2424);
  V v_t_2433;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Exited: {
    V v_n_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    v_t_2433 = heff_bool(heff_intEq_c_lent(v_n_2430, MK_INT(0LL), 2));
    heff_drop(v_n_2430);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2429, 0ULL, 1);
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2429, 0ULL, 1);
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_clo_take(self, 8);
    heff_drop(v_ended_2424);
    heff_drop(v_err_2425);
    heff_drop(v_who_247);
    heff_drop(v_out_241);
    heff_drop(v_lit_248);
    heff_drop(v_t_2433);
    V f_ = v_next_245;
    heff_room[0] = v_hd_244;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 8);
    heff_drop(v_next_245);
    heff_drop(v_t_2433);
    V v_t_2434 = v_ended_2424;
    V v_t_2443;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Exited: {
      heff_take_n(v_t_2434, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str9);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2434, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str10);
      break;
    }
    case TAG_TimedOut: {
      v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str11);
      break;
    }
    case TAG_NotRun: {
      V v_err_2437 = heff_field(v_t_2434, 0);
      heff_take_n(v_t_2434, 1ULL, 1);
      V v_path_2438 = heff_take_field(v_err_2437, 3);
      V v_name_2439 = heff_take_field(v_err_2437, 1);
      V v_message_2440 = heff_get_n(v_err_2437, 2, 4);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_path_2438, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str12)), v_name_2439);
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str13)), v_message_2440);
      v_t_2443 = heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_str14));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2443, v_err_2425), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam3, 1, 5, (V[]){v_who_247, v_out_241, v_hd_244, v_lit_248, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_who_247 = heff_env(self)[4];
  V v_out_241 = heff_env(self)[5];
  V v_lit_248 = heff_env(self)[6];
  V v_ended_2424 = heff_take_field(v_x_2423, 0);
  V v_err_2425 = heff_get_n(v_x_2423, 2, 3);
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag_n(TAG_End, 2, (V[]){v_x_243, NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0_lam2, 1, 8, (V[]){v_ended_2424, v_next_245, v_hd_244, v_k_246, v_err_2425, v_who_247, v_out_241, v_lit_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_str1, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_str2, 9, "heff.link");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(V v_st_240, V v_dir_241, V v_p_242, V v_hd_243, V v_out_244, V v_lit_245, V v_next_246, V v_k_247, V v_who_248, V v_lit_249, V v_x_2410) {
top: ;
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_2412 = heff_field(v_x_2410, 0);
    v_t_2413 = heff_dup(v_y_2412);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2414 = (g_list_2ekeepIf_24s1063601026x1972672043(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_str0), v_t_2413));
  V v_x_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam0, 1, 2, (V[]){heff_dup(v_st_240), heff_dup(v_dir_241)}), v_t_2414));
  V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2419));
  V v_total_2421 = heff_intAdd(v_t_2420, MK_INT(1LL));
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_242, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_str1), v_total_2421, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam1_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam2, 1, 10, (V[]){v_st_240, v_dir_241, v_hd_243, v_x_2419, v_out_244, v_lit_245, v_next_246, v_k_247, v_who_248, v_lit_249})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam0(V self, V *args) {
  V v_n_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_2415));
  V v_t_2418 = (g_std_2epath_2ejoin(v_t_2416, v_t_2417));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2418); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam1(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam3(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_out_244 = heff_env(self)[1];
  V v_lit_245 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_who_248 = heff_env(self)[7];
  V v_lit_249 = heff_env(self)[8];
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    V v_x_2440 = heff_field(v_x_2439, 0);
    V v_ru_24x_2439_24Left = heff_take_reuse_n(v_x_2439, 1ULL, 1);
    heff_clo_take(self, 9);
    return ({ V a_0 = v_x_2419; V a_1 = v_out_244; V a_2 = v_lit_245; V a_3 = v_x_2425; V a_4 = v_hd_243; V a_5 = v_next_246; V a_6 = v_k_247; V a_7 = v_who_248; V a_8 = v_lit_249; V b_9 = heff_tag_re_n(v_ru_24x_2439_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2440}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
  }
  case TAG_Right: {
    V v_y_2441 = heff_field(v_x_2439, 0);
    V v_ru_24x_2439_24Right = heff_take_reuse_n(v_x_2439, 1ULL, 1);
    switch (heff_tag_of(v_y_2441)) {
    case TAG_Left: {
      V v_err_2442 = heff_field(v_y_2441, 0);
      V v_ru_24y_2441_24Left = heff_take_reuse_n(v_y_2441, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2439_24Right, 1);
      heff_clo_take(self, 9);
      return ({ V a_0 = v_x_2419; V a_1 = v_out_244; V a_2 = v_lit_245; V a_3 = v_x_2425; V a_4 = v_hd_243; V a_5 = v_next_246; V a_6 = v_k_247; V a_7 = v_who_248; V a_8 = v_lit_249; V b_9 = heff_tag_re_n(v_ru_24y_2441_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2442}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
    }
    case TAG_Right: {
      V v_x_2443 = heff_field(v_y_2441, 0);
      heff_take_n(v_y_2441, 1ULL, 1);
      heff_clo_take(self, 9);
      return ({ V a_0 = v_x_2419; V a_1 = v_out_244; V a_2 = v_lit_245; V a_3 = v_x_2425; V a_4 = v_hd_243; V a_5 = v_next_246; V a_6 = v_k_247; V a_7 = v_who_248; V a_8 = v_lit_249; V b_9 = heff_tag_at_n(v_ru_24x_2439_24Right, TAG_Right, 1, (V[]){v_x_2443}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
    }
    default: return heff_nomatch(v_y_2441);
    }
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_out_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_next_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_who_248 = heff_env(self)[8];
  V v_lit_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_str2)));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  V v_s_2429 = ({ V a_0 = v_st_240; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2428); r_; });
  V v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2429));
  V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2430; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2430); r_; });
  V v_a_2433 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam3_clo)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2438, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_lam4, 1, 9, (V[]){v_x_2419, v_out_244, v_lit_245, v_x_2425, v_hd_243, v_next_246, v_k_247, v_who_248, v_lit_249})));
}