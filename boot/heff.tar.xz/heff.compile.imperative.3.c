// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_DSets 40405
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartOp 18051
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SIf 29564
#define TAG_SLet 1789
#define TAG_SSet 8516
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_toDest 1077793512
#define LBL_val 326043
static uint32_t shape_val__op__cond__sts__tl[] = {LBL_val, LBL_op, LBL_cond, LBL_sts, LBL_tl};
V g_heff_2ecompile_2eimperative_2eallL(V, V);
V g_heff_2ecompile_2eimperative_2eallL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eallL_clo;
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo;
V g_heff_2ecompile_2eimperative_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2efirstNamesTl(V);
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo;
V g_heff_2ecompile_2eimperative_2ematchTo(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchTo_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(V, V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_clo;
V g_heff_2ecompile_2eimperative_2eopTail(V, V);
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopTail_clo;
V g_heff_2ecompile_2eimperative_2epartsCond(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsSt(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsSt_clo;
V g_heff_2ecompile_2eimperative_2epartsTl(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_clo;
V g_heff_2ecompile_2eimperative_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2esetsOf(V, V, V);
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esetsOf_clo;
HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etestTail_clo;
V g_heff_2ecompile_2eimperative_2etoDest(V, V, V);
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etoDest_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2econdExpr(V);
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdExpr_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ezipWith_24s583291244x257539062(V, V);
V g_list_2ezipWith_24s583291244x257539062_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s251316015x352006831(V, V);
V g_prelude_2etraverse_24s251316015x352006831_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s251316015x352006831_clo;
Clo g_heff_2ecompile_2eimperative_2eallL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eallL_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eallL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eallL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2eallL(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLet: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_o_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_rest_243, v_p_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_q_249 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_PLet, 3, (V[]){v_x_244, v_o_245, v_q_249})}});
        } else {
          heff_drop(v_x_244);
          heff_drop(v_o_245);
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_SDecl: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSet: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIf: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCase: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eimperative_2epredLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredLets_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredLets(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_x1_240, v_p_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredLets(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseSet(V v_g_240, V v_d_241, V v_s_242, V v_arms_243) {
top: ;
  V v_atom_244 = heff_take_field(v_g_240, 5);
  V v_toDest_245 = heff_get_n(v_g_240, 4, 8);
  V v_m_246 = heff_tr(heff_call(v_atom_244, 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam0, 1, 4, (V[]){v_m_246, v_toDest_245, v_d_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  V v_vs_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_toDest_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_b_2414 = heff_field(v_arm_2411, 2);
    heff_take_n(v_arm_2411, 7ULL, 3);
    V v_m_2415 = heff_tr(heff_call(v_toDest_245, 2, (V[]){v_d_241, v_b_2414}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam2, 1, 3, (V[]){v_m_2415, v_t_2412, v_vs_2413});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_toDest_245 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2420 = (g_prelude_2etraverse_24s251316015x352006831(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam1, 1, 2, (V[]){v_toDest_245, v_d_241}), v_arms_243));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      V v_t_2426;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_dup(heff_field(v_x_249, 0));
        v_t_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2429;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_y_2428 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2429 = v_y_2428;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_t_2429, v_x_2422}), NTAG(TAG_Nil)});
      V v_x_2431 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2430));
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str3, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str4, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str5, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str6, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str8, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str9, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str10, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str11, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str12, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str13, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str14, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str15, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str16, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str17, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str18, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str19, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str21, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str22, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str23, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str24, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str25, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str26, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str27, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str28, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str29, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str30, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str31, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str32, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str33, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str34, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str35, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str36, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str37, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str38, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str39, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str40, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str41, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str42, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str43, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str44, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str45, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str46, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str47, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str48, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str49, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str50, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str51, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str52, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str53, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str54, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str55, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str56, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str57, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str58, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str59, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str60, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str61, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str62, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str63, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str64, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str65, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str66, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str67, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str68, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str69, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str70, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str71, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str72, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str73, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str74, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str75, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str76, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str77, 1, "t");
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam12(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam19(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam20(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam21(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam22(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam23(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam24(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam25(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam26(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam27(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam28(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam29(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam30(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam31(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam32(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam33(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam34(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam35(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam36(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam37(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam38(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam39(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam40(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam41(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam42(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam43(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam44(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam45(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam46(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam47(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam48(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam49(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam50(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam51(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam52(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam53(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam54(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam55(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam56(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam57(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam58(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam59(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam60(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etoDest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etoDest_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etoDest(V v_g_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_245 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam0, 1, 2, (V[]){v_m_245, v_d_241});
    }
    case TAG_DLet: {
      V v_m_2423 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam1, 1, 2, (V[]){v_m_2423, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_2441 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam2, 1, 1, (V[]){v_m_2441});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_2458 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam3, 1, 2, (V[]){v_m_2458, v_d_241});
    }
    case TAG_DLet: {
      V v_m_2476 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam4, 1, 2, (V[]){v_m_2476, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_2494 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam5, 1, 1, (V[]){v_m_2494});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_ELam: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24112 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam6, 1, 2, (V[]){v_m_24112, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24130 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam7, 1, 2, (V[]){v_m_24130, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24148 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam8, 1, 1, (V[]){v_m_24148});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24166 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam9, 1, 2, (V[]){v_m_24166, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24184 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam10, 1, 2, (V[]){v_m_24184, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24202 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam11, 1, 1, (V[]){v_m_24202});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_ELet: {
    V v_y_24217 = heff_field(v_e_242, 0);
    V v_a_24218 = heff_field(v_e_242, 1);
    V v_b_24219 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_24220 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(v_y_24217, heff_dup(v_a_24218), heff_dup(v_b_24219)));
    {
      V v_field_24222 = v_t_24220.f[1];
      int64_t v_tag_24221 = ((int64_t)v_t_24220.f[0]);
      if ((v_tag_24221 == ((int64_t)0ULL))) {
        heff_drop(v_y_24217);
        heff_drop(v_a_24218);
        heff_drop(v_b_24219);
        V v_e2_24223 = v_field_24222;
        V t_0 = v_g_240;
        V t_1 = v_d_241;
        V t_2 = v_e2_24223;
        v_g_240 = t_0;
        v_d_241 = t_1;
        v_e_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_24222);
        V v_m_24224 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_24217, v_a_24218}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam12, 1, 4, (V[]){v_m_24224, v_g_240, v_d_241, v_b_24219});
      }
    }
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24237 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam13, 1, 2, (V[]){v_m_24237, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24255 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam14, 1, 2, (V[]){v_m_24255, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24273 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam15, 1, 1, (V[]){v_m_24273});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24293 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam16, 1, 2, (V[]){v_m_24293, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24311 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam17, 1, 2, (V[]){v_m_24311, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24329 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam18, 1, 1, (V[]){v_m_24329});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24348 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam19, 1, 2, (V[]){v_m_24348, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24366 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam20, 1, 2, (V[]){v_m_24366, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24384 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam21, 1, 1, (V[]){v_m_24384});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EMatch: {
    V v_s_24399 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_24400 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24401 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24400));
    if (heff_intEq_c(v_t_24401, MK_INT(2LL))) {
      HeffT2 v_t_24402 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2etoDest_str28); V a_1 = heff_dup(v_arms_24400); HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_24404 = v_t_24402.f[1];
        int64_t v_tag_24403 = ((int64_t)v_t_24402.f[0]);
        if ((v_tag_24403 == ((int64_t)0ULL))) {
          V v_t_24405 = v_field_24404;
          HeffT2 v_t_24406 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2etoDest_str29); V a_1 = heff_dup(v_arms_24400); HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_24408 = v_t_24406.f[1];
            int64_t v_tag_24407 = ((int64_t)v_t_24406.f[0]);
            if ((v_tag_24407 == ((int64_t)0ULL))) {
              V v_f_24409 = v_field_24408;
              V v_t_24410 = v_t_24405;
              V v_f_24411 = v_f_24409;
              V v_t_24412 = heff_dup(heff_rfield(v_g_240, 0));
              if ((heff_dup(v_t_24412) == NTAG(TAG_True))) {
                heff_drop(v_t_24412);
                V v_t_24413 = (g_heff_2ecompile_2eimperative_2econdShaped(v_t_24410));
                if ((heff_dup(v_t_24413) == NTAG(TAG_True))) {
                  heff_drop(v_t_24413);
                  V v_t_24414 = (g_heff_2ecompile_2eimperative_2econdShaped(v_f_24411));
                  if ((heff_dup(v_t_24414) == NTAG(TAG_True))) {
                    heff_drop(v_t_24414);
                    V v_m_24415 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
                    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam22, 1, 5, (V[]){v_m_24415, v_g_240, v_d_241, v_s_24399, v_arms_24400});
                  } else {
                    heff_drop_tag(v_e_242, 2);
                    heff_drop(v_t_24414);
                    return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
                  }
                } else {
                  heff_drop_tag(v_e_242, 2);
                  heff_drop(v_f_24411);
                  heff_drop(v_t_24413);
                  return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
                }
              } else {
                heff_drop_tag(v_e_242, 2);
                heff_drop(v_t_24410);
                heff_drop(v_f_24411);
                heff_drop(v_t_24412);
                return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
              }
            } else {
              heff_drop_tag(v_e_242, 2);
              heff_drop(v_t_24405);
              heff_drop(v_field_24408);
              return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
            }
          }
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_field_24404);
          return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
        }
      }
    } else {
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24429 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam23, 1, 2, (V[]){v_m_24429, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24447 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam24, 1, 2, (V[]){v_m_24447, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24465 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam25, 1, 1, (V[]){v_m_24465});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24483 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam26, 1, 2, (V[]){v_m_24483, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24501 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam27, 1, 2, (V[]){v_m_24501, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24519 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam28, 1, 1, (V[]){v_m_24519});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24537 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam29, 1, 2, (V[]){v_m_24537, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24555 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam30, 1, 2, (V[]){v_m_24555, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24573 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam31, 1, 1, (V[]){v_m_24573});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24590 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam32, 1, 2, (V[]){v_m_24590, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24608 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam33, 1, 2, (V[]){v_m_24608, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24626 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam34, 1, 1, (V[]){v_m_24626});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24643 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam35, 1, 2, (V[]){v_m_24643, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24661 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam36, 1, 2, (V[]){v_m_24661, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24679 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam37, 1, 1, (V[]){v_m_24679});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24696 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam38, 1, 2, (V[]){v_m_24696, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24714 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam39, 1, 2, (V[]){v_m_24714, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24732 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam40, 1, 1, (V[]){v_m_24732});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24749 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam41, 1, 2, (V[]){v_m_24749, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24767 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam42, 1, 2, (V[]){v_m_24767, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24785 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam43, 1, 1, (V[]){v_m_24785});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24803 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam44, 1, 2, (V[]){v_m_24803, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24821 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam45, 1, 2, (V[]){v_m_24821, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24839 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam46, 1, 1, (V[]){v_m_24839});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24856 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam47, 1, 2, (V[]){v_m_24856, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24874 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam48, 1, 2, (V[]){v_m_24874, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24892 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam49, 1, 1, (V[]){v_m_24892});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24908 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam50, 1, 2, (V[]){v_m_24908, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24926 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam51, 1, 2, (V[]){v_m_24926, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24944 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam52, 1, 1, (V[]){v_m_24944});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EBool: {
    V v_c_24959 = heff_dup(heff_field(v_e_242, 0));
    V v_m_24960 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam53, 1, 4, (V[]){v_m_24960, v_c_24959, v_g_240, v_d_241});
  }
  case TAG_ESet: {
    V v_e1_24974 = heff_field(v_e_242, 0);
    V v_a_24975 = heff_field(v_e_242, 1);
    V v_b_24976 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_24977 = (g_heff_2ecompile_2eimperative_2esetsOf(heff_dup(v_g_240), v_e1_24974, v_a_24975));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam54, 1, 4, (V[]){v_m_24977, v_g_240, v_d_241, v_b_24976});
  }
  case TAG_EValues: {
    V v_es_24987 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_drop(v_es_24987);
      V v_m_24989 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam55, 1, 2, (V[]){v_m_24989, v_d_241});
    }
    case TAG_DLet: {
      heff_drop(v_es_24987);
      V v_m_241007 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam56, 1, 2, (V[]){v_m_241007, v_d_241});
    }
    case TAG_DSets: {
      V v_xs_241024 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      heff_drop_tag(v_e_242, 1);
      V v_m_241025 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_es_24987));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam57, 1, 2, (V[]){v_m_241025, v_xs_241024});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_241041 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam58, 1, 2, (V[]){v_m_241041, v_d_241});
    }
    case TAG_DLet: {
      V v_m_241059 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam59, 1, 2, (V[]){v_m_241059, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_241077 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam60, 1, 1, (V[]){v_m_241077});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etoDest(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_dup(heff_field(v_x_248, 0));
      v_t_2412 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_o_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_y_2414 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_o_2415 = v_y_2414;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2419;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2416 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2419 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2416, v_o_2415});
      break;
    }
    case TAG_DLet: {
      V v_x_2417 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2419 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2417, v_o_2415});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_2419 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str0), v_o_2415});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_x_2421 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2420));
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_t_2430;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkPair: {
      V v_x_2428 = heff_dup(heff_field(v_x_2426, 0));
      v_t_2430 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_o_2433;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_MkPair: {
      V v_y_2432 = heff_field(v_x_2426, 1);
      heff_take_n(v_x_2426, 2ULL, 2);
      v_o_2433 = v_y_2432;
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2437;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2434 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2437 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2434, v_o_2433});
      break;
    }
    case TAG_DLet: {
      V v_x_2435 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2437 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2435, v_o_2433});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_2437 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str1), v_o_2433});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    V v_x_2439 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2438));
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_2439, v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args) {
  V v_n_2442 = args[0];
  V v_m_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2443 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_n_2442}));
  switch (heff_tag_of(v_x2_2443)) {
  case TAG_MkPair: {
    V v_x_2444 = heff_field(v_x2_2443, 0);
    V v_n_2445 = heff_field(v_x2_2443, 1);
    V v_ru_24x2_2443_24MkPair = heff_take_reuse_n(v_x2_2443, 3ULL, 2);
    V v_t_2448;
    switch (heff_tag_of(v_x_2444)) {
    case TAG_MkPair: {
      V v_x_2446 = heff_dup(heff_field(v_x_2444, 0));
      v_t_2448 = v_x_2446;
      break;
    }
    default: heff_nomatch(v_x_2444);
    }
    V v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str2), heff_intShow(heff_dup(v_n_2445)));
    V v_t_2452;
    switch (heff_tag_of(v_x_2444)) {
    case TAG_MkPair: {
      V v_y_2451 = heff_field(v_x_2444, 1);
      heff_take_n(v_x_2444, 2ULL, 2);
      v_t_2452 = v_y_2451;
      break;
    }
    default: heff_nomatch(v_x_2444);
    }
    V v_t_2453 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str3), v_t_2449), v_t_2452});
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    V v_x_2455 = (g_prelude_2e_2b_2b(v_t_2448, v_t_2454));
    return heff_tag_at_n(v_ru_24x2_2443_24MkPair, TAG_MkPair, 2, (V[]){v_x_2455, heff_intAdd(v_n_2445, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_2443);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    V v_t_2465;
    switch (heff_tag_of(v_x_2461)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_dup(heff_field(v_x_2461, 0));
      v_t_2465 = v_x_2463;
      break;
    }
    default: heff_nomatch(v_x_2461);
    }
    V v_o_2468;
    switch (heff_tag_of(v_x_2461)) {
    case TAG_MkPair: {
      V v_y_2467 = heff_field(v_x_2461, 1);
      heff_take_n(v_x_2461, 2ULL, 2);
      v_o_2468 = v_y_2467;
      break;
    }
    default: heff_nomatch(v_x_2461);
    }
    V v_t_2472;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2469 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2472 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2469, v_o_2468});
      break;
    }
    case TAG_DLet: {
      V v_x_2470 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2472 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2470, v_o_2468});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_2472 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str4), v_o_2468});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
    V v_x_2474 = (g_prelude_2e_2b_2b(v_t_2465, v_t_2473));
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){v_x_2474, v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args) {
  V v_n_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_n_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_n_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_t_2483;
    switch (heff_tag_of(v_x_2479)) {
    case TAG_MkPair: {
      V v_x_2481 = heff_dup(heff_field(v_x_2479, 0));
      v_t_2483 = v_x_2481;
      break;
    }
    default: heff_nomatch(v_x_2479);
    }
    V v_o_2486;
    switch (heff_tag_of(v_x_2479)) {
    case TAG_MkPair: {
      V v_y_2485 = heff_field(v_x_2479, 1);
      heff_take_n(v_x_2479, 2ULL, 2);
      v_o_2486 = v_y_2485;
      break;
    }
    default: heff_nomatch(v_x_2479);
    }
    V v_t_2490;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2487 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2490 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2487, v_o_2486});
      break;
    }
    case TAG_DLet: {
      V v_x_2488 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2490 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2488, v_o_2486});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_2490 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str5), v_o_2486});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, NTAG(TAG_Nil)});
    V v_x_2492 = (g_prelude_2e_2b_2b(v_t_2483, v_t_2491));
    return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){v_x_2492, v_n_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args) {
  V v_n_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_n_2495}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_MkPair: {
    V v_x_2497 = heff_field(v_x2_2496, 0);
    V v_n_2498 = heff_field(v_x2_2496, 1);
    V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
    V v_t_24101;
    switch (heff_tag_of(v_x_2497)) {
    case TAG_MkPair: {
      V v_x_2499 = heff_dup(heff_field(v_x_2497, 0));
      v_t_24101 = v_x_2499;
      break;
    }
    default: heff_nomatch(v_x_2497);
    }
    V v_t_24102 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str6), heff_intShow(heff_dup(v_n_2498)));
    V v_t_24105;
    switch (heff_tag_of(v_x_2497)) {
    case TAG_MkPair: {
      V v_y_24104 = heff_field(v_x_2497, 1);
      heff_take_n(v_x_2497, 2ULL, 2);
      v_t_24105 = v_y_24104;
      break;
    }
    default: heff_nomatch(v_x_2497);
    }
    V v_t_24106 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str7), v_t_24102), v_t_24105});
    V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, NTAG(TAG_Nil)});
    V v_x_24108 = (g_prelude_2e_2b_2b(v_t_24101, v_t_24107));
    return heff_tag_at_n(v_ru_24x2_2496_24MkPair, TAG_MkPair, 2, (V[]){v_x_24108, heff_intAdd(v_n_2498, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args) {
  V v_n_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_n_24113}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_n_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    V v_t_24119;
    switch (heff_tag_of(v_x_24115)) {
    case TAG_MkPair: {
      V v_x_24117 = heff_dup(heff_field(v_x_24115, 0));
      v_t_24119 = v_x_24117;
      break;
    }
    default: heff_nomatch(v_x_24115);
    }
    V v_o_24122;
    switch (heff_tag_of(v_x_24115)) {
    case TAG_MkPair: {
      V v_y_24121 = heff_field(v_x_24115, 1);
      heff_take_n(v_x_24115, 2ULL, 2);
      v_o_24122 = v_y_24121;
      break;
    }
    default: heff_nomatch(v_x_24115);
    }
    V v_t_24126;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24123 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24126 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24123, v_o_24122});
      break;
    }
    case TAG_DLet: {
      V v_x_24124 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24126 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24124, v_o_24122});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24126 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str8), v_o_24122});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
    V v_x_24128 = (g_prelude_2e_2b_2b(v_t_24119, v_t_24127));
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){v_x_24128, v_n_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args) {
  V v_n_24131 = args[0];
  V v_m_24130 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24132 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_n_24131}));
  switch (heff_tag_of(v_x2_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_x2_24132, 0);
    V v_n_24134 = heff_field(v_x2_24132, 1);
    V v_ru_24x2_24132_24MkPair = heff_take_reuse_n(v_x2_24132, 3ULL, 2);
    V v_t_24137;
    switch (heff_tag_of(v_x_24133)) {
    case TAG_MkPair: {
      V v_x_24135 = heff_dup(heff_field(v_x_24133, 0));
      v_t_24137 = v_x_24135;
      break;
    }
    default: heff_nomatch(v_x_24133);
    }
    V v_o_24140;
    switch (heff_tag_of(v_x_24133)) {
    case TAG_MkPair: {
      V v_y_24139 = heff_field(v_x_24133, 1);
      heff_take_n(v_x_24133, 2ULL, 2);
      v_o_24140 = v_y_24139;
      break;
    }
    default: heff_nomatch(v_x_24133);
    }
    V v_t_24144;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24141 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24144 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24141, v_o_24140});
      break;
    }
    case TAG_DLet: {
      V v_x_24142 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24144 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24142, v_o_24140});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24144 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str9), v_o_24140});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, NTAG(TAG_Nil)});
    V v_x_24146 = (g_prelude_2e_2b_2b(v_t_24137, v_t_24145));
    return heff_tag_at_n(v_ru_24x2_24132_24MkPair, TAG_MkPair, 2, (V[]){v_x_24146, v_n_24134});
  }
  default: return heff_nomatch(v_x2_24132);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args) {
  V v_n_24149 = args[0];
  V v_m_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24150 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_n_24149}));
  switch (heff_tag_of(v_x2_24150)) {
  case TAG_MkPair: {
    V v_x_24151 = heff_field(v_x2_24150, 0);
    V v_n_24152 = heff_field(v_x2_24150, 1);
    V v_ru_24x2_24150_24MkPair = heff_take_reuse_n(v_x2_24150, 3ULL, 2);
    V v_t_24155;
    switch (heff_tag_of(v_x_24151)) {
    case TAG_MkPair: {
      V v_x_24153 = heff_dup(heff_field(v_x_24151, 0));
      v_t_24155 = v_x_24153;
      break;
    }
    default: heff_nomatch(v_x_24151);
    }
    V v_t_24156 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str10), heff_intShow(heff_dup(v_n_24152)));
    V v_t_24159;
    switch (heff_tag_of(v_x_24151)) {
    case TAG_MkPair: {
      V v_y_24158 = heff_field(v_x_24151, 1);
      heff_take_n(v_x_24151, 2ULL, 2);
      v_t_24159 = v_y_24158;
      break;
    }
    default: heff_nomatch(v_x_24151);
    }
    V v_t_24160 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str11), v_t_24156), v_t_24159});
    V v_t_24161 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24160, NTAG(TAG_Nil)});
    V v_x_24162 = (g_prelude_2e_2b_2b(v_t_24155, v_t_24161));
    return heff_tag_at_n(v_ru_24x2_24150_24MkPair, TAG_MkPair, 2, (V[]){v_x_24162, heff_intAdd(v_n_24152, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24150);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args) {
  V v_n_24167 = args[0];
  V v_m_24166 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24168 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_n_24167}));
  switch (heff_tag_of(v_x2_24168)) {
  case TAG_MkPair: {
    V v_x_24169 = heff_field(v_x2_24168, 0);
    V v_n_24170 = heff_field(v_x2_24168, 1);
    V v_ru_24x2_24168_24MkPair = heff_take_reuse_n(v_x2_24168, 3ULL, 2);
    V v_t_24173;
    switch (heff_tag_of(v_x_24169)) {
    case TAG_MkPair: {
      V v_x_24171 = heff_dup(heff_field(v_x_24169, 0));
      v_t_24173 = v_x_24171;
      break;
    }
    default: heff_nomatch(v_x_24169);
    }
    V v_o_24176;
    switch (heff_tag_of(v_x_24169)) {
    case TAG_MkPair: {
      V v_y_24175 = heff_field(v_x_24169, 1);
      heff_take_n(v_x_24169, 2ULL, 2);
      v_o_24176 = v_y_24175;
      break;
    }
    default: heff_nomatch(v_x_24169);
    }
    V v_t_24180;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24177 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24180 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24177, v_o_24176});
      break;
    }
    case TAG_DLet: {
      V v_x_24178 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24180 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24178, v_o_24176});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24180 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str12), v_o_24176});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24180, NTAG(TAG_Nil)});
    V v_x_24182 = (g_prelude_2e_2b_2b(v_t_24173, v_t_24181));
    return heff_tag_at_n(v_ru_24x2_24168_24MkPair, TAG_MkPair, 2, (V[]){v_x_24182, v_n_24170});
  }
  default: return heff_nomatch(v_x2_24168);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam10(V self, V *args) {
  V v_n_24185 = args[0];
  V v_m_24184 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24186 = heff_tr(heff_call(v_m_24184, 1, (V[]){v_n_24185}));
  switch (heff_tag_of(v_x2_24186)) {
  case TAG_MkPair: {
    V v_x_24187 = heff_field(v_x2_24186, 0);
    V v_n_24188 = heff_field(v_x2_24186, 1);
    V v_ru_24x2_24186_24MkPair = heff_take_reuse_n(v_x2_24186, 3ULL, 2);
    V v_t_24191;
    switch (heff_tag_of(v_x_24187)) {
    case TAG_MkPair: {
      V v_x_24189 = heff_dup(heff_field(v_x_24187, 0));
      v_t_24191 = v_x_24189;
      break;
    }
    default: heff_nomatch(v_x_24187);
    }
    V v_o_24194;
    switch (heff_tag_of(v_x_24187)) {
    case TAG_MkPair: {
      V v_y_24193 = heff_field(v_x_24187, 1);
      heff_take_n(v_x_24187, 2ULL, 2);
      v_o_24194 = v_y_24193;
      break;
    }
    default: heff_nomatch(v_x_24187);
    }
    V v_t_24198;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24195 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24198 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24195, v_o_24194});
      break;
    }
    case TAG_DLet: {
      V v_x_24196 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24198 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24196, v_o_24194});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24198 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str13), v_o_24194});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24199 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24198, NTAG(TAG_Nil)});
    V v_x_24200 = (g_prelude_2e_2b_2b(v_t_24191, v_t_24199));
    return heff_tag_at_n(v_ru_24x2_24186_24MkPair, TAG_MkPair, 2, (V[]){v_x_24200, v_n_24188});
  }
  default: return heff_nomatch(v_x2_24186);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam11(V self, V *args) {
  V v_n_24203 = args[0];
  V v_m_24202 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24204 = heff_tr(heff_call(v_m_24202, 1, (V[]){v_n_24203}));
  switch (heff_tag_of(v_x2_24204)) {
  case TAG_MkPair: {
    V v_x_24205 = heff_field(v_x2_24204, 0);
    V v_n_24206 = heff_field(v_x2_24204, 1);
    V v_ru_24x2_24204_24MkPair = heff_take_reuse_n(v_x2_24204, 3ULL, 2);
    V v_t_24209;
    switch (heff_tag_of(v_x_24205)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_dup(heff_field(v_x_24205, 0));
      v_t_24209 = v_x_24207;
      break;
    }
    default: heff_nomatch(v_x_24205);
    }
    V v_t_24210 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str14), heff_intShow(heff_dup(v_n_24206)));
    V v_t_24213;
    switch (heff_tag_of(v_x_24205)) {
    case TAG_MkPair: {
      V v_y_24212 = heff_field(v_x_24205, 1);
      heff_take_n(v_x_24205, 2ULL, 2);
      v_t_24213 = v_y_24212;
      break;
    }
    default: heff_nomatch(v_x_24205);
    }
    V v_t_24214 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str15), v_t_24210), v_t_24213});
    V v_t_24215 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24214, NTAG(TAG_Nil)});
    V v_x_24216 = (g_prelude_2e_2b_2b(v_t_24209, v_t_24215));
    return heff_tag_at_n(v_ru_24x2_24204_24MkPair, TAG_MkPair, 2, (V[]){v_x_24216, heff_intAdd(v_n_24206, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24204);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam12(V self, V *args) {
  V v_n_24225 = args[0];
  V v_m_24224 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_24219 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24226 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_n_24225}));
  switch (heff_tag_of(v_x2_24226)) {
  case TAG_MkPair: {
    V v_x_24227 = heff_field(v_x2_24226, 0);
    V v_n_24228 = heff_field(v_x2_24226, 1);
    V v_ru_24x2_24226_24MkPair = heff_take_reuse_n(v_x2_24226, 3ULL, 2);
    V v_m_24229 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_b_24219));
    V v_x2_24230 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_n_24228}));
    switch (heff_tag_of(v_x2_24230)) {
    case TAG_MkPair: {
      V v_x_24231 = heff_field(v_x2_24230, 0);
      V v_n_24232 = heff_field(v_x2_24230, 1);
      V v_ru_24x2_24230_24MkPair = heff_take_reuse_n(v_x2_24230, 3ULL, 2);
      V v_x_24233 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_24230_24MkPair, v_x_24227, v_x_24231));
      return heff_tag_at_n(v_ru_24x2_24226_24MkPair, TAG_MkPair, 2, (V[]){v_x_24233, v_n_24232});
    }
    default: return heff_nomatch(v_x2_24230);
    }
  }
  default: return heff_nomatch(v_x2_24226);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam13(V self, V *args) {
  V v_n_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_n_24238}));
  switch (heff_tag_of(v_x2_24239)) {
  case TAG_MkPair: {
    V v_x_24240 = heff_field(v_x2_24239, 0);
    V v_n_24241 = heff_field(v_x2_24239, 1);
    V v_ru_24x2_24239_24MkPair = heff_take_reuse_n(v_x2_24239, 3ULL, 2);
    V v_t_24244;
    switch (heff_tag_of(v_x_24240)) {
    case TAG_MkPair: {
      V v_x_24242 = heff_dup(heff_field(v_x_24240, 0));
      v_t_24244 = v_x_24242;
      break;
    }
    default: heff_nomatch(v_x_24240);
    }
    V v_o_24247;
    switch (heff_tag_of(v_x_24240)) {
    case TAG_MkPair: {
      V v_y_24246 = heff_field(v_x_24240, 1);
      heff_take_n(v_x_24240, 2ULL, 2);
      v_o_24247 = v_y_24246;
      break;
    }
    default: heff_nomatch(v_x_24240);
    }
    V v_t_24251;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24248 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24251 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24248, v_o_24247});
      break;
    }
    case TAG_DLet: {
      V v_x_24249 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24251 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24249, v_o_24247});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24251 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str16), v_o_24247});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24252 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24251, NTAG(TAG_Nil)});
    V v_x_24253 = (g_prelude_2e_2b_2b(v_t_24244, v_t_24252));
    return heff_tag_at_n(v_ru_24x2_24239_24MkPair, TAG_MkPair, 2, (V[]){v_x_24253, v_n_24241});
  }
  default: return heff_nomatch(v_x2_24239);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam14(V self, V *args) {
  V v_n_24256 = args[0];
  V v_m_24255 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24257 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_n_24256}));
  switch (heff_tag_of(v_x2_24257)) {
  case TAG_MkPair: {
    V v_x_24258 = heff_field(v_x2_24257, 0);
    V v_n_24259 = heff_field(v_x2_24257, 1);
    V v_ru_24x2_24257_24MkPair = heff_take_reuse_n(v_x2_24257, 3ULL, 2);
    V v_t_24262;
    switch (heff_tag_of(v_x_24258)) {
    case TAG_MkPair: {
      V v_x_24260 = heff_dup(heff_field(v_x_24258, 0));
      v_t_24262 = v_x_24260;
      break;
    }
    default: heff_nomatch(v_x_24258);
    }
    V v_o_24265;
    switch (heff_tag_of(v_x_24258)) {
    case TAG_MkPair: {
      V v_y_24264 = heff_field(v_x_24258, 1);
      heff_take_n(v_x_24258, 2ULL, 2);
      v_o_24265 = v_y_24264;
      break;
    }
    default: heff_nomatch(v_x_24258);
    }
    V v_t_24269;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24266 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24269 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24266, v_o_24265});
      break;
    }
    case TAG_DLet: {
      V v_x_24267 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24269 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24267, v_o_24265});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24269 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str17), v_o_24265});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24270 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24269, NTAG(TAG_Nil)});
    V v_x_24271 = (g_prelude_2e_2b_2b(v_t_24262, v_t_24270));
    return heff_tag_at_n(v_ru_24x2_24257_24MkPair, TAG_MkPair, 2, (V[]){v_x_24271, v_n_24259});
  }
  default: return heff_nomatch(v_x2_24257);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam15(V self, V *args) {
  V v_n_24274 = args[0];
  V v_m_24273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24275 = heff_tr(heff_call(v_m_24273, 1, (V[]){v_n_24274}));
  switch (heff_tag_of(v_x2_24275)) {
  case TAG_MkPair: {
    V v_x_24276 = heff_field(v_x2_24275, 0);
    V v_n_24277 = heff_field(v_x2_24275, 1);
    V v_ru_24x2_24275_24MkPair = heff_take_reuse_n(v_x2_24275, 3ULL, 2);
    V v_t_24280;
    switch (heff_tag_of(v_x_24276)) {
    case TAG_MkPair: {
      V v_x_24278 = heff_dup(heff_field(v_x_24276, 0));
      v_t_24280 = v_x_24278;
      break;
    }
    default: heff_nomatch(v_x_24276);
    }
    V v_t_24281 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str18), heff_intShow(heff_dup(v_n_24277)));
    V v_t_24284;
    switch (heff_tag_of(v_x_24276)) {
    case TAG_MkPair: {
      V v_y_24283 = heff_field(v_x_24276, 1);
      heff_take_n(v_x_24276, 2ULL, 2);
      v_t_24284 = v_y_24283;
      break;
    }
    default: heff_nomatch(v_x_24276);
    }
    V v_t_24285 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str19), v_t_24281), v_t_24284});
    V v_t_24286 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24285, NTAG(TAG_Nil)});
    V v_x_24287 = (g_prelude_2e_2b_2b(v_t_24280, v_t_24286));
    return heff_tag_at_n(v_ru_24x2_24275_24MkPair, TAG_MkPair, 2, (V[]){v_x_24287, heff_intAdd(v_n_24277, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24275);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam16(V self, V *args) {
  V v_n_24294 = args[0];
  V v_m_24293 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24295 = heff_tr(heff_call(v_m_24293, 1, (V[]){v_n_24294}));
  switch (heff_tag_of(v_x2_24295)) {
  case TAG_MkPair: {
    V v_x_24296 = heff_field(v_x2_24295, 0);
    V v_n_24297 = heff_field(v_x2_24295, 1);
    V v_ru_24x2_24295_24MkPair = heff_take_reuse_n(v_x2_24295, 3ULL, 2);
    V v_t_24300;
    switch (heff_tag_of(v_x_24296)) {
    case TAG_MkPair: {
      V v_x_24298 = heff_dup(heff_field(v_x_24296, 0));
      v_t_24300 = v_x_24298;
      break;
    }
    default: heff_nomatch(v_x_24296);
    }
    V v_o_24303;
    switch (heff_tag_of(v_x_24296)) {
    case TAG_MkPair: {
      V v_y_24302 = heff_field(v_x_24296, 1);
      heff_take_n(v_x_24296, 2ULL, 2);
      v_o_24303 = v_y_24302;
      break;
    }
    default: heff_nomatch(v_x_24296);
    }
    V v_t_24307;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24304 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24307 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24304, v_o_24303});
      break;
    }
    case TAG_DLet: {
      V v_x_24305 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24307 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24305, v_o_24303});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24307 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str20), v_o_24303});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24308 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24307, NTAG(TAG_Nil)});
    V v_x_24309 = (g_prelude_2e_2b_2b(v_t_24300, v_t_24308));
    return heff_tag_at_n(v_ru_24x2_24295_24MkPair, TAG_MkPair, 2, (V[]){v_x_24309, v_n_24297});
  }
  default: return heff_nomatch(v_x2_24295);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam17(V self, V *args) {
  V v_n_24312 = args[0];
  V v_m_24311 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24313 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_n_24312}));
  switch (heff_tag_of(v_x2_24313)) {
  case TAG_MkPair: {
    V v_x_24314 = heff_field(v_x2_24313, 0);
    V v_n_24315 = heff_field(v_x2_24313, 1);
    V v_ru_24x2_24313_24MkPair = heff_take_reuse_n(v_x2_24313, 3ULL, 2);
    V v_t_24318;
    switch (heff_tag_of(v_x_24314)) {
    case TAG_MkPair: {
      V v_x_24316 = heff_dup(heff_field(v_x_24314, 0));
      v_t_24318 = v_x_24316;
      break;
    }
    default: heff_nomatch(v_x_24314);
    }
    V v_o_24321;
    switch (heff_tag_of(v_x_24314)) {
    case TAG_MkPair: {
      V v_y_24320 = heff_field(v_x_24314, 1);
      heff_take_n(v_x_24314, 2ULL, 2);
      v_o_24321 = v_y_24320;
      break;
    }
    default: heff_nomatch(v_x_24314);
    }
    V v_t_24325;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24322 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24325 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24322, v_o_24321});
      break;
    }
    case TAG_DLet: {
      V v_x_24323 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24325 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24323, v_o_24321});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24325 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str21), v_o_24321});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24326 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24325, NTAG(TAG_Nil)});
    V v_x_24327 = (g_prelude_2e_2b_2b(v_t_24318, v_t_24326));
    return heff_tag_at_n(v_ru_24x2_24313_24MkPair, TAG_MkPair, 2, (V[]){v_x_24327, v_n_24315});
  }
  default: return heff_nomatch(v_x2_24313);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam18(V self, V *args) {
  V v_n_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_n_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_n_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_t_24336;
    switch (heff_tag_of(v_x_24332)) {
    case TAG_MkPair: {
      V v_x_24334 = heff_dup(heff_field(v_x_24332, 0));
      v_t_24336 = v_x_24334;
      break;
    }
    default: heff_nomatch(v_x_24332);
    }
    V v_t_24337 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str22), heff_intShow(heff_dup(v_n_24333)));
    V v_t_24340;
    switch (heff_tag_of(v_x_24332)) {
    case TAG_MkPair: {
      V v_y_24339 = heff_field(v_x_24332, 1);
      heff_take_n(v_x_24332, 2ULL, 2);
      v_t_24340 = v_y_24339;
      break;
    }
    default: heff_nomatch(v_x_24332);
    }
    V v_t_24341 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str23), v_t_24337), v_t_24340});
    V v_t_24342 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24341, NTAG(TAG_Nil)});
    V v_x_24343 = (g_prelude_2e_2b_2b(v_t_24336, v_t_24342));
    return heff_tag_at_n(v_ru_24x2_24331_24MkPair, TAG_MkPair, 2, (V[]){v_x_24343, heff_intAdd(v_n_24333, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam19(V self, V *args) {
  V v_n_24349 = args[0];
  V v_m_24348 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24350 = heff_tr(heff_call(v_m_24348, 1, (V[]){v_n_24349}));
  switch (heff_tag_of(v_x2_24350)) {
  case TAG_MkPair: {
    V v_x_24351 = heff_field(v_x2_24350, 0);
    V v_n_24352 = heff_field(v_x2_24350, 1);
    V v_ru_24x2_24350_24MkPair = heff_take_reuse_n(v_x2_24350, 3ULL, 2);
    V v_t_24355;
    switch (heff_tag_of(v_x_24351)) {
    case TAG_MkPair: {
      V v_x_24353 = heff_dup(heff_field(v_x_24351, 0));
      v_t_24355 = v_x_24353;
      break;
    }
    default: heff_nomatch(v_x_24351);
    }
    V v_o_24358;
    switch (heff_tag_of(v_x_24351)) {
    case TAG_MkPair: {
      V v_y_24357 = heff_field(v_x_24351, 1);
      heff_take_n(v_x_24351, 2ULL, 2);
      v_o_24358 = v_y_24357;
      break;
    }
    default: heff_nomatch(v_x_24351);
    }
    V v_t_24362;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24359 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24362 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24359, v_o_24358});
      break;
    }
    case TAG_DLet: {
      V v_x_24360 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24362 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24360, v_o_24358});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24362 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str24), v_o_24358});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24363 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24362, NTAG(TAG_Nil)});
    V v_x_24364 = (g_prelude_2e_2b_2b(v_t_24355, v_t_24363));
    return heff_tag_at_n(v_ru_24x2_24350_24MkPair, TAG_MkPair, 2, (V[]){v_x_24364, v_n_24352});
  }
  default: return heff_nomatch(v_x2_24350);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam20(V self, V *args) {
  V v_n_24367 = args[0];
  V v_m_24366 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24368 = heff_tr(heff_call(v_m_24366, 1, (V[]){v_n_24367}));
  switch (heff_tag_of(v_x2_24368)) {
  case TAG_MkPair: {
    V v_x_24369 = heff_field(v_x2_24368, 0);
    V v_n_24370 = heff_field(v_x2_24368, 1);
    V v_ru_24x2_24368_24MkPair = heff_take_reuse_n(v_x2_24368, 3ULL, 2);
    V v_t_24373;
    switch (heff_tag_of(v_x_24369)) {
    case TAG_MkPair: {
      V v_x_24371 = heff_dup(heff_field(v_x_24369, 0));
      v_t_24373 = v_x_24371;
      break;
    }
    default: heff_nomatch(v_x_24369);
    }
    V v_o_24376;
    switch (heff_tag_of(v_x_24369)) {
    case TAG_MkPair: {
      V v_y_24375 = heff_field(v_x_24369, 1);
      heff_take_n(v_x_24369, 2ULL, 2);
      v_o_24376 = v_y_24375;
      break;
    }
    default: heff_nomatch(v_x_24369);
    }
    V v_t_24380;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24377 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24380 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24377, v_o_24376});
      break;
    }
    case TAG_DLet: {
      V v_x_24378 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24380 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24378, v_o_24376});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24380 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str25), v_o_24376});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24381 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24380, NTAG(TAG_Nil)});
    V v_x_24382 = (g_prelude_2e_2b_2b(v_t_24373, v_t_24381));
    return heff_tag_at_n(v_ru_24x2_24368_24MkPair, TAG_MkPair, 2, (V[]){v_x_24382, v_n_24370});
  }
  default: return heff_nomatch(v_x2_24368);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam21(V self, V *args) {
  V v_n_24385 = args[0];
  V v_m_24384 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24386 = heff_tr(heff_call(v_m_24384, 1, (V[]){v_n_24385}));
  switch (heff_tag_of(v_x2_24386)) {
  case TAG_MkPair: {
    V v_x_24387 = heff_field(v_x2_24386, 0);
    V v_n_24388 = heff_field(v_x2_24386, 1);
    V v_ru_24x2_24386_24MkPair = heff_take_reuse_n(v_x2_24386, 3ULL, 2);
    V v_t_24391;
    switch (heff_tag_of(v_x_24387)) {
    case TAG_MkPair: {
      V v_x_24389 = heff_dup(heff_field(v_x_24387, 0));
      v_t_24391 = v_x_24389;
      break;
    }
    default: heff_nomatch(v_x_24387);
    }
    V v_t_24392 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str26), heff_intShow(heff_dup(v_n_24388)));
    V v_t_24395;
    switch (heff_tag_of(v_x_24387)) {
    case TAG_MkPair: {
      V v_y_24394 = heff_field(v_x_24387, 1);
      heff_take_n(v_x_24387, 2ULL, 2);
      v_t_24395 = v_y_24394;
      break;
    }
    default: heff_nomatch(v_x_24387);
    }
    V v_t_24396 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str27), v_t_24392), v_t_24395});
    V v_t_24397 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24396, NTAG(TAG_Nil)});
    V v_x_24398 = (g_prelude_2e_2b_2b(v_t_24391, v_t_24397));
    return heff_tag_at_n(v_ru_24x2_24386_24MkPair, TAG_MkPair, 2, (V[]){v_x_24398, heff_intAdd(v_n_24388, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24386);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam22(V self, V *args) {
  V v_n_24416 = args[0];
  V v_m_24415 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_s_24399 = heff_env(self)[3];
  V v_arms_24400 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24417 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_n_24416}));
  switch (heff_tag_of(v_x2_24417)) {
  case TAG_MkPair: {
    V v_x_24418 = heff_field(v_x2_24417, 0);
    V v_n_24419 = heff_field(v_x2_24417, 1);
    V v_ru_24x2_24417_24MkPair = heff_take_reuse_n(v_x2_24417, 3ULL, 2);
    switch (heff_tag_of(v_x_24418)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_24417_24MkPair, 2);
      V v_t_24420 = (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_24399, v_arms_24400));
      V f_ = v_t_24420;
      args[0] = v_n_24419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_24421 = heff_field(v_x_24418, 0);
      V v_ru_24x_24418_24Just = heff_take_reuse_n(v_x_24418, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_24399);
      heff_drop(v_arms_24400);
      V v_t_24425;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24422 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24425 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24422, heff_tag_at_n(v_ru_24x_24418_24Just, TAG_OBool, 1, (V[]){v_c_24421})});
        break;
      }
      case TAG_DLet: {
        V v_x_24423 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24425 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24423, heff_tag_at_n(v_ru_24x_24418_24Just, TAG_OBool, 1, (V[]){v_c_24421})});
        break;
      }
      case TAG_DSets: {
        heff_take_n(v_d_241, 0ULL, 1);
        v_t_24425 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str30), heff_tag_at_n(v_ru_24x_24418_24Just, TAG_OBool, 1, (V[]){v_c_24421})});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_t_24426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24425, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_24417_24MkPair, TAG_MkPair, 2, (V[]){v_t_24426, v_n_24419});
    }
    default: return heff_nomatch(v_x_24418);
    }
  }
  default: return heff_nomatch(v_x2_24417);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam23(V self, V *args) {
  V v_n_24430 = args[0];
  V v_m_24429 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24431 = heff_tr(heff_call(v_m_24429, 1, (V[]){v_n_24430}));
  switch (heff_tag_of(v_x2_24431)) {
  case TAG_MkPair: {
    V v_x_24432 = heff_field(v_x2_24431, 0);
    V v_n_24433 = heff_field(v_x2_24431, 1);
    V v_ru_24x2_24431_24MkPair = heff_take_reuse_n(v_x2_24431, 3ULL, 2);
    V v_t_24436;
    switch (heff_tag_of(v_x_24432)) {
    case TAG_MkPair: {
      V v_x_24434 = heff_dup(heff_field(v_x_24432, 0));
      v_t_24436 = v_x_24434;
      break;
    }
    default: heff_nomatch(v_x_24432);
    }
    V v_o_24439;
    switch (heff_tag_of(v_x_24432)) {
    case TAG_MkPair: {
      V v_y_24438 = heff_field(v_x_24432, 1);
      heff_take_n(v_x_24432, 2ULL, 2);
      v_o_24439 = v_y_24438;
      break;
    }
    default: heff_nomatch(v_x_24432);
    }
    V v_t_24443;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24440 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24443 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24440, v_o_24439});
      break;
    }
    case TAG_DLet: {
      V v_x_24441 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24443 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24441, v_o_24439});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24443 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str31), v_o_24439});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24443, NTAG(TAG_Nil)});
    V v_x_24445 = (g_prelude_2e_2b_2b(v_t_24436, v_t_24444));
    return heff_tag_at_n(v_ru_24x2_24431_24MkPair, TAG_MkPair, 2, (V[]){v_x_24445, v_n_24433});
  }
  default: return heff_nomatch(v_x2_24431);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam24(V self, V *args) {
  V v_n_24448 = args[0];
  V v_m_24447 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24449 = heff_tr(heff_call(v_m_24447, 1, (V[]){v_n_24448}));
  switch (heff_tag_of(v_x2_24449)) {
  case TAG_MkPair: {
    V v_x_24450 = heff_field(v_x2_24449, 0);
    V v_n_24451 = heff_field(v_x2_24449, 1);
    V v_ru_24x2_24449_24MkPair = heff_take_reuse_n(v_x2_24449, 3ULL, 2);
    V v_t_24454;
    switch (heff_tag_of(v_x_24450)) {
    case TAG_MkPair: {
      V v_x_24452 = heff_dup(heff_field(v_x_24450, 0));
      v_t_24454 = v_x_24452;
      break;
    }
    default: heff_nomatch(v_x_24450);
    }
    V v_o_24457;
    switch (heff_tag_of(v_x_24450)) {
    case TAG_MkPair: {
      V v_y_24456 = heff_field(v_x_24450, 1);
      heff_take_n(v_x_24450, 2ULL, 2);
      v_o_24457 = v_y_24456;
      break;
    }
    default: heff_nomatch(v_x_24450);
    }
    V v_t_24461;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24458 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24461 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24458, v_o_24457});
      break;
    }
    case TAG_DLet: {
      V v_x_24459 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24461 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24459, v_o_24457});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24461 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str32), v_o_24457});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24461, NTAG(TAG_Nil)});
    V v_x_24463 = (g_prelude_2e_2b_2b(v_t_24454, v_t_24462));
    return heff_tag_at_n(v_ru_24x2_24449_24MkPair, TAG_MkPair, 2, (V[]){v_x_24463, v_n_24451});
  }
  default: return heff_nomatch(v_x2_24449);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam25(V self, V *args) {
  V v_n_24466 = args[0];
  V v_m_24465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24467 = heff_tr(heff_call(v_m_24465, 1, (V[]){v_n_24466}));
  switch (heff_tag_of(v_x2_24467)) {
  case TAG_MkPair: {
    V v_x_24468 = heff_field(v_x2_24467, 0);
    V v_n_24469 = heff_field(v_x2_24467, 1);
    V v_ru_24x2_24467_24MkPair = heff_take_reuse_n(v_x2_24467, 3ULL, 2);
    V v_t_24472;
    switch (heff_tag_of(v_x_24468)) {
    case TAG_MkPair: {
      V v_x_24470 = heff_dup(heff_field(v_x_24468, 0));
      v_t_24472 = v_x_24470;
      break;
    }
    default: heff_nomatch(v_x_24468);
    }
    V v_t_24473 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str33), heff_intShow(heff_dup(v_n_24469)));
    V v_t_24476;
    switch (heff_tag_of(v_x_24468)) {
    case TAG_MkPair: {
      V v_y_24475 = heff_field(v_x_24468, 1);
      heff_take_n(v_x_24468, 2ULL, 2);
      v_t_24476 = v_y_24475;
      break;
    }
    default: heff_nomatch(v_x_24468);
    }
    V v_t_24477 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str34), v_t_24473), v_t_24476});
    V v_t_24478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24477, NTAG(TAG_Nil)});
    V v_x_24479 = (g_prelude_2e_2b_2b(v_t_24472, v_t_24478));
    return heff_tag_at_n(v_ru_24x2_24467_24MkPair, TAG_MkPair, 2, (V[]){v_x_24479, heff_intAdd(v_n_24469, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24467);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam26(V self, V *args) {
  V v_n_24484 = args[0];
  V v_m_24483 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24485 = heff_tr(heff_call(v_m_24483, 1, (V[]){v_n_24484}));
  switch (heff_tag_of(v_x2_24485)) {
  case TAG_MkPair: {
    V v_x_24486 = heff_field(v_x2_24485, 0);
    V v_n_24487 = heff_field(v_x2_24485, 1);
    V v_ru_24x2_24485_24MkPair = heff_take_reuse_n(v_x2_24485, 3ULL, 2);
    V v_t_24490;
    switch (heff_tag_of(v_x_24486)) {
    case TAG_MkPair: {
      V v_x_24488 = heff_dup(heff_field(v_x_24486, 0));
      v_t_24490 = v_x_24488;
      break;
    }
    default: heff_nomatch(v_x_24486);
    }
    V v_o_24493;
    switch (heff_tag_of(v_x_24486)) {
    case TAG_MkPair: {
      V v_y_24492 = heff_field(v_x_24486, 1);
      heff_take_n(v_x_24486, 2ULL, 2);
      v_o_24493 = v_y_24492;
      break;
    }
    default: heff_nomatch(v_x_24486);
    }
    V v_t_24497;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24494 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24497 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24494, v_o_24493});
      break;
    }
    case TAG_DLet: {
      V v_x_24495 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24497 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24495, v_o_24493});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24497 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str35), v_o_24493});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24498 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24497, NTAG(TAG_Nil)});
    V v_x_24499 = (g_prelude_2e_2b_2b(v_t_24490, v_t_24498));
    return heff_tag_at_n(v_ru_24x2_24485_24MkPair, TAG_MkPair, 2, (V[]){v_x_24499, v_n_24487});
  }
  default: return heff_nomatch(v_x2_24485);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam27(V self, V *args) {
  V v_n_24502 = args[0];
  V v_m_24501 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24503 = heff_tr(heff_call(v_m_24501, 1, (V[]){v_n_24502}));
  switch (heff_tag_of(v_x2_24503)) {
  case TAG_MkPair: {
    V v_x_24504 = heff_field(v_x2_24503, 0);
    V v_n_24505 = heff_field(v_x2_24503, 1);
    V v_ru_24x2_24503_24MkPair = heff_take_reuse_n(v_x2_24503, 3ULL, 2);
    V v_t_24508;
    switch (heff_tag_of(v_x_24504)) {
    case TAG_MkPair: {
      V v_x_24506 = heff_dup(heff_field(v_x_24504, 0));
      v_t_24508 = v_x_24506;
      break;
    }
    default: heff_nomatch(v_x_24504);
    }
    V v_o_24511;
    switch (heff_tag_of(v_x_24504)) {
    case TAG_MkPair: {
      V v_y_24510 = heff_field(v_x_24504, 1);
      heff_take_n(v_x_24504, 2ULL, 2);
      v_o_24511 = v_y_24510;
      break;
    }
    default: heff_nomatch(v_x_24504);
    }
    V v_t_24515;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24512 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24515 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24512, v_o_24511});
      break;
    }
    case TAG_DLet: {
      V v_x_24513 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24515 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24513, v_o_24511});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24515 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str36), v_o_24511});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24516 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24515, NTAG(TAG_Nil)});
    V v_x_24517 = (g_prelude_2e_2b_2b(v_t_24508, v_t_24516));
    return heff_tag_at_n(v_ru_24x2_24503_24MkPair, TAG_MkPair, 2, (V[]){v_x_24517, v_n_24505});
  }
  default: return heff_nomatch(v_x2_24503);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam28(V self, V *args) {
  V v_n_24520 = args[0];
  V v_m_24519 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24521 = heff_tr(heff_call(v_m_24519, 1, (V[]){v_n_24520}));
  switch (heff_tag_of(v_x2_24521)) {
  case TAG_MkPair: {
    V v_x_24522 = heff_field(v_x2_24521, 0);
    V v_n_24523 = heff_field(v_x2_24521, 1);
    V v_ru_24x2_24521_24MkPair = heff_take_reuse_n(v_x2_24521, 3ULL, 2);
    V v_t_24526;
    switch (heff_tag_of(v_x_24522)) {
    case TAG_MkPair: {
      V v_x_24524 = heff_dup(heff_field(v_x_24522, 0));
      v_t_24526 = v_x_24524;
      break;
    }
    default: heff_nomatch(v_x_24522);
    }
    V v_t_24527 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str37), heff_intShow(heff_dup(v_n_24523)));
    V v_t_24530;
    switch (heff_tag_of(v_x_24522)) {
    case TAG_MkPair: {
      V v_y_24529 = heff_field(v_x_24522, 1);
      heff_take_n(v_x_24522, 2ULL, 2);
      v_t_24530 = v_y_24529;
      break;
    }
    default: heff_nomatch(v_x_24522);
    }
    V v_t_24531 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str38), v_t_24527), v_t_24530});
    V v_t_24532 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24531, NTAG(TAG_Nil)});
    V v_x_24533 = (g_prelude_2e_2b_2b(v_t_24526, v_t_24532));
    return heff_tag_at_n(v_ru_24x2_24521_24MkPair, TAG_MkPair, 2, (V[]){v_x_24533, heff_intAdd(v_n_24523, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24521);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam29(V self, V *args) {
  V v_n_24538 = args[0];
  V v_m_24537 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24539 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_n_24538}));
  switch (heff_tag_of(v_x2_24539)) {
  case TAG_MkPair: {
    V v_x_24540 = heff_field(v_x2_24539, 0);
    V v_n_24541 = heff_field(v_x2_24539, 1);
    V v_ru_24x2_24539_24MkPair = heff_take_reuse_n(v_x2_24539, 3ULL, 2);
    V v_t_24544;
    switch (heff_tag_of(v_x_24540)) {
    case TAG_MkPair: {
      V v_x_24542 = heff_dup(heff_field(v_x_24540, 0));
      v_t_24544 = v_x_24542;
      break;
    }
    default: heff_nomatch(v_x_24540);
    }
    V v_o_24547;
    switch (heff_tag_of(v_x_24540)) {
    case TAG_MkPair: {
      V v_y_24546 = heff_field(v_x_24540, 1);
      heff_take_n(v_x_24540, 2ULL, 2);
      v_o_24547 = v_y_24546;
      break;
    }
    default: heff_nomatch(v_x_24540);
    }
    V v_t_24551;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24548 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24551 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24548, v_o_24547});
      break;
    }
    case TAG_DLet: {
      V v_x_24549 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24551 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24549, v_o_24547});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24551 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str39), v_o_24547});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24552 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24551, NTAG(TAG_Nil)});
    V v_x_24553 = (g_prelude_2e_2b_2b(v_t_24544, v_t_24552));
    return heff_tag_at_n(v_ru_24x2_24539_24MkPair, TAG_MkPair, 2, (V[]){v_x_24553, v_n_24541});
  }
  default: return heff_nomatch(v_x2_24539);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam30(V self, V *args) {
  V v_n_24556 = args[0];
  V v_m_24555 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24557 = heff_tr(heff_call(v_m_24555, 1, (V[]){v_n_24556}));
  switch (heff_tag_of(v_x2_24557)) {
  case TAG_MkPair: {
    V v_x_24558 = heff_field(v_x2_24557, 0);
    V v_n_24559 = heff_field(v_x2_24557, 1);
    V v_ru_24x2_24557_24MkPair = heff_take_reuse_n(v_x2_24557, 3ULL, 2);
    V v_t_24562;
    switch (heff_tag_of(v_x_24558)) {
    case TAG_MkPair: {
      V v_x_24560 = heff_dup(heff_field(v_x_24558, 0));
      v_t_24562 = v_x_24560;
      break;
    }
    default: heff_nomatch(v_x_24558);
    }
    V v_o_24565;
    switch (heff_tag_of(v_x_24558)) {
    case TAG_MkPair: {
      V v_y_24564 = heff_field(v_x_24558, 1);
      heff_take_n(v_x_24558, 2ULL, 2);
      v_o_24565 = v_y_24564;
      break;
    }
    default: heff_nomatch(v_x_24558);
    }
    V v_t_24569;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24566 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24569 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24566, v_o_24565});
      break;
    }
    case TAG_DLet: {
      V v_x_24567 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24569 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24567, v_o_24565});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24569 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str40), v_o_24565});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24570 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24569, NTAG(TAG_Nil)});
    V v_x_24571 = (g_prelude_2e_2b_2b(v_t_24562, v_t_24570));
    return heff_tag_at_n(v_ru_24x2_24557_24MkPair, TAG_MkPair, 2, (V[]){v_x_24571, v_n_24559});
  }
  default: return heff_nomatch(v_x2_24557);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam31(V self, V *args) {
  V v_n_24574 = args[0];
  V v_m_24573 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24575 = heff_tr(heff_call(v_m_24573, 1, (V[]){v_n_24574}));
  switch (heff_tag_of(v_x2_24575)) {
  case TAG_MkPair: {
    V v_x_24576 = heff_field(v_x2_24575, 0);
    V v_n_24577 = heff_field(v_x2_24575, 1);
    V v_ru_24x2_24575_24MkPair = heff_take_reuse_n(v_x2_24575, 3ULL, 2);
    V v_t_24580;
    switch (heff_tag_of(v_x_24576)) {
    case TAG_MkPair: {
      V v_x_24578 = heff_dup(heff_field(v_x_24576, 0));
      v_t_24580 = v_x_24578;
      break;
    }
    default: heff_nomatch(v_x_24576);
    }
    V v_t_24581 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str41), heff_intShow(heff_dup(v_n_24577)));
    V v_t_24584;
    switch (heff_tag_of(v_x_24576)) {
    case TAG_MkPair: {
      V v_y_24583 = heff_field(v_x_24576, 1);
      heff_take_n(v_x_24576, 2ULL, 2);
      v_t_24584 = v_y_24583;
      break;
    }
    default: heff_nomatch(v_x_24576);
    }
    V v_t_24585 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str42), v_t_24581), v_t_24584});
    V v_t_24586 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24585, NTAG(TAG_Nil)});
    V v_x_24587 = (g_prelude_2e_2b_2b(v_t_24580, v_t_24586));
    return heff_tag_at_n(v_ru_24x2_24575_24MkPair, TAG_MkPair, 2, (V[]){v_x_24587, heff_intAdd(v_n_24577, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24575);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam32(V self, V *args) {
  V v_n_24591 = args[0];
  V v_m_24590 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24592 = heff_tr(heff_call(v_m_24590, 1, (V[]){v_n_24591}));
  switch (heff_tag_of(v_x2_24592)) {
  case TAG_MkPair: {
    V v_x_24593 = heff_field(v_x2_24592, 0);
    V v_n_24594 = heff_field(v_x2_24592, 1);
    V v_ru_24x2_24592_24MkPair = heff_take_reuse_n(v_x2_24592, 3ULL, 2);
    V v_t_24597;
    switch (heff_tag_of(v_x_24593)) {
    case TAG_MkPair: {
      V v_x_24595 = heff_dup(heff_field(v_x_24593, 0));
      v_t_24597 = v_x_24595;
      break;
    }
    default: heff_nomatch(v_x_24593);
    }
    V v_o_24600;
    switch (heff_tag_of(v_x_24593)) {
    case TAG_MkPair: {
      V v_y_24599 = heff_field(v_x_24593, 1);
      heff_take_n(v_x_24593, 2ULL, 2);
      v_o_24600 = v_y_24599;
      break;
    }
    default: heff_nomatch(v_x_24593);
    }
    V v_t_24604;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24601 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24604 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24601, v_o_24600});
      break;
    }
    case TAG_DLet: {
      V v_x_24602 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24604 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24602, v_o_24600});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24604 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str43), v_o_24600});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24605 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24604, NTAG(TAG_Nil)});
    V v_x_24606 = (g_prelude_2e_2b_2b(v_t_24597, v_t_24605));
    return heff_tag_at_n(v_ru_24x2_24592_24MkPair, TAG_MkPair, 2, (V[]){v_x_24606, v_n_24594});
  }
  default: return heff_nomatch(v_x2_24592);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam33(V self, V *args) {
  V v_n_24609 = args[0];
  V v_m_24608 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24610 = heff_tr(heff_call(v_m_24608, 1, (V[]){v_n_24609}));
  switch (heff_tag_of(v_x2_24610)) {
  case TAG_MkPair: {
    V v_x_24611 = heff_field(v_x2_24610, 0);
    V v_n_24612 = heff_field(v_x2_24610, 1);
    V v_ru_24x2_24610_24MkPair = heff_take_reuse_n(v_x2_24610, 3ULL, 2);
    V v_t_24615;
    switch (heff_tag_of(v_x_24611)) {
    case TAG_MkPair: {
      V v_x_24613 = heff_dup(heff_field(v_x_24611, 0));
      v_t_24615 = v_x_24613;
      break;
    }
    default: heff_nomatch(v_x_24611);
    }
    V v_o_24618;
    switch (heff_tag_of(v_x_24611)) {
    case TAG_MkPair: {
      V v_y_24617 = heff_field(v_x_24611, 1);
      heff_take_n(v_x_24611, 2ULL, 2);
      v_o_24618 = v_y_24617;
      break;
    }
    default: heff_nomatch(v_x_24611);
    }
    V v_t_24622;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24619 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24622 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24619, v_o_24618});
      break;
    }
    case TAG_DLet: {
      V v_x_24620 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24622 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24620, v_o_24618});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24622 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str44), v_o_24618});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24623 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24622, NTAG(TAG_Nil)});
    V v_x_24624 = (g_prelude_2e_2b_2b(v_t_24615, v_t_24623));
    return heff_tag_at_n(v_ru_24x2_24610_24MkPair, TAG_MkPair, 2, (V[]){v_x_24624, v_n_24612});
  }
  default: return heff_nomatch(v_x2_24610);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam34(V self, V *args) {
  V v_n_24627 = args[0];
  V v_m_24626 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24628 = heff_tr(heff_call(v_m_24626, 1, (V[]){v_n_24627}));
  switch (heff_tag_of(v_x2_24628)) {
  case TAG_MkPair: {
    V v_x_24629 = heff_field(v_x2_24628, 0);
    V v_n_24630 = heff_field(v_x2_24628, 1);
    V v_ru_24x2_24628_24MkPair = heff_take_reuse_n(v_x2_24628, 3ULL, 2);
    V v_t_24633;
    switch (heff_tag_of(v_x_24629)) {
    case TAG_MkPair: {
      V v_x_24631 = heff_dup(heff_field(v_x_24629, 0));
      v_t_24633 = v_x_24631;
      break;
    }
    default: heff_nomatch(v_x_24629);
    }
    V v_t_24634 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str45), heff_intShow(heff_dup(v_n_24630)));
    V v_t_24637;
    switch (heff_tag_of(v_x_24629)) {
    case TAG_MkPair: {
      V v_y_24636 = heff_field(v_x_24629, 1);
      heff_take_n(v_x_24629, 2ULL, 2);
      v_t_24637 = v_y_24636;
      break;
    }
    default: heff_nomatch(v_x_24629);
    }
    V v_t_24638 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str46), v_t_24634), v_t_24637});
    V v_t_24639 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24638, NTAG(TAG_Nil)});
    V v_x_24640 = (g_prelude_2e_2b_2b(v_t_24633, v_t_24639));
    return heff_tag_at_n(v_ru_24x2_24628_24MkPair, TAG_MkPair, 2, (V[]){v_x_24640, heff_intAdd(v_n_24630, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24628);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam35(V self, V *args) {
  V v_n_24644 = args[0];
  V v_m_24643 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24645 = heff_tr(heff_call(v_m_24643, 1, (V[]){v_n_24644}));
  switch (heff_tag_of(v_x2_24645)) {
  case TAG_MkPair: {
    V v_x_24646 = heff_field(v_x2_24645, 0);
    V v_n_24647 = heff_field(v_x2_24645, 1);
    V v_ru_24x2_24645_24MkPair = heff_take_reuse_n(v_x2_24645, 3ULL, 2);
    V v_t_24650;
    switch (heff_tag_of(v_x_24646)) {
    case TAG_MkPair: {
      V v_x_24648 = heff_dup(heff_field(v_x_24646, 0));
      v_t_24650 = v_x_24648;
      break;
    }
    default: heff_nomatch(v_x_24646);
    }
    V v_o_24653;
    switch (heff_tag_of(v_x_24646)) {
    case TAG_MkPair: {
      V v_y_24652 = heff_field(v_x_24646, 1);
      heff_take_n(v_x_24646, 2ULL, 2);
      v_o_24653 = v_y_24652;
      break;
    }
    default: heff_nomatch(v_x_24646);
    }
    V v_t_24657;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24654 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24657 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24654, v_o_24653});
      break;
    }
    case TAG_DLet: {
      V v_x_24655 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24657 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24655, v_o_24653});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24657 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str47), v_o_24653});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24658 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24657, NTAG(TAG_Nil)});
    V v_x_24659 = (g_prelude_2e_2b_2b(v_t_24650, v_t_24658));
    return heff_tag_at_n(v_ru_24x2_24645_24MkPair, TAG_MkPair, 2, (V[]){v_x_24659, v_n_24647});
  }
  default: return heff_nomatch(v_x2_24645);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam36(V self, V *args) {
  V v_n_24662 = args[0];
  V v_m_24661 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24663 = heff_tr(heff_call(v_m_24661, 1, (V[]){v_n_24662}));
  switch (heff_tag_of(v_x2_24663)) {
  case TAG_MkPair: {
    V v_x_24664 = heff_field(v_x2_24663, 0);
    V v_n_24665 = heff_field(v_x2_24663, 1);
    V v_ru_24x2_24663_24MkPair = heff_take_reuse_n(v_x2_24663, 3ULL, 2);
    V v_t_24668;
    switch (heff_tag_of(v_x_24664)) {
    case TAG_MkPair: {
      V v_x_24666 = heff_dup(heff_field(v_x_24664, 0));
      v_t_24668 = v_x_24666;
      break;
    }
    default: heff_nomatch(v_x_24664);
    }
    V v_o_24671;
    switch (heff_tag_of(v_x_24664)) {
    case TAG_MkPair: {
      V v_y_24670 = heff_field(v_x_24664, 1);
      heff_take_n(v_x_24664, 2ULL, 2);
      v_o_24671 = v_y_24670;
      break;
    }
    default: heff_nomatch(v_x_24664);
    }
    V v_t_24675;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24672 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24675 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24672, v_o_24671});
      break;
    }
    case TAG_DLet: {
      V v_x_24673 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24675 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24673, v_o_24671});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24675 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str48), v_o_24671});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24676 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24675, NTAG(TAG_Nil)});
    V v_x_24677 = (g_prelude_2e_2b_2b(v_t_24668, v_t_24676));
    return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){v_x_24677, v_n_24665});
  }
  default: return heff_nomatch(v_x2_24663);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam37(V self, V *args) {
  V v_n_24680 = args[0];
  V v_m_24679 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24681 = heff_tr(heff_call(v_m_24679, 1, (V[]){v_n_24680}));
  switch (heff_tag_of(v_x2_24681)) {
  case TAG_MkPair: {
    V v_x_24682 = heff_field(v_x2_24681, 0);
    V v_n_24683 = heff_field(v_x2_24681, 1);
    V v_ru_24x2_24681_24MkPair = heff_take_reuse_n(v_x2_24681, 3ULL, 2);
    V v_t_24686;
    switch (heff_tag_of(v_x_24682)) {
    case TAG_MkPair: {
      V v_x_24684 = heff_dup(heff_field(v_x_24682, 0));
      v_t_24686 = v_x_24684;
      break;
    }
    default: heff_nomatch(v_x_24682);
    }
    V v_t_24687 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str49), heff_intShow(heff_dup(v_n_24683)));
    V v_t_24690;
    switch (heff_tag_of(v_x_24682)) {
    case TAG_MkPair: {
      V v_y_24689 = heff_field(v_x_24682, 1);
      heff_take_n(v_x_24682, 2ULL, 2);
      v_t_24690 = v_y_24689;
      break;
    }
    default: heff_nomatch(v_x_24682);
    }
    V v_t_24691 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str50), v_t_24687), v_t_24690});
    V v_t_24692 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24691, NTAG(TAG_Nil)});
    V v_x_24693 = (g_prelude_2e_2b_2b(v_t_24686, v_t_24692));
    return heff_tag_at_n(v_ru_24x2_24681_24MkPair, TAG_MkPair, 2, (V[]){v_x_24693, heff_intAdd(v_n_24683, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24681);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam38(V self, V *args) {
  V v_n_24697 = args[0];
  V v_m_24696 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24698 = heff_tr(heff_call(v_m_24696, 1, (V[]){v_n_24697}));
  switch (heff_tag_of(v_x2_24698)) {
  case TAG_MkPair: {
    V v_x_24699 = heff_field(v_x2_24698, 0);
    V v_n_24700 = heff_field(v_x2_24698, 1);
    V v_ru_24x2_24698_24MkPair = heff_take_reuse_n(v_x2_24698, 3ULL, 2);
    V v_t_24703;
    switch (heff_tag_of(v_x_24699)) {
    case TAG_MkPair: {
      V v_x_24701 = heff_dup(heff_field(v_x_24699, 0));
      v_t_24703 = v_x_24701;
      break;
    }
    default: heff_nomatch(v_x_24699);
    }
    V v_o_24706;
    switch (heff_tag_of(v_x_24699)) {
    case TAG_MkPair: {
      V v_y_24705 = heff_field(v_x_24699, 1);
      heff_take_n(v_x_24699, 2ULL, 2);
      v_o_24706 = v_y_24705;
      break;
    }
    default: heff_nomatch(v_x_24699);
    }
    V v_t_24710;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24707 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24710 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24707, v_o_24706});
      break;
    }
    case TAG_DLet: {
      V v_x_24708 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24710 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24708, v_o_24706});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24710 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str51), v_o_24706});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24711 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24710, NTAG(TAG_Nil)});
    V v_x_24712 = (g_prelude_2e_2b_2b(v_t_24703, v_t_24711));
    return heff_tag_at_n(v_ru_24x2_24698_24MkPair, TAG_MkPair, 2, (V[]){v_x_24712, v_n_24700});
  }
  default: return heff_nomatch(v_x2_24698);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam39(V self, V *args) {
  V v_n_24715 = args[0];
  V v_m_24714 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24716 = heff_tr(heff_call(v_m_24714, 1, (V[]){v_n_24715}));
  switch (heff_tag_of(v_x2_24716)) {
  case TAG_MkPair: {
    V v_x_24717 = heff_field(v_x2_24716, 0);
    V v_n_24718 = heff_field(v_x2_24716, 1);
    V v_ru_24x2_24716_24MkPair = heff_take_reuse_n(v_x2_24716, 3ULL, 2);
    V v_t_24721;
    switch (heff_tag_of(v_x_24717)) {
    case TAG_MkPair: {
      V v_x_24719 = heff_dup(heff_field(v_x_24717, 0));
      v_t_24721 = v_x_24719;
      break;
    }
    default: heff_nomatch(v_x_24717);
    }
    V v_o_24724;
    switch (heff_tag_of(v_x_24717)) {
    case TAG_MkPair: {
      V v_y_24723 = heff_field(v_x_24717, 1);
      heff_take_n(v_x_24717, 2ULL, 2);
      v_o_24724 = v_y_24723;
      break;
    }
    default: heff_nomatch(v_x_24717);
    }
    V v_t_24728;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24725 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24728 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24725, v_o_24724});
      break;
    }
    case TAG_DLet: {
      V v_x_24726 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24728 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24726, v_o_24724});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24728 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str52), v_o_24724});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24729 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24728, NTAG(TAG_Nil)});
    V v_x_24730 = (g_prelude_2e_2b_2b(v_t_24721, v_t_24729));
    return heff_tag_at_n(v_ru_24x2_24716_24MkPair, TAG_MkPair, 2, (V[]){v_x_24730, v_n_24718});
  }
  default: return heff_nomatch(v_x2_24716);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam40(V self, V *args) {
  V v_n_24733 = args[0];
  V v_m_24732 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24734 = heff_tr(heff_call(v_m_24732, 1, (V[]){v_n_24733}));
  switch (heff_tag_of(v_x2_24734)) {
  case TAG_MkPair: {
    V v_x_24735 = heff_field(v_x2_24734, 0);
    V v_n_24736 = heff_field(v_x2_24734, 1);
    V v_ru_24x2_24734_24MkPair = heff_take_reuse_n(v_x2_24734, 3ULL, 2);
    V v_t_24739;
    switch (heff_tag_of(v_x_24735)) {
    case TAG_MkPair: {
      V v_x_24737 = heff_dup(heff_field(v_x_24735, 0));
      v_t_24739 = v_x_24737;
      break;
    }
    default: heff_nomatch(v_x_24735);
    }
    V v_t_24740 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str53), heff_intShow(heff_dup(v_n_24736)));
    V v_t_24743;
    switch (heff_tag_of(v_x_24735)) {
    case TAG_MkPair: {
      V v_y_24742 = heff_field(v_x_24735, 1);
      heff_take_n(v_x_24735, 2ULL, 2);
      v_t_24743 = v_y_24742;
      break;
    }
    default: heff_nomatch(v_x_24735);
    }
    V v_t_24744 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str54), v_t_24740), v_t_24743});
    V v_t_24745 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24744, NTAG(TAG_Nil)});
    V v_x_24746 = (g_prelude_2e_2b_2b(v_t_24739, v_t_24745));
    return heff_tag_at_n(v_ru_24x2_24734_24MkPair, TAG_MkPair, 2, (V[]){v_x_24746, heff_intAdd(v_n_24736, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24734);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam41(V self, V *args) {
  V v_n_24750 = args[0];
  V v_m_24749 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24751 = heff_tr(heff_call(v_m_24749, 1, (V[]){v_n_24750}));
  switch (heff_tag_of(v_x2_24751)) {
  case TAG_MkPair: {
    V v_x_24752 = heff_field(v_x2_24751, 0);
    V v_n_24753 = heff_field(v_x2_24751, 1);
    V v_ru_24x2_24751_24MkPair = heff_take_reuse_n(v_x2_24751, 3ULL, 2);
    V v_t_24756;
    switch (heff_tag_of(v_x_24752)) {
    case TAG_MkPair: {
      V v_x_24754 = heff_dup(heff_field(v_x_24752, 0));
      v_t_24756 = v_x_24754;
      break;
    }
    default: heff_nomatch(v_x_24752);
    }
    V v_o_24759;
    switch (heff_tag_of(v_x_24752)) {
    case TAG_MkPair: {
      V v_y_24758 = heff_field(v_x_24752, 1);
      heff_take_n(v_x_24752, 2ULL, 2);
      v_o_24759 = v_y_24758;
      break;
    }
    default: heff_nomatch(v_x_24752);
    }
    V v_t_24763;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24760 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24763 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24760, v_o_24759});
      break;
    }
    case TAG_DLet: {
      V v_x_24761 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24763 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24761, v_o_24759});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24763 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str55), v_o_24759});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24764 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24763, NTAG(TAG_Nil)});
    V v_x_24765 = (g_prelude_2e_2b_2b(v_t_24756, v_t_24764));
    return heff_tag_at_n(v_ru_24x2_24751_24MkPair, TAG_MkPair, 2, (V[]){v_x_24765, v_n_24753});
  }
  default: return heff_nomatch(v_x2_24751);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam42(V self, V *args) {
  V v_n_24768 = args[0];
  V v_m_24767 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24769 = heff_tr(heff_call(v_m_24767, 1, (V[]){v_n_24768}));
  switch (heff_tag_of(v_x2_24769)) {
  case TAG_MkPair: {
    V v_x_24770 = heff_field(v_x2_24769, 0);
    V v_n_24771 = heff_field(v_x2_24769, 1);
    V v_ru_24x2_24769_24MkPair = heff_take_reuse_n(v_x2_24769, 3ULL, 2);
    V v_t_24774;
    switch (heff_tag_of(v_x_24770)) {
    case TAG_MkPair: {
      V v_x_24772 = heff_dup(heff_field(v_x_24770, 0));
      v_t_24774 = v_x_24772;
      break;
    }
    default: heff_nomatch(v_x_24770);
    }
    V v_o_24777;
    switch (heff_tag_of(v_x_24770)) {
    case TAG_MkPair: {
      V v_y_24776 = heff_field(v_x_24770, 1);
      heff_take_n(v_x_24770, 2ULL, 2);
      v_o_24777 = v_y_24776;
      break;
    }
    default: heff_nomatch(v_x_24770);
    }
    V v_t_24781;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24778 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24781 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24778, v_o_24777});
      break;
    }
    case TAG_DLet: {
      V v_x_24779 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24781 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24779, v_o_24777});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24781 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str56), v_o_24777});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24782 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24781, NTAG(TAG_Nil)});
    V v_x_24783 = (g_prelude_2e_2b_2b(v_t_24774, v_t_24782));
    return heff_tag_at_n(v_ru_24x2_24769_24MkPair, TAG_MkPair, 2, (V[]){v_x_24783, v_n_24771});
  }
  default: return heff_nomatch(v_x2_24769);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam43(V self, V *args) {
  V v_n_24786 = args[0];
  V v_m_24785 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24787 = heff_tr(heff_call(v_m_24785, 1, (V[]){v_n_24786}));
  switch (heff_tag_of(v_x2_24787)) {
  case TAG_MkPair: {
    V v_x_24788 = heff_field(v_x2_24787, 0);
    V v_n_24789 = heff_field(v_x2_24787, 1);
    V v_ru_24x2_24787_24MkPair = heff_take_reuse_n(v_x2_24787, 3ULL, 2);
    V v_t_24792;
    switch (heff_tag_of(v_x_24788)) {
    case TAG_MkPair: {
      V v_x_24790 = heff_dup(heff_field(v_x_24788, 0));
      v_t_24792 = v_x_24790;
      break;
    }
    default: heff_nomatch(v_x_24788);
    }
    V v_t_24793 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str57), heff_intShow(heff_dup(v_n_24789)));
    V v_t_24796;
    switch (heff_tag_of(v_x_24788)) {
    case TAG_MkPair: {
      V v_y_24795 = heff_field(v_x_24788, 1);
      heff_take_n(v_x_24788, 2ULL, 2);
      v_t_24796 = v_y_24795;
      break;
    }
    default: heff_nomatch(v_x_24788);
    }
    V v_t_24797 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str58), v_t_24793), v_t_24796});
    V v_t_24798 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24797, NTAG(TAG_Nil)});
    V v_x_24799 = (g_prelude_2e_2b_2b(v_t_24792, v_t_24798));
    return heff_tag_at_n(v_ru_24x2_24787_24MkPair, TAG_MkPair, 2, (V[]){v_x_24799, heff_intAdd(v_n_24789, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24787);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam44(V self, V *args) {
  V v_n_24804 = args[0];
  V v_m_24803 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24805 = heff_tr(heff_call(v_m_24803, 1, (V[]){v_n_24804}));
  switch (heff_tag_of(v_x2_24805)) {
  case TAG_MkPair: {
    V v_x_24806 = heff_field(v_x2_24805, 0);
    V v_n_24807 = heff_field(v_x2_24805, 1);
    V v_ru_24x2_24805_24MkPair = heff_take_reuse_n(v_x2_24805, 3ULL, 2);
    V v_t_24810;
    switch (heff_tag_of(v_x_24806)) {
    case TAG_MkPair: {
      V v_x_24808 = heff_dup(heff_field(v_x_24806, 0));
      v_t_24810 = v_x_24808;
      break;
    }
    default: heff_nomatch(v_x_24806);
    }
    V v_o_24813;
    switch (heff_tag_of(v_x_24806)) {
    case TAG_MkPair: {
      V v_y_24812 = heff_field(v_x_24806, 1);
      heff_take_n(v_x_24806, 2ULL, 2);
      v_o_24813 = v_y_24812;
      break;
    }
    default: heff_nomatch(v_x_24806);
    }
    V v_t_24817;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24814 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24817 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24814, v_o_24813});
      break;
    }
    case TAG_DLet: {
      V v_x_24815 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24817 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24815, v_o_24813});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24817 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str59), v_o_24813});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24818 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24817, NTAG(TAG_Nil)});
    V v_x_24819 = (g_prelude_2e_2b_2b(v_t_24810, v_t_24818));
    return heff_tag_at_n(v_ru_24x2_24805_24MkPair, TAG_MkPair, 2, (V[]){v_x_24819, v_n_24807});
  }
  default: return heff_nomatch(v_x2_24805);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam45(V self, V *args) {
  V v_n_24822 = args[0];
  V v_m_24821 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24823 = heff_tr(heff_call(v_m_24821, 1, (V[]){v_n_24822}));
  switch (heff_tag_of(v_x2_24823)) {
  case TAG_MkPair: {
    V v_x_24824 = heff_field(v_x2_24823, 0);
    V v_n_24825 = heff_field(v_x2_24823, 1);
    V v_ru_24x2_24823_24MkPair = heff_take_reuse_n(v_x2_24823, 3ULL, 2);
    V v_t_24828;
    switch (heff_tag_of(v_x_24824)) {
    case TAG_MkPair: {
      V v_x_24826 = heff_dup(heff_field(v_x_24824, 0));
      v_t_24828 = v_x_24826;
      break;
    }
    default: heff_nomatch(v_x_24824);
    }
    V v_o_24831;
    switch (heff_tag_of(v_x_24824)) {
    case TAG_MkPair: {
      V v_y_24830 = heff_field(v_x_24824, 1);
      heff_take_n(v_x_24824, 2ULL, 2);
      v_o_24831 = v_y_24830;
      break;
    }
    default: heff_nomatch(v_x_24824);
    }
    V v_t_24835;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24832 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24835 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24832, v_o_24831});
      break;
    }
    case TAG_DLet: {
      V v_x_24833 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24835 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24833, v_o_24831});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24835 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str60), v_o_24831});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24836 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24835, NTAG(TAG_Nil)});
    V v_x_24837 = (g_prelude_2e_2b_2b(v_t_24828, v_t_24836));
    return heff_tag_at_n(v_ru_24x2_24823_24MkPair, TAG_MkPair, 2, (V[]){v_x_24837, v_n_24825});
  }
  default: return heff_nomatch(v_x2_24823);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam46(V self, V *args) {
  V v_n_24840 = args[0];
  V v_m_24839 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24841 = heff_tr(heff_call(v_m_24839, 1, (V[]){v_n_24840}));
  switch (heff_tag_of(v_x2_24841)) {
  case TAG_MkPair: {
    V v_x_24842 = heff_field(v_x2_24841, 0);
    V v_n_24843 = heff_field(v_x2_24841, 1);
    V v_ru_24x2_24841_24MkPair = heff_take_reuse_n(v_x2_24841, 3ULL, 2);
    V v_t_24846;
    switch (heff_tag_of(v_x_24842)) {
    case TAG_MkPair: {
      V v_x_24844 = heff_dup(heff_field(v_x_24842, 0));
      v_t_24846 = v_x_24844;
      break;
    }
    default: heff_nomatch(v_x_24842);
    }
    V v_t_24847 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str61), heff_intShow(heff_dup(v_n_24843)));
    V v_t_24850;
    switch (heff_tag_of(v_x_24842)) {
    case TAG_MkPair: {
      V v_y_24849 = heff_field(v_x_24842, 1);
      heff_take_n(v_x_24842, 2ULL, 2);
      v_t_24850 = v_y_24849;
      break;
    }
    default: heff_nomatch(v_x_24842);
    }
    V v_t_24851 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str62), v_t_24847), v_t_24850});
    V v_t_24852 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24851, NTAG(TAG_Nil)});
    V v_x_24853 = (g_prelude_2e_2b_2b(v_t_24846, v_t_24852));
    return heff_tag_at_n(v_ru_24x2_24841_24MkPair, TAG_MkPair, 2, (V[]){v_x_24853, heff_intAdd(v_n_24843, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24841);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam47(V self, V *args) {
  V v_n_24857 = args[0];
  V v_m_24856 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24858 = heff_tr(heff_call(v_m_24856, 1, (V[]){v_n_24857}));
  switch (heff_tag_of(v_x2_24858)) {
  case TAG_MkPair: {
    V v_x_24859 = heff_field(v_x2_24858, 0);
    V v_n_24860 = heff_field(v_x2_24858, 1);
    V v_ru_24x2_24858_24MkPair = heff_take_reuse_n(v_x2_24858, 3ULL, 2);
    V v_t_24863;
    switch (heff_tag_of(v_x_24859)) {
    case TAG_MkPair: {
      V v_x_24861 = heff_dup(heff_field(v_x_24859, 0));
      v_t_24863 = v_x_24861;
      break;
    }
    default: heff_nomatch(v_x_24859);
    }
    V v_o_24866;
    switch (heff_tag_of(v_x_24859)) {
    case TAG_MkPair: {
      V v_y_24865 = heff_field(v_x_24859, 1);
      heff_take_n(v_x_24859, 2ULL, 2);
      v_o_24866 = v_y_24865;
      break;
    }
    default: heff_nomatch(v_x_24859);
    }
    V v_t_24870;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24867 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24870 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24867, v_o_24866});
      break;
    }
    case TAG_DLet: {
      V v_x_24868 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24870 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24868, v_o_24866});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24870 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str63), v_o_24866});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24871 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24870, NTAG(TAG_Nil)});
    V v_x_24872 = (g_prelude_2e_2b_2b(v_t_24863, v_t_24871));
    return heff_tag_at_n(v_ru_24x2_24858_24MkPair, TAG_MkPair, 2, (V[]){v_x_24872, v_n_24860});
  }
  default: return heff_nomatch(v_x2_24858);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam48(V self, V *args) {
  V v_n_24875 = args[0];
  V v_m_24874 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24876 = heff_tr(heff_call(v_m_24874, 1, (V[]){v_n_24875}));
  switch (heff_tag_of(v_x2_24876)) {
  case TAG_MkPair: {
    V v_x_24877 = heff_field(v_x2_24876, 0);
    V v_n_24878 = heff_field(v_x2_24876, 1);
    V v_ru_24x2_24876_24MkPair = heff_take_reuse_n(v_x2_24876, 3ULL, 2);
    V v_t_24881;
    switch (heff_tag_of(v_x_24877)) {
    case TAG_MkPair: {
      V v_x_24879 = heff_dup(heff_field(v_x_24877, 0));
      v_t_24881 = v_x_24879;
      break;
    }
    default: heff_nomatch(v_x_24877);
    }
    V v_o_24884;
    switch (heff_tag_of(v_x_24877)) {
    case TAG_MkPair: {
      V v_y_24883 = heff_field(v_x_24877, 1);
      heff_take_n(v_x_24877, 2ULL, 2);
      v_o_24884 = v_y_24883;
      break;
    }
    default: heff_nomatch(v_x_24877);
    }
    V v_t_24888;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24885 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24888 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24885, v_o_24884});
      break;
    }
    case TAG_DLet: {
      V v_x_24886 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24888 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24886, v_o_24884});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24888 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str64), v_o_24884});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24889 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24888, NTAG(TAG_Nil)});
    V v_x_24890 = (g_prelude_2e_2b_2b(v_t_24881, v_t_24889));
    return heff_tag_at_n(v_ru_24x2_24876_24MkPair, TAG_MkPair, 2, (V[]){v_x_24890, v_n_24878});
  }
  default: return heff_nomatch(v_x2_24876);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam49(V self, V *args) {
  V v_n_24893 = args[0];
  V v_m_24892 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24894 = heff_tr(heff_call(v_m_24892, 1, (V[]){v_n_24893}));
  switch (heff_tag_of(v_x2_24894)) {
  case TAG_MkPair: {
    V v_x_24895 = heff_field(v_x2_24894, 0);
    V v_n_24896 = heff_field(v_x2_24894, 1);
    V v_ru_24x2_24894_24MkPair = heff_take_reuse_n(v_x2_24894, 3ULL, 2);
    V v_t_24899;
    switch (heff_tag_of(v_x_24895)) {
    case TAG_MkPair: {
      V v_x_24897 = heff_dup(heff_field(v_x_24895, 0));
      v_t_24899 = v_x_24897;
      break;
    }
    default: heff_nomatch(v_x_24895);
    }
    V v_t_24900 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str65), heff_intShow(heff_dup(v_n_24896)));
    V v_t_24903;
    switch (heff_tag_of(v_x_24895)) {
    case TAG_MkPair: {
      V v_y_24902 = heff_field(v_x_24895, 1);
      heff_take_n(v_x_24895, 2ULL, 2);
      v_t_24903 = v_y_24902;
      break;
    }
    default: heff_nomatch(v_x_24895);
    }
    V v_t_24904 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str66), v_t_24900), v_t_24903});
    V v_t_24905 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24904, NTAG(TAG_Nil)});
    V v_x_24906 = (g_prelude_2e_2b_2b(v_t_24899, v_t_24905));
    return heff_tag_at_n(v_ru_24x2_24894_24MkPair, TAG_MkPair, 2, (V[]){v_x_24906, heff_intAdd(v_n_24896, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24894);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam50(V self, V *args) {
  V v_n_24909 = args[0];
  V v_m_24908 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24910 = heff_tr(heff_call(v_m_24908, 1, (V[]){v_n_24909}));
  switch (heff_tag_of(v_x2_24910)) {
  case TAG_MkPair: {
    V v_x_24911 = heff_field(v_x2_24910, 0);
    V v_n_24912 = heff_field(v_x2_24910, 1);
    V v_ru_24x2_24910_24MkPair = heff_take_reuse_n(v_x2_24910, 3ULL, 2);
    V v_t_24915;
    switch (heff_tag_of(v_x_24911)) {
    case TAG_MkPair: {
      V v_x_24913 = heff_dup(heff_field(v_x_24911, 0));
      v_t_24915 = v_x_24913;
      break;
    }
    default: heff_nomatch(v_x_24911);
    }
    V v_o_24918;
    switch (heff_tag_of(v_x_24911)) {
    case TAG_MkPair: {
      V v_y_24917 = heff_field(v_x_24911, 1);
      heff_take_n(v_x_24911, 2ULL, 2);
      v_o_24918 = v_y_24917;
      break;
    }
    default: heff_nomatch(v_x_24911);
    }
    V v_t_24922;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24919 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24922 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24919, v_o_24918});
      break;
    }
    case TAG_DLet: {
      V v_x_24920 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24922 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24920, v_o_24918});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24922 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str67), v_o_24918});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24923 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24922, NTAG(TAG_Nil)});
    V v_x_24924 = (g_prelude_2e_2b_2b(v_t_24915, v_t_24923));
    return heff_tag_at_n(v_ru_24x2_24910_24MkPair, TAG_MkPair, 2, (V[]){v_x_24924, v_n_24912});
  }
  default: return heff_nomatch(v_x2_24910);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam51(V self, V *args) {
  V v_n_24927 = args[0];
  V v_m_24926 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24928 = heff_tr(heff_call(v_m_24926, 1, (V[]){v_n_24927}));
  switch (heff_tag_of(v_x2_24928)) {
  case TAG_MkPair: {
    V v_x_24929 = heff_field(v_x2_24928, 0);
    V v_n_24930 = heff_field(v_x2_24928, 1);
    V v_ru_24x2_24928_24MkPair = heff_take_reuse_n(v_x2_24928, 3ULL, 2);
    V v_t_24933;
    switch (heff_tag_of(v_x_24929)) {
    case TAG_MkPair: {
      V v_x_24931 = heff_dup(heff_field(v_x_24929, 0));
      v_t_24933 = v_x_24931;
      break;
    }
    default: heff_nomatch(v_x_24929);
    }
    V v_o_24936;
    switch (heff_tag_of(v_x_24929)) {
    case TAG_MkPair: {
      V v_y_24935 = heff_field(v_x_24929, 1);
      heff_take_n(v_x_24929, 2ULL, 2);
      v_o_24936 = v_y_24935;
      break;
    }
    default: heff_nomatch(v_x_24929);
    }
    V v_t_24940;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24937 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24940 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24937, v_o_24936});
      break;
    }
    case TAG_DLet: {
      V v_x_24938 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24940 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24938, v_o_24936});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24940 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str68), v_o_24936});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24941 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24940, NTAG(TAG_Nil)});
    V v_x_24942 = (g_prelude_2e_2b_2b(v_t_24933, v_t_24941));
    return heff_tag_at_n(v_ru_24x2_24928_24MkPair, TAG_MkPair, 2, (V[]){v_x_24942, v_n_24930});
  }
  default: return heff_nomatch(v_x2_24928);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam52(V self, V *args) {
  V v_n_24945 = args[0];
  V v_m_24944 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24946 = heff_tr(heff_call(v_m_24944, 1, (V[]){v_n_24945}));
  switch (heff_tag_of(v_x2_24946)) {
  case TAG_MkPair: {
    V v_x_24947 = heff_field(v_x2_24946, 0);
    V v_n_24948 = heff_field(v_x2_24946, 1);
    V v_ru_24x2_24946_24MkPair = heff_take_reuse_n(v_x2_24946, 3ULL, 2);
    V v_t_24951;
    switch (heff_tag_of(v_x_24947)) {
    case TAG_MkPair: {
      V v_x_24949 = heff_dup(heff_field(v_x_24947, 0));
      v_t_24951 = v_x_24949;
      break;
    }
    default: heff_nomatch(v_x_24947);
    }
    V v_t_24952 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str69), heff_intShow(heff_dup(v_n_24948)));
    V v_t_24955;
    switch (heff_tag_of(v_x_24947)) {
    case TAG_MkPair: {
      V v_y_24954 = heff_field(v_x_24947, 1);
      heff_take_n(v_x_24947, 2ULL, 2);
      v_t_24955 = v_y_24954;
      break;
    }
    default: heff_nomatch(v_x_24947);
    }
    V v_t_24956 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str70), v_t_24952), v_t_24955});
    V v_t_24957 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24956, NTAG(TAG_Nil)});
    V v_x_24958 = (g_prelude_2e_2b_2b(v_t_24951, v_t_24957));
    return heff_tag_at_n(v_ru_24x2_24946_24MkPair, TAG_MkPair, 2, (V[]){v_x_24958, heff_intAdd(v_n_24948, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24946);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam53(V self, V *args) {
  V v_n_24961 = args[0];
  V v_m_24960 = heff_env(self)[0];
  V v_c_24959 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24962 = heff_tr(heff_call(v_m_24960, 1, (V[]){v_n_24961}));
  switch (heff_tag_of(v_x2_24962)) {
  case TAG_MkPair: {
    V v_x_24963 = heff_field(v_x2_24962, 0);
    V v_n_24964 = heff_field(v_x2_24962, 1);
    V v_ru_24x2_24962_24MkPair = heff_take_reuse_n(v_x2_24962, 3ULL, 2);
    switch (heff_tag_of(v_x_24963)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_24962_24MkPair, 2);
      V v_t_24965 = (g_heff_2ecompile_2eir_2econdExpr(v_c_24959));
      V v_t_24966 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_t_24965));
      V f_ = v_t_24966;
      args[0] = v_n_24964;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_24967 = heff_field(v_x_24963, 0);
      V v_ru_24x_24963_24Just = heff_take_reuse_n(v_x_24963, 1ULL, 1);
      heff_drop(v_c_24959);
      heff_drop_rec(v_g_240, 8);
      V v_t_24968 = heff_tag_at_n(v_ru_24x_24963_24Just, TAG_OBool, 1, (V[]){v_c_24967});
      V v_t_24972;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24969 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24972 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24969, v_t_24968});
        break;
      }
      case TAG_DLet: {
        V v_x_24970 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24972 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24970, v_t_24968});
        break;
      }
      case TAG_DSets: {
        heff_take_n(v_d_241, 0ULL, 1);
        v_t_24972 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str71), v_t_24968});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_t_24973 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24972, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_24962_24MkPair, TAG_MkPair, 2, (V[]){v_t_24973, v_n_24964});
    }
    default: return heff_nomatch(v_x_24963);
    }
  }
  default: return heff_nomatch(v_x2_24962);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam54(V self, V *args) {
  V v_n_24978 = args[0];
  V v_m_24977 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_24976 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24979 = heff_tr(heff_call(v_m_24977, 1, (V[]){v_n_24978}));
  switch (heff_tag_of(v_x2_24979)) {
  case TAG_MkPair: {
    V v_x_24980 = heff_field(v_x2_24979, 0);
    V v_n_24981 = heff_field(v_x2_24979, 1);
    V v_ru_24x2_24979_24MkPair = heff_take_reuse_n(v_x2_24979, 3ULL, 2);
    V v_m_24982 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_b_24976));
    V v_x2_24983 = heff_tr(heff_call(v_m_24982, 1, (V[]){v_n_24981}));
    switch (heff_tag_of(v_x2_24983)) {
    case TAG_MkPair: {
      V v_x_24984 = heff_field(v_x2_24983, 0);
      V v_n_24985 = heff_field(v_x2_24983, 1);
      V v_ru_24x2_24983_24MkPair = heff_take_reuse_n(v_x2_24983, 3ULL, 2);
      V v_x_24986 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_24983_24MkPair, v_x_24980, v_x_24984));
      return heff_tag_at_n(v_ru_24x2_24979_24MkPair, TAG_MkPair, 2, (V[]){v_x_24986, v_n_24985});
    }
    default: return heff_nomatch(v_x2_24983);
    }
  }
  default: return heff_nomatch(v_x2_24979);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam55(V self, V *args) {
  V v_n_24990 = args[0];
  V v_m_24989 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24991 = heff_tr(heff_call(v_m_24989, 1, (V[]){v_n_24990}));
  switch (heff_tag_of(v_x2_24991)) {
  case TAG_MkPair: {
    V v_x_24992 = heff_field(v_x2_24991, 0);
    V v_n_24993 = heff_field(v_x2_24991, 1);
    V v_ru_24x2_24991_24MkPair = heff_take_reuse_n(v_x2_24991, 3ULL, 2);
    V v_t_24996;
    switch (heff_tag_of(v_x_24992)) {
    case TAG_MkPair: {
      V v_x_24994 = heff_dup(heff_field(v_x_24992, 0));
      v_t_24996 = v_x_24994;
      break;
    }
    default: heff_nomatch(v_x_24992);
    }
    V v_o_24999;
    switch (heff_tag_of(v_x_24992)) {
    case TAG_MkPair: {
      V v_y_24998 = heff_field(v_x_24992, 1);
      heff_take_n(v_x_24992, 2ULL, 2);
      v_o_24999 = v_y_24998;
      break;
    }
    default: heff_nomatch(v_x_24992);
    }
    V v_t_241003;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_241000 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241003 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_241000, v_o_24999});
      break;
    }
    case TAG_DLet: {
      V v_x_241001 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241003 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_241001, v_o_24999});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_241003 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str72), v_o_24999});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_241004 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241003, NTAG(TAG_Nil)});
    V v_x_241005 = (g_prelude_2e_2b_2b(v_t_24996, v_t_241004));
    return heff_tag_at_n(v_ru_24x2_24991_24MkPair, TAG_MkPair, 2, (V[]){v_x_241005, v_n_24993});
  }
  default: return heff_nomatch(v_x2_24991);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam56(V self, V *args) {
  V v_n_241008 = args[0];
  V v_m_241007 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_241009 = heff_tr(heff_call(v_m_241007, 1, (V[]){v_n_241008}));
  switch (heff_tag_of(v_x2_241009)) {
  case TAG_MkPair: {
    V v_x_241010 = heff_field(v_x2_241009, 0);
    V v_n_241011 = heff_field(v_x2_241009, 1);
    V v_ru_24x2_241009_24MkPair = heff_take_reuse_n(v_x2_241009, 3ULL, 2);
    V v_t_241014;
    switch (heff_tag_of(v_x_241010)) {
    case TAG_MkPair: {
      V v_x_241012 = heff_dup(heff_field(v_x_241010, 0));
      v_t_241014 = v_x_241012;
      break;
    }
    default: heff_nomatch(v_x_241010);
    }
    V v_o_241017;
    switch (heff_tag_of(v_x_241010)) {
    case TAG_MkPair: {
      V v_y_241016 = heff_field(v_x_241010, 1);
      heff_take_n(v_x_241010, 2ULL, 2);
      v_o_241017 = v_y_241016;
      break;
    }
    default: heff_nomatch(v_x_241010);
    }
    V v_t_241021;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_241018 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241021 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_241018, v_o_241017});
      break;
    }
    case TAG_DLet: {
      V v_x_241019 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241021 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_241019, v_o_241017});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_241021 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str73), v_o_241017});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_241022 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241021, NTAG(TAG_Nil)});
    V v_x_241023 = (g_prelude_2e_2b_2b(v_t_241014, v_t_241022));
    return heff_tag_at_n(v_ru_24x2_241009_24MkPair, TAG_MkPair, 2, (V[]){v_x_241023, v_n_241011});
  }
  default: return heff_nomatch(v_x2_241009);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam57(V self, V *args) {
  V v_n_241026 = args[0];
  V v_m_241025 = heff_env(self)[0];
  V v_xs_241024 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_241027 = heff_tr(heff_call(v_m_241025, 1, (V[]){v_n_241026}));
  switch (heff_tag_of(v_x2_241027)) {
  case TAG_MkPair: {
    V v_x_241028 = heff_field(v_x2_241027, 0);
    V v_n_241029 = heff_field(v_x2_241027, 1);
    V v_ru_24x2_241027_24MkPair = heff_take_reuse_n(v_x2_241027, 3ULL, 2);
    V v_t_241032;
    switch (heff_tag_of(v_x_241028)) {
    case TAG_MkPair: {
      V v_x_241030 = heff_dup(heff_field(v_x_241028, 0));
      v_t_241032 = v_x_241030;
      break;
    }
    default: heff_nomatch(v_x_241028);
    }
    V v_t_241035;
    switch (heff_tag_of(v_x_241028)) {
    case TAG_MkPair: {
      V v_y_241034 = heff_field(v_x_241028, 1);
      heff_take_n(v_x_241028, 2ULL, 2);
      v_t_241035 = v_y_241034;
      break;
    }
    default: heff_nomatch(v_x_241028);
    }
    V v_t_241036 = (g_list_2ezipWith_24s583291244x257539062(v_xs_241024, v_t_241035));
    V v_x_241037 = (g_prelude_2e_2b_2b(v_t_241032, v_t_241036));
    return heff_tag_at_n(v_ru_24x2_241027_24MkPair, TAG_MkPair, 2, (V[]){v_x_241037, v_n_241029});
  }
  default: return heff_nomatch(v_x2_241027);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam58(V self, V *args) {
  V v_n_241042 = args[0];
  V v_m_241041 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_241043 = heff_tr(heff_call(v_m_241041, 1, (V[]){v_n_241042}));
  switch (heff_tag_of(v_x2_241043)) {
  case TAG_MkPair: {
    V v_x_241044 = heff_field(v_x2_241043, 0);
    V v_n_241045 = heff_field(v_x2_241043, 1);
    V v_ru_24x2_241043_24MkPair = heff_take_reuse_n(v_x2_241043, 3ULL, 2);
    V v_t_241048;
    switch (heff_tag_of(v_x_241044)) {
    case TAG_MkPair: {
      V v_x_241046 = heff_dup(heff_field(v_x_241044, 0));
      v_t_241048 = v_x_241046;
      break;
    }
    default: heff_nomatch(v_x_241044);
    }
    V v_o_241051;
    switch (heff_tag_of(v_x_241044)) {
    case TAG_MkPair: {
      V v_y_241050 = heff_field(v_x_241044, 1);
      heff_take_n(v_x_241044, 2ULL, 2);
      v_o_241051 = v_y_241050;
      break;
    }
    default: heff_nomatch(v_x_241044);
    }
    V v_t_241055;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_241052 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241055 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_241052, v_o_241051});
      break;
    }
    case TAG_DLet: {
      V v_x_241053 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241055 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_241053, v_o_241051});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_241055 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str74), v_o_241051});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_241056 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241055, NTAG(TAG_Nil)});
    V v_x_241057 = (g_prelude_2e_2b_2b(v_t_241048, v_t_241056));
    return heff_tag_at_n(v_ru_24x2_241043_24MkPair, TAG_MkPair, 2, (V[]){v_x_241057, v_n_241045});
  }
  default: return heff_nomatch(v_x2_241043);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam59(V self, V *args) {
  V v_n_241060 = args[0];
  V v_m_241059 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_241061 = heff_tr(heff_call(v_m_241059, 1, (V[]){v_n_241060}));
  switch (heff_tag_of(v_x2_241061)) {
  case TAG_MkPair: {
    V v_x_241062 = heff_field(v_x2_241061, 0);
    V v_n_241063 = heff_field(v_x2_241061, 1);
    V v_ru_24x2_241061_24MkPair = heff_take_reuse_n(v_x2_241061, 3ULL, 2);
    V v_t_241066;
    switch (heff_tag_of(v_x_241062)) {
    case TAG_MkPair: {
      V v_x_241064 = heff_dup(heff_field(v_x_241062, 0));
      v_t_241066 = v_x_241064;
      break;
    }
    default: heff_nomatch(v_x_241062);
    }
    V v_o_241069;
    switch (heff_tag_of(v_x_241062)) {
    case TAG_MkPair: {
      V v_y_241068 = heff_field(v_x_241062, 1);
      heff_take_n(v_x_241062, 2ULL, 2);
      v_o_241069 = v_y_241068;
      break;
    }
    default: heff_nomatch(v_x_241062);
    }
    V v_t_241073;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_241070 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241073 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_241070, v_o_241069});
      break;
    }
    case TAG_DLet: {
      V v_x_241071 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_241073 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_241071, v_o_241069});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_241073 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str75), v_o_241069});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_241074 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241073, NTAG(TAG_Nil)});
    V v_x_241075 = (g_prelude_2e_2b_2b(v_t_241066, v_t_241074));
    return heff_tag_at_n(v_ru_24x2_241061_24MkPair, TAG_MkPair, 2, (V[]){v_x_241075, v_n_241063});
  }
  default: return heff_nomatch(v_x2_241061);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam60(V self, V *args) {
  V v_n_241078 = args[0];
  V v_m_241077 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_241079 = heff_tr(heff_call(v_m_241077, 1, (V[]){v_n_241078}));
  switch (heff_tag_of(v_x2_241079)) {
  case TAG_MkPair: {
    V v_x_241080 = heff_field(v_x2_241079, 0);
    V v_n_241081 = heff_field(v_x2_241079, 1);
    V v_ru_24x2_241079_24MkPair = heff_take_reuse_n(v_x2_241079, 3ULL, 2);
    V v_t_241084;
    switch (heff_tag_of(v_x_241080)) {
    case TAG_MkPair: {
      V v_x_241082 = heff_dup(heff_field(v_x_241080, 0));
      v_t_241084 = v_x_241082;
      break;
    }
    default: heff_nomatch(v_x_241080);
    }
    V v_t_241085 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str76), heff_intShow(heff_dup(v_n_241081)));
    V v_t_241088;
    switch (heff_tag_of(v_x_241080)) {
    case TAG_MkPair: {
      V v_y_241087 = heff_field(v_x_241080, 1);
      heff_take_n(v_x_241080, 2ULL, 2);
      v_t_241088 = v_y_241087;
      break;
    }
    default: heff_nomatch(v_x_241080);
    }
    V v_t_241089 = heff_tag_n(TAG_SLet, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str77), v_t_241085), v_t_241088});
    V v_t_241090 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241089, NTAG(TAG_Nil)});
    V v_x_241091 = (g_prelude_2e_2b_2b(v_t_241084, v_t_241090));
    return heff_tag_at_n(v_ru_24x2_241079_24MkPair, TAG_MkPair, 2, (V[]){v_x_241091, heff_intAdd(v_n_241081, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_241079);
  }
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eopTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopTail_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopTail(V v_g_240, V v_e_241) {
top: ;
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_241}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2eopTail_lam0, 1, 1, (V[]){v_m_242});
}
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopTail(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_n_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_n_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_ss_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_dup(heff_field(v_x_245, 0));
      v_ss_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ss_249)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_Cons: {
      v_t_2415 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_249, heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412})});
      break;
    }
    default: heff_nomatch(v_ss_249);
    }
    return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_n_246});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etestTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etestTail_entry, 6, 0};

V g_heff_2ecompile_2eimperative_2etestTail(V v_g_240, V v_self_241, V v_s_242, V v_t_243, V v_f_244, V v_arms_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2etestTail_lam0, 1, 7, (V[]){v_m_246, v_g_240, v_self_241, v_s_242, v_arms_245, v_t_243, v_f_244});
}
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etestTail(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_245 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_f_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2411 = (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_242, v_arms_245));
      V f_ = v_t_2411;
      args[0] = v_n_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_245);
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 2)), 2, (V[]){heff_dup(v_self_241), v_t_243}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2410}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_n_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_f_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_n_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2412, v_x_2415, v_x_2419}), v_n_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsCond(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  V v_val_243 = heff_take_field(v_r_240, 0);
  V v_cond_244 = heff_take_field(v_r_240, 2);
  V v_op_245 = heff_get_n(v_r_240, 1, 5);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PTrue: {
    heff_drop(v_val_243);
    heff_drop(v_cond_244);
    heff_drop(v_op_245);
    return v_acc_242;
  }
  case TAG_PFalse: {
    heff_drop(v_val_243);
    heff_drop(v_cond_244);
    heff_drop(v_op_245);
    return v_acc_242;
  }
  case TAG_PRel: {
    V v_a_247 = heff_field(v_x2_241, 1);
    V v_b_248 = heff_field(v_x2_241, 2);
    heff_drop(v_cond_244);
    heff_drop(v_op_245);
    V v_t_249 = heff_tr(heff_call(heff_dup(v_val_243), 2, (V[]){heff_dup(v_b_248), v_acc_242}));
    return heff_tail(v_val_243, 2, (V[]){heff_dup(v_a_247), v_t_249});
  }
  case TAG_PBool: {
    V v_v_2410 = heff_field(v_x2_241, 0);
    heff_drop(v_cond_244);
    heff_drop(v_op_245);
    return heff_tail(v_val_243, 2, (V[]){heff_dup(v_v_2410), v_acc_242});
  }
  case TAG_PNot: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    heff_drop(v_val_243);
    heff_drop(v_op_245);
    return heff_tail(v_cond_244, 2, (V[]){heff_dup(v_c_2411), v_acc_242});
  }
  case TAG_PIf: {
    V v_a_2412 = heff_field(v_x2_241, 0);
    V v_b_2413 = heff_field(v_x2_241, 1);
    V v_c_2414 = heff_field(v_x2_241, 2);
    heff_drop(v_val_243);
    heff_drop(v_op_245);
    V v_t_2415 = heff_tr(heff_call(heff_dup(v_cond_244), 2, (V[]){heff_dup(v_c_2414), v_acc_242}));
    V v_t_2416 = heff_tr(heff_call(heff_dup(v_cond_244), 2, (V[]){heff_dup(v_b_2413), v_t_2415}));
    return heff_tail(v_cond_244, 2, (V[]){heff_dup(v_a_2412), v_t_2416});
  }
  case TAG_PLet: {
    V v_o_2418 = heff_field(v_x2_241, 1);
    V v_c_2419 = heff_field(v_x2_241, 2);
    heff_drop(v_val_243);
    V v_t_2420 = heff_tr(heff_call(v_cond_244, 2, (V[]){heff_dup(v_c_2419), v_acc_242}));
    return heff_tail(v_op_245, 2, (V[]){heff_dup(v_o_2418), v_t_2420});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2epartsCond(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam0, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam1, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam2, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam3, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam5, 2, 0};

static V g_heff_2ecompile_2eimperative_2epk_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2epk_st;
static V g_heff_2ecompile_2eimperative_2epk_init(void) {
  return heff_rec_n(5, shape_val__op__cond__sts__tl, (V[]){((V)&g_heff_2ecompile_2eimperative_2epk_lam0_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam1_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam2_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam3_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam5_clo)});
}
V g_heff_2ecompile_2eimperative_2epk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2epk_st)) return g_heff_2ecompile_2eimperative_2epk_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2epk_val, &g_heff_2ecompile_2eimperative_2epk_st, g_heff_2ecompile_2eimperative_2epk_init);
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args) {
  V v_v_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsVal(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_v_240, v_acc_241));
}
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args) {
  V v_o_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsOp(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_o_242, v_acc_243));
}
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args) {
  V v_c_244 = args[0];
  V v_acc_245 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get()); V a_1 = v_c_244; V a_2 = v_acc_245; V r_ = (g_heff_2ecompile_2eimperative_2epartsCond(a_0, a_1, a_2)); heff_drop(v_c_244); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_248; V a_1 = v_x_2411; V a_2 = v_acc_2410; V r_ = (g_heff_2ecompile_2eimperative_2epartsSt(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args) {
  V v_ss_246 = args[0];
  V v_acc_247 = args[1];
  V v_r_248 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam4, 2, 1, (V[]){v_r_248}); V a_1 = v_acc_247; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args) {
  V v_t_2412 = args[0];
  V v_acc_2413 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get()); V a_1 = v_t_2412; V a_2 = v_acc_2413; V r_ = (g_heff_2ecompile_2eimperative_2epartsTl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return v_acc_241;
  }
  case TAG_PFalse: {
    return v_acc_241;
  }
  case TAG_PRel: {
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    V v_acc_245 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_b_244), v_acc_241));
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_a_243), v_acc_245);
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_v_246), v_acc_241);
  }
  case TAG_PNot: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V t_0 = v_c_247;
    V t_1 = v_acc_241;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_PIf: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_c_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2410), v_acc_241}));
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_b_249), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_a_248), v_t_2412});
  }
  case TAG_PLet: {
    V v_o_2414 = heff_field(v_x2_240, 1);
    V v_c_2415 = heff_field(v_x2_240, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2415), v_acc_241}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_2414), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V v_o_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_242 = heff_dup(heff_field(v_o_240, 0));
    V v_t_243 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_242, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_243});
  }
  case TAG_OCall: {
    V v_args_245 = heff_dup(heff_field(v_o_240, 1));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_245));
    V v_t_247 = ({ V a_0 = v_acc_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_247});
  }
  case TAG_OApply: {
    V v_f_248 = heff_dup(heff_field(v_o_240, 0));
    V v_args_249 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_args_249})));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2411});
  }
  case TAG_OPrim: {
    V v_args_2413 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2413));
    V v_t_2415 = ({ V a_0 = v_acc_241; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2415});
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_acc_241});
  }
  case TAG_OBool: {
    V v_c_2416 = heff_dup(heff_field(v_o_240, 0));
    V v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2416); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2417});
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopNamesTop_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eopNamesTop(V v_o_240) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_241 = heff_field(v_o_240, 0);
    heff_take_n(v_o_240, 1ULL, 1);
    return ({ V a_0 = v_v_241; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_241); r_; });
  }
  case TAG_OCall: {
    V v_args_243 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_OApply: {
    V v_f_245 = heff_field(v_o_240, 0);
    V v_args_246 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OApply = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24o_240_24OApply, TAG_Cons, 2, (V[]){v_f_245, v_args_246})));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  case TAG_OPrim: {
    V v_args_249 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_249));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_o_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopNamesTop(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2efirstNamesTl_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2efirstNamesTl(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_TSeq: {
    V v_t1_241 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_t1_241)) {
    case TAG_Nil: {
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_st_243 = heff_field(v_t1_241, 0);
      switch (heff_tag_of(v_st_243)) {
      case TAG_SLet: {
        V v_o_246 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_246));
      }
      case TAG_SDecl: {
        return NTAG(TAG_Nil);
      }
      case TAG_SSet: {
        V v_o_249 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_249));
      }
      case TAG_SIf: {
        return NTAG(TAG_Nil);
      }
      case TAG_SCase: {
        V v_v_2413 = heff_field(v_st_243, 0);
        return (g_heff_2ecompile_2eimperative_2evalNamesTop(v_v_2413, NTAG(TAG_Nil)));
      }
      default: return heff_nomatch(v_st_243);
      }
    }
    default: return heff_nomatch(v_t1_241);
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_t_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_2415));
  }
  case TAG_TLoop: {
    V v_vs_2416 = heff_field(v_t_240, 0);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2416)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_TIf: {
    return NTAG(TAG_Nil);
  }
  case TAG_TCase: {
    V v_v_2421 = heff_field(v_t_240, 0);
    return (g_heff_2ecompile_2eimperative_2evalNamesTop(v_v_2421, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2efirstNamesTl(a0); heff_drop(a0); return r;
}