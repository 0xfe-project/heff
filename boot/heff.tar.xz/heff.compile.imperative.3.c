// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_DSets 40405
#define TAG_EBool 8245
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_ESet 50124
#define TAG_EValues 34965
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartOp 18051
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_toDest 1077793512
#define LBL_val 326043
static uint32_t shape_val__op__cond__sts__tl[] = {LBL_val, LBL_op, LBL_cond, LBL_sts, LBL_tl};
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo;
V g_heff_2ecompile_2eimperative_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965(V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_clo;
V g_heff_2ecompile_2eimperative_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchSet_clo;
V g_heff_2ecompile_2eimperative_2ematchTo(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchTo_clo;
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284(V);
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_clo;
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps(V, V);
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_clo;
V g_heff_2ecompile_2eimperative_2eonceK_get(void);
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(V);
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_clo;
V g_heff_2ecompile_2eimperative_2eonceSts(V, V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_clo;
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps(V, V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_clo;
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(V);
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2eopTail(V, V);
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopTail_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2esetsOf(V, V, V);
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esetsOf_clo;
HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etestTail_clo;
V g_heff_2ecompile_2eimperative_2etoDest(V, V, V);
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etoDest_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2econdExpr(V);
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdExpr_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1155474388x1593011685(V);
V g_list_2emap_24s1155474388x1593011685_entry(V self, V *a);
extern Clo g_list_2emap_24s1155474388x1593011685_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s583291244x257539062(V, V);
V g_list_2ezipWith_24s583291244x257539062_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;

HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLet: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_o_245 = heff_field(v_x11_242, 1);
      HeffT2 v_t_246 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_rest_243, v_p_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_q_249 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_PLet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_o_245), v_q_249})}});
        } else {
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_SOnce: {
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SDecl: {
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSet: {
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIf: {
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCase: {
      heff_drop(v_p_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eimperative_2epredLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredLets_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredLets(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_x1_240, v_p_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epredLets(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseSet(V v_g_240, V v_d_241, V v_s_242, V v_arms_243) {
top: ;
  V v_atom_244 = heff_take_field(v_g_240, 5);
  V v_toDest_245 = heff_get_n(v_g_240, 4, 8);
  V v_m_246 = heff_tr(heff_call(v_atom_244, 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam0, 1, 4, (V[]){v_m_246, v_toDest_245, v_d_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  V v_vs_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_toDest_245 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_b_2414 = heff_field(v_arm_2411, 2);
    heff_take_n(v_arm_2411, 7ULL, 3);
    V v_m_2415 = heff_tr(heff_call(v_toDest_245, 2, (V[]){v_d_241, v_b_2414}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam2, 1, 3, (V[]){v_m_2415, v_t_2412, v_vs_2413});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_toDest_245 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2420 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam1, 1, 2, (V[]){v_toDest_245, v_d_241}), v_arms_243));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      V v_t_2426;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_dup(heff_field(v_x_249, 0));
        v_t_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2429;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_y_2428 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2429 = v_y_2428;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_t_2429, v_x_2422}), NTAG(TAG_Nil)});
      V v_x_2431 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2430));
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_lit_240}), NTAG(TAG_Nil)});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_lit_240}), v_t_246});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_247);
    }
    case TAG_Cons: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_lit_240;
      V t_1 = v_x22_245;
      V t_2 = v_cell_2410;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str3, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str4, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str5, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str6, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str7, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str8, 2, "t$");
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etoDest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etoDest_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etoDest(V v_g_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELet: {
    V v_y_243 = heff_field(v_e_242, 0);
    V v_a_244 = heff_field(v_e_242, 1);
    V v_b_245 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_246 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(v_y_243, heff_dup(v_a_244), heff_dup(v_b_245)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_y_243);
        heff_drop(v_a_244);
        heff_drop(v_b_245);
        V v_e2_249 = v_field_248;
        V t_0 = v_g_240;
        V t_1 = v_d_241;
        V t_2 = v_e2_249;
        v_g_240 = t_0;
        v_d_241 = t_1;
        v_e_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_248);
        V v_m_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_243, v_a_244}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam0, 1, 4, (V[]){v_m_2410, v_g_240, v_d_241, v_b_245});
      }
    }
  }
  case TAG_EMatch: {
    V v_s_2420 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2421 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2421));
    if (heff_intEq_c(v_t_2422, MK_INT(2LL))) {
      HeffT2 v_t_2423 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2etoDest_str0); V a_1 = v_arms_2421; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_t_2426 = v_field_2425;
          HeffT2 v_t_2427 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2etoDest_str1); V a_1 = v_arms_2421; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2429 = v_t_2427.f[1];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              V v_f_2430 = v_field_2429;
              V v_t_2431 = v_t_2426;
              V v_f_2432 = v_f_2430;
              V v_t_2433 = heff_dup(heff_rfield(v_g_240, 0));
              if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                heff_drop(v_t_2433);
                V v_t_2434 = (g_heff_2ecompile_2eimperative_2econdShaped(v_t_2431));
                if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
                  heff_drop(v_t_2434);
                  V v_t_2435 = (g_heff_2ecompile_2eimperative_2econdShaped(v_f_2432));
                  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
                    heff_drop(v_t_2435);
                    V v_m_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
                    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam1, 1, 5, (V[]){v_m_2436, v_d_241, v_g_240, v_s_2420, v_arms_2421});
                  } else {
                    heff_drop_tag(v_e_242, 2);
                    heff_drop(v_t_2435);
                    return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_2420, v_arms_2421));
                  }
                } else {
                  heff_drop_tag(v_e_242, 2);
                  heff_drop(v_f_2432);
                  heff_drop(v_t_2434);
                  return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_2420, v_arms_2421));
                }
              } else {
                heff_drop_tag(v_e_242, 2);
                heff_drop(v_t_2431);
                heff_drop(v_f_2432);
                heff_drop(v_t_2433);
                return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_2420, v_arms_2421));
              }
            } else {
              heff_drop_tag(v_e_242, 2);
              heff_drop(v_t_2426);
              heff_drop(v_field_2429);
              return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_2420, v_arms_2421));
            }
          }
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_field_2425);
          return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_2420, v_arms_2421));
        }
      }
    } else {
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2ecompile_2eimperative_2ematchTo(v_g_240, v_d_241, v_s_2420, v_arms_2421));
    }
  }
  case TAG_EBool: {
    V v_c_2459 = heff_dup(heff_field(v_e_242, 0));
    V v_m_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam2, 1, 4, (V[]){v_m_2460, v_c_2459, v_g_240, v_d_241});
  }
  case TAG_ESet: {
    V v_e1_2474 = heff_field(v_e_242, 0);
    V v_a_2475 = heff_field(v_e_242, 1);
    V v_b_2476 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2477 = (g_heff_2ecompile_2eimperative_2esetsOf(heff_dup(v_g_240), v_e1_2474, v_a_2475));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam3, 1, 4, (V[]){v_m_2477, v_g_240, v_d_241, v_b_2476});
  }
  case TAG_EValues: {
    V v_es_2487 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_drop(v_es_2487);
      V v_m_2489 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam4, 1, 2, (V[]){v_m_2489, v_d_241});
    }
    case TAG_DLet: {
      heff_drop(v_es_2487);
      V v_m_24107 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam5, 1, 2, (V[]){v_m_24107, v_d_241});
    }
    case TAG_DSets: {
      V v_xs_24124 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      heff_drop_tag(v_e_242, 1);
      V v_m_24125 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_es_2487));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam6, 1, 2, (V[]){v_m_24125, v_xs_24124});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  default: {
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_m_24139 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam7, 1, 2, (V[]){v_m_24139, v_d_241});
    }
    case TAG_DLet: {
      V v_m_24157 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam8, 1, 2, (V[]){v_m_24157, v_d_241});
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      V v_m_24175 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam9, 1, 1, (V[]){v_m_24175});
    }
    default: return heff_nomatch(v_d_241);
    }
  }
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etoDest(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_m_2415 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_b_245));
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2414}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
      V v_x_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2416_24MkPair, v_x_2413, v_x_2417));
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_n_2418});
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_s_2420 = heff_env(self)[3];
  V v_arms_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    switch (heff_tag_of(v_x_2439)) {
    case TAG_Nothing: {
      V v_t_2444;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        v_t_2444 = heff_dup(v_d_241);
        break;
      }
      case TAG_DLet: {
        V v_x_2442 = heff_dup(heff_field(v_d_241, 0));
        v_t_2444 = heff_tag_n(TAG_DSet, 1, (V[]){v_x_2442});
        break;
      }
      case TAG_DSets: {
        v_t_2444 = heff_dup(v_d_241);
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_2445 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_2444, v_s_2420, v_arms_2421));
      V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_n_2440}));
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_MkPair: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_n_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        V v_x_2452;
        switch (heff_tag_of(v_d_241)) {
        case TAG_DSet: {
          heff_take_n(v_d_241, 0ULL, 1);
          v_x_2452 = v_x_2447;
          break;
        }
        case TAG_DLet: {
          V v_x_2450 = heff_field(v_d_241, 0);
          V v_ru_24d_241_24DLet = heff_take_reuse_n(v_d_241, 1ULL, 1);
          v_x_2452 = (g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(v_ru_24d_241_24DLet, v_x_2450, v_x_2447));
          break;
        }
        case TAG_DSets: {
          heff_take_n(v_d_241, 0ULL, 1);
          v_x_2452 = v_x_2447;
          break;
        }
        default: heff_nomatch(v_d_241);
        }
        return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){v_x_2452, v_n_2448});
      }
      default: return heff_nomatch(v_x2_2446);
      }
    }
    case TAG_Just: {
      V v_c_2453 = heff_field(v_x_2439, 0);
      V v_ru_24x_2439_24Just = heff_take_reuse_n(v_x_2439, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_2420);
      heff_drop(v_arms_2421);
      V v_t_2457;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_2454 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_2457 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2454, heff_tag_at_n(v_ru_24x_2439_24Just, TAG_OBool, 1, (V[]){v_c_2453})});
        break;
      }
      case TAG_DLet: {
        V v_x_2455 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_2457 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2455, heff_tag_at_n(v_ru_24x_2439_24Just, TAG_OBool, 1, (V[]){v_c_2453})});
        break;
      }
      case TAG_DSets: {
        heff_take_n(v_d_241, 0ULL, 1);
        v_t_2457 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str2), heff_tag_at_n(v_ru_24x_2439_24Just, TAG_OBool, 1, (V[]){v_c_2453})});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){v_t_2458, v_n_2440});
    }
    default: return heff_nomatch(v_x_2439);
    }
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_c_2459 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    switch (heff_tag_of(v_x_2463)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_2462_24MkPair, 2);
      V v_t_2465 = (g_heff_2ecompile_2eir_2econdExpr(v_c_2459));
      V v_t_2466 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_t_2465));
      V f_ = v_t_2466;
      args[0] = v_n_2464;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2467 = heff_field(v_x_2463, 0);
      V v_ru_24x_2463_24Just = heff_take_reuse_n(v_x_2463, 1ULL, 1);
      heff_drop(v_c_2459);
      heff_drop_rec(v_g_240, 8);
      V v_t_2468 = heff_tag_at_n(v_ru_24x_2463_24Just, TAG_OBool, 1, (V[]){v_c_2467});
      V v_t_2472;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_2469 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_2472 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2469, v_t_2468});
        break;
      }
      case TAG_DLet: {
        V v_x_2470 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_2472 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2470, v_t_2468});
        break;
      }
      case TAG_DSets: {
        heff_take_n(v_d_241, 0ULL, 1);
        v_t_2472 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str3), v_t_2468});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){v_t_2473, v_n_2464});
    }
    default: return heff_nomatch(v_x_2463);
    }
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args) {
  V v_n_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_2476 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_n_2478}));
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_field(v_x2_2479, 0);
    V v_n_2481 = heff_field(v_x2_2479, 1);
    V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
    V v_m_2482 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_b_2476));
    V v_x2_2483 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2481}));
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_MkPair: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_n_2485 = heff_field(v_x2_2483, 1);
      V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
      V v_x_2486 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2483_24MkPair, v_x_2480, v_x_2484));
      return heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_MkPair, 2, (V[]){v_x_2486, v_n_2485});
    }
    default: return heff_nomatch(v_x2_2483);
    }
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args) {
  V v_n_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_n_2490}));
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_MkPair: {
    V v_x_2492 = heff_field(v_x2_2491, 0);
    V v_n_2493 = heff_field(v_x2_2491, 1);
    V v_ru_24x2_2491_24MkPair = heff_take_reuse_n(v_x2_2491, 3ULL, 2);
    V v_t_2496;
    switch (heff_tag_of(v_x_2492)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_dup(heff_field(v_x_2492, 0));
      v_t_2496 = v_x_2494;
      break;
    }
    default: heff_nomatch(v_x_2492);
    }
    V v_o_2499;
    switch (heff_tag_of(v_x_2492)) {
    case TAG_MkPair: {
      V v_y_2498 = heff_field(v_x_2492, 1);
      heff_take_n(v_x_2492, 2ULL, 2);
      v_o_2499 = v_y_2498;
      break;
    }
    default: heff_nomatch(v_x_2492);
    }
    V v_t_24103;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24100 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24103 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24100, v_o_2499});
      break;
    }
    case TAG_DLet: {
      V v_x_24101 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24103 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24101, v_o_2499});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24103 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str4), v_o_2499});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
    V v_x_24105 = (g_prelude_2e_2b_2b(v_t_2496, v_t_24104));
    return heff_tag_at_n(v_ru_24x2_2491_24MkPair, TAG_MkPair, 2, (V[]){v_x_24105, v_n_2493});
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args) {
  V v_n_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_n_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_n_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    V v_t_24114;
    switch (heff_tag_of(v_x_24110)) {
    case TAG_MkPair: {
      V v_x_24112 = heff_dup(heff_field(v_x_24110, 0));
      v_t_24114 = v_x_24112;
      break;
    }
    default: heff_nomatch(v_x_24110);
    }
    V v_o_24117;
    switch (heff_tag_of(v_x_24110)) {
    case TAG_MkPair: {
      V v_y_24116 = heff_field(v_x_24110, 1);
      heff_take_n(v_x_24110, 2ULL, 2);
      v_o_24117 = v_y_24116;
      break;
    }
    default: heff_nomatch(v_x_24110);
    }
    V v_t_24121;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24118 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24121 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24118, v_o_24117});
      break;
    }
    case TAG_DLet: {
      V v_x_24119 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24121 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24119, v_o_24117});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24121 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str5), v_o_24117});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
    V v_x_24123 = (g_prelude_2e_2b_2b(v_t_24114, v_t_24122));
    return heff_tag_at_n(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){v_x_24123, v_n_24111});
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_xs_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24132;
    switch (heff_tag_of(v_x_24128)) {
    case TAG_MkPair: {
      V v_x_24130 = heff_dup(heff_field(v_x_24128, 0));
      v_t_24132 = v_x_24130;
      break;
    }
    default: heff_nomatch(v_x_24128);
    }
    V v_t_24135;
    switch (heff_tag_of(v_x_24128)) {
    case TAG_MkPair: {
      V v_y_24134 = heff_field(v_x_24128, 1);
      heff_take_n(v_x_24128, 2ULL, 2);
      v_t_24135 = v_y_24134;
      break;
    }
    default: heff_nomatch(v_x_24128);
    }
    V v_t_24136 = (g_list_2ezipWith_24s583291244x257539062(v_xs_24124, v_t_24135));
    V v_x_24137 = (g_prelude_2e_2b_2b(v_t_24132, v_t_24136));
    return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){v_x_24137, v_n_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args) {
  V v_n_24140 = args[0];
  V v_m_24139 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24141 = heff_tr(heff_call(v_m_24139, 1, (V[]){v_n_24140}));
  switch (heff_tag_of(v_x2_24141)) {
  case TAG_MkPair: {
    V v_x_24142 = heff_field(v_x2_24141, 0);
    V v_n_24143 = heff_field(v_x2_24141, 1);
    V v_ru_24x2_24141_24MkPair = heff_take_reuse_n(v_x2_24141, 3ULL, 2);
    V v_t_24146;
    switch (heff_tag_of(v_x_24142)) {
    case TAG_MkPair: {
      V v_x_24144 = heff_dup(heff_field(v_x_24142, 0));
      v_t_24146 = v_x_24144;
      break;
    }
    default: heff_nomatch(v_x_24142);
    }
    V v_o_24149;
    switch (heff_tag_of(v_x_24142)) {
    case TAG_MkPair: {
      V v_y_24148 = heff_field(v_x_24142, 1);
      heff_take_n(v_x_24142, 2ULL, 2);
      v_o_24149 = v_y_24148;
      break;
    }
    default: heff_nomatch(v_x_24142);
    }
    V v_t_24153;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24150 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24153 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24150, v_o_24149});
      break;
    }
    case TAG_DLet: {
      V v_x_24151 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24153 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24151, v_o_24149});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24153 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str6), v_o_24149});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24154 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24153, NTAG(TAG_Nil)});
    V v_x_24155 = (g_prelude_2e_2b_2b(v_t_24146, v_t_24154));
    return heff_tag_at_n(v_ru_24x2_24141_24MkPair, TAG_MkPair, 2, (V[]){v_x_24155, v_n_24143});
  }
  default: return heff_nomatch(v_x2_24141);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args) {
  V v_n_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_n_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_n_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_t_24164;
    switch (heff_tag_of(v_x_24160)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_dup(heff_field(v_x_24160, 0));
      v_t_24164 = v_x_24162;
      break;
    }
    default: heff_nomatch(v_x_24160);
    }
    V v_o_24167;
    switch (heff_tag_of(v_x_24160)) {
    case TAG_MkPair: {
      V v_y_24166 = heff_field(v_x_24160, 1);
      heff_take_n(v_x_24160, 2ULL, 2);
      v_o_24167 = v_y_24166;
      break;
    }
    default: heff_nomatch(v_x_24160);
    }
    V v_t_24171;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24168 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24171 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24168, v_o_24167});
      break;
    }
    case TAG_DLet: {
      V v_x_24169 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24171 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24169, v_o_24167});
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_t_24171 = heff_tag_n(TAG_SLet, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2etoDest_str7), v_o_24167});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24172 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24171, NTAG(TAG_Nil)});
    V v_x_24173 = (g_prelude_2e_2b_2b(v_t_24164, v_t_24172));
    return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_x_24173, v_n_24161});
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args) {
  V v_n_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_n_24176}));
  switch (heff_tag_of(v_x2_24177)) {
  case TAG_MkPair: {
    V v_x_24178 = heff_field(v_x2_24177, 0);
    V v_n_24179 = heff_field(v_x2_24177, 1);
    V v_ru_24x2_24177_24MkPair = heff_take_reuse_n(v_x2_24177, 3ULL, 2);
    V v_t_24182;
    switch (heff_tag_of(v_x_24178)) {
    case TAG_MkPair: {
      V v_x_24180 = heff_dup(heff_field(v_x_24178, 0));
      v_t_24182 = v_x_24180;
      break;
    }
    default: heff_nomatch(v_x_24178);
    }
    V v_t_24183 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2etoDest_str8), heff_intShow(heff_dup(v_n_24179)));
    V v_t_24186;
    switch (heff_tag_of(v_x_24178)) {
    case TAG_MkPair: {
      V v_y_24185 = heff_field(v_x_24178, 1);
      heff_take_n(v_x_24178, 2ULL, 2);
      v_t_24186 = v_y_24185;
      break;
    }
    default: heff_nomatch(v_x_24178);
    }
    V v_t_24187 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SLet, 2, (V[]){v_t_24183, v_t_24186}), NTAG(TAG_Nil)});
    V v_x_24188 = (g_prelude_2e_2b_2b(v_t_24182, v_t_24187));
    return heff_tag_at_n(v_ru_24x2_24177_24MkPair, TAG_MkPair, 2, (V[]){v_x_24188, heff_intAdd(v_n_24179, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_24177);
  }
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eopTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopTail_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopTail(V v_g_240, V v_e_241) {
top: ;
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_241}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2eopTail_lam0, 1, 1, (V[]){v_m_242});
}
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopTail(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_n_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_n_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_ss_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_dup(heff_field(v_x_245, 0));
      v_ss_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ss_249)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_Cons: {
      v_t_2415 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_249, heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412})});
      break;
    }
    default: heff_nomatch(v_ss_249);
    }
    return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_n_246});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etestTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etestTail_entry, 6, 0};

V g_heff_2ecompile_2eimperative_2etestTail(V v_g_240, V v_self_241, V v_s_242, V v_t_243, V v_f_244, V v_arms_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2etestTail_lam0, 1, 7, (V[]){v_m_246, v_g_240, v_self_241, v_s_242, v_arms_245, v_t_243, v_f_244});
}
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etestTail(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_245 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_f_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2411 = (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_242, v_arms_245));
      V f_ = v_t_2411;
      args[0] = v_n_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_245);
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 2)), 2, (V[]){heff_dup(v_self_241), v_t_243}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2410}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_n_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_f_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_n_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2412, v_x_2415, v_x_2419}), v_n_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam0, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam1, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam5, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam6(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam6, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam9(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam9, 2, 0};

static V g_heff_2ecompile_2eimperative_2epk_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2epk_st;
static V g_heff_2ecompile_2eimperative_2epk_init(void) {
  return heff_rec_n(5, shape_val__op__cond__sts__tl, (V[]){((V)&g_heff_2ecompile_2eimperative_2epk_lam0_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam1_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam5_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam6_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam9_clo)});
}
V g_heff_2ecompile_2eimperative_2epk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2epk_st)) return g_heff_2ecompile_2eimperative_2epk_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2epk_val, &g_heff_2ecompile_2eimperative_2epk_st, g_heff_2ecompile_2eimperative_2epk_init);
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args) {
  V v_v_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsVal(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_v_240, v_acc_241));
}
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_x_2415 = args[1];
  V v_val_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_245;
  args[0] = v_x_2415;
  args[1] = v_acc_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_x_2421 = args[1];
  V v_val_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_245;
  args[0] = v_x_2421;
  args[1] = v_acc_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args) {
  V v_acc_2426 = args[0];
  V v_x_2427 = args[1];
  V v_val_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_245;
  args[0] = v_x_2427;
  args[1] = v_acc_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args) {
  V v_o_242 = args[0];
  V v_acc_243 = args[1];
  V v_r_244 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_val_245 = heff_take_field(v_r_244, 0);
  V v_cond_246 = heff_get_n(v_r_244, 2, 5);
  V v_o_247 = v_o_242;
  V v_acc_248 = v_acc_243;
  switch (heff_tag_of(v_o_247)) {
  case TAG_OSimple: {
    V v_v_249 = heff_dup(heff_field(v_o_247, 0));
    heff_drop(v_cond_246);
    V v_t_2410 = heff_tr(heff_call(v_val_245, 2, (V[]){v_v_249, v_acc_248}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_247}), v_t_2410});
  }
  case TAG_OCall: {
    V v_args_2412 = heff_dup(heff_field(v_o_247, 1));
    heff_drop(v_cond_246);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2412));
    V v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam2, 2, 1, (V[]){v_val_245}); V a_1 = v_acc_248; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_247}), v_t_2416});
  }
  case TAG_OApply: {
    V v_f_2417 = heff_dup(heff_field(v_o_247, 0));
    V v_args_2418 = heff_dup(heff_field(v_o_247, 1));
    heff_drop(v_cond_246);
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_2417, v_args_2418})));
    V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam3, 2, 1, (V[]){v_val_245}); V a_1 = v_acc_248; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_247}), v_t_2422});
  }
  case TAG_OPrim: {
    V v_args_2424 = heff_dup(heff_field(v_o_247, 1));
    heff_drop(v_cond_246);
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2424));
    V v_t_2428 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam4, 2, 1, (V[]){v_val_245}); V a_1 = v_acc_248; V a_2 = v_t_2425; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_247}), v_t_2428});
  }
  case TAG_OAbandon: {
    heff_drop(v_val_245);
    heff_drop(v_cond_246);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_247}), v_acc_248});
  }
  case TAG_OBool: {
    V v_c_2429 = heff_dup(heff_field(v_o_247, 0));
    heff_drop(v_val_245);
    V v_t_2430 = heff_tr(heff_call(v_cond_246, 2, (V[]){v_c_2429, v_acc_248}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_247}), v_t_2430});
  }
  default: return heff_nomatch(v_o_247);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args) {
  V v_c_2431 = args[0];
  V v_acc_2432 = args[1];
  V v_r_2433 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_val_2434 = heff_take_field(v_r_2433, 0);
  V v_cond_2435 = heff_take_field(v_r_2433, 2);
  V v_op_2436 = heff_get_n(v_r_2433, 1, 5);
  V v_x2_2437 = v_c_2431;
  V v_acc_2438 = v_acc_2432;
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_PTrue: {
    heff_drop(v_val_2434);
    heff_drop(v_cond_2435);
    heff_drop(v_op_2436);
    return v_acc_2438;
  }
  case TAG_PFalse: {
    heff_drop(v_val_2434);
    heff_drop(v_cond_2435);
    heff_drop(v_op_2436);
    return v_acc_2438;
  }
  case TAG_PRel: {
    V v_a_2440 = heff_field(v_x2_2437, 1);
    V v_b_2441 = heff_field(v_x2_2437, 2);
    heff_take_n(v_x2_2437, 6ULL, 3);
    heff_drop(v_cond_2435);
    heff_drop(v_op_2436);
    V v_t_2442 = heff_tr(heff_call(heff_dup(v_val_2434), 2, (V[]){v_b_2441, v_acc_2438}));
    V f_ = v_val_2434;
    args[0] = v_a_2440;
    args[1] = v_t_2442;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_PBool: {
    V v_v_2443 = heff_field(v_x2_2437, 0);
    heff_take_n(v_x2_2437, 1ULL, 1);
    heff_drop(v_cond_2435);
    heff_drop(v_op_2436);
    V f_ = v_val_2434;
    args[0] = v_v_2443;
    args[1] = v_acc_2438;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_PNot: {
    V v_c_2444 = heff_field(v_x2_2437, 0);
    heff_take_n(v_x2_2437, 1ULL, 1);
    heff_drop(v_val_2434);
    heff_drop(v_op_2436);
    V f_ = v_cond_2435;
    args[0] = v_c_2444;
    args[1] = v_acc_2438;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_PIf: {
    V v_a_2445 = heff_field(v_x2_2437, 0);
    V v_b_2446 = heff_field(v_x2_2437, 1);
    V v_c_2447 = heff_field(v_x2_2437, 2);
    heff_take_n(v_x2_2437, 7ULL, 3);
    heff_drop(v_val_2434);
    heff_drop(v_op_2436);
    V v_t_2448 = heff_tr(heff_call(heff_dup(v_cond_2435), 2, (V[]){v_c_2447, v_acc_2438}));
    V v_t_2449 = heff_tr(heff_call(heff_dup(v_cond_2435), 2, (V[]){v_b_2446, v_t_2448}));
    V f_ = v_cond_2435;
    args[0] = v_a_2445;
    args[1] = v_t_2449;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_PLet: {
    V v_o_2451 = heff_field(v_x2_2437, 1);
    V v_c_2452 = heff_field(v_x2_2437, 2);
    heff_take_n(v_x2_2437, 6ULL, 3);
    heff_drop(v_val_2434);
    V v_t_2453 = heff_tr(heff_call(v_cond_2435, 2, (V[]){v_c_2452, v_acc_2438}));
    V f_ = v_op_2436;
    args[0] = v_o_2451;
    args[1] = v_t_2453;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam8(V self, V *args) {
  V v_acc_2482 = args[0];
  V v_x_2483 = args[1];
  V v_sts_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2483)) {
  case TAG_MkArm: {
    V v_ss_2486 = heff_field(v_x_2483, 2);
    heff_take_n(v_x_2483, 4ULL, 3);
    V f_ = v_sts_2463;
    args[0] = v_ss_2486;
    args[1] = v_acc_2482;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_2483);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam7(V self, V *args) {
  V v_acc_2458 = args[0];
  V v_x_2459 = args[1];
  V v_r_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_2460 = v_r_2456;
  V v_op_2461 = heff_take_field(v_r_2460, 1);
  V v_cond_2462 = heff_take_field(v_r_2460, 2);
  V v_sts_2463 = heff_take_field(v_r_2460, 3);
  V v_val_2464 = heff_get_n(v_r_2460, 0, 5);
  V v_x2_2465 = v_x_2459;
  V v_acc_2466 = v_acc_2458;
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_SLet: {
    V v_o_2468 = heff_field(v_x2_2465, 1);
    heff_take_n(v_x2_2465, 2ULL, 2);
    heff_drop(v_cond_2462);
    heff_drop(v_sts_2463);
    heff_drop(v_val_2464);
    V f_ = v_op_2461;
    args[0] = v_o_2468;
    args[1] = v_acc_2466;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_SOnce: {
    V v_o_2470 = heff_field(v_x2_2465, 1);
    heff_take_n(v_x2_2465, 2ULL, 2);
    heff_drop(v_cond_2462);
    heff_drop(v_sts_2463);
    heff_drop(v_val_2464);
    V f_ = v_op_2461;
    args[0] = v_o_2470;
    args[1] = v_acc_2466;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_SDecl: {
    heff_take_n(v_x2_2465, 0ULL, 1);
    heff_drop(v_op_2461);
    heff_drop(v_cond_2462);
    heff_drop(v_sts_2463);
    heff_drop(v_val_2464);
    return v_acc_2466;
  }
  case TAG_SSet: {
    V v_o_2473 = heff_field(v_x2_2465, 1);
    heff_take_n(v_x2_2465, 2ULL, 2);
    heff_drop(v_cond_2462);
    heff_drop(v_sts_2463);
    heff_drop(v_val_2464);
    V f_ = v_op_2461;
    args[0] = v_o_2473;
    args[1] = v_acc_2466;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_SIf: {
    V v_c_2474 = heff_field(v_x2_2465, 0);
    V v_ts_2475 = heff_field(v_x2_2465, 1);
    V v_fs_2476 = heff_field(v_x2_2465, 2);
    heff_take_n(v_x2_2465, 7ULL, 3);
    heff_drop(v_op_2461);
    heff_drop(v_val_2464);
    V v_t_2477 = heff_tr(heff_call(heff_dup(v_sts_2463), 2, (V[]){v_fs_2476, v_acc_2466}));
    V v_t_2478 = heff_tr(heff_call(v_sts_2463, 2, (V[]){v_ts_2475, v_t_2477}));
    V f_ = v_cond_2462;
    args[0] = v_c_2474;
    args[1] = v_t_2478;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_SCase: {
    V v_v_2479 = heff_field(v_x2_2465, 0);
    V v_arms_2480 = heff_field(v_x2_2465, 1);
    heff_take_n(v_x2_2465, 3ULL, 2);
    heff_drop(v_op_2461);
    heff_drop(v_cond_2462);
    V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2480));
    V v_t_2487 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam8, 2, 1, (V[]){v_sts_2463}); V a_1 = v_acc_2466; V a_2 = v_t_2481; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2481); r_; });
    V f_ = v_val_2464;
    args[0] = v_v_2479;
    args[1] = v_t_2487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam6(V self, V *args) {
  V v_ss_2454 = args[0];
  V v_acc_2455 = args[1];
  V v_r_2456 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_2454));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam7, 2, 1, (V[]){v_r_2456}); V a_1 = v_acc_2455; V a_2 = v_t_2457; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2457); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam10(V self, V *args) {
  V v_acc_24104 = args[0];
  V v_x_24105 = args[1];
  V v_val_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_2494;
  args[0] = v_x_24105;
  args[1] = v_acc_24104;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epk_lam11(V self, V *args) {
  V v_acc_24114 = args[0];
  V v_x_24115 = args[1];
  V v_tl_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_24115)) {
  case TAG_MkArm: {
    V v_t_24118 = heff_field(v_x_24115, 2);
    heff_take_n(v_x_24115, 4ULL, 3);
    V f_ = v_tl_2492;
    args[0] = v_t_24118;
    args[1] = v_acc_24114;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_24115);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam9(V self, V *args) {
  V v_t_2488 = args[0];
  V v_acc_2489 = args[1];
  V v_r_2490 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_sts_2491 = heff_take_field(v_r_2490, 3);
  V v_tl_2492 = heff_take_field(v_r_2490, 4);
  V v_op_2493 = heff_take_field(v_r_2490, 1);
  V v_val_2494 = heff_take_field(v_r_2490, 0);
  V v_cond_2495 = heff_get_n(v_r_2490, 2, 5);
  V v_x2_2496 = v_t_2488;
  V v_acc_2497 = v_acc_2489;
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_TSeq: {
    V v_ss_2498 = heff_field(v_x2_2496, 0);
    V v_t_2499 = heff_field(v_x2_2496, 1);
    heff_take_n(v_x2_2496, 3ULL, 2);
    heff_drop(v_op_2493);
    heff_drop(v_val_2494);
    heff_drop(v_cond_2495);
    V v_t_24100 = heff_tr(heff_call(v_tl_2492, 2, (V[]){v_t_2499, v_acc_2497}));
    V f_ = v_sts_2491;
    args[0] = v_ss_2498;
    args[1] = v_t_24100;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_TReturn: {
    V v_o_24101 = heff_field(v_x2_2496, 0);
    heff_take_n(v_x2_2496, 1ULL, 1);
    heff_drop(v_sts_2491);
    heff_drop(v_tl_2492);
    heff_drop(v_val_2494);
    heff_drop(v_cond_2495);
    V f_ = v_op_2493;
    args[0] = v_o_24101;
    args[1] = v_acc_2497;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_TLoop: {
    V v_vs_24102 = heff_field(v_x2_2496, 0);
    heff_take_n(v_x2_2496, 1ULL, 1);
    heff_drop(v_sts_2491);
    heff_drop(v_tl_2492);
    heff_drop(v_op_2493);
    heff_drop(v_cond_2495);
    V v_t_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24102));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam10, 2, 1, (V[]){v_val_2494}); V a_1 = v_acc_2497; V a_2 = v_t_24103; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24103); r_; });
  }
  case TAG_TIf: {
    V v_c_24106 = heff_field(v_x2_2496, 0);
    V v_t_24107 = heff_field(v_x2_2496, 1);
    V v_e_24108 = heff_field(v_x2_2496, 2);
    heff_take_n(v_x2_2496, 7ULL, 3);
    heff_drop(v_sts_2491);
    heff_drop(v_op_2493);
    heff_drop(v_val_2494);
    V v_t_24109 = heff_tr(heff_call(heff_dup(v_tl_2492), 2, (V[]){v_e_24108, v_acc_2497}));
    V v_t_24110 = heff_tr(heff_call(v_tl_2492, 2, (V[]){v_t_24107, v_t_24109}));
    V f_ = v_cond_2495;
    args[0] = v_c_24106;
    args[1] = v_t_24110;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_TCase: {
    V v_v_24111 = heff_field(v_x2_2496, 0);
    V v_arms_24112 = heff_field(v_x2_2496, 1);
    heff_take_n(v_x2_2496, 3ULL, 2);
    heff_drop(v_sts_2491);
    heff_drop(v_op_2493);
    heff_drop(v_cond_2495);
    V v_t_24113 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24112));
    V v_t_24119 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam11, 2, 1, (V[]){v_tl_2492}); V a_1 = v_acc_2497; V a_2 = v_t_24113; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24113); r_; });
    V f_ = v_val_2494;
    args[0] = v_v_24111;
    args[1] = v_t_24119;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return v_acc_241;
  }
  case TAG_PFalse: {
    return v_acc_241;
  }
  case TAG_PRel: {
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    V v_acc_245 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_b_244), v_acc_241));
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_a_243), v_acc_245);
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_v_246), v_acc_241);
  }
  case TAG_PNot: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V t_0 = v_c_247;
    V t_1 = v_acc_241;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_PIf: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_c_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2410), v_acc_241}));
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_b_249), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_a_248), v_t_2412});
  }
  case TAG_PLet: {
    V v_o_2414 = heff_field(v_x2_240, 1);
    V v_c_2415 = heff_field(v_x2_240, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2415), v_acc_241}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_2414), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V v_o_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_242 = heff_dup(heff_field(v_o_240, 0));
    V v_t_243 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_242, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_243});
  }
  case TAG_OCall: {
    V v_args_245 = heff_dup(heff_field(v_o_240, 1));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_245));
    V v_t_247 = ({ V a_0 = v_acc_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_247});
  }
  case TAG_OApply: {
    V v_f_248 = heff_dup(heff_field(v_o_240, 0));
    V v_args_249 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_args_249})));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2411});
  }
  case TAG_OPrim: {
    V v_args_2413 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2413));
    V v_t_2415 = ({ V a_0 = v_acc_241; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2415});
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_acc_241});
  }
  case TAG_OBool: {
    V v_c_2416 = heff_dup(heff_field(v_o_240, 0));
    V v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2416); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2417});
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopNamesTop_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eopNamesTop(V v_o_240) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_241 = heff_field(v_o_240, 0);
    heff_take_n(v_o_240, 1ULL, 1);
    return ({ V a_0 = v_v_241; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_241); r_; });
  }
  case TAG_OCall: {
    V v_args_243 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_OApply: {
    V v_f_245 = heff_field(v_o_240, 0);
    V v_args_246 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OApply = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24o_240_24OApply, TAG_Cons, 2, (V[]){v_f_245, v_args_246})));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  case TAG_OPrim: {
    V v_args_249 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_249));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_o_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopNamesTop(a[0]);
}
V g_heff_2ecompile_2eimperative_2eonceK_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2eonceK_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eonceK_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceK_lam0, 1, 0};
V g_heff_2ecompile_2eimperative_2eonceK_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eonceK_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceK_lam2, 1, 0};
V g_heff_2ecompile_2eimperative_2eonceK_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eonceK_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceK_lam3, 1, 0};
V g_heff_2ecompile_2eimperative_2eonceK_lam4(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eonceK_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceK_lam4, 2, 0};
V g_heff_2ecompile_2eimperative_2eonceK_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2eonceK_lam5(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eonceK_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceK_lam5, 1, 0};

static V g_heff_2ecompile_2eimperative_2eonceK_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2eonceK_st;
static V g_heff_2ecompile_2eimperative_2eonceK_init(void) {
  return heff_rec_n(5, shape_val__op__cond__sts__tl, (V[]){((V)&g_heff_2ecompile_2eimperative_2eonceK_lam0_clo), ((V)&g_heff_2ecompile_2eimperative_2eonceK_lam2_clo), ((V)&g_heff_2ecompile_2eimperative_2eonceK_lam3_clo), ((V)&g_heff_2ecompile_2eimperative_2eonceK_lam4_clo), ((V)&g_heff_2ecompile_2eimperative_2eonceK_lam5_clo)});
}
V g_heff_2ecompile_2eimperative_2eonceK_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2eonceK_st)) return g_heff_2ecompile_2eimperative_2eonceK_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2eonceK_val, &g_heff_2ecompile_2eimperative_2eonceK_st, g_heff_2ecompile_2eimperative_2eonceK_init);
}
V g_heff_2ecompile_2eimperative_2eonceK_lam1(V self, V *args) {
  V v_f_2425 = args[0];
  V v_val_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_dup(heff_field(v_f_2425, 0));
    v_t_2428 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V v_t_2431;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_f_2425, 1);
    heff_take_n(v_f_2425, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V v_t_2432 = heff_tr(heff_call(v_val_243, 1, (V[]){v_t_2431}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_t_2432});
}
V g_heff_2ecompile_2eimperative_2eonceK_lam0(V self, V *args) {
  V v_v_240 = args[0];
  V v_k_241 = heff_dup(g_heff_2ecompile_2eimperative_2eonceK_get());
  V v_tl_242 = heff_take_field(v_k_241, 4);
  V v_val_243 = heff_get_n(v_k_241, 0, 5);
  V v_x2_244 = v_v_240;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_SVar: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SGlobal: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SInt: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SFloat: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SStr: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SBytes: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SFixed: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SFloat32: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SPrimFn: {
    heff_drop(v_tl_242);
    heff_drop(v_val_243);
    return v_x2_244;
  }
  case TAG_SLam: {
    V v_xs_2415 = heff_field(v_x2_244, 0);
    V v_x22_2416 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24SLam = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    heff_drop(v_val_243);
    switch (heff_tag_of(v_x22_2416)) {
    case TAG_MkBlock: {
      V v_t_2417 = heff_field(v_x22_2416, 0);
      V v_ru_24x22_2416_24MkBlock = heff_take_reuse_n(v_x22_2416, 1ULL, 1);
      V v_t_2418 = heff_tr(heff_call(v_tl_242, 1, (V[]){v_t_2417}));
      return heff_tag_at_n(v_ru_24x2_244_24SLam, TAG_SLam, 2, (V[]){v_xs_2415, heff_tag_at_n(v_ru_24x22_2416_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2418})});
    }
    default: return heff_nomatch(v_x22_2416);
    }
  }
  case TAG_STag: {
    V v_tag_2419 = heff_field(v_x2_244, 0);
    V v_args_2420 = heff_field(v_x2_244, 1);
    V v_ts_2421 = heff_field(v_x2_244, 2);
    V v_ru_24x2_244_24STag = heff_take_reuse_n(v_x2_244, 7ULL, 3);
    heff_drop(v_tl_242);
    V v_t_2422 = (g_list_2emap(v_val_243, v_args_2420));
    return heff_tag_at_n(v_ru_24x2_244_24STag, TAG_STag, 3, (V[]){v_tag_2419, v_t_2422, v_ts_2421});
  }
  case TAG_SRec: {
    V v_fs_2423 = heff_field(v_x2_244, 0);
    V v_ts_2424 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24SRec = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    heff_drop(v_tl_242);
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eimperative_2eonceK_lam1, 1, 1, (V[]){v_val_243}), v_fs_2423));
    return heff_tag_at_n(v_ru_24x2_244_24SRec, TAG_SRec, 2, (V[]){v_t_2433, v_ts_2424});
  }
  case TAG_SProj: {
    V v_v_2434 = heff_field(v_x2_244, 0);
    V v_l_2435 = heff_field(v_x2_244, 1);
    V v_ls_2436 = heff_field(v_x2_244, 2);
    V v_t_2437 = heff_field(v_x2_244, 3);
    V v_ru_24x2_244_24SProj = heff_take_reuse_n(v_x2_244, 15ULL, 4);
    heff_drop(v_tl_242);
    V v_t_2438 = heff_tr(heff_call(v_val_243, 1, (V[]){v_v_2434}));
    return heff_tag_at_n(v_ru_24x2_244_24SProj, TAG_SProj, 4, (V[]){v_t_2438, v_l_2435, v_ls_2436, v_t_2437});
  }
  case TAG_SPrim: {
    V v_p_2439 = heff_field(v_x2_244, 0);
    V v_args_2440 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24SPrim = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    heff_drop(v_tl_242);
    V v_t_2441 = (g_list_2emap(v_val_243, v_args_2440));
    return heff_tag_at_n(v_ru_24x2_244_24SPrim, TAG_SPrim, 2, (V[]){v_p_2439, v_t_2441});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2eimperative_2eonceK_lam2(V self, V *args) {
  V v_o_2442 = args[0];
  V v_k_2443 = heff_dup(g_heff_2ecompile_2eimperative_2eonceK_get());
  V v_val_2444 = heff_take_field(v_k_2443, 0);
  V v_cond_2445 = heff_get_n(v_k_2443, 2, 5);
  V v_o_2446 = v_o_2442;
  switch (heff_tag_of(v_o_2446)) {
  case TAG_OSimple: {
    V v_v_2447 = heff_field(v_o_2446, 0);
    V v_ru_24o_2446_24OSimple = heff_take_reuse_n(v_o_2446, 1ULL, 1);
    heff_drop(v_cond_2445);
    V v_t_2448 = heff_tr(heff_call(v_val_2444, 1, (V[]){v_v_2447}));
    return heff_tag_at_n(v_ru_24o_2446_24OSimple, TAG_OSimple, 1, (V[]){v_t_2448});
  }
  case TAG_OCall: {
    V v_g_2449 = heff_field(v_o_2446, 0);
    V v_args_2450 = heff_field(v_o_2446, 1);
    V v_ru_24o_2446_24OCall = heff_take_reuse_n(v_o_2446, 3ULL, 2);
    heff_drop(v_cond_2445);
    V v_t_2451 = (g_list_2emap(v_val_2444, v_args_2450));
    return heff_tag_at_n(v_ru_24o_2446_24OCall, TAG_OCall, 2, (V[]){v_g_2449, v_t_2451});
  }
  case TAG_OApply: {
    V v_f_2452 = heff_field(v_o_2446, 0);
    V v_args_2453 = heff_field(v_o_2446, 1);
    V v_ru_24o_2446_24OApply = heff_take_reuse_n(v_o_2446, 3ULL, 2);
    heff_drop(v_cond_2445);
    V v_t_2454 = heff_tr(heff_call(heff_dup(v_val_2444), 1, (V[]){v_f_2452}));
    V v_t_2455 = (g_list_2emap(v_val_2444, v_args_2453));
    return heff_tag_at_n(v_ru_24o_2446_24OApply, TAG_OApply, 2, (V[]){v_t_2454, v_t_2455});
  }
  case TAG_OPrim: {
    V v_p_2456 = heff_field(v_o_2446, 0);
    V v_args_2457 = heff_field(v_o_2446, 1);
    V v_ru_24o_2446_24OPrim = heff_take_reuse_n(v_o_2446, 3ULL, 2);
    heff_drop(v_cond_2445);
    V v_t_2458 = (g_list_2emap(v_val_2444, v_args_2457));
    return heff_tag_at_n(v_ru_24o_2446_24OPrim, TAG_OPrim, 2, (V[]){v_p_2456, v_t_2458});
  }
  case TAG_OAbandon: {
    heff_drop(v_val_2444);
    heff_drop(v_cond_2445);
    return v_o_2446;
  }
  case TAG_OBool: {
    V v_c_2459 = heff_field(v_o_2446, 0);
    V v_ru_24o_2446_24OBool = heff_take_reuse_n(v_o_2446, 1ULL, 1);
    heff_drop(v_val_2444);
    V v_t_2460 = heff_tr(heff_call(v_cond_2445, 1, (V[]){v_c_2459}));
    return heff_tag_at_n(v_ru_24o_2446_24OBool, TAG_OBool, 1, (V[]){v_t_2460});
  }
  default: return heff_nomatch(v_o_2446);
  }
}
V g_heff_2ecompile_2eimperative_2eonceK_lam3(V self, V *args) {
  V v_c_2461 = args[0];
  V v_k_2462 = heff_dup(g_heff_2ecompile_2eimperative_2eonceK_get());
  V v_val_2463 = heff_take_field(v_k_2462, 0);
  V v_cond_2464 = heff_take_field(v_k_2462, 2);
  V v_op_2465 = heff_get_n(v_k_2462, 1, 5);
  V v_x2_2466 = v_c_2461;
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_PTrue: {
    heff_drop(v_val_2463);
    heff_drop(v_cond_2464);
    heff_drop(v_op_2465);
    return v_x2_2466;
  }
  case TAG_PFalse: {
    heff_drop(v_val_2463);
    heff_drop(v_cond_2464);
    heff_drop(v_op_2465);
    return v_x2_2466;
  }
  case TAG_PRel: {
    V v_p_2467 = heff_field(v_x2_2466, 0);
    V v_a_2468 = heff_field(v_x2_2466, 1);
    V v_b_2469 = heff_field(v_x2_2466, 2);
    V v_ru_24x2_2466_24PRel = heff_take_reuse_n(v_x2_2466, 7ULL, 3);
    heff_drop(v_cond_2464);
    heff_drop(v_op_2465);
    V v_t_2470 = heff_tr(heff_call(heff_dup(v_val_2463), 1, (V[]){v_a_2468}));
    V v_t_2471 = heff_tr(heff_call(v_val_2463, 1, (V[]){v_b_2469}));
    return heff_tag_at_n(v_ru_24x2_2466_24PRel, TAG_PRel, 3, (V[]){v_p_2467, v_t_2470, v_t_2471});
  }
  case TAG_PBool: {
    V v_v_2472 = heff_field(v_x2_2466, 0);
    V v_ru_24x2_2466_24PBool = heff_take_reuse_n(v_x2_2466, 1ULL, 1);
    heff_drop(v_cond_2464);
    heff_drop(v_op_2465);
    V v_t_2473 = heff_tr(heff_call(v_val_2463, 1, (V[]){v_v_2472}));
    return heff_tag_at_n(v_ru_24x2_2466_24PBool, TAG_PBool, 1, (V[]){v_t_2473});
  }
  case TAG_PNot: {
    V v_c_2474 = heff_field(v_x2_2466, 0);
    V v_ru_24x2_2466_24PNot = heff_take_reuse_n(v_x2_2466, 1ULL, 1);
    heff_drop(v_val_2463);
    heff_drop(v_op_2465);
    V v_t_2475 = heff_tr(heff_call(v_cond_2464, 1, (V[]){v_c_2474}));
    return heff_tag_at_n(v_ru_24x2_2466_24PNot, TAG_PNot, 1, (V[]){v_t_2475});
  }
  case TAG_PIf: {
    V v_a_2476 = heff_field(v_x2_2466, 0);
    V v_b_2477 = heff_field(v_x2_2466, 1);
    V v_c_2478 = heff_field(v_x2_2466, 2);
    V v_ru_24x2_2466_24PIf = heff_take_reuse_n(v_x2_2466, 7ULL, 3);
    heff_drop(v_val_2463);
    heff_drop(v_op_2465);
    V v_t_2479 = heff_tr(heff_call(heff_dup(v_cond_2464), 1, (V[]){v_a_2476}));
    V v_t_2480 = heff_tr(heff_call(heff_dup(v_cond_2464), 1, (V[]){v_b_2477}));
    V v_t_2481 = heff_tr(heff_call(v_cond_2464, 1, (V[]){v_c_2478}));
    return heff_tag_at_n(v_ru_24x2_2466_24PIf, TAG_PIf, 3, (V[]){v_t_2479, v_t_2480, v_t_2481});
  }
  case TAG_PLet: {
    V v_x_2482 = heff_field(v_x2_2466, 0);
    V v_o_2483 = heff_field(v_x2_2466, 1);
    V v_c_2484 = heff_field(v_x2_2466, 2);
    V v_ru_24x2_2466_24PLet = heff_take_reuse_n(v_x2_2466, 7ULL, 3);
    heff_drop(v_val_2463);
    V v_t_2485 = heff_tr(heff_call(v_op_2465, 1, (V[]){v_o_2483}));
    V v_t_2486 = heff_tr(heff_call(v_cond_2464, 1, (V[]){v_c_2484}));
    return heff_tag_at_n(v_ru_24x2_2466_24PLet, TAG_PLet, 3, (V[]){v_x_2482, v_t_2485, v_t_2486});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2eimperative_2eonceK_lam4(V self, V *args) {
  V v_ss_2487 = args[0];
  V v_after_2488 = args[1];
  return (g_heff_2ecompile_2eimperative_2eonceSts(heff_dup(g_heff_2ecompile_2eimperative_2eonceK_get()), v_ss_2487, v_after_2488));
}
V g_heff_2ecompile_2eimperative_2eonceK_lam6(V self, V *args) {
  V v_x2_24114 = args[0];
  V v_tl_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkArm: {
    V v_tag_24115 = heff_field(v_x2_24114, 0);
    V v_vs_24116 = heff_field(v_x2_24114, 1);
    V v_b_24117 = heff_field(v_x2_24114, 2);
    V v_ru_24x2_24114_24MkArm = heff_take_reuse_n(v_x2_24114, 7ULL, 3);
    V v_t_24118 = heff_tr(heff_call(v_tl_2492, 1, (V[]){v_b_24117}));
    return heff_tag_at_n(v_ru_24x2_24114_24MkArm, TAG_MkArm, 3, (V[]){v_tag_24115, v_vs_24116, v_t_24118});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2eimperative_2eonceK_lam5(V self, V *args) {
  V v_t_2489 = args[0];
  V v_k_2490 = heff_dup(g_heff_2ecompile_2eimperative_2eonceK_get());
  V v_sts_2491 = heff_take_field(v_k_2490, 3);
  V v_tl_2492 = heff_take_field(v_k_2490, 4);
  V v_op_2493 = heff_take_field(v_k_2490, 1);
  V v_val_2494 = heff_take_field(v_k_2490, 0);
  V v_cond_2495 = heff_get_n(v_k_2490, 2, 5);
  V v_x2_2496 = v_t_2489;
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_TSeq: {
    V v_ss_2497 = heff_field(v_x2_2496, 0);
    V v_t_2498 = heff_field(v_x2_2496, 1);
    V v_ru_24x2_2496_24TSeq = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
    heff_drop(v_op_2493);
    heff_drop(v_val_2494);
    heff_drop(v_cond_2495);
    V v_t_2499 = heff_tr(heff_call(v_sts_2491, 2, (V[]){v_ss_2497, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_2498)})}));
    V v_t_24100 = heff_tr(heff_call(v_tl_2492, 1, (V[]){v_t_2498}));
    return heff_tag_at_n(v_ru_24x2_2496_24TSeq, TAG_TSeq, 2, (V[]){v_t_2499, v_t_24100});
  }
  case TAG_TReturn: {
    V v_o_24101 = heff_field(v_x2_2496, 0);
    V v_ru_24x2_2496_24TReturn = heff_take_reuse_n(v_x2_2496, 1ULL, 1);
    heff_drop(v_sts_2491);
    heff_drop(v_tl_2492);
    heff_drop(v_val_2494);
    heff_drop(v_cond_2495);
    V v_t_24102 = heff_tr(heff_call(v_op_2493, 1, (V[]){v_o_24101}));
    return heff_tag_at_n(v_ru_24x2_2496_24TReturn, TAG_TReturn, 1, (V[]){v_t_24102});
  }
  case TAG_TLoop: {
    V v_vs_24103 = heff_field(v_x2_2496, 0);
    V v_ru_24x2_2496_24TLoop = heff_take_reuse_n(v_x2_2496, 1ULL, 1);
    heff_drop(v_sts_2491);
    heff_drop(v_tl_2492);
    heff_drop(v_op_2493);
    heff_drop(v_cond_2495);
    V v_t_24104 = (g_list_2emap(v_val_2494, v_vs_24103));
    return heff_tag_at_n(v_ru_24x2_2496_24TLoop, TAG_TLoop, 1, (V[]){v_t_24104});
  }
  case TAG_TIf: {
    V v_c_24105 = heff_field(v_x2_2496, 0);
    V v_t_24106 = heff_field(v_x2_2496, 1);
    V v_e_24107 = heff_field(v_x2_2496, 2);
    V v_ru_24x2_2496_24TIf = heff_take_reuse_n(v_x2_2496, 7ULL, 3);
    heff_drop(v_sts_2491);
    heff_drop(v_op_2493);
    heff_drop(v_val_2494);
    V v_t_24108 = heff_tr(heff_call(v_cond_2495, 1, (V[]){v_c_24105}));
    V v_t_24109 = heff_tr(heff_call(heff_dup(v_tl_2492), 1, (V[]){v_t_24106}));
    V v_t_24110 = heff_tr(heff_call(v_tl_2492, 1, (V[]){v_e_24107}));
    return heff_tag_at_n(v_ru_24x2_2496_24TIf, TAG_TIf, 3, (V[]){v_t_24108, v_t_24109, v_t_24110});
  }
  case TAG_TCase: {
    V v_v_24111 = heff_field(v_x2_2496, 0);
    V v_arms_24112 = heff_field(v_x2_2496, 1);
    V v_ru_24x2_2496_24TCase = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
    heff_drop(v_sts_2491);
    heff_drop(v_op_2493);
    heff_drop(v_cond_2495);
    V v_t_24113 = heff_tr(heff_call(v_val_2494, 1, (V[]){v_v_24111}));
    V v_t_24119 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eimperative_2eonceK_lam6, 1, 1, (V[]){v_tl_2492}), v_arms_24112));
    return heff_tag_at_n(v_ru_24x2_2496_24TCase, TAG_TCase, 2, (V[]){v_t_24113, v_t_24119});
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
Clo g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return v_x2_240;
  }
  case TAG_PFalse: {
    return v_x2_240;
  }
  case TAG_PRel: {
    V v_p_241 = heff_field(v_x2_240, 0);
    V v_a_242 = heff_field(v_x2_240, 1);
    V v_b_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PRel = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_a_242));
    V v_t_245 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_b_243));
    return heff_tag_at_n(v_ru_24x2_240_24PRel, TAG_PRel, 3, (V[]){v_p_241, v_t_244, v_t_245});
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PBool = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_v_246));
    return heff_tag_at_n(v_ru_24x2_240_24PBool, TAG_PBool, 1, (V[]){v_t_247});
  }
  case TAG_PNot: {
    V v_c_248 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PNot = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24PNot, TAG_PNot, 1, (V[]){heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps(v_c_248, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_PIf: {
    V v_a_2411 = heff_field(v_x2_240, 0);
    V v_b_2412 = heff_field(v_x2_240, 1);
    V v_c_2413 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PIf = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_a_2411}));
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_b_2412}));
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2413}));
    return heff_tag_at_n(v_ru_24x2_240_24PIf, TAG_PIf, 3, (V[]){v_t_2414, v_t_2415, v_t_2416});
  }
  case TAG_PLet: {
    V v_x_2417 = heff_field(v_x2_240, 0);
    V v_o_2418 = heff_field(v_x2_240, 1);
    V v_c_2419 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PLet = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 1)), 1, (V[]){v_o_2418}));
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2419}));
    return heff_tag_at_n(v_ru_24x2_240_24PLet, TAG_PLet, 3, (V[]){v_x_2417, v_t_2420, v_t_2421});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24TSeq = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(v_ss_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_243)})));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24TSeq, TAG_TSeq, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_t_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_TReturn: {
    V v_o_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = (g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(v_o_247));
    return heff_setField(v_d_241, MK_INT(1LL), heff_tag_n(TAG_TReturn, 1, (V[]){v_t_248}));
  }
  case TAG_TLoop: {
    V v_vs_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_vs_249));
    return heff_setField(v_d_241, MK_INT(1LL), heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2410}));
  }
  case TAG_TIf: {
    V v_c_2411 = heff_field(v_x2_240, 0);
    V v_t_2412 = heff_field(v_x2_240, 1);
    V v_e_2413 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2411}));
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 4)), 1, (V[]){v_t_2412}));
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 4)), 1, (V[]){v_e_2413}));
    return heff_setField(v_d_241, MK_INT(1LL), heff_tag_n(TAG_TIf, 3, (V[]){v_t_2414, v_t_2415, v_t_2416}));
  }
  case TAG_TCase: {
    V v_v_2417 = heff_field(v_x2_240, 0);
    V v_arms_2418 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), 1, (V[]){v_v_2417}));
    V v_t_2420 = (g_list_2emap_24s1155474388x1593011685(v_arms_2418));
    return heff_setField(v_d_241, MK_INT(1LL), heff_tag_n(TAG_TCase, 2, (V[]){v_t_2419, v_t_2420}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps(a[0], a[1]);
}