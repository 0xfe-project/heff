// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_args 9498020
#define LBL_b 316
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_n__args[] = {LBL_n, LBL_args};
static uint32_t shape_xs__b[] = {LBL_xs, LBL_b};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
HeffT2 g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_clo;
V g_heff_2ecompile_2eir_2ewaysOut(V);
V g_heff_2ecompile_2eir_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOut_clo;
V g_heff_2ecompile_2eonce_2ebound(V, V, V);
V g_heff_2ecompile_2eonce_2ebound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ebound_clo;
V g_heff_2ecompile_2eonce_2ebound_24dps(V, V, V, V);
V g_heff_2ecompile_2eonce_2ebound_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ebound_24dps_clo;
V g_heff_2ecompile_2eonce_2ebound_24tok3(V, V, V, V);
V g_heff_2ecompile_2eonce_2ebound_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ebound_24tok3_clo;
V g_heff_2ecompile_2eonce_2ecalleeFresh(V, V, V);
V g_heff_2ecompile_2eonce_2ecalleeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ecalleeFresh_clo;
V g_heff_2ecompile_2eonce_2eeachOnce(V, V);
V g_heff_2ecompile_2eonce_2eeachOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2eeachOnce_clo;
V g_heff_2ecompile_2eonce_2einlined(V, V, V);
V g_heff_2ecompile_2eonce_2einlined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2einlined_clo;
V g_heff_2ecompile_2eonce_2emoved(V, V);
V g_heff_2ecompile_2eonce_2emoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2emoved_clo;
HeffT4 g_heff_2ecompile_2eonce_2esetOf_24cpr(V, V);
V g_heff_2ecompile_2eonce_2eusesW(V, V, V);
V g_heff_2ecompile_2eonce_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2eusesW_clo;
HeffT2 g_heff_2ecompile_2eonce_2evaluesOut_24cpr(V, V, V);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
HeffT2 g_list_2efind_24s2013978071x937269256_24cpr(V, V);
HeffT2 g_list_2efind_24s538188352x1294684142_24cpr(V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s704759456x417074234(V, V, V, V, V);
V g_list_2ezipWith_24s704759456x417074234_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s704759456x417074234_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eonce_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2eusesW_entry, 3, 0};

V g_heff_2ecompile_2eonce_2eusesW(V v_small_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_m_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EGlobal: {
      V v_g_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_small_240, v_g_245));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        V v_t_2416;
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_248;
          heff_drop(v_x_249);
          HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_g_245));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            V v_t_2415;
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_u_2413 = v_field_2412;
              V v_t_2414 = heff_intAdd(heff_take_field(v_u_2413, 0), MK_INT(1LL));
              v_t_2415 = ({ V rv_0 = v_t_2414; V rv_1 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_u_2413, 0ULL, 2, shape_n__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            } else {
              heff_drop(v_field_2412);
              v_t_2415 = heff_rec_n(2, shape_n__args, (V[]){MK_INT(1LL), MK_INT(-1LL)});
            }
            v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_g_245, v_t_2415));
          }
        } else {
          heff_drop(v_g_245);
          heff_drop(v_field_248);
          v_t_2416 = v_m_241;
        }
        V t_0 = v_small_240;
        V t_1 = v_t_2416;
        V t_2 = v_rest_244;
        v_small_240 = t_0;
        v_m_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_x311_2417 = heff_dup(heff_field(v_x31_243, 0));
      switch (heff_tag_of(v_x311_2417)) {
      case TAG_EGlobal: {
        V v_g_2419 = heff_field(v_x311_2417, 0);
        heff_take_n(v_x311_2417, 1ULL, 1);
        switch (heff_tag_of(v_x31_243)) {
        case TAG_EApp: {
          V v_argv_2421 = heff_field(v_x31_243, 1);
          heff_take_n(v_x31_243, 2ULL, 2);
          V v_k_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2421));
          HeffT2 v_t_2423 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_small_240, v_g_2419));
          {
            V v_field_2425 = v_t_2423.f[1];
            int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
            V v_t_2433;
            if ((v_tag_2424 == ((int64_t)0ULL))) {
              V v_x_2426 = v_field_2425;
              heff_drop(v_x_2426);
              HeffT2 v_t_2427 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_g_2419));
              {
                V v_field_2429 = v_t_2427.f[1];
                int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                V v_t_2432;
                if ((v_tag_2428 == ((int64_t)0ULL))) {
                  V v_u_2430 = v_field_2429;
                  V v_t_2431 = heff_intAdd(heff_take_field(v_u_2430, 0), MK_INT(1LL));
                  v_t_2432 = ({ V rv_0 = v_t_2431; V rv_1 = v_k_2422; V rr_ = heff_rec_reuse_nf(v_u_2430, 0ULL, 2, shape_n__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                } else {
                  heff_drop(v_field_2429);
                  v_t_2432 = heff_rec_n(2, shape_n__args, (V[]){MK_INT(1LL), v_k_2422});
                }
                v_t_2433 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_g_2419, v_t_2432));
              }
            } else {
              heff_drop(v_g_2419);
              heff_drop(v_k_2422);
              heff_drop(v_field_2425);
              v_t_2433 = v_m_241;
            }
            V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2421, v_rest_244));
            V t_0 = v_small_240;
            V t_1 = v_t_2433;
            V t_2 = v_t_2434;
            v_small_240 = t_0;
            v_m_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
        }
        default: return heff_nomatch(v_x31_243);
        }
      }
      default: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x311_2417);
        V v_t_2435 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
        V t_0 = v_small_240;
        V t_1 = v_m_241;
        V t_2 = v_t_2435;
        v_small_240 = t_0;
        v_m_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      }
    }
    case TAG_ECall: {
      V v_g_2436 = heff_field(v_x31_243, 0);
      V v_argv_2437 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_k_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2437));
      HeffT2 v_t_2439 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_small_240, v_g_2436));
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        V v_t_2449;
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          V v_x_2442 = v_field_2441;
          heff_drop(v_x_2442);
          HeffT2 v_t_2443 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_g_2436));
          {
            V v_field_2445 = v_t_2443.f[1];
            int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
            V v_t_2448;
            if ((v_tag_2444 == ((int64_t)0ULL))) {
              V v_u_2446 = v_field_2445;
              V v_t_2447 = heff_intAdd(heff_take_field(v_u_2446, 0), MK_INT(1LL));
              v_t_2448 = ({ V rv_0 = v_t_2447; V rv_1 = v_k_2438; V rr_ = heff_rec_reuse_nf(v_u_2446, 0ULL, 2, shape_n__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            } else {
              heff_drop(v_field_2445);
              v_t_2448 = heff_rec_n(2, shape_n__args, (V[]){MK_INT(1LL), v_k_2438});
            }
            v_t_2449 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_g_2436, v_t_2448));
          }
        } else {
          heff_drop(v_g_2436);
          heff_drop(v_k_2438);
          heff_drop(v_field_2441);
          v_t_2449 = v_m_241;
        }
        V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2437, v_rest_244));
        V t_0 = v_small_240;
        V t_1 = v_t_2449;
        V t_2 = v_t_2450;
        v_small_240 = t_0;
        v_m_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2451 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_small_240;
      V t_1 = v_m_241;
      V t_2 = v_t_2451;
      v_small_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eonce_2eusesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eonce_2eusesW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eonce_2ecalleeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ecalleeFresh_entry, 3, 0};

V g_heff_2ecompile_2eonce_2ecalleeFresh(V v_m_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_n_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_g_241, heff_rec_n(2, shape_xs__b, (V[]){v_xs_247, v_b_248})));
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_249, v_n_244});
    }
    case TAG_EApp: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_ELet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EProj: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_ECall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EAbandon: {
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EBool: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_ESet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EValues: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_re_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_m_240, v_n_244});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eonce_2ecalleeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eonce_2ecalleeFresh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eonce_2ebound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ebound_entry, 3, 0};

V g_heff_2ecompile_2eonce_2ebound(V v_x1_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_b_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_b_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_argv_246 = heff_field(v_x2_241, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_243), heff_dup(v_a_245), heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2eonce_2ebound_24dps(v_xs_244, v_argv_246, v_b_242, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eonce_2ebound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eonce_2ebound(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eonce_2ebound_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ebound_24dps_entry, 4, 0};

V g_heff_2ecompile_2eonce_2ebound_24dps(V v_x1_240, V v_x2_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_b_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_b_242);
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_x2_241, 0);
      V v_argv_247 = heff_field(v_x2_241, 1);
      V v_cell_248 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_246), heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_cell_248);
      V t_0 = v_xs_245;
      V t_1 = v_argv_247;
      V t_2 = v_b_242;
      V t_3 = v_u_249;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_b_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eonce_2ebound_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eonce_2ebound_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eonce_2eeachOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2eeachOnce_entry, 2, 0};

V g_heff_2ecompile_2eonce_2eeachOnce(V v_arms_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    V v_x1_244 = (g_list_2eany_24s1006624359x760861690(v_t_242, v_ts_243));
    if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
      heff_drop(v_x1_244);
      HeffT2 v_t_245 = (g_list_2efind_24s2013978071x937269256_24cpr(v_t_242, v_arms_240));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x11_248 = v_field_247;
          heff_drop(v_x11_248);
          V t_0 = v_arms_240;
          V t_1 = v_ts_243;
          v_arms_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_field_247);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_x1_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eonce_2eeachOnce_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eonce_2eeachOnce(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eonce_2emoved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2emoved_entry, 2, 0};

V g_heff_2ecompile_2eonce_2emoved(V v_arms_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    return v_e_241;
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_241, 0);
    V v_argv_2418 = heff_field(v_e_241, 1);
    V v_ts_2419 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_2420 = (g_list_2efind_24s2013978071x937269256_24cpr(v_t_2417, v_arms_240));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        heff_drop(v_t_2417);
        heff_drop(v_ts_2419);
        V v_a_2423 = v_field_2422;
        V v_t_2427;
        switch (heff_tag_of(v_a_2423)) {
        case TAG_MkArm: {
          V v_vs_2425 = heff_dup(heff_field(v_a_2423, 1));
          v_t_2427 = v_vs_2425;
          break;
        }
        default: heff_nomatch(v_a_2423);
        }
        V v_t_2431;
        switch (heff_tag_of(v_a_2423)) {
        case TAG_MkArm: {
          V v_b_2430 = heff_field(v_a_2423, 2);
          heff_take_n(v_a_2423, 4ULL, 3);
          v_t_2431 = v_b_2430;
          break;
        }
        default: heff_nomatch(v_a_2423);
        }
        return ({ V a_0 = v_ru_24e_241_24ETag; V a_1 = v_t_2427; V a_2 = v_argv_2418; V a_3 = v_t_2431; V r_ = (g_heff_2ecompile_2eonce_2ebound_24tok3(a_0, a_1, a_2, a_3)); heff_drop(v_t_2427); heff_drop(v_argv_2418); r_; });
      } else {
        heff_drop(v_field_2422);
        return heff_tag_re_n(v_ru_24e_241_24ETag, TAG_ETag, 3, 7ULL, (V[]){v_t_2417, v_argv_2418, v_ts_2419});
      }
    }
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    return v_e_241;
  }
  case TAG_ESet: {
    return v_e_241;
  }
  case TAG_EValues: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eonce_2emoved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eonce_2emoved(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eonce_2evaluesOut_24cpr(V v_t_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    V v_u_2418 = heff_field(v_e_242, 0);
    V v_argv_2419 = heff_field(v_e_242, 1);
    if ((heff_strEq_c_lent(v_t_240, v_u_2418, 0) && ({ V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2419)); int c_ = heff_intEq_c_lent(v_t_2442, v_n_241, 0); heff_drop(v_t_2442); c_; }))) {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){heff_dup(v_argv_2419)})}});
    } else {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EMatch: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_EAbandon)}});
  }
  case TAG_EBool: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eonce_2esetOf_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eonce_2esetOf_24cpr_str1, 6, "MkLazy");
HEFF_LIT(g_heff_2ecompile_2eonce_2esetOf_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eonce_2esetOf_24cpr_str3, 2, "$_");

HeffT4 g_heff_2ecompile_2eonce_2esetOf_24cpr(V v_s_240, V v_arms_241) {
top: ;
  switch (heff_tag_of(v_arms_241)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_arms1_242 = heff_field(v_arms_241, 0);
    V v_arms2_243 = heff_field(v_arms_241, 1);
    switch (heff_tag_of(v_arms1_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_arms1_242, 0);
      V v_vs_245 = heff_field(v_arms1_242, 1);
      V v_b_246 = heff_field(v_arms1_242, 2);
      switch (heff_tag_of(v_arms2_243)) {
      case TAG_Nil: {
        HeffT2 v_t_247 = ({ V b_0 = ((V)&g_heff_2ecompile_2eonce_2esetOf_24cpr_str0); V a_1 = v_vs_245; HeffT2 r_ = (g_list_2efind_24s538188352x1294684142_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_x_2410 = v_field_249;
            if ((heff_strEq_c(heff_dup(v_t_244), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())) ? 0 : (heff_strEq_c_lent(v_t_244, ((V)&g_heff_2ecompile_2eonce_2esetOf_24cpr_str1), 2) ? 0 : ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_244, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_244, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)))) {
              V v_x1_2411 = (g_heff_2ecompile_2eir_2ewaysOut(heff_dup(v_s_240)));
              V v_t_2414;
              switch (heff_tag_of(v_x1_2411)) {
              case TAG_MkPair: {
                V v_x_2412 = heff_field(v_x1_2411, 0);
                heff_take_n(v_x1_2411, 1ULL, 2);
                v_t_2414 = v_x_2412;
                break;
              }
              default: heff_nomatch(v_x1_2411);
              }
              V v_t_2415 = ({ V a_0 = v_t_244; V a_1 = v_t_2414; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2414); r_; });
              if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                heff_drop(v_t_2415);
                V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_245));
                HeffT2 v_t_2417 = (g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(v_t_244, v_t_2416, v_s_240));
                {
                  V v_field_2419 = v_t_2417.f[1];
                  int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                  if ((v_tag_2418 == ((int64_t)0ULL))) {
                    V v_x_2420 = v_field_2419;
                    V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_245));
                    V v_t_2422 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2421, MK_INT(1LL))));
                    V v_t_2423 = ({ V b_0 = ((V)&g_heff_2ecompile_2eonce_2esetOf_24cpr_str2); V a_1 = v_x_2410; V a_2 = ((V)&g_heff_2ecompile_2eonce_2esetOf_24cpr_str3); V a_3 = heff_dup(v_vs_245); V a_4 = v_t_2422; V r_ = (g_list_2ezipWith_24s704759456x417074234(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
                    return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_t_2423, v_x_2420, heff_dup(v_b_246)}});
                  } else {
                    heff_drop(v_x_2410);
                    heff_drop(v_field_2419);
                    return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop(v_s_240);
                heff_drop(v_x_2410);
                heff_drop(v_t_2415);
                return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_2410);
              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_field_249);
            return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Cons: {
        heff_drop(v_s_240);
        return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
      }
      default: return ((HeffT4){{heff_nomatch(v_arms2_243)}});
      }
    }
    default: return ((HeffT4){{heff_nomatch(v_arms1_242)}});
    }
  }
  default: return ((HeffT4){{heff_nomatch(v_arms_241)}});
  }
}
V g_heff_2ecompile_2eonce_2einlined_lam0(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam1(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam2(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam3(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam4(V self, V *args);
Clo g_heff_2ecompile_2eonce_2einlined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2einlined_entry, 3, 0};

V g_heff_2ecompile_2eonce_2einlined(V v_cs_240, V v_going_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EApp: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EGlobal: {
      V v_g_245 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EGlobal = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_EApp: {
        V v_argv_247 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_argv_249 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam0, 1, 2, (V[]){heff_dup(v_cs_240), heff_dup(v_going_241)}), v_argv_247));
        V v_t_2410 = (g_list_2eany_24s1006624359x760861690(v_g_245, v_going_241));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_going_241);
          heff_drop(v_t_2410);
          return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){heff_tag_re_n(v_ru_24e1_243_24EGlobal, TAG_EGlobal, 1, 1ULL, (V[]){v_g_245}), v_argv_249});
        } else {
          heff_drop(v_t_2410);
          HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_cs_240, v_g_245));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24e1_243_24EGlobal, 1);
              heff_drop_cell(v_ru_24e_242_24EApp, 2);
              V v_c_2414 = v_field_2413;
              V v_b_2415 = heff_take_field(v_c_2414, 1);
              V v_xs_2416 = heff_get_n(v_c_2414, 0, 2);
              V v_t_2417 = (g_heff_2ecompile_2eonce_2einlined(v_cs_240, heff_tag_n(TAG_Cons, 2, (V[]){v_g_245, v_going_241}), v_b_2415));
              return ({ V a_0 = v_xs_2416; V a_1 = v_argv_249; V a_2 = v_t_2417; V r_ = (g_heff_2ecompile_2eonce_2ebound(a_0, a_1, a_2)); heff_drop(v_xs_2416); heff_drop(v_argv_249); r_; });
            } else {
              heff_drop(v_going_241);
              heff_drop(v_field_2413);
              return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){heff_tag_re_n(v_ru_24e1_243_24EGlobal, TAG_EGlobal, 1, 1ULL, (V[]){v_g_245}), v_argv_249});
            }
          }
        }
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    default: {
      heff_drop(v_e1_243);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam1, 2, 2, (V[]){heff_dup(v_cs_240), v_going_241}), v_e_242));
    }
    }
  }
  case TAG_EMatch: {
    V v_s_2420 = heff_field(v_e_242, 0);
    V v_arms_2421 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_e_2424 = (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam2, 2, 2, (V[]){heff_dup(v_cs_240), v_going_241}), heff_tag_re_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_s_2420, v_arms_2421})));
    switch (heff_tag_of(v_e_2424)) {
    case TAG_EVar: {
      return v_e_2424;
    }
    case TAG_EGlobal: {
      return v_e_2424;
    }
    case TAG_ELam: {
      return v_e_2424;
    }
    case TAG_EApp: {
      return v_e_2424;
    }
    case TAG_ELet: {
      return v_e_2424;
    }
    case TAG_ERecord: {
      return v_e_2424;
    }
    case TAG_EProj: {
      return v_e_2424;
    }
    case TAG_ETag: {
      return v_e_2424;
    }
    case TAG_EMatch: {
      V v_s_2443 = heff_field(v_e_2424, 0);
      V v_arms_2444 = heff_field(v_e_2424, 1);
      V v_ru_24e_2424_24EMatch = heff_take_reuse_n(v_e_2424, 3ULL, 2);
      V v_s_2445 = v_s_2443;
      V v_arms_2446 = v_arms_2444;
      V v_x2_2447 = (g_heff_2ecompile_2eir_2ewaysOut(heff_dup(v_s_2445)));
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_MkPair: {
        V v_ts_2448 = heff_field(v_x2_2447, 0);
        V v_n_2449 = heff_field(v_x2_2447, 1);
        heff_take_n(v_x2_2447, 3ULL, 2);
        if (heff_intEq_c(v_n_2449, MK_INT(0LL))) {
          V v_t_2450 = ({ V a_0 = v_arms_2446; V a_1 = v_ts_2448; V r_ = (g_heff_2ecompile_2eonce_2eeachOnce(a_0, a_1)); heff_drop(v_ts_2448); r_; });
          if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e_2424_24EMatch, 2);
            heff_drop(v_t_2450);
            return ({ V a_0 = v_arms_2446; V a_1 = v_s_2445; V r_ = (g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(a_0, a_1)); heff_drop(v_arms_2446); r_; });
          } else {
            heff_drop(v_t_2450);
            HeffT4 v_t_2451 = (g_heff_2ecompile_2eonce_2esetOf_24cpr(heff_dup(v_s_2445), v_arms_2446));
            {
              V v_field_2453 = v_t_2451.f[1];
              V v_field_2454 = v_t_2451.f[2];
              V v_field_2455 = v_t_2451.f[3];
              int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
              if ((v_tag_2452 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24e_2424_24EMatch, 2);
                heff_drop(v_s_2445);
                heff_drop(v_arms_2446);
                V v_x_2456 = heff_tag_n(TAG_ESet, 3, (V[]){v_field_2453, v_field_2454, v_field_2455});
                return v_x_2456;
              } else {
                heff_drop(v_field_2453);
                heff_drop(v_field_2454);
                heff_drop(v_field_2455);
                return heff_tag_at_n(v_ru_24e_2424_24EMatch, TAG_EMatch, 2, (V[]){v_s_2445, v_arms_2446});
              }
            }
          }
        } else {
          heff_drop(v_ts_2448);
          HeffT4 v_t_2457 = (g_heff_2ecompile_2eonce_2esetOf_24cpr(heff_dup(v_s_2445), v_arms_2446));
          {
            V v_field_2459 = v_t_2457.f[1];
            V v_field_2460 = v_t_2457.f[2];
            V v_field_2461 = v_t_2457.f[3];
            int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
            if ((v_tag_2458 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24e_2424_24EMatch, 2);
              heff_drop(v_s_2445);
              heff_drop(v_arms_2446);
              V v_x_2462 = heff_tag_n(TAG_ESet, 3, (V[]){v_field_2459, v_field_2460, v_field_2461});
              return v_x_2462;
            } else {
              heff_drop(v_field_2459);
              heff_drop(v_field_2460);
              heff_drop(v_field_2461);
              return heff_tag_at_n(v_ru_24e_2424_24EMatch, TAG_EMatch, 2, (V[]){v_s_2445, v_arms_2446});
            }
          }
        }
      }
      default: return heff_nomatch(v_x2_2447);
      }
    }
    case TAG_EPrim: {
      return v_e_2424;
    }
    case TAG_EPrimCall: {
      return v_e_2424;
    }
    case TAG_ECall: {
      return v_e_2424;
    }
    case TAG_EInt: {
      return v_e_2424;
    }
    case TAG_EFloat: {
      return v_e_2424;
    }
    case TAG_EStr: {
      return v_e_2424;
    }
    case TAG_EBytes: {
      return v_e_2424;
    }
    case TAG_EFixed: {
      return v_e_2424;
    }
    case TAG_EFloat32: {
      return v_e_2424;
    }
    case TAG_EAbandon: {
      return v_e_2424;
    }
    case TAG_EBool: {
      return v_e_2424;
    }
    case TAG_ESet: {
      return v_e_2424;
    }
    case TAG_EValues: {
      return v_e_2424;
    }
    case TAG_EFix: {
      return v_e_2424;
    }
    default: return heff_nomatch(v_e_2424);
    }
  }
  case TAG_ECall: {
    V v_g_2482 = heff_field(v_e_242, 0);
    V v_argv_2483 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_argv_2485 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam3, 1, 2, (V[]){heff_dup(v_cs_240), heff_dup(v_going_241)}), v_argv_2483));
    V v_t_2486 = (g_list_2eany_24s1006624359x760861690(v_g_2482, v_going_241));
    if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
      heff_drop(v_going_241);
      heff_drop(v_t_2486);
      return heff_tag_re_n(v_ru_24e_242_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2482, v_argv_2485});
    } else {
      heff_drop(v_t_2486);
      HeffT2 v_t_2487 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_cs_240, v_g_2482));
      {
        V v_field_2489 = v_t_2487.f[1];
        int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
        if ((v_tag_2488 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24e_242_24ECall, 2);
          V v_c_2490 = v_field_2489;
          V v_b_2491 = heff_take_field(v_c_2490, 1);
          V v_xs_2492 = heff_get_n(v_c_2490, 0, 2);
          V v_t_2493 = (g_heff_2ecompile_2eonce_2einlined(v_cs_240, heff_tag_n(TAG_Cons, 2, (V[]){v_g_2482, v_going_241}), v_b_2491));
          return ({ V a_0 = v_xs_2492; V a_1 = v_argv_2485; V a_2 = v_t_2493; V r_ = (g_heff_2ecompile_2eonce_2ebound(a_0, a_1, a_2)); heff_drop(v_xs_2492); heff_drop(v_argv_2485); r_; });
        } else {
          heff_drop(v_going_241);
          heff_drop(v_field_2489);
          return heff_tag_re_n(v_ru_24e_242_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2482, v_argv_2485});
        }
      }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam4, 2, 2, (V[]){heff_dup(v_cs_240), v_going_241}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2eonce_2einlined_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eonce_2einlined(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eonce_2einlined_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_a_248; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_2419 = args[1];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_drop(v_x_2418);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_p_2419; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_p_2423 = args[1];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_drop(v_x_2422);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_p_2423; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam3(V self, V *args) {
  V v_a_2484 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_a_2484; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam4(V self, V *args) {
  V v_x_2494 = args[0];
  V v_p_2495 = args[1];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_drop(v_x_2494);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_p_2495; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
Clo g_heff_2ecompile_2eonce_2ebound_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ebound_24tok3_entry, 4, 0};

V g_heff_2ecompile_2eonce_2ebound_24tok3(V v_tok_240, V v_x1_241, V v_x2_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 3);
    return v_b_243;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_241, 0);
    V v_xs_245 = heff_field(v_x1_241, 1);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 3);
      return v_b_243;
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_x2_242, 0);
      V v_argv_247 = heff_field(v_x2_242, 1);
      V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_246), heff_hole()});
      V v_u_249 = (g_heff_2ecompile_2eonce_2ebound_24dps(v_xs_245, v_argv_247, v_b_243, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eonce_2ebound_24tok3_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eonce_2ebound_24tok3(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}