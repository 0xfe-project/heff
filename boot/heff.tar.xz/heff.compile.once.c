// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_args 9498020
#define LBL_b 316
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_n__args[] = {LBL_n, LBL_args};
static uint32_t shape_xs__b[] = {LBL_xs, LBL_b};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_clo;
V g_heff_2ecompile_2eir_2ewaysOut(V);
V g_heff_2ecompile_2eir_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOut_clo;
V g_heff_2ecompile_2eonce_2ebound(V, V, V);
V g_heff_2ecompile_2eonce_2ebound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ebound_clo;
V g_heff_2ecompile_2eonce_2ebound_24dps(V, V, V, V);
V g_heff_2ecompile_2eonce_2ebound_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ebound_24dps_clo;
V g_heff_2ecompile_2eonce_2ebound_24tok3(V, V, V, V);
V g_heff_2ecompile_2eonce_2ebound_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ebound_24tok3_clo;
V g_heff_2ecompile_2eonce_2ecalleeFresh(V, V, V);
V g_heff_2ecompile_2eonce_2ecalleeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2ecalleeFresh_clo;
V g_heff_2ecompile_2eonce_2eeachOnce(V, V);
V g_heff_2ecompile_2eonce_2eeachOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2eeachOnce_clo;
V g_heff_2ecompile_2eonce_2einlined(V, V, V);
V g_heff_2ecompile_2eonce_2einlined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2einlined_clo;
V g_heff_2ecompile_2eonce_2emoved(V, V);
V g_heff_2ecompile_2eonce_2emoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2emoved_clo;
V g_heff_2ecompile_2eonce_2eusesW(V, V, V);
V g_heff_2ecompile_2eonce_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2eusesW_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
HeffT2 g_list_2efind_24s2013978071x937269256_24cpr(V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eonce_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2eusesW_entry, 3, 0};

V g_heff_2ecompile_2eonce_2eusesW(V v_small_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_m_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EGlobal: {
      V v_g_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_small_240, v_g_245));
      V v_t_2416;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_248;
          heff_drop(v_x_249);
          HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_g_245));
          V v_t_2415;
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              V v_u_2413 = v_field_2412;
              V v_t_2414 = heff_intAdd(heff_get_n(v_u_2413, 0, 2), MK_INT(1LL));
              v_t_2415 = heff_rec_n(2, shape_n__args, (V[]){v_t_2414, MK_INT(-1LL)});
            } else {
              heff_drop(v_field_2412);
              v_t_2415 = heff_rec_n(2, shape_n__args, (V[]){MK_INT(1LL), MK_INT(-1LL)});
            }
          }
          v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_g_245, v_t_2415));
        } else {
          heff_drop(v_g_245);
          heff_drop(v_field_248);
          v_t_2416 = v_m_241;
        }
      }
      V t_0 = v_small_240;
      V t_1 = v_t_2416;
      V t_2 = v_rest_244;
      v_small_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_x311_2417 = heff_dup(heff_field(v_x31_243, 0));
      switch (heff_tag_of(v_x311_2417)) {
      case TAG_EGlobal: {
        V v_g_2419 = heff_field(v_x311_2417, 0);
        heff_take_n(v_x311_2417, 1ULL, 1);
        switch (heff_tag_of(v_x31_243)) {
        case TAG_EApp: {
          V v_argv_2421 = heff_field(v_x31_243, 1);
          heff_take_n(v_x31_243, 2ULL, 2);
          V v_k_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2421));
          HeffT2 v_t_2423 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_small_240, v_g_2419));
          V v_t_2433;
          {
            V v_field_2425 = v_t_2423.f[1];
            int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
            if ((v_tag_2424 == ((int64_t)0ULL))) {
              V v_x_2426 = v_field_2425;
              heff_drop(v_x_2426);
              HeffT2 v_t_2427 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_g_2419));
              V v_t_2432;
              {
                V v_field_2429 = v_t_2427.f[1];
                int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                if ((v_tag_2428 == ((int64_t)0ULL))) {
                  V v_u_2430 = v_field_2429;
                  V v_t_2431 = heff_intAdd(heff_get_n(v_u_2430, 0, 2), MK_INT(1LL));
                  v_t_2432 = heff_rec_n(2, shape_n__args, (V[]){v_t_2431, v_k_2422});
                } else {
                  heff_drop(v_field_2429);
                  v_t_2432 = heff_rec_n(2, shape_n__args, (V[]){MK_INT(1LL), v_k_2422});
                }
              }
              v_t_2433 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_g_2419, v_t_2432));
            } else {
              heff_drop(v_g_2419);
              heff_drop(v_k_2422);
              heff_drop(v_field_2425);
              v_t_2433 = v_m_241;
            }
          }
          V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2421, v_rest_244));
          V t_0 = v_small_240;
          V t_1 = v_t_2433;
          V t_2 = v_t_2434;
          v_small_240 = t_0;
          v_m_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x31_243);
        }
      }
      default: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x311_2417);
        V v_t_2435 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
        V t_0 = v_small_240;
        V t_1 = v_m_241;
        V t_2 = v_t_2435;
        v_small_240 = t_0;
        v_m_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      }
    }
    case TAG_ECall: {
      V v_g_2436 = heff_field(v_x31_243, 0);
      V v_argv_2437 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_k_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2437));
      HeffT2 v_t_2439 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_small_240, v_g_2436));
      V v_t_2449;
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          V v_x_2442 = v_field_2441;
          heff_drop(v_x_2442);
          HeffT2 v_t_2443 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_g_2436));
          V v_t_2448;
          {
            V v_field_2445 = v_t_2443.f[1];
            int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
            if ((v_tag_2444 == ((int64_t)0ULL))) {
              V v_u_2446 = v_field_2445;
              V v_t_2447 = heff_intAdd(heff_get_n(v_u_2446, 0, 2), MK_INT(1LL));
              v_t_2448 = heff_rec_n(2, shape_n__args, (V[]){v_t_2447, v_k_2438});
            } else {
              heff_drop(v_field_2445);
              v_t_2448 = heff_rec_n(2, shape_n__args, (V[]){MK_INT(1LL), v_k_2438});
            }
          }
          v_t_2449 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_g_2436, v_t_2448));
        } else {
          heff_drop(v_g_2436);
          heff_drop(v_k_2438);
          heff_drop(v_field_2441);
          v_t_2449 = v_m_241;
        }
      }
      V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2437, v_rest_244));
      V t_0 = v_small_240;
      V t_1 = v_t_2449;
      V t_2 = v_t_2450;
      v_small_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2451 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_small_240;
      V t_1 = v_m_241;
      V t_2 = v_t_2451;
      v_small_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eonce_2eusesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eonce_2eusesW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eonce_2ecalleeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ecalleeFresh_entry, 3, 0};

V g_heff_2ecompile_2eonce_2ecalleeFresh(V v_m_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_n_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_x31_243, 0);
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_g_241, heff_rec_n(2, shape_xs__b, (V[]){v_xs_247, v_b_248})));
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_n_244});
    }
    case TAG_EApp: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_ELet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EProj: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_ECall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EAbandon: {
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EBool: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_ESet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EValues: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_m_240, v_n_244});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eonce_2ecalleeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eonce_2ecalleeFresh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eonce_2ebound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ebound_entry, 3, 0};

V g_heff_2ecompile_2eonce_2ebound(V v_x1_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_b_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_b_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_argv_246 = heff_field(v_x2_241, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_243), heff_dup(v_a_245), heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2eonce_2ebound_24dps(v_xs_244, v_argv_246, v_b_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eonce_2ebound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eonce_2ebound(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eonce_2ebound_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ebound_24dps_entry, 4, 0};

V g_heff_2ecompile_2eonce_2ebound_24dps(V v_x1_240, V v_x2_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(2LL), v_b_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_setField(v_d_243, MK_INT(2LL), v_b_242);
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_x2_241, 0);
      V v_argv_247 = heff_field(v_x2_241, 1);
      V v_cell_248 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_246), heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_245;
      V t_1 = v_argv_247;
      V t_2 = v_b_242;
      V t_3 = v_cell_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_b_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eonce_2ebound_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eonce_2ebound_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eonce_2eeachOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2eeachOnce_entry, 2, 0};

V g_heff_2ecompile_2eonce_2eeachOnce(V v_arms_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    V v_x1_244 = (g_list_2eany_24s1006624359x760861690(v_t_242, v_ts_243));
    if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
      heff_drop(v_x1_244);
      HeffT2 v_t_245 = (g_list_2efind_24s2013978071x937269256_24cpr(v_t_242, v_arms_240));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x11_248 = v_field_247;
          heff_drop(v_x11_248);
          V t_0 = v_arms_240;
          V t_1 = v_ts_243;
          v_arms_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_field_247);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_x1_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eonce_2eeachOnce_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eonce_2eeachOnce(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eonce_2emoved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2emoved_entry, 2, 0};

V g_heff_2ecompile_2eonce_2emoved(V v_arms_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    return v_e_241;
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_241, 0);
    V v_argv_2418 = heff_field(v_e_241, 1);
    V v_ts_2419 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_2420 = (g_list_2efind_24s2013978071x937269256_24cpr(v_t_2417, v_arms_240));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        heff_drop(v_t_2417);
        heff_drop(v_ts_2419);
        V v_a_2423 = v_field_2422;
        V v_t_2427;
        switch (heff_tag_of(v_a_2423)) {
        case TAG_MkArm: {
          V v_vs_2425 = heff_dup(heff_field(v_a_2423, 1));
          v_t_2427 = v_vs_2425;
          break;
        }
        default: heff_nomatch(v_a_2423);
        }
        V v_t_2431;
        switch (heff_tag_of(v_a_2423)) {
        case TAG_MkArm: {
          V v_b_2430 = heff_field(v_a_2423, 2);
          heff_take_n(v_a_2423, 4ULL, 3);
          v_t_2431 = v_b_2430;
          break;
        }
        default: heff_nomatch(v_a_2423);
        }
        return ({ V a_0 = v_ru_24e_241_24ETag; V a_1 = v_t_2427; V a_2 = v_argv_2418; V a_3 = v_t_2431; V r_ = (g_heff_2ecompile_2eonce_2ebound_24tok3(a_0, a_1, a_2, a_3)); heff_drop(v_t_2427); heff_drop(v_argv_2418); r_; });
      } else {
        heff_drop(v_field_2422);
        return heff_tag_at_n(v_ru_24e_241_24ETag, TAG_ETag, 3, (V[]){v_t_2417, v_argv_2418, v_ts_2419});
      }
    }
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    return v_e_241;
  }
  case TAG_ESet: {
    return v_e_241;
  }
  case TAG_EValues: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eonce_2emoved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eonce_2emoved(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eonce_2einlined_lam0(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam1(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam2(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam3(V self, V *args);
V g_heff_2ecompile_2eonce_2einlined_lam4(V self, V *args);
Clo g_heff_2ecompile_2eonce_2einlined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2einlined_entry, 3, 0};

V g_heff_2ecompile_2eonce_2einlined(V v_cs_240, V v_going_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EApp: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EGlobal: {
      V v_g_245 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EGlobal = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_EApp: {
        V v_argv_247 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 2ULL, 2);
        V v_argv_249 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam0, 1, 2, (V[]){heff_dup(v_cs_240), heff_dup(v_going_241)}), v_argv_247));
        V v_t_2410 = (g_list_2eany_24s1006624359x760861690(v_g_245, v_going_241));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_going_241);
          heff_drop(v_t_2410);
          return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_245}), v_argv_249});
        } else {
          heff_drop(v_t_2410);
          HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_cs_240, v_g_245));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24e1_243_24EGlobal, 1);
              heff_drop_cell(v_ru_24e_242_24EApp, 2);
              V v_c_2414 = v_field_2413;
              V v_xs_2415 = heff_take_field(v_c_2414, 0);
              V v_b_2416 = heff_get_n(v_c_2414, 1, 2);
              V v_t_2417 = (g_heff_2ecompile_2eonce_2einlined(v_cs_240, heff_tag_n(TAG_Cons, 2, (V[]){v_g_245, v_going_241}), v_b_2416));
              return ({ V a_0 = v_xs_2415; V a_1 = v_argv_249; V a_2 = v_t_2417; V r_ = (g_heff_2ecompile_2eonce_2ebound(a_0, a_1, a_2)); heff_drop(v_xs_2415); heff_drop(v_argv_249); r_; });
            } else {
              heff_drop(v_going_241);
              heff_drop(v_field_2413);
              return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24e1_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_245}), v_argv_249});
            }
          }
        }
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    default: {
      heff_drop(v_e1_243);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam1, 2, 2, (V[]){heff_dup(v_cs_240), v_going_241}), v_e_242));
    }
    }
  }
  case TAG_EMatch: {
    V v_s_2420 = heff_field(v_e_242, 0);
    V v_arms_2421 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_e_2424 = (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam2, 2, 2, (V[]){heff_dup(v_cs_240), v_going_241}), heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2420, v_arms_2421})));
    switch (heff_tag_of(v_e_2424)) {
    case TAG_EVar: {
      return v_e_2424;
    }
    case TAG_EGlobal: {
      return v_e_2424;
    }
    case TAG_ELam: {
      return v_e_2424;
    }
    case TAG_EApp: {
      return v_e_2424;
    }
    case TAG_ELet: {
      return v_e_2424;
    }
    case TAG_ERecord: {
      return v_e_2424;
    }
    case TAG_EProj: {
      return v_e_2424;
    }
    case TAG_ETag: {
      return v_e_2424;
    }
    case TAG_EMatch: {
      V v_s_2443 = heff_field(v_e_2424, 0);
      V v_arms_2444 = heff_field(v_e_2424, 1);
      V v_ru_24e_2424_24EMatch = heff_take_reuse_n(v_e_2424, 3ULL, 2);
      V v_x2_2445 = (g_heff_2ecompile_2eir_2ewaysOut(heff_dup(v_s_2443)));
      switch (heff_tag_of(v_x2_2445)) {
      case TAG_MkPair: {
        V v_ts_2446 = heff_field(v_x2_2445, 0);
        V v_n_2447 = heff_field(v_x2_2445, 1);
        heff_take_n(v_x2_2445, 3ULL, 2);
        if (heff_intEq_c(v_n_2447, MK_INT(0LL))) {
          V v_t_2448 = ({ V a_0 = v_arms_2444; V a_1 = v_ts_2446; V r_ = (g_heff_2ecompile_2eonce_2eeachOnce(a_0, a_1)); heff_drop(v_ts_2446); r_; });
          if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e_2424_24EMatch, 2);
            heff_drop(v_t_2448);
            return ({ V a_0 = v_arms_2444; V a_1 = v_s_2443; V r_ = (g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(a_0, a_1)); heff_drop(v_arms_2444); r_; });
          } else {
            heff_drop(v_t_2448);
            return heff_tag_at_n(v_ru_24e_2424_24EMatch, TAG_EMatch, 2, (V[]){v_s_2443, v_arms_2444});
          }
        } else {
          heff_drop(v_ts_2446);
          return heff_tag_at_n(v_ru_24e_2424_24EMatch, TAG_EMatch, 2, (V[]){v_s_2443, v_arms_2444});
        }
      }
      default: return heff_nomatch(v_x2_2445);
      }
    }
    case TAG_EPrim: {
      return v_e_2424;
    }
    case TAG_EPrimCall: {
      return v_e_2424;
    }
    case TAG_ECall: {
      return v_e_2424;
    }
    case TAG_EInt: {
      return v_e_2424;
    }
    case TAG_EFloat: {
      return v_e_2424;
    }
    case TAG_EStr: {
      return v_e_2424;
    }
    case TAG_EBytes: {
      return v_e_2424;
    }
    case TAG_EFixed: {
      return v_e_2424;
    }
    case TAG_EFloat32: {
      return v_e_2424;
    }
    case TAG_EAbandon: {
      return v_e_2424;
    }
    case TAG_EBool: {
      return v_e_2424;
    }
    case TAG_ESet: {
      return v_e_2424;
    }
    case TAG_EValues: {
      return v_e_2424;
    }
    case TAG_EFix: {
      return v_e_2424;
    }
    default: return heff_nomatch(v_e_2424);
    }
  }
  case TAG_ECall: {
    V v_g_2468 = heff_field(v_e_242, 0);
    V v_argv_2469 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_argv_2471 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam3, 1, 2, (V[]){heff_dup(v_cs_240), heff_dup(v_going_241)}), v_argv_2469));
    V v_t_2472 = (g_list_2eany_24s1006624359x760861690(v_g_2468, v_going_241));
    if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
      heff_drop(v_going_241);
      heff_drop(v_t_2472);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2468, v_argv_2471});
    } else {
      heff_drop(v_t_2472);
      HeffT2 v_t_2473 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_cs_240, v_g_2468));
      {
        V v_field_2475 = v_t_2473.f[1];
        int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
        if ((v_tag_2474 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24e_242_24ECall, 2);
          V v_c_2476 = v_field_2475;
          V v_xs_2477 = heff_take_field(v_c_2476, 0);
          V v_b_2478 = heff_get_n(v_c_2476, 1, 2);
          V v_t_2479 = (g_heff_2ecompile_2eonce_2einlined(v_cs_240, heff_tag_n(TAG_Cons, 2, (V[]){v_g_2468, v_going_241}), v_b_2478));
          return ({ V a_0 = v_xs_2477; V a_1 = v_argv_2471; V a_2 = v_t_2479; V r_ = (g_heff_2ecompile_2eonce_2ebound(a_0, a_1, a_2)); heff_drop(v_xs_2477); heff_drop(v_argv_2471); r_; });
        } else {
          heff_drop(v_going_241);
          heff_drop(v_field_2475);
          return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2468, v_argv_2471});
        }
      }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eonce_2einlined_lam4, 2, 2, (V[]){heff_dup(v_cs_240), v_going_241}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2eonce_2einlined_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eonce_2einlined(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eonce_2einlined_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_a_248; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_2419 = args[1];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_p_2419; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_p_2423 = args[1];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_p_2423; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam3(V self, V *args) {
  V v_a_2470 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_a_2470; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
V g_heff_2ecompile_2eonce_2einlined_lam4(V self, V *args) {
  V v_x_2480 = args[0];
  V v_p_2481 = args[1];
  V v_cs_240 = heff_env(self)[0];
  V v_going_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2480);
  return ({ V a_0 = v_cs_240; V a_1 = v_going_241; V a_2 = v_p_2481; V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_cs_240); r_; });
}
Clo g_heff_2ecompile_2eonce_2ebound_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eonce_2ebound_24tok3_entry, 4, 0};

V g_heff_2ecompile_2eonce_2ebound_24tok3(V v_tok_240, V v_x1_241, V v_x2_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 3);
    return v_b_243;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_241, 0);
    V v_xs_245 = heff_field(v_x1_241, 1);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 3);
      return v_b_243;
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_x2_242, 0);
      V v_argv_247 = heff_field(v_x2_242, 1);
      V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_246), heff_hole()});
      V v_u_249 = (g_heff_2ecompile_2eonce_2ebound_24dps(v_xs_245, v_argv_247, v_b_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eonce_2ebound_24tok3_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eonce_2ebound_24tok3(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}