// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240(V);
V g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_clo;
V g_std_2ecli_2einteractive_2eslashFrom(V, V);
V g_std_2ecli_2einteractive_2eslashFrom_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslashFrom_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_str0, 1, "/");
HEFF_LIT(g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_str1, 1, "/");
Clo g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_entry, 1, 0};

V g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240(V v_q_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_q_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice_lent(v_q_240, heff_box_word(v_t_241), heff_strLength_lent(v_q_240, 0), 6);
  if (heff_strEq_c(v_t_242, ((V)&g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_str0))) {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_q_240, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240(heff_strSlice(v_q_240, MK_INT(0LL), heff_box_word(v_t_243))));
    return heff_strAppend(v_t_244, ((V)&g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_str1));
  } else {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_q_240, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_std_2ecli_2einteractive_2eslashFrom(v_q_240, heff_box_word(v_t_245)));
    V v_t_247 = heff_strSlice(heff_dup(v_q_240), MK_INT(0LL), heff_intAdd(v_t_246, MK_INT(1LL)));
    return heff_strSlice(heff_dup(v_q_240), heff_strLength(v_t_247), heff_strLength(v_q_240));
  }
}
V g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240(a[0]);
}