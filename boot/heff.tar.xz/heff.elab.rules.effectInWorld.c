// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
V g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240(V, V, V);
V g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
Clo g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240_entry, 3, 0};

V g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240(V v_mc_240, V v_h_241, V v_k_242) {
top: ;
  V v_it_243 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_h_241));
  switch (heff_tag_of(v_it_243)) {
  case TAG_VNeu: {
    V v_it1_244 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 5);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_kh_2410 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_k_242, v_kh_2410, 0));
      heff_drop(v_kh_2410);
      return v_ret_24bool;
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_244, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_it_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_VLam: {
    heff_take_n(v_it_243, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_VCons: {
    heff_take_n(v_it_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eeffectInWorld_2esameEffect_240(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}