// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_again 294104954
#define LBL_body 9524841
#define LBL_bytes 295582853
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_decls 296817955
#define LBL_def 308863
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_falls 298554482
#define LBL_first 298798794
#define LBL_glob 9671231
#define LBL_groups 709681407
#define LBL_home 9703846
#define LBL_hope 9703939
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_lines 304335641
#define LBL_lprotos 613175609
#define LBL_members 1180739419
#define LBL_modified 129625309
#define LBL_mods 9852536
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_refs 9991943
#define LBL_result 1012715336
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_shapes 1043573789
#define LBL_sig 323403
#define LBL_sizes 310811820
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_touched 1244526179
#define LBL_track 311979365
#define LBL_units 312791945
#define LBL_ver 326173
#define LBL_vers 10111479
#define LBL_works 314677148
static uint32_t shape_body__touched[] = {LBL_body, LBL_touched};
static uint32_t shape_def__refs[] = {LBL_def, LBL_refs};
static uint32_t shape_first__hope__falls__again[] = {LBL_first, LBL_hope, LBL_falls, LBL_again};
static uint32_t shape_groups__copies__emits__jss__works[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss, LBL_works};
static uint32_t shape_key__name__body__safe__touched__sgSafe__sgTotal[] = {LBL_key, LBL_name, LBL_body, LBL_safe, LBL_touched, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_key__track__sig__lent[] = {LBL_key, LBL_track, LBL_sig, LBL_lent};
static uint32_t shape_name__home__keys__vers__sizes__tags__lbls__decls__glob__bytes__modified[] = {LBL_name, LBL_home, LBL_keys, LBL_vers, LBL_sizes, LBL_tags, LBL_lbls, LBL_decls, LBL_glob, LBL_bytes, LBL_modified};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
V g_heff_2ebuild_2ebackcache_2eaddCopy(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo;
V g_heff_2ebuild_2ebackcache_2eaddEmit(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo;
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eaddJs(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo;
V g_heff_2ebuild_2ebackcache_2eaddWork(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddWork_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddWork_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V);
HeffT3 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackText(V, V);
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackText_clo;
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
HeffT4 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesOf(V);
V g_heff_2ebuild_2ebackcache_2eentriesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesOf_clo;
HeffT4 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsText_clo;
V g_heff_2ebuild_2ebackcache_2elastDotGo(V, V, V);
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2elentFrom_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2ebackcache_2ememberD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2ememberT(V, V);
V g_heff_2ebuild_2ebackcache_2ememberT_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ememberT_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ebackcache_2epairsGo(V, V);
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2epartD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2epartText(V);
V g_heff_2ebuild_2ebackcache_2epartText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epartText_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2ereprOf_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2esigT(V, V);
V g_heff_2ebuild_2ebackcache_2esigT_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2esigT_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2estampD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ebackcache_2eunitText(V);
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitText_clo;
V g_heff_2ebuild_2ebackcache_2eversion_get(void);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s1097244187x1352538307_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1145270990x1942717591_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1449102187x1886111842_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1905230983x427868326_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s373319101x980263517_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_intShow_get(void);
HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V, V);
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1319961944x1515404846(V, V);
V g_list_2efoldl_24s1319961944x1515404846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1319961944x1515404846_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1378809716x1427336252(V, V);
V g_list_2efoldl_24s1378809716x1427336252_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1378809716x1427336252_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s2047942056x1956366232(V);
V g_list_2emap_24s2047942056x1956366232_entry(V self, V *a);
extern Clo g_list_2emap_24s2047942056x1956366232_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eversion_str0, 15, "heff-backend/17");

static V g_heff_2ebuild_2ebackcache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2eversion_st;
static V g_heff_2ebuild_2ebackcache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2eversion_str0);
}
V g_heff_2ebuild_2ebackcache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2eversion_st)) return g_heff_2ebuild_2ebackcache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2eversion_val, &g_heff_2ebuild_2ebackcache_2eversion_st, g_heff_2ebuild_2ebackcache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str1, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2epairsGo_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2epairsGo(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(v_rest_241);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_rest_244 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_243, v_rest_241));
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_p_242, 0);
      V v_b_246 = heff_field(v_p_242, 1);
      V v_ru_24p_242_24MkPair = heff_take_reuse_n(v_p_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_a_245, 0));
      V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str0)), v_a_245);
      V v_t_249 = heff_intShow(heff_strLength_lent(v_b_246, 0));
      V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str1)), v_b_246);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_tag_at_n(v_ru_24p_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, v_rest_244})});
    }
    default: return heff_nomatch(v_p_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebackcache_2epairsGo(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str1, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str4, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str5, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str6, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str10, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eunitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eunitText(V v_u_240) {
top: ;
  V v_done_241 = heff_take_field(v_u_240, 0);
  V v_name_242 = heff_take_field(v_u_240, 1);
  V v_refs_243 = heff_take_field(v_u_240, 2);
  V v_sgSafe_244 = heff_take_field(v_u_240, 3);
  V v_sgTotal_245 = heff_get_n(v_u_240, 4, 5);
  V v_s_246 = heff_take_field(v_done_241, 0);
  V v_s_247 = v_name_242;
  V v_xs_248 = v_refs_243;
  V v_t_249 = v_sgSafe_244;
  V v_t_2410;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_t_2410 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str0);
  } else {
    heff_drop(v_t_249);
    v_t_2410 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str1);
  }
  V v_x2_2411 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_take_field(v_done_241, 1), NTAG(TAG_Nil)));
  V v_s_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_s_2414 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_s_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_take_field(v_done_241, 2);
  V v_t_2416;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str4);
  } else {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str5);
  }
  V v_ps_2417 = heff_get_n(v_done_241, 3, 4);
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2417));
  V v_t_2419 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_2417, NTAG(TAG_Nil)));
  V v_t_2420 = heff_intShow(heff_strLength_lent(v_s_2414, 0));
  V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str6)), v_s_2414);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_sgTotal_245), v_t_2423});
  V v_rest_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424});
  V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2427 = heff_intShow(v_t_2426);
  V v_t_2428 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2425, v_xs_248));
  V v_t_2429 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str7)), v_s_247);
  V v_t_2431 = heff_intShow(heff_strLength_lent(v_s_246, 0));
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str8)), v_s_246);
  V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str9)), v_t_2430);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str10); V a_1 = v_t_2433; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2428}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eemitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitText(V v_key_240, V v_k_241) {
top: ;
  V v_ver_242 = heff_take_field(v_k_241, 0);
  V v_protos_243 = heff_take_field(v_k_241, 1);
  V v_code_244 = heff_take_field(v_k_241, 2);
  V v_strs_245 = heff_take_field(v_k_241, 3);
  V v_lprotos_246 = heff_take_field(v_k_241, 4);
  V v_lams_247 = heff_take_field(v_k_241, 5);
  V v_shapes_248 = heff_take_field(v_k_241, 6);
  V v_prims_249 = heff_get_n(v_k_241, 7, 8);
  V v_s_2410 = v_ver_242;
  V v_xs_2411 = v_protos_243;
  V v_xs_2412 = v_code_244;
  V v_xs_2413 = v_strs_245;
  V v_xs_2414 = v_lprotos_246;
  V v_xs_2415 = v_lams_247;
  V v_xs_2416 = v_shapes_248;
  V v_xs_2417 = v_prims_249;
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2417));
  V v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2416));
  V v_t_2422 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2420, v_xs_2416));
  V v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2421), v_t_2422});
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2415));
  V v_t_2425 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2423, v_xs_2415));
  V v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2424), v_t_2425});
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2414));
  V v_t_2428 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2426, v_xs_2414));
  V v_rest_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2427), v_t_2428});
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2413));
  V v_t_2431 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2429, v_xs_2413));
  V v_rest_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2430), v_t_2431});
  V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2412));
  V v_t_2434 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2432, v_xs_2412));
  V v_rest_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), v_t_2434});
  V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2437 = heff_intShow(v_t_2436);
  V v_t_2438 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2435, v_xs_2411));
  V v_t_2439 = heff_intShow(heff_strLength_lent(v_s_2410, 0));
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str0)), v_s_2410);
  V v_t_2441 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str1)), v_key_240);
  V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str2)), v_t_2440);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str3); V a_1 = v_t_2443; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2438}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eemitText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epartText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epartText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epartText_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epartText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epartText_str4, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2epartText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2epartText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2epartText(V v_m_240) {
top: ;
  V v_name_241 = heff_take_field(v_m_240, 0);
  V v_home_242 = heff_take_field(v_m_240, 1);
  V v_keys_243 = heff_take_field(v_m_240, 2);
  V v_vers_244 = heff_take_field(v_m_240, 3);
  V v_sizes_245 = heff_take_field(v_m_240, 4);
  V v_tags_246 = heff_take_field(v_m_240, 5);
  V v_lbls_247 = heff_take_field(v_m_240, 6);
  V v_decls_248 = heff_take_field(v_m_240, 7);
  V v_glob_249 = heff_take_field(v_m_240, 8);
  V v_bytes_2410 = heff_take_field(v_m_240, 9);
  V v_modified_2411 = heff_get_n(v_m_240, 10, 11);
  V v_s_2412 = v_name_241;
  V v_s_2413 = v_home_242;
  V v_xs_2414 = v_keys_243;
  V v_xs_2415 = v_vers_244;
  V v_xs_2416 = v_sizes_245;
  V v_xs_2417 = v_tags_246;
  V v_xs_2418 = v_lbls_247;
  V v_xs_2419 = v_decls_248;
  V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2419));
  V v_s_2421 = v_glob_249;
  V v_t_2422 = heff_intShow(heff_strLength_lent(v_s_2421, 0));
  V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ebackcache_2epartText_str0)), v_s_2421);
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_modified_2411), NTAG(TAG_Nil)});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_bytes_2410), v_t_2424});
  V v_t_2426 = (g_prelude_2e_2b_2b_24f1815933030x829523367(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2425}), v_xs_2419));
  V v_rest_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2420), v_t_2426});
  V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
  V v_t_2429 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2427, v_xs_2418));
  V v_rest_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2428), v_t_2429});
  V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
  V v_t_2432 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2430, v_xs_2417));
  V v_rest_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2431), v_t_2432});
  V v_t_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2416));
  V v_t_2435 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_2433, heff_dup(g_intShow_get()), v_xs_2416));
  V v_rest_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2434), v_t_2435});
  V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2415));
  V v_t_2438 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2436, v_xs_2415));
  V v_rest_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2437), v_t_2438});
  V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2414));
  V v_t_2441 = heff_intShow(v_t_2440);
  V v_t_2442 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2439, v_xs_2414));
  V v_t_2443 = heff_intShow(heff_strLength_lent(v_s_2413, 0));
  V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2443, ((V)&g_heff_2ebuild_2ebackcache_2epartText_str1)), v_s_2413);
  V v_t_2445 = heff_intShow(heff_strLength_lent(v_s_2412, 0));
  V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2ebackcache_2epartText_str2)), v_s_2412);
  V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2ebackcache_2epartText_str3)), v_t_2444);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2epartText_str4); V a_1 = v_t_2447; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2442}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2epartText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2epartText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ejsText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsText(V v_key_240, V v_k_241) {
top: ;
  V v_ver_242 = heff_take_field(v_k_241, 0);
  V v_lines_243 = heff_take_field(v_k_241, 1);
  V v_params_244 = heff_take_field(v_k_241, 2);
  V v_refs_245 = heff_take_field(v_k_241, 3);
  V v_prims_246 = heff_get_n(v_k_241, 4, 5);
  V v_s_247 = v_ver_242;
  V v_xs_248 = v_lines_243;
  V v_xs_249 = v_params_244;
  V v_xs_2410 = v_refs_245;
  V v_xs_2411 = v_prims_246;
  V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2413 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2411));
  V v_rest_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2412), v_t_2413});
  V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
  V v_t_2416 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2414, v_xs_2410));
  V v_rest_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), v_t_2416});
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2417, v_xs_249));
  V v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2422 = heff_intShow(v_t_2421);
  V v_t_2423 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2420, v_xs_248));
  V v_t_2424 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str0)), v_s_247);
  V v_t_2426 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str1)), v_key_240);
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str2)), v_t_2425);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str3); V a_1 = v_t_2428; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ejsText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str1, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str2, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str3, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str4, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str9, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str10, 7, "Float64");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str11, 3, "Int");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2esigT_str12, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2esigT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2esigT_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2esigT(V v_s_240, V v_rest_241) {
top: ;
  V v_params_242 = heff_take_field(v_s_240, 0);
  V v_result_243 = heff_get_n(v_s_240, 1, 2);
  V v_xs_244 = (g_list_2emap_24s2090270526x1588636862(v_params_242));
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_244));
  V v_t_246 = (g_list_2emap_24s2047942056x1956366232(v_xs_244));
  V v_t_247 = v_result_243;
  V v_s_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_RepV: {
    v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str0);
    break;
  }
  case TAG_RepFix: {
    V v_w_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    switch (heff_tag_of(v_w_248)) {
    case TAG_I8: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str1);
      break;
    }
    case TAG_I16: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str2);
      break;
    }
    case TAG_I32: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str3);
      break;
    }
    case TAG_I64: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str4);
      break;
    }
    case TAG_U8: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str5);
      break;
    }
    case TAG_U16: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str6);
      break;
    }
    case TAG_U32: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str7);
      break;
    }
    case TAG_U64: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str8);
      break;
    }
    case TAG_F32: {
      v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str9);
      break;
    }
    default: heff_nomatch(v_w_248);
    }
    break;
  }
  case TAG_RepF64: {
    v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str10);
    break;
  }
  case TAG_RepInt: {
    v_s_249 = ((V)&g_heff_2ebuild_2ebackcache_2esigT_str11);
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_intShow(heff_strLength_lent(v_s_249, 0));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ebackcache_2esigT_str12)), v_s_249);
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_rest_241})));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_245), v_t_2412});
}
V g_heff_2ebuild_2ebackcache_2esigT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2esigT(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str1, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str2, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str3, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str4, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str5, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ememberT_str6, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2ememberT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ememberT_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ememberT(V v_m_240, V v_rest_241) {
top: ;
  V v_key_242 = heff_take_field(v_m_240, 0);
  V v_track_243 = heff_take_field(v_m_240, 1);
  V v_sig_244 = heff_take_field(v_m_240, 2);
  V v_lent_245 = heff_get_n(v_m_240, 3, 4);
  V v_s_246 = v_key_242;
  V v_cs_247 = heff_take_field(v_track_243, 0);
  V v_x1_248 = heff_take_field(v_track_243, 1);
  V v_cs_249 = heff_take_field(v_track_243, 2);
  V v_cs_2410 = heff_get_n(v_track_243, 3, 4);
  V v_x1_2411 = v_sig_244;
  V v_t_2412 = v_lent_245;
  V v_rest_2417;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    v_rest_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ememberT_str0), v_rest_241});
    break;
  }
  case TAG_Just: {
    V v_is_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_is_2413));
    V v_t_2415 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_241, heff_dup(g_intShow_get()), v_is_2413));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2415});
    v_rest_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ememberT_str1), v_t_2416});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_rest_2420;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nothing: {
    v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ememberT_str2), v_rest_2417});
    break;
  }
  case TAG_Just: {
    V v_s_2418 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    V v_t_2419 = (g_heff_2ebuild_2ebackcache_2esigT(v_s_2418, v_rest_2417));
    v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ememberT_str3), v_t_2419});
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_2410));
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_2410));
  V v_t_2423 = (g_list_2efoldl_24s1319961944x1515404846(v_rest_2420, v_t_2422));
  V v_rest_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2421), v_t_2423});
  V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_249));
  V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_249));
  V v_t_2427 = (g_list_2efoldl_24s1319961944x1515404846(v_rest_2424, v_t_2426));
  V v_rest_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2427});
  V v_rest_2431;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nothing: {
    v_rest_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ememberT_str4), v_rest_2428});
    break;
  }
  case TAG_Just: {
    V v_s_2429 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    V v_t_2430 = (g_heff_2ebuild_2ebackcache_2esigT(v_s_2429, v_rest_2428));
    v_rest_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ememberT_str5), v_t_2430});
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_247));
  V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_247));
  V v_t_2434 = (g_list_2efoldl_24s1319961944x1515404846(v_rest_2431, v_t_2433));
  V v_t_2435 = heff_intShow(heff_strLength_lent(v_s_246, 0));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ebackcache_2ememberT_str6)), v_s_246);
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2432), v_t_2434});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2437});
}
V g_heff_2ebuild_2ebackcache_2ememberT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ememberT(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eunitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eunitD(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam0, 3, 3, (V[]){v_x_246, v_x_2412, v_x_2424}), v_s_240, v_j_2425));
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args) {
  V v_u_2456 = args[0];
  V v_x_2439 = heff_env(self)[0];
  heff_drop(v_u_2456);
  heff_clo_take(self, 1);
  HeffT3 v_t_2457 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2439, MK_INT(0LL)));
  {
    V v_field_2459 = v_t_2457.f[1];
    V v_field_2460 = v_t_2457.f[2];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_x_2461 = v_field_2459;
      V v_x112_2462 = v_field_2460;
      heff_drop(v_x112_2462);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2461});
    } else {
      heff_drop(v_field_2459);
      heff_drop(v_field_2460);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args) {
  V v_safe_2441 = args[0];
  V v_s_2442 = args[1];
  V v_i_2443 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_sgSafe_2426 = heff_env(self)[3];
  V v_x_2433 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2442, v_i_2443));
  {
    V v_field_2446 = v_t_2444.f[1];
    V v_field_2447 = v_t_2444.f[2];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_x_2448 = v_field_2446;
      V v_j_2449 = v_field_2447;
      HeffT3 v_t_2450 = ({ V a_0 = v_x_2448; V a_1 = v_s_2442; V a_2 = v_j_2449; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(a_0, a_1, a_2)); heff_drop(v_s_2442); r_; });
      {
        V v_field_2452 = v_t_2450.f[1];
        V v_field_2453 = v_t_2450.f[2];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_x_2454 = v_field_2452;
          V v_j_2455 = v_field_2453;
          heff_clo_take(self, 6);
          V v_t_2463 = heff_rec_n(2, shape_def__refs, (V[]){heff_rec_n(7, shape_key__name__body__safe__touched__sgSafe__sgTotal, (V[]){v_x_246, v_x_2412, heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam2, 1, 1, (V[]){v_x_2439}), v_safe_2441, v_x_2454, v_sgSafe_2426, v_x_2433}), v_x_2424});
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_j_2455})});
        } else {
          heff_drop(v_safe_2441);
          heff_drop(self);
          heff_drop(v_field_2452);
          heff_drop(v_field_2453);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_safe_2441);
      heff_drop(v_s_2442);
      heff_drop(self);
      heff_drop(v_field_2446);
      heff_drop(v_field_2447);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args) {
  V v_sgSafe_2426 = args[0];
  V v_s_2427 = args[1];
  V v_i_2428 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  HeffT3 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2427, v_i_2428));
  {
    V v_field_2431 = v_t_2429.f[1];
    V v_field_2432 = v_t_2429.f[2];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_x_2433 = v_field_2431;
      V v_j_2434 = v_field_2432;
      HeffT3 v_t_2435 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_2427), v_j_2434));
      {
        V v_field_2437 = v_t_2435.f[1];
        V v_field_2438 = v_t_2435.f[2];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          V v_x_2439 = v_field_2437;
          V v_j_2440 = v_field_2438;
          heff_clo_take(self, 3);
          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam1, 3, 6, (V[]){v_x_246, v_x_2412, v_x_2439, v_sgSafe_2426, v_x_2433, v_x_2424}), v_s_2427, v_j_2440));
        } else {
          heff_drop(v_sgSafe_2426);
          heff_drop(v_s_2427);
          heff_drop(self);
          heff_drop(v_x_2433);
          heff_drop(v_field_2437);
          heff_drop(v_field_2438);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_sgSafe_2426);
      heff_drop(v_s_2427);
      heff_drop(self);
      heff_drop(v_field_2431);
      heff_drop(v_field_2432);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1, 1, "n");
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args);

HeffT3 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0), 2)) {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            HeffT3 v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_z_241; V a_2 = v_j_2414; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(a_0, a_1, a_2)); heff_drop(v_z_241); r_; });
            {
              V v_field_2417 = v_t_2415.f[1];
              V v_field_2418 = v_t_2415.f[2];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_x_2419 = v_field_2417;
                V v_j_2420 = v_field_2418;
                V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_body__touched, (V[]){heff_clo_n(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0, 1, 1, (V[]){v_x_247}), v_x_2419})});
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2428, v_j_2420}});
              } else {
                heff_drop(v_x_247);
                heff_drop(v_field_2417);
                heff_drop(v_field_2418);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_z_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1), 2)) {
      heff_drop(v_z_241);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nothing), v_z_242}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args) {
  V v_u_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_drop(v_u_2421);
  heff_clo_take(self, 1);
  HeffT3 v_t_2422 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_247, MK_INT(0LL)));
  {
    V v_field_2424 = v_t_2422.f[1];
    V v_field_2425 = v_t_2422.f[2];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x_2426 = v_field_2424;
      V v_x112_2427 = v_field_2425;
      heff_drop(v_x112_2427);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2426});
    } else {
      heff_drop(v_field_2424);
      heff_drop(v_field_2425);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT4 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, v_s_240, v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          HeffT3 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                          {
                            V v_field_2440 = v_t_2438.f[1];
                            V v_field_2441 = v_t_2438.f[2];
                            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                            if ((v_tag_2439 == ((int64_t)0ULL))) {
                              V v_x_2442 = v_field_2440;
                              V v_j_2443 = v_field_2441;
                              HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2442, v_s_240, v_j_2443));
                              {
                                V v_field_2446 = v_t_2444.f[1];
                                V v_field_2447 = v_t_2444.f[2];
                                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                if ((v_tag_2445 == ((int64_t)0ULL))) {
                                  V v_x_2448 = v_field_2446;
                                  V v_j_2449 = v_field_2447;
                                  HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                  {
                                    V v_field_2452 = v_t_2450.f[1];
                                    V v_field_2453 = v_t_2450.f[2];
                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                      V v_x_2454 = v_field_2452;
                                      V v_j_2455 = v_field_2453;
                                      HeffT3 v_t_2456 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2454, v_s_240, v_j_2455));
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        V v_field_2459 = v_t_2456.f[2];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x_2460 = v_field_2458;
                                          V v_j_2461 = v_field_2459;
                                          HeffT3 v_t_2462 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2461));
                                          {
                                            V v_field_2464 = v_t_2462.f[1];
                                            V v_field_2465 = v_t_2462.f[2];
                                            int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                                            if ((v_tag_2463 == ((int64_t)0ULL))) {
                                              V v_x_2466 = v_field_2464;
                                              V v_j_2467 = v_field_2465;
                                              HeffT3 v_t_2468 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2466, v_s_240, v_j_2467));
                                              {
                                                V v_field_2470 = v_t_2468.f[1];
                                                V v_field_2471 = v_t_2468.f[2];
                                                int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                                                if ((v_tag_2469 == ((int64_t)0ULL))) {
                                                  V v_x_2472 = v_field_2470;
                                                  V v_j_2473 = v_field_2471;
                                                  HeffT3 v_t_2474 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2473));
                                                  {
                                                    V v_field_2476 = v_t_2474.f[1];
                                                    V v_field_2477 = v_t_2474.f[2];
                                                    int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
                                                    if ((v_tag_2475 == ((int64_t)0ULL))) {
                                                      V v_x_2478 = v_field_2476;
                                                      V v_j_2479 = v_field_2477;
                                                      HeffT3 v_t_2480 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2478, v_s_240, v_j_2479));
                                                      {
                                                        V v_field_2482 = v_t_2480.f[1];
                                                        V v_field_2483 = v_t_2480.f[2];
                                                        int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                                                        if ((v_tag_2481 == ((int64_t)0ULL))) {
                                                          V v_x_2484 = v_field_2482;
                                                          V v_j_2485 = v_field_2483;
                                                          HeffT3 v_t_2486 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2485));
                                                          {
                                                            V v_field_2488 = v_t_2486.f[1];
                                                            V v_field_2489 = v_t_2486.f[2];
                                                            int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                                                            if ((v_tag_2487 == ((int64_t)0ULL))) {
                                                              V v_x_2490 = v_field_2488;
                                                              V v_j_2491 = v_field_2489;
                                                              HeffT3 v_t_2492 = ({ V a_0 = v_x_2490; V a_1 = v_s_240; V a_2 = v_j_2491; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(a_0, a_1, a_2)); heff_drop(v_s_240); r_; });
                                                              {
                                                                V v_field_2494 = v_t_2492.f[1];
                                                                V v_field_2495 = v_t_2492.f[2];
                                                                int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                                                                if ((v_tag_2493 == ((int64_t)0ULL))) {
                                                                  V v_x_2496 = v_field_2494;
                                                                  V v_j_2497 = v_field_2495;
                                                                  return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_x_246, heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460, v_x_2472, v_x_2484, v_x_2496}), v_j_2497}});
                                                                } else {
                                                                  heff_drop(v_x_246);
                                                                  heff_drop(v_x_2412);
                                                                  heff_drop(v_x_2424);
                                                                  heff_drop(v_x_2436);
                                                                  heff_drop(v_x_2448);
                                                                  heff_drop(v_x_2460);
                                                                  heff_drop(v_x_2472);
                                                                  heff_drop(v_x_2484);
                                                                  heff_drop(v_field_2494);
                                                                  heff_drop(v_field_2495);
                                                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                                }
                                                              }
                                                            } else {
                                                              heff_drop(v_s_240);
                                                              heff_drop(v_x_246);
                                                              heff_drop(v_x_2412);
                                                              heff_drop(v_x_2424);
                                                              heff_drop(v_x_2436);
                                                              heff_drop(v_x_2448);
                                                              heff_drop(v_x_2460);
                                                              heff_drop(v_x_2472);
                                                              heff_drop(v_x_2484);
                                                              heff_drop(v_field_2488);
                                                              heff_drop(v_field_2489);
                                                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                            }
                                                          }
                                                        } else {
                                                          heff_drop(v_s_240);
                                                          heff_drop(v_x_246);
                                                          heff_drop(v_x_2412);
                                                          heff_drop(v_x_2424);
                                                          heff_drop(v_x_2436);
                                                          heff_drop(v_x_2448);
                                                          heff_drop(v_x_2460);
                                                          heff_drop(v_x_2472);
                                                          heff_drop(v_field_2482);
                                                          heff_drop(v_field_2483);
                                                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    } else {
                                                      heff_drop(v_s_240);
                                                      heff_drop(v_x_246);
                                                      heff_drop(v_x_2412);
                                                      heff_drop(v_x_2424);
                                                      heff_drop(v_x_2436);
                                                      heff_drop(v_x_2448);
                                                      heff_drop(v_x_2460);
                                                      heff_drop(v_x_2472);
                                                      heff_drop(v_field_2476);
                                                      heff_drop(v_field_2477);
                                                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  heff_drop(v_s_240);
                                                  heff_drop(v_x_246);
                                                  heff_drop(v_x_2412);
                                                  heff_drop(v_x_2424);
                                                  heff_drop(v_x_2436);
                                                  heff_drop(v_x_2448);
                                                  heff_drop(v_x_2460);
                                                  heff_drop(v_field_2470);
                                                  heff_drop(v_field_2471);
                                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              heff_drop(v_s_240);
                                              heff_drop(v_x_246);
                                              heff_drop(v_x_2412);
                                              heff_drop(v_x_2424);
                                              heff_drop(v_x_2436);
                                              heff_drop(v_x_2448);
                                              heff_drop(v_x_2460);
                                              heff_drop(v_field_2464);
                                              heff_drop(v_field_2465);
                                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_s_240);
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2412);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_x_2448);
                                          heff_drop(v_field_2458);
                                          heff_drop(v_field_2459);
                                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_240);
                                      heff_drop(v_x_246);
                                      heff_drop(v_x_2412);
                                      heff_drop(v_x_2424);
                                      heff_drop(v_x_2436);
                                      heff_drop(v_x_2448);
                                      heff_drop(v_field_2452);
                                      heff_drop(v_field_2453);
                                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_240);
                                  heff_drop(v_x_246);
                                  heff_drop(v_x_2412);
                                  heff_drop(v_x_2424);
                                  heff_drop(v_x_2436);
                                  heff_drop(v_field_2446);
                                  heff_drop(v_field_2447);
                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_240);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2412);
                              heff_drop(v_x_2424);
                              heff_drop(v_x_2436);
                              heff_drop(v_field_2440);
                              heff_drop(v_field_2441);
                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2424);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2424);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}

HeffT4 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, v_s_240, v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          HeffT3 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                          {
                            V v_field_2440 = v_t_2438.f[1];
                            V v_field_2441 = v_t_2438.f[2];
                            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                            if ((v_tag_2439 == ((int64_t)0ULL))) {
                              V v_x_2442 = v_field_2440;
                              V v_j_2443 = v_field_2441;
                              HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2442, v_s_240, v_j_2443));
                              {
                                V v_field_2446 = v_t_2444.f[1];
                                V v_field_2447 = v_t_2444.f[2];
                                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                if ((v_tag_2445 == ((int64_t)0ULL))) {
                                  V v_x_2448 = v_field_2446;
                                  V v_j_2449 = v_field_2447;
                                  HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                  {
                                    V v_field_2452 = v_t_2450.f[1];
                                    V v_field_2453 = v_t_2450.f[2];
                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                      V v_x_2454 = v_field_2452;
                                      V v_j_2455 = v_field_2453;
                                      HeffT3 v_t_2456 = ({ V a_0 = v_x_2454; V a_1 = v_s_240; V a_2 = v_j_2455; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(a_0, a_1, a_2)); heff_drop(v_s_240); r_; });
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        V v_field_2459 = v_t_2456.f[2];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x_2460 = v_field_2458;
                                          V v_j_2461 = v_field_2459;
                                          return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_x_246, heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460}), v_j_2461}});
                                        } else {
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2412);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_x_2448);
                                          heff_drop(v_field_2458);
                                          heff_drop(v_field_2459);
                                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_240);
                                      heff_drop(v_x_246);
                                      heff_drop(v_x_2412);
                                      heff_drop(v_x_2424);
                                      heff_drop(v_x_2436);
                                      heff_drop(v_x_2448);
                                      heff_drop(v_field_2452);
                                      heff_drop(v_field_2453);
                                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_240);
                                  heff_drop(v_x_246);
                                  heff_drop(v_x_2412);
                                  heff_drop(v_x_2424);
                                  heff_drop(v_x_2436);
                                  heff_drop(v_field_2446);
                                  heff_drop(v_field_2447);
                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_240);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2412);
                              heff_drop(v_x_2424);
                              heff_drop(v_x_2436);
                              heff_drop(v_field_2440);
                              heff_drop(v_field_2441);
                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2424);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2424);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}

HeffT3 g_heff_2ebuild_2ebackcache_2epartD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, v_s_240, v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          HeffT3 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                          {
                            V v_field_2440 = v_t_2438.f[1];
                            V v_field_2441 = v_t_2438.f[2];
                            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                            if ((v_tag_2439 == ((int64_t)0ULL))) {
                              V v_x_2442 = v_field_2440;
                              V v_j_2443 = v_field_2441;
                              HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1449102187x1886111842_24cpr(v_x_2442, v_s_240, v_j_2443));
                              {
                                V v_field_2446 = v_t_2444.f[1];
                                V v_field_2447 = v_t_2444.f[2];
                                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                if ((v_tag_2445 == ((int64_t)0ULL))) {
                                  V v_x_2448 = v_field_2446;
                                  V v_j_2449 = v_field_2447;
                                  HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                  {
                                    V v_field_2452 = v_t_2450.f[1];
                                    V v_field_2453 = v_t_2450.f[2];
                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                      V v_x_2454 = v_field_2452;
                                      V v_j_2455 = v_field_2453;
                                      HeffT3 v_t_2456 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2454, v_s_240, v_j_2455));
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        V v_field_2459 = v_t_2456.f[2];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x_2460 = v_field_2458;
                                          V v_j_2461 = v_field_2459;
                                          HeffT3 v_t_2462 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2461));
                                          {
                                            V v_field_2464 = v_t_2462.f[1];
                                            V v_field_2465 = v_t_2462.f[2];
                                            int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                                            if ((v_tag_2463 == ((int64_t)0ULL))) {
                                              V v_x_2466 = v_field_2464;
                                              V v_j_2467 = v_field_2465;
                                              HeffT3 v_t_2468 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2466, v_s_240, v_j_2467));
                                              {
                                                V v_field_2470 = v_t_2468.f[1];
                                                V v_field_2471 = v_t_2468.f[2];
                                                int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                                                if ((v_tag_2469 == ((int64_t)0ULL))) {
                                                  V v_x_2472 = v_field_2470;
                                                  V v_j_2473 = v_field_2471;
                                                  HeffT3 v_t_2474 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2473));
                                                  {
                                                    V v_field_2476 = v_t_2474.f[1];
                                                    V v_field_2477 = v_t_2474.f[2];
                                                    int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
                                                    if ((v_tag_2475 == ((int64_t)0ULL))) {
                                                      V v_x_2478 = v_field_2476;
                                                      V v_j_2479 = v_field_2477;
                                                      HeffT3 v_t_2480 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2478, v_s_240, v_j_2479));
                                                      {
                                                        V v_field_2482 = v_t_2480.f[1];
                                                        V v_field_2483 = v_t_2480.f[2];
                                                        int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                                                        if ((v_tag_2481 == ((int64_t)0ULL))) {
                                                          V v_x_2484 = v_field_2482;
                                                          V v_j_2485 = v_field_2483;
                                                          HeffT3 v_t_2486 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_2485));
                                                          {
                                                            V v_field_2488 = v_t_2486.f[1];
                                                            V v_field_2489 = v_t_2486.f[2];
                                                            int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                                                            if ((v_tag_2487 == ((int64_t)0ULL))) {
                                                              V v_x_2490 = v_field_2488;
                                                              V v_j_2491 = v_field_2489;
                                                              HeffT3 v_t_2492 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2491));
                                                              {
                                                                V v_field_2494 = v_t_2492.f[1];
                                                                V v_field_2495 = v_t_2492.f[2];
                                                                int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                                                                if ((v_tag_2493 == ((int64_t)0ULL))) {
                                                                  V v_x_2496 = v_field_2494;
                                                                  V v_j_2497 = v_field_2495;
                                                                  HeffT3 v_t_2498 = ({ V a_0 = v_s_240; V a_1 = v_j_2497; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_s_240); r_; });
                                                                  {
                                                                    V v_field_24100 = v_t_2498.f[1];
                                                                    V v_field_24101 = v_t_2498.f[2];
                                                                    int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
                                                                    if ((v_tag_2499 == ((int64_t)0ULL))) {
                                                                      V v_x_24102 = v_field_24100;
                                                                      V v_j_24103 = v_field_24101;
                                                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(11, shape_name__home__keys__vers__sizes__tags__lbls__decls__glob__bytes__modified, (V[]){v_x_246, v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460, v_x_2472, v_x_2484, v_x_2490, v_x_2496, v_x_24102}), v_j_24103}});
                                                                    } else {
                                                                      heff_drop(v_x_246);
                                                                      heff_drop(v_x_2412);
                                                                      heff_drop(v_x_2424);
                                                                      heff_drop(v_x_2436);
                                                                      heff_drop(v_x_2448);
                                                                      heff_drop(v_x_2460);
                                                                      heff_drop(v_x_2472);
                                                                      heff_drop(v_x_2484);
                                                                      heff_drop(v_x_2490);
                                                                      heff_drop(v_x_2496);
                                                                      heff_drop(v_field_24100);
                                                                      heff_drop(v_field_24101);
                                                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                                    }
                                                                  }
                                                                } else {
                                                                  heff_drop(v_s_240);
                                                                  heff_drop(v_x_246);
                                                                  heff_drop(v_x_2412);
                                                                  heff_drop(v_x_2424);
                                                                  heff_drop(v_x_2436);
                                                                  heff_drop(v_x_2448);
                                                                  heff_drop(v_x_2460);
                                                                  heff_drop(v_x_2472);
                                                                  heff_drop(v_x_2484);
                                                                  heff_drop(v_x_2490);
                                                                  heff_drop(v_field_2494);
                                                                  heff_drop(v_field_2495);
                                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                                }
                                                              }
                                                            } else {
                                                              heff_drop(v_s_240);
                                                              heff_drop(v_x_246);
                                                              heff_drop(v_x_2412);
                                                              heff_drop(v_x_2424);
                                                              heff_drop(v_x_2436);
                                                              heff_drop(v_x_2448);
                                                              heff_drop(v_x_2460);
                                                              heff_drop(v_x_2472);
                                                              heff_drop(v_x_2484);
                                                              heff_drop(v_field_2488);
                                                              heff_drop(v_field_2489);
                                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                            }
                                                          }
                                                        } else {
                                                          heff_drop(v_s_240);
                                                          heff_drop(v_x_246);
                                                          heff_drop(v_x_2412);
                                                          heff_drop(v_x_2424);
                                                          heff_drop(v_x_2436);
                                                          heff_drop(v_x_2448);
                                                          heff_drop(v_x_2460);
                                                          heff_drop(v_x_2472);
                                                          heff_drop(v_field_2482);
                                                          heff_drop(v_field_2483);
                                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    } else {
                                                      heff_drop(v_s_240);
                                                      heff_drop(v_x_246);
                                                      heff_drop(v_x_2412);
                                                      heff_drop(v_x_2424);
                                                      heff_drop(v_x_2436);
                                                      heff_drop(v_x_2448);
                                                      heff_drop(v_x_2460);
                                                      heff_drop(v_x_2472);
                                                      heff_drop(v_field_2476);
                                                      heff_drop(v_field_2477);
                                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  heff_drop(v_s_240);
                                                  heff_drop(v_x_246);
                                                  heff_drop(v_x_2412);
                                                  heff_drop(v_x_2424);
                                                  heff_drop(v_x_2436);
                                                  heff_drop(v_x_2448);
                                                  heff_drop(v_x_2460);
                                                  heff_drop(v_field_2470);
                                                  heff_drop(v_field_2471);
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              heff_drop(v_s_240);
                                              heff_drop(v_x_246);
                                              heff_drop(v_x_2412);
                                              heff_drop(v_x_2424);
                                              heff_drop(v_x_2436);
                                              heff_drop(v_x_2448);
                                              heff_drop(v_x_2460);
                                              heff_drop(v_field_2464);
                                              heff_drop(v_field_2465);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_s_240);
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2412);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_x_2448);
                                          heff_drop(v_field_2458);
                                          heff_drop(v_field_2459);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_240);
                                      heff_drop(v_x_246);
                                      heff_drop(v_x_2412);
                                      heff_drop(v_x_2424);
                                      heff_drop(v_x_2436);
                                      heff_drop(v_x_2448);
                                      heff_drop(v_field_2452);
                                      heff_drop(v_field_2453);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_240);
                                  heff_drop(v_x_246);
                                  heff_drop(v_x_2412);
                                  heff_drop(v_x_2424);
                                  heff_drop(v_x_2436);
                                  heff_drop(v_field_2446);
                                  heff_drop(v_field_2447);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_240);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2412);
                              heff_drop(v_x_2424);
                              heff_drop(v_x_2436);
                              heff_drop(v_field_2440);
                              heff_drop(v_field_2441);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2424);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2424);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2estampD_24cpr_str0, 3, "end");

HeffT3 g_heff_2ebuild_2ebackcache_2estampD_24cpr(V v_id_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_241), v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      if (heff_strEq_c(v_x_247, heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()))) {
        V v_x_249 = NTAG(TAG_MkUnit);
        V v_j_2410 = v_j_248;
        HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_241), v_j_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            V v_j_2416 = v_field_2414;
            if (heff_strEq_c_lent(v_x_2415, v_id_240, 1)) {
              HeffT3 v_t_2417 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2416));
              {
                V v_field_2419 = v_t_2417.f[1];
                V v_field_2420 = v_t_2417.f[2];
                int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                if ((v_tag_2418 == ((int64_t)0ULL))) {
                  V v_x_2421 = v_field_2419;
                  V v_j_2422 = v_field_2420;
                  HeffT3 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s1905230983x427868326_24cpr(v_x_2421, v_s_241, v_j_2422));
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    V v_field_2426 = v_t_2423.f[2];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      V v_x_2427 = v_field_2425;
                      V v_j_2428 = v_field_2426;
                      HeffT3 v_t_2429 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_j_2428));
                      {
                        V v_field_2431 = v_t_2429.f[1];
                        V v_field_2432 = v_t_2429.f[2];
                        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                        if ((v_tag_2430 == ((int64_t)0ULL))) {
                          V v_x_2433 = v_field_2431;
                          V v_j_2434 = v_field_2432;
                          if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ebackcache_2estampD_24cpr_str0))) {
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_2427, v_j_2434}});
                          } else {
                            heff_drop(v_x_2427);
                            heff_drop(v_j_2434);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        } else {
                          heff_drop(v_x_2427);
                          heff_drop(v_field_2431);
                          heff_drop(v_field_2432);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_241);
                      heff_drop(v_field_2425);
                      heff_drop(v_field_2426);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_241);
                  heff_drop(v_field_2419);
                  heff_drop(v_field_2420);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_241);
              heff_drop(v_j_2416);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_s_241);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_s_241);
        heff_drop(v_j_248);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str1, 7, "Float64");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str2, 3, "Int");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str3, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str4, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str5, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str6, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str11, 7, "Float32");

HeffT3 g_heff_2ebuild_2ebackcache_2ereprOf_24cpr(V v_x_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str0), 2)) {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_RepV), v_z_242}});
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str1), 2)) {
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_RepF64), v_z_242}});
    } else {
      if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str2), 2)) {
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_RepInt), v_z_242}});
      } else {
        HeffT2 v_t_243 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str3); V a_1 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str4); V a_2 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str5); V a_3 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str6); V a_4 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str7); V a_5 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str8); V a_6 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str9); V a_7 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str10); V a_8 = ((V)&g_heff_2ebuild_2ebackcache_2ereprOf_24cpr_str11); V a_9 = v_x_240; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
        {
          V v_field_245 = v_t_243.f[1];
          int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
          if ((v_tag_244 == ((int64_t)0ULL))) {
            V v_w_246 = v_field_245;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_RepFix, 1, (V[]){v_w_246}), v_z_242}});
          } else {
            heff_drop(v_field_245);
            return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2elentFrom_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2elentFrom_24cpr_str1, 1, "n");

HeffT3 g_heff_2ebuild_2ebackcache_2elentFrom_24cpr(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2elentFrom_24cpr_str0), 2)) {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1449102187x1886111842_24cpr(v_x_247, v_z_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Just, 1, (V[]){v_x_2413}), v_j_2414}});
          } else {
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2elentFrom_24cpr_str1), 2)) {
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nothing), v_z_242}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    }
  }
}

HeffT3 g_heff_2ebuild_2ebackcache_2ememberD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2etimes_24s1145270990x1942717591_24cpr(v_x_2412, v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2ebind_24s1097244187x1352538307_24cpr(heff_dup(v_s_240), v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1145270990x1942717591_24cpr(v_x_2430, v_s_240, v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          HeffT3 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                          {
                            V v_field_2440 = v_t_2438.f[1];
                            V v_field_2441 = v_t_2438.f[2];
                            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                            if ((v_tag_2439 == ((int64_t)0ULL))) {
                              V v_x_2442 = v_field_2440;
                              V v_j_2443 = v_field_2441;
                              HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1145270990x1942717591_24cpr(v_x_2442, v_s_240, v_j_2443));
                              {
                                V v_field_2446 = v_t_2444.f[1];
                                V v_field_2447 = v_t_2444.f[2];
                                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                if ((v_tag_2445 == ((int64_t)0ULL))) {
                                  V v_x_2448 = v_field_2446;
                                  V v_j_2449 = v_field_2447;
                                  HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2ebind_24s1097244187x1352538307_24cpr(heff_dup(v_s_240), v_j_2449));
                                  {
                                    V v_field_2452 = v_t_2450.f[1];
                                    V v_field_2453 = v_t_2450.f[2];
                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                      V v_x_2454 = v_field_2452;
                                      V v_j_2455 = v_field_2453;
                                      HeffT3 v_t_2456 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_j_2455));
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        V v_field_2459 = v_t_2456.f[2];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x_2460 = v_field_2458;
                                          V v_j_2461 = v_field_2459;
                                          HeffT3 v_t_2462 = ({ V a_0 = v_x_2460; V a_1 = v_s_240; V a_2 = v_j_2461; HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2elentFrom_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2460); heff_drop(v_s_240); r_; });
                                          {
                                            V v_field_2464 = v_t_2462.f[1];
                                            V v_field_2465 = v_t_2462.f[2];
                                            int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                                            if ((v_tag_2463 == ((int64_t)0ULL))) {
                                              V v_x_2466 = v_field_2464;
                                              V v_j_2467 = v_field_2465;
                                              V v_t_2468 = heff_rec_n(4, shape_key__track__sig__lent, (V[]){v_x_246, heff_rec_n(4, shape_first__hope__falls__again, (V[]){v_x_2418, v_x_2424, v_x_2436, v_x_2448}), v_x_2454, v_x_2466});
                                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2468, v_j_2467}});
                                            } else {
                                              heff_drop(v_x_246);
                                              heff_drop(v_x_2418);
                                              heff_drop(v_x_2424);
                                              heff_drop(v_x_2436);
                                              heff_drop(v_x_2448);
                                              heff_drop(v_x_2454);
                                              heff_drop(v_field_2464);
                                              heff_drop(v_field_2465);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_s_240);
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2418);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_x_2448);
                                          heff_drop(v_x_2454);
                                          heff_drop(v_field_2458);
                                          heff_drop(v_field_2459);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_240);
                                      heff_drop(v_x_246);
                                      heff_drop(v_x_2418);
                                      heff_drop(v_x_2424);
                                      heff_drop(v_x_2436);
                                      heff_drop(v_x_2448);
                                      heff_drop(v_field_2452);
                                      heff_drop(v_field_2453);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_240);
                                  heff_drop(v_x_246);
                                  heff_drop(v_x_2418);
                                  heff_drop(v_x_2424);
                                  heff_drop(v_x_2436);
                                  heff_drop(v_field_2446);
                                  heff_drop(v_field_2447);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_240);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2418);
                              heff_drop(v_x_2424);
                              heff_drop(v_x_2436);
                              heff_drop(v_field_2440);
                              heff_drop(v_field_2441);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2418);
                          heff_drop(v_x_2424);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2418);
                      heff_drop(v_x_2424);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2418);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_REC_LIT(g_heff_2ebuild_2ebackcache_2enoBack_lit0, 5, shape_groups__copies__emits__jss__works, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2ebuild_2ebackcache_2enoBack_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2enoBack_st;
static V g_heff_2ebuild_2ebackcache_2enoBack_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2enoBack_lit0);
}
V g_heff_2ebuild_2ebackcache_2enoBack_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2enoBack_st)) return g_heff_2ebuild_2ebackcache_2enoBack_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2enoBack_val, &g_heff_2ebuild_2ebackcache_2enoBack_st, g_heff_2ebuild_2ebackcache_2enoBack_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0, 3, "end");

HeffT3 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V v_id_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_241), v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      if (heff_strEq_c(v_x_247, heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()))) {
        V v_x_249 = NTAG(TAG_MkUnit);
        V v_j_2410 = v_j_248;
        HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_241), v_j_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            V v_j_2416 = v_field_2414;
            if (heff_strEq_c_lent(v_x_2415, v_id_240, 1)) {
              HeffT3 v_t_2417 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2416));
              {
                V v_field_2419 = v_t_2417.f[1];
                V v_field_2420 = v_t_2417.f[2];
                int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                if ((v_tag_2418 == ((int64_t)0ULL))) {
                  V v_x_2421 = v_field_2419;
                  V v_j_2422 = v_field_2420;
                  HeffT3 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(v_x_2421, v_s_241, v_j_2422));
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    V v_field_2426 = v_t_2423.f[2];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      V v_x_2427 = v_field_2425;
                      V v_j_2428 = v_field_2426;
                      HeffT3 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2428));
                      {
                        V v_field_2431 = v_t_2429.f[1];
                        V v_field_2432 = v_t_2429.f[2];
                        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                        if ((v_tag_2430 == ((int64_t)0ULL))) {
                          V v_x_2433 = v_field_2431;
                          V v_j_2434 = v_field_2432;
                          HeffT3 v_t_2435 = (g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(v_x_2433, v_s_241, v_j_2434));
                          {
                            V v_field_2437 = v_t_2435.f[1];
                            V v_field_2438 = v_t_2435.f[2];
                            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                            if ((v_tag_2436 == ((int64_t)0ULL))) {
                              V v_x_2439 = v_field_2437;
                              V v_j_2440 = v_field_2438;
                              HeffT3 v_t_2441 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2440));
                              {
                                V v_field_2443 = v_t_2441.f[1];
                                V v_field_2444 = v_t_2441.f[2];
                                int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                                if ((v_tag_2442 == ((int64_t)0ULL))) {
                                  V v_x_2445 = v_field_2443;
                                  V v_j_2446 = v_field_2444;
                                  HeffT3 v_t_2447 = (g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(v_x_2445, v_s_241, v_j_2446));
                                  {
                                    V v_field_2449 = v_t_2447.f[1];
                                    V v_field_2450 = v_t_2447.f[2];
                                    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                                    if ((v_tag_2448 == ((int64_t)0ULL))) {
                                      V v_x_2451 = v_field_2449;
                                      V v_j_2452 = v_field_2450;
                                      HeffT3 v_t_2453 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2452));
                                      {
                                        V v_field_2455 = v_t_2453.f[1];
                                        V v_field_2456 = v_t_2453.f[2];
                                        int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                                        if ((v_tag_2454 == ((int64_t)0ULL))) {
                                          V v_x_2457 = v_field_2455;
                                          V v_j_2458 = v_field_2456;
                                          HeffT3 v_t_2459 = (g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(v_x_2457, v_s_241, v_j_2458));
                                          {
                                            V v_field_2461 = v_t_2459.f[1];
                                            V v_field_2462 = v_t_2459.f[2];
                                            int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                                            if ((v_tag_2460 == ((int64_t)0ULL))) {
                                              V v_x_2463 = v_field_2461;
                                              V v_j_2464 = v_field_2462;
                                              HeffT3 v_t_2465 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2464));
                                              {
                                                V v_field_2467 = v_t_2465.f[1];
                                                V v_field_2468 = v_t_2465.f[2];
                                                int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                                                if ((v_tag_2466 == ((int64_t)0ULL))) {
                                                  V v_x_2469 = v_field_2467;
                                                  V v_j_2470 = v_field_2468;
                                                  HeffT3 v_t_2471 = (g_heff_2ebuild_2edecoder_2etimes_24s373319101x980263517_24cpr(v_x_2469, v_s_241, v_j_2470));
                                                  {
                                                    V v_field_2473 = v_t_2471.f[1];
                                                    V v_field_2474 = v_t_2471.f[2];
                                                    int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
                                                    if ((v_tag_2472 == ((int64_t)0ULL))) {
                                                      V v_x_2475 = v_field_2473;
                                                      V v_j_2476 = v_field_2474;
                                                      HeffT3 v_t_2477 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_j_2476));
                                                      {
                                                        V v_field_2479 = v_t_2477.f[1];
                                                        V v_field_2480 = v_t_2477.f[2];
                                                        int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
                                                        if ((v_tag_2478 == ((int64_t)0ULL))) {
                                                          V v_x_2481 = v_field_2479;
                                                          V v_j_2482 = v_field_2480;
                                                          if (heff_strEq_c(v_x_2481, ((V)&g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0))) {
                                                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(5, shape_groups__copies__emits__jss__works, (V[]){v_x_2427, v_x_2439, v_x_2451, v_x_2463, v_x_2475}), v_j_2482}});
                                                          } else {
                                                            heff_drop(v_x_2427);
                                                            heff_drop(v_x_2439);
                                                            heff_drop(v_x_2451);
                                                            heff_drop(v_x_2463);
                                                            heff_drop(v_x_2475);
                                                            heff_drop(v_j_2482);
                                                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_2427);
                                                          heff_drop(v_x_2439);
                                                          heff_drop(v_x_2451);
                                                          heff_drop(v_x_2463);
                                                          heff_drop(v_x_2475);
                                                          heff_drop(v_field_2479);
                                                          heff_drop(v_field_2480);
                                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    } else {
                                                      heff_drop(v_s_241);
                                                      heff_drop(v_x_2427);
                                                      heff_drop(v_x_2439);
                                                      heff_drop(v_x_2451);
                                                      heff_drop(v_x_2463);
                                                      heff_drop(v_field_2473);
                                                      heff_drop(v_field_2474);
                                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  heff_drop(v_s_241);
                                                  heff_drop(v_x_2427);
                                                  heff_drop(v_x_2439);
                                                  heff_drop(v_x_2451);
                                                  heff_drop(v_x_2463);
                                                  heff_drop(v_field_2467);
                                                  heff_drop(v_field_2468);
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              heff_drop(v_s_241);
                                              heff_drop(v_x_2427);
                                              heff_drop(v_x_2439);
                                              heff_drop(v_x_2451);
                                              heff_drop(v_field_2461);
                                              heff_drop(v_field_2462);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_s_241);
                                          heff_drop(v_x_2427);
                                          heff_drop(v_x_2439);
                                          heff_drop(v_x_2451);
                                          heff_drop(v_field_2455);
                                          heff_drop(v_field_2456);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_241);
                                      heff_drop(v_x_2427);
                                      heff_drop(v_x_2439);
                                      heff_drop(v_field_2449);
                                      heff_drop(v_field_2450);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_241);
                                  heff_drop(v_x_2427);
                                  heff_drop(v_x_2439);
                                  heff_drop(v_field_2443);
                                  heff_drop(v_field_2444);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_241);
                              heff_drop(v_x_2427);
                              heff_drop(v_field_2437);
                              heff_drop(v_field_2438);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_241);
                          heff_drop(v_x_2427);
                          heff_drop(v_field_2431);
                          heff_drop(v_field_2432);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_241);
                      heff_drop(v_field_2425);
                      heff_drop(v_field_2426);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_241);
                  heff_drop(v_field_2419);
                  heff_drop(v_field_2420);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_241);
              heff_drop(v_j_2416);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_s_241);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_s_241);
        heff_drop(v_j_248);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2elastDotGo_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_k_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_243;
    if ((heff_unbox_word(heff_strByteAt_lent(v_k_240, v_i_241, 0)) == ((int64_t)46ULL))) {
      heff_drop(v_at_242);
      v_t_243 = heff_dup(v_i_241);
    } else {
      v_t_243 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = v_t_243;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2elastDotGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str3, 1, " ");
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddGroup_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddGroup(V v_fs_240, V v_m_241, V v_g_242) {
top: ;
  V v_fs_243 = heff_dup(v_fs_240);
  V v_m_244 = v_m_241;
  V v_md_245 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  V v_g_246 = heff_dup(v_g_242);
  V v_owner_247 = heff_dup(heff_rfield(v_g_242, 0));
  V v_ver_248 = heff_dup(heff_rfield(v_g_242, 1));
  V v_olds_249 = heff_take_field(v_fs_240, 1);
  V v_m_2410 = ({ V b_0 = heff_get_n(v_fs_240, 0, 2); V a_1 = heff_dup(heff_rfield(v_g_242, 0)); V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_olds_249; V a_1 = v_m_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_olds_249); heff_drop(v_m_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2415;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2415 = v_x_2414;
    } else {
      heff_drop(v_field_2413);
      v_t_2415 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2415, 0, 5)));
    V v_old_2426 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam0, 2, 1, (V[]){heff_dup(v_g_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2416; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2416); r_; });
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam1, 1, 1, (V[]){v_old_2426}), heff_get_n(v_g_242, 2, 3)));
    HeffT2 v_t_2440 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_t_2439));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      V v_x5_2452;
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        V v_us_2443 = v_field_2442;
        V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_us_2443));
        V v_t_2445 = heff_intShow(v_t_2444);
        V v_t_2446 = heff_intShow(heff_strLength_lent(v_ver_248, 0));
        V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str0)), v_ver_248);
        V v_t_2448 = heff_intShow(heff_strLength_lent(v_owner_247, 0));
        V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str1)), v_owner_247);
        V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str2)), v_t_2447);
        V v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str3); V a_1 = v_t_2450; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_us_2443}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        v_x5_2452 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2451});
      } else {
        heff_drop(v_owner_247);
        heff_drop(v_ver_248);
        heff_drop(v_field_2442);
        v_x5_2452 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_x5_2452)) {
      case TAG_Nothing: {
        heff_drop_rec(v_fs_243, 2);
        heff_drop(v_md_245);
        heff_drop_rec(v_g_246, 3);
        return v_m_244;
      }
      case TAG_Just: {
        V v_t_2453 = heff_field(v_x5_2452, 0);
        heff_take_n(v_x5_2452, 1ULL, 1);
        HeffT2 v_t_2454 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_244, v_md_245));
        {
          V v_field_2456 = v_t_2454.f[1];
          int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
          V v_es_2463;
          if ((v_tag_2455 == ((int64_t)0ULL))) {
            heff_drop_rec(v_fs_243, 2);
            V v_es_2457 = v_field_2456;
            v_es_2463 = v_es_2457;
          } else {
            heff_drop(v_field_2456);
            HeffT2 v_t_2458 = ({ V b_0 = heff_get_n(v_fs_243, 1, 2); V a_1 = v_md_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2460 = v_t_2458.f[1];
              int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
              V v_t_2462;
              if ((v_tag_2459 == ((int64_t)0ULL))) {
                V v_x_2461 = v_field_2460;
                v_t_2462 = v_x_2461;
              } else {
                heff_drop(v_field_2460);
                v_t_2462 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
              }
              v_es_2463 = (g_heff_2ebuild_2ebackcache_2eentriesOf(v_t_2462));
            }
          }
          V v_t_2464 = ({ V a_0 = heff_take_field(v_es_2463, 0); V b_1 = heff_get_n(v_g_246, 0, 3); V a_2 = v_t_2453; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_t_2453); r_; });
          V v_t_2465 = ({ V rv_0 = v_t_2464; V rr_ = heff_rec_reuse_nf(v_es_2463, 30ULL, 5, shape_groups__copies__emits__jss__works, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return ({ V a_0 = v_m_244; V a_1 = v_md_245; V a_2 = v_t_2465; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_md_245); heff_drop_rec(v_t_2465, 5); r_; });
        }
      }
      default: return heff_nomatch(v_x5_2452);
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddGroup(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args) {
  V v_acc_2417 = args[0];
  V v_x_2418 = args[1];
  V v_g_242 = heff_env(self)[0];
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_dup(heff_field(v_x_2418, 0));
    v_t_2421 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2425;
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_t_2421, 0, 3), heff_get_n(v_g_242, 0, 3))) {
    V v_t_2424;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x_2418, 0);
      heff_take_n(v_x_2418, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    v_t_2425 = heff_get_n(v_t_2424, 2, 3);
  } else {
    heff_drop(v_x_2418);
    v_t_2425 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2425, v_acc_2417));
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_old_2426 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_k_2428 = heff_field(v_x2_2427, 0);
    V v_x22_2429 = heff_field(v_x2_2427, 1);
    heff_take_n(v_x2_2427, 3ULL, 2);
    switch (heff_tag_of(v_x22_2429)) {
    case TAG_Nothing: {
      heff_clo_take(self, 1);
      HeffT2 v_t_2430 = ({ V a_0 = v_k_2428; V a_1 = v_old_2426; HeffT2 r_ = (g_list_2efind_24s1156299507x501436576_24cpr(a_0, a_1)); heff_drop(v_k_2428); heff_drop(v_old_2426); r_; });
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_p_2433 = v_field_2432;
          V v_t_2436;
          switch (heff_tag_of(v_p_2433)) {
          case TAG_MkPair: {
            V v_y_2435 = heff_field(v_p_2433, 1);
            heff_take_n(v_p_2433, 2ULL, 2);
            v_t_2436 = v_y_2435;
            break;
          }
          default: heff_nomatch(v_p_2433);
          }
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2436});
        } else {
          heff_drop(v_field_2432);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_u_2437 = heff_field(v_x22_2429, 0);
      V v_ru_24x22_2429_24Just = heff_take_reuse_n(v_x22_2429, 1ULL, 1);
      heff_drop(self);
      heff_drop(v_k_2428);
      V v_t_2438 = (g_heff_2ebuild_2ebackcache_2eunitText(v_u_2437));
      return heff_tag_at_n(v_ru_24x22_2429_24Just, TAG_Just, 1, (V[]){v_t_2438});
    }
    default: return heff_nomatch(v_x22_2429);
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddCopy_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddCopy(V v_fs_240, V v_m_241, V v_c_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  V v_g_245 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_246 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str0), v_g_245, MK_INT(0LL), 5);
  V v_t_247;
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_j_246);
    v_t_247 = v_g_245;
  } else {
    v_t_247 = heff_strSlice(v_g_245, MK_INT(0LL), v_j_246);
  }
  V v_t_248 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_247));
  V v_k_249 = heff_dup(heff_rfield(v_c_242, 0));
  V v_t_2410 = (g_heff_2ebuild_2ebackcache_2ecopyText(heff_dup(v_c_242)));
  V v_g_2411 = heff_get_n(v_c_242, 0, 7);
  V v_j_2412 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str1), v_g_2411, MK_INT(0LL), 5);
  V v_t_2413;
  if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
    heff_drop(v_j_2412);
    v_t_2413 = v_g_2411;
  } else {
    v_t_2413 = heff_strSlice(v_g_2411, MK_INT(0LL), v_j_2412);
  }
  V v_k_2414 = ({ V a_0 = v_mods_243; V a_1 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
  HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_k_2414));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_es_2424;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_olds_244);
      heff_drop(v_k_2414);
      V v_es_2418 = v_field_2417;
      v_es_2424 = v_es_2418;
    } else {
      heff_drop(v_field_2417);
      HeffT2 v_t_2419 = ({ V a_0 = v_olds_244; V a_1 = v_k_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_olds_244); heff_drop(v_k_2414); r_; });
      {
        V v_field_2421 = v_t_2419.f[1];
        int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
        V v_t_2423;
        if ((v_tag_2420 == ((int64_t)0ULL))) {
          V v_x_2422 = v_field_2421;
          v_t_2423 = v_x_2422;
        } else {
          heff_drop(v_field_2421);
          v_t_2423 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        v_es_2424 = (g_heff_2ebuild_2ebackcache_2eentriesOf(v_t_2423));
      }
    }
    V v_t_2425 = ({ V a_0 = heff_take_field(v_es_2424, 1); V a_1 = v_k_249; V a_2 = v_t_2410; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_249); heff_drop(v_t_2410); r_; });
    V v_t_2426 = ({ V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_es_2424, 29ULL, 5, shape_groups__copies__emits__jss__works, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return ({ V a_0 = v_m_241; V a_1 = v_t_248; V a_2 = v_t_2426; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_248); heff_drop_rec(v_t_2426, 5); r_; });
  }
}
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddCopy(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddEmit_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddEmit(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_242, 0);
    V v_e_246 = heff_field(v_x3_242, 1);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str0), v_k_245, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = heff_dup(v_k_245);
    } else {
      v_t_248 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_247, 6);
    }
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_248));
    V v_t_2410 = (g_heff_2ebuild_2ebackcache_2eemitText(heff_dup(v_k_245), heff_dup(v_e_246)));
    V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str1), v_k_245, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
      heff_drop(v_j_2411);
      v_t_2412 = heff_dup(v_k_245);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_2411, 6);
    }
    V v_k_2413 = ({ V a_0 = v_mods_243; V a_1 = v_t_2412; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
    HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_k_2413));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      V v_es_2423;
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_olds_244);
        heff_drop(v_k_2413);
        V v_es_2417 = v_field_2416;
        v_es_2423 = v_es_2417;
      } else {
        heff_drop(v_field_2416);
        HeffT2 v_t_2418 = ({ V a_0 = v_olds_244; V a_1 = v_k_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_olds_244); heff_drop(v_k_2413); r_; });
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          V v_t_2422;
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x_2421 = v_field_2420;
            v_t_2422 = v_x_2421;
          } else {
            heff_drop(v_field_2420);
            v_t_2422 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
          }
          v_es_2423 = (g_heff_2ebuild_2ebackcache_2eentriesOf(v_t_2422));
        }
      }
      V v_t_2424 = ({ V a_0 = heff_take_field(v_es_2423, 2); V a_1 = v_k_245; V a_2 = v_t_2410; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_es_2423, 27ULL, 5, shape_groups__copies__emits__jss__works, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return ({ V a_0 = v_m_241; V a_1 = v_t_249; V a_2 = v_t_2425; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop_rec(v_t_2425, 5); r_; });
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddEmit(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddJs_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddJs(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_242, 0);
    V v_e_246 = heff_field(v_x3_242, 1);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str0), v_k_245, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = heff_dup(v_k_245);
    } else {
      v_t_248 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_247, 6);
    }
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_248));
    V v_t_2410 = (g_heff_2ebuild_2ebackcache_2ejsText(heff_dup(v_k_245), heff_dup(v_e_246)));
    V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str1), v_k_245, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
      heff_drop(v_j_2411);
      v_t_2412 = heff_dup(v_k_245);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_2411, 6);
    }
    V v_k_2413 = ({ V a_0 = v_mods_243; V a_1 = v_t_2412; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
    HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_k_2413));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      V v_es_2423;
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_olds_244);
        heff_drop(v_k_2413);
        V v_es_2417 = v_field_2416;
        v_es_2423 = v_es_2417;
      } else {
        heff_drop(v_field_2416);
        HeffT2 v_t_2418 = ({ V a_0 = v_olds_244; V a_1 = v_k_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_olds_244); heff_drop(v_k_2413); r_; });
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          V v_t_2422;
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x_2421 = v_field_2420;
            v_t_2422 = v_x_2421;
          } else {
            heff_drop(v_field_2420);
            v_t_2422 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
          }
          v_es_2423 = (g_heff_2ebuild_2ebackcache_2eentriesOf(v_t_2422));
        }
      }
      V v_t_2424 = ({ V a_0 = heff_take_field(v_es_2423, 3); V a_1 = v_k_245; V a_2 = v_t_2410; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_t_2425 = ({ V rv_3 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_es_2423, 23ULL, 5, shape_groups__copies__emits__jss__works, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      return ({ V a_0 = v_m_241; V a_1 = v_t_249; V a_2 = v_t_2425; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop_rec(v_t_2425, 5); r_; });
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddJs(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddWork_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddWork_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddWork_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddWork_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddWork_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddWork_str5, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddWork_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddWork_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddWork(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_242, 0);
    V v_w_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddWork_str0), v_k_245, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = heff_dup(v_k_245);
    } else {
      v_t_248 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_247, 6);
    }
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_248));
    V v_key_2410 = heff_dup(v_k_245);
    V v_k_2411 = v_w_246;
    V v_ver_2412 = heff_take_field(v_k_2411, 0);
    V v_members_2413 = heff_get_n(v_k_2411, 1, 2);
    V v_s_2414 = v_ver_2412;
    V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_members_2413));
    V v_t_2416 = heff_intShow(v_t_2415);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_members_2413));
    V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1378809716x1427336252(a_0, a_1)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = heff_intShow(heff_strLength_lent(v_s_2414, 0));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ebackcache_2eaddWork_str1)), v_s_2414);
    V v_t_2421 = heff_intShow(heff_strLength_lent(v_key_2410, 0));
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ebackcache_2eaddWork_str2)), v_key_2410);
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ebackcache_2eaddWork_str3)), v_t_2420);
    V v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eaddWork_str4); V a_1 = v_t_2423; V b_2 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2416, v_t_2418}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_j_2425 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddWork_str5), v_k_245, MK_INT(0LL), 5);
    V v_t_2426;
    if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
      heff_drop(v_j_2425);
      v_t_2426 = heff_dup(v_k_245);
    } else {
      v_t_2426 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_2425, 6);
    }
    V v_k_2427 = ({ V a_0 = v_mods_243; V a_1 = v_t_2426; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
    HeffT2 v_t_2428 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_k_2427));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      V v_es_2437;
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop(v_olds_244);
        heff_drop(v_k_2427);
        V v_es_2431 = v_field_2430;
        v_es_2437 = v_es_2431;
      } else {
        heff_drop(v_field_2430);
        HeffT2 v_t_2432 = ({ V a_0 = v_olds_244; V a_1 = v_k_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_olds_244); heff_drop(v_k_2427); r_; });
        {
          V v_field_2434 = v_t_2432.f[1];
          int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
          V v_t_2436;
          if ((v_tag_2433 == ((int64_t)0ULL))) {
            V v_x_2435 = v_field_2434;
            v_t_2436 = v_x_2435;
          } else {
            heff_drop(v_field_2434);
            v_t_2436 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
          }
          v_es_2437 = (g_heff_2ebuild_2ebackcache_2eentriesOf(v_t_2436));
        }
      }
      V v_t_2438 = ({ V a_0 = heff_take_field(v_es_2437, 4); V a_1 = v_k_245; V a_2 = v_t_2424; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_245); heff_drop(v_t_2424); r_; });
      V v_t_2439 = ({ V rv_4 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_es_2437, 15ULL, 5, shape_groups__copies__emits__jss__works, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      return ({ V a_0 = v_m_241; V a_1 = v_t_249; V a_2 = v_t_2439; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop_rec(v_t_2439, 5); r_; });
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddWork_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddWork(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str0, 5, "3:end");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str4, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ebackText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ebackText(V v_id_240, V v_es_241) {
top: ;
  V v_groups_242 = heff_take_field(v_es_241, 0);
  V v_copies_243 = heff_take_field(v_es_241, 1);
  V v_emits_244 = heff_take_field(v_es_241, 2);
  V v_jss_245 = heff_take_field(v_es_241, 3);
  V v_works_246 = heff_get_n(v_es_241, 4, 5);
  V v_t_247 = (g_std_2eordmap_2esize(v_groups_242));
  V v_t_248 = heff_intShow(v_t_247);
  V v_t_249 = ({ V a_0 = v_groups_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_groups_242); r_; });
  V v_t_2410 = (g_list_2emap_24s1173914895x100384474(v_t_249));
  V v_t_2411 = (g_std_2eordmap_2esize(v_copies_243));
  V v_t_2412 = ({ V a_0 = v_copies_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_copies_243); r_; });
  V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_t_2412));
  V v_t_2414 = (g_std_2eordmap_2esize(v_emits_244));
  V v_t_2415 = ({ V a_0 = v_emits_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_emits_244); r_; });
  V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
  V v_t_2417 = (g_std_2eordmap_2esize(v_jss_245));
  V v_t_2418 = ({ V a_0 = v_jss_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_jss_245); r_; });
  V v_t_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
  V v_t_2420 = (g_std_2eordmap_2esize(v_works_246));
  V v_t_2421 = ({ V a_0 = v_works_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_works_246); r_; });
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ebackText_str0), NTAG(TAG_Nil)});
  V v_t_2423 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_2422, v_t_2421));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2420), v_t_2423});
  V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2424));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), v_t_2425});
  V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2426));
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2427});
  V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2428));
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2429});
  V v_ys_2431 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2430));
  V v_t_2432 = heff_intShow(heff_strLength_lent(v_id_240, 0));
  V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str1)), v_id_240);
  V v_t_2434 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str2)), heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str3)), v_t_2433);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str4); V a_1 = v_t_2436; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_ys_2431}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackText(a[0], a[1]);
}