// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HC 9068
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ebytesH_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eckOf(V);
V g_heff_2ecompile_2eirtext_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eckOf_clo;
HeffT1 g_heff_2ecompile_2eirtext_2eckOf_24cpr(V);
V g_heff_2ecompile_2eirtext_2econdOfTag(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo;
HeffT3 g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
HeffT3 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH(V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V, V);
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V);
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2ecompile_2eirtext_2estrsT_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprimitive_2eprimOfName(V);
V g_heff_2eelab_2eprimitive_2eprimOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimOfName_clo;
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsT(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eirtext_2estrsT_str0)), v_x_242);
    V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsT_24dps(v_xs_243, v_rest_241, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_24dps_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsT_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eirtext_2estrsT_24dps_str0)), v_x_243);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_u_248;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eirtext_2estrsT_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_rest_244 = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(v_es_243, v_rest_241));
    HEFF_LAST return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_242), v_rest_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str57, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str58, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str59, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_244 = heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0)), v_x_242);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_rest_241})});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_g_245, 0));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2)), v_g_245);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_249, v_rest_241));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_248, v_rest_2410));
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4), v_t_2413});
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_240, 0);
    V v_args_2415 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2415));
    V v_t_2417 = ({ V a_0 = v_args_2415; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2415); r_; });
    V v_rest_2418 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2417});
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5), heff_hole()});
    V v_u_2420 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_f_2414, v_rest_2418, v_cell_2419));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_a_2422 = heff_field(v_x2_240, 1);
    V v_b_2423 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_rest_2424 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2423, v_rest_241));
    V v_cell_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6), heff_hole()});
    V v_t_2426 = heff_intShow(heff_strLength_lent(v_x_2421, 0));
    V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7)), v_x_2421);
    V v_cell_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_hole()});
    V v_u_2429 = heff_setField(heff_dup(v_cell_2425), MK_INT(1LL), v_cell_2428);
    V v_u_2430 = ({ V a_0 = v_a_2422; V a_1 = v_rest_2424; V a_2 = v_u_2429; V r_ = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(a_0, a_1, a_2)); heff_drop(v_u_2429); r_; });
    heff_drop(v_u_2430);
    return v_cell_2425;
  }
  case TAG_ERecord: {
    V v_fs_2431 = heff_field(v_x2_240, 0);
    V v_ts_2432 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2431));
    V v_xs_2434 = (g_list_2emap_24s143096761x246530315(v_ts_2432));
    V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2434));
    V v_t_2436 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2434, v_rest_241));
    V v_t_2437 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2435), v_t_2436});
    V v_t_2438 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2431, v_t_2437));
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), v_t_2438});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8), v_t_2439});
  }
  case TAG_EProj: {
    V v_e_2440 = heff_field(v_x2_240, 0);
    V v_l_2441 = heff_field(v_x2_240, 1);
    V v_sh_2442 = heff_field(v_x2_240, 2);
    V v_t_2443 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2442));
    V v_s_2446;
    switch (heff_tag_of(v_t_2443)) {
    case TAG_FtFloat: {
      v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2445 = heff_field(v_t_2443, 0);
      heff_take_n(v_t_2443, 1ULL, 1);
      switch (heff_tag_of(v_w_2445)) {
      case TAG_I8: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10);
        break;
      }
      case TAG_I16: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11);
        break;
      }
      case TAG_I32: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12);
        break;
      }
      case TAG_I64: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13);
        break;
      }
      case TAG_U8: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14);
        break;
      }
      case TAG_U16: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15);
        break;
      }
      case TAG_U32: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16);
        break;
      }
      case TAG_U64: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17);
        break;
      }
      case TAG_F32: {
        v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18);
        break;
      }
      default: heff_nomatch(v_w_2445);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19);
      break;
    }
    case TAG_FtAny: {
      v_s_2446 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20);
      break;
    }
    default: heff_nomatch(v_t_2443);
    }
    V v_t_2447 = heff_intShow(heff_strLength_lent(v_s_2446, 0));
    V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21)), v_s_2446);
    V v_t_2449 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_rest_241})));
    V v_t_2450 = heff_intShow(heff_strLength_lent(v_l_2441, 0));
    V v_t_2451 = heff_strAppend(heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22)), v_l_2441);
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2444), v_t_2449});
    V v_rest_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2452});
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23), heff_hole()});
    V v_u_2455 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_e_2440, v_rest_2453, v_cell_2454));
    heff_drop(v_u_2455);
    return v_cell_2454;
  }
  case TAG_ETag: {
    V v_t_2456 = heff_field(v_x2_240, 0);
    V v_args_2457 = heff_field(v_x2_240, 1);
    V v_ts_2458 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2457));
    V v_xs_2460 = (g_list_2emap_24s143096761x246530315(v_ts_2458));
    V v_t_2461 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2460));
    V v_t_2462 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2460, v_rest_241));
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2461), v_t_2462});
    V v_t_2464 = ({ V a_0 = v_args_2457; V a_1 = v_t_2463; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2457); r_; });
    V v_t_2465 = heff_intShow(heff_strLength_lent(v_t_2456, 0));
    V v_t_2466 = heff_strAppend(heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24)), v_t_2456);
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2459), v_t_2464});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, v_t_2467})});
  }
  case TAG_EMatch: {
    V v_s_2468 = heff_field(v_x2_240, 0);
    V v_arms_2469 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2469));
    V v_t_2471 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2469, v_rest_241));
    V v_rest_2472 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2470), v_t_2471});
    V v_cell_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26), heff_hole()});
    V v_u_2474 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_s_2468, v_rest_2472, v_cell_2473));
    heff_drop(v_u_2474);
    return v_cell_2473;
  }
  case TAG_EPrim: {
    V v_p_2475 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2476 = ({ V a_0 = v_p_2475; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2475); r_; });
    V v_t_2477 = heff_intShow(heff_strLength_lent(v_s_2476, 0));
    V v_t_2478 = heff_strAppend(heff_strAppend(v_t_2477, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27)), v_s_2476);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_rest_241})});
  }
  case TAG_EPrimCall: {
    V v_p_2479 = heff_field(v_x2_240, 0);
    V v_args_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_s_2481 = ({ V a_0 = v_p_2479; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2479); r_; });
    V v_t_2482 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2480));
    V v_t_2483 = ({ V a_0 = v_args_2480; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2480); r_; });
    V v_t_2484 = heff_intShow(heff_strLength_lent(v_s_2481, 0));
    V v_t_2485 = heff_strAppend(heff_strAppend(v_t_2484, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29)), v_s_2481);
    V v_t_2486 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2482), v_t_2483});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_t_2486})});
  }
  case TAG_ECall: {
    V v_g_2487 = heff_field(v_x2_240, 0);
    V v_args_2488 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2489 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2488));
    V v_t_2490 = ({ V a_0 = v_args_2488; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2488); r_; });
    V v_t_2491 = heff_intShow(heff_strLength_lent(v_g_2487, 0));
    V v_t_2492 = heff_strAppend(heff_strAppend(v_t_2491, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31)), v_g_2487);
    V v_t_2493 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2489), v_t_2490});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2492, v_t_2493})});
  }
  case TAG_EInt: {
    V v_i_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2495 = heff_intShow(v_i_2494);
    V v_t_2496 = heff_intShow(heff_strLength_lent(v_s_2495, 0));
    V v_t_2497 = heff_strAppend(heff_strAppend(v_t_2496, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33)), v_s_2495);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2498 = heff_tget_v(v_x2_240, 0);
    heff_take_nf(v_x2_240, 0ULL, 1);
    V v_s_2499 = heff_floatShow(v_x_2498);
    V v_t_24100 = heff_intShow(heff_strLength_lent(v_s_2499, 0));
    V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35)), v_s_2499);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24101, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_24102 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24103 = heff_intShow(heff_strLength_lent(v_s_24102, 0));
    V v_t_24104 = heff_strAppend(heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37)), v_s_24102);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24104, v_rest_241})});
  }
  case TAG_EBytes: {
    V v_s_24105 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24106 = heff_intShow(heff_strLength_lent(v_s_24105, 0));
    V v_t_24107 = heff_strAppend(heff_strAppend(v_t_24106, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39)), v_s_24105);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_rest_241})});
  }
  case TAG_EFixed: {
    V v_w_24108 = heff_field(v_x2_240, 0);
    V v_n_24109 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24110;
    switch (heff_tag_of(v_w_24108)) {
    case TAG_I8: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41);
      break;
    }
    case TAG_I16: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42);
      break;
    }
    case TAG_I32: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43);
      break;
    }
    case TAG_I64: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44);
      break;
    }
    case TAG_U8: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45);
      break;
    }
    case TAG_U16: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46);
      break;
    }
    case TAG_U32: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47);
      break;
    }
    case TAG_U64: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48);
      break;
    }
    case TAG_F32: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49);
      break;
    }
    default: heff_nomatch(v_w_24108);
    }
    V v_s_24111 = heff_intShow(v_n_24109);
    V v_t_24112 = heff_intShow(heff_strLength_lent(v_s_24111, 0));
    V v_t_24113 = heff_strAppend(heff_strAppend(v_t_24112, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50)), v_s_24111);
    V v_t_24114 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24110, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51), v_t_24114});
  }
  case TAG_EFloat32: {
    V v_x_24115 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24116 = heff_floatShow(v_x_24115);
    V v_t_24117 = heff_intShow(heff_strLength_lent(v_s_24116, 0));
    V v_t_24118 = heff_strAppend(heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52)), v_s_24116);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54), v_rest_241});
  }
  case TAG_EBool: {
    V v_c_24119 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24120 = ({ V a_0 = v_c_24119; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(a_0, a_1)); heff_drop(v_c_24119); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55), v_t_24120});
  }
  case TAG_ESet: {
    V v_xs_24121 = heff_field(v_x2_240, 0);
    V v_a_24122 = heff_field(v_x2_240, 1);
    V v_b_24123 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_rest_24124 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_24123, v_rest_241));
    V v_rest_24125 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_24122, v_rest_24124));
    V v_t_24126 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24121));
    V v_t_24127 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_24121, v_rest_24125));
    V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24126), v_t_24127});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56), v_t_24128});
  }
  case TAG_EValues: {
    V v_es_24129 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24130 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_24129));
    V v_t_24131 = ({ V a_0 = v_es_24129; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_es_24129); r_; });
    V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24130), v_t_24131});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str57), v_t_24132});
  }
  case TAG_EFix: {
    V v_f_24133 = heff_field(v_x2_240, 0);
    V v_b_24134 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24135 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str58), heff_hole()});
    V v_t_24136 = heff_intShow(heff_strLength_lent(v_f_24133, 0));
    V v_t_24137 = heff_strAppend(heff_strAppend(v_t_24136, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str59)), v_f_24133);
    V v_cell_24138 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24137, heff_hole()});
    V v_u_24139 = heff_setField(heff_dup(v_cell_24135), MK_INT(1LL), v_cell_24138);
    V v_u_24140 = ({ V a_0 = v_b_24134; V a_1 = v_rest_241; V a_2 = v_u_24139; V r_ = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(a_0, a_1, a_2)); heff_drop(v_u_24139); r_; });
    heff_drop(v_u_24140);
    return v_cell_24135;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD(V v_d_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_dup(v_d_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_clo), 2, (V[]){v_d_240, v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo);
  } else {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo), 1, (V[]){v_t_244});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}
Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econdOfTag_entry, 5, 0};

V g_heff_2ecompile_2eirtext_2econdOfTag(V v_k_240, V v_c_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(v_k_240, v_c_241, v_x3_242, v_z_243, v_z_244));
  {
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_247, v_field_248})});
    } else {
      heff_drop(v_field_247);
      heff_drop(v_field_248);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eirtext_2econdOfTag(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eirtext_2eckOf_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2ecompile_2eirtext_2eckOf_24cpr(V v_k_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2ecompile_2eirtext_2eckOf_24cpr_lam0, 2, 1, (V[]){v_k_240})}});
}
V g_heff_2ecompile_2eirtext_2eckOf_24cpr_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_t_243 = (g_heff_2ecompile_2eirtext_2eckOf(heff_dup(v_k_240)));
  HeffT3 v_t_244 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      V v_j_249 = v_field_247;
      heff_clo_take(self, 1);
      return ({ V a_0 = v_k_240; V a_1 = v_t_243; V a_2 = v_x_248; V a_3 = v_s_241; V a_4 = v_j_249; V r_ = (g_heff_2ecompile_2eirtext_2econdOfTag(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_248); r_; });
    } else {
      heff_drop(v_s_241);
      heff_drop(self);
      heff_drop(v_t_243);
      heff_drop(v_field_246);
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo);
  } else {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo), 1, (V[]){v_t_244});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0, 2, 0};
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args);
Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V v_lit_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_lit_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo);
  } else {
    V v_more_245 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(heff_dup(v_lit_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_clo_n(g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1, 2, 2, (V[]){v_lit_240, v_more_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_i_247 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_more_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_k_248 = v_lit_240;
  V v_s_249 = heff_dup(v_s_246);
  V v_i_2410 = v_i_247;
  HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_249), v_i_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    V v_field_2414 = v_t_2411.f[2];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_x3_2433;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      V v_j_2416 = v_field_2414;
      HeffT3 v_t_2417 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_249, v_j_2416));
      {
        V v_field_2419 = v_t_2417.f[1];
        V v_field_2420 = v_t_2417.f[2];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_x_2421 = v_field_2419;
          V v_j_2422 = v_field_2420;
          V v_t_2423 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2421));
          V v_x3_2424 = heff_tr(heff_call(v_t_2423, 2, (V[]){heff_dup(v_s_249), v_j_2422}));
          switch (heff_tag_of(v_x3_2424)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_248, 1);
            heff_drop(v_s_249);
            heff_drop(v_x_2415);
            v_x3_2433 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2425 = heff_field(v_x3_2424, 0);
            V v_ru_24x3_2424_24Just = heff_take_reuse_n(v_x3_2424, 1ULL, 1);
            switch (heff_tag_of(v_x31_2425)) {
            case TAG_MkPair: {
              V v_x_2426 = heff_field(v_x31_2425, 0);
              V v_j_2427 = heff_field(v_x31_2425, 1);
              V v_ru_24x31_2425_24MkPair = heff_take_reuse_n(v_x31_2425, 3ULL, 2);
              V v_x3_2428 = heff_tr(heff_call(heff_get_n(v_k_248, 0, 1), 2, (V[]){v_s_249, v_j_2427}));
              switch (heff_tag_of(v_x3_2428)) {
              case TAG_Nothing: {
                heff_drop(v_x_2415);
                heff_drop_cell(v_ru_24x3_2424_24Just, 1);
                heff_drop(v_x_2426);
                heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                v_x3_2433 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2429 = heff_field(v_x3_2428, 0);
                heff_take_n(v_x3_2428, 1ULL, 1);
                switch (heff_tag_of(v_x31_2429)) {
                case TAG_MkPair: {
                  V v_x_2430 = heff_field(v_x31_2429, 0);
                  V v_j_2431 = heff_field(v_x31_2429, 1);
                  heff_take_n(v_x31_2429, 3ULL, 2);
                  V v_t_2432 = heff_tag_at_n(v_ru_24x31_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_x_2415, v_x_2426, v_x_2430}), v_j_2431});
                  v_x3_2433 = heff_tag_at_n(v_ru_24x3_2424_24Just, TAG_Just, 1, (V[]){v_t_2432});
                  break;
                }
                default: heff_nomatch(v_x31_2429);
                }
                break;
              }
              default: heff_nomatch(v_x3_2428);
              }
              break;
            }
            default: heff_nomatch(v_x31_2425);
            }
            break;
          }
          default: heff_nomatch(v_x3_2424);
          }
        } else {
          heff_drop_rec(v_k_248, 1);
          heff_drop(v_s_249);
          heff_drop(v_x_2415);
          heff_drop(v_field_2419);
          heff_drop(v_field_2420);
          v_x3_2433 = NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_k_248, 1);
      heff_drop(v_s_249);
      heff_drop(v_field_2413);
      heff_drop(v_field_2414);
      v_x3_2433 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_2433)) {
    case TAG_Nothing: {
      heff_drop(v_s_246);
      heff_drop(v_more_245);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_2434 = heff_field(v_x3_2433, 0);
      V v_ru_24x3_2433_24Just = heff_take_reuse_n(v_x3_2433, 1ULL, 1);
      switch (heff_tag_of(v_x31_2434)) {
      case TAG_MkPair: {
        V v_x_2435 = heff_field(v_x31_2434, 0);
        V v_j_2436 = heff_field(v_x31_2434, 1);
        V v_ru_24x31_2434_24MkPair = heff_take_reuse_n(v_x31_2434, 3ULL, 2);
        V v_x3_2437 = heff_tr(heff_call(v_more_245, 2, (V[]){v_s_246, v_j_2436}));
        switch (heff_tag_of(v_x3_2437)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_2433_24Just, 1);
          heff_drop(v_x_2435);
          heff_drop_cell(v_ru_24x31_2434_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2438 = heff_field(v_x3_2437, 0);
          heff_take_n(v_x3_2437, 1ULL, 1);
          switch (heff_tag_of(v_x31_2438)) {
          case TAG_MkPair: {
            V v_x_2439 = heff_field(v_x31_2438, 0);
            V v_j_2440 = heff_field(v_x31_2438, 1);
            V v_ru_24x31_2438_24MkPair = heff_take_reuse_n(v_x31_2438, 3ULL, 2);
            V v_t_2441 = heff_tag_at_n(v_ru_24x31_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2438_24MkPair, TAG_Cons, 2, (V[]){v_x_2435, v_x_2439}), v_j_2440});
            return heff_tag_at_n(v_ru_24x3_2433_24Just, TAG_Just, 1, (V[]){v_t_2441});
          }
          default: return heff_nomatch(v_x31_2438);
          }
        }
        default: return heff_nomatch(v_x3_2437);
        }
      }
      default: return heff_nomatch(v_x31_2434);
      }
    }
    default: return heff_nomatch(v_x3_2433);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str28, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str29, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str30, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str31, 1, "F");

HeffT3 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 1);
    HeffT3 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        V v_j_249 = v_field_247;
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EVar, 1, (V[]){v_x_248}), v_j_249}});
      } else {
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 1);
      HeffT3 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
      {
        V v_field_2412 = v_t_2410.f[1];
        V v_field_2413 = v_t_2410.f[2];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2412;
          V v_j_2415 = v_field_2413;
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2414}), v_j_2415}});
        } else {
          heff_drop(v_field_2412);
          heff_drop(v_field_2413);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2), 2)) {
        HeffT3 v_t_2416 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
        {
          V v_field_2418 = v_t_2416.f[1];
          V v_field_2419 = v_t_2416.f[2];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x_2420 = v_field_2418;
            V v_j_2421 = v_field_2419;
            V v_t_2422 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2420));
            V v_x3_2423 = heff_tr(heff_call(v_t_2422, 2, (V[]){heff_dup(v_z_242), v_j_2421}));
            switch (heff_tag_of(v_x3_2423)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 1);
              heff_drop(v_z_242);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2424 = heff_field(v_x3_2423, 0);
              heff_take_n(v_x3_2423, 1ULL, 1);
              switch (heff_tag_of(v_x31_2424)) {
              case TAG_MkPair: {
                V v_x_2425 = heff_field(v_x31_2424, 0);
                V v_j_2426 = heff_field(v_x31_2424, 1);
                V v_ru_24x31_2424_24MkPair = heff_take_reuse_n(v_x31_2424, 3ULL, 2);
                V v_x3_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2426}));
                switch (heff_tag_of(v_x3_2427)) {
                case TAG_Nothing: {
                  heff_drop(v_x_2425);
                  heff_drop_cell(v_ru_24x31_2424_24MkPair, 2);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2428 = heff_field(v_x3_2427, 0);
                  heff_take_n(v_x3_2427, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2428)) {
                  case TAG_MkPair: {
                    V v_x_2429 = heff_field(v_x31_2428, 0);
                    V v_j_2430 = heff_field(v_x31_2428, 1);
                    heff_take_n(v_x31_2428, 3ULL, 2);
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2424_24MkPair, TAG_ELam, 2, (V[]){v_x_2425, v_x_2429}), v_j_2430}});
                  }
                  default: return ((HeffT3){{heff_nomatch(v_x31_2428)}});
                  }
                }
                default: return ((HeffT3){{heff_nomatch(v_x3_2427)}});
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x31_2424)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x3_2423)}});
            }
          } else {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            heff_drop(v_field_2418);
            heff_drop(v_field_2419);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3), 2)) {
          V v_m_2431 = heff_dup(heff_rfield(v_k_240, 0));
          V v_x3_2432 = heff_tr(heff_call(v_m_2431, 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2432)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2433 = heff_field(v_x3_2432, 0);
            heff_take_n(v_x3_2432, 1ULL, 1);
            switch (heff_tag_of(v_x31_2433)) {
            case TAG_MkPair: {
              V v_x_2434 = heff_field(v_x31_2433, 0);
              V v_j_2435 = heff_field(v_x31_2433, 1);
              V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
              HeffT3 v_t_2436 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2435));
              {
                V v_field_2438 = v_t_2436.f[1];
                V v_field_2439 = v_t_2436.f[2];
                int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                if ((v_tag_2437 == ((int64_t)0ULL))) {
                  V v_x_2440 = v_field_2438;
                  V v_j_2441 = v_field_2439;
                  V v_t_2442 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2440));
                  V v_x3_2443 = heff_tr(heff_call(v_t_2442, 2, (V[]){v_z_242, v_j_2441}));
                  switch (heff_tag_of(v_x3_2443)) {
                  case TAG_Nothing: {
                    heff_drop(v_x_2434);
                    heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2444 = heff_field(v_x3_2443, 0);
                    heff_take_n(v_x3_2443, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2444)) {
                    case TAG_MkPair: {
                      V v_x_2445 = heff_field(v_x31_2444, 0);
                      V v_j_2446 = heff_field(v_x31_2444, 1);
                      heff_take_n(v_x31_2444, 3ULL, 2);
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_EApp, 2, (V[]){v_x_2434, v_x_2445}), v_j_2446}});
                    }
                    default: return ((HeffT3){{heff_nomatch(v_x31_2444)}});
                    }
                  }
                  default: return ((HeffT3){{heff_nomatch(v_x3_2443)}});
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_x_2434);
                  heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                  heff_drop(v_field_2438);
                  heff_drop(v_field_2439);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x31_2433)}});
            }
          }
          default: return ((HeffT3){{heff_nomatch(v_x3_2432)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4), 2)) {
            HeffT3 v_t_2447 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
            {
              V v_field_2449 = v_t_2447.f[1];
              V v_field_2450 = v_t_2447.f[2];
              int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
              if ((v_tag_2448 == ((int64_t)0ULL))) {
                V v_x_2451 = v_field_2449;
                V v_j_2452 = v_field_2450;
                V v_x3_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_2452}));
                switch (heff_tag_of(v_x3_2453)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_x_2451);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2454 = heff_field(v_x3_2453, 0);
                  heff_take_n(v_x3_2453, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2454)) {
                  case TAG_MkPair: {
                    V v_x_2455 = heff_field(v_x31_2454, 0);
                    V v_j_2456 = heff_field(v_x31_2454, 1);
                    heff_take_n(v_x31_2454, 3ULL, 2);
                    V v_x3_2457 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2456}));
                    switch (heff_tag_of(v_x3_2457)) {
                    case TAG_Nothing: {
                      heff_drop(v_x_2451);
                      heff_drop(v_x_2455);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2458 = heff_field(v_x3_2457, 0);
                      heff_take_n(v_x3_2457, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2458)) {
                      case TAG_MkPair: {
                        V v_x_2459 = heff_field(v_x31_2458, 0);
                        V v_j_2460 = heff_field(v_x31_2458, 1);
                        heff_take_n(v_x31_2458, 3ULL, 2);
                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_ELet, 3, (V[]){v_x_2451, v_x_2455, v_x_2459}), v_j_2460}});
                      }
                      default: return ((HeffT3){{heff_nomatch(v_x31_2458)}});
                      }
                    }
                    default: return ((HeffT3){{heff_nomatch(v_x3_2457)}});
                    }
                  }
                  default: return ((HeffT3){{heff_nomatch(v_x31_2454)}});
                  }
                }
                default: return ((HeffT3){{heff_nomatch(v_x3_2453)}});
                }
              } else {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                heff_drop(v_field_2449);
                heff_drop(v_field_2450);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5), 2)) {
              HeffT3 v_t_2461 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
              {
                V v_field_2463 = v_t_2461.f[1];
                V v_field_2464 = v_t_2461.f[2];
                int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                if ((v_tag_2462 == ((int64_t)0ULL))) {
                  V v_x_2465 = v_field_2463;
                  V v_j_2466 = v_field_2464;
                  V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2efieldD_clo), 1, (V[]){v_k_240}));
                  V v_t_2468 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_2467, v_x_2465));
                  V v_x3_2469 = heff_tr(heff_call(v_t_2468, 2, (V[]){heff_dup(v_z_242), v_j_2466}));
                  switch (heff_tag_of(v_x3_2469)) {
                  case TAG_Nothing: {
                    heff_drop(v_z_242);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2470 = heff_field(v_x3_2469, 0);
                    heff_take_n(v_x3_2469, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2470)) {
                    case TAG_MkPair: {
                      V v_x_2471 = heff_field(v_x31_2470, 0);
                      V v_j_2472 = heff_field(v_x31_2470, 1);
                      V v_ru_24x31_2470_24MkPair = heff_take_reuse_n(v_x31_2470, 3ULL, 2);
                      HeffT3 v_t_2473 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2472));
                      {
                        V v_field_2475 = v_t_2473.f[1];
                        V v_field_2476 = v_t_2473.f[2];
                        int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                        if ((v_tag_2474 == ((int64_t)0ULL))) {
                          V v_x_2477 = v_field_2475;
                          V v_j_2478 = v_field_2476;
                          V v_t_2479 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_2477));
                          V v_x3_2480 = heff_tr(heff_call(v_t_2479, 2, (V[]){v_z_242, v_j_2478}));
                          switch (heff_tag_of(v_x3_2480)) {
                          case TAG_Nothing: {
                            heff_drop(v_x_2471);
                            heff_drop_cell(v_ru_24x31_2470_24MkPair, 2);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_2481 = heff_field(v_x3_2480, 0);
                            heff_take_n(v_x3_2480, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2481)) {
                            case TAG_MkPair: {
                              V v_x_2482 = heff_field(v_x31_2481, 0);
                              V v_j_2483 = heff_field(v_x31_2481, 1);
                              heff_take_n(v_x31_2481, 3ULL, 2);
                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2470_24MkPair, TAG_ERecord, 2, (V[]){v_x_2471, v_x_2482}), v_j_2483}});
                            }
                            default: return ((HeffT3){{heff_nomatch(v_x31_2481)}});
                            }
                          }
                          default: return ((HeffT3){{heff_nomatch(v_x3_2480)}});
                          }
                        } else {
                          heff_drop(v_z_242);
                          heff_drop(v_x_2471);
                          heff_drop_cell(v_ru_24x31_2470_24MkPair, 2);
                          heff_drop(v_field_2475);
                          heff_drop(v_field_2476);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT3){{heff_nomatch(v_x31_2470)}});
                    }
                  }
                  default: return ((HeffT3){{heff_nomatch(v_x3_2469)}});
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_field_2463);
                  heff_drop(v_field_2464);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6), 2)) {
                V v_x3_2484 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2484)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2485 = heff_field(v_x3_2484, 0);
                  heff_take_n(v_x3_2484, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2485)) {
                  case TAG_MkPair: {
                    V v_x_2486 = heff_field(v_x31_2485, 0);
                    V v_j_2487 = heff_field(v_x31_2485, 1);
                    heff_take_n(v_x31_2485, 3ULL, 2);
                    HeffT3 v_t_2488 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_j_2487));
                    {
                      V v_field_2490 = v_t_2488.f[1];
                      V v_field_2491 = v_t_2488.f[2];
                      int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
                      if ((v_tag_2489 == ((int64_t)0ULL))) {
                        V v_x_2492 = v_field_2490;
                        V v_j_2493 = v_field_2491;
                        HeffT3 v_t_2494 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2493));
                        {
                          V v_field_2496 = v_t_2494.f[1];
                          V v_field_2497 = v_t_2494.f[2];
                          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
                          if ((v_tag_2495 == ((int64_t)0ULL))) {
                            V v_x_2498 = v_field_2496;
                            V v_j_2499 = v_field_2497;
                            V v_t_24100 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2498));
                            V v_x3_24101 = heff_tr(heff_call(v_t_24100, 2, (V[]){heff_dup(v_z_242), v_j_2499}));
                            switch (heff_tag_of(v_x3_24101)) {
                            case TAG_Nothing: {
                              heff_drop(v_z_242);
                              heff_drop(v_x_2486);
                              heff_drop(v_x_2492);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                            case TAG_Just: {
                              V v_x31_24102 = heff_field(v_x3_24101, 0);
                              heff_take_n(v_x3_24101, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24102)) {
                              case TAG_MkPair: {
                                V v_x_24103 = heff_field(v_x31_24102, 0);
                                V v_j_24104 = heff_field(v_x31_24102, 1);
                                heff_take_n(v_x31_24102, 3ULL, 2);
                                HeffT3 v_t_24105 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24104));
                                {
                                  V v_field_24107 = v_t_24105.f[1];
                                  V v_field_24108 = v_t_24105.f[2];
                                  int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
                                  if ((v_tag_24106 == ((int64_t)0ULL))) {
                                    V v_x_24109 = v_field_24107;
                                    V v_j_24110 = v_field_24108;
                                    HeffT2 v_t_24111 = ({ V a_0 = v_x_24109; HeffT2 r_ = (g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(a_0)); heff_drop(v_x_24109); r_; });
                                    {
                                      V v_field_24113 = v_t_24111.f[1];
                                      int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
                                      if ((v_tag_24112 == ((int64_t)0ULL))) {
                                        V v_x_24114 = v_field_24113;
                                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EProj, 4, (V[]){v_x_2486, v_x_2492, v_x_24103, v_x_24114}), v_j_24110}});
                                      } else {
                                        heff_drop(v_x_2486);
                                        heff_drop(v_x_2492);
                                        heff_drop(v_x_24103);
                                        heff_drop(v_j_24110);
                                        heff_drop(v_field_24113);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    heff_drop(v_x_2486);
                                    heff_drop(v_x_2492);
                                    heff_drop(v_x_24103);
                                    heff_drop(v_field_24107);
                                    heff_drop(v_field_24108);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT3){{heff_nomatch(v_x31_24102)}});
                              }
                            }
                            default: return ((HeffT3){{heff_nomatch(v_x3_24101)}});
                            }
                          } else {
                            heff_drop(v_z_242);
                            heff_drop(v_x_2486);
                            heff_drop(v_x_2492);
                            heff_drop(v_field_2496);
                            heff_drop(v_field_2497);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop(v_z_242);
                        heff_drop(v_x_2486);
                        heff_drop(v_field_2490);
                        heff_drop(v_field_2491);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT3){{heff_nomatch(v_x31_2485)}});
                  }
                }
                default: return ((HeffT3){{heff_nomatch(v_x3_2484)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7), 2)) {
                  HeffT3 v_t_24115 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                  {
                    V v_field_24117 = v_t_24115.f[1];
                    V v_field_24118 = v_t_24115.f[2];
                    int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
                    if ((v_tag_24116 == ((int64_t)0ULL))) {
                      V v_x_24119 = v_field_24117;
                      V v_j_24120 = v_field_24118;
                      HeffT3 v_t_24121 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24120));
                      {
                        V v_field_24123 = v_t_24121.f[1];
                        V v_field_24124 = v_t_24121.f[2];
                        int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
                        if ((v_tag_24122 == ((int64_t)0ULL))) {
                          V v_x_24125 = v_field_24123;
                          V v_j_24126 = v_field_24124;
                          V v_t_24127 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24125));
                          V v_x3_24128 = heff_tr(heff_call(v_t_24127, 2, (V[]){heff_dup(v_z_242), v_j_24126}));
                          switch (heff_tag_of(v_x3_24128)) {
                          case TAG_Nothing: {
                            heff_drop(v_z_242);
                            heff_drop(v_x_24119);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_24129 = heff_field(v_x3_24128, 0);
                            heff_take_n(v_x3_24128, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24129)) {
                            case TAG_MkPair: {
                              V v_x_24130 = heff_field(v_x31_24129, 0);
                              V v_j_24131 = heff_field(v_x31_24129, 1);
                              heff_take_n(v_x31_24129, 3ULL, 2);
                              HeffT3 v_t_24132 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24131));
                              {
                                V v_field_24134 = v_t_24132.f[1];
                                V v_field_24135 = v_t_24132.f[2];
                                int64_t v_tag_24133 = ((int64_t)v_t_24132.f[0]);
                                if ((v_tag_24133 == ((int64_t)0ULL))) {
                                  V v_x_24136 = v_field_24134;
                                  V v_j_24137 = v_field_24135;
                                  V v_t_24138 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_24136));
                                  V v_x3_24139 = heff_tr(heff_call(v_t_24138, 2, (V[]){v_z_242, v_j_24137}));
                                  switch (heff_tag_of(v_x3_24139)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_x_24119);
                                    heff_drop(v_x_24130);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                  case TAG_Just: {
                                    V v_x31_24140 = heff_field(v_x3_24139, 0);
                                    heff_take_n(v_x3_24139, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24140)) {
                                    case TAG_MkPair: {
                                      V v_x_24141 = heff_field(v_x31_24140, 0);
                                      V v_j_24142 = heff_field(v_x31_24140, 1);
                                      heff_take_n(v_x31_24140, 3ULL, 2);
                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_ETag, 3, (V[]){v_x_24119, v_x_24130, v_x_24141}), v_j_24142}});
                                    }
                                    default: return ((HeffT3){{heff_nomatch(v_x31_24140)}});
                                    }
                                  }
                                  default: return ((HeffT3){{heff_nomatch(v_x3_24139)}});
                                  }
                                } else {
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_24119);
                                  heff_drop(v_x_24130);
                                  heff_drop(v_field_24134);
                                  heff_drop(v_field_24135);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT3){{heff_nomatch(v_x31_24129)}});
                            }
                          }
                          default: return ((HeffT3){{heff_nomatch(v_x3_24128)}});
                          }
                        } else {
                          heff_drop_rec(v_k_240, 1);
                          heff_drop(v_z_242);
                          heff_drop(v_x_24119);
                          heff_drop(v_field_24123);
                          heff_drop(v_field_24124);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      heff_drop(v_field_24117);
                      heff_drop(v_field_24118);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8), 2)) {
                    V v_m_24143 = heff_dup(heff_rfield(v_k_240, 0));
                    V v_x3_24144 = heff_tr(heff_call(v_m_24143, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24144)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_24145 = heff_field(v_x3_24144, 0);
                      heff_take_n(v_x3_24144, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24145)) {
                      case TAG_MkPair: {
                        V v_x_24146 = heff_field(v_x31_24145, 0);
                        V v_j_24147 = heff_field(v_x31_24145, 1);
                        V v_ru_24x31_24145_24MkPair = heff_take_reuse_n(v_x31_24145, 3ULL, 2);
                        HeffT3 v_t_24148 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24147));
                        {
                          V v_field_24150 = v_t_24148.f[1];
                          V v_field_24151 = v_t_24148.f[2];
                          int64_t v_tag_24149 = ((int64_t)v_t_24148.f[0]);
                          if ((v_tag_24149 == ((int64_t)0ULL))) {
                            V v_x_24152 = v_field_24150;
                            V v_j_24153 = v_field_24151;
                            V v_t_24154 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(v_k_240, v_x_24152));
                            V v_x3_24155 = heff_tr(heff_call(v_t_24154, 2, (V[]){v_z_242, v_j_24153}));
                            switch (heff_tag_of(v_x3_24155)) {
                            case TAG_Nothing: {
                              heff_drop(v_x_24146);
                              heff_drop_cell(v_ru_24x31_24145_24MkPair, 2);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                            case TAG_Just: {
                              V v_x31_24156 = heff_field(v_x3_24155, 0);
                              heff_take_n(v_x3_24155, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24156)) {
                              case TAG_MkPair: {
                                V v_x_24157 = heff_field(v_x31_24156, 0);
                                V v_j_24158 = heff_field(v_x31_24156, 1);
                                heff_take_n(v_x31_24156, 3ULL, 2);
                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24145_24MkPair, TAG_EMatch, 2, (V[]){v_x_24146, v_x_24157}), v_j_24158}});
                              }
                              default: return ((HeffT3){{heff_nomatch(v_x31_24156)}});
                              }
                            }
                            default: return ((HeffT3){{heff_nomatch(v_x3_24155)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_x_24146);
                            heff_drop_cell(v_ru_24x31_24145_24MkPair, 2);
                            heff_drop(v_field_24150);
                            heff_drop(v_field_24151);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT3){{heff_nomatch(v_x31_24145)}});
                      }
                    }
                    default: return ((HeffT3){{heff_nomatch(v_x3_24144)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 1);
                      HeffT3 v_t_24159 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                      {
                        V v_field_24161 = v_t_24159.f[1];
                        V v_field_24162 = v_t_24159.f[2];
                        int64_t v_tag_24160 = ((int64_t)v_t_24159.f[0]);
                        if ((v_tag_24160 == ((int64_t)0ULL))) {
                          V v_x_24163 = v_field_24161;
                          V v_j_24164 = v_field_24162;
                          V v_x1_24165 = ({ V a_0 = v_x_24163; V r_ = (g_heff_2eelab_2eprimitive_2eprimOfName(a_0)); heff_drop(v_x_24163); r_; });
                          switch (heff_tag_of(v_x1_24165)) {
                          case TAG_Nothing: {
                            heff_drop(v_j_24164);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x_24166 = heff_field(v_x1_24165, 0);
                            V v_ru_24x1_24165_24Just = heff_take_reuse_n(v_x1_24165, 1ULL, 1);
                            V v_x_24167 = v_x_24166;
                            V v_j_24168 = v_j_24164;
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_24165_24Just, TAG_EPrim, 1, (V[]){v_x_24167}), v_j_24168}});
                          }
                          default: return ((HeffT3){{heff_nomatch(v_x1_24165)}});
                          }
                        } else {
                          heff_drop(v_field_24161);
                          heff_drop(v_field_24162);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10), 2)) {
                        HeffT3 v_t_24169 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                        {
                          V v_field_24171 = v_t_24169.f[1];
                          V v_field_24172 = v_t_24169.f[2];
                          int64_t v_tag_24170 = ((int64_t)v_t_24169.f[0]);
                          if ((v_tag_24170 == ((int64_t)0ULL))) {
                            V v_x_24173 = v_field_24171;
                            V v_j_24174 = v_field_24172;
                            V v_x1_24175 = ({ V a_0 = v_x_24173; V r_ = (g_heff_2eelab_2eprimitive_2eprimOfName(a_0)); heff_drop(v_x_24173); r_; });
                            switch (heff_tag_of(v_x1_24175)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              heff_drop(v_j_24174);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                            case TAG_Just: {
                              V v_x_24176 = heff_field(v_x1_24175, 0);
                              heff_take_n(v_x1_24175, 1ULL, 1);
                              V v_x_24177 = v_x_24176;
                              V v_j_24178 = v_j_24174;
                              HeffT3 v_t_24179 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24178));
                              {
                                V v_field_24181 = v_t_24179.f[1];
                                V v_field_24182 = v_t_24179.f[2];
                                int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
                                if ((v_tag_24180 == ((int64_t)0ULL))) {
                                  V v_x_24183 = v_field_24181;
                                  V v_j_24184 = v_field_24182;
                                  V v_t_24185 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24183));
                                  V v_x3_24186 = heff_tr(heff_call(v_t_24185, 2, (V[]){v_z_242, v_j_24184}));
                                  switch (heff_tag_of(v_x3_24186)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_x_24177);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                  case TAG_Just: {
                                    V v_x31_24187 = heff_field(v_x3_24186, 0);
                                    heff_take_n(v_x3_24186, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24187)) {
                                    case TAG_MkPair: {
                                      V v_x_24188 = heff_field(v_x31_24187, 0);
                                      V v_j_24189 = heff_field(v_x31_24187, 1);
                                      V v_ru_24x31_24187_24MkPair = heff_take_reuse_n(v_x31_24187, 3ULL, 2);
                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24187_24MkPair, TAG_EPrimCall, 2, (V[]){v_x_24177, v_x_24188}), v_j_24189}});
                                    }
                                    default: return ((HeffT3){{heff_nomatch(v_x31_24187)}});
                                    }
                                  }
                                  default: return ((HeffT3){{heff_nomatch(v_x3_24186)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_24177);
                                  heff_drop(v_field_24181);
                                  heff_drop(v_field_24182);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT3){{heff_nomatch(v_x1_24175)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_field_24171);
                            heff_drop(v_field_24172);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11), 2)) {
                          HeffT3 v_t_24190 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                          {
                            V v_field_24192 = v_t_24190.f[1];
                            V v_field_24193 = v_t_24190.f[2];
                            int64_t v_tag_24191 = ((int64_t)v_t_24190.f[0]);
                            if ((v_tag_24191 == ((int64_t)0ULL))) {
                              V v_x_24194 = v_field_24192;
                              V v_j_24195 = v_field_24193;
                              HeffT3 v_t_24196 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24195));
                              {
                                V v_field_24198 = v_t_24196.f[1];
                                V v_field_24199 = v_t_24196.f[2];
                                int64_t v_tag_24197 = ((int64_t)v_t_24196.f[0]);
                                if ((v_tag_24197 == ((int64_t)0ULL))) {
                                  V v_x_24200 = v_field_24198;
                                  V v_j_24201 = v_field_24199;
                                  V v_t_24202 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24200));
                                  V v_x3_24203 = heff_tr(heff_call(v_t_24202, 2, (V[]){v_z_242, v_j_24201}));
                                  switch (heff_tag_of(v_x3_24203)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_x_24194);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                  case TAG_Just: {
                                    V v_x31_24204 = heff_field(v_x3_24203, 0);
                                    heff_take_n(v_x3_24203, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24204)) {
                                    case TAG_MkPair: {
                                      V v_x_24205 = heff_field(v_x31_24204, 0);
                                      V v_j_24206 = heff_field(v_x31_24204, 1);
                                      V v_ru_24x31_24204_24MkPair = heff_take_reuse_n(v_x31_24204, 3ULL, 2);
                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24204_24MkPair, TAG_ECall, 2, (V[]){v_x_24194, v_x_24205}), v_j_24206}});
                                    }
                                    default: return ((HeffT3){{heff_nomatch(v_x31_24204)}});
                                    }
                                  }
                                  default: return ((HeffT3){{heff_nomatch(v_x3_24203)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_24194);
                                  heff_drop(v_field_24198);
                                  heff_drop(v_field_24199);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              heff_drop(v_field_24192);
                              heff_drop(v_field_24193);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 1);
                            HeffT3 v_t_24207 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                            {
                              V v_field_24209 = v_t_24207.f[1];
                              V v_field_24210 = v_t_24207.f[2];
                              int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
                              if ((v_tag_24208 == ((int64_t)0ULL))) {
                                V v_x_24211 = v_field_24209;
                                V v_j_24212 = v_field_24210;
                                V v_t_24213 = ({ V a_0 = v_x_24211; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24211); r_; });
                                V v_x_24214 = heff_tag_n(TAG_EInt, 1, (V[]){v_t_24213});
                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24214, v_j_24212}});
                              } else {
                                heff_drop(v_field_24209);
                                heff_drop(v_field_24210);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13), 2)) {
                              heff_drop_rec(v_k_240, 1);
                              HeffT3 v_t_24215 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                              {
                                V v_field_24217 = v_t_24215.f[1];
                                V v_field_24218 = v_t_24215.f[2];
                                int64_t v_tag_24216 = ((int64_t)v_t_24215.f[0]);
                                if ((v_tag_24216 == ((int64_t)0ULL))) {
                                  V v_x_24219 = v_field_24217;
                                  V v_j_24220 = v_field_24218;
                                  double v_t_24221 = ({ V a_0 = v_x_24219; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24219); r_; });
                                  V v_x_24222 = heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_24221)});
                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24222, v_j_24220}});
                                } else {
                                  heff_drop(v_field_24217);
                                  heff_drop(v_field_24218);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14), 2)) {
                                heff_drop_rec(v_k_240, 1);
                                HeffT3 v_t_24223 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                {
                                  V v_field_24225 = v_t_24223.f[1];
                                  V v_field_24226 = v_t_24223.f[2];
                                  int64_t v_tag_24224 = ((int64_t)v_t_24223.f[0]);
                                  if ((v_tag_24224 == ((int64_t)0ULL))) {
                                    V v_x_24227 = v_field_24225;
                                    V v_j_24228 = v_field_24226;
                                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EStr, 1, (V[]){v_x_24227}), v_j_24228}});
                                  } else {
                                    heff_drop(v_field_24225);
                                    heff_drop(v_field_24226);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15), 2)) {
                                  heff_drop_rec(v_k_240, 1);
                                  HeffT3 v_t_24229 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                  {
                                    V v_field_24231 = v_t_24229.f[1];
                                    V v_field_24232 = v_t_24229.f[2];
                                    int64_t v_tag_24230 = ((int64_t)v_t_24229.f[0]);
                                    if ((v_tag_24230 == ((int64_t)0ULL))) {
                                      V v_x_24233 = v_field_24231;
                                      V v_j_24234 = v_field_24232;
                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EBytes, 1, (V[]){v_x_24233}), v_j_24234}});
                                    } else {
                                      heff_drop(v_field_24231);
                                      heff_drop(v_field_24232);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16), 2)) {
                                    heff_drop_rec(v_k_240, 1);
                                    V v_s_24235 = heff_dup(v_z_242);
                                    V v_i_24236 = v_z_243;
                                    HeffT3 v_t_24237 = ({ V a_0 = v_s_24235; V a_1 = v_i_24236; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2eword_24cpr(a_0, a_1)); heff_drop(v_s_24235); r_; });
                                    {
                                      V v_field_24239 = v_t_24237.f[1];
                                      V v_field_24240 = v_t_24237.f[2];
                                      int64_t v_tag_24238 = ((int64_t)v_t_24237.f[0]);
                                      V v_x3_24247;
                                      if ((v_tag_24238 == ((int64_t)0ULL))) {
                                        V v_x_24241 = v_field_24239;
                                        V v_j_24242 = v_field_24240;
                                        HeffT2 v_t_24243 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17); V a_1 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18); V a_2 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19); V a_3 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20); V a_4 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21); V a_5 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22); V a_6 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23); V a_7 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24); V a_8 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25); V a_9 = v_x_24241; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(v_x_24241); heff_drop(b_10); r_; });
                                        {
                                          V v_field_24245 = v_t_24243.f[1];
                                          int64_t v_tag_24244 = ((int64_t)v_t_24243.f[0]);
                                          if ((v_tag_24244 == ((int64_t)0ULL))) {
                                            V v_x_24246 = v_field_24245;
                                            v_x3_24247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24246, v_j_24242})});
                                          } else {
                                            heff_drop(v_j_24242);
                                            heff_drop(v_field_24245);
                                            v_x3_24247 = NTAG(TAG_Nothing);
                                          }
                                        }
                                      } else {
                                        heff_drop(v_field_24239);
                                        heff_drop(v_field_24240);
                                        v_x3_24247 = NTAG(TAG_Nothing);
                                      }
                                      switch (heff_tag_of(v_x3_24247)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_z_242);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                      case TAG_Just: {
                                        V v_x31_24248 = heff_field(v_x3_24247, 0);
                                        heff_take_n(v_x3_24247, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24248)) {
                                        case TAG_MkPair: {
                                          V v_x_24249 = heff_field(v_x31_24248, 0);
                                          V v_j_24250 = heff_field(v_x31_24248, 1);
                                          V v_ru_24x31_24248_24MkPair = heff_take_reuse_n(v_x31_24248, 3ULL, 2);
                                          HeffT3 v_t_24251 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24250));
                                          {
                                            V v_field_24253 = v_t_24251.f[1];
                                            V v_field_24254 = v_t_24251.f[2];
                                            int64_t v_tag_24252 = ((int64_t)v_t_24251.f[0]);
                                            if ((v_tag_24252 == ((int64_t)0ULL))) {
                                              V v_x_24255 = v_field_24253;
                                              V v_j_24256 = v_field_24254;
                                              V v_t_24257 = ({ V a_0 = v_x_24255; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24255); r_; });
                                              V v_x_24258 = heff_tag_at_n(v_ru_24x31_24248_24MkPair, TAG_EFixed, 2, (V[]){v_x_24249, v_t_24257});
                                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24258, v_j_24256}});
                                            } else {
                                              heff_drop(v_x_24249);
                                              heff_drop_cell(v_ru_24x31_24248_24MkPair, 2);
                                              heff_drop(v_field_24253);
                                              heff_drop(v_field_24254);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT3){{heff_nomatch(v_x31_24248)}});
                                        }
                                      }
                                      default: return ((HeffT3){{heff_nomatch(v_x3_24247)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26), 2)) {
                                      heff_drop_rec(v_k_240, 1);
                                      HeffT3 v_t_24259 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                      {
                                        V v_field_24261 = v_t_24259.f[1];
                                        V v_field_24262 = v_t_24259.f[2];
                                        int64_t v_tag_24260 = ((int64_t)v_t_24259.f[0]);
                                        if ((v_tag_24260 == ((int64_t)0ULL))) {
                                          V v_x_24263 = v_field_24261;
                                          V v_j_24264 = v_field_24262;
                                          double v_t_24265 = ({ V a_0 = v_x_24263; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24263); r_; });
                                          V v_x_24266 = heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24265)});
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24266, v_j_24264}});
                                        } else {
                                          heff_drop(v_field_24261);
                                          heff_drop(v_field_24262);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27), 2)) {
                                        heff_drop_rec(v_k_240, 1);
                                        heff_drop(v_z_242);
                                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_EAbandon), v_z_243}});
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str28), 2)) {
                                          HeffT3 v_t_24267 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
                                          {
                                            V v_field_24269 = v_t_24267.f[1];
                                            V v_field_24270 = v_t_24267.f[2];
                                            int64_t v_tag_24268 = ((int64_t)v_t_24267.f[0]);
                                            if ((v_tag_24268 == ((int64_t)0ULL))) {
                                              V v_x_24271 = v_field_24269;
                                              V v_j_24272 = v_field_24270;
                                              V v_t_24273 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_24271));
                                              V v_x3_24274 = heff_tr(heff_call(v_t_24273, 2, (V[]){heff_dup(v_z_242), v_j_24272}));
                                              switch (heff_tag_of(v_x3_24274)) {
                                              case TAG_Nothing: {
                                                heff_drop_rec(v_k_240, 1);
                                                heff_drop(v_z_242);
                                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                              }
                                              case TAG_Just: {
                                                V v_x31_24275 = heff_field(v_x3_24274, 0);
                                                heff_take_n(v_x3_24274, 1ULL, 1);
                                                switch (heff_tag_of(v_x31_24275)) {
                                                case TAG_MkPair: {
                                                  V v_x_24276 = heff_field(v_x31_24275, 0);
                                                  V v_j_24277 = heff_field(v_x31_24275, 1);
                                                  heff_take_n(v_x31_24275, 3ULL, 2);
                                                  V v_x3_24278 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_24277}));
                                                  switch (heff_tag_of(v_x3_24278)) {
                                                  case TAG_Nothing: {
                                                    heff_drop_rec(v_k_240, 1);
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_x_24276);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                  }
                                                  case TAG_Just: {
                                                    V v_x31_24279 = heff_field(v_x3_24278, 0);
                                                    heff_take_n(v_x3_24278, 1ULL, 1);
                                                    switch (heff_tag_of(v_x31_24279)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24280 = heff_field(v_x31_24279, 0);
                                                      V v_j_24281 = heff_field(v_x31_24279, 1);
                                                      heff_take_n(v_x31_24279, 3ULL, 2);
                                                      V v_x3_24282 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24281}));
                                                      switch (heff_tag_of(v_x3_24282)) {
                                                      case TAG_Nothing: {
                                                        heff_drop(v_x_24276);
                                                        heff_drop(v_x_24280);
                                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                      }
                                                      case TAG_Just: {
                                                        V v_x31_24283 = heff_field(v_x3_24282, 0);
                                                        heff_take_n(v_x3_24282, 1ULL, 1);
                                                        switch (heff_tag_of(v_x31_24283)) {
                                                        case TAG_MkPair: {
                                                          V v_x_24284 = heff_field(v_x31_24283, 0);
                                                          V v_j_24285 = heff_field(v_x31_24283, 1);
                                                          heff_take_n(v_x31_24283, 3ULL, 2);
                                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_ESet, 3, (V[]){v_x_24276, v_x_24280, v_x_24284}), v_j_24285}});
                                                        }
                                                        default: return ((HeffT3){{heff_nomatch(v_x31_24283)}});
                                                        }
                                                      }
                                                      default: return ((HeffT3){{heff_nomatch(v_x3_24282)}});
                                                      }
                                                    }
                                                    default: return ((HeffT3){{heff_nomatch(v_x31_24279)}});
                                                    }
                                                  }
                                                  default: return ((HeffT3){{heff_nomatch(v_x3_24278)}});
                                                  }
                                                }
                                                default: return ((HeffT3){{heff_nomatch(v_x31_24275)}});
                                                }
                                              }
                                              default: return ((HeffT3){{heff_nomatch(v_x3_24274)}});
                                              }
                                            } else {
                                              heff_drop_rec(v_k_240, 1);
                                              heff_drop(v_z_242);
                                              heff_drop(v_field_24269);
                                              heff_drop(v_field_24270);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str29), 2)) {
                                            HeffT3 v_t_24286 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
                                            {
                                              V v_field_24288 = v_t_24286.f[1];
                                              V v_field_24289 = v_t_24286.f[2];
                                              int64_t v_tag_24287 = ((int64_t)v_t_24286.f[0]);
                                              if ((v_tag_24287 == ((int64_t)0ULL))) {
                                                V v_x_24290 = v_field_24288;
                                                V v_j_24291 = v_field_24289;
                                                V v_t_24292 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24290));
                                                V v_x3_24293 = heff_tr(heff_call(v_t_24292, 2, (V[]){v_z_242, v_j_24291}));
                                                switch (heff_tag_of(v_x3_24293)) {
                                                case TAG_Nothing: {
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24294 = heff_field(v_x3_24293, 0);
                                                  V v_ru_24x3_24293_24Just = heff_take_reuse_n(v_x3_24293, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24294)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24295 = heff_field(v_x31_24294, 0);
                                                    V v_j_24296 = heff_field(v_x31_24294, 1);
                                                    heff_take_n(v_x31_24294, 3ULL, 2);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_24293_24Just, TAG_EValues, 1, (V[]){v_x_24295}), v_j_24296}});
                                                  }
                                                  default: return ((HeffT3){{heff_nomatch(v_x31_24294)}});
                                                  }
                                                }
                                                default: return ((HeffT3){{heff_nomatch(v_x3_24293)}});
                                                }
                                              } else {
                                                heff_drop_rec(v_k_240, 1);
                                                heff_drop(v_z_242);
                                                heff_drop(v_field_24288);
                                                heff_drop(v_field_24289);
                                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str30), 2)) {
                                              HeffT1 v_t_24297 = (g_heff_2ecompile_2eirtext_2eckOf_24cpr(v_k_240));
                                              {
                                                V v_field_24298 = v_t_24297.f[0];
                                                V v_m_24299 = v_field_24298;
                                                V v_x3_24300 = heff_tr(heff_call(v_m_24299, 2, (V[]){v_z_242, v_z_243}));
                                                switch (heff_tag_of(v_x3_24300)) {
                                                case TAG_Nothing: {
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24301 = heff_field(v_x3_24300, 0);
                                                  V v_ru_24x3_24300_24Just = heff_take_reuse_n(v_x3_24300, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24301)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24302 = heff_field(v_x31_24301, 0);
                                                    V v_j_24303 = heff_field(v_x31_24301, 1);
                                                    heff_take_n(v_x31_24301, 3ULL, 2);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_24300_24Just, TAG_EBool, 1, (V[]){v_x_24302}), v_j_24303}});
                                                  }
                                                  default: return ((HeffT3){{heff_nomatch(v_x31_24301)}});
                                                  }
                                                }
                                                default: return ((HeffT3){{heff_nomatch(v_x3_24300)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str31), 2)) {
                                                HeffT3 v_t_24304 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                                                {
                                                  V v_field_24306 = v_t_24304.f[1];
                                                  V v_field_24307 = v_t_24304.f[2];
                                                  int64_t v_tag_24305 = ((int64_t)v_t_24304.f[0]);
                                                  if ((v_tag_24305 == ((int64_t)0ULL))) {
                                                    V v_x_24308 = v_field_24306;
                                                    V v_j_24309 = v_field_24307;
                                                    V v_x3_24310 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24309}));
                                                    switch (heff_tag_of(v_x3_24310)) {
                                                    case TAG_Nothing: {
                                                      heff_drop(v_x_24308);
                                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                    case TAG_Just: {
                                                      V v_x31_24311 = heff_field(v_x3_24310, 0);
                                                      heff_take_n(v_x3_24310, 1ULL, 1);
                                                      switch (heff_tag_of(v_x31_24311)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24312 = heff_field(v_x31_24311, 0);
                                                        V v_j_24313 = heff_field(v_x31_24311, 1);
                                                        V v_ru_24x31_24311_24MkPair = heff_take_reuse_n(v_x31_24311, 3ULL, 2);
                                                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24311_24MkPair, TAG_EFix, 2, (V[]){v_x_24308, v_x_24312}), v_j_24313}});
                                                      }
                                                      default: return ((HeffT3){{heff_nomatch(v_x31_24311)}});
                                                      }
                                                    }
                                                    default: return ((HeffT3){{heff_nomatch(v_x3_24310)}});
                                                    }
                                                  } else {
                                                    heff_drop_rec(v_k_240, 1);
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24306);
                                                    heff_drop(v_field_24307);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                heff_drop_rec(v_k_240, 1);
                                                return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

static V g_heff_2ecompile_2eirtext_2etakeExpr_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2etakeExpr_st;
static V g_heff_2ecompile_2eirtext_2etakeExpr_init(void) {
  return heff_dup(heff_rfield(g_heff_2ecompile_2eirtext_2edk_get(), 0));
}
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2etakeExpr_st)) return g_heff_2ecompile_2eirtext_2etakeExpr_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2etakeExpr_val, &g_heff_2ecompile_2eirtext_2etakeExpr_st, g_heff_2ecompile_2eirtext_2etakeExpr_init);
}
Clo g_heff_2ecompile_2eirtext_2ebytesH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2ebytesH_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2ebytesH(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eirtext_2ebytesH_24cpr(v_s_240, v_i_241, v_a_242, v_b_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2ebytesH(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eirtext_2estrsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2estrsH_24dps(v_xs_243, v_rest_241, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_243}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eirtext_2estrsH_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_244}), heff_hole()});
      V v_cell_247 = heff_tag_at_n(v_ru_24x11_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_245}), heff_hole()});
      V v_u_248 = heff_setField(heff_dup(v_cell_246), MK_INT(1LL), v_cell_247);
      V v_u_249 = ({ V a_0 = v_fs_243; V a_1 = v_rest_241; V a_2 = v_u_248; V r_ = (g_heff_2ecompile_2eirtext_2efieldsH_24dps(a_0, a_1, a_2)); heff_drop(v_u_248); r_; });
      heff_drop(v_u_249);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str12, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str13, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str14, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str15, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str16, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str17, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str18, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str19, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str20, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2enodeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enodeH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enodeH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_HS, 1, (V[]){v_x_242}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(1LL)}), v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EGlobal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EGlobal, TAG_HS, 1, (V[]){v_g_244}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(2LL)}), v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_247}), v_rest_241});
    V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_246, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2410});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(3LL)}), v_t_2411});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_args_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2413));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2413, v_rest_241));
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_f_2412}), v_t_2416});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(4LL)}), v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    V v_a_2419 = heff_field(v_x1_240, 1);
    V v_b_2420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2420}), v_rest_241});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2419}), v_t_2421});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2418}), v_t_2422});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(5LL)}), v_t_2423});
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x1_240, 0);
    V v_ts_2425 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2424));
    V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2425));
    V v_t_2428 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2425));
    V v_t_2429 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2427}), v_t_2428});
    V v_t_2430 = (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_2424, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2426}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(6LL)}), v_t_2431});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_l_2433 = heff_field(v_x1_240, 1);
    V v_sh_2434 = heff_field(v_x1_240, 2);
    V v_t_2435 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2438;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_FtFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2437 = heff_field(v_t_2435, 0);
      heff_take_n(v_t_2435, 1ULL, 1);
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str1);
        break;
      }
      case TAG_I16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str2);
        break;
      }
      case TAG_I32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str3);
        break;
      }
      case TAG_I64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str4);
        break;
      }
      case TAG_U8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str5);
        break;
      }
      case TAG_U16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str6);
        break;
      }
      case TAG_U32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str7);
        break;
      }
      case TAG_U64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str8);
        break;
      }
      case TAG_F32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str9);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str11);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2438}), v_rest_241});
    V v_t_2440 = (g_heff_2ecompile_2eirtext_2estrsH(v_sh_2434, v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2436}), v_t_2440});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_2433}), v_t_2441});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_2432}), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(7LL)}), v_t_2443});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x1_240, 0);
    V v_args_2445 = heff_field(v_x1_240, 1);
    V v_ts_2446 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2445));
    V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2446));
    V v_t_2449 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2446));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2448}), v_t_2449});
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2445, v_t_2450));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2447}), v_t_2451});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2444}), v_t_2452});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(8LL)}), v_t_2453});
  }
  case TAG_EMatch: {
    V v_s_2454 = heff_field(v_x1_240, 0);
    V v_arms_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2455));
    V v_t_2457 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_2455, v_rest_241));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2456}), v_t_2457});
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_s_2454}), v_t_2458});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(9LL)}), v_t_2459});
  }
  case TAG_EPrim: {
    V v_p_2460 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2461 = ({ V a_0 = v_p_2460; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2460); r_; });
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EPrim, TAG_HS, 1, (V[]){v_t_2461}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(10LL)}), v_t_2462});
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_x1_240, 0);
    V v_args_2464 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2465 = ({ V a_0 = v_p_2463; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2463); r_; });
    V v_t_2466 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2464));
    V v_t_2467 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2464, v_rest_241));
    V v_t_2468 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2466}), v_t_2467});
    V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2465}), v_t_2468});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(11LL)}), v_t_2469});
  }
  case TAG_ECall: {
    V v_g_2470 = heff_field(v_x1_240, 0);
    V v_args_2471 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2472 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2471));
    V v_t_2473 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2471, v_rest_241));
    V v_t_2474 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2472}), v_t_2473});
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_2470}), v_t_2474});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(12LL)}), v_t_2475});
  }
  case TAG_EInt: {
    V v_i_2476 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_HS, 1, (V[]){heff_intShow(v_i_2476)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(13LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2478 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_nf(v_x1_240, 0ULL, 1);
    V v_t_2479 = heff_tag_at_n(v_ru_24x1_240_24EFloat, TAG_HS, 1, (V[]){heff_floatShow(v_x_2478)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(14LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2480 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_HS, 1, (V[]){v_s_2480}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(15LL)}), v_t_2481});
  }
  case TAG_EBytes: {
    V v_s_2482 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBytes = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBytes, TAG_HS, 1, (V[]){v_s_2482}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(20LL)}), v_t_2483});
  }
  case TAG_EFixed: {
    V v_w_2484 = heff_field(v_x1_240, 0);
    V v_n_2485 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2486;
    switch (heff_tag_of(v_w_2484)) {
    case TAG_I8: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str12);
      break;
    }
    case TAG_I16: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str13);
      break;
    }
    case TAG_I32: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str14);
      break;
    }
    case TAG_I64: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str15);
      break;
    }
    case TAG_U8: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str16);
      break;
    }
    case TAG_U16: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str17);
      break;
    }
    case TAG_U32: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str18);
      break;
    }
    case TAG_U64: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str19);
      break;
    }
    case TAG_F32: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str20);
      break;
    }
    default: heff_nomatch(v_w_2484);
    }
    V v_t_2487 = heff_tag_n(TAG_HS, 1, (V[]){heff_intShow(v_n_2485)});
    V v_t_2488 = heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2486}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(16LL)}), v_t_2488});
  }
  case TAG_EFloat32: {
    V v_x_2489 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat32 = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2490 = heff_tag_at_n(v_ru_24x1_240_24EFloat32, TAG_HS, 1, (V[]){heff_floatShow(v_x_2489)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(17LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(18LL)}), v_rest_241});
  }
  case TAG_EBool: {
    V v_c_2491 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBool = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBool, TAG_HC, 1, (V[]){v_c_2491}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(21LL)}), v_t_2492});
  }
  case TAG_ESet: {
    V v_xs_2493 = heff_field(v_x1_240, 0);
    V v_a_2494 = heff_field(v_x1_240, 1);
    V v_b_2495 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2496 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2493));
    V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2495}), v_rest_241});
    V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2494}), v_t_2497});
    V v_t_2499 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_2493, v_t_2498));
    V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2496}), v_t_2499});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(22LL)}), v_t_24100});
  }
  case TAG_EValues: {
    V v_es_24101 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EValues = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24102 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_24101));
    V v_t_24103 = (g_heff_2ecompile_2eirtext_2eexprsH(v_es_24101, v_rest_241));
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EValues, TAG_HN, 1, (V[]){v_t_24102}), v_t_24103});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(23LL)}), v_t_24104});
  }
  case TAG_EFix: {
    V v_f_24105 = heff_field(v_x1_240, 0);
    V v_b_24106 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_24107 = heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_24106}), v_rest_241});
    V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_f_24105}), v_t_24107});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(19LL)}), v_t_24108});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enodeH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V v_rest_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_rest_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1);
        break;
      }
      case TAG_I16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2);
        break;
      }
      case TAG_I32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3);
        break;
      }
      case TAG_I64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4);
        break;
      }
      case TAG_U8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5);
        break;
      }
      case TAG_U16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6);
        break;
      }
      case TAG_U32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7);
        break;
      }
      case TAG_U64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8);
        break;
      }
      case TAG_F32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_245}), heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(v_rest_240, v_xs_243, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(a[0], a[1]);
}