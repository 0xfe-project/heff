// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ecompile_2eirtext_2earmD(V, V, V);
V g_heff_2ecompile_2eirtext_2earmD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmD_clo;
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldsH(V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V);
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2ecompile_2eirtext_2estrsT_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsT(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_str0), v_x_242));
    V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsT_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_24dps_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsT_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_24dps_str0), v_x_243));
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_247;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_rest_244 = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(v_es_243, v_rest_241));
    HEFF_LAST return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_242), v_rest_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_244 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0), v_x_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_rest_241})});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_g_245, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2), v_g_245));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_249, v_rest_241));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_248, v_rest_2410));
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4), v_t_2413});
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_240, 0);
    V v_as_2415 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2415));
    V v_t_2417 = ({ V a_0 = v_as_2415; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2415); r_; });
    V v_rest_2418 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2417});
    V v_t_2419 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2414, v_rest_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5), v_t_2419});
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_x2_240, 0);
    V v_a_2421 = heff_field(v_x2_240, 1);
    V v_b_2422 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2423 = heff_intShow(heff_strLength_lent(v_x_2420, 0));
    V v_t_2424 = heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6), v_x_2420));
    V v_rest_2425 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2422, v_rest_241));
    V v_t_2426 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2421, v_rest_2425));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2426})});
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_x2_240, 0);
    V v_ts_2428 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2427));
    V v_xs_2430 = (g_list_2emap_24s143096761x246530315(v_ts_2428));
    V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
    V v_t_2432 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2430, v_rest_241));
    V v_t_2433 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2431), v_t_2432});
    V v_t_2434 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2427, v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2429), v_t_2434});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8), v_t_2435});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_240, 0);
    V v_l_2437 = heff_field(v_x2_240, 1);
    V v_sh_2438 = heff_field(v_x2_240, 2);
    V v_t_2439 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2440 = heff_intShow(heff_strLength_lent(v_l_2437, 0));
    V v_t_2441 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9), v_l_2437));
    V v_s_2443;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_FtFloat: {
      v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2442 = heff_field(v_t_2439, 0);
      heff_take_n(v_t_2439, 1ULL, 1);
      switch (heff_tag_of(v_w_2442)) {
      case TAG_I8: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11);
        break;
      }
      case TAG_I16: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12);
        break;
      }
      case TAG_I32: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13);
        break;
      }
      case TAG_I64: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14);
        break;
      }
      case TAG_U8: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15);
        break;
      }
      case TAG_U16: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16);
        break;
      }
      case TAG_U32: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17);
        break;
      }
      case TAG_U64: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18);
        break;
      }
      case TAG_F32: {
        v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19);
        break;
      }
      default: heff_nomatch(v_w_2442);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20);
      break;
    }
    case TAG_FtAny: {
      v_s_2443 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21);
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    V v_t_2444 = heff_intShow(heff_strLength_lent(v_s_2443, 0));
    V v_t_2445 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22), v_s_2443));
    V v_rest_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_rest_241});
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2438));
    V v_t_2448 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2438, v_rest_2446));
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2447), v_t_2448});
    V v_rest_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2449});
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2436, v_rest_2450));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23), v_t_2451});
  }
  case TAG_ETag: {
    V v_t_2452 = heff_field(v_x2_240, 0);
    V v_as_2453 = heff_field(v_x2_240, 1);
    V v_ts_2454 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2455 = heff_intShow(heff_strLength_lent(v_t_2452, 0));
    V v_t_2456 = heff_strAppend(v_t_2455, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24), v_t_2452));
    V v_t_2457 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2453));
    V v_xs_2458 = (g_list_2emap_24s143096761x246530315(v_ts_2454));
    V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2458));
    V v_t_2460 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2458, v_rest_241));
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2459), v_t_2460});
    V v_t_2462 = ({ V a_0 = v_as_2453; V a_1 = v_t_2461; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2453); r_; });
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2457), v_t_2462});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, v_t_2463})});
  }
  case TAG_EMatch: {
    V v_s_2464 = heff_field(v_x2_240, 0);
    V v_arms_2465 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2466 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2465));
    V v_t_2467 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2465, v_rest_241));
    V v_rest_2468 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2466), v_t_2467});
    V v_t_2469 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2464, v_rest_2468));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26), v_t_2469});
  }
  case TAG_EPrim: {
    V v_p_2470 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2471 = heff_intShow(heff_strLength_lent(v_p_2470, 0));
    V v_t_2472 = heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27), v_p_2470));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, v_rest_241})});
  }
  case TAG_EPrimCall: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_as_2474 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2475 = heff_intShow(heff_strLength_lent(v_p_2473, 0));
    V v_t_2476 = heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29), v_p_2473));
    V v_t_2477 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2474));
    V v_t_2478 = ({ V a_0 = v_as_2474; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2474); r_; });
    V v_t_2479 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2477), v_t_2478});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2479})});
  }
  case TAG_ECall: {
    V v_g_2480 = heff_field(v_x2_240, 0);
    V v_as_2481 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2482 = heff_intShow(heff_strLength_lent(v_g_2480, 0));
    V v_t_2483 = heff_strAppend(v_t_2482, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31), v_g_2480));
    V v_t_2484 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2481));
    V v_t_2485 = ({ V a_0 = v_as_2481; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2481); r_; });
    V v_t_2486 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2484), v_t_2485});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, v_t_2486})});
  }
  case TAG_EInt: {
    V v_i_2487 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2488 = heff_intShow(v_i_2487);
    V v_t_2489 = heff_intShow(heff_strLength_lent(v_s_2488, 0));
    V v_t_2490 = heff_strAppend(v_t_2489, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33), v_s_2488));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2491 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_2492 = heff_floatShow(v_x_2491);
    V v_t_2493 = heff_intShow(heff_strLength_lent(v_s_2492, 0));
    V v_t_2494 = heff_strAppend(v_t_2493, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35), v_s_2492));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2495 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2496 = heff_intShow(heff_strLength_lent(v_s_2495, 0));
    V v_t_2497 = heff_strAppend(v_t_2496, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37), v_s_2495));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_rest_241})});
  }
  case TAG_EBytes: {
    V v_s_2498 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2499 = heff_intShow(heff_strLength_lent(v_s_2498, 0));
    V v_t_24100 = heff_strAppend(v_t_2499, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39), v_s_2498));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, v_rest_241})});
  }
  case TAG_EFixed: {
    V v_w_24101 = heff_field(v_x2_240, 0);
    V v_n_24102 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24103;
    switch (heff_tag_of(v_w_24101)) {
    case TAG_I8: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41);
      break;
    }
    case TAG_I16: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42);
      break;
    }
    case TAG_I32: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43);
      break;
    }
    case TAG_I64: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44);
      break;
    }
    case TAG_U8: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45);
      break;
    }
    case TAG_U16: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46);
      break;
    }
    case TAG_U32: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47);
      break;
    }
    case TAG_U64: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48);
      break;
    }
    case TAG_F32: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49);
      break;
    }
    default: heff_nomatch(v_w_24101);
    }
    V v_s_24104 = heff_intShow(v_n_24102);
    V v_t_24105 = heff_intShow(heff_strLength_lent(v_s_24104, 0));
    V v_t_24106 = heff_strAppend(v_t_24105, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50), v_s_24104));
    V v_t_24107 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24103, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51), v_t_24107});
  }
  case TAG_EFloat32: {
    V v_x_24108 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24109 = heff_floatShow(v_x_24108);
    V v_t_24110 = heff_intShow(heff_strLength_lent(v_s_24109, 0));
    V v_t_24111 = heff_strAppend(v_t_24110, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52), v_s_24109));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54), v_rest_241});
  }
  case TAG_EFix: {
    V v_f_24112 = heff_field(v_x2_240, 0);
    V v_b_24113 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24114 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55), heff_hole()});
    V v_t_24115 = heff_intShow(heff_strLength_lent(v_f_24112, 0));
    V v_t_24116 = heff_strAppend(v_t_24115, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56), v_f_24112));
    V v_cell_24117 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24116, heff_hole()});
    V v_u_24118 = heff_setField(heff_dup(v_cell_24114), MK_INT(1LL), heff_dup(v_cell_24117));
    heff_drop(v_u_24118);
    V v_u_24119 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_b_24113, v_rest_241, v_cell_24117));
    heff_drop(v_u_24119);
    return v_cell_24114;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD(V v_d_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_lam0_clo);
  } else {
    V v_t_246 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_dup(v_d_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_clo), 2, (V[]){v_d_240, v_t_246});
  }
}
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  heff_drop(v_s_243);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_244});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo), 1, (V[]){v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
Clo g_heff_2ecompile_2eirtext_2earmD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmD_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2earmD(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_j_246));
      V v_x3_2412;
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        v_x3_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_249));
          v_x3_2412 = heff_tr(heff_call(v_t_2411, 2, (V[]){heff_dup(v_s_241), v_j_2410}));
          break;
        }
        default: heff_nomatch(v_x31_248);
        }
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      switch (heff_tag_of(v_x3_2412)) {
      case TAG_Nothing: {
        heff_drop_rec(v_k_240, 1);
        heff_drop(v_s_241);
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2413 = heff_field(v_x3_2412, 0);
        heff_take_n(v_x3_2412, 1ULL, 1);
        switch (heff_tag_of(v_x31_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x31_2413, 0);
          V v_j_2415 = heff_field(v_x31_2413, 1);
          heff_take_n(v_x31_2413, 3ULL, 2);
          V v_x3_2416 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_s_241, v_j_2415}));
          switch (heff_tag_of(v_x3_2416)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_243_24Just, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
            heff_drop(v_x_2414);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2417 = heff_field(v_x3_2416, 0);
            heff_take_n(v_x3_2416, 1ULL, 1);
            switch (heff_tag_of(v_x31_2417)) {
            case TAG_MkPair: {
              V v_x_2418 = heff_field(v_x31_2417, 0);
              V v_j_2419 = heff_field(v_x31_2417, 1);
              heff_take_n(v_x31_2417, 3ULL, 2);
              V v_t_2420 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_x_245, v_x_2414, v_x_2418}), v_j_2419});
              return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2420});
            }
            default: return heff_nomatch(v_x31_2417);
            }
          }
          default: return heff_nomatch(v_x3_2416);
          }
        }
        default: return heff_nomatch(v_x31_2413);
        }
      }
      default: return heff_nomatch(v_x3_2412);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2earmD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmD(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo), 1, (V[]){v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}

static V g_heff_2ecompile_2eirtext_2etakeExpr_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2etakeExpr_st;
static V g_heff_2ecompile_2eirtext_2etakeExpr_init(void) {
  return heff_dup(heff_rfield(g_heff_2ecompile_2eirtext_2edk_get(), 0));
}
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2etakeExpr_st)) return g_heff_2ecompile_2eirtext_2etakeExpr_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2etakeExpr_val, &g_heff_2ecompile_2eirtext_2etakeExpr_st, g_heff_2ecompile_2eirtext_2etakeExpr_init);
}
Clo g_heff_2ecompile_2eirtext_2ebytesH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2ebytesH_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2ebytesH(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    V v_t_245 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), MK_INT(256LL));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_247 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), MK_INT(256LL));
    V v_t_248 = heff_intMod(heff_intAdd(v_t_247, MK_INT(1LL)), MK_INT(2147483629LL));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_248});
  } else {
    V v_t_249 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
    V v_t_2410 = heff_intMod(heff_intAdd(v_t_249, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_2411 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
    V v_t_2412 = heff_intMod(heff_intAdd(v_t_2411, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_2410;
    V t_3 = v_t_2412;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2ebytesH(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2estrsH_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_244}), heff_hole()});
      V v_cell_247 = heff_tag_at_n(v_ru_24x11_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_245}), heff_hole()});
      V v_u_248 = heff_setField(heff_dup(v_cell_246), MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_u_249 = (g_heff_2ecompile_2eirtext_2efieldsH_24dps(v_fs_243, v_rest_241, v_cell_247));
      heff_drop(v_u_249);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str12, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str13, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str14, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str15, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str16, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str17, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str18, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str19, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str20, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2enodeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enodeH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enodeH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_HS, 1, (V[]){v_x_242}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(1LL)}), v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EGlobal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EGlobal, TAG_HS, 1, (V[]){v_g_244}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(2LL)}), v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_247}), v_rest_241});
    V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_246, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2410});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(3LL)}), v_t_2411});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_as_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2413));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2413, v_rest_241));
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_f_2412}), v_t_2416});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(4LL)}), v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    V v_a_2419 = heff_field(v_x1_240, 1);
    V v_b_2420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2420}), v_rest_241});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2419}), v_t_2421});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2418}), v_t_2422});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(5LL)}), v_t_2423});
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x1_240, 0);
    V v_ts_2425 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2424));
    V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2425));
    V v_t_2428 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2425));
    V v_t_2429 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2427}), v_t_2428});
    V v_t_2430 = (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_2424, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2426}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(6LL)}), v_t_2431});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_l_2433 = heff_field(v_x1_240, 1);
    V v_sh_2434 = heff_field(v_x1_240, 2);
    V v_t_2435 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2438;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_FtFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2437 = heff_field(v_t_2435, 0);
      heff_take_n(v_t_2435, 1ULL, 1);
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str1);
        break;
      }
      case TAG_I16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str2);
        break;
      }
      case TAG_I32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str3);
        break;
      }
      case TAG_I64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str4);
        break;
      }
      case TAG_U8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str5);
        break;
      }
      case TAG_U16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str6);
        break;
      }
      case TAG_U32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str7);
        break;
      }
      case TAG_U64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str8);
        break;
      }
      case TAG_F32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str9);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str11);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2438}), v_rest_241});
    V v_t_2440 = (g_heff_2ecompile_2eirtext_2estrsH(v_sh_2434, v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2436}), v_t_2440});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_2433}), v_t_2441});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_2432}), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(7LL)}), v_t_2443});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x1_240, 0);
    V v_as_2445 = heff_field(v_x1_240, 1);
    V v_ts_2446 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2445));
    V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2446));
    V v_t_2449 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2446));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2448}), v_t_2449});
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2445, v_t_2450));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2447}), v_t_2451});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2444}), v_t_2452});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(8LL)}), v_t_2453});
  }
  case TAG_EMatch: {
    V v_s_2454 = heff_field(v_x1_240, 0);
    V v_arms_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2455));
    V v_t_2457 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_2455, v_rest_241));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2456}), v_t_2457});
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_s_2454}), v_t_2458});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(9LL)}), v_t_2459});
  }
  case TAG_EPrim: {
    V v_p_2460 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EPrim, TAG_HS, 1, (V[]){v_p_2460}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(10LL)}), v_t_2461});
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_x1_240, 0);
    V v_as_2463 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2464 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2463));
    V v_t_2465 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2463, v_rest_241));
    V v_t_2466 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2464}), v_t_2465});
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_p_2462}), v_t_2466});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(11LL)}), v_t_2467});
  }
  case TAG_ECall: {
    V v_g_2468 = heff_field(v_x1_240, 0);
    V v_as_2469 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2469));
    V v_t_2471 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2469, v_rest_241));
    V v_t_2472 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2470}), v_t_2471});
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_2468}), v_t_2472});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(12LL)}), v_t_2473});
  }
  case TAG_EInt: {
    V v_i_2474 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2475 = heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_HS, 1, (V[]){heff_intShow(v_i_2474)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(13LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2476 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x1_240_24EFloat, TAG_HS, 1, (V[]){heff_floatShow(v_x_2476)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(14LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2478 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_HS, 1, (V[]){v_s_2478}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(15LL)}), v_t_2479});
  }
  case TAG_EBytes: {
    V v_s_2480 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBytes = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBytes, TAG_HS, 1, (V[]){v_s_2480}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(20LL)}), v_t_2481});
  }
  case TAG_EFixed: {
    V v_w_2482 = heff_field(v_x1_240, 0);
    V v_n_2483 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2484;
    switch (heff_tag_of(v_w_2482)) {
    case TAG_I8: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str12);
      break;
    }
    case TAG_I16: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str13);
      break;
    }
    case TAG_I32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str14);
      break;
    }
    case TAG_I64: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str15);
      break;
    }
    case TAG_U8: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str16);
      break;
    }
    case TAG_U16: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str17);
      break;
    }
    case TAG_U32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str18);
      break;
    }
    case TAG_U64: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str19);
      break;
    }
    case TAG_F32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str20);
      break;
    }
    default: heff_nomatch(v_w_2482);
    }
    V v_t_2485 = heff_tag_n(TAG_HS, 1, (V[]){heff_intShow(v_n_2483)});
    V v_t_2486 = heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2484}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(16LL)}), v_t_2486});
  }
  case TAG_EFloat32: {
    V v_x_2487 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat32 = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2488 = heff_tag_at_n(v_ru_24x1_240_24EFloat32, TAG_HS, 1, (V[]){heff_floatShow(v_x_2487)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(17LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(18LL)}), v_rest_241});
  }
  case TAG_EFix: {
    V v_f_2489 = heff_field(v_x1_240, 0);
    V v_b_2490 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2491 = heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2490}), v_rest_241});
    V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_f_2489}), v_t_2491});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(19LL)}), v_t_2492});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enodeH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V v_rest_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_rest_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1);
        break;
      }
      case TAG_I16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2);
        break;
      }
      case TAG_I32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3);
        break;
      }
      case TAG_I64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4);
        break;
      }
      case TAG_U8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5);
        break;
      }
      case TAG_U16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6);
        break;
      }
      case TAG_U32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7);
        break;
      }
      case TAG_U64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8);
        break;
      }
      case TAG_F32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_245}), heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(v_rest_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(a[0], a[1]);
}