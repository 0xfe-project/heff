// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HC 9068
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
HeffT2 g_heff_2ecompile_2eirtext_2earmD_24cpr(V, V, V);
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2eckOf(V);
V g_heff_2ecompile_2eirtext_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eckOf_clo;
V g_heff_2ecompile_2eirtext_2econdH(V, V);
V g_heff_2ecompile_2eirtext_2econdH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdH_clo;
V g_heff_2ecompile_2eirtext_2econdOfTag(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo;
HeffT2 g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH(V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
HeffT2 g_heff_2ecompile_2eirtext_2efixedD_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V, V);
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V);
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2ecompile_2eirtext_2estrsT_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsT(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_str0), v_x_242));
    V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsT_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_24dps_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsT_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_24dps_str0), v_x_243));
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_247;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_rest_244 = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(v_es_243, v_rest_241));
    HEFF_LAST return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_242), v_rest_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str57, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str58, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str59, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_244 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0), v_x_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_rest_241})});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_g_245, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2), v_g_245));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_249, v_rest_241));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_248, v_rest_2410));
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4), v_t_2413});
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_240, 0);
    V v_args_2415 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2415));
    V v_t_2417 = ({ V a_0 = v_args_2415; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2415); r_; });
    V v_rest_2418 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2417});
    V v_t_2419 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2414, v_rest_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5), v_t_2419});
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_x2_240, 0);
    V v_a_2421 = heff_field(v_x2_240, 1);
    V v_b_2422 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2423 = heff_intShow(heff_strLength_lent(v_x_2420, 0));
    V v_t_2424 = heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6), v_x_2420));
    V v_rest_2425 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2422, v_rest_241));
    V v_t_2426 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2421, v_rest_2425));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2426})});
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_x2_240, 0);
    V v_ts_2428 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2427));
    V v_xs_2430 = (g_list_2emap_24s143096761x246530315(v_ts_2428));
    V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
    V v_t_2432 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2430, v_rest_241));
    V v_t_2433 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2431), v_t_2432});
    V v_t_2434 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2427, v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2429), v_t_2434});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8), v_t_2435});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_240, 0);
    V v_l_2437 = heff_field(v_x2_240, 1);
    V v_sh_2438 = heff_field(v_x2_240, 2);
    V v_t_2439 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2440 = heff_intShow(heff_strLength_lent(v_l_2437, 0));
    V v_t_2441 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9), v_l_2437));
    V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2438));
    V v_s_2444;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_FtFloat: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2443 = heff_field(v_t_2439, 0);
      heff_take_n(v_t_2439, 1ULL, 1);
      switch (heff_tag_of(v_w_2443)) {
      case TAG_I8: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11);
        break;
      }
      case TAG_I16: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12);
        break;
      }
      case TAG_I32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13);
        break;
      }
      case TAG_I64: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14);
        break;
      }
      case TAG_U8: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15);
        break;
      }
      case TAG_U16: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16);
        break;
      }
      case TAG_U32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17);
        break;
      }
      case TAG_U64: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18);
        break;
      }
      case TAG_F32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19);
        break;
      }
      default: heff_nomatch(v_w_2443);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20);
      break;
    }
    case TAG_FtAny: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21);
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    V v_t_2445 = heff_intShow(heff_strLength_lent(v_s_2444, 0));
    V v_t_2446 = heff_strAppend(v_t_2445, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22), v_s_2444));
    V v_t_2447 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_rest_241})));
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2442), v_t_2447});
    V v_rest_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2448});
    V v_t_2450 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2436, v_rest_2449));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23), v_t_2450});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_x2_240, 0);
    V v_args_2452 = heff_field(v_x2_240, 1);
    V v_ts_2453 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2454 = heff_intShow(heff_strLength_lent(v_t_2451, 0));
    V v_t_2455 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24), v_t_2451));
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2452));
    V v_xs_2457 = (g_list_2emap_24s143096761x246530315(v_ts_2453));
    V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2457));
    V v_t_2459 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2457, v_rest_241));
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2458), v_t_2459});
    V v_t_2461 = ({ V a_0 = v_args_2452; V a_1 = v_t_2460; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2452); r_; });
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2456), v_t_2461});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2462})});
  }
  case TAG_EMatch: {
    V v_s_2463 = heff_field(v_x2_240, 0);
    V v_arms_2464 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2464));
    V v_t_2466 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2464, v_rest_241));
    V v_rest_2467 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2465), v_t_2466});
    V v_t_2468 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2463, v_rest_2467));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26), v_t_2468});
  }
  case TAG_EPrim: {
    V v_p_2469 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2470 = heff_intShow(heff_strLength_lent(v_p_2469, 0));
    V v_t_2471 = heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27), v_p_2469));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, v_rest_241})});
  }
  case TAG_EPrimCall: {
    V v_p_2472 = heff_field(v_x2_240, 0);
    V v_args_2473 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2474 = heff_intShow(heff_strLength_lent(v_p_2472, 0));
    V v_t_2475 = heff_strAppend(v_t_2474, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29), v_p_2472));
    V v_t_2476 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2473));
    V v_t_2477 = ({ V a_0 = v_args_2473; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2473); r_; });
    V v_t_2478 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2476), v_t_2477});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_t_2478})});
  }
  case TAG_ECall: {
    V v_g_2479 = heff_field(v_x2_240, 0);
    V v_args_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2481 = heff_intShow(heff_strLength_lent(v_g_2479, 0));
    V v_t_2482 = heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31), v_g_2479));
    V v_t_2483 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2480));
    V v_t_2484 = ({ V a_0 = v_args_2480; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2480); r_; });
    V v_t_2485 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2483), v_t_2484});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, v_t_2485})});
  }
  case TAG_EInt: {
    V v_i_2486 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2487 = heff_intShow(v_i_2486);
    V v_t_2488 = heff_intShow(heff_strLength_lent(v_s_2487, 0));
    V v_t_2489 = heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33), v_s_2487));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2490 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_2491 = heff_floatShow(v_x_2490);
    V v_t_2492 = heff_intShow(heff_strLength_lent(v_s_2491, 0));
    V v_t_2493 = heff_strAppend(v_t_2492, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35), v_s_2491));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2493, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2495 = heff_intShow(heff_strLength_lent(v_s_2494, 0));
    V v_t_2496 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37), v_s_2494));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, v_rest_241})});
  }
  case TAG_EBytes: {
    V v_s_2497 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2498 = heff_intShow(heff_strLength_lent(v_s_2497, 0));
    V v_t_2499 = heff_strAppend(v_t_2498, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39), v_s_2497));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, v_rest_241})});
  }
  case TAG_EFixed: {
    V v_w_24100 = heff_field(v_x2_240, 0);
    V v_n_24101 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24102;
    switch (heff_tag_of(v_w_24100)) {
    case TAG_I8: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41);
      break;
    }
    case TAG_I16: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42);
      break;
    }
    case TAG_I32: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43);
      break;
    }
    case TAG_I64: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44);
      break;
    }
    case TAG_U8: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45);
      break;
    }
    case TAG_U16: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46);
      break;
    }
    case TAG_U32: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47);
      break;
    }
    case TAG_U64: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48);
      break;
    }
    case TAG_F32: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49);
      break;
    }
    default: heff_nomatch(v_w_24100);
    }
    V v_s_24103 = heff_intShow(v_n_24101);
    V v_t_24104 = heff_intShow(heff_strLength_lent(v_s_24103, 0));
    V v_t_24105 = heff_strAppend(v_t_24104, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50), v_s_24103));
    V v_t_24106 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24102, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51), v_t_24106});
  }
  case TAG_EFloat32: {
    V v_x_24107 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24108 = heff_floatShow(v_x_24107);
    V v_t_24109 = heff_intShow(heff_strLength_lent(v_s_24108, 0));
    V v_t_24110 = heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52), v_s_24108));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54), v_rest_241});
  }
  case TAG_EBool: {
    V v_c_24111 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24112 = ({ V a_0 = v_c_24111; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(a_0, a_1)); heff_drop(v_c_24111); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55), v_t_24112});
  }
  case TAG_ESet: {
    V v_xs_24113 = heff_field(v_x2_240, 0);
    V v_a_24114 = heff_field(v_x2_240, 1);
    V v_b_24115 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_rest_24116 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_24115, v_rest_241));
    V v_rest_24117 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_24114, v_rest_24116));
    V v_t_24118 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24113));
    V v_t_24119 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_24113, v_rest_24117));
    V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24118), v_t_24119});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56), v_t_24120});
  }
  case TAG_EValues: {
    V v_es_24121 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24122 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_24121));
    V v_t_24123 = ({ V a_0 = v_es_24121; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_es_24121); r_; });
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24122), v_t_24123});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str57), v_t_24124});
  }
  case TAG_EFix: {
    V v_f_24125 = heff_field(v_x2_240, 0);
    V v_b_24126 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24127 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str58), heff_hole()});
    V v_t_24128 = heff_intShow(heff_strLength_lent(v_f_24125, 0));
    V v_t_24129 = heff_strAppend(v_t_24128, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str59), v_f_24125));
    V v_cell_24130 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24129, heff_hole()});
    V v_u_24131 = heff_setField(heff_dup(v_cell_24127), MK_INT(1LL), heff_dup(v_cell_24130));
    heff_drop(v_u_24131);
    V v_u_24132 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_b_24126, v_rest_241, v_cell_24130));
    heff_drop(v_u_24132);
    return v_cell_24127;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD(V v_d_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_dup(v_d_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_clo), 2, (V[]){v_d_240, v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo);
  } else {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo), 1, (V[]){v_t_244});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}
Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econdOfTag_entry, 5, 0};

V g_heff_2ecompile_2eirtext_2econdOfTag(V v_k_240, V v_c_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(v_k_240, v_c_241, v_x3_242, v_z_243, v_z_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_247});
    } else {
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eirtext_2econdOfTag(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo);
  } else {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo), 1, (V[]){v_t_244});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0, 2, 0};
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args);
Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V v_lit_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_lit_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo);
  } else {
    V v_more_245 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(heff_dup(v_lit_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_clo_n(g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1, 2, 2, (V[]){v_lit_240, v_more_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_i_247 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_more_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_248 = (g_heff_2ecompile_2eirtext_2earmD_24cpr(v_lit_240, heff_dup(v_s_246), v_i_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x31_2411 = v_field_2410;
      switch (heff_tag_of(v_x31_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x31_2411, 0);
        V v_j_2413 = heff_field(v_x31_2411, 1);
        V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
        V v_x3_2414 = heff_tr(heff_call(v_more_245, 2, (V[]){v_s_246, v_j_2413}));
        switch (heff_tag_of(v_x3_2414)) {
        case TAG_Nothing: {
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2415 = heff_field(v_x3_2414, 0);
          V v_ru_24x3_2414_24Just = heff_take_reuse_n(v_x3_2414, 1ULL, 1);
          switch (heff_tag_of(v_x31_2415)) {
          case TAG_MkPair: {
            V v_x_2416 = heff_field(v_x31_2415, 0);
            V v_j_2417 = heff_field(v_x31_2415, 1);
            heff_take_n(v_x31_2415, 3ULL, 2);
            V v_t_2418 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_x_2416}), v_j_2417});
            return heff_tag_at_n(v_ru_24x3_2414_24Just, TAG_Just, 1, (V[]){v_t_2418});
          }
          default: return heff_nomatch(v_x31_2415);
          }
        }
        default: return heff_nomatch(v_x3_2414);
        }
      }
      default: return heff_nomatch(v_x31_2411);
      }
    } else {
      heff_drop(v_s_246);
      heff_drop(v_more_245);
      heff_drop(v_field_2410);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str28, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str29, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str30, 1, "F");

HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_248}), v_j_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 1);
      HeffT2 v_t_2411 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x31_2414 = v_field_2413;
          switch (heff_tag_of(v_x31_2414)) {
          case TAG_MkPair: {
            V v_x_2415 = heff_field(v_x31_2414, 0);
            V v_j_2416 = heff_field(v_x31_2414, 1);
            V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
            V v_t_2417 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2415}), v_j_2416});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2414)}});
          }
        } else {
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2), 2)) {
        HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x31_2421 = v_field_2420;
            switch (heff_tag_of(v_x31_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x31_2421, 0);
              V v_j_2423 = heff_field(v_x31_2421, 1);
              V v_ru_24x31_2421_24MkPair = heff_take_reuse_n(v_x31_2421, 3ULL, 2);
              V v_t_2424 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2422));
              V v_x3_2425 = heff_tr(heff_call(v_t_2424, 2, (V[]){heff_dup(v_z_242), v_j_2423}));
              switch (heff_tag_of(v_x3_2425)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                heff_drop_cell(v_ru_24x31_2421_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2426 = heff_field(v_x3_2425, 0);
                heff_take_n(v_x3_2425, 1ULL, 1);
                switch (heff_tag_of(v_x31_2426)) {
                case TAG_MkPair: {
                  V v_x_2427 = heff_field(v_x31_2426, 0);
                  V v_j_2428 = heff_field(v_x31_2426, 1);
                  heff_take_n(v_x31_2426, 3ULL, 2);
                  V v_x3_2429 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2428}));
                  switch (heff_tag_of(v_x3_2429)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x31_2421_24MkPair, 2);
                    heff_drop(v_x_2427);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2430 = heff_field(v_x3_2429, 0);
                    heff_take_n(v_x3_2429, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2430)) {
                    case TAG_MkPair: {
                      V v_x_2431 = heff_field(v_x31_2430, 0);
                      V v_j_2432 = heff_field(v_x31_2430, 1);
                      heff_take_n(v_x31_2430, 3ULL, 2);
                      V v_t_2433 = heff_tag_at_n(v_ru_24x31_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_x_2427, v_x_2431}), v_j_2432});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2433}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2430)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2429)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2426)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2425)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2421)}});
            }
          } else {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            heff_drop(v_field_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3), 2)) {
          V v_x3_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2434)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2435 = heff_field(v_x3_2434, 0);
            heff_take_n(v_x3_2434, 1ULL, 1);
            switch (heff_tag_of(v_x31_2435)) {
            case TAG_MkPair: {
              V v_x_2436 = heff_field(v_x31_2435, 0);
              V v_j_2437 = heff_field(v_x31_2435, 1);
              V v_ru_24x31_2435_24MkPair = heff_take_reuse_n(v_x31_2435, 3ULL, 2);
              HeffT2 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2437));
              {
                V v_field_2440 = v_t_2438.f[1];
                int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                if ((v_tag_2439 == ((int64_t)0ULL))) {
                  V v_x31_2441 = v_field_2440;
                  switch (heff_tag_of(v_x31_2441)) {
                  case TAG_MkPair: {
                    V v_x_2442 = heff_field(v_x31_2441, 0);
                    V v_j_2443 = heff_field(v_x31_2441, 1);
                    heff_take_n(v_x31_2441, 3ULL, 2);
                    V v_t_2444 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2442));
                    V v_x3_2445 = heff_tr(heff_call(v_t_2444, 2, (V[]){v_z_242, v_j_2443}));
                    switch (heff_tag_of(v_x3_2445)) {
                    case TAG_Nothing: {
                      heff_drop(v_x_2436);
                      heff_drop_cell(v_ru_24x31_2435_24MkPair, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2446 = heff_field(v_x3_2445, 0);
                      heff_take_n(v_x3_2445, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2446)) {
                      case TAG_MkPair: {
                        V v_x_2447 = heff_field(v_x31_2446, 0);
                        V v_j_2448 = heff_field(v_x31_2446, 1);
                        heff_take_n(v_x31_2446, 3ULL, 2);
                        V v_t_2449 = heff_tag_at_n(v_ru_24x31_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2436, v_x_2447}), v_j_2448});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2449}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2446)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2445)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_x_2436);
                  heff_drop_cell(v_ru_24x31_2435_24MkPair, 2);
                  heff_drop(v_field_2440);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2435)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2434)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4), 2)) {
            HeffT2 v_t_2450 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
            {
              V v_field_2452 = v_t_2450.f[1];
              int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
              if ((v_tag_2451 == ((int64_t)0ULL))) {
                V v_x31_2453 = v_field_2452;
                switch (heff_tag_of(v_x31_2453)) {
                case TAG_MkPair: {
                  V v_x_2454 = heff_field(v_x31_2453, 0);
                  V v_j_2455 = heff_field(v_x31_2453, 1);
                  V v_ru_24x31_2453_24MkPair = heff_take_reuse_n(v_x31_2453, 3ULL, 2);
                  V v_x3_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_2455}));
                  switch (heff_tag_of(v_x3_2456)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_k_240, 1);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2454);
                    heff_drop_cell(v_ru_24x31_2453_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2457 = heff_field(v_x3_2456, 0);
                    heff_take_n(v_x3_2456, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2457)) {
                    case TAG_MkPair: {
                      V v_x_2458 = heff_field(v_x31_2457, 0);
                      V v_j_2459 = heff_field(v_x31_2457, 1);
                      heff_take_n(v_x31_2457, 3ULL, 2);
                      V v_x3_2460 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2459}));
                      switch (heff_tag_of(v_x3_2460)) {
                      case TAG_Nothing: {
                        heff_drop(v_x_2454);
                        heff_drop_cell(v_ru_24x31_2453_24MkPair, 2);
                        heff_drop(v_x_2458);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2461 = heff_field(v_x3_2460, 0);
                        heff_take_n(v_x3_2460, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2461)) {
                        case TAG_MkPair: {
                          V v_x_2462 = heff_field(v_x31_2461, 0);
                          V v_j_2463 = heff_field(v_x31_2461, 1);
                          heff_take_n(v_x31_2461, 3ULL, 2);
                          V v_t_2464 = heff_tag_at_n(v_ru_24x31_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2454, v_x_2458, v_x_2462}), v_j_2463});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2464}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2461)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2460)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2457)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2456)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2453)}});
                }
              } else {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                heff_drop(v_field_2452);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5), 2)) {
              HeffT2 v_t_2465 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
              {
                V v_field_2467 = v_t_2465.f[1];
                int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                if ((v_tag_2466 == ((int64_t)0ULL))) {
                  V v_x31_2468 = v_field_2467;
                  switch (heff_tag_of(v_x31_2468)) {
                  case TAG_MkPair: {
                    V v_x_2469 = heff_field(v_x31_2468, 0);
                    V v_j_2470 = heff_field(v_x31_2468, 1);
                    V v_ru_24x31_2468_24MkPair = heff_take_reuse_n(v_x31_2468, 3ULL, 2);
                    V v_t_2471 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2efieldD_clo), 1, (V[]){v_k_240}));
                    V v_t_2472 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_2471, v_x_2469));
                    V v_x3_2473 = heff_tr(heff_call(v_t_2472, 2, (V[]){heff_dup(v_z_242), v_j_2470}));
                    switch (heff_tag_of(v_x3_2473)) {
                    case TAG_Nothing: {
                      heff_drop(v_z_242);
                      heff_drop_cell(v_ru_24x31_2468_24MkPair, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2474 = heff_field(v_x3_2473, 0);
                      heff_take_n(v_x3_2473, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2474)) {
                      case TAG_MkPair: {
                        V v_x_2475 = heff_field(v_x31_2474, 0);
                        V v_j_2476 = heff_field(v_x31_2474, 1);
                        heff_take_n(v_x31_2474, 3ULL, 2);
                        HeffT2 v_t_2477 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2476));
                        {
                          V v_field_2479 = v_t_2477.f[1];
                          int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
                          if ((v_tag_2478 == ((int64_t)0ULL))) {
                            V v_x31_2480 = v_field_2479;
                            switch (heff_tag_of(v_x31_2480)) {
                            case TAG_MkPair: {
                              V v_x_2481 = heff_field(v_x31_2480, 0);
                              V v_j_2482 = heff_field(v_x31_2480, 1);
                              heff_take_n(v_x31_2480, 3ULL, 2);
                              V v_t_2483 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_2481));
                              V v_x3_2484 = heff_tr(heff_call(v_t_2483, 2, (V[]){v_z_242, v_j_2482}));
                              switch (heff_tag_of(v_x3_2484)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x31_2468_24MkPair, 2);
                                heff_drop(v_x_2475);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_2485 = heff_field(v_x3_2484, 0);
                                heff_take_n(v_x3_2484, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2485)) {
                                case TAG_MkPair: {
                                  V v_x_2486 = heff_field(v_x31_2485, 0);
                                  V v_j_2487 = heff_field(v_x31_2485, 1);
                                  heff_take_n(v_x31_2485, 3ULL, 2);
                                  V v_t_2488 = heff_tag_at_n(v_ru_24x31_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2475, v_x_2486}), v_j_2487});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2488}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_2485)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_2484)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2480)}});
                            }
                          } else {
                            heff_drop(v_z_242);
                            heff_drop_cell(v_ru_24x31_2468_24MkPair, 2);
                            heff_drop(v_x_2475);
                            heff_drop(v_field_2479);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2474)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2473)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2468)}});
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_field_2467);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6), 2)) {
                V v_x3_2489 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2489)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2490 = heff_field(v_x3_2489, 0);
                  heff_take_n(v_x3_2489, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2490)) {
                  case TAG_MkPair: {
                    V v_x_2491 = heff_field(v_x31_2490, 0);
                    V v_j_2492 = heff_field(v_x31_2490, 1);
                    V v_ru_24x31_2490_24MkPair = heff_take_reuse_n(v_x31_2490, 3ULL, 2);
                    HeffT2 v_t_2493 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_2492));
                    {
                      V v_field_2495 = v_t_2493.f[1];
                      int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
                      if ((v_tag_2494 == ((int64_t)0ULL))) {
                        V v_x31_2496 = v_field_2495;
                        switch (heff_tag_of(v_x31_2496)) {
                        case TAG_MkPair: {
                          V v_x_2497 = heff_field(v_x31_2496, 0);
                          V v_j_2498 = heff_field(v_x31_2496, 1);
                          heff_take_n(v_x31_2496, 3ULL, 2);
                          HeffT2 v_t_2499 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2498));
                          {
                            V v_field_24101 = v_t_2499.f[1];
                            int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
                            if ((v_tag_24100 == ((int64_t)0ULL))) {
                              V v_x31_24102 = v_field_24101;
                              switch (heff_tag_of(v_x31_24102)) {
                              case TAG_MkPair: {
                                V v_x_24103 = heff_field(v_x31_24102, 0);
                                V v_j_24104 = heff_field(v_x31_24102, 1);
                                heff_take_n(v_x31_24102, 3ULL, 2);
                                V v_t_24105 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_24103));
                                V v_x3_24106 = heff_tr(heff_call(v_t_24105, 2, (V[]){heff_dup(v_z_242), v_j_24104}));
                                switch (heff_tag_of(v_x3_24106)) {
                                case TAG_Nothing: {
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_2491);
                                  heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                                  heff_drop(v_x_2497);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24107 = heff_field(v_x3_24106, 0);
                                  heff_take_n(v_x3_24106, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24107)) {
                                  case TAG_MkPair: {
                                    V v_x_24108 = heff_field(v_x31_24107, 0);
                                    V v_j_24109 = heff_field(v_x31_24107, 1);
                                    heff_take_n(v_x31_24107, 3ULL, 2);
                                    HeffT2 v_t_24110 = ({ V a_0 = v_z_242; V a_1 = v_j_24109; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                    {
                                      V v_field_24112 = v_t_24110.f[1];
                                      int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
                                      if ((v_tag_24111 == ((int64_t)0ULL))) {
                                        V v_x31_24113 = v_field_24112;
                                        switch (heff_tag_of(v_x31_24113)) {
                                        case TAG_MkPair: {
                                          V v_x_24114 = heff_field(v_x31_24113, 0);
                                          V v_j_24115 = heff_field(v_x31_24113, 1);
                                          heff_take_n(v_x31_24113, 3ULL, 2);
                                          HeffT2 v_t_24116 = ({ V a_0 = v_x_24114; HeffT2 r_ = (g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(a_0)); heff_drop(v_x_24114); r_; });
                                          {
                                            V v_field_24118 = v_t_24116.f[1];
                                            int64_t v_tag_24117 = ((int64_t)v_t_24116.f[0]);
                                            if ((v_tag_24117 == ((int64_t)0ULL))) {
                                              V v_x_24119 = v_field_24118;
                                              V v_t_24120 = heff_tag_at_n(v_ru_24x31_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2491, v_x_2497, v_x_24108, v_x_24119}), v_j_24115});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24120}});
                                            } else {
                                              heff_drop(v_x_2491);
                                              heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                                              heff_drop(v_x_2497);
                                              heff_drop(v_x_24108);
                                              heff_drop(v_j_24115);
                                              heff_drop(v_field_24118);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24113)}});
                                        }
                                      } else {
                                        heff_drop(v_x_2491);
                                        heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                                        heff_drop(v_x_2497);
                                        heff_drop(v_x_24108);
                                        heff_drop(v_field_24112);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24107)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24106)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24102)}});
                              }
                            } else {
                              heff_drop(v_z_242);
                              heff_drop(v_x_2491);
                              heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                              heff_drop(v_x_2497);
                              heff_drop(v_field_24101);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2496)}});
                        }
                      } else {
                        heff_drop(v_z_242);
                        heff_drop(v_x_2491);
                        heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                        heff_drop(v_field_2495);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2490)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2489)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7), 2)) {
                  HeffT2 v_t_24121 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                  {
                    V v_field_24123 = v_t_24121.f[1];
                    int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
                    if ((v_tag_24122 == ((int64_t)0ULL))) {
                      V v_x31_24124 = v_field_24123;
                      switch (heff_tag_of(v_x31_24124)) {
                      case TAG_MkPair: {
                        V v_x_24125 = heff_field(v_x31_24124, 0);
                        V v_j_24126 = heff_field(v_x31_24124, 1);
                        V v_ru_24x31_24124_24MkPair = heff_take_reuse_n(v_x31_24124, 3ULL, 2);
                        HeffT2 v_t_24127 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24126));
                        {
                          V v_field_24129 = v_t_24127.f[1];
                          int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
                          if ((v_tag_24128 == ((int64_t)0ULL))) {
                            V v_x31_24130 = v_field_24129;
                            switch (heff_tag_of(v_x31_24130)) {
                            case TAG_MkPair: {
                              V v_x_24131 = heff_field(v_x31_24130, 0);
                              V v_j_24132 = heff_field(v_x31_24130, 1);
                              heff_take_n(v_x31_24130, 3ULL, 2);
                              V v_t_24133 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24131));
                              V v_x3_24134 = heff_tr(heff_call(v_t_24133, 2, (V[]){heff_dup(v_z_242), v_j_24132}));
                              switch (heff_tag_of(v_x3_24134)) {
                              case TAG_Nothing: {
                                heff_drop(v_z_242);
                                heff_drop(v_x_24125);
                                heff_drop_cell(v_ru_24x31_24124_24MkPair, 2);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24135 = heff_field(v_x3_24134, 0);
                                heff_take_n(v_x3_24134, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24135)) {
                                case TAG_MkPair: {
                                  V v_x_24136 = heff_field(v_x31_24135, 0);
                                  V v_j_24137 = heff_field(v_x31_24135, 1);
                                  heff_take_n(v_x31_24135, 3ULL, 2);
                                  HeffT2 v_t_24138 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24137));
                                  {
                                    V v_field_24140 = v_t_24138.f[1];
                                    int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
                                    if ((v_tag_24139 == ((int64_t)0ULL))) {
                                      V v_x31_24141 = v_field_24140;
                                      switch (heff_tag_of(v_x31_24141)) {
                                      case TAG_MkPair: {
                                        V v_x_24142 = heff_field(v_x31_24141, 0);
                                        V v_j_24143 = heff_field(v_x31_24141, 1);
                                        heff_take_n(v_x31_24141, 3ULL, 2);
                                        V v_t_24144 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_24142));
                                        V v_x3_24145 = heff_tr(heff_call(v_t_24144, 2, (V[]){v_z_242, v_j_24143}));
                                        switch (heff_tag_of(v_x3_24145)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24125);
                                          heff_drop_cell(v_ru_24x31_24124_24MkPair, 2);
                                          heff_drop(v_x_24136);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24146 = heff_field(v_x3_24145, 0);
                                          heff_take_n(v_x3_24145, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24146)) {
                                          case TAG_MkPair: {
                                            V v_x_24147 = heff_field(v_x31_24146, 0);
                                            V v_j_24148 = heff_field(v_x31_24146, 1);
                                            heff_take_n(v_x31_24146, 3ULL, 2);
                                            V v_t_24149 = heff_tag_at_n(v_ru_24x31_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_x_24125, v_x_24136, v_x_24147}), v_j_24148});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24149}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24146)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24145)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24141)}});
                                      }
                                    } else {
                                      heff_drop(v_z_242);
                                      heff_drop(v_x_24125);
                                      heff_drop_cell(v_ru_24x31_24124_24MkPair, 2);
                                      heff_drop(v_x_24136);
                                      heff_drop(v_field_24140);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24135)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24134)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24130)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_x_24125);
                            heff_drop_cell(v_ru_24x31_24124_24MkPair, 2);
                            heff_drop(v_field_24129);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24124)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      heff_drop(v_field_24123);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8), 2)) {
                    V v_x3_24150 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24150)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_24151 = heff_field(v_x3_24150, 0);
                      heff_take_n(v_x3_24150, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24151)) {
                      case TAG_MkPair: {
                        V v_x_24152 = heff_field(v_x31_24151, 0);
                        V v_j_24153 = heff_field(v_x31_24151, 1);
                        V v_ru_24x31_24151_24MkPair = heff_take_reuse_n(v_x31_24151, 3ULL, 2);
                        HeffT2 v_t_24154 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24153));
                        {
                          V v_field_24156 = v_t_24154.f[1];
                          int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
                          if ((v_tag_24155 == ((int64_t)0ULL))) {
                            V v_x31_24157 = v_field_24156;
                            switch (heff_tag_of(v_x31_24157)) {
                            case TAG_MkPair: {
                              V v_x_24158 = heff_field(v_x31_24157, 0);
                              V v_j_24159 = heff_field(v_x31_24157, 1);
                              heff_take_n(v_x31_24157, 3ULL, 2);
                              V v_t_24160 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(v_k_240, v_x_24158));
                              V v_x3_24161 = heff_tr(heff_call(v_t_24160, 2, (V[]){v_z_242, v_j_24159}));
                              switch (heff_tag_of(v_x3_24161)) {
                              case TAG_Nothing: {
                                heff_drop(v_x_24152);
                                heff_drop_cell(v_ru_24x31_24151_24MkPair, 2);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24162 = heff_field(v_x3_24161, 0);
                                heff_take_n(v_x3_24161, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24162)) {
                                case TAG_MkPair: {
                                  V v_x_24163 = heff_field(v_x31_24162, 0);
                                  V v_j_24164 = heff_field(v_x31_24162, 1);
                                  heff_take_n(v_x31_24162, 3ULL, 2);
                                  V v_t_24165 = heff_tag_at_n(v_ru_24x31_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24152, v_x_24163}), v_j_24164});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24165}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24162)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24161)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24157)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_x_24152);
                            heff_drop_cell(v_ru_24x31_24151_24MkPair, 2);
                            heff_drop(v_field_24156);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24151)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_24150)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 1);
                      HeffT2 v_t_24166 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                      {
                        V v_field_24168 = v_t_24166.f[1];
                        int64_t v_tag_24167 = ((int64_t)v_t_24166.f[0]);
                        if ((v_tag_24167 == ((int64_t)0ULL))) {
                          V v_x31_24169 = v_field_24168;
                          switch (heff_tag_of(v_x31_24169)) {
                          case TAG_MkPair: {
                            V v_x_24170 = heff_field(v_x31_24169, 0);
                            V v_j_24171 = heff_field(v_x31_24169, 1);
                            V v_ru_24x31_24169_24MkPair = heff_take_reuse_n(v_x31_24169, 3ULL, 2);
                            V v_t_24172 = heff_tag_at_n(v_ru_24x31_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24170}), v_j_24171});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24172}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24169)}});
                          }
                        } else {
                          heff_drop(v_field_24168);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10), 2)) {
                        HeffT2 v_t_24173 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                        {
                          V v_field_24175 = v_t_24173.f[1];
                          int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
                          if ((v_tag_24174 == ((int64_t)0ULL))) {
                            V v_x31_24176 = v_field_24175;
                            switch (heff_tag_of(v_x31_24176)) {
                            case TAG_MkPair: {
                              V v_x_24177 = heff_field(v_x31_24176, 0);
                              V v_j_24178 = heff_field(v_x31_24176, 1);
                              V v_ru_24x31_24176_24MkPair = heff_take_reuse_n(v_x31_24176, 3ULL, 2);
                              HeffT2 v_t_24179 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24178));
                              {
                                V v_field_24181 = v_t_24179.f[1];
                                int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
                                if ((v_tag_24180 == ((int64_t)0ULL))) {
                                  V v_x31_24182 = v_field_24181;
                                  switch (heff_tag_of(v_x31_24182)) {
                                  case TAG_MkPair: {
                                    V v_x_24183 = heff_field(v_x31_24182, 0);
                                    V v_j_24184 = heff_field(v_x31_24182, 1);
                                    heff_take_n(v_x31_24182, 3ULL, 2);
                                    V v_t_24185 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24183));
                                    V v_x3_24186 = heff_tr(heff_call(v_t_24185, 2, (V[]){v_z_242, v_j_24184}));
                                    switch (heff_tag_of(v_x3_24186)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_x_24177);
                                      heff_drop_cell(v_ru_24x31_24176_24MkPair, 2);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_24187 = heff_field(v_x3_24186, 0);
                                      heff_take_n(v_x3_24186, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24187)) {
                                      case TAG_MkPair: {
                                        V v_x_24188 = heff_field(v_x31_24187, 0);
                                        V v_j_24189 = heff_field(v_x31_24187, 1);
                                        heff_take_n(v_x31_24187, 3ULL, 2);
                                        V v_t_24190 = heff_tag_at_n(v_ru_24x31_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x_24177, v_x_24188}), v_j_24189});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24190}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24187)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_24186)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24182)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_24177);
                                  heff_drop_cell(v_ru_24x31_24176_24MkPair, 2);
                                  heff_drop(v_field_24181);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24176)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_field_24175);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11), 2)) {
                          HeffT2 v_t_24191 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                          {
                            V v_field_24193 = v_t_24191.f[1];
                            int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
                            if ((v_tag_24192 == ((int64_t)0ULL))) {
                              V v_x31_24194 = v_field_24193;
                              switch (heff_tag_of(v_x31_24194)) {
                              case TAG_MkPair: {
                                V v_x_24195 = heff_field(v_x31_24194, 0);
                                V v_j_24196 = heff_field(v_x31_24194, 1);
                                V v_ru_24x31_24194_24MkPair = heff_take_reuse_n(v_x31_24194, 3ULL, 2);
                                HeffT2 v_t_24197 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24196));
                                {
                                  V v_field_24199 = v_t_24197.f[1];
                                  int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
                                  if ((v_tag_24198 == ((int64_t)0ULL))) {
                                    V v_x31_24200 = v_field_24199;
                                    switch (heff_tag_of(v_x31_24200)) {
                                    case TAG_MkPair: {
                                      V v_x_24201 = heff_field(v_x31_24200, 0);
                                      V v_j_24202 = heff_field(v_x31_24200, 1);
                                      heff_take_n(v_x31_24200, 3ULL, 2);
                                      V v_t_24203 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24201));
                                      V v_x3_24204 = heff_tr(heff_call(v_t_24203, 2, (V[]){v_z_242, v_j_24202}));
                                      switch (heff_tag_of(v_x3_24204)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_x_24195);
                                        heff_drop_cell(v_ru_24x31_24194_24MkPair, 2);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                      case TAG_Just: {
                                        V v_x31_24205 = heff_field(v_x3_24204, 0);
                                        heff_take_n(v_x3_24204, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24205)) {
                                        case TAG_MkPair: {
                                          V v_x_24206 = heff_field(v_x31_24205, 0);
                                          V v_j_24207 = heff_field(v_x31_24205, 1);
                                          heff_take_n(v_x31_24205, 3ULL, 2);
                                          V v_t_24208 = heff_tag_at_n(v_ru_24x31_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_x_24195, v_x_24206}), v_j_24207});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24208}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24205)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x3_24204)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24200)}});
                                    }
                                  } else {
                                    heff_drop_rec(v_k_240, 1);
                                    heff_drop(v_z_242);
                                    heff_drop(v_x_24195);
                                    heff_drop_cell(v_ru_24x31_24194_24MkPair, 2);
                                    heff_drop(v_field_24199);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24194)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              heff_drop(v_field_24193);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 1);
                            HeffT2 v_t_24209 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                            {
                              V v_field_24211 = v_t_24209.f[1];
                              int64_t v_tag_24210 = ((int64_t)v_t_24209.f[0]);
                              if ((v_tag_24210 == ((int64_t)0ULL))) {
                                V v_x31_24212 = v_field_24211;
                                switch (heff_tag_of(v_x31_24212)) {
                                case TAG_MkPair: {
                                  V v_x_24213 = heff_field(v_x31_24212, 0);
                                  V v_j_24214 = heff_field(v_x31_24212, 1);
                                  V v_ru_24x31_24212_24MkPair = heff_take_reuse_n(v_x31_24212, 3ULL, 2);
                                  V v_t_24215 = ({ V a_0 = v_x_24213; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24213); r_; });
                                  V v_x_24216 = heff_tag_n(TAG_EInt, 1, (V[]){v_t_24215});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24212_24MkPair, TAG_MkPair, 2, (V[]){v_x_24216, v_j_24214})}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24212)}});
                                }
                              } else {
                                heff_drop(v_field_24211);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13), 2)) {
                              heff_drop_rec(v_k_240, 1);
                              HeffT2 v_t_24217 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                              {
                                V v_field_24219 = v_t_24217.f[1];
                                int64_t v_tag_24218 = ((int64_t)v_t_24217.f[0]);
                                if ((v_tag_24218 == ((int64_t)0ULL))) {
                                  V v_x31_24220 = v_field_24219;
                                  switch (heff_tag_of(v_x31_24220)) {
                                  case TAG_MkPair: {
                                    V v_x_24221 = heff_field(v_x31_24220, 0);
                                    V v_j_24222 = heff_field(v_x31_24220, 1);
                                    V v_ru_24x31_24220_24MkPair = heff_take_reuse_n(v_x31_24220, 3ULL, 2);
                                    V v_x2_24223 = ({ V b_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14); V a_1 = v_x_24221; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15), v_x_24221, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24221); r_; });
                                    V v_t_24226;
                                    switch (heff_tag_of(v_x2_24223)) {
                                    case TAG_Nil: {
                                      v_t_24226 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16);
                                      break;
                                    }
                                    case TAG_Cons: {
                                      V v_x_24224 = heff_field(v_x2_24223, 0);
                                      V v_xs_24225 = heff_field(v_x2_24223, 1);
                                      heff_take_n(v_x2_24223, 3ULL, 2);
                                      v_t_24226 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17); V a_1 = v_x_24224; V a_2 = v_xs_24225; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24225); r_; });
                                      break;
                                    }
                                    default: heff_nomatch(v_x2_24223);
                                    }
                                    double v_t_24227 = ({ V a_0 = v_t_24226; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24226); r_; });
                                    V v_x_24228 = heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_24227)});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24220_24MkPair, TAG_MkPair, 2, (V[]){v_x_24228, v_j_24222})}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24220)}});
                                  }
                                } else {
                                  heff_drop(v_field_24219);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18), 2)) {
                                heff_drop_rec(v_k_240, 1);
                                HeffT2 v_t_24229 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                {
                                  V v_field_24231 = v_t_24229.f[1];
                                  int64_t v_tag_24230 = ((int64_t)v_t_24229.f[0]);
                                  if ((v_tag_24230 == ((int64_t)0ULL))) {
                                    V v_x31_24232 = v_field_24231;
                                    switch (heff_tag_of(v_x31_24232)) {
                                    case TAG_MkPair: {
                                      V v_x_24233 = heff_field(v_x31_24232, 0);
                                      V v_j_24234 = heff_field(v_x31_24232, 1);
                                      V v_ru_24x31_24232_24MkPair = heff_take_reuse_n(v_x31_24232, 3ULL, 2);
                                      V v_t_24235 = heff_tag_at_n(v_ru_24x31_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_x_24233}), v_j_24234});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24235}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24232)}});
                                    }
                                  } else {
                                    heff_drop(v_field_24231);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19), 2)) {
                                  heff_drop_rec(v_k_240, 1);
                                  HeffT2 v_t_24236 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                  {
                                    V v_field_24238 = v_t_24236.f[1];
                                    int64_t v_tag_24237 = ((int64_t)v_t_24236.f[0]);
                                    if ((v_tag_24237 == ((int64_t)0ULL))) {
                                      V v_x31_24239 = v_field_24238;
                                      switch (heff_tag_of(v_x31_24239)) {
                                      case TAG_MkPair: {
                                        V v_x_24240 = heff_field(v_x31_24239, 0);
                                        V v_j_24241 = heff_field(v_x31_24239, 1);
                                        V v_ru_24x31_24239_24MkPair = heff_take_reuse_n(v_x31_24239, 3ULL, 2);
                                        V v_t_24242 = heff_tag_at_n(v_ru_24x31_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBytes, 1, (V[]){v_x_24240}), v_j_24241});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24242}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24239)}});
                                      }
                                    } else {
                                      heff_drop(v_field_24238);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20), 2)) {
                                    heff_drop_rec(v_k_240, 1);
                                    HeffT2 v_t_24243 = (g_heff_2ecompile_2eirtext_2efixedD_24cpr(v_z_242, v_z_243));
                                    {
                                      V v_field_24245 = v_t_24243.f[1];
                                      int64_t v_tag_24244 = ((int64_t)v_t_24243.f[0]);
                                      if ((v_tag_24244 == ((int64_t)0ULL))) {
                                        V v_x31_24246 = v_field_24245;
                                        switch (heff_tag_of(v_x31_24246)) {
                                        case TAG_MkPair: {
                                          V v_x_24247 = heff_field(v_x31_24246, 0);
                                          V v_j_24248 = heff_field(v_x31_24246, 1);
                                          V v_ru_24x31_24246_24MkPair = heff_take_reuse_n(v_x31_24246, 3ULL, 2);
                                          HeffT2 v_t_24249 = ({ V a_0 = v_z_242; V a_1 = v_j_24248; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                          {
                                            V v_field_24251 = v_t_24249.f[1];
                                            int64_t v_tag_24250 = ((int64_t)v_t_24249.f[0]);
                                            if ((v_tag_24250 == ((int64_t)0ULL))) {
                                              V v_x31_24252 = v_field_24251;
                                              switch (heff_tag_of(v_x31_24252)) {
                                              case TAG_MkPair: {
                                                V v_x_24253 = heff_field(v_x31_24252, 0);
                                                V v_j_24254 = heff_field(v_x31_24252, 1);
                                                V v_ru_24x31_24252_24MkPair = heff_take_reuse_n(v_x31_24252, 3ULL, 2);
                                                V v_t_24255 = ({ V a_0 = v_x_24253; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24253); r_; });
                                                V v_x_24256 = heff_tag_at_n(v_ru_24x31_24252_24MkPair, TAG_EFixed, 2, (V[]){v_x_24247, v_t_24255});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24246_24MkPair, TAG_MkPair, 2, (V[]){v_x_24256, v_j_24254})}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24252)}});
                                              }
                                            } else {
                                              heff_drop(v_x_24247);
                                              heff_drop_cell(v_ru_24x31_24246_24MkPair, 2);
                                              heff_drop(v_field_24251);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24246)}});
                                        }
                                      } else {
                                        heff_drop(v_z_242);
                                        heff_drop(v_field_24245);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21), 2)) {
                                      heff_drop_rec(v_k_240, 1);
                                      HeffT2 v_t_24257 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                      {
                                        V v_field_24259 = v_t_24257.f[1];
                                        int64_t v_tag_24258 = ((int64_t)v_t_24257.f[0]);
                                        if ((v_tag_24258 == ((int64_t)0ULL))) {
                                          V v_x31_24260 = v_field_24259;
                                          switch (heff_tag_of(v_x31_24260)) {
                                          case TAG_MkPair: {
                                            V v_x_24261 = heff_field(v_x31_24260, 0);
                                            V v_j_24262 = heff_field(v_x31_24260, 1);
                                            V v_ru_24x31_24260_24MkPair = heff_take_reuse_n(v_x31_24260, 3ULL, 2);
                                            V v_x2_24263 = ({ V b_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22); V a_1 = v_x_24261; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23), v_x_24261, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24261); r_; });
                                            V v_t_24266;
                                            switch (heff_tag_of(v_x2_24263)) {
                                            case TAG_Nil: {
                                              v_t_24266 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24);
                                              break;
                                            }
                                            case TAG_Cons: {
                                              V v_x_24264 = heff_field(v_x2_24263, 0);
                                              V v_xs_24265 = heff_field(v_x2_24263, 1);
                                              heff_take_n(v_x2_24263, 3ULL, 2);
                                              v_t_24266 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25); V a_1 = v_x_24264; V a_2 = v_xs_24265; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24265); r_; });
                                              break;
                                            }
                                            default: heff_nomatch(v_x2_24263);
                                            }
                                            double v_t_24267 = ({ V a_0 = v_t_24266; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24266); r_; });
                                            V v_x_24268 = heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24267)});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24260_24MkPair, TAG_MkPair, 2, (V[]){v_x_24268, v_j_24262})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24260)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24259);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26), 2)) {
                                        heff_drop_rec(v_k_240, 1);
                                        heff_drop(v_z_242);
                                        V v_t_24269 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_z_243});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24269}});
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27), 2)) {
                                          HeffT2 v_t_24270 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
                                          {
                                            V v_field_24272 = v_t_24270.f[1];
                                            int64_t v_tag_24271 = ((int64_t)v_t_24270.f[0]);
                                            if ((v_tag_24271 == ((int64_t)0ULL))) {
                                              V v_x31_24273 = v_field_24272;
                                              switch (heff_tag_of(v_x31_24273)) {
                                              case TAG_MkPair: {
                                                V v_x_24274 = heff_field(v_x31_24273, 0);
                                                V v_j_24275 = heff_field(v_x31_24273, 1);
                                                V v_ru_24x31_24273_24MkPair = heff_take_reuse_n(v_x31_24273, 3ULL, 2);
                                                V v_t_24276 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_24274));
                                                V v_x3_24277 = heff_tr(heff_call(v_t_24276, 2, (V[]){heff_dup(v_z_242), v_j_24275}));
                                                switch (heff_tag_of(v_x3_24277)) {
                                                case TAG_Nothing: {
                                                  heff_drop_rec(v_k_240, 1);
                                                  heff_drop(v_z_242);
                                                  heff_drop_cell(v_ru_24x31_24273_24MkPair, 2);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24278 = heff_field(v_x3_24277, 0);
                                                  heff_take_n(v_x3_24277, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24278)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24279 = heff_field(v_x31_24278, 0);
                                                    V v_j_24280 = heff_field(v_x31_24278, 1);
                                                    heff_take_n(v_x31_24278, 3ULL, 2);
                                                    V v_x3_24281 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_24280}));
                                                    switch (heff_tag_of(v_x3_24281)) {
                                                    case TAG_Nothing: {
                                                      heff_drop_rec(v_k_240, 1);
                                                      heff_drop(v_z_242);
                                                      heff_drop_cell(v_ru_24x31_24273_24MkPair, 2);
                                                      heff_drop(v_x_24279);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                    case TAG_Just: {
                                                      V v_x31_24282 = heff_field(v_x3_24281, 0);
                                                      heff_take_n(v_x3_24281, 1ULL, 1);
                                                      switch (heff_tag_of(v_x31_24282)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24283 = heff_field(v_x31_24282, 0);
                                                        V v_j_24284 = heff_field(v_x31_24282, 1);
                                                        heff_take_n(v_x31_24282, 3ULL, 2);
                                                        V v_x3_24285 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24284}));
                                                        switch (heff_tag_of(v_x3_24285)) {
                                                        case TAG_Nothing: {
                                                          heff_drop_cell(v_ru_24x31_24273_24MkPair, 2);
                                                          heff_drop(v_x_24279);
                                                          heff_drop(v_x_24283);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                        case TAG_Just: {
                                                          V v_x31_24286 = heff_field(v_x3_24285, 0);
                                                          heff_take_n(v_x3_24285, 1ULL, 1);
                                                          switch (heff_tag_of(v_x31_24286)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24287 = heff_field(v_x31_24286, 0);
                                                            V v_j_24288 = heff_field(v_x31_24286, 1);
                                                            heff_take_n(v_x31_24286, 3ULL, 2);
                                                            V v_t_24289 = heff_tag_at_n(v_ru_24x31_24273_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_x_24279, v_x_24283, v_x_24287}), v_j_24288});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24289}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24286)}});
                                                          }
                                                        }
                                                        default: return ((HeffT2){{heff_nomatch(v_x3_24285)}});
                                                        }
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24282)}});
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x3_24281)}});
                                                    }
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24278)}});
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x3_24277)}});
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24273)}});
                                              }
                                            } else {
                                              heff_drop_rec(v_k_240, 1);
                                              heff_drop(v_z_242);
                                              heff_drop(v_field_24272);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str28), 2)) {
                                            HeffT2 v_t_24290 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
                                            {
                                              V v_field_24292 = v_t_24290.f[1];
                                              int64_t v_tag_24291 = ((int64_t)v_t_24290.f[0]);
                                              if ((v_tag_24291 == ((int64_t)0ULL))) {
                                                V v_x31_24293 = v_field_24292;
                                                switch (heff_tag_of(v_x31_24293)) {
                                                case TAG_MkPair: {
                                                  V v_x_24294 = heff_field(v_x31_24293, 0);
                                                  V v_j_24295 = heff_field(v_x31_24293, 1);
                                                  V v_ru_24x31_24293_24MkPair = heff_take_reuse_n(v_x31_24293, 3ULL, 2);
                                                  V v_t_24296 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24294));
                                                  V v_x3_24297 = heff_tr(heff_call(v_t_24296, 2, (V[]){v_z_242, v_j_24295}));
                                                  switch (heff_tag_of(v_x3_24297)) {
                                                  case TAG_Nothing: {
                                                    heff_drop_cell(v_ru_24x31_24293_24MkPair, 2);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                  case TAG_Just: {
                                                    V v_x31_24298 = heff_field(v_x3_24297, 0);
                                                    heff_take_n(v_x3_24297, 1ULL, 1);
                                                    switch (heff_tag_of(v_x31_24298)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24299 = heff_field(v_x31_24298, 0);
                                                      V v_j_24300 = heff_field(v_x31_24298, 1);
                                                      heff_take_n(v_x31_24298, 3ULL, 2);
                                                      V v_t_24301 = heff_tag_at_n(v_ru_24x31_24293_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24299}), v_j_24300});
                                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24301}});
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24298)}});
                                                    }
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x3_24297)}});
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24293)}});
                                                }
                                              } else {
                                                heff_drop_rec(v_k_240, 1);
                                                heff_drop(v_z_242);
                                                heff_drop(v_field_24292);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str29), 2)) {
                                              V v_t_24302 = (g_heff_2ecompile_2eirtext_2eckOf(v_k_240));
                                              V v_m_24303 = heff_get_n(v_t_24302, 0, 1);
                                              V v_x3_24304 = heff_tr(heff_call(v_m_24303, 2, (V[]){v_z_242, v_z_243}));
                                              switch (heff_tag_of(v_x3_24304)) {
                                              case TAG_Nothing: {
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                              case TAG_Just: {
                                                V v_x31_24305 = heff_field(v_x3_24304, 0);
                                                V v_ru_24x3_24304_24Just = heff_take_reuse_n(v_x3_24304, 1ULL, 1);
                                                switch (heff_tag_of(v_x31_24305)) {
                                                case TAG_MkPair: {
                                                  V v_x_24306 = heff_field(v_x31_24305, 0);
                                                  V v_j_24307 = heff_field(v_x31_24305, 1);
                                                  V v_ru_24x31_24305_24MkPair = heff_take_reuse_n(v_x31_24305, 3ULL, 2);
                                                  V v_t_24308 = heff_tag_at_n(v_ru_24x31_24305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24304_24Just, TAG_EBool, 1, (V[]){v_x_24306}), v_j_24307});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24308}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24305)}});
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x3_24304)}});
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str30), 2)) {
                                                HeffT2 v_t_24309 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                                {
                                                  V v_field_24311 = v_t_24309.f[1];
                                                  int64_t v_tag_24310 = ((int64_t)v_t_24309.f[0]);
                                                  if ((v_tag_24310 == ((int64_t)0ULL))) {
                                                    V v_x31_24312 = v_field_24311;
                                                    switch (heff_tag_of(v_x31_24312)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24313 = heff_field(v_x31_24312, 0);
                                                      V v_j_24314 = heff_field(v_x31_24312, 1);
                                                      V v_ru_24x31_24312_24MkPair = heff_take_reuse_n(v_x31_24312, 3ULL, 2);
                                                      V v_x3_24315 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24314}));
                                                      switch (heff_tag_of(v_x3_24315)) {
                                                      case TAG_Nothing: {
                                                        heff_drop(v_x_24313);
                                                        heff_drop_cell(v_ru_24x31_24312_24MkPair, 2);
                                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                      }
                                                      case TAG_Just: {
                                                        V v_x31_24316 = heff_field(v_x3_24315, 0);
                                                        heff_take_n(v_x3_24315, 1ULL, 1);
                                                        switch (heff_tag_of(v_x31_24316)) {
                                                        case TAG_MkPair: {
                                                          V v_x_24317 = heff_field(v_x31_24316, 0);
                                                          V v_j_24318 = heff_field(v_x31_24316, 1);
                                                          heff_take_n(v_x31_24316, 3ULL, 2);
                                                          V v_t_24319 = heff_tag_at_n(v_ru_24x31_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24313, v_x_24317}), v_j_24318});
                                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24319}});
                                                        }
                                                        default: return ((HeffT2){{heff_nomatch(v_x31_24316)}});
                                                        }
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x3_24315)}});
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24312)}});
                                                    }
                                                  } else {
                                                    heff_drop_rec(v_k_240, 1);
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24311);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                heff_drop_rec(v_k_240, 1);
                                                return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

static V g_heff_2ecompile_2eirtext_2etakeExpr_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2etakeExpr_st;
static V g_heff_2ecompile_2eirtext_2etakeExpr_init(void) {
  return heff_dup(heff_rfield(g_heff_2ecompile_2eirtext_2edk_get(), 0));
}
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2etakeExpr_st)) return g_heff_2ecompile_2eirtext_2etakeExpr_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2etakeExpr_val, &g_heff_2ecompile_2eirtext_2etakeExpr_st, g_heff_2ecompile_2eirtext_2etakeExpr_init);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2estrsH_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_244}), heff_hole()});
      V v_cell_247 = heff_tag_at_n(v_ru_24x11_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_245}), heff_hole()});
      V v_u_248 = heff_setField(heff_dup(v_cell_246), MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_u_249 = (g_heff_2ecompile_2eirtext_2efieldsH_24dps(v_fs_243, v_rest_241, v_cell_247));
      heff_drop(v_u_249);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str12, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str13, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str14, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str15, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str16, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str17, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str18, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str19, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str20, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2enodeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enodeH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enodeH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_HS, 1, (V[]){v_x_242}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(1LL)}), v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EGlobal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EGlobal, TAG_HS, 1, (V[]){v_g_244}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(2LL)}), v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_247}), v_rest_241});
    V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_246, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2410});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(3LL)}), v_t_2411});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_args_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2413));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2413, v_rest_241));
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_f_2412}), v_t_2416});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(4LL)}), v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    V v_a_2419 = heff_field(v_x1_240, 1);
    V v_b_2420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2420}), v_rest_241});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2419}), v_t_2421});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2418}), v_t_2422});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(5LL)}), v_t_2423});
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x1_240, 0);
    V v_ts_2425 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2424));
    V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2425));
    V v_t_2428 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2425));
    V v_t_2429 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2427}), v_t_2428});
    V v_t_2430 = (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_2424, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2426}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(6LL)}), v_t_2431});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_l_2433 = heff_field(v_x1_240, 1);
    V v_sh_2434 = heff_field(v_x1_240, 2);
    V v_t_2435 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2438;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_FtFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2437 = heff_field(v_t_2435, 0);
      heff_take_n(v_t_2435, 1ULL, 1);
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str1);
        break;
      }
      case TAG_I16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str2);
        break;
      }
      case TAG_I32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str3);
        break;
      }
      case TAG_I64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str4);
        break;
      }
      case TAG_U8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str5);
        break;
      }
      case TAG_U16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str6);
        break;
      }
      case TAG_U32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str7);
        break;
      }
      case TAG_U64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str8);
        break;
      }
      case TAG_F32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str9);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str11);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2438}), v_rest_241});
    V v_t_2440 = (g_heff_2ecompile_2eirtext_2estrsH(v_sh_2434, v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2436}), v_t_2440});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_2433}), v_t_2441});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_2432}), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(7LL)}), v_t_2443});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x1_240, 0);
    V v_args_2445 = heff_field(v_x1_240, 1);
    V v_ts_2446 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2445));
    V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2446));
    V v_t_2449 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2446));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2448}), v_t_2449});
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2445, v_t_2450));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2447}), v_t_2451});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2444}), v_t_2452});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(8LL)}), v_t_2453});
  }
  case TAG_EMatch: {
    V v_s_2454 = heff_field(v_x1_240, 0);
    V v_arms_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2455));
    V v_t_2457 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_2455, v_rest_241));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2456}), v_t_2457});
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_s_2454}), v_t_2458});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(9LL)}), v_t_2459});
  }
  case TAG_EPrim: {
    V v_p_2460 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EPrim, TAG_HS, 1, (V[]){v_p_2460}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(10LL)}), v_t_2461});
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_x1_240, 0);
    V v_args_2463 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2464 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2463));
    V v_t_2465 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2463, v_rest_241));
    V v_t_2466 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2464}), v_t_2465});
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_p_2462}), v_t_2466});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(11LL)}), v_t_2467});
  }
  case TAG_ECall: {
    V v_g_2468 = heff_field(v_x1_240, 0);
    V v_args_2469 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2469));
    V v_t_2471 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2469, v_rest_241));
    V v_t_2472 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2470}), v_t_2471});
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_2468}), v_t_2472});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(12LL)}), v_t_2473});
  }
  case TAG_EInt: {
    V v_i_2474 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2475 = heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_HS, 1, (V[]){heff_intShow(v_i_2474)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(13LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2476 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x1_240_24EFloat, TAG_HS, 1, (V[]){heff_floatShow(v_x_2476)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(14LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2478 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_HS, 1, (V[]){v_s_2478}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(15LL)}), v_t_2479});
  }
  case TAG_EBytes: {
    V v_s_2480 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBytes = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBytes, TAG_HS, 1, (V[]){v_s_2480}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(20LL)}), v_t_2481});
  }
  case TAG_EFixed: {
    V v_w_2482 = heff_field(v_x1_240, 0);
    V v_n_2483 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2484;
    switch (heff_tag_of(v_w_2482)) {
    case TAG_I8: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str12);
      break;
    }
    case TAG_I16: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str13);
      break;
    }
    case TAG_I32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str14);
      break;
    }
    case TAG_I64: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str15);
      break;
    }
    case TAG_U8: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str16);
      break;
    }
    case TAG_U16: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str17);
      break;
    }
    case TAG_U32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str18);
      break;
    }
    case TAG_U64: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str19);
      break;
    }
    case TAG_F32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str20);
      break;
    }
    default: heff_nomatch(v_w_2482);
    }
    V v_t_2485 = heff_tag_n(TAG_HS, 1, (V[]){heff_intShow(v_n_2483)});
    V v_t_2486 = heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2484}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(16LL)}), v_t_2486});
  }
  case TAG_EFloat32: {
    V v_x_2487 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat32 = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2488 = heff_tag_at_n(v_ru_24x1_240_24EFloat32, TAG_HS, 1, (V[]){heff_floatShow(v_x_2487)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(17LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(18LL)}), v_rest_241});
  }
  case TAG_EBool: {
    V v_c_2489 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBool = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBool, TAG_HC, 1, (V[]){v_c_2489}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(21LL)}), v_t_2490});
  }
  case TAG_ESet: {
    V v_xs_2491 = heff_field(v_x1_240, 0);
    V v_a_2492 = heff_field(v_x1_240, 1);
    V v_b_2493 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2494 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2491));
    V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2493}), v_rest_241});
    V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2492}), v_t_2495});
    V v_t_2497 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_2491, v_t_2496));
    V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2494}), v_t_2497});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(22LL)}), v_t_2498});
  }
  case TAG_EValues: {
    V v_es_2499 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EValues = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24100 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_2499));
    V v_t_24101 = (g_heff_2ecompile_2eirtext_2eexprsH(v_es_2499, v_rest_241));
    V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EValues, TAG_HN, 1, (V[]){v_t_24100}), v_t_24101});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(23LL)}), v_t_24102});
  }
  case TAG_EFix: {
    V v_f_24103 = heff_field(v_x1_240, 0);
    V v_b_24104 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_24105 = heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_24104}), v_rest_241});
    V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_f_24103}), v_t_24105});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(19LL)}), v_t_24106});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enodeH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2econdH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econdH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2econdH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(30LL)}), v_rest_241});
  }
  case TAG_CFalse: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(31LL)}), v_rest_241});
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_a_243 = heff_field(v_x1_240, 1);
    V v_b_244 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_244}), v_rest_241});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_243}), v_t_245});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_p_242}), v_t_246});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(32LL)}), v_t_247});
  }
  case TAG_CTest: {
    V v_e_248 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CTest = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24CTest, TAG_HE, 1, (V[]){v_e_248}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(33LL)}), v_t_249});
  }
  case TAG_CNot: {
    V v_c_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CNot = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_HC, 1, (V[]){v_c_2410}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(34LL)}), v_t_2411});
  }
  case TAG_CIf: {
    V v_a_2412 = heff_field(v_x1_240, 0);
    V v_b_2413 = heff_field(v_x1_240, 1);
    V v_c_2414 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HC, 1, (V[]){v_c_2414}), v_rest_241});
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HC, 1, (V[]){v_b_2413}), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HC, 1, (V[]){v_a_2412}), v_t_2416});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(35LL)}), v_t_2417});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2econdH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econdH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V v_rest_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_rest_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1);
        break;
      }
      case TAG_I16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2);
        break;
      }
      case TAG_I32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3);
        break;
      }
      case TAG_I64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4);
        break;
      }
      case TAG_U8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5);
        break;
      }
      case TAG_U16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6);
        break;
      }
      case TAG_U32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7);
        break;
      }
      case TAG_U64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8);
        break;
      }
      case TAG_F32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_245}), heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(v_rest_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(a[0], a[1]);
}