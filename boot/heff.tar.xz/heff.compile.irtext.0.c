// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
HeffT2 g_heff_2ecompile_2eirtext_2earmD_24cpr(V, V, V);
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH(V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
HeffT2 g_heff_2ecompile_2eirtext_2efixedD_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V, V);
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V);
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2ecompile_2eirtext_2estrsT_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsT(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_str0), v_x_242));
    V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsT_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_24dps_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsT_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_24dps_str0), v_x_243));
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_247;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_rest_244 = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(v_es_243, v_rest_241));
    HEFF_LAST return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_242), v_rest_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_244 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0), v_x_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_rest_241})});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_g_245, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2), v_g_245));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_249, v_rest_241));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_248, v_rest_2410));
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4), v_t_2413});
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_240, 0);
    V v_as_2415 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2415));
    V v_t_2417 = ({ V a_0 = v_as_2415; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2415); r_; });
    V v_rest_2418 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2417});
    V v_t_2419 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2414, v_rest_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5), v_t_2419});
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_x2_240, 0);
    V v_a_2421 = heff_field(v_x2_240, 1);
    V v_b_2422 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2423 = heff_intShow(heff_strLength_lent(v_x_2420, 0));
    V v_t_2424 = heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6), v_x_2420));
    V v_rest_2425 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2422, v_rest_241));
    V v_t_2426 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2421, v_rest_2425));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2426})});
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_x2_240, 0);
    V v_ts_2428 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2427));
    V v_xs_2430 = (g_list_2emap_24s143096761x246530315(v_ts_2428));
    V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
    V v_t_2432 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2430, v_rest_241));
    V v_t_2433 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2431), v_t_2432});
    V v_t_2434 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2427, v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2429), v_t_2434});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8), v_t_2435});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_240, 0);
    V v_l_2437 = heff_field(v_x2_240, 1);
    V v_sh_2438 = heff_field(v_x2_240, 2);
    V v_t_2439 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2440 = heff_intShow(heff_strLength_lent(v_l_2437, 0));
    V v_t_2441 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9), v_l_2437));
    V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2438));
    V v_s_2444;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_FtFloat: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2443 = heff_field(v_t_2439, 0);
      heff_take_n(v_t_2439, 1ULL, 1);
      switch (heff_tag_of(v_w_2443)) {
      case TAG_I8: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11);
        break;
      }
      case TAG_I16: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12);
        break;
      }
      case TAG_I32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13);
        break;
      }
      case TAG_I64: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14);
        break;
      }
      case TAG_U8: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15);
        break;
      }
      case TAG_U16: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16);
        break;
      }
      case TAG_U32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17);
        break;
      }
      case TAG_U64: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18);
        break;
      }
      case TAG_F32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19);
        break;
      }
      default: heff_nomatch(v_w_2443);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20);
      break;
    }
    case TAG_FtAny: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21);
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    V v_t_2445 = heff_intShow(heff_strLength_lent(v_s_2444, 0));
    V v_t_2446 = heff_strAppend(v_t_2445, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22), v_s_2444));
    V v_t_2447 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_rest_241})));
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2442), v_t_2447});
    V v_rest_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2448});
    V v_t_2450 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2436, v_rest_2449));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23), v_t_2450});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_x2_240, 0);
    V v_as_2452 = heff_field(v_x2_240, 1);
    V v_ts_2453 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2454 = heff_intShow(heff_strLength_lent(v_t_2451, 0));
    V v_t_2455 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24), v_t_2451));
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2452));
    V v_xs_2457 = (g_list_2emap_24s143096761x246530315(v_ts_2453));
    V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2457));
    V v_t_2459 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2457, v_rest_241));
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2458), v_t_2459});
    V v_t_2461 = ({ V a_0 = v_as_2452; V a_1 = v_t_2460; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2452); r_; });
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2456), v_t_2461});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2462})});
  }
  case TAG_EMatch: {
    V v_s_2463 = heff_field(v_x2_240, 0);
    V v_arms_2464 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2464));
    V v_t_2466 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2464, v_rest_241));
    V v_rest_2467 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2465), v_t_2466});
    V v_t_2468 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2463, v_rest_2467));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26), v_t_2468});
  }
  case TAG_EPrim: {
    V v_p_2469 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2470 = heff_intShow(heff_strLength_lent(v_p_2469, 0));
    V v_t_2471 = heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27), v_p_2469));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, v_rest_241})});
  }
  case TAG_EPrimCall: {
    V v_p_2472 = heff_field(v_x2_240, 0);
    V v_as_2473 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2474 = heff_intShow(heff_strLength_lent(v_p_2472, 0));
    V v_t_2475 = heff_strAppend(v_t_2474, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29), v_p_2472));
    V v_t_2476 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2473));
    V v_t_2477 = ({ V a_0 = v_as_2473; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2473); r_; });
    V v_t_2478 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2476), v_t_2477});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_t_2478})});
  }
  case TAG_ECall: {
    V v_g_2479 = heff_field(v_x2_240, 0);
    V v_as_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2481 = heff_intShow(heff_strLength_lent(v_g_2479, 0));
    V v_t_2482 = heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31), v_g_2479));
    V v_t_2483 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2480));
    V v_t_2484 = ({ V a_0 = v_as_2480; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2480); r_; });
    V v_t_2485 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2483), v_t_2484});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, v_t_2485})});
  }
  case TAG_EInt: {
    V v_i_2486 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2487 = heff_intShow(v_i_2486);
    V v_t_2488 = heff_intShow(heff_strLength_lent(v_s_2487, 0));
    V v_t_2489 = heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33), v_s_2487));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2490 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_2491 = heff_floatShow(v_x_2490);
    V v_t_2492 = heff_intShow(heff_strLength_lent(v_s_2491, 0));
    V v_t_2493 = heff_strAppend(v_t_2492, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35), v_s_2491));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2493, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2495 = heff_intShow(heff_strLength_lent(v_s_2494, 0));
    V v_t_2496 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37), v_s_2494));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, v_rest_241})});
  }
  case TAG_EBytes: {
    V v_s_2497 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2498 = heff_intShow(heff_strLength_lent(v_s_2497, 0));
    V v_t_2499 = heff_strAppend(v_t_2498, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39), v_s_2497));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, v_rest_241})});
  }
  case TAG_EFixed: {
    V v_w_24100 = heff_field(v_x2_240, 0);
    V v_n_24101 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24102;
    switch (heff_tag_of(v_w_24100)) {
    case TAG_I8: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41);
      break;
    }
    case TAG_I16: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42);
      break;
    }
    case TAG_I32: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43);
      break;
    }
    case TAG_I64: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44);
      break;
    }
    case TAG_U8: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45);
      break;
    }
    case TAG_U16: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46);
      break;
    }
    case TAG_U32: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47);
      break;
    }
    case TAG_U64: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48);
      break;
    }
    case TAG_F32: {
      v_t_24102 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49);
      break;
    }
    default: heff_nomatch(v_w_24100);
    }
    V v_s_24103 = heff_intShow(v_n_24101);
    V v_t_24104 = heff_intShow(heff_strLength_lent(v_s_24103, 0));
    V v_t_24105 = heff_strAppend(v_t_24104, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50), v_s_24103));
    V v_t_24106 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24102, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51), v_t_24106});
  }
  case TAG_EFloat32: {
    V v_x_24107 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24108 = heff_floatShow(v_x_24107);
    V v_t_24109 = heff_intShow(heff_strLength_lent(v_s_24108, 0));
    V v_t_24110 = heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52), v_s_24108));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54), v_rest_241});
  }
  case TAG_EFix: {
    V v_f_24111 = heff_field(v_x2_240, 0);
    V v_b_24112 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24113 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55), heff_hole()});
    V v_t_24114 = heff_intShow(heff_strLength_lent(v_f_24111, 0));
    V v_t_24115 = heff_strAppend(v_t_24114, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56), v_f_24111));
    V v_cell_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24115, heff_hole()});
    V v_u_24117 = heff_setField(heff_dup(v_cell_24113), MK_INT(1LL), heff_dup(v_cell_24116));
    heff_drop(v_u_24117);
    V v_u_24118 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_b_24112, v_rest_241, v_cell_24116));
    heff_drop(v_u_24118);
    return v_cell_24113;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD(V v_d_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_lam0_clo);
  } else {
    V v_t_246 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_dup(v_d_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_clo), 2, (V[]){v_d_240, v_t_246});
  }
}
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  heff_drop(v_s_243);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_244});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo), 1, (V[]){v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo), 1, (V[]){v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0, 2, 0};
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args);
Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V v_lit_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_lit_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo);
  } else {
    V v_more_246 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(heff_dup(v_lit_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_clo_n(g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1, 2, 2, (V[]){v_lit_240, v_more_246});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  heff_drop(v_s_243);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_244});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_i_248 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_more_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_249 = (g_heff_2ecompile_2eirtext_2earmD_24cpr(v_lit_240, heff_dup(v_s_247), v_i_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x31_2413 = v_field_2411;
      switch (heff_tag_of(v_x31_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x31_2413, 0);
        V v_j_2415 = heff_field(v_x31_2413, 1);
        V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
        V v_x3_2416 = heff_tr(heff_call(v_more_246, 2, (V[]){v_s_247, v_j_2415}));
        switch (heff_tag_of(v_x3_2416)) {
        case TAG_Nothing: {
          heff_drop(v_x_2414);
          heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2417 = heff_field(v_x3_2416, 0);
          V v_ru_24x3_2416_24Just = heff_take_reuse_n(v_x3_2416, 1ULL, 1);
          switch (heff_tag_of(v_x31_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x31_2417, 0);
            V v_j_2419 = heff_field(v_x31_2417, 1);
            heff_take_n(v_x31_2417, 3ULL, 2);
            V v_t_2420 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_j_2419});
            return heff_tag_at_n(v_ru_24x3_2416_24Just, TAG_Just, 1, (V[]){v_t_2420});
          }
          default: return heff_nomatch(v_x31_2417);
          }
        }
        default: return heff_nomatch(v_x3_2416);
        }
      }
      default: return heff_nomatch(v_x31_2413);
      }
    } else {
      heff_drop(v_s_247);
      heff_drop(v_more_246);
      heff_drop(v_field_2411);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27, 1, "F");

HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_x2_241);
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2410}), v_j_2411});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 1);
      heff_drop(v_x2_241);
      HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_x31_2418 = v_field_2416;
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2419}), v_j_2420});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2418)}});
          }
        } else {
          heff_drop(v_field_2416);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2), 2)) {
        heff_drop(v_x2_241);
        HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_z_243));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          V v_x3_2431;
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_x31_2427 = v_field_2425;
            switch (heff_tag_of(v_x31_2427)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_field(v_x31_2427, 0);
              V v_j_2429 = heff_field(v_x31_2427, 1);
              heff_take_n(v_x31_2427, 3ULL, 2);
              V v_t_2430 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2428));
              v_x3_2431 = heff_tr(heff_call(v_t_2430, 2, (V[]){heff_dup(v_z_242), v_j_2429}));
              break;
            }
            default: heff_nomatch(v_x31_2427);
            }
          } else {
            heff_drop(v_field_2425);
            v_x3_2431 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_x3_2431)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2432 = heff_field(v_x3_2431, 0);
            heff_take_n(v_x3_2431, 1ULL, 1);
            switch (heff_tag_of(v_x31_2432)) {
            case TAG_MkPair: {
              V v_x_2433 = heff_field(v_x31_2432, 0);
              V v_j_2434 = heff_field(v_x31_2432, 1);
              V v_ru_24x31_2432_24MkPair = heff_take_reuse_n(v_x31_2432, 3ULL, 2);
              V v_x3_2435 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2434}));
              switch (heff_tag_of(v_x3_2435)) {
              case TAG_Nothing: {
                heff_drop(v_x_2433);
                heff_drop_cell(v_ru_24x31_2432_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2436 = heff_field(v_x3_2435, 0);
                heff_take_n(v_x3_2435, 1ULL, 1);
                switch (heff_tag_of(v_x31_2436)) {
                case TAG_MkPair: {
                  V v_x_2437 = heff_field(v_x31_2436, 0);
                  V v_j_2438 = heff_field(v_x31_2436, 1);
                  heff_take_n(v_x31_2436, 3ULL, 2);
                  V v_t_2439 = heff_tag_at_n(v_ru_24x31_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_x_2433, v_x_2437}), v_j_2438});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2439}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2436)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2435)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2432)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2431)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3), 2)) {
          heff_drop(v_x2_241);
          V v_x3_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2441)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2442 = heff_field(v_x3_2441, 0);
            heff_take_n(v_x3_2441, 1ULL, 1);
            switch (heff_tag_of(v_x31_2442)) {
            case TAG_MkPair: {
              V v_x_2443 = heff_field(v_x31_2442, 0);
              V v_j_2444 = heff_field(v_x31_2442, 1);
              V v_ru_24x31_2442_24MkPair = heff_take_reuse_n(v_x31_2442, 3ULL, 2);
              HeffT2 v_t_2445 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_2444));
              {
                V v_field_2447 = v_t_2445.f[1];
                int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
                V v_x3_2453;
                if ((v_tag_2446 == ((int64_t)0ULL))) {
                  V v_x31_2449 = v_field_2447;
                  switch (heff_tag_of(v_x31_2449)) {
                  case TAG_MkPair: {
                    V v_x_2450 = heff_field(v_x31_2449, 0);
                    V v_j_2451 = heff_field(v_x31_2449, 1);
                    heff_take_n(v_x31_2449, 3ULL, 2);
                    V v_t_2452 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2450));
                    v_x3_2453 = heff_tr(heff_call(v_t_2452, 2, (V[]){v_z_242, v_j_2451}));
                    break;
                  }
                  default: heff_nomatch(v_x31_2449);
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_field_2447);
                  v_x3_2453 = NTAG(TAG_Nothing);
                }
                switch (heff_tag_of(v_x3_2453)) {
                case TAG_Nothing: {
                  heff_drop(v_x_2443);
                  heff_drop_cell(v_ru_24x31_2442_24MkPair, 2);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2454 = heff_field(v_x3_2453, 0);
                  heff_take_n(v_x3_2453, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2454)) {
                  case TAG_MkPair: {
                    V v_x_2455 = heff_field(v_x31_2454, 0);
                    V v_j_2456 = heff_field(v_x31_2454, 1);
                    heff_take_n(v_x31_2454, 3ULL, 2);
                    V v_t_2457 = heff_tag_at_n(v_ru_24x31_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2443, v_x_2455}), v_j_2456});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2457}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2453)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2442)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2441)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4), 2)) {
            heff_drop(v_x2_241);
            HeffT2 v_t_2459 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
            {
              V v_field_2461 = v_t_2459.f[1];
              int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
              if ((v_tag_2460 == ((int64_t)0ULL))) {
                V v_x31_2463 = v_field_2461;
                switch (heff_tag_of(v_x31_2463)) {
                case TAG_MkPair: {
                  V v_x_2464 = heff_field(v_x31_2463, 0);
                  V v_j_2465 = heff_field(v_x31_2463, 1);
                  V v_ru_24x31_2463_24MkPair = heff_take_reuse_n(v_x31_2463, 3ULL, 2);
                  V v_x3_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_2465}));
                  switch (heff_tag_of(v_x3_2466)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_k_240, 1);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2464);
                    heff_drop_cell(v_ru_24x31_2463_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2467 = heff_field(v_x3_2466, 0);
                    heff_take_n(v_x3_2466, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2467)) {
                    case TAG_MkPair: {
                      V v_x_2468 = heff_field(v_x31_2467, 0);
                      V v_j_2469 = heff_field(v_x31_2467, 1);
                      heff_take_n(v_x31_2467, 3ULL, 2);
                      V v_x3_2470 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2469}));
                      switch (heff_tag_of(v_x3_2470)) {
                      case TAG_Nothing: {
                        heff_drop(v_x_2464);
                        heff_drop_cell(v_ru_24x31_2463_24MkPair, 2);
                        heff_drop(v_x_2468);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2471 = heff_field(v_x3_2470, 0);
                        heff_take_n(v_x3_2470, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2471)) {
                        case TAG_MkPair: {
                          V v_x_2472 = heff_field(v_x31_2471, 0);
                          V v_j_2473 = heff_field(v_x31_2471, 1);
                          heff_take_n(v_x31_2471, 3ULL, 2);
                          V v_t_2474 = heff_tag_at_n(v_ru_24x31_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2464, v_x_2468, v_x_2472}), v_j_2473});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2474}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2471)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2470)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2467)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2466)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2463)}});
                }
              } else {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                heff_drop(v_field_2461);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5), 2)) {
              heff_drop(v_x2_241);
              HeffT2 v_t_2476 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_z_243));
              {
                V v_field_2478 = v_t_2476.f[1];
                int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
                V v_x3_2485;
                if ((v_tag_2477 == ((int64_t)0ULL))) {
                  V v_x31_2480 = v_field_2478;
                  switch (heff_tag_of(v_x31_2480)) {
                  case TAG_MkPair: {
                    V v_x_2481 = heff_field(v_x31_2480, 0);
                    V v_j_2482 = heff_field(v_x31_2480, 1);
                    heff_take_n(v_x31_2480, 3ULL, 2);
                    V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2efieldD_clo), 1, (V[]){v_k_240}));
                    V v_t_2484 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_2483, v_x_2481));
                    v_x3_2485 = heff_tr(heff_call(v_t_2484, 2, (V[]){heff_dup(v_z_242), v_j_2482}));
                    break;
                  }
                  default: heff_nomatch(v_x31_2480);
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_field_2478);
                  v_x3_2485 = NTAG(TAG_Nothing);
                }
                switch (heff_tag_of(v_x3_2485)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2486 = heff_field(v_x3_2485, 0);
                  heff_take_n(v_x3_2485, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2486)) {
                  case TAG_MkPair: {
                    V v_x_2487 = heff_field(v_x31_2486, 0);
                    V v_j_2488 = heff_field(v_x31_2486, 1);
                    V v_ru_24x31_2486_24MkPair = heff_take_reuse_n(v_x31_2486, 3ULL, 2);
                    HeffT2 v_t_2489 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_2488));
                    {
                      V v_field_2491 = v_t_2489.f[1];
                      int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
                      V v_x3_2497;
                      if ((v_tag_2490 == ((int64_t)0ULL))) {
                        V v_x31_2493 = v_field_2491;
                        switch (heff_tag_of(v_x31_2493)) {
                        case TAG_MkPair: {
                          V v_x_2494 = heff_field(v_x31_2493, 0);
                          V v_j_2495 = heff_field(v_x31_2493, 1);
                          heff_take_n(v_x31_2493, 3ULL, 2);
                          V v_t_2496 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_2494));
                          v_x3_2497 = heff_tr(heff_call(v_t_2496, 2, (V[]){v_z_242, v_j_2495}));
                          break;
                        }
                        default: heff_nomatch(v_x31_2493);
                        }
                      } else {
                        heff_drop(v_z_242);
                        heff_drop(v_field_2491);
                        v_x3_2497 = NTAG(TAG_Nothing);
                      }
                      switch (heff_tag_of(v_x3_2497)) {
                      case TAG_Nothing: {
                        heff_drop(v_x_2487);
                        heff_drop_cell(v_ru_24x31_2486_24MkPair, 2);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2498 = heff_field(v_x3_2497, 0);
                        heff_take_n(v_x3_2497, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2498)) {
                        case TAG_MkPair: {
                          V v_x_2499 = heff_field(v_x31_2498, 0);
                          V v_j_24100 = heff_field(v_x31_2498, 1);
                          heff_take_n(v_x31_2498, 3ULL, 2);
                          V v_t_24101 = heff_tag_at_n(v_ru_24x31_2486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2487, v_x_2499}), v_j_24100});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24101}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2498)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2497)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2486)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2485)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6), 2)) {
                heff_drop(v_x2_241);
                V v_x3_24103 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_24103)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_24104 = heff_field(v_x3_24103, 0);
                  heff_take_n(v_x3_24103, 1ULL, 1);
                  switch (heff_tag_of(v_x31_24104)) {
                  case TAG_MkPair: {
                    V v_x_24105 = heff_field(v_x31_24104, 0);
                    V v_j_24106 = heff_field(v_x31_24104, 1);
                    V v_ru_24x31_24104_24MkPair = heff_take_reuse_n(v_x31_24104, 3ULL, 2);
                    HeffT2 v_t_24107 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_j_24106));
                    {
                      V v_field_24109 = v_t_24107.f[1];
                      int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
                      if ((v_tag_24108 == ((int64_t)0ULL))) {
                        V v_x31_24111 = v_field_24109;
                        switch (heff_tag_of(v_x31_24111)) {
                        case TAG_MkPair: {
                          V v_x_24112 = heff_field(v_x31_24111, 0);
                          V v_j_24113 = heff_field(v_x31_24111, 1);
                          heff_take_n(v_x31_24111, 3ULL, 2);
                          HeffT2 v_t_24114 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_24113));
                          {
                            V v_field_24116 = v_t_24114.f[1];
                            int64_t v_tag_24115 = ((int64_t)v_t_24114.f[0]);
                            V v_x3_24122;
                            if ((v_tag_24115 == ((int64_t)0ULL))) {
                              V v_x31_24118 = v_field_24116;
                              switch (heff_tag_of(v_x31_24118)) {
                              case TAG_MkPair: {
                                V v_x_24119 = heff_field(v_x31_24118, 0);
                                V v_j_24120 = heff_field(v_x31_24118, 1);
                                heff_take_n(v_x31_24118, 3ULL, 2);
                                V v_t_24121 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_24119));
                                v_x3_24122 = heff_tr(heff_call(v_t_24121, 2, (V[]){heff_dup(v_z_242), v_j_24120}));
                                break;
                              }
                              default: heff_nomatch(v_x31_24118);
                              }
                            } else {
                              heff_drop(v_field_24116);
                              v_x3_24122 = NTAG(TAG_Nothing);
                            }
                            switch (heff_tag_of(v_x3_24122)) {
                            case TAG_Nothing: {
                              heff_drop(v_z_242);
                              heff_drop(v_x_24105);
                              heff_drop_cell(v_ru_24x31_24104_24MkPair, 2);
                              heff_drop(v_x_24112);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_Just: {
                              V v_x31_24123 = heff_field(v_x3_24122, 0);
                              heff_take_n(v_x3_24122, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24123)) {
                              case TAG_MkPair: {
                                V v_x_24124 = heff_field(v_x31_24123, 0);
                                V v_j_24125 = heff_field(v_x31_24123, 1);
                                heff_take_n(v_x31_24123, 3ULL, 2);
                                HeffT2 v_t_24126 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24125));
                                {
                                  V v_field_24128 = v_t_24126.f[1];
                                  int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
                                  if ((v_tag_24127 == ((int64_t)0ULL))) {
                                    V v_x31_24130 = v_field_24128;
                                    switch (heff_tag_of(v_x31_24130)) {
                                    case TAG_MkPair: {
                                      V v_x_24131 = heff_field(v_x31_24130, 0);
                                      V v_j_24132 = heff_field(v_x31_24130, 1);
                                      heff_take_n(v_x31_24130, 3ULL, 2);
                                      HeffT2 v_t_24133 = (g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(v_x_24131));
                                      {
                                        V v_field_24135 = v_t_24133.f[1];
                                        int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                                        if ((v_tag_24134 == ((int64_t)0ULL))) {
                                          V v_x_24137 = v_field_24135;
                                          V v_t_24138 = heff_tag_at_n(v_ru_24x31_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_24105, v_x_24112, v_x_24124, v_x_24137}), v_j_24132});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24138}});
                                        } else {
                                          heff_drop(v_x_24105);
                                          heff_drop_cell(v_ru_24x31_24104_24MkPair, 2);
                                          heff_drop(v_x_24112);
                                          heff_drop(v_x_24124);
                                          heff_drop(v_j_24132);
                                          heff_drop(v_field_24135);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24130)}});
                                    }
                                  } else {
                                    heff_drop(v_x_24105);
                                    heff_drop_cell(v_ru_24x31_24104_24MkPair, 2);
                                    heff_drop(v_x_24112);
                                    heff_drop(v_x_24124);
                                    heff_drop(v_field_24128);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24123)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x3_24122)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24111)}});
                        }
                      } else {
                        heff_drop(v_z_242);
                        heff_drop(v_x_24105);
                        heff_drop_cell(v_ru_24x31_24104_24MkPair, 2);
                        heff_drop(v_field_24109);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24104)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_24103)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7), 2)) {
                  heff_drop(v_x2_241);
                  HeffT2 v_t_24140 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                  {
                    V v_field_24142 = v_t_24140.f[1];
                    int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
                    if ((v_tag_24141 == ((int64_t)0ULL))) {
                      V v_x31_24144 = v_field_24142;
                      switch (heff_tag_of(v_x31_24144)) {
                      case TAG_MkPair: {
                        V v_x_24145 = heff_field(v_x31_24144, 0);
                        V v_j_24146 = heff_field(v_x31_24144, 1);
                        V v_ru_24x31_24144_24MkPair = heff_take_reuse_n(v_x31_24144, 3ULL, 2);
                        HeffT2 v_t_24147 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_24146));
                        {
                          V v_field_24149 = v_t_24147.f[1];
                          int64_t v_tag_24148 = ((int64_t)v_t_24147.f[0]);
                          V v_x3_24155;
                          if ((v_tag_24148 == ((int64_t)0ULL))) {
                            V v_x31_24151 = v_field_24149;
                            switch (heff_tag_of(v_x31_24151)) {
                            case TAG_MkPair: {
                              V v_x_24152 = heff_field(v_x31_24151, 0);
                              V v_j_24153 = heff_field(v_x31_24151, 1);
                              heff_take_n(v_x31_24151, 3ULL, 2);
                              V v_t_24154 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24152));
                              v_x3_24155 = heff_tr(heff_call(v_t_24154, 2, (V[]){heff_dup(v_z_242), v_j_24153}));
                              break;
                            }
                            default: heff_nomatch(v_x31_24151);
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_field_24149);
                            v_x3_24155 = NTAG(TAG_Nothing);
                          }
                          switch (heff_tag_of(v_x3_24155)) {
                          case TAG_Nothing: {
                            heff_drop(v_z_242);
                            heff_drop(v_x_24145);
                            heff_drop_cell(v_ru_24x31_24144_24MkPair, 2);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_24156 = heff_field(v_x3_24155, 0);
                            heff_take_n(v_x3_24155, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24156)) {
                            case TAG_MkPair: {
                              V v_x_24157 = heff_field(v_x31_24156, 0);
                              V v_j_24158 = heff_field(v_x31_24156, 1);
                              heff_take_n(v_x31_24156, 3ULL, 2);
                              HeffT2 v_t_24159 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_24158));
                              {
                                V v_field_24161 = v_t_24159.f[1];
                                int64_t v_tag_24160 = ((int64_t)v_t_24159.f[0]);
                                V v_x3_24167;
                                if ((v_tag_24160 == ((int64_t)0ULL))) {
                                  V v_x31_24163 = v_field_24161;
                                  switch (heff_tag_of(v_x31_24163)) {
                                  case TAG_MkPair: {
                                    V v_x_24164 = heff_field(v_x31_24163, 0);
                                    V v_j_24165 = heff_field(v_x31_24163, 1);
                                    heff_take_n(v_x31_24163, 3ULL, 2);
                                    V v_t_24166 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_24164));
                                    v_x3_24167 = heff_tr(heff_call(v_t_24166, 2, (V[]){v_z_242, v_j_24165}));
                                    break;
                                  }
                                  default: heff_nomatch(v_x31_24163);
                                  }
                                } else {
                                  heff_drop(v_z_242);
                                  heff_drop(v_field_24161);
                                  v_x3_24167 = NTAG(TAG_Nothing);
                                }
                                switch (heff_tag_of(v_x3_24167)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24145);
                                  heff_drop_cell(v_ru_24x31_24144_24MkPair, 2);
                                  heff_drop(v_x_24157);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24168 = heff_field(v_x3_24167, 0);
                                  heff_take_n(v_x3_24167, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24168)) {
                                  case TAG_MkPair: {
                                    V v_x_24169 = heff_field(v_x31_24168, 0);
                                    V v_j_24170 = heff_field(v_x31_24168, 1);
                                    heff_take_n(v_x31_24168, 3ULL, 2);
                                    V v_t_24171 = heff_tag_at_n(v_ru_24x31_24144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_x_24145, v_x_24157, v_x_24169}), v_j_24170});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24171}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24168)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24167)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24156)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x3_24155)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24144)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      heff_drop(v_field_24142);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8), 2)) {
                    heff_drop(v_x2_241);
                    V v_x3_24173 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24173)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_24174 = heff_field(v_x3_24173, 0);
                      heff_take_n(v_x3_24173, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24174)) {
                      case TAG_MkPair: {
                        V v_x_24175 = heff_field(v_x31_24174, 0);
                        V v_j_24176 = heff_field(v_x31_24174, 1);
                        V v_ru_24x31_24174_24MkPair = heff_take_reuse_n(v_x31_24174, 3ULL, 2);
                        HeffT2 v_t_24177 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_24176));
                        {
                          V v_field_24179 = v_t_24177.f[1];
                          int64_t v_tag_24178 = ((int64_t)v_t_24177.f[0]);
                          V v_x3_24185;
                          if ((v_tag_24178 == ((int64_t)0ULL))) {
                            V v_x31_24181 = v_field_24179;
                            switch (heff_tag_of(v_x31_24181)) {
                            case TAG_MkPair: {
                              V v_x_24182 = heff_field(v_x31_24181, 0);
                              V v_j_24183 = heff_field(v_x31_24181, 1);
                              heff_take_n(v_x31_24181, 3ULL, 2);
                              V v_t_24184 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(v_k_240, v_x_24182));
                              v_x3_24185 = heff_tr(heff_call(v_t_24184, 2, (V[]){v_z_242, v_j_24183}));
                              break;
                            }
                            default: heff_nomatch(v_x31_24181);
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_field_24179);
                            v_x3_24185 = NTAG(TAG_Nothing);
                          }
                          switch (heff_tag_of(v_x3_24185)) {
                          case TAG_Nothing: {
                            heff_drop(v_x_24175);
                            heff_drop_cell(v_ru_24x31_24174_24MkPair, 2);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_24186 = heff_field(v_x3_24185, 0);
                            heff_take_n(v_x3_24185, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24186)) {
                            case TAG_MkPair: {
                              V v_x_24187 = heff_field(v_x31_24186, 0);
                              V v_j_24188 = heff_field(v_x31_24186, 1);
                              heff_take_n(v_x31_24186, 3ULL, 2);
                              V v_t_24189 = heff_tag_at_n(v_ru_24x31_24174_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24175, v_x_24187}), v_j_24188});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24189}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24186)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x3_24185)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24174)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_24173)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_x2_241);
                      HeffT2 v_t_24191 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                      {
                        V v_field_24193 = v_t_24191.f[1];
                        int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
                        if ((v_tag_24192 == ((int64_t)0ULL))) {
                          V v_x31_24195 = v_field_24193;
                          switch (heff_tag_of(v_x31_24195)) {
                          case TAG_MkPair: {
                            V v_x_24196 = heff_field(v_x31_24195, 0);
                            V v_j_24197 = heff_field(v_x31_24195, 1);
                            V v_ru_24x31_24195_24MkPair = heff_take_reuse_n(v_x31_24195, 3ULL, 2);
                            V v_t_24198 = heff_tag_at_n(v_ru_24x31_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24196}), v_j_24197});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24198}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24195)}});
                          }
                        } else {
                          heff_drop(v_field_24193);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10), 2)) {
                        heff_drop(v_x2_241);
                        HeffT2 v_t_24200 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                        {
                          V v_field_24202 = v_t_24200.f[1];
                          int64_t v_tag_24201 = ((int64_t)v_t_24200.f[0]);
                          if ((v_tag_24201 == ((int64_t)0ULL))) {
                            V v_x31_24204 = v_field_24202;
                            switch (heff_tag_of(v_x31_24204)) {
                            case TAG_MkPair: {
                              V v_x_24205 = heff_field(v_x31_24204, 0);
                              V v_j_24206 = heff_field(v_x31_24204, 1);
                              V v_ru_24x31_24204_24MkPair = heff_take_reuse_n(v_x31_24204, 3ULL, 2);
                              HeffT2 v_t_24207 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_24206));
                              {
                                V v_field_24209 = v_t_24207.f[1];
                                int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
                                V v_x3_24215;
                                if ((v_tag_24208 == ((int64_t)0ULL))) {
                                  V v_x31_24211 = v_field_24209;
                                  switch (heff_tag_of(v_x31_24211)) {
                                  case TAG_MkPair: {
                                    V v_x_24212 = heff_field(v_x31_24211, 0);
                                    V v_j_24213 = heff_field(v_x31_24211, 1);
                                    heff_take_n(v_x31_24211, 3ULL, 2);
                                    V v_t_24214 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24212));
                                    v_x3_24215 = heff_tr(heff_call(v_t_24214, 2, (V[]){v_z_242, v_j_24213}));
                                    break;
                                  }
                                  default: heff_nomatch(v_x31_24211);
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_z_242);
                                  heff_drop(v_field_24209);
                                  v_x3_24215 = NTAG(TAG_Nothing);
                                }
                                switch (heff_tag_of(v_x3_24215)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24205);
                                  heff_drop_cell(v_ru_24x31_24204_24MkPair, 2);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24216 = heff_field(v_x3_24215, 0);
                                  heff_take_n(v_x3_24215, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24216)) {
                                  case TAG_MkPair: {
                                    V v_x_24217 = heff_field(v_x31_24216, 0);
                                    V v_j_24218 = heff_field(v_x31_24216, 1);
                                    heff_take_n(v_x31_24216, 3ULL, 2);
                                    V v_t_24219 = heff_tag_at_n(v_ru_24x31_24204_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x_24205, v_x_24217}), v_j_24218});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24219}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24216)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24215)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24204)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_field_24202);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11), 2)) {
                          heff_drop(v_x2_241);
                          HeffT2 v_t_24221 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                          {
                            V v_field_24223 = v_t_24221.f[1];
                            int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
                            if ((v_tag_24222 == ((int64_t)0ULL))) {
                              V v_x31_24225 = v_field_24223;
                              switch (heff_tag_of(v_x31_24225)) {
                              case TAG_MkPair: {
                                V v_x_24226 = heff_field(v_x31_24225, 0);
                                V v_j_24227 = heff_field(v_x31_24225, 1);
                                V v_ru_24x31_24225_24MkPair = heff_take_reuse_n(v_x31_24225, 3ULL, 2);
                                HeffT2 v_t_24228 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_242), v_j_24227));
                                {
                                  V v_field_24230 = v_t_24228.f[1];
                                  int64_t v_tag_24229 = ((int64_t)v_t_24228.f[0]);
                                  V v_x3_24236;
                                  if ((v_tag_24229 == ((int64_t)0ULL))) {
                                    V v_x31_24232 = v_field_24230;
                                    switch (heff_tag_of(v_x31_24232)) {
                                    case TAG_MkPair: {
                                      V v_x_24233 = heff_field(v_x31_24232, 0);
                                      V v_j_24234 = heff_field(v_x31_24232, 1);
                                      heff_take_n(v_x31_24232, 3ULL, 2);
                                      V v_t_24235 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24233));
                                      v_x3_24236 = heff_tr(heff_call(v_t_24235, 2, (V[]){v_z_242, v_j_24234}));
                                      break;
                                    }
                                    default: heff_nomatch(v_x31_24232);
                                    }
                                  } else {
                                    heff_drop_rec(v_k_240, 1);
                                    heff_drop(v_z_242);
                                    heff_drop(v_field_24230);
                                    v_x3_24236 = NTAG(TAG_Nothing);
                                  }
                                  switch (heff_tag_of(v_x3_24236)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_x_24226);
                                    heff_drop_cell(v_ru_24x31_24225_24MkPair, 2);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                  case TAG_Just: {
                                    V v_x31_24237 = heff_field(v_x3_24236, 0);
                                    heff_take_n(v_x3_24236, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24237)) {
                                    case TAG_MkPair: {
                                      V v_x_24238 = heff_field(v_x31_24237, 0);
                                      V v_j_24239 = heff_field(v_x31_24237, 1);
                                      heff_take_n(v_x31_24237, 3ULL, 2);
                                      V v_t_24240 = heff_tag_at_n(v_ru_24x31_24225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_x_24226, v_x_24238}), v_j_24239});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24240}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24237)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x3_24236)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24225)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              heff_drop(v_field_24223);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_x2_241);
                            HeffT2 v_t_24242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                            {
                              V v_field_24244 = v_t_24242.f[1];
                              int64_t v_tag_24243 = ((int64_t)v_t_24242.f[0]);
                              if ((v_tag_24243 == ((int64_t)0ULL))) {
                                V v_x31_24246 = v_field_24244;
                                switch (heff_tag_of(v_x31_24246)) {
                                case TAG_MkPair: {
                                  V v_x_24247 = heff_field(v_x31_24246, 0);
                                  V v_j_24248 = heff_field(v_x31_24246, 1);
                                  V v_ru_24x31_24246_24MkPair = heff_take_reuse_n(v_x31_24246, 3ULL, 2);
                                  V v_t_24249 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24247));
                                  V v_x_24250 = heff_tag_n(TAG_EInt, 1, (V[]){v_t_24249});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24246_24MkPair, TAG_MkPair, 2, (V[]){v_x_24250, v_j_24248})}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24246)}});
                                }
                              } else {
                                heff_drop(v_field_24244);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13), 2)) {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_x2_241);
                              HeffT2 v_t_24252 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                              {
                                V v_field_24254 = v_t_24252.f[1];
                                int64_t v_tag_24253 = ((int64_t)v_t_24252.f[0]);
                                if ((v_tag_24253 == ((int64_t)0ULL))) {
                                  V v_x31_24256 = v_field_24254;
                                  switch (heff_tag_of(v_x31_24256)) {
                                  case TAG_MkPair: {
                                    V v_x_24257 = heff_field(v_x31_24256, 0);
                                    V v_j_24258 = heff_field(v_x31_24256, 1);
                                    V v_ru_24x31_24256_24MkPair = heff_take_reuse_n(v_x31_24256, 3ULL, 2);
                                    V v_x2_24259 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14), heff_dup(v_x_24257), MK_INT(0LL), heff_strFind(((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15), v_x_24257, MK_INT(0LL)), NTAG(TAG_Nil)));
                                    V v_t_24262;
                                    switch (heff_tag_of(v_x2_24259)) {
                                    case TAG_Nil: {
                                      v_t_24262 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16);
                                      break;
                                    }
                                    case TAG_Cons: {
                                      V v_x_24260 = heff_field(v_x2_24259, 0);
                                      V v_xs_24261 = heff_field(v_x2_24259, 1);
                                      heff_take_n(v_x2_24259, 3ULL, 2);
                                      v_t_24262 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17); V a_1 = v_x_24260; V a_2 = v_xs_24261; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24261); r_; });
                                      break;
                                    }
                                    default: heff_nomatch(v_x2_24259);
                                    }
                                    double v_t_24263 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24262));
                                    V v_x_24264 = heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_24263)});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24256_24MkPair, TAG_MkPair, 2, (V[]){v_x_24264, v_j_24258})}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24256)}});
                                  }
                                } else {
                                  heff_drop(v_field_24254);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18), 2)) {
                                heff_drop_rec(v_k_240, 1);
                                heff_drop(v_x2_241);
                                HeffT2 v_t_24266 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                {
                                  V v_field_24268 = v_t_24266.f[1];
                                  int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
                                  if ((v_tag_24267 == ((int64_t)0ULL))) {
                                    V v_x31_24270 = v_field_24268;
                                    switch (heff_tag_of(v_x31_24270)) {
                                    case TAG_MkPair: {
                                      V v_x_24271 = heff_field(v_x31_24270, 0);
                                      V v_j_24272 = heff_field(v_x31_24270, 1);
                                      V v_ru_24x31_24270_24MkPair = heff_take_reuse_n(v_x31_24270, 3ULL, 2);
                                      V v_t_24273 = heff_tag_at_n(v_ru_24x31_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_x_24271}), v_j_24272});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24273}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24270)}});
                                    }
                                  } else {
                                    heff_drop(v_field_24268);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19), 2)) {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_x2_241);
                                  HeffT2 v_t_24275 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                  {
                                    V v_field_24277 = v_t_24275.f[1];
                                    int64_t v_tag_24276 = ((int64_t)v_t_24275.f[0]);
                                    if ((v_tag_24276 == ((int64_t)0ULL))) {
                                      V v_x31_24279 = v_field_24277;
                                      switch (heff_tag_of(v_x31_24279)) {
                                      case TAG_MkPair: {
                                        V v_x_24280 = heff_field(v_x31_24279, 0);
                                        V v_j_24281 = heff_field(v_x31_24279, 1);
                                        V v_ru_24x31_24279_24MkPair = heff_take_reuse_n(v_x31_24279, 3ULL, 2);
                                        V v_t_24282 = heff_tag_at_n(v_ru_24x31_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBytes, 1, (V[]){v_x_24280}), v_j_24281});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24282}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24279)}});
                                      }
                                    } else {
                                      heff_drop(v_field_24277);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20), 2)) {
                                    heff_drop_rec(v_k_240, 1);
                                    heff_drop(v_x2_241);
                                    HeffT2 v_t_24284 = (g_heff_2ecompile_2eirtext_2efixedD_24cpr(heff_dup(v_z_242), v_z_243));
                                    {
                                      V v_field_24286 = v_t_24284.f[1];
                                      int64_t v_tag_24285 = ((int64_t)v_t_24284.f[0]);
                                      if ((v_tag_24285 == ((int64_t)0ULL))) {
                                        V v_x31_24288 = v_field_24286;
                                        switch (heff_tag_of(v_x31_24288)) {
                                        case TAG_MkPair: {
                                          V v_x_24289 = heff_field(v_x31_24288, 0);
                                          V v_j_24290 = heff_field(v_x31_24288, 1);
                                          V v_ru_24x31_24288_24MkPair = heff_take_reuse_n(v_x31_24288, 3ULL, 2);
                                          HeffT2 v_t_24291 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24290));
                                          {
                                            V v_field_24293 = v_t_24291.f[1];
                                            int64_t v_tag_24292 = ((int64_t)v_t_24291.f[0]);
                                            if ((v_tag_24292 == ((int64_t)0ULL))) {
                                              V v_x31_24295 = v_field_24293;
                                              switch (heff_tag_of(v_x31_24295)) {
                                              case TAG_MkPair: {
                                                V v_x_24296 = heff_field(v_x31_24295, 0);
                                                V v_j_24297 = heff_field(v_x31_24295, 1);
                                                V v_ru_24x31_24295_24MkPair = heff_take_reuse_n(v_x31_24295, 3ULL, 2);
                                                V v_t_24298 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24296));
                                                V v_x_24299 = heff_tag_at_n(v_ru_24x31_24295_24MkPair, TAG_EFixed, 2, (V[]){v_x_24289, v_t_24298});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24288_24MkPair, TAG_MkPair, 2, (V[]){v_x_24299, v_j_24297})}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24295)}});
                                              }
                                            } else {
                                              heff_drop(v_x_24289);
                                              heff_drop_cell(v_ru_24x31_24288_24MkPair, 2);
                                              heff_drop(v_field_24293);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24288)}});
                                        }
                                      } else {
                                        heff_drop(v_z_242);
                                        heff_drop(v_field_24286);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21), 2)) {
                                      heff_drop_rec(v_k_240, 1);
                                      heff_drop(v_x2_241);
                                      HeffT2 v_t_24301 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                      {
                                        V v_field_24303 = v_t_24301.f[1];
                                        int64_t v_tag_24302 = ((int64_t)v_t_24301.f[0]);
                                        if ((v_tag_24302 == ((int64_t)0ULL))) {
                                          V v_x31_24305 = v_field_24303;
                                          switch (heff_tag_of(v_x31_24305)) {
                                          case TAG_MkPair: {
                                            V v_x_24306 = heff_field(v_x31_24305, 0);
                                            V v_j_24307 = heff_field(v_x31_24305, 1);
                                            V v_ru_24x31_24305_24MkPair = heff_take_reuse_n(v_x31_24305, 3ULL, 2);
                                            V v_x2_24308 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22), heff_dup(v_x_24306), MK_INT(0LL), heff_strFind(((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23), v_x_24306, MK_INT(0LL)), NTAG(TAG_Nil)));
                                            V v_t_24311;
                                            switch (heff_tag_of(v_x2_24308)) {
                                            case TAG_Nil: {
                                              v_t_24311 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24);
                                              break;
                                            }
                                            case TAG_Cons: {
                                              V v_x_24309 = heff_field(v_x2_24308, 0);
                                              V v_xs_24310 = heff_field(v_x2_24308, 1);
                                              heff_take_n(v_x2_24308, 3ULL, 2);
                                              v_t_24311 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25); V a_1 = v_x_24309; V a_2 = v_xs_24310; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24310); r_; });
                                              break;
                                            }
                                            default: heff_nomatch(v_x2_24308);
                                            }
                                            double v_t_24312 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24311));
                                            V v_x_24313 = heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24312)});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24305_24MkPair, TAG_MkPair, 2, (V[]){v_x_24313, v_j_24307})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24305)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24303);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26), 2)) {
                                        heff_drop_rec(v_k_240, 1);
                                        heff_drop(v_x2_241);
                                        heff_drop(v_z_242);
                                        V v_t_24315 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_z_243});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24315}});
                                      } else {
                                        if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27))) {
                                          HeffT2 v_t_24317 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                                          {
                                            V v_field_24319 = v_t_24317.f[1];
                                            int64_t v_tag_24318 = ((int64_t)v_t_24317.f[0]);
                                            if ((v_tag_24318 == ((int64_t)0ULL))) {
                                              V v_x31_24321 = v_field_24319;
                                              switch (heff_tag_of(v_x31_24321)) {
                                              case TAG_MkPair: {
                                                V v_x_24322 = heff_field(v_x31_24321, 0);
                                                V v_j_24323 = heff_field(v_x31_24321, 1);
                                                V v_ru_24x31_24321_24MkPair = heff_take_reuse_n(v_x31_24321, 3ULL, 2);
                                                V v_x3_24324 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24323}));
                                                switch (heff_tag_of(v_x3_24324)) {
                                                case TAG_Nothing: {
                                                  heff_drop(v_x_24322);
                                                  heff_drop_cell(v_ru_24x31_24321_24MkPair, 2);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24325 = heff_field(v_x3_24324, 0);
                                                  heff_take_n(v_x3_24324, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24325)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24326 = heff_field(v_x31_24325, 0);
                                                    V v_j_24327 = heff_field(v_x31_24325, 1);
                                                    heff_take_n(v_x31_24325, 3ULL, 2);
                                                    V v_t_24328 = heff_tag_at_n(v_ru_24x31_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24322, v_x_24326}), v_j_24327});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24328}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24325)}});
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x3_24324)}});
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24321)}});
                                              }
                                            } else {
                                              heff_drop_rec(v_k_240, 1);
                                              heff_drop(v_z_242);
                                              heff_drop(v_field_24319);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop_rec(v_k_240, 1);
                                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

static V g_heff_2ecompile_2eirtext_2etakeExpr_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2etakeExpr_st;
static V g_heff_2ecompile_2eirtext_2etakeExpr_init(void) {
  return heff_dup(heff_rfield(g_heff_2ecompile_2eirtext_2edk_get(), 0));
}
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2etakeExpr_st)) return g_heff_2ecompile_2eirtext_2etakeExpr_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2etakeExpr_val, &g_heff_2ecompile_2eirtext_2etakeExpr_st, g_heff_2ecompile_2eirtext_2etakeExpr_init);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2estrsH_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_244}), heff_hole()});
      V v_cell_247 = heff_tag_at_n(v_ru_24x11_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_245}), heff_hole()});
      V v_u_248 = heff_setField(heff_dup(v_cell_246), MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_u_249 = (g_heff_2ecompile_2eirtext_2efieldsH_24dps(v_fs_243, v_rest_241, v_cell_247));
      heff_drop(v_u_249);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str12, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str13, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str14, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str15, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str16, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str17, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str18, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str19, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str20, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2enodeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enodeH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enodeH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_HS, 1, (V[]){v_x_242}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(1LL)}), v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EGlobal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EGlobal, TAG_HS, 1, (V[]){v_g_244}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(2LL)}), v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_247}), v_rest_241});
    V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_246, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2410});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(3LL)}), v_t_2411});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_as_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2413));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2413, v_rest_241));
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_f_2412}), v_t_2416});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(4LL)}), v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    V v_a_2419 = heff_field(v_x1_240, 1);
    V v_b_2420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2420}), v_rest_241});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2419}), v_t_2421});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2418}), v_t_2422});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(5LL)}), v_t_2423});
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x1_240, 0);
    V v_ts_2425 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2424));
    V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2425));
    V v_t_2428 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2425));
    V v_t_2429 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2427}), v_t_2428});
    V v_t_2430 = (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_2424, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2426}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(6LL)}), v_t_2431});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_l_2433 = heff_field(v_x1_240, 1);
    V v_sh_2434 = heff_field(v_x1_240, 2);
    V v_t_2435 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2438;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_FtFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2437 = heff_field(v_t_2435, 0);
      heff_take_n(v_t_2435, 1ULL, 1);
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str1);
        break;
      }
      case TAG_I16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str2);
        break;
      }
      case TAG_I32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str3);
        break;
      }
      case TAG_I64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str4);
        break;
      }
      case TAG_U8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str5);
        break;
      }
      case TAG_U16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str6);
        break;
      }
      case TAG_U32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str7);
        break;
      }
      case TAG_U64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str8);
        break;
      }
      case TAG_F32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str9);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str11);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2438}), v_rest_241});
    V v_t_2440 = (g_heff_2ecompile_2eirtext_2estrsH(v_sh_2434, v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2436}), v_t_2440});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_2433}), v_t_2441});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_2432}), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(7LL)}), v_t_2443});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x1_240, 0);
    V v_as_2445 = heff_field(v_x1_240, 1);
    V v_ts_2446 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2445));
    V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2446));
    V v_t_2449 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2446));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2448}), v_t_2449});
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2445, v_t_2450));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2447}), v_t_2451});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2444}), v_t_2452});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(8LL)}), v_t_2453});
  }
  case TAG_EMatch: {
    V v_s_2454 = heff_field(v_x1_240, 0);
    V v_arms_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2455));
    V v_t_2457 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_2455, v_rest_241));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2456}), v_t_2457});
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_s_2454}), v_t_2458});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(9LL)}), v_t_2459});
  }
  case TAG_EPrim: {
    V v_p_2460 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EPrim, TAG_HS, 1, (V[]){v_p_2460}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(10LL)}), v_t_2461});
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_x1_240, 0);
    V v_as_2463 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2464 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2463));
    V v_t_2465 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2463, v_rest_241));
    V v_t_2466 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2464}), v_t_2465});
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_p_2462}), v_t_2466});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(11LL)}), v_t_2467});
  }
  case TAG_ECall: {
    V v_g_2468 = heff_field(v_x1_240, 0);
    V v_as_2469 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2469));
    V v_t_2471 = (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2469, v_rest_241));
    V v_t_2472 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2470}), v_t_2471});
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_2468}), v_t_2472});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(12LL)}), v_t_2473});
  }
  case TAG_EInt: {
    V v_i_2474 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2475 = heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_HS, 1, (V[]){heff_intShow(v_i_2474)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(13LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2476 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x1_240_24EFloat, TAG_HS, 1, (V[]){heff_floatShow(v_x_2476)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(14LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2478 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_HS, 1, (V[]){v_s_2478}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(15LL)}), v_t_2479});
  }
  case TAG_EBytes: {
    V v_s_2480 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBytes = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBytes, TAG_HS, 1, (V[]){v_s_2480}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(20LL)}), v_t_2481});
  }
  case TAG_EFixed: {
    V v_w_2482 = heff_field(v_x1_240, 0);
    V v_n_2483 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2484;
    switch (heff_tag_of(v_w_2482)) {
    case TAG_I8: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str12);
      break;
    }
    case TAG_I16: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str13);
      break;
    }
    case TAG_I32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str14);
      break;
    }
    case TAG_I64: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str15);
      break;
    }
    case TAG_U8: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str16);
      break;
    }
    case TAG_U16: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str17);
      break;
    }
    case TAG_U32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str18);
      break;
    }
    case TAG_U64: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str19);
      break;
    }
    case TAG_F32: {
      v_t_2484 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str20);
      break;
    }
    default: heff_nomatch(v_w_2482);
    }
    V v_t_2485 = heff_tag_n(TAG_HS, 1, (V[]){heff_intShow(v_n_2483)});
    V v_t_2486 = heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2484}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(16LL)}), v_t_2486});
  }
  case TAG_EFloat32: {
    V v_x_2487 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat32 = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2488 = heff_tag_at_n(v_ru_24x1_240_24EFloat32, TAG_HS, 1, (V[]){heff_floatShow(v_x_2487)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(17LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(18LL)}), v_rest_241});
  }
  case TAG_EFix: {
    V v_f_2489 = heff_field(v_x1_240, 0);
    V v_b_2490 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2491 = heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2490}), v_rest_241});
    V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_f_2489}), v_t_2491});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(19LL)}), v_t_2492});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enodeH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V v_rest_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_rest_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1);
        break;
      }
      case TAG_I16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2);
        break;
      }
      case TAG_I32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3);
        break;
      }
      case TAG_I64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4);
        break;
      }
      case TAG_U8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5);
        break;
      }
      case TAG_U16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6);
        break;
      }
      case TAG_U32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7);
        break;
      }
      case TAG_U64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8);
        break;
      }
      case TAG_F32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_245}), heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(v_rest_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(a[0], a[1]);
}