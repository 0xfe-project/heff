// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HC 9068
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ebytesH_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eckOf(V);
V g_heff_2ecompile_2eirtext_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eckOf_clo;
V g_heff_2ecompile_2eirtext_2econdOfTag(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo;
HeffT2 g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH(V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V, V);
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V);
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
HeffT2 g_heff_2ecompile_2eirtext_2eprimD_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2ecompile_2eirtext_2estrsT_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2eprimitive_2ecompilerTable_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsT(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eirtext_2estrsT_str0)), v_x_242);
    V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsT_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_24dps_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsT_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eirtext_2estrsT_24dps_str0)), v_x_243);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_247;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_rest_244 = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(v_es_243, v_rest_241));
    HEFF_LAST return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_242), v_rest_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str57, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str58, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str59, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_t_244 = heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0)), v_x_242);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_rest_241})});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_g_245, 0));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2)), v_g_245);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_249, v_rest_241));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_248, v_rest_2410));
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4), v_t_2413});
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_240, 0);
    V v_args_2415 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2415));
    V v_t_2417 = ({ V a_0 = v_args_2415; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2415); r_; });
    V v_rest_2418 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2417});
    V v_t_2419 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2414, v_rest_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5), v_t_2419});
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_x2_240, 0);
    V v_a_2421 = heff_field(v_x2_240, 1);
    V v_b_2422 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2423 = heff_intShow(heff_strLength_lent(v_x_2420, 0));
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6)), v_x_2420);
    V v_rest_2425 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2422, v_rest_241));
    V v_t_2426 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2421, v_rest_2425));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2426})});
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_x2_240, 0);
    V v_ts_2428 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2427));
    V v_xs_2430 = (g_list_2emap_24s143096761x246530315(v_ts_2428));
    V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
    V v_t_2432 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2430, v_rest_241));
    V v_t_2433 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2431), v_t_2432});
    V v_t_2434 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2427, v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2429), v_t_2434});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8), v_t_2435});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_240, 0);
    V v_l_2437 = heff_field(v_x2_240, 1);
    V v_sh_2438 = heff_field(v_x2_240, 2);
    V v_t_2439 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2440 = heff_intShow(heff_strLength_lent(v_l_2437, 0));
    V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9)), v_l_2437);
    V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2438));
    V v_s_2444;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_FtFloat: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2443 = heff_field(v_t_2439, 0);
      heff_take_n(v_t_2439, 1ULL, 1);
      switch (heff_tag_of(v_w_2443)) {
      case TAG_I8: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11);
        break;
      }
      case TAG_I16: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12);
        break;
      }
      case TAG_I32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13);
        break;
      }
      case TAG_I64: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14);
        break;
      }
      case TAG_U8: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15);
        break;
      }
      case TAG_U16: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16);
        break;
      }
      case TAG_U32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17);
        break;
      }
      case TAG_U64: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18);
        break;
      }
      case TAG_F32: {
        v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19);
        break;
      }
      default: heff_nomatch(v_w_2443);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20);
      break;
    }
    case TAG_FtAny: {
      v_s_2444 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21);
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    V v_t_2445 = heff_intShow(heff_strLength_lent(v_s_2444, 0));
    V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22)), v_s_2444);
    V v_t_2447 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_rest_241})));
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2442), v_t_2447});
    V v_rest_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2448});
    V v_t_2450 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2436, v_rest_2449));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23), v_t_2450});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_x2_240, 0);
    V v_args_2452 = heff_field(v_x2_240, 1);
    V v_ts_2453 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2454 = heff_intShow(heff_strLength_lent(v_t_2451, 0));
    V v_t_2455 = heff_strAppend(heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24)), v_t_2451);
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2452));
    V v_xs_2457 = (g_list_2emap_24s143096761x246530315(v_ts_2453));
    V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2457));
    V v_t_2459 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2457, v_rest_241));
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2458), v_t_2459});
    V v_t_2461 = ({ V a_0 = v_args_2452; V a_1 = v_t_2460; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2452); r_; });
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2456), v_t_2461});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2462})});
  }
  case TAG_EMatch: {
    V v_s_2463 = heff_field(v_x2_240, 0);
    V v_arms_2464 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2464));
    V v_t_2466 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2464, v_rest_241));
    V v_rest_2467 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2465), v_t_2466});
    V v_t_2468 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2463, v_rest_2467));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26), v_t_2468});
  }
  case TAG_EPrim: {
    V v_p_2469 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2470 = ({ V a_0 = v_p_2469; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2469); r_; });
    V v_t_2471 = heff_intShow(heff_strLength_lent(v_s_2470, 0));
    V v_t_2472 = heff_strAppend(heff_strAppend(v_t_2471, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27)), v_s_2470);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, v_rest_241})});
  }
  case TAG_EPrimCall: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_args_2474 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_s_2475 = ({ V a_0 = v_p_2473; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2473); r_; });
    V v_t_2476 = heff_intShow(heff_strLength_lent(v_s_2475, 0));
    V v_t_2477 = heff_strAppend(heff_strAppend(v_t_2476, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29)), v_s_2475);
    V v_t_2478 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2474));
    V v_t_2479 = ({ V a_0 = v_args_2474; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2474); r_; });
    V v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2478), v_t_2479});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_t_2480})});
  }
  case TAG_ECall: {
    V v_g_2481 = heff_field(v_x2_240, 0);
    V v_args_2482 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2483 = heff_intShow(heff_strLength_lent(v_g_2481, 0));
    V v_t_2484 = heff_strAppend(heff_strAppend(v_t_2483, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31)), v_g_2481);
    V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2482));
    V v_t_2486 = ({ V a_0 = v_args_2482; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2482); r_; });
    V v_t_2487 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2485), v_t_2486});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, v_t_2487})});
  }
  case TAG_EInt: {
    V v_i_2488 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2489 = heff_intShow(v_i_2488);
    V v_t_2490 = heff_intShow(heff_strLength_lent(v_s_2489, 0));
    V v_t_2491 = heff_strAppend(heff_strAppend(v_t_2490, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33)), v_s_2489);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2492 = heff_tget_v(v_x2_240, 0);
    heff_take_nf(v_x2_240, 0ULL, 1);
    V v_s_2493 = heff_floatShow(v_x_2492);
    V v_t_2494 = heff_intShow(heff_strLength_lent(v_s_2493, 0));
    V v_t_2495 = heff_strAppend(heff_strAppend(v_t_2494, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35)), v_s_2493);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2496 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2497 = heff_intShow(heff_strLength_lent(v_s_2496, 0));
    V v_t_2498 = heff_strAppend(heff_strAppend(v_t_2497, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37)), v_s_2496);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, v_rest_241})});
  }
  case TAG_EBytes: {
    V v_s_2499 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24100 = heff_intShow(heff_strLength_lent(v_s_2499, 0));
    V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39)), v_s_2499);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24101, v_rest_241})});
  }
  case TAG_EFixed: {
    V v_w_24102 = heff_field(v_x2_240, 0);
    V v_n_24103 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24104;
    switch (heff_tag_of(v_w_24102)) {
    case TAG_I8: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41);
      break;
    }
    case TAG_I16: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str42);
      break;
    }
    case TAG_I32: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str43);
      break;
    }
    case TAG_I64: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str44);
      break;
    }
    case TAG_U8: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str45);
      break;
    }
    case TAG_U16: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str46);
      break;
    }
    case TAG_U32: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str47);
      break;
    }
    case TAG_U64: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str48);
      break;
    }
    case TAG_F32: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str49);
      break;
    }
    default: heff_nomatch(v_w_24102);
    }
    V v_s_24105 = heff_intShow(v_n_24103);
    V v_t_24106 = heff_intShow(heff_strLength_lent(v_s_24105, 0));
    V v_t_24107 = heff_strAppend(heff_strAppend(v_t_24106, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str50)), v_s_24105);
    V v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24104, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str51), v_t_24108});
  }
  case TAG_EFloat32: {
    V v_x_24109 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24110 = heff_floatShow(v_x_24109);
    V v_t_24111 = heff_intShow(heff_strLength_lent(v_s_24110, 0));
    V v_t_24112 = heff_strAppend(heff_strAppend(v_t_24111, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str52)), v_s_24110);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24112, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str54), v_rest_241});
  }
  case TAG_EBool: {
    V v_c_24113 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24114 = ({ V a_0 = v_c_24113; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(a_0, a_1)); heff_drop(v_c_24113); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str55), v_t_24114});
  }
  case TAG_ESet: {
    V v_xs_24115 = heff_field(v_x2_240, 0);
    V v_a_24116 = heff_field(v_x2_240, 1);
    V v_b_24117 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_rest_24118 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_24117, v_rest_241));
    V v_rest_24119 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_24116, v_rest_24118));
    V v_t_24120 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24115));
    V v_t_24121 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_24115, v_rest_24119));
    V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24120), v_t_24121});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str56), v_t_24122});
  }
  case TAG_EValues: {
    V v_es_24123 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24124 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_24123));
    V v_t_24125 = ({ V a_0 = v_es_24123; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_es_24123); r_; });
    V v_t_24126 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24124), v_t_24125});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str57), v_t_24126});
  }
  case TAG_EFix: {
    V v_f_24127 = heff_field(v_x2_240, 0);
    V v_b_24128 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24129 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str58), heff_hole()});
    V v_t_24130 = heff_intShow(heff_strLength_lent(v_f_24127, 0));
    V v_t_24131 = heff_strAppend(heff_strAppend(v_t_24130, ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str59)), v_f_24127);
    V v_cell_24132 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24131, heff_hole()});
    V v_u_24133 = heff_setField(heff_dup(v_cell_24129), MK_INT(1LL), heff_dup(v_cell_24132));
    heff_drop(v_u_24133);
    V v_u_24134 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(v_b_24128, v_rest_241, v_cell_24132));
    heff_drop(v_u_24134);
    return v_cell_24129;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD(V v_d_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_dup(v_d_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_clo), 2, (V[]){v_d_240, v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo);
  } else {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo), 1, (V[]){v_t_244});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}

HeffT2 g_heff_2ecompile_2eirtext_2eprimD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2ecompilerTable_get()); V a_1 = v_x_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          HeffT2 v_t_2411 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_x_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_246); r_; });
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_field_2410);
              V v_x_2414 = v_field_2413;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_j_247})}});
            } else {
              heff_drop(v_field_2413);
              if ((v_tag_249 == ((int64_t)0ULL))) {
                V v_x_2415 = v_field_2410;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_j_247})}});
              } else {
                heff_drop(v_j_247);
                heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                heff_drop(v_field_2410);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econdOfTag_entry, 5, 0};

V g_heff_2ecompile_2eirtext_2econdOfTag(V v_k_240, V v_c_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(v_k_240, v_c_241, v_x3_242, v_z_243, v_z_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_247});
    } else {
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eirtext_2econdOfTag(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0_clo);
  } else {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo), 1, (V[]){v_t_244});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0, 2, 0};
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args);
Clo g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(V v_lit_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
    heff_drop(v_lit_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0_clo);
  } else {
    V v_more_245 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(heff_dup(v_lit_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_clo_n(g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1, 2, 2, (V[]){v_lit_240, v_more_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_i_247 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_more_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_k_248 = v_lit_240;
  V v_s_249 = heff_dup(v_s_246);
  V v_i_2410 = v_i_247;
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_249), v_i_2410));
  V v_x3_2433;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x31_2414 = v_field_2413;
      switch (heff_tag_of(v_x31_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x31_2414, 0);
        V v_j_2416 = heff_field(v_x31_2414, 1);
        V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
        HeffT2 v_t_2417 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_249, v_j_2416));
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_x31_2420 = v_field_2419;
            switch (heff_tag_of(v_x31_2420)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_field(v_x31_2420, 0);
              V v_j_2422 = heff_field(v_x31_2420, 1);
              heff_take_n(v_x31_2420, 3ULL, 2);
              V v_t_2423 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2421));
              V v_x3_2424 = heff_tr(heff_call(v_t_2423, 2, (V[]){heff_dup(v_s_249), v_j_2422}));
              switch (heff_tag_of(v_x3_2424)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_248, 1);
                heff_drop(v_s_249);
                heff_drop(v_x_2415);
                heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
                v_x3_2433 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2425 = heff_field(v_x3_2424, 0);
                V v_ru_24x3_2424_24Just = heff_take_reuse_n(v_x3_2424, 1ULL, 1);
                switch (heff_tag_of(v_x31_2425)) {
                case TAG_MkPair: {
                  V v_x_2426 = heff_field(v_x31_2425, 0);
                  V v_j_2427 = heff_field(v_x31_2425, 1);
                  heff_take_n(v_x31_2425, 3ULL, 2);
                  V v_x3_2428 = heff_tr(heff_call(heff_get_n(v_k_248, 0, 1), 2, (V[]){v_s_249, v_j_2427}));
                  switch (heff_tag_of(v_x3_2428)) {
                  case TAG_Nothing: {
                    heff_drop(v_x_2415);
                    heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
                    heff_drop_cell(v_ru_24x3_2424_24Just, 1);
                    heff_drop(v_x_2426);
                    v_x3_2433 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2429 = heff_field(v_x3_2428, 0);
                    heff_take_n(v_x3_2428, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2429)) {
                    case TAG_MkPair: {
                      V v_x_2430 = heff_field(v_x31_2429, 0);
                      V v_j_2431 = heff_field(v_x31_2429, 1);
                      heff_take_n(v_x31_2429, 3ULL, 2);
                      V v_t_2432 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_x_2415, v_x_2426, v_x_2430}), v_j_2431});
                      v_x3_2433 = heff_tag_at_n(v_ru_24x3_2424_24Just, TAG_Just, 1, (V[]){v_t_2432});
                      break;
                    }
                    default: heff_nomatch(v_x31_2429);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2428);
                  }
                  break;
                }
                default: heff_nomatch(v_x31_2425);
                }
                break;
              }
              default: heff_nomatch(v_x3_2424);
              }
              break;
            }
            default: heff_nomatch(v_x31_2420);
            }
          } else {
            heff_drop_rec(v_k_248, 1);
            heff_drop(v_s_249);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
            heff_drop(v_field_2419);
            v_x3_2433 = NTAG(TAG_Nothing);
          }
        }
        break;
      }
      default: heff_nomatch(v_x31_2414);
      }
    } else {
      heff_drop_rec(v_k_248, 1);
      heff_drop(v_s_249);
      heff_drop(v_field_2413);
      v_x3_2433 = NTAG(TAG_Nothing);
    }
  }
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_Nothing: {
    heff_drop(v_s_246);
    heff_drop(v_more_245);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2434 = heff_field(v_x3_2433, 0);
    V v_ru_24x3_2433_24Just = heff_take_reuse_n(v_x3_2433, 1ULL, 1);
    switch (heff_tag_of(v_x31_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x31_2434, 0);
      V v_j_2436 = heff_field(v_x31_2434, 1);
      V v_ru_24x31_2434_24MkPair = heff_take_reuse_n(v_x31_2434, 3ULL, 2);
      V v_x3_2437 = heff_tr(heff_call(v_more_245, 2, (V[]){v_s_246, v_j_2436}));
      switch (heff_tag_of(v_x3_2437)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2433_24Just, 1);
        heff_drop(v_x_2435);
        heff_drop_cell(v_ru_24x31_2434_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2438 = heff_field(v_x3_2437, 0);
        heff_take_n(v_x3_2437, 1ULL, 1);
        switch (heff_tag_of(v_x31_2438)) {
        case TAG_MkPair: {
          V v_x_2439 = heff_field(v_x31_2438, 0);
          V v_j_2440 = heff_field(v_x31_2438, 1);
          V v_ru_24x31_2438_24MkPair = heff_take_reuse_n(v_x31_2438, 3ULL, 2);
          V v_t_2441 = heff_tag_at_n(v_ru_24x31_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2438_24MkPair, TAG_Cons, 2, (V[]){v_x_2435, v_x_2439}), v_j_2440});
          return heff_tag_at_n(v_ru_24x3_2433_24Just, TAG_Just, 1, (V[]){v_t_2441});
        }
        default: return heff_nomatch(v_x31_2438);
        }
      }
      default: return heff_nomatch(v_x3_2437);
      }
    }
    default: return heff_nomatch(v_x31_2434);
    }
  }
  default: return heff_nomatch(v_x3_2433);
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str28, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str29, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str30, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str31, 1, "F");

HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 1);
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_248}), v_j_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 1);
      HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x31_2414 = v_field_2413;
          switch (heff_tag_of(v_x31_2414)) {
          case TAG_MkPair: {
            V v_x_2415 = heff_field(v_x31_2414, 0);
            V v_j_2416 = heff_field(v_x31_2414, 1);
            V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
            V v_t_2417 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2415}), v_j_2416});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2414)}});
          }
        } else {
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str2), 2)) {
        HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x31_2421 = v_field_2420;
            switch (heff_tag_of(v_x31_2421)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_field(v_x31_2421, 0);
              V v_j_2423 = heff_field(v_x31_2421, 1);
              V v_ru_24x31_2421_24MkPair = heff_take_reuse_n(v_x31_2421, 3ULL, 2);
              V v_t_2424 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2422));
              V v_x3_2425 = heff_tr(heff_call(v_t_2424, 2, (V[]){heff_dup(v_z_242), v_j_2423}));
              switch (heff_tag_of(v_x3_2425)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                heff_drop_cell(v_ru_24x31_2421_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2426 = heff_field(v_x3_2425, 0);
                heff_take_n(v_x3_2425, 1ULL, 1);
                switch (heff_tag_of(v_x31_2426)) {
                case TAG_MkPair: {
                  V v_x_2427 = heff_field(v_x31_2426, 0);
                  V v_j_2428 = heff_field(v_x31_2426, 1);
                  V v_ru_24x31_2426_24MkPair = heff_take_reuse_n(v_x31_2426, 3ULL, 2);
                  V v_x3_2429 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2428}));
                  switch (heff_tag_of(v_x3_2429)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x31_2421_24MkPair, 2);
                    heff_drop(v_x_2427);
                    heff_drop_cell(v_ru_24x31_2426_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2430 = heff_field(v_x3_2429, 0);
                    heff_take_n(v_x3_2429, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2430)) {
                    case TAG_MkPair: {
                      V v_x_2431 = heff_field(v_x31_2430, 0);
                      V v_j_2432 = heff_field(v_x31_2430, 1);
                      heff_take_n(v_x31_2430, 3ULL, 2);
                      V v_t_2433 = heff_tag_at_n(v_ru_24x31_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2426_24MkPair, TAG_ELam, 2, (V[]){v_x_2427, v_x_2431}), v_j_2432});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2433}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2430)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2429)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2426)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2425)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2421)}});
            }
          } else {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            heff_drop(v_field_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str3), 2)) {
          V v_m_2434 = heff_dup(heff_rfield(v_k_240, 0));
          V v_x3_2435 = heff_tr(heff_call(v_m_2434, 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2435)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2436 = heff_field(v_x3_2435, 0);
            heff_take_n(v_x3_2435, 1ULL, 1);
            switch (heff_tag_of(v_x31_2436)) {
            case TAG_MkPair: {
              V v_x_2437 = heff_field(v_x31_2436, 0);
              V v_j_2438 = heff_field(v_x31_2436, 1);
              V v_ru_24x31_2436_24MkPair = heff_take_reuse_n(v_x31_2436, 3ULL, 2);
              HeffT2 v_t_2439 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2438));
              {
                V v_field_2441 = v_t_2439.f[1];
                int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                if ((v_tag_2440 == ((int64_t)0ULL))) {
                  V v_x31_2442 = v_field_2441;
                  switch (heff_tag_of(v_x31_2442)) {
                  case TAG_MkPair: {
                    V v_x_2443 = heff_field(v_x31_2442, 0);
                    V v_j_2444 = heff_field(v_x31_2442, 1);
                    V v_ru_24x31_2442_24MkPair = heff_take_reuse_n(v_x31_2442, 3ULL, 2);
                    V v_t_2445 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2443));
                    V v_x3_2446 = heff_tr(heff_call(v_t_2445, 2, (V[]){v_z_242, v_j_2444}));
                    switch (heff_tag_of(v_x3_2446)) {
                    case TAG_Nothing: {
                      heff_drop(v_x_2437);
                      heff_drop_cell(v_ru_24x31_2436_24MkPair, 2);
                      heff_drop_cell(v_ru_24x31_2442_24MkPair, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2447 = heff_field(v_x3_2446, 0);
                      heff_take_n(v_x3_2446, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2447)) {
                      case TAG_MkPair: {
                        V v_x_2448 = heff_field(v_x31_2447, 0);
                        V v_j_2449 = heff_field(v_x31_2447, 1);
                        heff_take_n(v_x31_2447, 3ULL, 2);
                        V v_t_2450 = heff_tag_at_n(v_ru_24x31_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2442_24MkPair, TAG_EApp, 2, (V[]){v_x_2437, v_x_2448}), v_j_2449});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2450}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2447)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2446)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2442)}});
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_x_2437);
                  heff_drop_cell(v_ru_24x31_2436_24MkPair, 2);
                  heff_drop(v_field_2441);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2436)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2435)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str4), 2)) {
            HeffT2 v_t_2451 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
            {
              V v_field_2453 = v_t_2451.f[1];
              int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
              if ((v_tag_2452 == ((int64_t)0ULL))) {
                V v_x31_2454 = v_field_2453;
                switch (heff_tag_of(v_x31_2454)) {
                case TAG_MkPair: {
                  V v_x_2455 = heff_field(v_x31_2454, 0);
                  V v_j_2456 = heff_field(v_x31_2454, 1);
                  V v_ru_24x31_2454_24MkPair = heff_take_reuse_n(v_x31_2454, 3ULL, 2);
                  V v_x3_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_2456}));
                  switch (heff_tag_of(v_x3_2457)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_k_240, 1);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2455);
                    heff_drop_cell(v_ru_24x31_2454_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2458 = heff_field(v_x3_2457, 0);
                    heff_take_n(v_x3_2457, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2458)) {
                    case TAG_MkPair: {
                      V v_x_2459 = heff_field(v_x31_2458, 0);
                      V v_j_2460 = heff_field(v_x31_2458, 1);
                      heff_take_n(v_x31_2458, 3ULL, 2);
                      V v_x3_2461 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2460}));
                      switch (heff_tag_of(v_x3_2461)) {
                      case TAG_Nothing: {
                        heff_drop(v_x_2455);
                        heff_drop_cell(v_ru_24x31_2454_24MkPair, 2);
                        heff_drop(v_x_2459);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2462 = heff_field(v_x3_2461, 0);
                        heff_take_n(v_x3_2461, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2462)) {
                        case TAG_MkPair: {
                          V v_x_2463 = heff_field(v_x31_2462, 0);
                          V v_j_2464 = heff_field(v_x31_2462, 1);
                          heff_take_n(v_x31_2462, 3ULL, 2);
                          V v_t_2465 = heff_tag_at_n(v_ru_24x31_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2455, v_x_2459, v_x_2463}), v_j_2464});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2465}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2462)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2461)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2458)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2457)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
                }
              } else {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                heff_drop(v_field_2453);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str5), 2)) {
              HeffT2 v_t_2466 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
              {
                V v_field_2468 = v_t_2466.f[1];
                int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
                if ((v_tag_2467 == ((int64_t)0ULL))) {
                  V v_x31_2469 = v_field_2468;
                  switch (heff_tag_of(v_x31_2469)) {
                  case TAG_MkPair: {
                    V v_x_2470 = heff_field(v_x31_2469, 0);
                    V v_j_2471 = heff_field(v_x31_2469, 1);
                    V v_ru_24x31_2469_24MkPair = heff_take_reuse_n(v_x31_2469, 3ULL, 2);
                    V v_t_2472 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2efieldD_clo), 1, (V[]){v_k_240}));
                    V v_t_2473 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_2472, v_x_2470));
                    V v_x3_2474 = heff_tr(heff_call(v_t_2473, 2, (V[]){heff_dup(v_z_242), v_j_2471}));
                    switch (heff_tag_of(v_x3_2474)) {
                    case TAG_Nothing: {
                      heff_drop(v_z_242);
                      heff_drop_cell(v_ru_24x31_2469_24MkPair, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2475 = heff_field(v_x3_2474, 0);
                      heff_take_n(v_x3_2474, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2475)) {
                      case TAG_MkPair: {
                        V v_x_2476 = heff_field(v_x31_2475, 0);
                        V v_j_2477 = heff_field(v_x31_2475, 1);
                        V v_ru_24x31_2475_24MkPair = heff_take_reuse_n(v_x31_2475, 3ULL, 2);
                        HeffT2 v_t_2478 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2477));
                        {
                          V v_field_2480 = v_t_2478.f[1];
                          int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
                          if ((v_tag_2479 == ((int64_t)0ULL))) {
                            V v_x31_2481 = v_field_2480;
                            switch (heff_tag_of(v_x31_2481)) {
                            case TAG_MkPair: {
                              V v_x_2482 = heff_field(v_x31_2481, 0);
                              V v_j_2483 = heff_field(v_x31_2481, 1);
                              heff_take_n(v_x31_2481, 3ULL, 2);
                              V v_t_2484 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_2482));
                              V v_x3_2485 = heff_tr(heff_call(v_t_2484, 2, (V[]){v_z_242, v_j_2483}));
                              switch (heff_tag_of(v_x3_2485)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x31_2469_24MkPair, 2);
                                heff_drop(v_x_2476);
                                heff_drop_cell(v_ru_24x31_2475_24MkPair, 2);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_2486 = heff_field(v_x3_2485, 0);
                                heff_take_n(v_x3_2485, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2486)) {
                                case TAG_MkPair: {
                                  V v_x_2487 = heff_field(v_x31_2486, 0);
                                  V v_j_2488 = heff_field(v_x31_2486, 1);
                                  heff_take_n(v_x31_2486, 3ULL, 2);
                                  V v_t_2489 = heff_tag_at_n(v_ru_24x31_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2475_24MkPair, TAG_ERecord, 2, (V[]){v_x_2476, v_x_2487}), v_j_2488});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2489}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_2486)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_2485)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2481)}});
                            }
                          } else {
                            heff_drop(v_z_242);
                            heff_drop_cell(v_ru_24x31_2469_24MkPair, 2);
                            heff_drop(v_x_2476);
                            heff_drop_cell(v_ru_24x31_2475_24MkPair, 2);
                            heff_drop(v_field_2480);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2475)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2474)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2469)}});
                  }
                } else {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop(v_field_2468);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str6), 2)) {
                V v_x3_2490 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2490)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2491 = heff_field(v_x3_2490, 0);
                  heff_take_n(v_x3_2490, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2491)) {
                  case TAG_MkPair: {
                    V v_x_2492 = heff_field(v_x31_2491, 0);
                    V v_j_2493 = heff_field(v_x31_2491, 1);
                    V v_ru_24x31_2491_24MkPair = heff_take_reuse_n(v_x31_2491, 3ULL, 2);
                    HeffT2 v_t_2494 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_j_2493));
                    {
                      V v_field_2496 = v_t_2494.f[1];
                      int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
                      if ((v_tag_2495 == ((int64_t)0ULL))) {
                        V v_x31_2497 = v_field_2496;
                        switch (heff_tag_of(v_x31_2497)) {
                        case TAG_MkPair: {
                          V v_x_2498 = heff_field(v_x31_2497, 0);
                          V v_j_2499 = heff_field(v_x31_2497, 1);
                          heff_take_n(v_x31_2497, 3ULL, 2);
                          HeffT2 v_t_24100 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2499));
                          {
                            V v_field_24102 = v_t_24100.f[1];
                            int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                            if ((v_tag_24101 == ((int64_t)0ULL))) {
                              V v_x31_24103 = v_field_24102;
                              switch (heff_tag_of(v_x31_24103)) {
                              case TAG_MkPair: {
                                V v_x_24104 = heff_field(v_x31_24103, 0);
                                V v_j_24105 = heff_field(v_x31_24103, 1);
                                heff_take_n(v_x31_24103, 3ULL, 2);
                                V v_t_24106 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_24104));
                                V v_x3_24107 = heff_tr(heff_call(v_t_24106, 2, (V[]){heff_dup(v_z_242), v_j_24105}));
                                switch (heff_tag_of(v_x3_24107)) {
                                case TAG_Nothing: {
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_2492);
                                  heff_drop_cell(v_ru_24x31_2491_24MkPair, 2);
                                  heff_drop(v_x_2498);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24108 = heff_field(v_x3_24107, 0);
                                  heff_take_n(v_x3_24107, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24108)) {
                                  case TAG_MkPair: {
                                    V v_x_24109 = heff_field(v_x31_24108, 0);
                                    V v_j_24110 = heff_field(v_x31_24108, 1);
                                    heff_take_n(v_x31_24108, 3ULL, 2);
                                    HeffT2 v_t_24111 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24110));
                                    {
                                      V v_field_24113 = v_t_24111.f[1];
                                      int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
                                      if ((v_tag_24112 == ((int64_t)0ULL))) {
                                        V v_x31_24114 = v_field_24113;
                                        switch (heff_tag_of(v_x31_24114)) {
                                        case TAG_MkPair: {
                                          V v_x_24115 = heff_field(v_x31_24114, 0);
                                          V v_j_24116 = heff_field(v_x31_24114, 1);
                                          heff_take_n(v_x31_24114, 3ULL, 2);
                                          HeffT2 v_t_24117 = ({ V a_0 = v_x_24115; HeffT2 r_ = (g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(a_0)); heff_drop(v_x_24115); r_; });
                                          {
                                            V v_field_24119 = v_t_24117.f[1];
                                            int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
                                            if ((v_tag_24118 == ((int64_t)0ULL))) {
                                              V v_x_24120 = v_field_24119;
                                              V v_t_24121 = heff_tag_at_n(v_ru_24x31_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2492, v_x_2498, v_x_24109, v_x_24120}), v_j_24116});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24121}});
                                            } else {
                                              heff_drop(v_x_2492);
                                              heff_drop_cell(v_ru_24x31_2491_24MkPair, 2);
                                              heff_drop(v_x_2498);
                                              heff_drop(v_x_24109);
                                              heff_drop(v_j_24116);
                                              heff_drop(v_field_24119);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24114)}});
                                        }
                                      } else {
                                        heff_drop(v_x_2492);
                                        heff_drop_cell(v_ru_24x31_2491_24MkPair, 2);
                                        heff_drop(v_x_2498);
                                        heff_drop(v_x_24109);
                                        heff_drop(v_field_24113);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24108)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24107)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24103)}});
                              }
                            } else {
                              heff_drop(v_z_242);
                              heff_drop(v_x_2492);
                              heff_drop_cell(v_ru_24x31_2491_24MkPair, 2);
                              heff_drop(v_x_2498);
                              heff_drop(v_field_24102);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2497)}});
                        }
                      } else {
                        heff_drop(v_z_242);
                        heff_drop(v_x_2492);
                        heff_drop_cell(v_ru_24x31_2491_24MkPair, 2);
                        heff_drop(v_field_2496);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2491)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2490)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str7), 2)) {
                  HeffT2 v_t_24122 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                  {
                    V v_field_24124 = v_t_24122.f[1];
                    int64_t v_tag_24123 = ((int64_t)v_t_24122.f[0]);
                    if ((v_tag_24123 == ((int64_t)0ULL))) {
                      V v_x31_24125 = v_field_24124;
                      switch (heff_tag_of(v_x31_24125)) {
                      case TAG_MkPair: {
                        V v_x_24126 = heff_field(v_x31_24125, 0);
                        V v_j_24127 = heff_field(v_x31_24125, 1);
                        V v_ru_24x31_24125_24MkPair = heff_take_reuse_n(v_x31_24125, 3ULL, 2);
                        HeffT2 v_t_24128 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24127));
                        {
                          V v_field_24130 = v_t_24128.f[1];
                          int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
                          if ((v_tag_24129 == ((int64_t)0ULL))) {
                            V v_x31_24131 = v_field_24130;
                            switch (heff_tag_of(v_x31_24131)) {
                            case TAG_MkPair: {
                              V v_x_24132 = heff_field(v_x31_24131, 0);
                              V v_j_24133 = heff_field(v_x31_24131, 1);
                              heff_take_n(v_x31_24131, 3ULL, 2);
                              V v_t_24134 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24132));
                              V v_x3_24135 = heff_tr(heff_call(v_t_24134, 2, (V[]){heff_dup(v_z_242), v_j_24133}));
                              switch (heff_tag_of(v_x3_24135)) {
                              case TAG_Nothing: {
                                heff_drop(v_z_242);
                                heff_drop(v_x_24126);
                                heff_drop_cell(v_ru_24x31_24125_24MkPair, 2);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24136 = heff_field(v_x3_24135, 0);
                                heff_take_n(v_x3_24135, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24136)) {
                                case TAG_MkPair: {
                                  V v_x_24137 = heff_field(v_x31_24136, 0);
                                  V v_j_24138 = heff_field(v_x31_24136, 1);
                                  heff_take_n(v_x31_24136, 3ULL, 2);
                                  HeffT2 v_t_24139 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24138));
                                  {
                                    V v_field_24141 = v_t_24139.f[1];
                                    int64_t v_tag_24140 = ((int64_t)v_t_24139.f[0]);
                                    if ((v_tag_24140 == ((int64_t)0ULL))) {
                                      V v_x31_24142 = v_field_24141;
                                      switch (heff_tag_of(v_x31_24142)) {
                                      case TAG_MkPair: {
                                        V v_x_24143 = heff_field(v_x31_24142, 0);
                                        V v_j_24144 = heff_field(v_x31_24142, 1);
                                        heff_take_n(v_x31_24142, 3ULL, 2);
                                        V v_t_24145 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_24143));
                                        V v_x3_24146 = heff_tr(heff_call(v_t_24145, 2, (V[]){v_z_242, v_j_24144}));
                                        switch (heff_tag_of(v_x3_24146)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24126);
                                          heff_drop_cell(v_ru_24x31_24125_24MkPair, 2);
                                          heff_drop(v_x_24137);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24147 = heff_field(v_x3_24146, 0);
                                          heff_take_n(v_x3_24146, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24147)) {
                                          case TAG_MkPair: {
                                            V v_x_24148 = heff_field(v_x31_24147, 0);
                                            V v_j_24149 = heff_field(v_x31_24147, 1);
                                            heff_take_n(v_x31_24147, 3ULL, 2);
                                            V v_t_24150 = heff_tag_at_n(v_ru_24x31_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_x_24126, v_x_24137, v_x_24148}), v_j_24149});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24150}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24147)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24146)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24142)}});
                                      }
                                    } else {
                                      heff_drop(v_z_242);
                                      heff_drop(v_x_24126);
                                      heff_drop_cell(v_ru_24x31_24125_24MkPair, 2);
                                      heff_drop(v_x_24137);
                                      heff_drop(v_field_24141);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24136)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24135)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24131)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_x_24126);
                            heff_drop_cell(v_ru_24x31_24125_24MkPair, 2);
                            heff_drop(v_field_24130);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24125)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      heff_drop(v_field_24124);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str8), 2)) {
                    V v_m_24151 = heff_dup(heff_rfield(v_k_240, 0));
                    V v_x3_24152 = heff_tr(heff_call(v_m_24151, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24152)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_24153 = heff_field(v_x3_24152, 0);
                      heff_take_n(v_x3_24152, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24153)) {
                      case TAG_MkPair: {
                        V v_x_24154 = heff_field(v_x31_24153, 0);
                        V v_j_24155 = heff_field(v_x31_24153, 1);
                        V v_ru_24x31_24153_24MkPair = heff_take_reuse_n(v_x31_24153, 3ULL, 2);
                        HeffT2 v_t_24156 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24155));
                        {
                          V v_field_24158 = v_t_24156.f[1];
                          int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
                          if ((v_tag_24157 == ((int64_t)0ULL))) {
                            V v_x31_24159 = v_field_24158;
                            switch (heff_tag_of(v_x31_24159)) {
                            case TAG_MkPair: {
                              V v_x_24160 = heff_field(v_x31_24159, 0);
                              V v_j_24161 = heff_field(v_x31_24159, 1);
                              V v_ru_24x31_24159_24MkPair = heff_take_reuse_n(v_x31_24159, 3ULL, 2);
                              V v_t_24162 = (g_heff_2ecompile_2eirtext_2enD_24s1269069029x1592238963(v_k_240, v_x_24160));
                              V v_x3_24163 = heff_tr(heff_call(v_t_24162, 2, (V[]){v_z_242, v_j_24161}));
                              switch (heff_tag_of(v_x3_24163)) {
                              case TAG_Nothing: {
                                heff_drop(v_x_24154);
                                heff_drop_cell(v_ru_24x31_24153_24MkPair, 2);
                                heff_drop_cell(v_ru_24x31_24159_24MkPair, 2);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24164 = heff_field(v_x3_24163, 0);
                                heff_take_n(v_x3_24163, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24164)) {
                                case TAG_MkPair: {
                                  V v_x_24165 = heff_field(v_x31_24164, 0);
                                  V v_j_24166 = heff_field(v_x31_24164, 1);
                                  heff_take_n(v_x31_24164, 3ULL, 2);
                                  V v_t_24167 = heff_tag_at_n(v_ru_24x31_24153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24159_24MkPair, TAG_EMatch, 2, (V[]){v_x_24154, v_x_24165}), v_j_24166});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24167}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24164)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24163)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24159)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_x_24154);
                            heff_drop_cell(v_ru_24x31_24153_24MkPair, 2);
                            heff_drop(v_field_24158);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24153)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_24152)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 1);
                      HeffT2 v_t_24168 = (g_heff_2ecompile_2eirtext_2eprimD_24cpr(v_z_242, v_z_243));
                      {
                        V v_field_24170 = v_t_24168.f[1];
                        int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
                        if ((v_tag_24169 == ((int64_t)0ULL))) {
                          V v_x31_24171 = v_field_24170;
                          switch (heff_tag_of(v_x31_24171)) {
                          case TAG_MkPair: {
                            V v_x_24172 = heff_field(v_x31_24171, 0);
                            V v_j_24173 = heff_field(v_x31_24171, 1);
                            V v_ru_24x31_24171_24MkPair = heff_take_reuse_n(v_x31_24171, 3ULL, 2);
                            V v_t_24174 = heff_tag_at_n(v_ru_24x31_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24172}), v_j_24173});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24174}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24171)}});
                          }
                        } else {
                          heff_drop(v_field_24170);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str10), 2)) {
                        HeffT2 v_t_24175 = (g_heff_2ecompile_2eirtext_2eprimD_24cpr(heff_dup(v_z_242), v_z_243));
                        {
                          V v_field_24177 = v_t_24175.f[1];
                          int64_t v_tag_24176 = ((int64_t)v_t_24175.f[0]);
                          if ((v_tag_24176 == ((int64_t)0ULL))) {
                            V v_x31_24178 = v_field_24177;
                            switch (heff_tag_of(v_x31_24178)) {
                            case TAG_MkPair: {
                              V v_x_24179 = heff_field(v_x31_24178, 0);
                              V v_j_24180 = heff_field(v_x31_24178, 1);
                              V v_ru_24x31_24178_24MkPair = heff_take_reuse_n(v_x31_24178, 3ULL, 2);
                              HeffT2 v_t_24181 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24180));
                              {
                                V v_field_24183 = v_t_24181.f[1];
                                int64_t v_tag_24182 = ((int64_t)v_t_24181.f[0]);
                                if ((v_tag_24182 == ((int64_t)0ULL))) {
                                  V v_x31_24184 = v_field_24183;
                                  switch (heff_tag_of(v_x31_24184)) {
                                  case TAG_MkPair: {
                                    V v_x_24185 = heff_field(v_x31_24184, 0);
                                    V v_j_24186 = heff_field(v_x31_24184, 1);
                                    V v_ru_24x31_24184_24MkPair = heff_take_reuse_n(v_x31_24184, 3ULL, 2);
                                    V v_t_24187 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24185));
                                    V v_x3_24188 = heff_tr(heff_call(v_t_24187, 2, (V[]){v_z_242, v_j_24186}));
                                    switch (heff_tag_of(v_x3_24188)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_x_24179);
                                      heff_drop_cell(v_ru_24x31_24178_24MkPair, 2);
                                      heff_drop_cell(v_ru_24x31_24184_24MkPair, 2);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_24189 = heff_field(v_x3_24188, 0);
                                      heff_take_n(v_x3_24188, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24189)) {
                                      case TAG_MkPair: {
                                        V v_x_24190 = heff_field(v_x31_24189, 0);
                                        V v_j_24191 = heff_field(v_x31_24189, 1);
                                        heff_take_n(v_x31_24189, 3ULL, 2);
                                        V v_t_24192 = heff_tag_at_n(v_ru_24x31_24178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24184_24MkPair, TAG_EPrimCall, 2, (V[]){v_x_24179, v_x_24190}), v_j_24191});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24192}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24189)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_24188)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24184)}});
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_z_242);
                                  heff_drop(v_x_24179);
                                  heff_drop_cell(v_ru_24x31_24178_24MkPair, 2);
                                  heff_drop(v_field_24183);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24178)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            heff_drop(v_field_24177);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str11), 2)) {
                          HeffT2 v_t_24193 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                          {
                            V v_field_24195 = v_t_24193.f[1];
                            int64_t v_tag_24194 = ((int64_t)v_t_24193.f[0]);
                            if ((v_tag_24194 == ((int64_t)0ULL))) {
                              V v_x31_24196 = v_field_24195;
                              switch (heff_tag_of(v_x31_24196)) {
                              case TAG_MkPair: {
                                V v_x_24197 = heff_field(v_x31_24196, 0);
                                V v_j_24198 = heff_field(v_x31_24196, 1);
                                V v_ru_24x31_24196_24MkPair = heff_take_reuse_n(v_x31_24196, 3ULL, 2);
                                HeffT2 v_t_24199 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_24198));
                                {
                                  V v_field_24201 = v_t_24199.f[1];
                                  int64_t v_tag_24200 = ((int64_t)v_t_24199.f[0]);
                                  if ((v_tag_24200 == ((int64_t)0ULL))) {
                                    V v_x31_24202 = v_field_24201;
                                    switch (heff_tag_of(v_x31_24202)) {
                                    case TAG_MkPair: {
                                      V v_x_24203 = heff_field(v_x31_24202, 0);
                                      V v_j_24204 = heff_field(v_x31_24202, 1);
                                      V v_ru_24x31_24202_24MkPair = heff_take_reuse_n(v_x31_24202, 3ULL, 2);
                                      V v_t_24205 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24203));
                                      V v_x3_24206 = heff_tr(heff_call(v_t_24205, 2, (V[]){v_z_242, v_j_24204}));
                                      switch (heff_tag_of(v_x3_24206)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_x_24197);
                                        heff_drop_cell(v_ru_24x31_24196_24MkPair, 2);
                                        heff_drop_cell(v_ru_24x31_24202_24MkPair, 2);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                      case TAG_Just: {
                                        V v_x31_24207 = heff_field(v_x3_24206, 0);
                                        heff_take_n(v_x3_24206, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24207)) {
                                        case TAG_MkPair: {
                                          V v_x_24208 = heff_field(v_x31_24207, 0);
                                          V v_j_24209 = heff_field(v_x31_24207, 1);
                                          heff_take_n(v_x31_24207, 3ULL, 2);
                                          V v_t_24210 = heff_tag_at_n(v_ru_24x31_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24202_24MkPair, TAG_ECall, 2, (V[]){v_x_24197, v_x_24208}), v_j_24209});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24210}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24207)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x3_24206)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24202)}});
                                    }
                                  } else {
                                    heff_drop_rec(v_k_240, 1);
                                    heff_drop(v_z_242);
                                    heff_drop(v_x_24197);
                                    heff_drop_cell(v_ru_24x31_24196_24MkPair, 2);
                                    heff_drop(v_field_24201);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24196)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              heff_drop(v_field_24195);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 1);
                            HeffT2 v_t_24211 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                            {
                              V v_field_24213 = v_t_24211.f[1];
                              int64_t v_tag_24212 = ((int64_t)v_t_24211.f[0]);
                              if ((v_tag_24212 == ((int64_t)0ULL))) {
                                V v_x31_24214 = v_field_24213;
                                switch (heff_tag_of(v_x31_24214)) {
                                case TAG_MkPair: {
                                  V v_x_24215 = heff_field(v_x31_24214, 0);
                                  V v_j_24216 = heff_field(v_x31_24214, 1);
                                  V v_ru_24x31_24214_24MkPair = heff_take_reuse_n(v_x31_24214, 3ULL, 2);
                                  V v_t_24217 = ({ V a_0 = v_x_24215; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24215); r_; });
                                  V v_x_24218 = heff_tag_n(TAG_EInt, 1, (V[]){v_t_24217});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24214_24MkPair, TAG_MkPair, 2, (V[]){v_x_24218, v_j_24216})}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24214)}});
                                }
                              } else {
                                heff_drop(v_field_24213);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str13), 2)) {
                              heff_drop_rec(v_k_240, 1);
                              HeffT2 v_t_24219 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                              {
                                V v_field_24221 = v_t_24219.f[1];
                                int64_t v_tag_24220 = ((int64_t)v_t_24219.f[0]);
                                if ((v_tag_24220 == ((int64_t)0ULL))) {
                                  V v_x31_24222 = v_field_24221;
                                  switch (heff_tag_of(v_x31_24222)) {
                                  case TAG_MkPair: {
                                    V v_x_24223 = heff_field(v_x31_24222, 0);
                                    V v_j_24224 = heff_field(v_x31_24222, 1);
                                    V v_ru_24x31_24222_24MkPair = heff_take_reuse_n(v_x31_24222, 3ULL, 2);
                                    double v_t_24225 = ({ V a_0 = v_x_24223; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24223); r_; });
                                    V v_x_24226 = heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_24225)});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24222_24MkPair, TAG_MkPair, 2, (V[]){v_x_24226, v_j_24224})}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24222)}});
                                  }
                                } else {
                                  heff_drop(v_field_24221);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str14), 2)) {
                                heff_drop_rec(v_k_240, 1);
                                HeffT2 v_t_24227 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                {
                                  V v_field_24229 = v_t_24227.f[1];
                                  int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
                                  if ((v_tag_24228 == ((int64_t)0ULL))) {
                                    V v_x31_24230 = v_field_24229;
                                    switch (heff_tag_of(v_x31_24230)) {
                                    case TAG_MkPair: {
                                      V v_x_24231 = heff_field(v_x31_24230, 0);
                                      V v_j_24232 = heff_field(v_x31_24230, 1);
                                      V v_ru_24x31_24230_24MkPair = heff_take_reuse_n(v_x31_24230, 3ULL, 2);
                                      V v_t_24233 = heff_tag_at_n(v_ru_24x31_24230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_x_24231}), v_j_24232});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24233}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24230)}});
                                    }
                                  } else {
                                    heff_drop(v_field_24229);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str15), 2)) {
                                  heff_drop_rec(v_k_240, 1);
                                  HeffT2 v_t_24234 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                  {
                                    V v_field_24236 = v_t_24234.f[1];
                                    int64_t v_tag_24235 = ((int64_t)v_t_24234.f[0]);
                                    if ((v_tag_24235 == ((int64_t)0ULL))) {
                                      V v_x31_24237 = v_field_24236;
                                      switch (heff_tag_of(v_x31_24237)) {
                                      case TAG_MkPair: {
                                        V v_x_24238 = heff_field(v_x31_24237, 0);
                                        V v_j_24239 = heff_field(v_x31_24237, 1);
                                        V v_ru_24x31_24237_24MkPair = heff_take_reuse_n(v_x31_24237, 3ULL, 2);
                                        V v_t_24240 = heff_tag_at_n(v_ru_24x31_24237_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBytes, 1, (V[]){v_x_24238}), v_j_24239});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24240}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24237)}});
                                      }
                                    } else {
                                      heff_drop(v_field_24236);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str16), 2)) {
                                    heff_drop_rec(v_k_240, 1);
                                    V v_s_24241 = heff_dup(v_z_242);
                                    V v_i_24242 = v_z_243;
                                    HeffT2 v_t_24243 = ({ V a_0 = v_s_24241; V a_1 = v_i_24242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eword_24cpr(a_0, a_1)); heff_drop(v_s_24241); r_; });
                                    V v_x3_24253;
                                    {
                                      V v_field_24245 = v_t_24243.f[1];
                                      int64_t v_tag_24244 = ((int64_t)v_t_24243.f[0]);
                                      if ((v_tag_24244 == ((int64_t)0ULL))) {
                                        V v_x31_24246 = v_field_24245;
                                        switch (heff_tag_of(v_x31_24246)) {
                                        case TAG_MkPair: {
                                          V v_x_24247 = heff_field(v_x31_24246, 0);
                                          V v_j_24248 = heff_field(v_x31_24246, 1);
                                          V v_ru_24x31_24246_24MkPair = heff_take_reuse_n(v_x31_24246, 3ULL, 2);
                                          HeffT2 v_t_24249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str17); V a_1 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str18); V a_2 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str19); V a_3 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str20); V a_4 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str21); V a_5 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str22); V a_6 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str23); V a_7 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str24); V a_8 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str25); V a_9 = v_x_24247; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(v_x_24247); heff_drop(b_10); r_; });
                                          {
                                            V v_field_24251 = v_t_24249.f[1];
                                            int64_t v_tag_24250 = ((int64_t)v_t_24249.f[0]);
                                            if ((v_tag_24250 == ((int64_t)0ULL))) {
                                              V v_x_24252 = v_field_24251;
                                              v_x3_24253 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24246_24MkPair, TAG_MkPair, 2, (V[]){v_x_24252, v_j_24248})});
                                            } else {
                                              heff_drop(v_j_24248);
                                              heff_drop_cell(v_ru_24x31_24246_24MkPair, 2);
                                              heff_drop(v_field_24251);
                                              v_x3_24253 = NTAG(TAG_Nothing);
                                            }
                                          }
                                          break;
                                        }
                                        default: heff_nomatch(v_x31_24246);
                                        }
                                      } else {
                                        heff_drop(v_field_24245);
                                        v_x3_24253 = NTAG(TAG_Nothing);
                                      }
                                    }
                                    switch (heff_tag_of(v_x3_24253)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_z_242);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_24254 = heff_field(v_x3_24253, 0);
                                      heff_take_n(v_x3_24253, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24254)) {
                                      case TAG_MkPair: {
                                        V v_x_24255 = heff_field(v_x31_24254, 0);
                                        V v_j_24256 = heff_field(v_x31_24254, 1);
                                        V v_ru_24x31_24254_24MkPair = heff_take_reuse_n(v_x31_24254, 3ULL, 2);
                                        HeffT2 v_t_24257 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24256));
                                        {
                                          V v_field_24259 = v_t_24257.f[1];
                                          int64_t v_tag_24258 = ((int64_t)v_t_24257.f[0]);
                                          if ((v_tag_24258 == ((int64_t)0ULL))) {
                                            V v_x31_24260 = v_field_24259;
                                            switch (heff_tag_of(v_x31_24260)) {
                                            case TAG_MkPair: {
                                              V v_x_24261 = heff_field(v_x31_24260, 0);
                                              V v_j_24262 = heff_field(v_x31_24260, 1);
                                              V v_ru_24x31_24260_24MkPair = heff_take_reuse_n(v_x31_24260, 3ULL, 2);
                                              V v_t_24263 = ({ V a_0 = v_x_24261; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24261); r_; });
                                              V v_x_24264 = heff_tag_at_n(v_ru_24x31_24260_24MkPair, TAG_EFixed, 2, (V[]){v_x_24255, v_t_24263});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24254_24MkPair, TAG_MkPair, 2, (V[]){v_x_24264, v_j_24262})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24260)}});
                                            }
                                          } else {
                                            heff_drop(v_x_24255);
                                            heff_drop_cell(v_ru_24x31_24254_24MkPair, 2);
                                            heff_drop(v_field_24259);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24254)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_24253)}});
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str26), 2)) {
                                      heff_drop_rec(v_k_240, 1);
                                      HeffT2 v_t_24265 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                      {
                                        V v_field_24267 = v_t_24265.f[1];
                                        int64_t v_tag_24266 = ((int64_t)v_t_24265.f[0]);
                                        if ((v_tag_24266 == ((int64_t)0ULL))) {
                                          V v_x31_24268 = v_field_24267;
                                          switch (heff_tag_of(v_x31_24268)) {
                                          case TAG_MkPair: {
                                            V v_x_24269 = heff_field(v_x31_24268, 0);
                                            V v_j_24270 = heff_field(v_x31_24268, 1);
                                            V v_ru_24x31_24268_24MkPair = heff_take_reuse_n(v_x31_24268, 3ULL, 2);
                                            double v_t_24271 = ({ V a_0 = v_x_24269; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24269); r_; });
                                            V v_x_24272 = heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24271)});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24268_24MkPair, TAG_MkPair, 2, (V[]){v_x_24272, v_j_24270})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24268)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24267);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str27), 2)) {
                                        heff_drop_rec(v_k_240, 1);
                                        heff_drop(v_z_242);
                                        V v_t_24273 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_z_243});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24273}});
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str28), 2)) {
                                          HeffT2 v_t_24274 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
                                          {
                                            V v_field_24276 = v_t_24274.f[1];
                                            int64_t v_tag_24275 = ((int64_t)v_t_24274.f[0]);
                                            if ((v_tag_24275 == ((int64_t)0ULL))) {
                                              V v_x31_24277 = v_field_24276;
                                              switch (heff_tag_of(v_x31_24277)) {
                                              case TAG_MkPair: {
                                                V v_x_24278 = heff_field(v_x31_24277, 0);
                                                V v_j_24279 = heff_field(v_x31_24277, 1);
                                                V v_ru_24x31_24277_24MkPair = heff_take_reuse_n(v_x31_24277, 3ULL, 2);
                                                V v_t_24280 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_24278));
                                                V v_x3_24281 = heff_tr(heff_call(v_t_24280, 2, (V[]){heff_dup(v_z_242), v_j_24279}));
                                                switch (heff_tag_of(v_x3_24281)) {
                                                case TAG_Nothing: {
                                                  heff_drop_rec(v_k_240, 1);
                                                  heff_drop(v_z_242);
                                                  heff_drop_cell(v_ru_24x31_24277_24MkPair, 2);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24282 = heff_field(v_x3_24281, 0);
                                                  heff_take_n(v_x3_24281, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24282)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24283 = heff_field(v_x31_24282, 0);
                                                    V v_j_24284 = heff_field(v_x31_24282, 1);
                                                    heff_take_n(v_x31_24282, 3ULL, 2);
                                                    V v_x3_24285 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_24284}));
                                                    switch (heff_tag_of(v_x3_24285)) {
                                                    case TAG_Nothing: {
                                                      heff_drop_rec(v_k_240, 1);
                                                      heff_drop(v_z_242);
                                                      heff_drop_cell(v_ru_24x31_24277_24MkPair, 2);
                                                      heff_drop(v_x_24283);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                    case TAG_Just: {
                                                      V v_x31_24286 = heff_field(v_x3_24285, 0);
                                                      heff_take_n(v_x3_24285, 1ULL, 1);
                                                      switch (heff_tag_of(v_x31_24286)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24287 = heff_field(v_x31_24286, 0);
                                                        V v_j_24288 = heff_field(v_x31_24286, 1);
                                                        heff_take_n(v_x31_24286, 3ULL, 2);
                                                        V v_x3_24289 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24288}));
                                                        switch (heff_tag_of(v_x3_24289)) {
                                                        case TAG_Nothing: {
                                                          heff_drop_cell(v_ru_24x31_24277_24MkPair, 2);
                                                          heff_drop(v_x_24283);
                                                          heff_drop(v_x_24287);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                        case TAG_Just: {
                                                          V v_x31_24290 = heff_field(v_x3_24289, 0);
                                                          heff_take_n(v_x3_24289, 1ULL, 1);
                                                          switch (heff_tag_of(v_x31_24290)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24291 = heff_field(v_x31_24290, 0);
                                                            V v_j_24292 = heff_field(v_x31_24290, 1);
                                                            heff_take_n(v_x31_24290, 3ULL, 2);
                                                            V v_t_24293 = heff_tag_at_n(v_ru_24x31_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_x_24283, v_x_24287, v_x_24291}), v_j_24292});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24293}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24290)}});
                                                          }
                                                        }
                                                        default: return ((HeffT2){{heff_nomatch(v_x3_24289)}});
                                                        }
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24286)}});
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x3_24285)}});
                                                    }
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24282)}});
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x3_24281)}});
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24277)}});
                                              }
                                            } else {
                                              heff_drop_rec(v_k_240, 1);
                                              heff_drop(v_z_242);
                                              heff_drop(v_field_24276);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str29), 2)) {
                                            HeffT2 v_t_24294 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_z_243));
                                            {
                                              V v_field_24296 = v_t_24294.f[1];
                                              int64_t v_tag_24295 = ((int64_t)v_t_24294.f[0]);
                                              if ((v_tag_24295 == ((int64_t)0ULL))) {
                                                V v_x31_24297 = v_field_24296;
                                                switch (heff_tag_of(v_x31_24297)) {
                                                case TAG_MkPair: {
                                                  V v_x_24298 = heff_field(v_x31_24297, 0);
                                                  V v_j_24299 = heff_field(v_x31_24297, 1);
                                                  V v_ru_24x31_24297_24MkPair = heff_take_reuse_n(v_x31_24297, 3ULL, 2);
                                                  V v_t_24300 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24298));
                                                  V v_x3_24301 = heff_tr(heff_call(v_t_24300, 2, (V[]){v_z_242, v_j_24299}));
                                                  switch (heff_tag_of(v_x3_24301)) {
                                                  case TAG_Nothing: {
                                                    heff_drop_cell(v_ru_24x31_24297_24MkPair, 2);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                  case TAG_Just: {
                                                    V v_x31_24302 = heff_field(v_x3_24301, 0);
                                                    V v_ru_24x3_24301_24Just = heff_take_reuse_n(v_x3_24301, 1ULL, 1);
                                                    switch (heff_tag_of(v_x31_24302)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24303 = heff_field(v_x31_24302, 0);
                                                      V v_j_24304 = heff_field(v_x31_24302, 1);
                                                      heff_take_n(v_x31_24302, 3ULL, 2);
                                                      V v_t_24305 = heff_tag_at_n(v_ru_24x31_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24301_24Just, TAG_EValues, 1, (V[]){v_x_24303}), v_j_24304});
                                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24305}});
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24302)}});
                                                    }
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x3_24301)}});
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24297)}});
                                                }
                                              } else {
                                                heff_drop_rec(v_k_240, 1);
                                                heff_drop(v_z_242);
                                                heff_drop(v_field_24296);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str30), 2)) {
                                              V v_t_24306 = (g_heff_2ecompile_2eirtext_2eckOf(v_k_240));
                                              V v_m_24307 = heff_get_n(v_t_24306, 0, 1);
                                              V v_x3_24308 = heff_tr(heff_call(v_m_24307, 2, (V[]){v_z_242, v_z_243}));
                                              switch (heff_tag_of(v_x3_24308)) {
                                              case TAG_Nothing: {
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                              case TAG_Just: {
                                                V v_x31_24309 = heff_field(v_x3_24308, 0);
                                                V v_ru_24x3_24308_24Just = heff_take_reuse_n(v_x3_24308, 1ULL, 1);
                                                switch (heff_tag_of(v_x31_24309)) {
                                                case TAG_MkPair: {
                                                  V v_x_24310 = heff_field(v_x31_24309, 0);
                                                  V v_j_24311 = heff_field(v_x31_24309, 1);
                                                  V v_ru_24x31_24309_24MkPair = heff_take_reuse_n(v_x31_24309, 3ULL, 2);
                                                  V v_t_24312 = heff_tag_at_n(v_ru_24x31_24309_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24308_24Just, TAG_EBool, 1, (V[]){v_x_24310}), v_j_24311});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24312}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24309)}});
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x3_24308)}});
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_24cpr_str31), 2)) {
                                                HeffT2 v_t_24313 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                                                {
                                                  V v_field_24315 = v_t_24313.f[1];
                                                  int64_t v_tag_24314 = ((int64_t)v_t_24313.f[0]);
                                                  if ((v_tag_24314 == ((int64_t)0ULL))) {
                                                    V v_x31_24316 = v_field_24315;
                                                    switch (heff_tag_of(v_x31_24316)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24317 = heff_field(v_x31_24316, 0);
                                                      V v_j_24318 = heff_field(v_x31_24316, 1);
                                                      V v_ru_24x31_24316_24MkPair = heff_take_reuse_n(v_x31_24316, 3ULL, 2);
                                                      V v_x3_24319 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24318}));
                                                      switch (heff_tag_of(v_x3_24319)) {
                                                      case TAG_Nothing: {
                                                        heff_drop(v_x_24317);
                                                        heff_drop_cell(v_ru_24x31_24316_24MkPair, 2);
                                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                      }
                                                      case TAG_Just: {
                                                        V v_x31_24320 = heff_field(v_x3_24319, 0);
                                                        heff_take_n(v_x3_24319, 1ULL, 1);
                                                        switch (heff_tag_of(v_x31_24320)) {
                                                        case TAG_MkPair: {
                                                          V v_x_24321 = heff_field(v_x31_24320, 0);
                                                          V v_j_24322 = heff_field(v_x31_24320, 1);
                                                          V v_ru_24x31_24320_24MkPair = heff_take_reuse_n(v_x31_24320, 3ULL, 2);
                                                          V v_t_24323 = heff_tag_at_n(v_ru_24x31_24316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24320_24MkPair, TAG_EFix, 2, (V[]){v_x_24317, v_x_24321}), v_j_24322});
                                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24323}});
                                                        }
                                                        default: return ((HeffT2){{heff_nomatch(v_x31_24320)}});
                                                        }
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x3_24319)}});
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24316)}});
                                                    }
                                                  } else {
                                                    heff_drop_rec(v_k_240, 1);
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24315);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                heff_drop_rec(v_k_240, 1);
                                                return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

static V g_heff_2ecompile_2eirtext_2etakeExpr_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2etakeExpr_st;
static V g_heff_2ecompile_2eirtext_2etakeExpr_init(void) {
  return heff_dup(heff_rfield(g_heff_2ecompile_2eirtext_2edk_get(), 0));
}
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2etakeExpr_st)) return g_heff_2ecompile_2eirtext_2etakeExpr_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2etakeExpr_val, &g_heff_2ecompile_2eirtext_2etakeExpr_st, g_heff_2ecompile_2eirtext_2etakeExpr_init);
}
Clo g_heff_2ecompile_2eirtext_2ebytesH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2ebytesH_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2ebytesH(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eirtext_2ebytesH_24cpr(v_s_240, v_i_241, v_a_242, v_b_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2ebytesH(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eirtext_2estrsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2estrsH_24dps(v_xs_243, v_rest_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_244}), heff_hole()});
      V v_cell_247 = heff_tag_at_n(v_ru_24x11_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_245}), heff_hole()});
      V v_u_248 = heff_setField(heff_dup(v_cell_246), MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_u_249 = (g_heff_2ecompile_2eirtext_2efieldsH_24dps(v_fs_243, v_rest_241, v_cell_247));
      heff_drop(v_u_249);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str12, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str13, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str14, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str15, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str16, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str17, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str18, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str19, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str20, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2enodeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enodeH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enodeH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_HS, 1, (V[]){v_x_242}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(1LL)}), v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EGlobal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EGlobal, TAG_HS, 1, (V[]){v_g_244}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(2LL)}), v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_247}), v_rest_241});
    V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_246, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2410});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(3LL)}), v_t_2411});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x1_240, 0);
    V v_args_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2413));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2413, v_rest_241));
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_f_2412}), v_t_2416});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(4LL)}), v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    V v_a_2419 = heff_field(v_x1_240, 1);
    V v_b_2420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2420}), v_rest_241});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2419}), v_t_2421});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2418}), v_t_2422});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(5LL)}), v_t_2423});
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x1_240, 0);
    V v_ts_2425 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2424));
    V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2425));
    V v_t_2428 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2425));
    V v_t_2429 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2427}), v_t_2428});
    V v_t_2430 = (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_2424, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2426}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(6LL)}), v_t_2431});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_l_2433 = heff_field(v_x1_240, 1);
    V v_sh_2434 = heff_field(v_x1_240, 2);
    V v_t_2435 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2438;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_FtFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2437 = heff_field(v_t_2435, 0);
      heff_take_n(v_t_2435, 1ULL, 1);
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str1);
        break;
      }
      case TAG_I16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str2);
        break;
      }
      case TAG_I32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str3);
        break;
      }
      case TAG_I64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str4);
        break;
      }
      case TAG_U8: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str5);
        break;
      }
      case TAG_U16: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str6);
        break;
      }
      case TAG_U32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str7);
        break;
      }
      case TAG_U64: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str8);
        break;
      }
      case TAG_F32: {
        v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str9);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str11);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2438}), v_rest_241});
    V v_t_2440 = (g_heff_2ecompile_2eirtext_2estrsH(v_sh_2434, v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2436}), v_t_2440});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_2433}), v_t_2441});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_2432}), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(7LL)}), v_t_2443});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x1_240, 0);
    V v_args_2445 = heff_field(v_x1_240, 1);
    V v_ts_2446 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2445));
    V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2446));
    V v_t_2449 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(v_rest_241, v_ts_2446));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2448}), v_t_2449});
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2445, v_t_2450));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2447}), v_t_2451});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2444}), v_t_2452});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(8LL)}), v_t_2453});
  }
  case TAG_EMatch: {
    V v_s_2454 = heff_field(v_x1_240, 0);
    V v_arms_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2456 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2455));
    V v_t_2457 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_2455, v_rest_241));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2456}), v_t_2457});
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_s_2454}), v_t_2458});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(9LL)}), v_t_2459});
  }
  case TAG_EPrim: {
    V v_p_2460 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2461 = ({ V a_0 = v_p_2460; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2460); r_; });
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EPrim, TAG_HS, 1, (V[]){v_t_2461}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(10LL)}), v_t_2462});
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_x1_240, 0);
    V v_args_2464 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2465 = ({ V a_0 = v_p_2463; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_2463); r_; });
    V v_t_2466 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2464));
    V v_t_2467 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2464, v_rest_241));
    V v_t_2468 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2466}), v_t_2467});
    V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2465}), v_t_2468});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(11LL)}), v_t_2469});
  }
  case TAG_ECall: {
    V v_g_2470 = heff_field(v_x1_240, 0);
    V v_args_2471 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2472 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2471));
    V v_t_2473 = (g_heff_2ecompile_2eirtext_2eexprsH(v_args_2471, v_rest_241));
    V v_t_2474 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2472}), v_t_2473});
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_2470}), v_t_2474});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(12LL)}), v_t_2475});
  }
  case TAG_EInt: {
    V v_i_2476 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2477 = heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_HS, 1, (V[]){heff_intShow(v_i_2476)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(13LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2478 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_nf(v_x1_240, 0ULL, 1);
    V v_t_2479 = heff_tag_at_n(v_ru_24x1_240_24EFloat, TAG_HS, 1, (V[]){heff_floatShow(v_x_2478)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(14LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2480 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_HS, 1, (V[]){v_s_2480}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(15LL)}), v_t_2481});
  }
  case TAG_EBytes: {
    V v_s_2482 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBytes = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBytes, TAG_HS, 1, (V[]){v_s_2482}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(20LL)}), v_t_2483});
  }
  case TAG_EFixed: {
    V v_w_2484 = heff_field(v_x1_240, 0);
    V v_n_2485 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2486;
    switch (heff_tag_of(v_w_2484)) {
    case TAG_I8: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str12);
      break;
    }
    case TAG_I16: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str13);
      break;
    }
    case TAG_I32: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str14);
      break;
    }
    case TAG_I64: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str15);
      break;
    }
    case TAG_U8: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str16);
      break;
    }
    case TAG_U16: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str17);
      break;
    }
    case TAG_U32: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str18);
      break;
    }
    case TAG_U64: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str19);
      break;
    }
    case TAG_F32: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str20);
      break;
    }
    default: heff_nomatch(v_w_2484);
    }
    V v_t_2487 = heff_tag_n(TAG_HS, 1, (V[]){heff_intShow(v_n_2485)});
    V v_t_2488 = heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2486}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(16LL)}), v_t_2488});
  }
  case TAG_EFloat32: {
    V v_x_2489 = heff_tget_v(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat32 = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2490 = heff_tag_at_n(v_ru_24x1_240_24EFloat32, TAG_HS, 1, (V[]){heff_floatShow(v_x_2489)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(17LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(18LL)}), v_rest_241});
  }
  case TAG_EBool: {
    V v_c_2491 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBool = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EBool, TAG_HC, 1, (V[]){v_c_2491}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(21LL)}), v_t_2492});
  }
  case TAG_ESet: {
    V v_xs_2493 = heff_field(v_x1_240, 0);
    V v_a_2494 = heff_field(v_x1_240, 1);
    V v_b_2495 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2496 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2493));
    V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2495}), v_rest_241});
    V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2494}), v_t_2497});
    V v_t_2499 = (g_heff_2ecompile_2eirtext_2estrsH(v_xs_2493, v_t_2498));
    V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2496}), v_t_2499});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(22LL)}), v_t_24100});
  }
  case TAG_EValues: {
    V v_es_24101 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EValues = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24102 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_24101));
    V v_t_24103 = (g_heff_2ecompile_2eirtext_2eexprsH(v_es_24101, v_rest_241));
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EValues, TAG_HN, 1, (V[]){v_t_24102}), v_t_24103});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(23LL)}), v_t_24104});
  }
  case TAG_EFix: {
    V v_f_24105 = heff_field(v_x1_240, 0);
    V v_b_24106 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_24107 = heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_24106}), v_rest_241});
    V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_f_24105}), v_t_24107});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(19LL)}), v_t_24108});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enodeH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(V v_rest_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_rest_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str1);
        break;
      }
      case TAG_I16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str2);
        break;
      }
      case TAG_I32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str3);
        break;
      }
      case TAG_I64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str4);
        break;
      }
      case TAG_U8: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str5);
        break;
      }
      case TAG_U16: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str6);
        break;
      }
      case TAG_U32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str7);
        break;
      }
      case TAG_U64: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str8);
        break;
      }
      case TAG_F32: {
        v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_245 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_245}), heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(v_rest_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192(a[0], a[1]);
}