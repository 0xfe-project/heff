// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_heff 9694020
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str2, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str3, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str4, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(V v_x_240, V v_hd_241, V v_k_242, V v_x_243) {
top: ;
  V v_path_244 = v_x_240;
  V v_x2_247;
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    heff_take_n(v_x_243, 0ULL, 1);
    v_x2_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_246 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Right = heff_take_reuse_n(v_x_243, 1ULL, 1);
    v_x2_247 = heff_tag_at_n(v_ru_24x_243_24Right, TAG_Just, 1, (V[]){v_y_246});
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_t_2422;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_2422 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str0), v_path_244)});
    break;
  }
  case TAG_Just: {
    V v_src_248 = heff_field(v_x2_247, 0);
    V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
    HeffT2 v_t_249 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_src_248)));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2411;
        V v_t_2413 = ({ V a_0 = v_path_244; V a_1 = v_src_248; V a_2 = v_p_2412; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_248); r_; });
        v_t_2422 = heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str1), v_t_2413)});
      } else {
        V v_x_2414 = v_field_2411;
        HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2414); r_; });
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_p_2418 = v_field_2417;
            V v_t_2419 = ({ V a_0 = v_path_244; V a_1 = v_src_248; V a_2 = v_p_2418; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_248); r_; });
            v_t_2422 = heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str2), v_t_2419)});
          } else {
            heff_drop(v_path_244);
            heff_drop(v_src_248);
            V v_p_2420 = v_field_2417;
            V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str3), heff_get_n(v_p_2420, 1, 4));
            v_t_2422 = heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Right, 1, (V[]){v_t_2421});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Left: {
    V v_why_2423 = heff_field(v_t_2422, 0);
    V v_ru_24t_2422_24Left = heff_take_reuse_n(v_t_2422, 1ULL, 1);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str4), v_why_2423), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str5));
    V v_t_2425 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_at_n(v_ru_24t_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_line_2438 = heff_field(v_t_2422, 0);
    V v_ru_24t_2422_24Right = heff_take_reuse_n(v_t_2422, 1ULL, 1);
    V v_t_2439 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2438, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_str6)), NTAG(TAG_MkUnit)});
    V v_t_2440 = heff_tag_at_n(v_ru_24t_2422_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_t_2422);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_lam0(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_241, v_k_242));
}