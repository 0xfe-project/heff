// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_ECall 24489
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_Flagged 28540
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkBinding 51651
#define TAG_MkCArm 24694
#define TAG_PatVar 49363
#define TAG_Picked 5619
#define TAG_Plain 3036
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetPath 11095
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define TAG_Typed 36072
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_detail 611917692
#define LBL_e 319
#define LBL_end 310101
#define LBL_input 301716452
#define LBL_key 315609
#define LBL_l 326
#define LBL_label 304085774
#define LBL_looser 850054335
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_options 1129866465
#define LBL_part 9928890
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_t 334
#define LBL_text 10052084
#define LBL_tighter 1059982480
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2edefun_2egroupOf(V, V, V, V);
V g_heff_2ecompile_2edefun_2egroupOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2egroupOf_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(V);
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2emonadic_2evalue(V);
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2evalue_clo;
V g_heff_2ecompile_2escalars_2ecallersRw(V, V);
V g_heff_2ecompile_2escalars_2ecallersRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallersRw_clo;
V g_heff_2ecompile_2escalars_2ecallsLoopW(V, V);
V g_heff_2ecompile_2escalars_2ecallsLoopW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallsLoopW_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2eelab_2eclauses_2ebare(V);
V g_heff_2eelab_2eclauses_2ebare_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebare_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2esurface_2epatTags(V, V);
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTags_clo;
V g_list_2eall_24s1139804755x744724287(V);
V g_list_2eall_24s1139804755x744724287_entry(V self, V *a);
extern Clo g_list_2eall_24s1139804755x744724287_clo;
V g_list_2eall_24s1411948616x47436528(V, V, V);
V g_list_2eall_24s1411948616x47436528_entry(V self, V *a);
extern Clo g_list_2eall_24s1411948616x47436528_clo;
V g_list_2eall_24s2116272255x866448265(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s2116272255x866448265_entry(V self, V *a);
extern Clo g_list_2eall_24s2116272255x866448265_clo;
V g_list_2eany_24s108509638x1972721376(V, V);
V g_list_2eany_24s108509638x1972721376_entry(V self, V *a);
extern Clo g_list_2eany_24s108509638x1972721376_clo;
V g_list_2eany_24s1119291297x466217959(V, V);
V g_list_2eany_24s1119291297x466217959_entry(V self, V *a);
extern Clo g_list_2eany_24s1119291297x466217959_clo;
V g_list_2eany_24s1678884672x1211895143(V, V);
V g_list_2eany_24s1678884672x1211895143_entry(V self, V *a);
extern Clo g_list_2eany_24s1678884672x1211895143_clo;
V g_list_2ecollapse(V, V, V);
V g_list_2ecollapse_entry(V self, V *a);
extern Clo g_list_2ecollapse_clo;
V g_list_2ecollapse_24s945166865x820780714(V, V);
V g_list_2ecollapse_24s945166865x820780714_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s945166865x820780714_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_list_2efind_24s582717128x15493447_24cpr(V, V);
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f547094838x440994078(V, V, V);
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a);
extern Clo g_list_2efoldl_24f547094838x440994078_clo;
V g_list_2efoldl_24f603879485x1484249893(V, V, V, V);
V g_list_2efoldl_24f603879485x1484249893_entry(V self, V *a);
extern Clo g_list_2efoldl_24f603879485x1484249893_clo;
V g_list_2efoldl_24s1007625675x912768453(V, V, V);
V g_list_2efoldl_24s1007625675x912768453_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1007625675x912768453_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1413159824x1120446397(V, V);
V g_list_2efoldl_24s1413159824x1120446397_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1413159824x1120446397_clo;
V g_list_2efoldl_24s1841827593x957980306(V, V, V, V);
V g_list_2efoldl_24s1841827593x957980306_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1841827593x957980306_clo;
V g_list_2efoldl_24s2092021924x904081891(V, V);
V g_list_2efoldl_24s2092021924x904081891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2092021924x904081891_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
HeffT2 g_list_2eindexWhere_2eindexFrom_240_24cpr(V, V, V);
V g_list_2ekeepIf_24s2034497759x755284100(V, V);
V g_list_2ekeepIf_24s2034497759x755284100_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2034497759x755284100_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1511070573x340395911_24dps(V, V, V, V);
V g_list_2emap_24f1511070573x340395911_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1511070573x340395911_24dps_clo;
V g_list_2emap_24f1651437062x1594169608(V, V);
V g_list_2emap_24f1651437062x1594169608_entry(V self, V *a);
extern Clo g_list_2emap_24f1651437062x1594169608_clo;
V g_list_2emap_24f1651437062x1594169608_24dps(V, V, V);
V g_list_2emap_24f1651437062x1594169608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1651437062x1594169608_24dps_clo;
V g_list_2emap_24f1749649202x1754028860_24dps(V, V, V);
V g_list_2emap_24f1749649202x1754028860_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_24dps_clo;
V g_list_2emap_24f869471183x993026796(V, V, V);
V g_list_2emap_24f869471183x993026796_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s1132197644x1537385180(V, V);
V g_list_2emap_24s1132197644x1537385180_entry(V self, V *a);
extern Clo g_list_2emap_24s1132197644x1537385180_clo;
V g_list_2emap_24s1132197644x1537385180_24dps(V, V, V);
V g_list_2emap_24s1132197644x1537385180_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1132197644x1537385180_24dps_clo;
V g_list_2emap_24s1237964173x885934184(V);
V g_list_2emap_24s1237964173x885934184_entry(V self, V *a);
extern Clo g_list_2emap_24s1237964173x885934184_clo;
V g_list_2emap_24s1237964173x885934184_24dps(V, V);
V g_list_2emap_24s1237964173x885934184_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1237964173x885934184_24dps_clo;
V g_list_2emap_24s1238159332x1367432882(V);
V g_list_2emap_24s1238159332x1367432882_entry(V self, V *a);
extern Clo g_list_2emap_24s1238159332x1367432882_clo;
V g_list_2emap_24s1238159332x1367432882_24dps(V, V);
V g_list_2emap_24s1238159332x1367432882_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1238159332x1367432882_24dps_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1492759219x1917596721_24dps(V, V, V);
V g_list_2emap_24s1492759219x1917596721_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_24dps_clo;
V g_list_2emap_24s1613211967x1923010103_24dps(V, V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_24dps_clo;
V g_list_2emap_24s1694755346x1599566812_24dps(V, V, V);
V g_list_2emap_24s1694755346x1599566812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1694755346x1599566812_24dps_clo;
V g_list_2emap_24s1722943925x2063725971(V);
V g_list_2emap_24s1722943925x2063725971_entry(V self, V *a);
extern Clo g_list_2emap_24s1722943925x2063725971_clo;
V g_list_2emap_24s1722943925x2063725971_24dps(V, V);
V g_list_2emap_24s1722943925x2063725971_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1722943925x2063725971_24dps_clo;
V g_list_2emap_24s1915587473x866090925(V, V);
V g_list_2emap_24s1915587473x866090925_entry(V self, V *a);
extern Clo g_list_2emap_24s1915587473x866090925_clo;
V g_list_2emap_24s1915587473x866090925_24dps(V, V, V);
V g_list_2emap_24s1915587473x866090925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1915587473x866090925_24dps_clo;
V g_list_2emap_24s2010608108x1221393166_24dps(V, V);
V g_list_2emap_24s2010608108x1221393166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_24dps_clo;
V g_list_2emap_24s2051429168x672290949_24dps(V, V);
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_24dps_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s2133060086x110881273_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s2133060086x110881273_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2133060086x110881273_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s354283597x484250159_24dps(V, V, V);
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s419081849x11460228_24dps(V, V);
V g_list_2emap_24s419081849x11460228_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s419081849x11460228_24dps_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s4199228x1154005405_24tok2(V, V);
V g_list_2emap_24s4199228x1154005405_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24tok2_clo;
V g_list_2emap_24s456574265x331130481_24dps(V, V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_24dps_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s72189608x1424346484_24dps(V, V, V, V, V);
V g_list_2emap_24s72189608x1424346484_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s72189608x1424346484_24dps_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s890213172x1049425163(V);
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_clo;
V g_list_2emap_24s890213172x1049425163_24dps(V, V);
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_24dps_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24s942566919x1152393003_24dps(V, V, V);
V g_list_2emap_24s942566919x1152393003_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s991540778x2011810329(V, V);
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
HeffT2 g_std_2ecli_2einteractive_2eflagSlot_24cpr(V);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
Clo g_list_2ecollapse_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_entry, 3, 0};

V g_list_2ecollapse(V v_le_240, V v_run_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_run_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_below_246 = heff_field(v_x31_243, 1);
      V v_t_247 = (g_list_2emerge(heff_dup(v_le_240), heff_dup(v_below_246), v_run_241));
      V t_0 = v_le_240;
      V t_1 = v_t_247;
      V t_2 = v_rest_244;
      v_le_240 = t_0;
      v_run_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2ecollapse_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ecollapse(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1238159332x1367432882_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1238159332x1367432882_entry, 1, 0};

V g_list_2emap_24s1238159332x1367432882(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkBinding: {
        V v_a_247 = heff_field(v_a_243, 2);
        heff_take_n(v_a_243, 4ULL, 3);
        v_t_248 = v_a_247;
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1238159332x1367432882_24dps(v_xs_242, v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1238159332x1367432882_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1238159332x1367432882(a[0]);
}
Clo g_list_2emap_24s1237964173x885934184_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1237964173x885934184_entry, 1, 0};

V g_list_2emap_24s1237964173x885934184(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_245}), v_t_248});
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1237964173x885934184_24dps(v_xs_242, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1237964173x885934184_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1237964173x885934184(a[0]);
}
Clo g_list_2emap_24s942566919x1152393003_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s942566919x1152393003_entry, 2, 0};

V g_list_2emap_24s942566919x1152393003(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eargOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s942566919x1152393003_24dps(v_lit_240, v_xs_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s942566919x1152393003(a[0], a[1]);
}
Clo g_list_2emap_24s2051429168x672290949_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2051429168x672290949_24dps_entry, 2, 0};

V g_list_2emap_24s2051429168x672290949_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2441;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_ExplicitParam: {
        V v_x_247 = heff_field(v_x21_245, 0);
        V v_xsp_248 = heff_field(v_x21_245, 1);
        V v_t_249 = heff_field(v_x21_245, 2);
        V v_ru_24x21_245_24ExplicitParam = heff_take_reuse_n(v_x21_245, 7ULL, 3);
        HeffT3 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_249));
        {
          V v_field_2412 = v_t_2410.f[1];
          V v_field_2413 = v_t_2410.f[2];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          V v_t_2423;
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_c_2414 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2412, v_field_2413});
            V v_t_2417;
            switch (heff_tag_of(v_c_2414)) {
            case TAG_At: {
              V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
              v_t_2417 = v_s_2416;
              break;
            }
            default: heff_nomatch(v_c_2414);
            }
            v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
          } else {
            if ((v_tag_2411 == ((int64_t)1ULL))) {
              V v_i_2418 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2412, v_field_2413});
              V v_t_2421;
              switch (heff_tag_of(v_i_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_i_2418);
              }
              v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2418}), v_t_2421});
            } else {
              V v_t_2422 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2412, v_field_2413});
              v_t_2423 = v_t_2422;
            }
          }
          v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_245_24ExplicitParam, TAG_ExplicitParam, 3, 3ULL, (V[]){v_x_247, v_xsp_248, v_t_2423}), v_sp_246});
        }
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2424 = heff_field(v_x21_245, 0);
        V v_xsp_2425 = heff_field(v_x21_245, 1);
        V v_t_2426 = heff_field(v_x21_245, 2);
        V v_ru_24x21_245_24ImplicitParam = heff_take_reuse_n(v_x21_245, 7ULL, 3);
        HeffT3 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2426));
        {
          V v_field_2429 = v_t_2427.f[1];
          V v_field_2430 = v_t_2427.f[2];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          V v_t_2440;
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_c_2431 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2429, v_field_2430});
            V v_t_2434;
            switch (heff_tag_of(v_c_2431)) {
            case TAG_At: {
              V v_s_2433 = heff_dup(heff_field(v_c_2431, 1));
              v_t_2434 = v_s_2433;
              break;
            }
            default: heff_nomatch(v_c_2431);
            }
            v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2431}), v_t_2434});
          } else {
            if ((v_tag_2428 == ((int64_t)1ULL))) {
              V v_i_2435 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2429, v_field_2430});
              V v_t_2438;
              switch (heff_tag_of(v_i_2435)) {
              case TAG_At: {
                V v_s_2437 = heff_dup(heff_field(v_i_2435, 1));
                v_t_2438 = v_s_2437;
                break;
              }
              default: heff_nomatch(v_i_2435);
              }
              v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2435}), v_t_2438});
            } else {
              V v_t_2439 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2429, v_field_2430});
              v_t_2440 = v_t_2439;
            }
          }
          v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_245_24ImplicitParam, TAG_ImplicitParam, 3, 3ULL, (V[]){v_x_2424, v_xsp_2425, v_t_2440}), v_sp_246});
        }
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2442 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2441, heff_hole()});
    V v_u_2443 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2442);
    V t_0 = v_xs_243;
    V t_1 = v_u_2443;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2051429168x672290949_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s366989016x166432442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_24dps_entry, 2, 0};

V g_list_2emap_24s366989016x166432442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_re_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, 1ULL, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2414);
    V t_0 = v_xs_243;
    V t_1 = v_u_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s366989016x166432442_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s474585387x1072098790_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_24dps_entry, 2, 0};

V g_list_2emap_24s474585387x1072098790_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ExplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          V v_ru_24a_248_24At = heff_take_reuse_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_248_24At, v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_re_n(v_ru_24a_244_24ExplicitParam, TAG_ExplicitParam, 3, 3ULL, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_a_2414 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ImplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2417;
        switch (heff_tag_of(v_a_2414)) {
        case TAG_At: {
          V v_a_2415 = heff_field(v_a_2414, 0);
          V v_a_2416 = heff_field(v_a_2414, 1);
          V v_ru_24a_2414_24At = heff_take_reuse_n(v_a_2414, 3ULL, 2);
          v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2414_24At, v_a_2416, v_a_2415));
          break;
        }
        default: heff_nomatch(v_a_2414);
        }
        v_t_2418 = heff_tag_re_n(v_ru_24a_244_24ImplicitParam, TAG_ImplicitParam, 3, 3ULL, (V[]){v_a_2412, v_a_2413, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2420);
    V t_0 = v_xs_243;
    V t_1 = v_u_2421;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s474585387x1072098790_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1413159824x1120446397_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1413159824x1120446397_entry, 2, 0};

V g_list_2efoldl_24s1413159824x1120446397(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2esyntax_2esurface_2epatTags(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1413159824x1120446397_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1413159824x1120446397(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1492759219x1917596721_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1492759219x1917596721_24dps_entry, 3, 0};

V g_list_2emap_24s1492759219x1917596721_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_lit_240; V a_1 = v_x_243; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1492759219x1917596721_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1492759219x1917596721_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s419081849x11460228_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s419081849x11460228_24dps_entry, 2, 0};

V g_list_2emap_24s419081849x11460228_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_t_249));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_2410}), heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
    V t_0 = v_xs_243;
    V t_1 = v_u_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s419081849x11460228_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s419081849x11460228_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str1, 7, "Float64");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str2, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str3, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str4, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str5, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str6, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str7, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str8, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str9, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2010608108x1221393166_24dps_str10, 7, "Float32");
Clo g_list_2emap_24s2010608108x1221393166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2010608108x1221393166_24dps_entry, 2, 0};

V g_list_2emap_24s2010608108x1221393166_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_244 = v_x_242;
    V v_t_249;
    if (heff_strEq_c_lent(v_x_244, ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str0), 2)) {
      heff_drop(v_x_244);
      v_t_249 = NTAG(TAG_RepV);
    } else {
      if (heff_strEq_c_lent(v_x_244, ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str1), 2)) {
        heff_drop(v_x_244);
        v_t_249 = NTAG(TAG_RepF64);
      } else {
        HeffT2 v_t_245 = ({ V a_0 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str2); V a_1 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str3); V a_2 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str4); V a_3 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str5); V a_4 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str6); V a_5 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str7); V a_6 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str8); V a_7 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str9); V a_8 = ((V)&g_list_2emap_24s2010608108x1221393166_24dps_str10); V a_9 = v_x_244; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(v_x_244); heff_drop(b_10); r_; });
        {
          V v_field_247 = v_t_245.f[1];
          int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
          if ((v_tag_246 == ((int64_t)0ULL))) {
            V v_x_248 = v_field_247;
            v_t_249 = heff_tag_n(TAG_RepFix, 1, (V[]){v_x_248});
          } else {
            heff_drop(v_field_247);
            v_t_249 = NTAG(TAG_RepV);
          }
        }
      }
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2410);
    V t_0 = v_xs_243;
    V t_1 = v_u_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2010608108x1221393166_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2010608108x1221393166_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1678884672x1211895143_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1678884672x1211895143_entry, 2, 0};

V g_list_2eany_24s1678884672x1211895143(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2427;
    switch (heff_tag_of(v_x_242)) {
    case TAG_SVar: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_2427 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_244, 0));
      break;
    }
    case TAG_SGlobal: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SInt: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SFloat: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SStr: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SBytes: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SFixed: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SFloat32: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrimFn: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SLam: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_STag: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SRec: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SProj: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2427);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1678884672x1211895143_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1678884672x1211895143(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2092021924x904081891_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2092021924x904081891_entry, 2, 0};

V g_list_2efoldl_24s2092021924x904081891(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_t_244 = heff_field(v_x_242, 0);
      V v_a2_245 = heff_field(v_x_242, 1);
      V v_a3_246 = heff_field(v_x_242, 2);
      V v_a6_249 = heff_field(v_x_242, 5);
      heff_take_n(v_x_242, 39ULL, 8);
      switch (heff_tag_of(v_a2_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_a3_246)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_a6_249)) {
          case TAG_TakeNone: {
            v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, v_z_240});
            break;
          }
          case TAG_TakeN: {
            heff_take_n(v_a6_249, 0ULL, 3);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_t_244);
            v_t_2423 = v_z_240;
            break;
          }
          case TAG_TakeKeep: {
            heff_take_n(v_a6_249, 0ULL, 4);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_t_244);
            v_t_2423 = v_z_240;
            break;
          }
          default: heff_nomatch(v_a6_249);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_a3_246, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_a6_249);
          v_t_2423 = v_z_240;
          break;
        }
        default: heff_nomatch(v_a3_246);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_a2_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_t_244);
        heff_drop(v_a3_246);
        heff_drop(v_a6_249);
        v_t_2423 = v_z_240;
        break;
      }
      default: heff_nomatch(v_a2_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2423;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2092021924x904081891_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2092021924x904081891(a[0], a[1]);
}
Clo g_list_2efoldl_24s1007625675x912768453_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1007625675x912768453_entry, 3, 0};

V g_list_2efoldl_24s1007625675x912768453(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_z_241, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2410;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_z_241, 1));
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2413;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_z_241, 0);
      heff_take_n(v_z_241, 1ULL, 2);
      v_t_2413 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2414 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2410, heff_get_n(v_x_243, 0, 3), v_t_2413));
    V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){heff_intAdd_lent(v_t_247, v_lit_240, 1), v_t_2414});
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1007625675x912768453_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1007625675x912768453(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s72189608x1424346484_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s72189608x1424346484_24dps_entry, 5, 0};

V g_list_2emap_24s72189608x1424346484_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2edefun_2egroupOf(v_lit_240, v_lit_241, v_lit_242, v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s72189608x1424346484_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2emap_24s72189608x1424346484_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2efoldl_24s978059622x523571930_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s978059622x523571930_entry, 2, 0};

V g_list_2efoldl_24s978059622x523571930(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s978059622x523571930(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s2116272255x866448265_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s2116272255x866448265_entry, 12, 0};

V g_list_2eall_24s2116272255x866448265(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_l_2414 = heff_dup(heff_rfield(v_x_2412, 0));
    V v_t_2415 = heff_dup(heff_rfield(v_x_2412, 2));
    if (!heff_strEq_c(heff_dup(v_l_2414), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop(v_l_2414);
      heff_drop(v_t_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    } else {
      heff_drop(v_l_2414);
      V v_t_2416 = v_t_2415;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_FtFloat: {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        int64_t t_10 = v_lit_2410;
        V t_11 = v_xs_2413;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_x2_2411 = t_11;
        goto top;
      }
      case TAG_FtFixed: {
        V v_a_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        V v_t_2418;
        switch (heff_tag_of(v_a_2417)) {
        case TAG_I8: {
          v_t_2418 = heff_dup(v_lit_241);
          break;
        }
        case TAG_I16: {
          v_t_2418 = heff_dup(v_lit_242);
          break;
        }
        case TAG_I32: {
          v_t_2418 = heff_dup(v_lit_243);
          break;
        }
        case TAG_I64: {
          v_t_2418 = heff_dup(v_lit_244);
          break;
        }
        case TAG_U8: {
          v_t_2418 = heff_dup(v_lit_245);
          break;
        }
        case TAG_U16: {
          v_t_2418 = heff_dup(v_lit_246);
          break;
        }
        case TAG_U32: {
          v_t_2418 = heff_dup(v_lit_247);
          break;
        }
        case TAG_U64: {
          v_t_2418 = heff_dup(v_lit_248);
          break;
        }
        case TAG_F32: {
          v_t_2418 = heff_dup(v_lit_249);
          break;
        }
        default: heff_nomatch(v_a_2417);
        }
        if ((heff_unbox_word(v_t_2418) == v_lit_2410)) {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_lit_245;
          V t_6 = v_lit_246;
          V t_7 = v_lit_247;
          V t_8 = v_lit_248;
          V t_9 = v_lit_249;
          int64_t t_10 = v_lit_2410;
          V t_11 = v_xs_2413;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_lit_245 = t_5;
          v_lit_246 = t_6;
          v_lit_247 = t_7;
          v_lit_248 = t_8;
          v_lit_249 = t_9;
          v_lit_2410 = t_10;
          v_x2_2411 = t_11;
          goto top;
        } else {
          heff_drop_rec(v_lit_240, 3);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          heff_drop(v_lit_243);
          heff_drop(v_lit_244);
          heff_drop(v_lit_245);
          heff_drop(v_lit_246);
          heff_drop(v_lit_247);
          heff_drop(v_lit_248);
          heff_drop(v_lit_249);
          return NTAG(TAG_False);
        }
      }
      case TAG_FtOther: {
        heff_drop_rec(v_lit_240, 3);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_lit_249);
        return NTAG(TAG_False);
      }
      case TAG_FtAny: {
        heff_drop_rec(v_lit_240, 3);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_lit_249);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2eall_24s2116272255x866448265_entry(V self, V *a) {
  (void)self;
  V a11 = a[11]; V r = g_list_2eall_24s2116272255x866448265(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a11); heff_drop(a11); return r;
}
Clo g_list_2eall_24s1139804755x744724287_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1139804755x744724287_entry, 1, 0};

V g_list_2eall_24s1139804755x744724287(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2emonadic_2evalue(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1139804755x744724287_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1139804755x744724287(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1915587473x866090925_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1915587473x866090925_entry, 2, 0};

V g_list_2emap_24s1915587473x866090925(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_244 = heff_dup(v_lit_240);
    V v_d_245 = v_x_242;
    V v_t_246 = heff_dup(heff_rfield(v_d_245, 2));
    V v_t_2420;
    switch (heff_tag_of(v_t_246)) {
    case TAG_ECall: {
      V v_g_247 = heff_field(v_t_246, 0);
      V v_args_248 = heff_field(v_t_246, 1);
      V v_ru_24t_246_24ECall = heff_take_reuse_n(v_t_246, 3ULL, 2);
      HeffT2 v_t_249 = ({ V a_0 = v_m_244; V a_1 = v_g_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_g_247); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop(v_args_248);
          heff_drop_cell(v_ru_24t_246_24ECall, 2);
          V v_x_2412 = v_field_2411;
          heff_drop(v_x_2412);
          V v_body_2413 = (g_heff_2ecompile_2escalars_2ecallersRw(v_m_244, heff_take_field(v_d_245, 2)));
          v_t_2420 = ({ V rv_2 = v_body_2413; V rr_ = heff_rec_reuse_nf(v_d_245, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        } else {
          heff_drop(v_field_2411);
          V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24t_246_24ECall, v_args_248, NTAG(TAG_Nil)));
          V v_t_2415 = (g_heff_2ecompile_2escalars_2ecallsLoopW(v_m_244, v_t_2414));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            V v_body_2416 = (g_heff_2ecompile_2escalars_2ecallersRw(v_m_244, heff_take_field(v_d_245, 2)));
            v_t_2420 = ({ V rv_2 = v_body_2416; V rr_ = heff_rec_reuse_nf(v_d_245, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          } else {
            heff_drop(v_m_244);
            heff_drop(v_t_2415);
            v_t_2420 = v_d_245;
          }
        }
      }
      break;
    }
    default: {
      V v_t_2417 = (g_heff_2ecompile_2eir_2epartsOnto(v_t_246, NTAG(TAG_Nil)));
      V v_t_2418 = (g_heff_2ecompile_2escalars_2ecallsLoopW(v_m_244, v_t_2417));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        V v_body_2419 = (g_heff_2ecompile_2escalars_2ecallersRw(v_m_244, heff_take_field(v_d_245, 2)));
        v_t_2420 = ({ V rv_2 = v_body_2419; V rr_ = heff_rec_reuse_nf(v_d_245, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      } else {
        heff_drop(v_m_244);
        heff_drop(v_t_2418);
        v_t_2420 = v_d_245;
      }
      break;
    }
    }
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = (g_list_2emap_24s1915587473x866090925_24dps(v_lit_240, v_xs_243, v_cell_2421));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1915587473x866090925_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1915587473x866090925(a[0], a[1]);
}
Clo g_list_2emap_24s456574265x331130481_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456574265x331130481_24dps_entry, 6, 0};

V g_list_2emap_24s456574265x331130481_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_prelude_2esplit_2esplitFrom_240(v_x_246, v_lit_240, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_246, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_248));
    V v_t_2412;
    switch (heff_tag_of(v_a_249)) {
    case TAG_Nil: {
      v_t_2412 = v_x_246;
      break;
    }
    case TAG_Cons: {
      V v_a_2410 = heff_field(v_a_249, 0);
      heff_take_n(v_a_249, 1ULL, 2);
      heff_drop(v_x_246);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_a_249);
    }
    V v_t_2413 = (g_heff_2ecompile_2eemit_2esafe(v_t_2412));
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_u_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s456574265x331130481_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V r = g_list_2emap_24s456574265x331130481_24dps(a0, a[1], a2, a3, a[4], a5); heff_drop(a0); heff_drop(a2); heff_drop(a3); heff_drop(a5); return r;
}
HEFF_LIT(g_list_2emap_24s732475005x1616712052_str0, 13, "export const ");
HEFF_LIT(g_list_2emap_24s732475005x1616712052_str1, 1, " ");
Clo g_list_2emap_24s732475005x1616712052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_entry, 1, 0};

V g_list_2emap_24s732475005x1616712052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_243 = v_x_241;
    V v_t_248;
    if (heff_strEq_c(heff_strSlice_lent(v_l_243, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24s732475005x1616712052_str0))) {
      V v_t_244 = heff_strSlice_lent(v_l_243, MK_INT(13LL), heff_strLength_lent(v_l_243, 0), 6);
      V v_j_245 = heff_strFind(((V)&g_list_2emap_24s732475005x1616712052_str1), v_t_244, MK_INT(0LL));
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        V v_t_246 = heff_strSlice(heff_dup(v_l_243), MK_INT(13LL), heff_strLength(v_l_243));
        v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
      } else {
        V v_t_247 = heff_strSlice(v_l_243, MK_INT(13LL), heff_intAdd(MK_INT(13LL), v_j_245));
        v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
      }
    } else {
      heff_drop(v_l_243);
      v_t_248 = NTAG(TAG_Nothing);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s732475005x1616712052_24dps(v_xs_242, v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052(a[0]);
}
Clo g_list_2emap_24s1613211967x1923010103_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1613211967x1923010103_24dps_entry, 5, 0};

V g_list_2emap_24s1613211967x1923010103_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_x_245)));
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_lit_241)), heff_intShow(v_x_245));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2410 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1613211967x1923010103_24dps_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2emap_24s1613211967x1923010103_24dps(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2emap_24s2133060086x110881273_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2133060086x110881273_24dps_entry, 8, 0};

V g_list_2emap_24s2133060086x110881273_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_dup(heff_field(v_x_248, 0));
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2417 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2413));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, heff_dup(v_lit_245)), heff_intShow(v_t_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2419);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_u_2420;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s2133060086x110881273_24dps_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_list_2emap_24s2133060086x110881273_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str0, 2, "__");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str1, 2, "__");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str2, 4, "LBL_");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str4, 2, ", ");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str5, 22, "static uint32_t shape_");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str6, 6, "[] = {");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_24dps_str7, 2, "};");
Clo g_list_2emap_24s2073083146x1445066245_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_24dps_entry, 2, 0};

V g_list_2emap_24s2073083146x1445066245_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = v_x_242;
    V v_t_245 = ({ V a_0 = v_name_244; V b_1 = ((V)&g_list_2emap_24s2073083146x1445066245_24dps_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s2073083146x1445066245_24dps_str1), v_name_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_246 = (g_list_2emap_24f869471183x993026796(((V)&g_list_2emap_24s2073083146x1445066245_24dps_str2), MK_INT(0LL), v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_list_2emap_24s2073083146x1445066245_24dps_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_list_2emap_24s2073083146x1445066245_24dps_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2073083146x1445066245_24dps_str5), v_name_244), ((V)&g_list_2emap_24s2073083146x1445066245_24dps_str6));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_t_249), ((V)&g_list_2emap_24s2073083146x1445066245_24dps_str7));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2412);
    V t_0 = v_xs_243;
    V t_1 = v_u_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2073083146x1445066245_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1722943925x2063725971_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1722943925x2063725971_entry, 1, 0};

V g_list_2emap_24s1722943925x2063725971(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eclauses_2ebare(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1722943925x2063725971_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1722943925x2063725971_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1722943925x2063725971(a[0]);
}
Clo g_list_2emap_24s1694755346x1599566812_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1694755346x1599566812_24dps_entry, 3, 0};

V g_list_2emap_24s1694755346x1599566812_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_key_246 = heff_get_n(v_x_243, 1, 2);
    V v_t_247 = heff_rec_n(3, shape_name__key__module, (V[]){v_name_245, v_key_246, heff_dup(heff_rfield(v_lit_240, 0))});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_249;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1694755346x1599566812_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1694755346x1599566812_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1119291297x466217959_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1119291297x466217959_entry, 2, 0};

V g_list_2eany_24s1119291297x466217959(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_start_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_end_245 = heff_dup(heff_rfield(v_x_242, 1));
    if ((heff_intEq_c(heff_dup(v_start_244), heff_dup(heff_rfield(v_lit_240, 0))) && heff_intEq_c(heff_dup(v_end_245), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1119291297x466217959_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1119291297x466217959(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s108509638x1972721376_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s108509638x1972721376_entry, 2, 0};

V g_list_2eany_24s108509638x1972721376(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s108509638x1972721376_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s108509638x1972721376(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s582717128x15493447_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1841827593x957980306_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1841827593x957980306_entry, 4, 0};

V g_list_2efoldl_24s1841827593x957980306(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_tighter_246 = heff_take_field(v_x_244, 0);
    V v_looser_247 = heff_get_n(v_x_244, 1, 2);
    V v_a_248 = v_tighter_246;
    V v_a_249 = v_looser_247;
    V v_t_2410 = heff_intShow(heff_strLength_lent(v_a_248, 0));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_lit_240)), v_a_248);
    V v_t_2412 = heff_intShow(heff_strLength_lent(v_a_249, 0));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, heff_dup(v_lit_241)), v_a_249);
    V v_t_2414 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_z_242})});
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2414;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1841827593x957980306_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1841827593x957980306(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eall_24s1411948616x47436528_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1411948616x47436528_entry, 3, 0};

V g_list_2eall_24s1411948616x47436528(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if ((heff_intLe_c_lent(v_lit_240, v_x_243, 0) && heff_intLe_c_lent(v_x_243, v_lit_241, 0))) {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s1411948616x47436528_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s1411948616x47436528(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s890213172x1049425163_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_entry, 1, 0};

V g_list_2emap_24s890213172x1049425163(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s890213172x1049425163_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163(a[0]);
}
Clo g_list_2emap_24s890213172x1049425163_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_24dps_entry, 2, 0};

V g_list_2emap_24s890213172x1049425163_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s890213172x1049425163_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ecollapse_24s945166865x820780714_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s945166865x820780714_entry, 2, 0};

V g_list_2ecollapse_24s945166865x820780714(V v_run_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_run_240;
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkPair: {
      V v_below_245 = heff_field(v_x31_242, 1);
      V v_t_246 = (g_list_2emerge_24s991540778x2011810329(heff_dup(v_below_245), v_run_240));
      V t_0 = v_t_246;
      V t_1 = v_rest_243;
      v_run_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2ecollapse_24s945166865x820780714_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ecollapse_24s945166865x820780714(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str1, 2, ", ");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str3, 1, "]");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str4, 1, " ");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str7, 8, "(variant");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str8, 1, ")");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str9, 1, " ");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str10, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str11, 0, "");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str12, 4, "(bad");
HEFF_LIT(g_list_2emap_24s354283597x484250159_24dps_str13, 1, ")");
Clo g_list_2emap_24s354283597x484250159_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s354283597x484250159_24dps_entry, 3, 0};

V g_list_2emap_24s354283597x484250159_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2430;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 1ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_TagVariant: {
        V v_t_249 = heff_field(v_x21_247, 0);
        V v_args_2411 = heff_field(v_x21_247, 2);
        heff_take_n(v_x21_247, 5ULL, 3);
        V v_x2_2412 = (g_list_2emap(heff_get_n(v_r_245, 0, 2), v_args_2411));
        V v_t_2415;
        switch (heff_tag_of(v_x2_2412)) {
        case TAG_Nil: {
          v_t_2415 = ((V)&g_list_2emap_24s354283597x484250159_24dps_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2413 = heff_field(v_x2_2412, 0);
          V v_xs_2414 = heff_field(v_x2_2412, 1);
          heff_take_n(v_x2_2412, 3ULL, 2);
          v_t_2415 = ({ V a_0 = ((V)&g_list_2emap_24s354283597x484250159_24dps_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2412);
        }
        V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s354283597x484250159_24dps_str2), v_t_2415), ((V)&g_list_2emap_24s354283597x484250159_24dps_str3));
        V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
        V v_parts_2418 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_t_249, v_t_2417});
        V v_x2_2419 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s354283597x484250159_24dps_str4), v_parts_2418));
        V v_t_2422;
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nil: {
          v_t_2422 = ((V)&g_list_2emap_24s354283597x484250159_24dps_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_x2_2419, 0);
          V v_xs_2421 = heff_field(v_x2_2419, 1);
          heff_take_n(v_x2_2419, 3ULL, 2);
          v_t_2422 = ({ V a_0 = ((V)&g_list_2emap_24s354283597x484250159_24dps_str6); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s354283597x484250159_24dps_str7), v_t_2422), ((V)&g_list_2emap_24s354283597x484250159_24dps_str8));
        break;
      }
      case TAG_BadVariant: {
        V v_e_2423 = heff_field(v_x21_247, 0);
        heff_take_n(v_x21_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_246_24At, 2);
        V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2423}));
        V v_parts_2425 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        V v_x2_2426 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s354283597x484250159_24dps_str9), v_parts_2425));
        V v_t_2429;
        switch (heff_tag_of(v_x2_2426)) {
        case TAG_Nil: {
          v_t_2429 = ((V)&g_list_2emap_24s354283597x484250159_24dps_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2427 = heff_field(v_x2_2426, 0);
          V v_xs_2428 = heff_field(v_x2_2426, 1);
          heff_take_n(v_x2_2426, 3ULL, 2);
          v_t_2429 = ({ V a_0 = ((V)&g_list_2emap_24s354283597x484250159_24dps_str11); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2426);
        }
        v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s354283597x484250159_24dps_str12), v_t_2429), ((V)&g_list_2emap_24s354283597x484250159_24dps_str13));
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, heff_hole()});
    V v_u_2432 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2431);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2432;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s354283597x484250159_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1420651609x666245096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_24dps_entry, 2, 0};

V g_list_2emap_24s1420651609x666245096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1420651609x666245096_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1132197644x1537385180_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1132197644x1537385180_str1, 2, "on");
Clo g_list_2emap_24s1132197644x1537385180_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1132197644x1537385180_entry, 2, 0};

V g_list_2emap_24s1132197644x1537385180(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_fs_244 = heff_dup(v_lit_240);
    V v_f_245 = v_x_242;
    V v_t_246 = (g_list_2ekeepIf_24s2034497759x755284100(heff_dup(v_f_245), v_fs_244));
    V v_x1_247 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_t_246));
    V v_t_2427;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2427 = (g_std_2ecli_2einteractive_2eflagSlot(v_f_245));
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      HeffT2 v_t_2410 = (g_std_2ecli_2einteractive_2eflagSlot_24cpr(heff_dup(v_f_245)));
      {
        V v_field_2412 = v_t_2410.f[1];
        heff_drop(v_t_2410.f[0]);
        V v_t_2413 = v_field_2412;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Typed: {
          heff_take_n(v_t_2413, 0ULL, 1);
          V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(heff_dup(v_x_248)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          V v_t_2416 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(v_x_248), v_t_2415});
          v_t_2427 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Flagged, 1, (V[]){v_f_245}), heff_tag_n(TAG_Typed, 1, (V[]){v_t_2416})});
          break;
        }
        case TAG_Picked: {
          V v_c_2417 = heff_field(v_t_2413, 0);
          heff_take_n(v_t_2413, 1ULL, 1);
          V v_d_2418 = heff_take_field(v_c_2417, 1);
          V v_t_2419;
          if (heff_strEq_c(heff_dup(heff_rfield(v_f_245, 2)), ((V)&g_list_2emap_24s1132197644x1537385180_str0))) {
            heff_drop(v_x_248);
            v_t_2419 = ((V)&g_list_2emap_24s1132197644x1537385180_str1);
          } else {
            v_t_2419 = v_x_248;
          }
          V v_p_2420 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_2419}));
          HeffT2 v_t_2421 = (g_list_2eindexWhere_2eindexFrom_240_24cpr(v_p_2420, MK_INT(0LL), heff_rfield(v_c_2417, 0)));
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            V v_t_2425;
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              heff_drop(v_d_2418);
              V v_x_2424 = v_field_2423;
              v_t_2425 = v_x_2424;
            } else {
              heff_drop(v_field_2423);
              v_t_2425 = v_d_2418;
            }
            V v_t_2426 = ({ V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_c_2417, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            v_t_2427 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Flagged, 1, (V[]){v_f_245}), heff_tag_n(TAG_Picked, 1, (V[]){v_t_2426})});
          }
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
      }
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_cell_2428 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2427, heff_hole()});
    V v_u_2429 = (g_list_2emap_24s1132197644x1537385180_24dps(v_lit_240, v_xs_243, v_cell_2428));
    heff_drop(v_u_2429);
    return v_cell_2428;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1132197644x1537385180_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1132197644x1537385180(a[0], a[1]);
}
Clo g_list_2efoldl_24f603879485x1484249893_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f603879485x1484249893_entry, 4, 0};

V g_list_2efoldl_24f603879485x1484249893(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_242, 4);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c(heff_dup(v_x_244), heff_dup(heff_rfield(v_lit_242, 0)))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f603879485x1484249893_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f603879485x1484249893(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1749649202x1754028860_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1749649202x1754028860_24dps_entry, 3, 0};

V g_list_2emap_24f1749649202x1754028860_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_module_245 = heff_take_field(v_x_243, 1);
    V v_key_246 = heff_get_n(v_x_243, 0, 2);
    if (heff_strEq_c(v_module_245, heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_key_246, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_key_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1749649202x1754028860_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24f1749649202x1754028860_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1651437062x1594169608_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1651437062x1594169608_entry, 2, 0};

V g_list_2emap_24f1651437062x1594169608(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_text_244 = heff_take_field(v_x_242, 0);
    V v_span_245 = heff_get_n(v_x_242, 1, 2);
    if (heff_strEq_c_lent(v_text_244, v_lit_240, 1)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_span_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f1651437062x1594169608_24dps(v_lit_240, v_xs_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_span_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1651437062x1594169608_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1651437062x1594169608(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24f547094838x440994078_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f547094838x440994078_entry, 3, 0};

V g_list_2efoldl_24f547094838x440994078(V v_z_240, V v_n_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_n_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
      heff_drop(v_n_241);
      return v_z_240;
    } else {
      V v_x_245 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_x_243)));
      V t_0 = heff_intAdd(v_z_240, v_x_245);
      V t_1 = heff_intSub(v_n_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_n_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f547094838x440994078(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24f1511070573x340395911_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24f1511070573x340395911_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24f1511070573x340395911_24dps_str2, 1, " ");
Clo g_list_2emap_24f1511070573x340395911_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1511070573x340395911_24dps_entry, 4, 0};

V g_list_2emap_24f1511070573x340395911_24dps(V v_w_240, V v_line_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1511070573x340395911_24dps_str0), 2)) {
      heff_drop(v_line_241);
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_244 = (g_list_2emap_24s1093229560x1486136516(NTAG(TAG_Nil)));
      V v_t_245 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_244}));
    }
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_242, 0);
    V v_xs_248 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1511070573x340395911_24dps_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_247;
      V t_2 = v_xs_248;
      V t_3 = v_d_243;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_xs_249 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_241))));
      V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_249); r_; });
      V v_xs_2411 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_247))));
      V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2411; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_2411); r_; });
      V v_t_2413 = heff_intAdd(heff_intAdd(v_t_2410, MK_INT(1LL)), v_t_2412);
      if (heff_intLe_c_lent(v_t_2413, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V v_t_2414 = heff_strAppend(heff_strAppend(v_line_241, ((V)&g_list_2emap_24f1511070573x340395911_24dps_str2)), v_x_247);
        V t_0 = v_w_240;
        V t_1 = v_t_2414;
        V t_2 = v_xs_248;
        V t_3 = v_d_243;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        V v_t_2415 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
        V v_u_2418 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2417);
        V t_0 = v_w_240;
        V t_1 = v_x_247;
        V t_2 = v_xs_248;
        V t_3 = v_u_2418;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1511070573x340395911_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24f1511070573x340395911_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24tok2_str0, 5, "label");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24tok2_str1, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24tok2_str2, 6, "detail");
Clo g_list_2emap_24s4199228x1154005405_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_24tok2_entry, 2, 0};

V g_list_2emap_24s4199228x1154005405_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_label_244 = heff_take_field(v_x_242, 0);
    V v_detail_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24tok2_str0), heff_tag_n(TAG_JString, 1, (V[]){v_label_244})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24tok2_str1), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24tok2_str2), heff_tag_n(TAG_JString, 1, (V[]){v_detail_245})});
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    V v_cell_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410}), heff_hole()});
    V v_u_2412 = (g_list_2emap_24s4199228x1154005405_24dps(v_xs_243, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s4199228x1154005405_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405_24tok2(a[0], a[1]);
}