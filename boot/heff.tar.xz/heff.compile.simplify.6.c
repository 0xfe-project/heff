// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_MkArm 55352
#define TAG_Perform 19235
#define LBL_all 306203
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_names 305943394
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_unrolled 706233391
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(V, V, V);
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2earmWith_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedAs_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ebuilds(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ecalledFirst(V, V, V);
V g_heff_2ecompile_2esimplify_2ecalledFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecalledFirst_clo;
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eetaCapturing(V);
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo;
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerOf(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerOf_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(V, V);
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_clo;
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438(V, V);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2emovesFirst(V, V);
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialIn_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2erecipeAsks(V, V, V);
V g_heff_2ecompile_2esimplify_2erecipeAsks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecipeAsks_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erunsGiven_clo;
V g_heff_2ecompile_2esimplify_2esharedIn(V, V);
V g_heff_2ecompile_2esimplify_2esharedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esharedIn_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2_clo;
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_clo;
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2evaluesAt(V, V);
V g_heff_2ecompile_2esimplify_2evaluesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesAt_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_list_2eall_24s1512314936x520990916(V);
V g_list_2eall_24s1512314936x520990916_entry(V self, V *a);
extern Clo g_list_2eall_24s1512314936x520990916_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1206739756x709939553(V, V, V, V);
V g_list_2eany_24s1206739756x709939553_entry(V self, V *a);
extern Clo g_list_2eany_24s1206739756x709939553_clo;
V g_list_2eany_24s392952474x1351014279(V, V);
V g_list_2eany_24s392952474x1351014279_entry(V self, V *a);
extern Clo g_list_2eany_24s392952474x1351014279_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1544308498x936697067(V, V);
V g_list_2efoldl_24s1544308498x936697067_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1544308498x936697067_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1112048172x371485672(V);
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1531069132x955165792(V);
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s704759456x417074234(V, V, V, V, V);
V g_list_2ezipWith_24s704759456x417074234_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s704759456x417074234_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1182736556x1844399207_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s196770916x1113382074_24cpr(V, V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      V v_cell_246 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eletsOf_24dps(v_rest_243, v_body_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V v_x1_240, V v_body_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_body_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_243, 0);
      V v_a_246 = heff_field(v_x11_243, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_245), heff_dup(v_a_246), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_244;
      V t_1 = v_body_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_body_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eflat_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eflat(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2esimplify_2eflat_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eflat(a[0]);
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureOrPartial_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epureOrPartial(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELet: {
    V v_a_243 = heff_field(v_e_241, 1);
    V v_b_244 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 6ULL, 3);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_240), v_a_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_s_240;
      V t_1 = v_b_244;
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_s_240, 10);
      heff_drop(v_b_244);
      heff_drop(v_t_245);
      return NTAG(TAG_False);
    }
  }
  case TAG_ETag: {
    V v_argv_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 3);
    V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureOrPartial_clo), 1, (V[]){v_s_240}));
    V v_t_2410 = (g_list_2emap(v_t_249, v_argv_247));
    return ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
  }
  case TAG_EMatch: {
    V v_sc_2411 = heff_field(v_e_241, 0);
    V v_arms_2412 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_sc_2411));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      switch (heff_tag_of(v_arms_2412)) {
      case TAG_Nil: {
        heff_drop_rec(v_s_240, 10);
        heff_drop_cell(v_ru_24e_241_24EMatch, 2);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2421 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2esimplify_2epureOrPartial_lam0, 1, 1, (V[]){v_s_240}), v_arms_2412));
        return ({ V a_0 = v_t_2421; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2421); r_; });
      }
      default: return heff_nomatch(v_arms_2412);
      }
    } else {
      heff_drop_rec(v_s_240, 10);
      heff_drop(v_arms_2412);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
  }
  default: {
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), heff_dup(v_e_241)));
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 10);
      heff_drop(v_e_241);
      heff_drop(v_t_2422);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2422);
      return ({ V a_0 = v_s_240; V a_1 = v_e_241; V r_ = (g_heff_2ecompile_2esimplify_2epartialIn(a_0, a_1)); heff_drop(v_e_241); r_; });
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epureOrPartial(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_lam0(V self, V *args) {
  V v_b_2416 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_b_2416)) {
  case TAG_MkArm: {
    V v_b_2419 = heff_field(v_b_2416, 2);
    heff_take_n(v_b_2416, 4ULL, 3);
    v_t_2420 = v_b_2419;
    break;
  }
  default: heff_nomatch(v_b_2416);
  }
  return (g_heff_2ecompile_2esimplify_2epureOrPartial(v_s_240, v_t_2420));
}
Clo g_heff_2ecompile_2esimplify_2esharedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esharedIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esharedIn(V v_s_240, V v_a_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_241), NTAG(TAG_Nil)});
  V v_x_243 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_242));
  if (!heff_intLt_c_lent(MK_INT(60LL), v_x_243, 1)) {
    heff_drop(v_x_243);
    V v_t_244 = heff_tr(g_heff_2ecompile_2espec_2eclosedIn(NTAG(TAG_Nil), heff_dup(v_a_241)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_s_240);
        heff_drop(v_a_241);
        heff_drop(v_t_245);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_245);
        return ({ V a_0 = v_s_240; V a_1 = v_a_241; V r_ = (g_heff_2ecompile_2esimplify_2epartialIn(a_0, a_1)); heff_drop(v_a_241); r_; });
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_a_241);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_a_241);
    heff_drop(v_x_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2esharedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esharedIn(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuiltBy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebuiltBy(V v_all_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_argv_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = (g_list_2emap_24s1112048172x371485672(heff_dup(v_argv_247)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_247));
        V v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_all_240, v_g_249));
        return ({ V a_0 = heff_dup(v_g_249); V a_1 = v_t_2412; V a_2 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2ebuilds(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
      } else {
        heff_drop(v_t_2411);
        return NTAG(TAG_False);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ebuiltBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2erunsGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erunsGiven_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2erunsGiven(V v_x_240, V v_a_241, V v_b_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_a1_246 = heff_field(v_a_241, 0);
    V v_body_247 = heff_field(v_a_241, 1);
    heff_take_n(v_a_241, 3ULL, 2);
    switch (heff_tag_of(v_a1_246)) {
    case TAG_Nil: {
      heff_drop(v_b_242);
      heff_drop(v_o_243);
      heff_drop(v_body_247);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_c_248 = heff_field(v_a1_246, 0);
      V v_cs_249 = heff_field(v_a1_246, 1);
      heff_take_n(v_a1_246, 3ULL, 2);
      V v_ret_24bool = heff_bool((heff_intLe_c_lent(v_o_243, MK_INT(2LL), 2) && ({ V v_t_2410 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_248), heff_dup(v_cs_249)}), heff_dup(v_body_247)}); int c_ = ({ V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_t_2410), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2412 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), heff_dup(v_t_2411))); int c_ = (heff_intLt_c_lent(MK_INT(160LL), v_x_2412, 1) ? 0 : ({ V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_body_247), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2414 = (g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(v_c_248, MK_INT(0LL), heff_dup(v_t_2413))); int c_ = (heff_intLt_c_lent(MK_INT(0LL), v_x_2414, 1) && ({ V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2451 = (g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(v_x_240, MK_INT(0LL), heff_dup(v_t_2415))); int c_ = heff_intEq_c_lent(v_t_2451, v_o_243, 0); heff_drop(v_t_2451); c_; }); heff_drop(v_t_2415); c_; })); heff_drop(v_x_2414); c_; }); heff_drop(v_t_2413); c_; })); heff_drop(v_x_2412); c_; }); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; })));
      heff_drop(v_b_242);
      heff_drop(v_o_243);
      heff_drop(v_body_247);
      heff_drop(v_c_248);
      heff_drop(v_cs_249);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_a1_246);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2erunsGiven_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2erunsGiven(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2earmWith_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_bs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_b_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_dup(heff_field(v_b_242, 2));
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_b_242);
    }
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_x_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_248));
    if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
      heff_drop(v_bs_243);
      V v_f_2413;
      switch (heff_tag_of(v_b_242)) {
      case TAG_MkArm: {
        V v_b_2412 = heff_field(v_b_242, 2);
        heff_take_n(v_b_242, 4ULL, 3);
        v_f_2413 = v_b_2412;
        break;
      }
      default: heff_nomatch(v_b_242);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
    } else {
      heff_drop(v_b_242);
      V t_0 = v_x_240;
      V t_1 = v_bs_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ecalledFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecalledFirst_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ecalledFirst(V v_all_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_argv_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      V v_y_249 = heff_field(v_x31_247, 0);
      if (heff_strEq_c_lent(v_x_241, v_y_249, 0)) {
        V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ehandlerOf_clo), 1, (V[]){v_all_240}));
        V v_t_2411 = (g_list_2eany(v_t_2410, v_argv_248));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          V v_t_2412 = (g_list_2emap_24s1531069132x955165792(heff_dup(v_argv_248)));
          return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
        } else {
          heff_drop(v_t_2411);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_all_240);
        return NTAG(TAG_False);
      }
    }
    case TAG_EGlobal: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_all_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_2452 = heff_field(v_x3_242, 1);
    V v_b_2453 = heff_field(v_x3_242, 2);
    V v_t_2454 = (g_heff_2ecompile_2esimplify_2ecalledFirst(heff_dup(v_all_240), v_x_241, v_a_2452));
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop(v_all_240);
      heff_drop(v_t_2454);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2ecompile_2eir_2eisValue(v_a_2452));
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop(v_t_2455);
        V t_0 = v_all_240;
        V t_1 = v_x_241;
        V t_2 = v_b_2453;
        v_all_240 = t_0;
        v_x_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_all_240);
        heff_drop(v_t_2455);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ERecord: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_sc_2465 = heff_field(v_x3_242, 0);
    V t_0 = v_all_240;
    V t_1 = v_x_241;
    V t_2 = v_sc_2465;
    v_all_240 = t_0;
    v_x_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EPrim: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_all_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2ecalledFirst_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2ecalledFirst(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecapturing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecapturing_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecapturing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (!heff_intLt_c_lent(MK_INT(60LL), v_x_246, 1)) {
      heff_drop(v_x_246);
      V v_t_247 = ({ V a_0 = v_xs_243; V a_1 = v_b_244; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
      return ({ V a_0 = v_t_247; V r_ = (g_list_2eall_24s1512314936x520990916(a_0)); heff_drop(v_t_247); r_; });
    } else {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      heff_drop(v_x_246);
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecapturing(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x2_241);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_241, 0);
      V v_xs_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_245);
        V t_0 = v_ms_244;
        V t_1 = v_xs_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_xs_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2echeap_str0, 6, "MkLazy");
Clo g_heff_2ecompile_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2echeap_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2echeap(V v_safe_240, V v_all_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_all_241);
    HeffT2 v_t_244 = ({ V a_0 = v_safe_240; V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_safe_240); heff_drop(v_g_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_245 == ((int64_t)0ULL)) && ({ V v_x_247 = heff_dup(v_field_246); int c_ = 1; heff_drop(v_x_247); c_; })));
      heff_drop(v_field_246);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_2410 = heff_field(v_e_242, 0);
    V v_argv_2411 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2410)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2413 = heff_field(v_e1_2410, 0);
      heff_take_n(v_e1_2410, 1ULL, 1);
      V v_x_2414 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, v_g_2413));
      V v_y_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2411));
      V v_x_2418;
      if (heff_intLt_c(v_y_2415, v_x_2414)) {
        V v_t_2416 = ({ V a_0 = v_all_241; V a_1 = v_g_2413; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_g_2413); r_; });
        V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2411));
        v_x_2418 = heff_intSub(v_t_2416, v_t_2417);
      } else {
        heff_drop(v_g_2413);
        v_x_2418 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_x_2418)) {
        V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2420 = (g_list_2emap_24tok2(v_ru_24e_242_24EApp, v_t_2419, v_argv_2411));
        return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
      } else {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        heff_drop(v_argv_2411);
        heff_drop_cell(v_ru_24e_242_24EApp, 2);
        return NTAG(TAG_False);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2410, 0ULL, 3);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2410, 0ULL, 4);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2410, 0ULL, 3);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2410, 0ULL, 3);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_2410);
    }
  }
  case TAG_ETag: {
    V v_t_2458 = heff_field(v_e_242, 0);
    V v_argv_2459 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 3);
    if (!heff_strEq_c_lent(v_t_2458, ((V)&g_heff_2ecompile_2esimplify_2echeap_str0), 2)) {
      heff_drop(v_t_2458);
      V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
      V v_t_2462 = (g_list_2emap(v_t_2461, v_argv_2459));
      return ({ V a_0 = v_t_2462; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2462); r_; });
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2458);
      heff_drop(v_argv_2459);
      return NTAG(TAG_False);
    }
  }
  case TAG_EMatch: {
    V v_sc_2463 = heff_field(v_e_242, 0);
    V v_arms_2464 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2465 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_sc_2463));
    if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
      heff_drop(v_t_2465);
      switch (heff_tag_of(v_arms_2464)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        heff_drop_cell(v_ru_24e_242_24EMatch, 2);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2469 = (g_list_2emap_24s60612435x257154841(v_arms_2464));
        V v_t_2470 = (g_list_2emap_24tok2(v_ru_24e_242_24EMatch, v_t_2468, v_t_2469));
        return ({ V a_0 = v_t_2470; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2470); r_; });
      }
      default: return heff_nomatch(v_arms_2464);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_arms_2464);
      heff_drop_cell(v_ru_24e_242_24EMatch, 2);
      heff_drop(v_t_2465);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrimCall: {
    V v_p_2471 = heff_field(v_e_242, 0);
    V v_argv_2472 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_p_2471)) {
    case TAG_IntShl: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2472);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_IntShr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2472);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndex: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2472);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_ArrayGenerate: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2472);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_Keep: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2472);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_Perform: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_argv_2472);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    default: {
      heff_drop(v_p_2471);
      V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
      V v_t_2474 = (g_list_2emap_24tok2(v_ru_24e_242_24EPrimCall, v_t_2473, v_argv_2472));
      return ({ V a_0 = v_t_2474; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2474); r_; });
    }
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  default: {
    V v_t_2479 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
    V v_t_2480 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, NTAG(TAG_Nil)));
    V v_t_2481 = (g_list_2emap(v_t_2479, v_t_2480));
    return ({ V a_0 = v_t_2481; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2481); r_; });
  }
  }
}
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2echeap(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_f_243 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_243, v_p_241}});
  }
  case TAG_EGlobal: {
    V v_f_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_245, v_p_241}});
  }
  case TAG_ELam: {
    V v_f_248 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_248, v_p_241}});
  }
  case TAG_EApp: {
    V v_f_2411 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2411, v_p_241}});
  }
  case TAG_ELet: {
    V v_a_2413 = heff_field(v_x1_240, 1);
    V v_e_2414 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_x_2415 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_a_2413));
    if ((heff_dup(v_x_2415) == NTAG(TAG_True))) {
      heff_drop(v_x_2415);
      V t_0 = v_e_2414;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    } else {
      heff_drop(v_e_2414);
      heff_drop(v_x_2415);
      return ((HeffT2){{NTAG(TAG_False), v_p_241}});
    }
  }
  case TAG_ERecord: {
    V v_f_2418 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2418, v_p_241}});
  }
  case TAG_EProj: {
    V v_f_2423 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2423, v_p_241}});
  }
  case TAG_ETag: {
    V v_f_2427 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2427, v_p_241}});
  }
  case TAG_EMatch: {
    V v_f_2430 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2430, v_p_241}});
  }
  case TAG_EPrim: {
    V v_f_2432 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2432, v_p_241}});
  }
  case TAG_EPrimCall: {
    V v_f_2435 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2435, v_p_241}});
  }
  case TAG_ECall: {
    V v_f_2438 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2438, v_p_241}});
  }
  case TAG_EInt: {
    V v_f_2440 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2440, v_p_241}});
  }
  case TAG_EFloat: {
    V v_f_2442 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2442, v_p_241}});
  }
  case TAG_EStr: {
    V v_f_2444 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2444, v_p_241}});
  }
  case TAG_EBytes: {
    V v_f_2446 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2446, v_p_241}});
  }
  case TAG_EFixed: {
    V v_f_2449 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2449, v_p_241}});
  }
  case TAG_EFloat32: {
    V v_f_2451 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2451, v_p_241}});
  }
  case TAG_EAbandon: {
    V v_f_2452 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2452, v_p_241}});
  }
  case TAG_EBool: {
    V v_f_2454 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2454, v_p_241}});
  }
  case TAG_ESet: {
    V v_f_2458 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2458, v_p_241}});
  }
  case TAG_EValues: {
    V v_f_2460 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2460, v_p_241}});
  }
  case TAG_EFix: {
    V v_f_2463 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2463, v_p_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emovesFirst_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emovesFirst(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_True);
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  }
}
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emovesFirst(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_g_240; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_246;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_ERecord: {
        V v_fs_248 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 2);
        HeffT2 v_t_2410 = ({ V a_0 = v_l_241; V a_1 = v_fs_248; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2efieldIn_24cpr(a_0, a_1)); heff_drop(v_fs_248); r_; });
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_v_2413 = v_field_2412;
            V v_t_2414 = (g_heff_2ecompile_2eir_2eisValue(v_v_2413));
            V v_t_2415;
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop(v_t_2414);
              v_t_2415 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2414);
              v_t_2415 = (g_heff_2ecompile_2esimplify_2epartialIn(heff_dup(v_s_242), v_v_2413));
            }
            if (((heff_dup(v_t_2415) == NTAG(TAG_True)) && heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1))))) {
              heff_drop(v_t_2415);
              V v_t_2416 = heff_intSub(heff_take_field(v_s_242, 1), MK_INT(1LL));
              V v_t_2417 = ({ V rv_1 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_s_242, 1021ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048563u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              HeffT2 v_t_2418 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_v_2413, v_t_2417));
              {
                V v_field_2419 = v_t_2418.f[0];
                V v_field_2420 = v_t_2418.f[1];
                V v_x_2421 = v_field_2419;
                V v_s_2422 = v_field_2420;
                return ((HeffT2){{heff_tag_n(TAG_Just, 1, (V[]){v_x_2421}), v_s_2422}});
              }
            } else {
              heff_drop(v_v_2413);
              heff_drop(v_t_2415);
              return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
            }
          } else {
            heff_drop(v_field_2412);
            return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
          }
        }
      }
      default: {
        heff_drop(v_it1_247);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      }
    } else {
      heff_drop(v_field_246);
      return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
    }
  }
}
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865(V v_x2_240, V v_x3_241, V v_rest_242, V v_z_243) {
top: ;
  if ((heff_dup(v_x2_240) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_x3_241)) {
    case TAG_MkPair: {
      V v_bds_244 = heff_field(v_x3_241, 0);
      V v_a_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_st_246 = NTAG(TAG_True);
      V v_a_247 = v_a_245;
      V v_rest_248 = v_rest_242;
      V v_s_249 = v_z_243;
      V v_k_2410 = (g_heff_2ecompile_2esimplify_2emissingOf(heff_dup(v_s_249), v_a_247));
      V v_x2_2454 = heff_tr(g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_lam0, 1, 3, (V[]){v_st_246, v_k_2410, heff_dup(v_a_247)}), heff_clo_n(g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_lam1, 2, 2, (V[]){v_rest_248, v_a_247}), v_s_249));
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_MkPair: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_s_2456 = heff_field(v_x2_2454, 1);
        V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
        V v_x_2460;
        switch (heff_tag_of(v_x_2455)) {
        case TAG_MkPair: {
          V v_rest_2457 = heff_field(v_x_2455, 0);
          V v_argv_2458 = heff_field(v_x_2455, 1);
          V v_ru_24x_2455_24MkPair = heff_take_reuse_n(v_x_2455, 3ULL, 2);
          V v_t_2459 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x_2455_24MkPair, v_bds_244, v_rest_2457));
          v_x_2460 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2459, v_argv_2458});
          break;
        }
        default: heff_nomatch(v_x_2455);
        }
        return heff_tag_at_n(v_ru_24x2_2454_24MkPair, TAG_MkPair, 2, (V[]){v_x_2460, v_s_2456});
      }
      default: return heff_nomatch(v_x2_2454);
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  } else {
    switch (heff_tag_of(v_x3_241)) {
    case TAG_MkPair: {
      V v_bds_2461 = heff_field(v_x3_241, 0);
      V v_a_2462 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_2465;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_MkPair: {
        V v_x_2463 = heff_dup(heff_field(v_rest_242, 0));
        v_t_2465 = v_x_2463;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2466 = ({ V a_0 = v_bds_2461; V a_1 = v_a_2462; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2461); r_; });
      V v_t_2469;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_MkPair: {
        V v_y_2468 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2469 = v_y_2468;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_x_2470 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2465, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, v_t_2469})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2470, v_z_243});
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_st_246 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_st_246) == NTAG(TAG_True))) {
    if (heff_intLt_c_lent(MK_INT(0LL), v_k_2410, 1)) {
      V v_e_2412 = v_a_247;
      V v_k_2413 = v_k_2410;
      V v_p_2414 = v_p_2411;
      switch (heff_tag_of(v_e_2412)) {
      case TAG_EApp: {
        V v_h_2415 = heff_field(v_e_2412, 0);
        V v_bs_2416 = heff_field(v_e_2412, 1);
        V v_ru_24e_2412_24EApp = heff_take_reuse_n(v_e_2412, 3ULL, 2);
        V v_x2_2417 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_bs_2416, heff_dup(v_p_2414)));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
          HeffT2 v_t_2420 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_k_2413, v_s_2419));
          {
            V v_field_2421 = v_t_2420.f[0];
            V v_field_2422 = v_t_2420.f[1];
            V v_x_2423 = v_field_2421;
            V v_s_2424 = v_field_2422;
            V v_t_2427;
            switch (heff_tag_of(v_x_2418)) {
            case TAG_MkPair: {
              V v_y_2426 = heff_dup(heff_field(v_x_2418, 1));
              v_t_2427 = v_y_2426;
              break;
            }
            default: heff_nomatch(v_x_2418);
            }
            V v_t_2428 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2423)));
            V v_argv_2429 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2428));
            V v_m_2430 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_h_2415, v_argv_2429));
            V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2424}));
            switch (heff_tag_of(v_x2_2431)) {
            case TAG_MkPair: {
              V v_x_2432 = heff_field(v_x2_2431, 0);
              V v_s_2433 = heff_field(v_x2_2431, 1);
              V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
              V v_saved_2434 = v_p_2414;
              V v_x2_2435 = v_x_2418;
              V v_lam1_2436 = heff_tag_at_n(v_ru_24e_2412_24EApp, TAG_ELam, 2, (V[]){v_x_2423, v_x_2432});
              V v_p_2437 = v_s_2433;
              switch (heff_tag_of(v_x2_2435)) {
              case TAG_MkPair: {
                V v_bds_2438 = heff_field(v_x2_2435, 0);
                heff_take_n(v_x2_2435, 1ULL, 2);
                V v_t_2440 = (g_heff_2ecompile_2esimplify_2eetaCapturing(heff_dup(v_lam1_2436)));
                if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
                  heff_drop_rec(v_saved_2434, 10);
                  heff_drop(v_t_2440);
                  V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2438, v_lam1_2436})});
                  return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2441, v_p_2437});
                } else {
                  heff_drop_cell(v_ru_24x2_2431_24MkPair, 2);
                  heff_drop_tag(v_lam1_2436, 2);
                  heff_drop(v_bds_2438);
                  heff_drop(v_t_2440);
                  V v_t_2442 = ({ V rv_2 = heff_take_field(v_saved_2434, 2); V rv_5 = heff_get_n(v_saved_2434, 5, 10); V rr_ = heff_rec_reuse_nf(v_p_2437, 987ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1045455u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
                  return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_t_2442});
                }
              }
              default: return heff_nomatch(v_x2_2435);
              }
            }
            default: return heff_nomatch(v_x2_2431);
            }
          }
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: {
        heff_drop(v_e_2412);
        heff_drop(v_k_2413);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2414});
      }
      }
    } else {
      heff_drop(v_k_2410);
      heff_drop(v_a_247);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2411});
    }
  } else {
    heff_drop(v_k_2410);
    heff_drop(v_a_247);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2411});
  }
}
V g_heff_2ecompile_2esimplify_2eetaLets_24s1196634686x1578907865_lam1(V self, V *args) {
  V v_e_2443 = args[0];
  V v_z_2444 = args[1];
  V v_rest_248 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2453;
  switch (heff_tag_of(v_e_2443)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_rest_248)) {
    case TAG_MkPair: {
      V v_rest_2445 = heff_field(v_rest_248, 0);
      V v_argv_2446 = heff_field(v_rest_248, 1);
      V v_ru_24rest_248_24MkPair = heff_take_reuse_n(v_rest_248, 3ULL, 2);
      v_x_2453 = heff_tag_at_n(v_ru_24rest_248_24MkPair, TAG_MkPair, 2, (V[]){v_rest_2445, heff_tag_n(TAG_Cons, 2, (V[]){v_a_247, v_argv_2446})});
      break;
    }
    default: heff_nomatch(v_rest_248);
    }
    break;
  }
  case TAG_Just: {
    V v_x21_2447 = heff_field(v_e_2443, 0);
    heff_take_n(v_e_2443, 1ULL, 1);
    heff_drop(v_a_247);
    switch (heff_tag_of(v_x21_2447)) {
    case TAG_MkPair: {
      V v_bds_2448 = heff_field(v_x21_2447, 0);
      V v_lam1_2449 = heff_field(v_x21_2447, 1);
      V v_ru_24x21_2447_24MkPair = heff_take_reuse_n(v_x21_2447, 3ULL, 2);
      switch (heff_tag_of(v_rest_248)) {
      case TAG_MkPair: {
        V v_rest_2450 = heff_field(v_rest_248, 0);
        V v_argv_2451 = heff_field(v_rest_248, 1);
        V v_ru_24rest_248_24MkPair = heff_take_reuse_n(v_rest_248, 3ULL, 2);
        V v_t_2452 = (g_prelude_2e_2b_2b(v_bds_2448, v_rest_2450));
        v_x_2453 = heff_tag_at_n(v_ru_24x21_2447_24MkPair, TAG_MkPair, 2, (V[]){v_t_2452, heff_tag_at_n(v_ru_24rest_248_24MkPair, TAG_Cons, 2, (V[]){v_lam1_2449, v_argv_2451})});
        break;
      }
      default: heff_nomatch(v_rest_248);
      }
      break;
    }
    default: heff_nomatch(v_x21_2447);
    }
    break;
  }
  default: heff_nomatch(v_e_2443);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2453, v_z_2444});
}
Clo g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378(V v_g_240, V v_xs_241, V v_b_242, V v_argv_243, V v_s_244) {
top: ;
  V v_g_245 = heff_dup(v_g_240);
  V v_xs_246 = heff_dup(v_xs_241);
  V v_b_247 = heff_dup(v_b_242);
  V v_argv_248 = heff_dup(v_argv_243);
  V v_s_249 = v_s_244;
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_s_249, 7)), 6, 7);
  V v_x2_2422;
  if (((heff_dup(v_t_2410) == NTAG(TAG_True)) || heff_intLe_c(MK_INT(50000LL), heff_get_n(heff_dup(heff_rfield(v_s_249, 7)), 5, 7)))) {
    heff_drop(v_xs_246);
    heff_drop(v_b_247);
    heff_drop(v_t_2410);
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_245}), v_argv_248));
    v_x2_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_249});
  } else {
    heff_drop(v_t_2410);
    V v_t_2412 = (g_list_2eany_24s392952474x1351014279(heff_dup(v_s_249), v_argv_248));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2ebeforeMoved(heff_dup(v_s_249), heff_dup(v_argv_248)));
      HeffT2 v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_s_249; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eallPure_24cpr(a_0, a_1)); heff_drop(v_t_2413); r_; });
      {
        V v_field_2415 = v_t_2414.f[0];
        V v_field_2416 = v_t_2414.f[1];
        V v_x_2417 = v_field_2415;
        V v_s_2418 = v_field_2416;
        V v_x2_2419 = ({ V a_0 = heff_dup(v_g_245); V a_1 = heff_dup(v_xs_246); V a_2 = heff_dup(v_b_247); V a_3 = heff_dup(v_argv_248); V a_4 = v_x_2417; V a_5 = v_s_2418; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2eetaLoop_24s1877313584x479300638(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2417); r_; });
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_MkPair: {
          V v_x_2420 = heff_field(v_x2_2419, 0);
          V v_s_2421 = heff_field(v_x2_2419, 1);
          V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
          v_x2_2422 = (g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_24tok2(v_ru_24x2_2419_24MkPair, v_g_245, v_xs_246, v_b_247, v_argv_248, v_x_2420, v_s_2421));
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
      }
    } else {
      heff_drop(v_t_2412);
      v_x2_2422 = (g_heff_2ecompile_2esimplify_2especBound_24s1499770947x611665000(heff_dup(v_argv_248), v_g_245, v_xs_246, v_b_247, v_argv_248, v_s_249));
    }
  }
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_s_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2estillCall(v_g_240, v_x_2423));
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_x_2427 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), v_t_2426));
      if (!heff_intLt_c_lent(MK_INT(160LL), v_x_2427, 1)) {
        heff_drop(v_x_2427);
        V v_x_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
        V v_y_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
        if (heff_intLt_c(v_y_2429, v_x_2428)) {
          V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_s_2424, 7)), 0, 7);
          V v_t_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ehandlerOf_clo), 1, (V[]){v_t_2430}));
          V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
          V v_t_2433 = (g_list_2edrop(v_t_2432, v_argv_243));
          V v_t_2434 = ({ V a_0 = v_t_2431; V a_1 = v_t_2433; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2433); r_; });
          if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
            heff_drop(v_x_2423);
            heff_drop_cell(v_ru_24x2_2422_24MkPair, 2);
            heff_drop(v_t_2434);
            HEFF_LAST return g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(v_g_240, v_xs_241, v_b_242, v_argv_243, v_s_2424);
          } else {
            heff_drop(v_g_240);
            heff_drop(v_xs_241);
            heff_drop(v_b_242);
            heff_drop(v_argv_243);
            heff_drop(v_t_2434);
            return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
          }
        } else {
          heff_drop(v_g_240);
          heff_drop(v_xs_241);
          heff_drop(v_b_242);
          heff_drop(v_argv_243);
          return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
        }
      } else {
        heff_drop(v_g_240);
        heff_drop(v_xs_241);
        heff_drop(v_b_242);
        heff_drop(v_argv_243);
        heff_drop(v_x_2427);
        return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
      }
    } else {
      heff_drop(v_g_240);
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      heff_drop(v_argv_243);
      heff_drop(v_t_2425);
      return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especHanded_24s745364586x583878378(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str0, 6, "MkLazy");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str1, 7, "matched");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str2, 5, "given");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str3, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str4, 2, "$_");
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam7(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438(V v_s_240, V v_arms_241) {
top: ;
  switch (heff_tag_of(v_s_240)) {
  case TAG_EGlobal: {
    V v_g_242 = heff_dup(heff_field(v_s_240, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam0, 1, 3, (V[]){v_g_242, v_s_240, v_arms_241});
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_s_240, 0);
    V v_a_2416 = heff_field(v_s_240, 1);
    V v_b_2417 = heff_field(v_s_240, 2);
    heff_take_n(v_s_240, 7ULL, 3);
    V v_m_2418 = (g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(v_b_2417, v_arms_241));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam1, 1, 3, (V[]){v_m_2418, v_x_2415, v_a_2416});
  }
  case TAG_ETag: {
    V v_t_2423 = heff_dup(heff_field(v_s_240, 0));
    V v_argv_2424 = heff_dup(heff_field(v_s_240, 1));
    HeffT2 v_t_2426 = ({ V a_0 = v_t_2423; V a_1 = v_arms_241; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(a_0, a_1)); heff_drop(v_t_2423); r_; });
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        heff_drop(v_arms_241);
        V v_it1_2429 = v_field_2428;
        switch (heff_tag_of(v_it1_2429)) {
        case TAG_MkArm: {
          V v_t2_2430 = heff_field(v_it1_2429, 0);
          V v_vs_2431 = heff_field(v_it1_2429, 1);
          V v_b_2432 = heff_field(v_it1_2429, 2);
          heff_take_n(v_it1_2429, 7ULL, 3);
          if (heff_strEq_c(v_t2_2430, heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
            switch (heff_tag_of(v_argv_2424)) {
            case TAG_Nil: {
              heff_drop_tag(v_s_240, 3);
              V v_t_2433 = (g_list_2ezipWith_24s1876717925x1404326288(v_vs_2431, v_argv_2424));
              V v_e_2434 = ({ V a_0 = v_t_2433; V a_1 = v_b_2432; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2433); r_; });
              return (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2434));
            }
            case TAG_Cons: {
              heff_take_n(v_argv_2424, 0ULL, 2);
              heff_drop(v_vs_2431);
              return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam2, 1, 2, (V[]){v_s_240, v_b_2432});
            }
            default: return heff_nomatch(v_argv_2424);
            }
          } else {
            heff_drop_tag(v_s_240, 3);
            V v_t_2448 = (g_list_2ezipWith_24s1876717925x1404326288(v_vs_2431, v_argv_2424));
            V v_e_2449 = ({ V a_0 = v_t_2448; V a_1 = v_b_2432; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2448); r_; });
            return (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2449));
          }
        }
        default: return heff_nomatch(v_it1_2429);
        }
      } else {
        heff_drop(v_argv_2424);
        heff_drop(v_field_2428);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam3, 1, 2, (V[]){v_s_240, v_arms_241});
      }
    }
  }
  case TAG_EMatch: {
    V v_s2_2451 = heff_field(v_s_240, 0);
    V v_arms2_2452 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24EMatch = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_s2_2453 = v_s2_2451;
    V v_arms2_2454 = v_arms2_2452;
    V v_arms_2455 = v_arms_241;
    V v_lit_2456 = heff_dup(v_s2_2453);
    heff_drop(v_lit_2456);
    V v_lit_2457 = heff_dup(v_arms2_2454);
    V v_budget_2458 = MK_INT(40LL);
    V v_arms_2459 = heff_dup(v_arms_2455);
    V v_t_2460 = heff_tag_at_n(v_ru_24s_240_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_x1_2461 = (g_list_2efoldl_24s1544308498x936697067(v_t_2460, heff_dup(v_lit_2457)));
    V v_t_2465;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_MkPair: {
      V v_ts_2462 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 2);
      V v_x_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2462; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2462); r_; });
      v_t_2465 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2464, 1));
      heff_drop(v_x_2464);
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    V v_t_2469;
    if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
      heff_drop(v_t_2465);
      V v_t_2466 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
      V v_t_2467 = (g_list_2efoldl_24s1544308498x936697067(v_t_2466, v_lit_2457));
      V v_x1_2468 = (g_list_2eany_24s1206739756x709939553(v_budget_2458, v_t_2467, heff_dup(v_arms_2459), v_arms_2459));
      v_t_2469 = heff_bool(!(heff_dup(v_x1_2468) == NTAG(TAG_True)));
      heff_drop(v_x1_2468);
    } else {
      heff_drop(v_lit_2457);
      heff_drop(v_budget_2458);
      heff_drop(v_arms_2459);
      heff_drop(v_t_2465);
      v_t_2469 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
      heff_drop(v_t_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam4, 1, 3, (V[]){v_arms_2455, v_arms2_2454, v_s2_2453});
    } else {
      heff_drop(v_t_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam5, 1, 3, (V[]){v_arms_2455, v_s2_2453, v_arms2_2454});
    }
  }
  case TAG_ESet: {
    V v_xs_24104 = heff_field(v_s_240, 0);
    V v_a_24105 = heff_field(v_s_240, 1);
    V v_b_24106 = heff_field(v_s_240, 2);
    heff_take_n(v_s_240, 7ULL, 3);
    V v_m_24107 = (g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(v_b_24106, v_arms_241));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam6, 1, 3, (V[]){v_m_24107, v_xs_24104, v_a_24105});
  }
  default: {
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam7, 1, 2, (V[]){v_s_240, v_arms_241});
  }
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_s_240 = heff_env(self)[1];
  V v_arms_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V a_0 = heff_rfield(v_s_243, 2); V a_1 = v_g_242; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_g_242); r_; });
  HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_244, v_s_243));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_x_248 = v_field_246;
    V v_s_249 = v_field_247;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_240, v_arms_241}), v_s_249});
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_ETag: {
        V v_t2_2411 = heff_field(v_it1_2410, 0);
        V v_as2_2412 = heff_field(v_it1_2410, 1);
        V v_ts2_2413 = heff_field(v_it1_2410, 2);
        V v_ru_24it1_2410_24ETag = heff_take_reuse_n(v_it1_2410, 7ULL, 3);
        if (heff_strEq_c_lent(v_t2_2411, ((V)&g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str0), 2)) {
          heff_drop(v_t2_2411);
          heff_drop(v_as2_2412);
          heff_drop(v_ts2_2413);
          heff_drop_cell(v_ru_24it1_2410_24ETag, 3);
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_240, v_arms_241}), v_s_249});
        } else {
          heff_drop_tag(v_s_240, 1);
          V v_t_2414 = (g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(heff_tag_at_n(v_ru_24it1_2410_24ETag, TAG_ETag, 3, (V[]){v_t2_2411, v_as2_2412, v_ts2_2413}), v_arms_241));
          V f_ = v_t_2414;
          args[0] = v_s_249;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
      default: {
        heff_drop(v_it1_2410);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_240, v_arms_241}), v_s_249});
      }
      }
    }
    default: return heff_nomatch(v_x_248);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam1(V self, V *args) {
  V v_s_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_a_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_s_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2415, v_a_2416, v_x_2421}), v_s_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam2(V self, V *args) {
  V v_s_2437 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_b_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2438 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str1), v_s_2437));
  {
    V v_field_2439 = v_t_2438.f[0];
    V v_field_2440 = v_t_2438.f[1];
    V v_x_2441 = v_field_2439;
    V v_s_2442 = v_field_2440;
    V v_m_2443 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_s_240));
    V v_x2_2444 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2442}));
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_MkPair: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_s_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      V v_t_2447 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(v_x_2441, v_x_2445, v_b_2432));
      V f_ = v_t_2447;
      args[0] = v_s_2446;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam3(V self, V *args) {
  V v_s_2450 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_arms_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_240, v_arms_241}), v_s_2450});
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam4(V self, V *args) {
  V v_s_2470 = args[0];
  V v_arms_2455 = heff_env(self)[0];
  V v_arms2_2454 = heff_env(self)[1];
  V v_s2_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2471 = (g_prelude_2etraverse_24s196770916x1113382074_24cpr(v_arms_2455, v_arms2_2454, v_s_2470));
  {
    V v_field_2472 = v_t_2471.f[0];
    V v_field_2473 = v_t_2471.f[1];
    V v_x_2474 = v_field_2472;
    V v_s_2475 = v_field_2473;
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_2453, v_x_2474}), v_s_2475});
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam5(V self, V *args) {
  V v_s_2476 = args[0];
  V v_arms_2455 = heff_env(self)[0];
  V v_s2_2453 = heff_env(self)[1];
  V v_arms2_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2477 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str2), v_s_2476));
  {
    V v_field_2478 = v_t_2477.f[0];
    V v_field_2479 = v_t_2477.f[1];
    V v_x_2480 = v_field_2478;
    V v_s_2481 = v_field_2479;
    V v_lit_2482 = heff_dup(v_x_2480);
    V v_lit_2483 = heff_dup(v_arms_2455);
    V v_x_2484 = v_x_2480;
    V v_a_2485 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s2_2453), heff_dup(v_arms2_2454)});
    V v_t_2486 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_lit_2482}), v_lit_2483});
    HeffT2 v_t_2487 = (g_heff_2ecompile_2esimplify_2eapartOf_24cpr(v_x_2484, v_t_2486));
    V v_x2_24101;
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      if ((v_tag_2488 == ((int64_t)0ULL))) {
        V v_ap_2490 = v_field_2489;
        V v_tags_2491 = heff_take_field(v_ap_2490, 0);
        V v_names_2492 = heff_take_field(v_ap_2490, 1);
        V v_body_2493 = heff_get_n(v_ap_2490, 2, 3);
        V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2evaluesAt_clo), 1, (V[]){v_tags_2491}));
        V v_x3_2495 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(v_t_2494, v_a_2485));
        switch (heff_tag_of(v_x3_2495)) {
        case TAG_Nothing: {
          heff_drop(v_x_2484);
          heff_drop(v_names_2492);
          heff_drop(v_body_2493);
          v_x2_24101 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2496 = heff_field(v_x3_2495, 0);
          V v_ru_24x3_2495_24Just = heff_take_reuse_n(v_x3_2495, 1ULL, 1);
          V v_ys_2497 = v_names_2492;
          V v_t_2498 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2497));
          V v_t_2499 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2498, MK_INT(1LL))));
          V v_t_24100 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str3); V a_1 = v_x_2484; V a_2 = ((V)&g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_str4); V a_3 = v_ys_2497; V a_4 = v_t_2499; V r_ = (g_list_2ezipWith_24s704759456x417074234(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          v_x2_24101 = heff_tag_at_n(v_ru_24x3_2495_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_t_24100, v_x_2496, v_body_2493})});
          break;
        }
        default: heff_nomatch(v_x3_2495);
        }
      } else {
        heff_drop(v_x_2484);
        heff_drop_tag(v_a_2485, 2);
        heff_drop(v_field_2489);
        v_x2_24101 = NTAG(TAG_Nothing);
      }
    }
    V v_t_24103;
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_Nothing: {
      v_t_24103 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_2453, v_arms2_2454}), v_arms_2455});
      break;
    }
    case TAG_Just: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      heff_take_n(v_x2_24101, 1ULL, 1);
      heff_drop(v_arms_2455);
      heff_drop(v_s2_2453);
      heff_drop(v_arms2_2454);
      v_t_24103 = v_x_24102;
      break;
    }
    default: heff_nomatch(v_x2_24101);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24103, v_s_2481});
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam6(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_xs_24104 = heff_env(self)[1];
  V v_a_24105 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24104, v_a_24105, v_x_24110}), v_s_24111});
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_24s792797277x82381438_lam7(V self, V *args) {
  V v_s_24112 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_arms_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_240, v_arms_241}), v_s_24112});
}
V g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V v_x1_240, V v_h_241, V v_b_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
    V v_hs_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_243, 8)), 4, 5);
    HeffT2 v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_h_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_f_2423;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2411;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_249;
        v_t_2411 = v_x_2410;
      } else {
        heff_drop(v_field_249);
        v_t_2411 = NTAG(TAG_Nil);
      }
      V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0, 2, 1, (V[]){heff_dup(v_p_243)}); V a_1 = v_t_2411; V a_2 = v_hs_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_245); r_; });
      V v_k_2420 = heff_take_field(v_p_243, 8);
      V v_t_2421 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_2420, 4), v_h_241, v_t_2419));
      V v_k_2422 = ({ V rv_4 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_k_2420, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      v_f_2423 = ({ V rv_8 = v_k_2422; V rr_ = heff_rec_reuse_nf(v_p_243, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2423}});
  }
  case TAG_Just: {
    heff_drop(v_h_241);
    heff_drop(v_b_242);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_h_2413 = args[1];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_get_n(heff_get_n(v_p_243, 7, 10), 2, 7);
  HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_h_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      heff_drop(v_x_2418);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2413, v_acc_2412});
    } else {
      heff_drop(v_h_2413);
      heff_drop(v_field_2417);
      return v_acc_2412;
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_240, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_seen_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_240, v_x_243, NTAG(TAG_MkUnit)));
        V t_0 = v_t_2411;
        V t_1 = v_xs_244;
        V t_2 = v_cell_249;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eoneDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneDef_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eoneDef(V v_d_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_d_240, v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneDef(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2erecipeAsks_str0, 0, "");
V g_heff_2ecompile_2esimplify_2erecipeAsks_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2erecipeAsks_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2erecipeAsks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecipeAsks_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecipeAsks(V v_st_240, V v_h_241, V v_r_242) {
top: ;
  V v_kp_243 = heff_take_field(v_st_240, 8);
  V v_sp_244 = heff_get_n(v_st_240, 7, 10);
  V v_vers_245 = heff_get_n(v_kp_243, 0, 5);
  V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(v_r_242));
  V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
  V v_t_2413 = (g_list_2efoldl_24f1428393365x1980555854(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2esimplify_2erecipeAsks_lam0, 1, 2, (V[]){heff_dup(v_h_241), v_sp_244}), v_t_247));
  V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2413));
  V v_t_2415 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2414));
  return (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2erecipeAsks_lam1, 1, 1, (V[]){v_vers_245}), v_t_2415));
}
V g_heff_2ecompile_2esimplify_2erecipeAsks_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2erecipeAsks(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2erecipeAsks_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_x_248, v_h_241, 0)) {
    heff_drop(v_h_241);
    HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_sp_244, 2, 7); V a_1 = v_x_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_248); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
      heff_drop(v_field_2411);
      return v_ret_24bool;
    }
  } else {
    heff_drop(v_x_248);
    heff_drop(v_h_241);
    heff_drop_rec(v_sp_244, 7);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2erecipeAsks_lam1(V self, V *args) {
  V v_h_2416 = args[0];
  V v_vers_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = ({ V a_0 = v_vers_245; V a_1 = v_h_2416; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_vers_245); r_; });
  V v_t_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2419;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2419);
      v_t_2421 = ((V)&g_heff_2ecompile_2esimplify_2erecipeAsks_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2416, v_t_2421});
}
Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyItems_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esimplifyItems(V v_n0_240, V v_sg_241, V v_vers_242, V v_kept_243, V v_items_244) {
top: ;
  V v_safe_245 = heff_take_field(v_sg_241, 0);
  V v_total_246 = heff_get_n(v_sg_241, 1, 2);
  V v_t_247 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_248 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_242, v_kept_243, NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
  HeffT2 v_t_249 = (g_prelude_2etraverse_24s1182736556x1844399207_24cpr(v_items_244, heff_rec_n(10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_safe_245), v_safe_245, v_total_246, heff_dup(g_std_2eordmap_2eempty_get()), v_t_247, v_t_248, heff_dup(g_std_2eordmap_2eempty_get())})));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_out_2412 = v_field_2410;
    V v_st_2413 = v_field_2411;
    V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_2412)));
    V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_2412)));
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_list_2emap_24s1937570095x2110149801(v_out_2412));
    V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = ({ V a_0 = heff_dup(v_st_2413); V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2419); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2415, heff_get_n(v_st_2413, 0, 10), v_t_2417, v_t_2420});
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyItems(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2easkedAs_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkedAs_24tok2_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2easkedAs_24tok2(V v_tok_240, V v_h_241, V v_kc_242, V v_b_243, V v_x4_244, V v_p_245) {
top: ;
  V v_depth_246 = heff_take_field(v_kc_242, 3);
  V v_safe_247 = heff_get_n(v_kc_242, 4, 6);
  if ((heff_dup(v_x4_244) == NTAG(TAG_True))) {
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_243, v_p_245));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_241), v_x_2411, v_depth_246, v_s_2412));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_x_2416 = v_field_2414;
        heff_drop(v_x_2416);
        V v_s_2417 = v_field_2415;
        V v_x1_2418 = v_safe_247;
        V v_h_2419 = v_h_241;
        V v_p_2420 = v_s_2417;
        V v_x2_2432;
        if ((heff_dup(v_x1_2418) == NTAG(TAG_True))) {
          heff_drop(v_x1_2418);
          V v_t_2421 = heff_take_field(v_p_2420, 0);
          V v_t_2422 = heff_take_field(v_p_2420, 1);
          V v_t_2423 = heff_take_field(v_p_2420, 2);
          V v_t_2424 = heff_take_field(v_p_2420, 3);
          V v_t_2425 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_p_2420, 4), heff_dup(v_h_2419), NTAG(TAG_MkUnit)));
          V v_t_2426 = heff_take_field(v_p_2420, 5);
          V v_t_2427 = heff_take_field(v_p_2420, 6);
          V v_t_2428 = heff_take_field(v_p_2420, 7);
          V v_t_2429 = heff_take_field(v_p_2420, 8);
          V v_t_2430 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2424, v_h_2419, NTAG(TAG_MkUnit)));
          V v_t_2431 = ({ V rv_0 = v_t_2421; V rv_1 = v_t_2422; V rv_2 = v_t_2423; V rv_3 = v_t_2430; V rv_4 = v_t_2425; V rv_5 = v_t_2426; V rv_6 = v_t_2427; V rv_7 = v_t_2428; V rv_8 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_p_2420, 512ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 786432u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
          v_x2_2432 = heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2431});
        } else {
          heff_drop(v_x1_2418);
          heff_drop(v_h_2419);
          v_x2_2432 = heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_2420});
        }
        switch (heff_tag_of(v_x2_2432)) {
        case TAG_MkPair: {
          V v_s_2434 = heff_field(v_x2_2432, 1);
          V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 2ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_2434});
        }
        default: return heff_nomatch(v_x2_2432);
        }
      }
    }
  } else {
    heff_drop(v_b_243);
    heff_drop(v_depth_246);
    heff_drop(v_safe_247);
    HeffT2 v_t_2436 = (g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(heff_clo_n(g_heff_2ecompile_2esimplify_2easkedAs_24tok2_lam0, 1, 1, (V[]){v_h_241}), v_p_245));
    {
      V v_field_2437 = v_t_2436.f[0];
      V v_field_2438 = v_t_2436.f[1];
      V v_x_2439 = v_field_2437;
      heff_drop(v_x_2439);
      V v_s_2440 = v_field_2438;
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2440});
    }
  }
}
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2easkedAs_24tok2(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2_lam0(V self, V *args) {
  V v_m_2435 = args[0];
  V v_h_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_2435; V a_1 = v_h_241; V r_ = (g_std_2eordmap_2edelete_24s2135745297x1725920174(a_0, a_1)); heff_drop(v_h_241); r_; });
}