// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eetaArg_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2eetaLets(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V);
V g_heff_2ecompile_2esimplify_2einlinedCall(V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknownMade_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2emovesFirst(V, V);
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
HeffT2 g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eunLam(V, V);
V g_heff_2ecompile_2esimplify_2eunLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunLam_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
HeffT2 g_map_2elookup_24s659669741x1036301430_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2esimplify_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      V v_cell_246 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eletsOf_24dps(v_rest_243, v_body_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V v_x1_240, V v_body_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_body_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_243, 0);
      V v_a_246 = heff_field(v_x11_243, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_245), heff_dup(v_a_246), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_244;
      V t_1 = v_body_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_body_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eflat_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eflat(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2esimplify_2eflat_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eflat(a[0]);
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureOrPartial_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epureOrPartial(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_248 = heff_field(v_e_241, 0);
        V v_as_249 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_249), v_f_248));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EGlobal: {
    V v_t_2439 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2439);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2439);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_2444 = heff_field(v_e_241, 0);
        V v_as_2445 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_2445), v_f_2444));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_ELam: {
    V v_t_2476 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2476);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2476);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_2481 = heff_field(v_e_241, 0);
        V v_as_2482 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_2482), v_f_2481));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EApp: {
    V v_t_24113 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24113);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24113);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24118 = heff_field(v_e_241, 0);
        V v_as_24119 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24119), v_f_24118));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_ELet: {
    V v_a_24149 = heff_field(v_e_241, 1);
    V v_b_24150 = heff_field(v_e_241, 2);
    V v_t_24151 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_240), v_a_24149));
    if ((heff_dup(v_t_24151) == NTAG(TAG_True))) {
      heff_drop(v_t_24151);
      V t_0 = v_s_240;
      V t_1 = v_b_24150;
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24151);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_t_24154 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24154) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24154);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24154);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24159 = heff_field(v_e_241, 0);
        V v_as_24160 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24160), v_f_24159));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EProj: {
    V v_t_24193 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24193) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24193);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24193);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24198 = heff_field(v_e_241, 0);
        V v_as_24199 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24199), v_f_24198));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_ETag: {
    V v_as_24229 = heff_field(v_e_241, 1);
    V v_t_24231 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureOrPartial_clo), 1, (V[]){v_s_240}));
    V v_t_24232 = (g_list_2emap(v_t_24231, heff_dup(v_as_24229)));
    return ({ V a_0 = v_t_24232; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24232); r_; });
  }
  case TAG_EMatch: {
    V v_sc_24233 = heff_field(v_e_241, 0);
    V v_arms_24234 = heff_field(v_e_241, 1);
    V v_t_24235 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_sc_24233));
    if ((heff_dup(v_t_24235) == NTAG(TAG_True))) {
      heff_drop(v_t_24235);
      switch (heff_tag_of(v_arms_24234)) {
      case TAG_Nil: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_24243 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureOrPartial_lam0, 1, 1, (V[]){v_s_240}), heff_dup(v_arms_24234)));
        return ({ V a_0 = v_t_24243; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24243); r_; });
      }
      default: return heff_nomatch(v_arms_24234);
      }
    } else {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24235);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    V v_t_24245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24245) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24245);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24250 = heff_field(v_e_241, 0);
        V v_as_24251 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24251), v_f_24250));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_24282 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24282) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24282);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24282);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24287 = heff_field(v_e_241, 0);
        V v_as_24288 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24288), v_f_24287));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_ECall: {
    V v_t_24319 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24319) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24319);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24319);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24324 = heff_field(v_e_241, 0);
        V v_as_24325 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24325), v_f_24324));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EInt: {
    V v_t_24355 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24355) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24355);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24355);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24360 = heff_field(v_e_241, 0);
        V v_as_24361 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24361), v_f_24360));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EFloat: {
    V v_t_24391 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24391) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24391);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24391);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24396 = heff_field(v_e_241, 0);
        V v_as_24397 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24397), v_f_24396));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EStr: {
    V v_t_24427 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24427) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24427);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24427);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24432 = heff_field(v_e_241, 0);
        V v_as_24433 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24433), v_f_24432));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EBytes: {
    V v_t_24463 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24463) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24463);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24463);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24468 = heff_field(v_e_241, 0);
        V v_as_24469 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24469), v_f_24468));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EFixed: {
    V v_t_24500 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24500) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24500);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24500);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24505 = heff_field(v_e_241, 0);
        V v_as_24506 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24506), v_f_24505));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EFloat32: {
    V v_t_24536 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24536) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24536);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24536);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24541 = heff_field(v_e_241, 0);
        V v_as_24542 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24542), v_f_24541));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EAbandon: {
    V v_t_24571 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24571) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24571);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24571);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24576 = heff_field(v_e_241, 0);
        V v_as_24577 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24577), v_f_24576));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  case TAG_EFix: {
    V v_t_24608 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_24608) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_24608);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_24608);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EVar: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        V v_f_24613 = heff_field(v_e_241, 0);
        V v_as_24614 = heff_field(v_e_241, 1);
        return (g_heff_2ecompile_2esimplify_2epartialHead(v_s_240, heff_dup(v_as_24614), v_f_24613));
      }
      case TAG_ELet: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epureOrPartial(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_lam0(V self, V *args) {
  V v_b_24238 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24242;
  switch (heff_tag_of(v_b_24238)) {
  case TAG_MkArm: {
    V v_b_24241 = heff_field(v_b_24238, 2);
    heff_take_n(v_b_24238, 4ULL, 3);
    v_t_24242 = v_b_24241;
    break;
  }
  default: heff_nomatch(v_b_24238);
  }
  return ({ V a_0 = v_s_240; V a_1 = v_t_24242; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop(v_t_24242); r_; });
}
Clo g_heff_2ecompile_2esimplify_2eetaHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_x1_244 = (g_heff_2ecompile_2esimplify_2eelemStr(heff_dup(v_y_243), v_xs_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
    heff_drop(v_x1_244);
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x3_242, 0);
    HeffT2 v_t_246 = (g_map_2elookup_24s659669741x1036301430_24cpr(heff_dup(v_g_245), v_kinds_240));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_2410 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_2410); c_; })));
      heff_drop(v_field_248);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eetaHead(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_as_243) {
top: ;
  V v_a_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_247;
  if (heff_intLe_c(heff_dup(v_a_244), heff_dup(v_b_245))) {
    heff_drop(v_b_245);
    v_t_247 = v_a_244;
  } else {
    heff_drop(v_a_244);
    v_t_247 = v_b_245;
  }
  V v_t_248 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_247, heff_dup(v_xs_241)));
  V v_a_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_2412;
  if (heff_intLe_c(heff_dup(v_a_249), heff_dup(v_b_2410))) {
    heff_drop(v_b_2410);
    v_t_2412 = v_a_249;
  } else {
    heff_drop(v_a_249);
    v_t_2412 = v_b_2410;
  }
  V v_t_2413 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2412, heff_dup(v_as_243)));
  V v_t_2414 = (g_heff_2ecompile_2esimplify_2ezipL(v_t_248, v_t_2413));
  V v_x_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_a_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_2419;
  if (heff_intLe_c(heff_dup(v_a_2416), heff_dup(v_b_2417))) {
    heff_drop(v_b_2417);
    v_t_2419 = v_a_2416;
  } else {
    heff_drop(v_a_2416);
    v_t_2419 = v_b_2417;
  }
  V v_t_2426;
  if (heff_intLt_c(v_t_2419, v_x_2415)) {
    V v_a_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_b_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2424;
    if (heff_intLe_c(heff_dup(v_a_2421), heff_dup(v_b_2422))) {
      heff_drop(v_b_2422);
      v_t_2424 = v_a_2421;
    } else {
      heff_drop(v_a_2421);
      v_t_2424 = v_b_2422;
    }
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2424, heff_dup(v_xs_241)));
    v_t_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2425, v_b_242});
  } else {
    v_t_2426 = v_b_242;
  }
  V v_t_2427 = ({ V a_0 = v_t_2414; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_m_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2427}));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_lam0, 1, 4, (V[]){v_m_2428, v_xs_241, v_as_243, v_r_240});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_a_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_b_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2436;
    if (heff_intLe_c(heff_dup(v_a_2433), heff_dup(v_b_2434))) {
      heff_drop(v_b_2434);
      v_t_2436 = v_a_2433;
    } else {
      heff_drop(v_a_2433);
      v_t_2436 = v_b_2434;
    }
    V v_t_2437 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2436, v_as_243));
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_2431;
    heff_room[1] = v_t_2437;
    heff_room[2] = v_s_2432;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2ecompile_2esimplify_2ecapturing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecapturing_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecapturing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(MK_INT(60LL), v_x_246)) {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      return NTAG(TAG_False);
    } else {
      return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsNothing(b_0)); heff_drop(b_0); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecapturing(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x2_241);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_241, 0);
      V v_xs_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_245);
        V t_0 = v_ms_244;
        V t_1 = v_xs_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_xs_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2echeap_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2echeap(V v_safe_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    heff_drop(v_all_241);
    HeffT2 v_t_245 = ({ V a_0 = heff_dup(v_g_244); V a_1 = v_safe_240; HeffT2 r_ = (g_map_2elookup_24s659669741x1036301430_24cpr(a_0, a_1)); heff_drop(v_safe_240); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_247);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ELam: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_x31_2412 = heff_field(v_x3_242, 0);
    V v_as_2413 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_EVar: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_x31_2412, 0);
      V v_x_2416 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, heff_dup(v_g_2415)));
      V v_y_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2413));
      V v_x_2421;
      if (heff_intLt_c(v_y_2417, v_x_2416)) {
        V v_t_2419 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, heff_dup(v_g_2415)));
        V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2413));
        v_x_2421 = heff_intSub(v_t_2419, v_t_2420);
      } else {
        v_x_2421 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_x_2421)) {
        V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2424 = (g_list_2emap(v_t_2423, heff_dup(v_as_2413)));
        return ({ V a_0 = v_t_2424; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2424); r_; });
      } else {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_ELam: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  case TAG_ELet: {
    V v_a_2458 = heff_field(v_x3_242, 1);
    V v_b_2459 = heff_field(v_x3_242, 2);
    V v_t_2460 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_2458));
    if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
      heff_drop(v_t_2460);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2459;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2460);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2461 = heff_field(v_x3_242, 0);
    V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
    V v_t_2464 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2461)));
    V v_t_2465 = (g_list_2emap(v_t_2463, v_t_2464));
    return ({ V a_0 = v_t_2465; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2465); r_; });
  }
  case TAG_EProj: {
    V v_e_2466 = heff_field(v_x3_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_all_241;
    V t_2 = v_e_2466;
    v_safe_240 = t_0;
    v_all_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2471 = heff_field(v_x3_242, 1);
    V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
    V v_t_2474 = (g_list_2emap(v_t_2473, heff_dup(v_as_2471)));
    return ({ V a_0 = v_t_2474; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2474); r_; });
  }
  case TAG_EMatch: {
    V v_sc_2475 = heff_field(v_x3_242, 0);
    V v_arms_2476 = heff_field(v_x3_242, 1);
    V v_t_2477 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_sc_2475));
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop(v_t_2477);
      switch (heff_tag_of(v_arms_2476)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2481 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2476)));
        V v_t_2482 = (g_list_2emap(v_t_2480, v_t_2481));
        return ({ V a_0 = v_t_2482; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2482); r_; });
      }
      default: return heff_nomatch(v_arms_2476);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2477);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2484 = heff_field(v_x3_242, 0);
    V v_as_2485 = heff_field(v_x3_242, 1);
    V v_x1_2486 = ({ V a_0 = heff_dup(v_p_2484); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2486) == NTAG(TAG_True))) {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_x1_2486);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2486);
      V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
      V v_t_2488 = (g_list_2emap(v_t_2487, heff_dup(v_as_2485)));
      return ({ V a_0 = v_t_2488; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2488); r_; });
    }
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2echeap(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLets_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eetaLets(V v_r_240, V v_x2_241, V v_x3_242, V v_rest_243, V v_z_244) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkPair: {
      V v_bds_245 = heff_field(v_x3_242, 0);
      V v_a_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      HeffT2 v_t_247 = ({ V a_0 = v_r_240; V b_1 = NTAG(TAG_True); V a_2 = v_a_246; V a_3 = v_rest_243; V a_4 = v_z_244; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2eetaArg_24cpr(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_x_2410 = v_field_248;
        V v_s_2411 = v_field_249;
        V v_x_2415;
        switch (heff_tag_of(v_x_2410)) {
        case TAG_MkPair: {
          V v_rest_2412 = heff_field(v_x_2410, 0);
          V v_as_2413 = heff_field(v_x_2410, 1);
          heff_take_n(v_x_2410, 3ULL, 2);
          V v_t_2414 = (g_heff_2ecompile_2esimplify_2eappendL(v_bds_245, v_rest_2412));
          v_x_2415 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_as_2413});
          break;
        }
        default: heff_nomatch(v_x_2410);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_s_2411});
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  } else {
    heff_drop(v_r_240);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkPair: {
      V v_bds_2416 = heff_field(v_x3_242, 0);
      V v_a_2417 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2420;
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_dup(heff_field(v_rest_243, 0));
        v_t_2420 = v_x_2418;
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      V v_t_2421 = ({ V a_0 = v_bds_2416; V a_1 = v_a_2417; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2416); r_; });
      V v_t_2424;
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_y_2423 = heff_field(v_rest_243, 1);
        heff_take_n(v_rest_243, 2ULL, 2);
        v_t_2424 = v_y_2423;
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      V v_x_2425 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2424})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_z_244});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaLets(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_f_243 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_243, v_p_241}});
  }
  case TAG_EGlobal: {
    V v_f_245 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_245, v_p_241}});
  }
  case TAG_ELam: {
    V v_f_248 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_248, v_p_241}});
  }
  case TAG_EApp: {
    V v_f_2411 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2411, v_p_241}});
  }
  case TAG_ELet: {
    V v_a_2413 = heff_field(v_x1_240, 1);
    V v_e_2414 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2415 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_a_2413; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop(v_a_2413); r_; });
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V t_0 = v_e_2414;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    } else {
      heff_drop(v_e_2414);
      heff_drop(v_t_2415);
      return ((HeffT2){{NTAG(TAG_False), v_p_241}});
    }
  }
  case TAG_ERecord: {
    V v_f_2418 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2418, v_p_241}});
  }
  case TAG_EProj: {
    V v_f_2423 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 4); r_; });
    return ((HeffT2){{v_f_2423, v_p_241}});
  }
  case TAG_ETag: {
    V v_f_2427 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 3); r_; });
    return ((HeffT2){{v_f_2427, v_p_241}});
  }
  case TAG_EMatch: {
    V v_f_2430 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2430, v_p_241}});
  }
  case TAG_EPrim: {
    V v_f_2432 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2432, v_p_241}});
  }
  case TAG_EPrimCall: {
    V v_f_2435 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2435, v_p_241}});
  }
  case TAG_ECall: {
    V v_f_2438 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2438, v_p_241}});
  }
  case TAG_EInt: {
    V v_f_2440 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2440, v_p_241}});
  }
  case TAG_EFloat: {
    V v_f_2442 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2442, v_p_241}});
  }
  case TAG_EStr: {
    V v_f_2444 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2444, v_p_241}});
  }
  case TAG_EBytes: {
    V v_f_2446 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2446, v_p_241}});
  }
  case TAG_EFixed: {
    V v_f_2449 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2449, v_p_241}});
  }
  case TAG_EFloat32: {
    V v_f_2451 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2451, v_p_241}});
  }
  case TAG_EAbandon: {
    V v_f_2452 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2452, v_p_241}});
  }
  case TAG_EFix: {
    V v_f_2455 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2455, v_p_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emovesFirst_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emovesFirst(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_True);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emovesFirst(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_g_240; V a_1 = v_t_243; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_it1_248 = v_field_246;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_EVar: {
        heff_take_n(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_248, 0ULL, 3);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ERecord: {
        V v_fs_2418 = heff_field(v_it1_248, 0);
        heff_take_n(v_it1_248, 1ULL, 2);
        HeffT2 v_t_2420 = (g_heff_2ecompile_2esimplify_2efieldIn_24cpr(v_l_241, v_fs_2418));
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_v_2424 = v_field_2422;
            V v_t_2425 = (g_heff_2ecompile_2eir_2eisValue(v_v_2424));
            if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
              heff_drop(v_t_2425);
              if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
                V v_t_2427 = heff_intSub(heff_take_field(v_s_242, 1), MK_INT(1LL));
                V v_t_2428 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_s_242, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                HeffT2 v_t_2429 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_v_2424, v_t_2428));
                {
                  V v_field_2430 = v_t_2429.f[0];
                  V v_field_2431 = v_t_2429.f[1];
                  V v_x_2432 = v_field_2430;
                  V v_s_2433 = v_field_2431;
                  return ((HeffT2){{heff_tag_n(TAG_Just, 1, (V[]){v_x_2432}), v_s_2433}});
                }
              } else {
                heff_drop(v_v_2424);
                return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
              }
            } else {
              heff_drop(v_v_2424);
              heff_drop(v_t_2425);
              return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
            }
          } else {
            heff_drop(v_field_2422);
            return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
          }
        }
      }
      case TAG_EProj: {
        heff_take_n(v_it1_248, 0ULL, 4);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_248, 0ULL, 3);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_248, 0ULL, 1);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EAbandon: {
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_248, 0ULL, 2);
        heff_drop(v_l_241);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_248)}});
      }
    } else {
      heff_drop(v_l_241);
      heff_drop(v_field_246);
      return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eknownMade_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = heff_dup(v_h_240); V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b_241), heff_dup(g_map_2eempty_get())));
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_dup(v_h_240); V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_f_2411;
  if (heff_intLt_c(v_t_244, v_t_246)) {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
    V v_x_249 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_248));
    if (heff_intLt_c(MK_INT(1200LL), v_x_249)) {
      heff_drop(v_h_240);
      heff_drop(v_b_241);
      v_f_2411 = v_s_242;
    } else {
      v_f_2411 = (g_heff_2ecompile_2esimplify_2erecordAll(v_h_240, v_b_241, v_s_242));
    }
  } else {
    heff_drop(v_h_240);
    heff_drop(v_b_241);
    v_f_2411 = v_s_242;
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2411}});
}
V g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V v_x1_240, V v_h_241, V v_b_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
    V v_hs_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_243, 8)), 4, 5);
    HeffT2 v_t_247 = ({ V a_0 = heff_dup(v_h_241); V a_1 = v_t_246; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_f_2425;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2412;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_249;
        v_t_2412 = v_x_2411;
      } else {
        heff_drop(v_field_249);
        v_t_2412 = NTAG(TAG_Nil);
      }
      V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0, 2, 1, (V[]){heff_dup(v_p_243)}); V a_1 = v_t_2412; V a_2 = v_hs_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_245); r_; });
      V v_k_2422 = heff_take_field(v_p_243, 8);
      V v_t_2423 = (g_map_2einsert_24s1341440536x470972936(v_h_241, v_t_2421, heff_take_field(v_k_2422, 4)));
      V v_k_2424 = ({ V rv_4 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_k_2422, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      v_f_2425 = ({ V rv_8 = v_k_2424; V rr_ = heff_rec_reuse_nf(v_p_243, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2425}});
  }
  case TAG_Just: {
    heff_drop(v_h_241);
    heff_drop(v_b_242);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_h_2414 = args[1];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_get_n(heff_get_n(v_p_243, 7, 9), 2, 7);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_h_2414); V a_1 = v_t_2415; HeffT2 r_ = (g_map_2elookup_24s659669741x1036301430_24cpr(a_0, a_1)); heff_drop(v_t_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2418;
      heff_drop(v_x_2420);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2414, v_acc_2413});
    } else {
      heff_drop(v_h_2414);
      heff_drop(v_field_2418);
      return v_acc_2413;
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2eunLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunLam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunLam(V v_e_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_240, 0);
    V v_b_245 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2ezipL(v_ys_244, v_as_241));
    return ({ V a_0 = v_t_246; V a_1 = v_b_245; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_as_241);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eunLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunLam(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2einlinedCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlinedCall_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2einlinedCall(V v_h_240, V v_lam1_241, V v_as_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_lam1_241)) {
  case TAG_EVar: {
    V v_ru_24lam1_241_24EVar = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_245 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EVar, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_z_243});
  }
  case TAG_EGlobal: {
    V v_ru_24lam1_241_24EGlobal = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_247 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EGlobal, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_z_243});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_lam1_241, 0);
    V v_b_249 = heff_field(v_lam1_241, 1);
    V v_ru_24lam1_241_24ELam = heff_take_reuse_n(v_lam1_241, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    if (heff_intEq_c(v_t_2410, v_t_2411)) {
      heff_drop(v_h_240);
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_at_n(v_ru_24lam1_241_24ELam, TAG_ELam, 2, (V[]){v_xs_248, v_b_249}), v_z_243));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_x_2416 = v_field_2414;
        V v_s_2417 = v_field_2415;
        V v_x_2418 = (g_heff_2ecompile_2esimplify_2eunLam(v_x_2416, v_as_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_s_2417});
      }
    } else {
      heff_drop(v_xs_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24lam1_241_24ELam, 2);
      V v_t_2419 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_z_243});
    }
  }
  case TAG_EApp: {
    V v_ru_24lam1_241_24EApp = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2422 = heff_tag_at_n(v_ru_24lam1_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_z_243});
  }
  case TAG_ELet: {
    heff_take_n(v_lam1_241, 0ULL, 3);
    V v_t_2426 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_z_243});
  }
  case TAG_ERecord: {
    V v_ru_24lam1_241_24ERecord = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2429 = heff_tag_at_n(v_ru_24lam1_241_24ERecord, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_z_243});
  }
  case TAG_EProj: {
    heff_take_n(v_lam1_241, 0ULL, 4);
    V v_t_2434 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_z_243});
  }
  case TAG_ETag: {
    heff_take_n(v_lam1_241, 0ULL, 3);
    V v_t_2438 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_z_243});
  }
  case TAG_EMatch: {
    V v_ru_24lam1_241_24EMatch = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2441 = heff_tag_at_n(v_ru_24lam1_241_24EMatch, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_z_243});
  }
  case TAG_EPrim: {
    V v_ru_24lam1_241_24EPrim = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2443 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EPrim, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_z_243});
  }
  case TAG_EPrimCall: {
    V v_ru_24lam1_241_24EPrimCall = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2446 = heff_tag_at_n(v_ru_24lam1_241_24EPrimCall, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_z_243});
  }
  case TAG_ECall: {
    V v_ru_24lam1_241_24ECall = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2449 = heff_tag_at_n(v_ru_24lam1_241_24ECall, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, v_z_243});
  }
  case TAG_EInt: {
    V v_ru_24lam1_241_24EInt = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2451 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EInt, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_z_243});
  }
  case TAG_EFloat: {
    V v_ru_24lam1_241_24EFloat = heff_take_reuse_na(v_lam1_241, 0ULL, 1);
    V v_t_2453 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EFloat, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_z_243});
  }
  case TAG_EStr: {
    V v_ru_24lam1_241_24EStr = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2455 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EStr, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_z_243});
  }
  case TAG_EBytes: {
    V v_ru_24lam1_241_24EBytes = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2457 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EBytes, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2457, v_z_243});
  }
  case TAG_EFixed: {
    V v_ru_24lam1_241_24EFixed = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2460 = heff_tag_at_n(v_ru_24lam1_241_24EFixed, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2460, v_z_243});
  }
  case TAG_EFloat32: {
    V v_ru_24lam1_241_24EFloat32 = heff_take_reuse_na(v_lam1_241, 0ULL, 1);
    V v_t_2462 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EFloat32, TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_z_243});
  }
  case TAG_EAbandon: {
    V v_t_2463 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_z_243});
  }
  case TAG_EFix: {
    V v_ru_24lam1_241_24EFix = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2466 = heff_tag_at_n(v_ru_24lam1_241_24EFix, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_as_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2466, v_z_243});
  }
  default: return heff_nomatch(v_lam1_241);
  }
}
V g_heff_2ecompile_2esimplify_2einlinedCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlinedCall(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_map_2elookup_24s659669741x1036301430_24cpr(heff_dup(v_x_243), v_seen_240));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_seen_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(v_x_243, NTAG(TAG_MkUnit), v_seen_240));
        V t_0 = v_t_2412;
        V t_1 = v_xs_244;
        V t_2 = v_cell_2410;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2esgItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgItem_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esgItem(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2eflat(heff_dup(heff_rfield(v_d_242, 2))));
    return ({ V a_0 = v_acc_240; V a_1 = heff_dup(heff_rfield(v_d_242, 0)); V a_2 = v_t_243; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  }
  case TAG_Kept: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_t_246 = heff_dup(heff_rfield(v_k_244, 5));
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_k_244, 0)), NTAG(TAG_MkUnit), heff_dup(heff_rfield(v_acc_240, 0))));
    } else {
      heff_drop(v_t_246);
      v_t_247 = heff_dup(heff_rfield(v_acc_240, 0));
    }
    V v_t_249;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_k_244, 6)))) {
      v_t_249 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_k_244, 0)), heff_dup(heff_rfield(v_k_244, 6)), heff_get_n(v_acc_240, 1, 2)));
    } else {
      v_t_249 = heff_get_n(v_acc_240, 1, 2);
    }
    return heff_rec_n(2, shape_safe__total, (V[]){v_t_247, v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2esgItem(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyItems_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esimplifyItems(V v_n0_240, V v_sg_241, V v_vers_242, V v_kept_243, V v_items_244) {
top: ;
  V v_t_245 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_246 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_242, v_kept_243, NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
  V v_t_247 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_sg_241, 0)), heff_dup(heff_rfield(v_sg_241, 0)), heff_get_n(v_sg_241, 1, 2), heff_dup(g_map_2eempty_get()), v_t_245, v_t_246});
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_24cpr(v_items_244, v_t_247));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_out_2411 = v_field_249;
    V v_st_2412 = v_field_2410;
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_2411)));
    V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_2411)));
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2emap_24s1937570095x2110149801(v_out_2411));
    V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = ({ V a_0 = heff_dup(v_st_2412); V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2418); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2414, heff_get_n(v_st_2412, 0, 9), v_t_2416, v_t_2419});
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyItems(a[0], a[1], a[2], a[3], a[4]);
}