// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2esimplify_2eapplyArm(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V);
V g_heff_2ecompile_2esimplify_2efollowerPushed(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerPushed_clo;
V g_heff_2ecompile_2esimplify_2ehandlerPushed(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerPushed_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownMade_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo;
V g_heff_2ecompile_2esimplify_2epartialIn(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialIn_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushBound(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2erunsGiven(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erunsGiven_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2eunLam(V, V);
V g_heff_2ecompile_2esimplify_2eunLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunLam_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1182736556x1844399207_24cpr(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
Clo g_heff_2ecompile_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      V v_cell_246 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2esimplify_2eletsOf_24dps(v_rest_243, v_body_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eflat_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eflat(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2esimplify_2eflat_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eflat(a[0]);
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureOrPartial_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epureOrPartial(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EGlobal: {
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_ELam: {
    V v_t_248 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EApp: {
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_ELet: {
    V v_a_2413 = heff_field(v_e_241, 1);
    V v_b_2414 = heff_field(v_e_241, 2);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_240), v_a_2413));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V t_0 = v_s_240;
      V t_1 = v_b_2414;
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2415);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2418);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2418);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EProj: {
    V v_t_2423 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2423);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2423);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_ETag: {
    V v_argv_2425 = heff_field(v_e_241, 1);
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureOrPartial_clo), 1, (V[]){v_s_240}));
    V v_t_2428 = (g_list_2emap(v_t_2427, heff_dup(v_argv_2425)));
    return ({ V a_0 = v_t_2428; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2428); r_; });
  }
  case TAG_EMatch: {
    V v_sc_2429 = heff_field(v_e_241, 0);
    V v_arms_2430 = heff_field(v_e_241, 1);
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_sc_2429));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_t_2431);
      switch (heff_tag_of(v_arms_2430)) {
      case TAG_Nil: {
        heff_drop_rec(v_s_240, 9);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureOrPartial_lam0, 1, 1, (V[]){v_s_240}), heff_dup(v_arms_2430)));
        return ({ V a_0 = v_t_2439; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2439); r_; });
      }
      default: return heff_nomatch(v_arms_2430);
      }
    } else {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2431);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    V v_t_2441 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2441);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2441);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2444 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2444);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2444);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_ECall: {
    V v_t_2447 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2447);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2447);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EInt: {
    V v_t_2449 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2449);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2449);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EFloat: {
    V v_t_2451 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2451);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2451);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EStr: {
    V v_t_2453 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2453);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2453);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EBytes: {
    V v_t_2455 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2455);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2455);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EFixed: {
    V v_t_2458 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2458);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2458);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EFloat32: {
    V v_t_2460 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2460);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2460);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EAbandon: {
    V v_t_2461 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2461);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2461);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EBool: {
    V v_t_2463 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2463);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2463);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_ESet: {
    V v_t_2467 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2467);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2467);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EValues: {
    V v_t_2469 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2469);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2469);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  case TAG_EFix: {
    V v_t_2472 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_240, 3), heff_rfield(v_s_240, 5), v_e_241));
    if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_t_2472);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2472);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epartialIn(v_s_240, v_e_241);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epureOrPartial(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2epureOrPartial_lam0(V self, V *args) {
  V v_b_2434 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438;
  switch (heff_tag_of(v_b_2434)) {
  case TAG_MkArm: {
    V v_b_2437 = heff_field(v_b_2434, 2);
    heff_take_n(v_b_2434, 4ULL, 3);
    v_t_2438 = v_b_2437;
    break;
  }
  default: heff_nomatch(v_b_2434);
  }
  return ({ V a_0 = v_s_240; V a_1 = v_t_2438; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop(v_t_2438); r_; });
}
Clo g_heff_2ecompile_2esimplify_2erunsGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erunsGiven_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2erunsGiven(V v_x_240, V v_a_241, V v_b_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_a1_246 = heff_field(v_a_241, 0);
    V v_body_247 = heff_field(v_a_241, 1);
    heff_take_n(v_a_241, 3ULL, 2);
    switch (heff_tag_of(v_a1_246)) {
    case TAG_Nil: {
      heff_drop(v_b_242);
      heff_drop(v_o_243);
      heff_drop(v_body_247);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_c_248 = heff_field(v_a1_246, 0);
      V v_cs_249 = heff_field(v_a1_246, 1);
      heff_take_n(v_a1_246, 3ULL, 2);
      V v_ret_24bool = heff_bool((heff_intLe_c_lent(v_o_243, MK_INT(2LL), 2) && ({ V v_t_2410 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_248), heff_dup(v_cs_249)}), heff_dup(v_body_247)}); int c_ = ({ V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_t_2410), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2412 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), heff_dup(v_t_2411))); int c_ = (heff_intLt_c_lent(MK_INT(160LL), v_x_2412, 1) ? 0 : ({ V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_body_247), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2414 = (g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(v_c_248, MK_INT(0LL), heff_dup(v_t_2413))); int c_ = (heff_intLt_c_lent(MK_INT(0LL), v_x_2414, 1) && ({ V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2451 = (g_heff_2ecompile_2esimplify_2ecallsW_24s1838112203x174474492(v_x_240, MK_INT(0LL), heff_dup(v_t_2415))); int c_ = heff_intEq_c_lent(v_t_2451, v_o_243, 0); heff_drop(v_t_2451); c_; }); heff_drop(v_t_2415); c_; })); heff_drop(v_x_2414); c_; }); heff_drop(v_t_2413); c_; })); heff_drop(v_x_2412); c_; }); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; })));
      heff_drop(v_b_242);
      heff_drop(v_o_243);
      heff_drop(v_body_247);
      heff_drop(v_c_248);
      heff_drop(v_cs_249);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_a1_246);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    heff_drop(v_o_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2erunsGiven_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2erunsGiven(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_x1_244 = (g_heff_2ecompile_2esimplify_2eelemStr(v_y_243, v_xs_241));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
    heff_drop(v_x1_244);
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x3_242, 0);
    HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_kinds_240, v_g_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_249); c_; })));
      heff_drop(v_field_248);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eetaHead(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_argv_243) {
top: ;
  V v_simp_244 = heff_take_field(v_r_240, 0);
  V v_applyTo_245 = heff_get_n(v_r_240, 1, 4);
  V v_a_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_248;
  if (heff_intLe_c_lent(v_a_246, v_b_247, 0)) {
    heff_drop(v_b_247);
    v_t_248 = v_a_246;
  } else {
    heff_drop(v_a_246);
    v_t_248 = v_b_247;
  }
  V v_t_249 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_248, heff_dup(v_xs_241)));
  V v_a_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_2412;
  if (heff_intLe_c_lent(v_a_2410, v_b_2411, 0)) {
    heff_drop(v_b_2411);
    v_t_2412 = v_a_2410;
  } else {
    heff_drop(v_a_2410);
    v_t_2412 = v_b_2411;
  }
  V v_t_2413 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2412, heff_dup(v_argv_243)));
  V v_t_2414 = (g_heff_2ecompile_2esimplify_2ezipL(v_t_249, v_t_2413));
  V v_x_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_a_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_2418;
  if (heff_intLe_c_lent(v_a_2416, v_b_2417, 0)) {
    heff_drop(v_b_2417);
    v_t_2418 = v_a_2416;
  } else {
    heff_drop(v_a_2416);
    v_t_2418 = v_b_2417;
  }
  V v_t_2423;
  if (heff_intLt_c(v_t_2418, v_x_2415)) {
    V v_a_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_b_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
    V v_t_2421;
    if (heff_intLe_c_lent(v_a_2419, v_b_2420, 0)) {
      heff_drop(v_b_2420);
      v_t_2421 = v_a_2419;
    } else {
      heff_drop(v_a_2419);
      v_t_2421 = v_b_2420;
    }
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2421, heff_dup(v_xs_241)));
    v_t_2423 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2422, v_b_242});
  } else {
    v_t_2423 = v_b_242;
  }
  V v_t_2424 = ({ V a_0 = v_t_2414; V a_1 = v_t_2423; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_m_2425 = heff_tr(heff_call(v_simp_244, 1, (V[]){v_t_2424}));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_lam0, 1, 4, (V[]){v_m_2425, v_xs_241, v_argv_243, v_applyTo_245});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args) {
  V v_s_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_argv_243 = heff_env(self)[2];
  V v_applyTo_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_s_2426}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_s_2429 = heff_field(v_x2_2427, 1);
    heff_take_n(v_x2_2427, 3ULL, 2);
    V v_a_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_b_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
    V v_t_2432;
    if (heff_intLe_c_lent(v_a_2430, v_b_2431, 0)) {
      heff_drop(v_b_2431);
      v_t_2432 = v_a_2430;
    } else {
      heff_drop(v_a_2430);
      v_t_2432 = v_b_2431;
    }
    V v_t_2433 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2432, v_argv_243));
    V f_ = v_applyTo_245;
    heff_room[0] = v_x_2428;
    heff_room[1] = v_t_2433;
    heff_room[2] = v_s_2429;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
Clo g_heff_2ecompile_2esimplify_2ecapturing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecapturing_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecapturing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (!heff_intLt_c_lent(MK_INT(60LL), v_x_246, 1)) {
      heff_drop(v_x_246);
      return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsNothing(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      heff_drop(v_x_246);
      return NTAG(TAG_False);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecapturing(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x2_241);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_241, 0);
      V v_xs_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_245);
        V t_0 = v_ms_244;
        V t_1 = v_xs_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ms_244;
        V t_1 = v_xs_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2echeap_str0, 6, "MkLazy");
Clo g_heff_2ecompile_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2echeap_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2echeap(V v_safe_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    heff_drop(v_all_241);
    HeffT2 v_t_245 = ({ V a_0 = v_safe_240; V a_1 = v_g_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_safe_240); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_247);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ELam: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_x31_2411 = heff_field(v_x3_242, 0);
    V v_argv_2412 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_2411)) {
    case TAG_EVar: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2414 = heff_field(v_x31_2411, 0);
      V v_x_2415 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, v_g_2414));
      V v_y_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2412));
      V v_x_2419;
      if (heff_intLt_c(v_y_2416, v_x_2415)) {
        V v_t_2417 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_241, v_g_2414));
        V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2412));
        v_x_2419 = heff_intSub(v_t_2417, v_t_2418);
      } else {
        v_x_2419 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_x_2419)) {
        V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2421 = (g_list_2emap(v_t_2420, heff_dup(v_argv_2412)));
        return ({ V a_0 = v_t_2421; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2421); r_; });
      } else {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_ELam: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_2411);
    }
  }
  case TAG_ELet: {
    V v_a_2460 = heff_field(v_x3_242, 1);
    V v_b_2461 = heff_field(v_x3_242, 2);
    V v_t_2462 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_2460));
    if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
      heff_drop(v_t_2462);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2461;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2462);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2463 = heff_field(v_x3_242, 0);
    V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
    V v_t_2466 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2463)));
    V v_t_2467 = (g_list_2emap(v_t_2465, v_t_2466));
    return ({ V a_0 = v_t_2467; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2467); r_; });
  }
  case TAG_EProj: {
    V v_e_2468 = heff_field(v_x3_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_all_241;
    V t_2 = v_e_2468;
    v_safe_240 = t_0;
    v_all_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_t_2472 = heff_field(v_x3_242, 0);
    V v_argv_2473 = heff_field(v_x3_242, 1);
    if (!heff_strEq_c_lent(v_t_2472, ((V)&g_heff_2ecompile_2esimplify_2echeap_str0), 2)) {
      V v_t_2475 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
      V v_t_2476 = (g_list_2emap(v_t_2475, heff_dup(v_argv_2473)));
      return ({ V a_0 = v_t_2476; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2476); r_; });
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return NTAG(TAG_False);
    }
  }
  case TAG_EMatch: {
    V v_sc_2477 = heff_field(v_x3_242, 0);
    V v_arms_2478 = heff_field(v_x3_242, 1);
    V v_t_2479 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_sc_2477));
    if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
      heff_drop(v_t_2479);
      switch (heff_tag_of(v_arms_2478)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2482 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2483 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2478)));
        V v_t_2484 = (g_list_2emap(v_t_2482, v_t_2483));
        return ({ V a_0 = v_t_2484; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2484); r_; });
      }
      default: return heff_nomatch(v_arms_2478);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2479);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2486 = heff_field(v_x3_242, 0);
    V v_argv_2487 = heff_field(v_x3_242, 1);
    V v_x1_2488 = ({ V a_0 = v_p_2486; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if (!(heff_dup(v_x1_2488) == NTAG(TAG_True))) {
      heff_drop(v_x1_2488);
      V v_t_2489 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
      V v_t_2490 = (g_list_2emap(v_t_2489, heff_dup(v_argv_2487)));
      return ({ V a_0 = v_t_2490; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2490); r_; });
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_x1_2488);
      return NTAG(TAG_False);
    }
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_24100 = heff_field(v_x3_242, 0);
    V v_t_24101 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
    V v_t_24102 = (g_heff_2ecompile_2eir_2econdOnto(v_c_24100, NTAG(TAG_Nil)));
    V v_t_24103 = (g_list_2emap(v_t_24101, v_t_24102));
    return ({ V a_0 = v_t_24103; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24103); r_; });
  }
  case TAG_ESet: {
    V v_a_24105 = heff_field(v_x3_242, 1);
    V v_b_24106 = heff_field(v_x3_242, 2);
    V v_t_24107 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_24105));
    if ((heff_dup(v_t_24107) == NTAG(TAG_True))) {
      heff_drop(v_t_24107);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_24106;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_24107);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_24108 = heff_field(v_x3_242, 0);
    V v_t_24109 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_240, v_all_241}));
    V v_t_24110 = (g_list_2emap(v_t_24109, heff_dup(v_es_24108)));
    return ({ V a_0 = v_t_24110; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24110); r_; });
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2echeap(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2ematchApplied_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchApplied_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchApplied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchApplied_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ematchApplied(V v_r_240, V v_s_241, V v_arms_242, V v_argv_243, V v_z_244) {
top: ;
  V v_t_245 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_243)));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_245); r_; });
  if (((heff_dup(v_t_246) == NTAG(TAG_True)) && ({ V v_t_247 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_243))); int c_ = ({ V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_242)); int c_ = ({ V v_t_2423 = heff_intMul(heff_dup(v_t_247), heff_intSub(heff_dup(v_t_248), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2423, MK_INT(120LL), 2); heff_drop(v_t_2423); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }))) {
    heff_drop(v_t_246);
    V v_m_2418 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_lam0, 1, 2, (V[]){v_r_240, v_argv_243}), v_arms_242));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_s_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_x_2420}), v_s_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  } else {
    heff_drop(v_t_246);
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2ehandlerPushed(v_arms_242, heff_dup(v_argv_243)));
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epushBound(v_r_240, v_s_241, v_arms_242, v_argv_243, v_z_244);
    } else {
      heff_drop(v_t_2422);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowerPushed(v_r_240, v_s_241, v_arms_242, v_argv_243, v_z_244);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchApplied(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2ematchApplied_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_argv_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_a_249, 0);
    V v_vs_2411 = heff_field(v_a_249, 1);
    V v_b_2412 = heff_field(v_a_249, 2);
    heff_take_n(v_a_249, 7ULL, 3);
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2eapplyArm(v_r_240, v_b_2412, v_argv_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_lam1, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eknownMade_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_h_240; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_h_240), heff_dup(v_b_241)));
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_h_240; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_f_249;
  if (heff_intLt_c(v_t_244, v_t_246)) {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
    V v_x_248 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_247));
    if (!heff_intLt_c_lent(MK_INT(1200LL), v_x_248, 1)) {
      heff_drop(v_x_248);
      v_f_249 = (g_heff_2ecompile_2esimplify_2erecordAll(v_h_240, v_b_241, v_s_242));
    } else {
      heff_drop(v_h_240);
      heff_drop(v_b_241);
      heff_drop(v_x_248);
      v_f_249 = v_s_242;
    }
  } else {
    heff_drop(v_h_240);
    heff_drop(v_b_241);
    v_f_249 = v_s_242;
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_249}});
}
Clo g_heff_2ecompile_2esimplify_2eunLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunLam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunLam(V v_e_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_240, 0);
    V v_b_245 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2ezipL(v_ys_244, v_argv_241));
    return ({ V a_0 = v_t_246; V a_1 = v_b_245; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_ESet: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2emkApp(v_e_240, v_argv_241);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eunLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunLam(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eonceEach_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_seen_240, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_seen_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(v_seen_240, v_x_243, NTAG(TAG_MkUnit)));
        V t_0 = v_t_2411;
        V t_1 = v_xs_244;
        V t_2 = v_cell_249;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyItems_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esimplifyItems(V v_n0_240, V v_sg_241, V v_vers_242, V v_kept_243, V v_items_244) {
top: ;
  V v_safe_245 = heff_take_field(v_sg_241, 0);
  V v_total_246 = heff_get_n(v_sg_241, 1, 2);
  V v_t_247 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_248 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_242, v_kept_243, NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
  HeffT2 v_t_249 = (g_prelude_2etraverse_24s1182736556x1844399207_24cpr(v_items_244, heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_safe_245), v_safe_245, v_total_246, heff_dup(g_std_2emap_2eempty_get()), v_t_247, v_t_248})));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_out_2412 = v_field_2410;
    V v_st_2413 = v_field_2411;
    V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_2412)));
    V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_2412)));
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_list_2emap_24s1937570095x2110149801(v_out_2412));
    V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = ({ V a_0 = heff_dup(v_st_2413); V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2419); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2415, heff_get_n(v_st_2413, 0, 9), v_t_2417, v_t_2420});
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyItems(a[0], a[1], a[2], a[3], a[4]);
}